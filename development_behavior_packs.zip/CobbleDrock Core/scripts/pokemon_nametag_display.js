import { system, world } from "@minecraft/server";
import { speciesData } from "./battle_math.js";
import { loadPokemonFromEntity } from "./storage.js";
import { anyUncaughtViewerNear, anyUnidentifiedViewerNear, hasCaughtSpecies, isIdentified } from "./identification.js";
import { isScanTargetNameTagLocked } from "./pokedex_system.js";


const REAL_NAME_TAG_PROPERTY = "lota:real_nametag";
const UNKNOWN_NAME_TAG_PROPERTY = "lota:unknown_nametag";
const CAUGHT_NAME_TAG_PROPERTY = "lota:caught_nametag";
const CAUGHT_BALL_GLYPH = String.fromCharCode(0xE600);
const MANAGE_RANGE = 40;
const MANAGE_INTERVAL_TICKS = 5;

const managedWildPokemon = new Map();

function wildDisplayName(pokemonData, typeIdFallback) {
    const nickname = String(pokemonData?.nickname || "");
    const rawSpecies = String(pokemonData?.species || typeIdFallback || "");
    const speciesKey = rawSpecies.replace("lota:", "").toLowerCase();
    const base = nickname || speciesData(pokemonData || typeIdFallback)?.name || speciesKey || "Unknown";
    return pokemonData?.isAlpha === true ? `§cAlpha ${base}§f` : base;
}

function wildNameTagVariants(pokemonData, typeIdFallback) {
    const displayName = wildDisplayName(pokemonData, typeIdFallback);
    const level = Math.max(1, Math.floor(Number(pokemonData?.level) || 1));
    return {
        real: `§f${displayName} Lv. ${level}§r`,
        caught: `§f${CAUGHT_BALL_GLYPH} ${displayName} Lv. ${level}§r`,
        unknown: "§f???§r"
    };
}

function ensureNameTagProperties(entity) {
    const variants = wildNameTagVariants(loadPokemonFromEntity(entity) || undefined, entity.typeId);
    let stored;
    try { stored = entity.getDynamicProperty(REAL_NAME_TAG_PROPERTY); } catch (error) {}
    let storedUnknown;
    try { storedUnknown = entity.getDynamicProperty(UNKNOWN_NAME_TAG_PROPERTY); } catch (error) {}
    let storedCaught;
    try { storedCaught = entity.getDynamicProperty(CAUGHT_NAME_TAG_PROPERTY); } catch (error) {}
    if (stored === variants.real && storedUnknown === variants.unknown && storedCaught === variants.caught) return variants;
    try {
        entity.setDynamicProperty(REAL_NAME_TAG_PROPERTY, variants.real);
        entity.setDynamicProperty(UNKNOWN_NAME_TAG_PROPERTY, variants.unknown);
        entity.setDynamicProperty(CAUGHT_NAME_TAG_PROPERTY, variants.caught);
    } catch (error) {}
    return variants;
}

export function applyWildPokemonNameTags(entity, pokemonData) {
    if (!entity?.isValid) return;
    const variants = wildNameTagVariants(pokemonData, entity.typeId);
    try {
        entity.setDynamicProperty(REAL_NAME_TAG_PROPERTY, variants.real);
        entity.setDynamicProperty(UNKNOWN_NAME_TAG_PROPERTY, variants.unknown);
        entity.setDynamicProperty(CAUGHT_NAME_TAG_PROPERTY, variants.caught);
    } catch (error) {}

    let initial = variants.real;
    try {
        if (isWildGatedPokemon(entity)) {
            if (anyUnidentifiedViewerNear(entity.dimension, entity.location, entity, MANAGE_RANGE)) {
                initial = variants.unknown;
            } else if (!anyUncaughtViewerNear(entity.dimension, entity.location, entity, MANAGE_RANGE)) {
                initial = variants.caught;
            }
        }
    } catch (error) {}
    try { entity.nameTag = initial; } catch (error) {}
}

export function storedRealNameTag(entity) {
    try {
        if (entity?.isValid) return ensureNameTagProperties(entity).real;
    } catch (error) {}
    try { return String(entity?.nameTag || ""); } catch (error) { return ""; }
}

function isWildGatedPokemon(entity) {
    if (!entity?.isValid) return false;
    try {
        const typeId = String(entity.typeId || "");
        if (!typeId.startsWith("lota:") || typeId.endsWith("_projectile") || typeId === "lota:poke_ball_capture") return false;
        if (!speciesData(typeId)) return false;
        if (entity.hasTag("lota:party_pokemon") || entity.hasTag("lota:battle_clone")) return false;
        if (String(entity.getDynamicProperty("lota:party_owner_id") || "")) return false;
        if (isScanTargetNameTagLocked(entity.id)) return false;
        return true;
    } catch (error) {
        return false;
    }
}

function applyNameTag(entity, desired) {
    if (!desired) return;
    try {
        if (entity.nameTag !== desired) entity.nameTag = desired;
    } catch (error) {}
}

system.runInterval(() => {
    const viewers = new Map();
    for (const player of world.getAllPlayers()) {
        if (!player?.isValid) continue;
        let nearby;
        try {
            nearby = player.dimension.getEntities({
                location: player.location,
                maxDistance: MANAGE_RANGE,
                families: ["pokemon"]
            });
        } catch (error) {
            continue;
        }
        for (const entity of nearby) {
            if (!isWildGatedPokemon(entity)) continue;
            let entry = viewers.get(entity.id);
            if (!entry) {
                entry = { entity, total: 0, identified: 0, caught: 0 };
                viewers.set(entity.id, entry);
            }
            entry.total += 1;
            if (isIdentified(player, entity)) entry.identified += 1;
            if (hasCaughtSpecies(player, entity)) entry.caught += 1;
        }
    }

    for (const entry of viewers.values()) {
        const entity = entry.entity;
        if (!entity.isValid) continue;
        managedWildPokemon.set(entity.id, entity);
        const variants = ensureNameTagProperties(entity);
        applyNameTag(entity, entry.identified === entry.total
            ? (entry.caught === entry.total ? variants.caught : variants.real)
            : variants.unknown);
    }

    for (const [entityId, entity] of managedWildPokemon) {
        if (viewers.has(entityId)) continue;
        managedWildPokemon.delete(entityId);
        if (!entity.isValid) continue;
        applyNameTag(entity, ensureNameTagProperties(entity).real);
    }
}, MANAGE_INTERVAL_TICKS);
