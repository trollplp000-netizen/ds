import { experienceToNextLevel } from "./experience.js";

export const EXPERIENCE_ITEMS = Object.freeze({
    "lota:rare_candy": Object.freeze({ rarity: "rare", experience: null }),
    "lota:exp_candy_xs": Object.freeze({ rarity: "common", experience: 100 }),
    "lota:exp_candy_s": Object.freeze({ rarity: "common", experience: 800 }),
    "lota:exp_candy_m": Object.freeze({ rarity: "common", experience: 3000 }),
    "lota:exp_candy_l": Object.freeze({ rarity: "common", experience: 10000 }),
    "lota:exp_candy_xl": Object.freeze({ rarity: "common", experience: 30000 })
});

export const EXPERIENCE_ITEM_IDS = Object.freeze(Object.keys(EXPERIENCE_ITEMS));
export const EXPERIENCE_ITEM_ID_SET = new Set(EXPERIENCE_ITEM_IDS);

export function experienceItemYield(itemId, pokemon) {
    const item = EXPERIENCE_ITEMS[itemId];
    if (!item || !pokemon) return 0;
    return item.experience === null
        ? experienceToNextLevel(pokemon)
        : item.experience;
}

function tooltipKey(itemId) {
    return `item.cobblemon.${String(itemId).replace(/^lota:/, "")}.tooltip`;
}

function containsTranslation(rawMessage, key) {
    if (!rawMessage || typeof rawMessage !== "object") return false;
    if (rawMessage.translate === key) return true;
    return Array.isArray(rawMessage.rawtext)
        && rawMessage.rawtext.some(part => containsTranslation(part, key));
}

export function experienceItemTooltipLine(itemId) {
    if (!EXPERIENCE_ITEM_ID_SET.has(itemId)) return undefined;
    return {
        rawtext: [
            { text: "§7" },
            { translate: tooltipKey(itemId) }
        ]
    };
}

export function withExperienceItemTooltip(itemId, rawLore = []) {
    const line = experienceItemTooltipLine(itemId);
    if (!line) return undefined;
    const key = tooltipKey(itemId);
    const current = Array.isArray(rawLore) ? rawLore : [];
    if (current.some(existing => containsTranslation(existing, key))) return undefined;
    return [line, ...current].slice(0, 20);
}
