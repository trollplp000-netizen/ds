import { world, system, ItemStack } from "@minecraft/server";
import { ALPHA_CONFIG } from "./alpha_config.js";
import { ALPHA_DATA } from "./alpha_data.js";
import {
  loadPokemonFromEntity,
  savePokemonToEntity,
  generateRandomPokemon,
  loadPartyFromPlayer,
  savePartyToPlayer,
  subscribePartySaved,
} from "./storage.js";
import { speciesData } from "./battle_math.js";
import { highestNaturalSpawnPartyLevel } from "./natural_spawn_rules.js";

const CFG = ALPHA_CONFIG;
const K = CFG.keys;
const NATURAL_SPAWN_TAG = "lota:natural_spawn";
const PARTY_POKEMON_TAG = "lota:party_pokemon";
const ALPHA_TAG = "lota:alpha";
const GLOW_TRACKED_TAG = "lota:alpha_glow_tracked";
const VISUAL_RESTORED_TAG = "lota:alpha_visual_restored";
const DIMENSIONS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];

function speciesKeyOf(entity) {
  try {
    return String(entity?.typeId || "").replace("lota:", "").toLowerCase();
  } catch (e) {
    return "";
  }
}

function isValid(entity) {
  try {
    return Boolean(entity && entity.isValid);
  } catch (e) {
    return false;
  }
}

function findEntityByPokemonUuid(uuid, preferredDimensionId) {
  if (!uuid) return undefined;
  const order = [preferredDimensionId, ...DIMENSIONS].filter((v, i, a) => v && a.indexOf(v) === i);
  for (const dimId of order) {
    let dimension;
    try {
      dimension = world.getDimension(dimId);
    } catch (e) {
      continue;
    }
    let entities = [];
    try {
      entities = dimension.getEntities({ families: ["pokemon"] });
    } catch (e) {
      continue;
    }
    for (const candidate of entities) {
      if (!isValid(candidate)) continue;
      let mon;
      try {
        mon = loadPokemonFromEntity(candidate);
      } catch (e) {
        continue;
      }
      if (mon && mon.uuid === uuid) return candidate;
    }
  }
  return undefined;
}

function randomInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

function pickLevelBonus(highest) {
  for (const row of CFG.levelBonusTable) {
    if (highest <= row.maxHighest) return row.bonus;
  }
  return CFG.levelBonusTable[CFG.levelBonusTable.length - 1].bonus;
}

function pickExpCandy(level) {
  for (const row of CFG.drops.expCandyByLevel) {
    if (level <= row.maxLevel) return row.item;
  }
  return "lota:exp_candy_xl";
}

function nearestPlayer(dimension, location, maxDistance) {
  let best, bestDist = Infinity;
  let players = [];
  try {
    players = dimension.getPlayers();
  } catch (e) {
    return undefined;
  }
  for (const p of players) {
    if (!isValid(p)) continue;
    const dx = p.location.x - location.x, dy = p.location.y - location.y, dz = p.location.z - location.z;
    const d = Math.hypot(dx, dy, dz);
    if (d < bestDist && (maxDistance == null || d <= maxDistance)) {
      bestDist = d;
      best = p;
    }
  }
  return best;
}

function highestPartyLevelNear(dimension, location) {
  const player = nearestPlayer(dimension, location, undefined);
  if (!player) return CFG.levelWhenNoParty;
  let party = [];
  try {
    party = loadPartyFromPlayer(player);
  } catch (e) {
    return CFG.levelWhenNoParty;
  }
  const highest = highestNaturalSpawnPartyLevel(party);
  return Number.isFinite(highest) ? highest : CFG.levelWhenNoParty;
}

function computeAlphaLevel(dimension, location) {
  const highest = highestPartyLevelNear(dimension, location);
  const bonus = pickLevelBonus(highest);
  const formulaLevel = highest + bonus;
  const [floorMin, floorMax] = CFG.minLevelFloorRange;
  const floor = randomInt(floorMin, floorMax);
  return Math.max(1, Math.min(CFG.maxAlphaLevel, Math.max(formulaLevel, floor)));
}

function displayName(species) {
  const data = speciesData(species);
  if (data?.name) return data.name;
  return species.charAt(0).toUpperCase() + species.slice(1);
}

function stripAlphaPrefix(mon, species) {
  if (!mon) return false;
  const current = String(mon.nickname || "");
  const cleaned = current.replace(/^(?:\u00a7[0-9a-fk-or])*\s*Alpha\s+/i, "").trim();
  const fallback = displayName(String(species || mon.species || "").replace(/^lota:/, "").toLowerCase());
  const next = cleaned || fallback;
  if (next === current) return false;
  mon.nickname = next;
  return true;
}

const alphaRegistry = new Map();
const herdMemberOf = new Map();
let recentlyHandledUuids = new Map();

function rememberCapturedUuid(uuid) {
  if (!uuid) return;
  recentlyHandledUuids.set(uuid, Date.now());
}

function cleanupHandledUuids() {
  const now = Date.now();
  for (const [uuid, t] of recentlyHandledUuids) {
    if (now - t > 60000) recentlyHandledUuids.delete(uuid);
  }
}

function finalizeAlphaEntity(entity, opts = {}) {
  if (!isValid(entity)) return;
  if (entity.hasTag(PARTY_POKEMON_TAG)) return;
  const species = speciesKeyOf(entity);
  const meta = ALPHA_DATA[species];
  if (!meta) return;

  let mon = loadPokemonFromEntity(entity);
  const isFreshSummon = !mon;
  if (isFreshSummon) {
    const fallbackLevel = Number.isFinite(opts.forcedLevel)
      ? opts.forcedLevel
      : computeAlphaLevel(entity.dimension, entity.location);
    mon = generateRandomPokemon(entity.typeId, fallbackLevel);
  }

  const level = Number.isFinite(opts.forcedLevel)
    ? Math.max(1, Math.min(CFG.maxAlphaLevel, Math.floor(opts.forcedLevel)))
    : computeAlphaLevel(entity.dimension, entity.location);

  const baseHp = Math.max(1, Number(speciesData(species)?.baseStats?.hp) || 45);
  const hpIv = Math.max(0, Math.min(31, Math.floor(Number(mon.ivs?.hp)) || 0));
  const newMaxHp = Math.floor((2 * baseHp + hpIv) * level / 100) + level + 10;
  const hpRatio = Number(mon.maxHp) > 0 ? Math.max(0, Math.min(1, Number(mon.currentHp) / Number(mon.maxHp))) : 1;

  mon.level = level;
  mon.maxHp = newMaxHp;
  mon.currentHp = Math.max(1, Math.round(newMaxHp * hpRatio));
  mon.isAlpha = true;
  stripAlphaPrefix(mon, species);
  const aspects = Array.isArray(mon.aspects) ? mon.aspects.slice() : [];
  if (!aspects.includes("alpha")) aspects.push("alpha");
  mon.aspects = aspects;

  if (CFG.wildMightEnabled) {
    const numBoosts = 1 + Math.floor(level / 10);
    const stages = { ...(mon.battleState?.stages || {}) };
    for (let i = 0; i < numBoosts; i++) {
      const stat = CFG.wildMightStats[Math.floor(Math.random() * CFG.wildMightStats.length)];
      stages[stat] = Math.max(-6, Math.min(6, Math.round(Number(stages[stat]) || 0) + 1));
    }
    mon.alphaWildMight = { ...stages };
    mon.battleState = { ...(mon.battleState || {}), stages };
  }

  savePokemonToEntity(entity, mon);

  try {
    entity.triggerEvent("lota:alpha");
  } catch (e) {
  }
  try {
    entity.nameTag = `\u00a7f\u00a7cAlpha ${mon.nickname} \u00a7fLv. ${mon.level}\u00a7r`;
  } catch (e) {}
  try {
    entity.addTag(ALPHA_TAG);
  } catch (e) {}

  const reg = {
    entity,
    species,
    level: mon.level,
    uuid: mon.uuid,
    dimensionId: entity.dimension.id,
    location: { ...entity.location },
    herd: new Set(),
    lastGreetedPlayerId: undefined,
  };
  alphaRegistry.set(entity.id, reg);

  const cameFromNaturalSpawn = opts.natural === true;
  if (cameFromNaturalSpawn && CFG.herdEnabled && meta.pool === "herd" && meta.base && meta.base !== species) {
    spawnHerd(entity, meta, reg);
  }
}

function spawnHerd(alphaEntity, meta, reg) {
  const baseType = `lota:${meta.base}`;
  const count = randomInt(CFG.herdMinSize, CFG.herdMaxSize);
  const herdLevel = Math.max(1, reg.level - CFG.herdLevelPenalty);
  const dimension = alphaEntity.dimension;
  const origin = alphaEntity.location;

  for (let i = 0; i < count; i++) {
    try {
      const angle = Math.random() * Math.PI * 2;
      const dist = 1.5 + Math.random() * CFG.herdSpawnRadius;
      const pos = { x: origin.x + Math.cos(angle) * dist, y: origin.y, z: origin.z + Math.sin(angle) * dist };
      const herdEntity = dimension.spawnEntity(baseType, pos);
      const herdMon = generateRandomPokemon(baseType, herdLevel);
      savePokemonToEntity(herdEntity, herdMon);
      herdEntity.addTag(NATURAL_SPAWN_TAG);
      herdEntity.addTag(K.isAlphaChecked);
      herdEntity.addTag(K.herdMember);
      try {
        herdEntity.setDynamicProperty("lota:natural_spawn_age", 0);
      } catch (e) {}
      try {
        herdEntity.setProperty("lota:scale_factor", 0.8 + 0.4 * Math.random());
        herdEntity.setProperty("lota:is_shiny", herdMon.isShiny ? 1 : 0);
      } catch (e) {}
      herdEntity.nameTag = `\u00a7f${herdMon.nickname} Lv. ${herdMon.level}\u00a7r`;
      reg.herd.add(herdEntity.id);
      herdMemberOf.set(herdEntity.id, alphaEntity.id);
    } catch (e) {
    }
  }
}

function scanNaturalSpawns() {
  for (const dimId of DIMENSIONS) {
    let dimension;
    try {
      dimension = world.getDimension(dimId);
    } catch (e) {
      continue;
    }
    let candidates = [];
    try {
      candidates = dimension.getEntities({ tags: [NATURAL_SPAWN_TAG] });
    } catch (e) {
      continue;
    }
    for (const entity of candidates) {
      if (!isValid(entity)) continue;
      if (entity.hasTag(K.isAlphaChecked)) continue;
      try {
        entity.addTag(K.isAlphaChecked);
      } catch (e) {}
      const species = speciesKeyOf(entity);
      const meta = ALPHA_DATA[species];
      if (!meta || !meta.pool) continue;
      const chance = meta.legendary
        ? CFG.naturalAlphaChanceLegendary
        : meta.pool === "herd"
        ? CFG.naturalAlphaChanceHerd
        : CFG.naturalAlphaChanceSolo;
      if (Math.random() >= chance) continue;
      finalizeAlphaEntity(entity, { natural: true });
    }
  }
}

function scanManualAlphas() {
  for (const dimId of DIMENSIONS) {
    let dimension;
    try {
      dimension = world.getDimension(dimId);
    } catch (e) {
      continue;
    }
    let entities = [];
    try {
      entities = dimension.getEntities({ families: ["pokemon"] });
    } catch (e) {
      continue;
    }
    for (const entity of entities) {
      if (!isValid(entity)) continue;
      if (entity.hasTag(PARTY_POKEMON_TAG)) continue;
      if (entity.hasTag(GLOW_TRACKED_TAG)) continue;
      let flagged = false;
      try {
        flagged = Number(entity.getProperty("lota:is_alpha")) >= 1 || entity.getProperty("lota:is_alpha") === true;
      } catch (e) {
        flagged = false;
      }
      if (!flagged) continue;
      try {
        entity.addTag(GLOW_TRACKED_TAG);
      } catch (e) {}
      if (!alphaRegistry.has(entity.id)) {
        finalizeAlphaEntity(entity, { natural: false });
      }
    }
  }
}

function restoreOwnedAlphaVisuals() {
  for (const dimId of DIMENSIONS) {
    let dimension;
    try {
      dimension = world.getDimension(dimId);
    } catch (e) {
      continue;
    }
    let entities = [];
    try {
      entities = dimension.getEntities({ tags: [PARTY_POKEMON_TAG] });
    } catch (e) {
      continue;
    }
    for (const entity of entities) {
      if (!isValid(entity)) continue;
      if (entity.hasTag(VISUAL_RESTORED_TAG)) continue;

      let mon;
      try {
        mon = loadPokemonFromEntity(entity);
      } catch (e) {
        continue;
      }
      if (!mon) continue;

      try {
        entity.addTag(VISUAL_RESTORED_TAG);
      } catch (e) {}
      if (!mon.isAlpha) continue;
      try {
        entity.setProperty("lota:is_alpha", true);
      } catch (e) {}
      try {
        stripAlphaPrefix(mon, speciesKeyOf(entity));
        entity.nameTag = `\u00a7f${mon.nickname} Lv. ${mon.level}\u00a7r`;
      } catch (e) {}
    }
  }
}


function reapplyAlphaToEntity(entity) {
  try {
    entity.setProperty("lota:is_alpha", true);
  } catch (e) {}
  try {
    entity.triggerEvent("lota:alpha");
  } catch (e) {}
}

let upkeepTick = 0;
function upkeepAlphas() {
  upkeepTick++;
  const doLeashCheck = upkeepTick % Math.max(1, Math.round(CFG.herdLeashCheckIntervalTicks / CFG.glowIntervalTicks)) === 0;

  for (const [id, reg] of [...alphaRegistry]) {
    const entity = reg.entity;
    if (!isValid(entity)) {
      const replacement = findEntityByPokemonUuid(reg.uuid, reg.dimensionId);
      if (replacement) {
        alphaRegistry.delete(id);
        reg.entity = replacement;
        alphaRegistry.set(replacement.id, reg);
        reapplyAlphaToEntity(replacement);
        continue;
      }
      handleAlphaGone(id, reg);
      continue;
    }
    reg.location = { ...entity.location };

    try {
      entity.setDynamicProperty("lota:natural_spawn_age", 0);
    } catch (e) {}

    try {
      const player = nearestPlayer(entity.dimension, entity.location, CFG.detectionRadius);
      if (player && player.id !== reg.lastGreetedPlayerId) {
        reg.lastGreetedPlayerId = player.id;
        try {
          entity.dimension.spawnParticle("lota:alphaboost_actorburst", entity.location);
        } catch (e) {}
        try {
          entity.dimension.spawnParticle("lota:alphaboost_actor", entity.location);
        } catch (e) {}
        try {
          entity.dimension.playSound(`pokemon.${reg.species}.cry`, entity.location, { pitch: 0.75, volume: 1 });
        } catch (e) {}
      }
    } catch (e) {}

    if (doLeashCheck && reg.herd.size) {
      for (const herdId of [...reg.herd]) {
      }
    }
  }

  if (doLeashCheck) leashHerds();
  cleanupHandledUuids();
}

function leashHerds() {
  for (const [id, reg] of alphaRegistry) {
    if (!reg.herd.size || !isValid(reg.entity)) continue;
    let nearby = [];
    try {
      nearby = reg.entity.dimension.getEntities({
        location: reg.entity.location,
        maxDistance: CFG.herdLeashDistance + CFG.herdSpawnRadius + 5,
        tags: [K.herdMember],
      });
    } catch (e) {
      continue;
    }
    for (const herdId of [...reg.herd]) {
      const member = nearby.find((e) => e.id === herdId);
      if (!member || !isValid(member)) {
        reg.herd.delete(herdId);
        herdMemberOf.delete(herdId);
        continue;
      }
      const dx = member.location.x - reg.entity.location.x;
      const dz = member.location.z - reg.entity.location.z;
      if (Math.hypot(dx, dz) > CFG.herdLeashDistance) {
        try {
          const angle = Math.random() * Math.PI * 2;
          const dist = 1.5 + Math.random() * CFG.herdSpawnRadius;
          member.teleport(
            { x: reg.entity.location.x + Math.cos(angle) * dist, y: reg.entity.location.y, z: reg.entity.location.z + Math.sin(angle) * dist },
            { dimension: reg.entity.dimension }
          );
        } catch (e) {}
      }
    }
  }
}

function handleAlphaGone(id, reg) {
  alphaRegistry.delete(id);
  for (const herdId of reg.herd) herdMemberOf.delete(herdId);

  system.runTimeout(() => finishAlphaGone(reg), 40);
}

function finishAlphaGone(reg) {
  const wasCaptured = reg.uuid && recentlyHandledUuids.has(reg.uuid);
  if (reg.uuid) recentlyHandledUuids.delete(reg.uuid);
  if (wasCaptured) return;

  const replacement = findEntityByPokemonUuid(reg.uuid, reg.dimensionId);
  if (replacement) {
    reg.entity = replacement;
    alphaRegistry.set(replacement.id, reg);
    reapplyAlphaToEntity(replacement);
    return;
  }

  try {
    const dimension = world.getDimension(reg.dimensionId);
    const loc = { x: Math.floor(reg.location.x) + 0.5, y: reg.location.y + 0.2, z: Math.floor(reg.location.z) + 0.5 };
    const types = speciesData(reg.species)?.types || ["normal"];
    if (CFG.drops.typeGem) {
      try {
        dimension.spawnItem(new ItemStack(`lota:${types[0]}_gem`, 1), loc);
      } catch (e) {}
    }
    try {
      dimension.spawnItem(new ItemStack(pickExpCandy(reg.level), 1), loc);
    } catch (e) {}
    try {
      dimension.spawnItem(new ItemStack(CFG.drops.bonusItem, 1), loc);
    } catch (e) {}

    const finder = nearestPlayer(dimension, reg.location, 24);
    if (finder) {
      try {
        if (!finder.getDynamicProperty(K.firstDefeated)) {
          finder.setDynamicProperty(K.firstDefeated, true);
          finder.sendMessage(`\u00a76\u2605 \u00a7fYou defeated your first Alpha Pokemon!`);
        }
      } catch (e) {}
    }
  } catch (e) {}
}

const lastPartyUuids = new Map();

function seedPartySnapshot(player) {
  try {
    const party = loadPartyFromPlayer(player);
    lastPartyUuids.set(player.id, new Set(party.filter(Boolean).map((m) => m.uuid)));
  } catch (e) {}
}

let strippingWildMight = false;
subscribePartySaved((player) => {
  if (strippingWildMight) return;
  if (!isValid(player)) return;
  let party = [];
  try {
    party = loadPartyFromPlayer(player);
  } catch (e) {
    return;
  }
  const newSet = new Set(party.filter(Boolean).map((m) => m.uuid));
  const oldSet = lastPartyUuids.get(player.id);
  lastPartyUuids.set(player.id, newSet);
  if (!oldSet) return;

  let dirty = false;
  for (const mon of party) {
    if (mon && stripAlphaPrefix(mon)) dirty = true;
  }
  for (const mon of party) {
    if (!mon || !mon.isAlpha) continue;
    if (oldSet.has(mon.uuid)) continue;
    rememberCapturedUuid(mon.uuid);

    if (mon.battleState) {
      delete mon.battleState;
      dirty = true;
    }
    if (mon.alphaWildMight !== undefined) {
      delete mon.alphaWildMight;
      dirty = true;
    }

    try {
      const totalRaw = Number(player.getDynamicProperty(K.totalCaptured)) || 0;
      player.setDynamicProperty(K.totalCaptured, totalRaw + 1);
      if (!player.getDynamicProperty(K.firstCaught)) {
        player.setDynamicProperty(K.firstCaught, true);
        player.sendMessage(`\u00a76========================================`);
        player.sendMessage(`\u00a76\u2605 First Alpha Pokemon captured! \u00a7f${mon.nickname}`);
        player.sendMessage(`\u00a7e(A PC wallpaper reward is reserved for this milestone.)`);
        player.sendMessage(`\u00a76========================================`);
      } else {
        player.sendMessage(`\u00a7c\u2691 \u00a7fThat was an Alpha Pokemon! \u00a77(Total Alpha catches: ${totalRaw + 1})`);
      }
    } catch (e) {}
  }
  if (dirty) {
    try {
      strippingWildMight = true;
      savePartyToPlayer(player, party);
    } catch (e) {
    } finally {
      strippingWildMight = false;
    }
  }
});

world.afterEvents.playerSpawn.subscribe((e) => {
  if (e?.player && !lastPartyUuids.has(e.player.id)) seedPartySnapshot(e.player);
});
world.afterEvents.playerLeave.subscribe((e) => {
  lastPartyUuids.delete(e.playerId);
});

system.afterEvents.scriptEventReceive.subscribe((event) => {
  if (event.id !== "lota:spawn_alpha") return;
  const source = event.sourceEntity;
  if (!source || source.typeId !== "minecraft:player") return;
  try {
    const args = String(event.message || "").trim().split(/\s+/).filter(Boolean);
    const speciesRaw = String(args[0] || "").trim().toLowerCase();
    if (!speciesRaw) {
      source.sendMessage("\u00a7c[Alpha] Usage: /scriptevent lota:spawn_alpha <species> [level]");
      return;
    }
    const species = speciesRaw.replace(/^lota:/, "");
    if (!ALPHA_DATA[species]) {
      source.sendMessage(`\u00a7c[Alpha] Unknown or unsupported species: ${species}`);
      return;
    }
    const parsedLevel = Math.floor(Number(args[1]));
    const forcedLevel = Number.isFinite(parsedLevel) && parsedLevel > 0 ? Math.max(1, Math.min(100, parsedLevel)) : undefined;
    const pos = { x: source.location.x, y: source.location.y, z: source.location.z };
    const entity = source.dimension.spawnEntity(`lota:${species}`, pos);
    finalizeAlphaEntity(entity, { natural: false, forcedLevel });
    source.sendMessage(`\u00a7a[Alpha] Spawned Alpha ${displayName(species)}.`);
  } catch (err) {
    try {
      source.sendMessage(`\u00a7c[Alpha] Error: ${err}`);
    } catch (e) {}
  }
});

system.runInterval(scanNaturalSpawns, CFG.scanIntervalTicks);
system.runInterval(scanManualAlphas, CFG.scanIntervalTicks);
system.runInterval(restoreOwnedAlphaVisuals, CFG.scanIntervalTicks);
system.runInterval(upkeepAlphas, CFG.glowIntervalTicks);

export function applyAlphaWildMight(mon) {
  try {
    const might = mon && mon.isAlpha ? mon.alphaWildMight : null;
    if (!might || typeof might !== "object") return;
    const stages = { ...((mon.battleState && mon.battleState.stages) || {}) };
    for (const stat of Object.keys(might)) {
      stages[stat] = Math.max(-6, Math.min(6, Math.round(Number(might[stat]) || 0)));
    }
    mon.battleState = { ...(mon.battleState || {}), stages };
  } catch (e) {}
}
