import { system, world } from "@minecraft/server";
import { captureBallType } from "./capture_rate.js";
import { loadPartyFromPlayer, savePartyToPlayer } from "./storage.js";
import { spawnColoredFlame } from "./particle_utils.js";

const BLOCK_ID = "lota:healing_machine";
const BATTLE_TAG = "lota:battle_player";
const HEAL_TICKS = 24;
const FULL_CHARGE = 6;
const FULL_CHARGE_TICKS = 900 * 20;
const CHARGE_PER_TICK = FULL_CHARGE / FULL_CHARGE_TICKS;
const machines = new Map();
const healingPlayers = new Set();

function key(block) {
    const { x, y, z } = block.location;
    return `${block.dimension.id}:${x},${y},${z}`;
}

function actionBar(player, key, withArgs = []) {
    try {
        player.onScreenDisplay.setActionBar({
            rawtext: [{ translate: key, with: withArgs.map(value => String(value)) }]
        });
    } catch (error) {}
}

function isCreative(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function chargeLevel(charge) {
    return Math.max(0, Math.min(5, Math.floor(charge)));
}

function setState(block, state, value) {
    try {
        block.setPermutation(block.permutation.withState(state, value));
    } catch (error) {}
}

function resolveMachine(block) {
    const id = key(block);
    let machine = machines.get(id);
    if (!machine) {
        const storedLevel = Number(block.permutation.getState("lota:charge")) || 0;
        machine = {
            dimensionId: block.dimension.id,
            location: { ...block.location },
            charge: storedLevel >= 5 ? FULL_CHARGE : storedLevel,
            infinite: false,
            active: false
        };
        machines.set(id, machine);
    }
    return machine;
}

function tickMachine(block, elapsedTicks = 20) {
    if (!block || block.typeId !== BLOCK_ID) return;
    const machine = resolveMachine(block);
    if (machine.active || machine.infinite || machine.charge >= FULL_CHARGE) return;
    const previous = chargeLevel(machine.charge);
    machine.charge = Math.min(FULL_CHARGE, machine.charge + CHARGE_PER_TICK * elapsedTicks);
    const next = chargeLevel(machine.charge);
    if (next !== previous) setState(block, "lota:charge", next);
}

function healingNeed(party) {
    let total = 0;
    for (const pokemon of party) {
        if (!pokemon) continue;
        const maxHp = Math.max(1, Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1);
        const currentHp = Math.max(0, Math.min(maxHp, Number(pokemon.currentHp) || 0));
        total += 1 - currentHp / maxHp;
    }
    return total;
}

function canBeHealed(pokemon) {
    if (!pokemon) return false;
    const maxHp = Math.max(1, Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1);
    if (Number(pokemon.currentHp) < maxHp) return true;
    if (String(pokemon.statusCondition || "NONE").toUpperCase() !== "NONE") return true;
    return Array.isArray(pokemon.moves)
        && pokemon.moves.some(move => move && Number(move.pp) < Number(move.maxPp));
}

function healPokemon(pokemon) {
    const maxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1));
    pokemon.maxHp = maxHp;
    pokemon.currentHp = maxHp;
    pokemon.statusCondition = "NONE";
    if (Array.isArray(pokemon.moves)) {
        for (const move of pokemon.moves) {
            if (!move) continue;
            const maxPp = Math.max(0, Math.floor(Number(move.maxPp) || Number(move.pp) || 0));
            move.maxPp = maxPp;
            move.pp = maxPp;
        }
    }
}

function recallParty(player) {
    for (const dimensionId of ["overworld", "nether", "the_end"]) {
        let entities = [];
        try {
            entities = world.getDimension(dimensionId).getEntities({ tags: ["lota:party_pokemon"] });
        } catch (error) {
            continue;
        }
        for (const entity of entities) {
            try {
                if (String(entity.getDynamicProperty("lota:party_owner_id") || "") === player.id) {
                    const location = { ...entity.location };
                    const dimension = entity.dimension;
                    entity.remove();
                    spawnColoredFlame(dimension, location);
                }
            } catch (error) {}
        }
    }
}

function ballType(pokemon) {
    return captureBallType(pokemon?.caughtBall);
}

function clearTrayBalls(machine) {
    for (const entity of machine.trayBalls || []) {
        try { if (entity?.isValid) entity.remove(); } catch (error) {}
    }
    machine.trayBalls = [];
}

function showTrayBalls(block, machine, party) {
    clearTrayBalls(machine);
    const offsets = [
        [-0.27, -0.20], [0, -0.20], [0.27, -0.20],
        [-0.27, 0.20], [0, 0.20], [0.27, 0.20]
    ];
    machine.trayBalls = [];
    for (let index = 0; index < Math.min(6, party.length); index++) {
        if (!party[index]) continue;
        const [x, z] = offsets[index];
        try {
            const entity = block.dimension.spawnEntity("lota:healing_ball_display", {
                x: block.location.x + 0.5 + x,
                y: block.location.y + 0.69,
                z: block.location.z + 0.5 + z
            });
            entity.setProperty("lota:ball_type", ballType(party[index]));
            machine.trayBalls.push(entity);
        } catch (error) {}
    }
}

function completeHealing(block, machine, player) {
    const party = loadPartyFromPlayer(player);
    for (const pokemon of party) healPokemon(pokemon);
    savePartyToPlayer(player, party);
    setState(block, "lota:active", false);
    setState(block, "lota:heal_frame", 0);
    setState(block, "lota:charge", machine.preHealChargeState ?? chargeLevel(machine.charge));
    clearTrayBalls(machine);
    machine.active = false;
    healingPlayers.delete(player.id);
    actionBar(player, "cobblemon.healingmachine.healed");
}

function activate(block, player, machine, party) {
    const need = healingNeed(party);
    if (!machine.infinite) machine.charge = Math.max(0, machine.charge - need);
    machine.active = true;
    healingPlayers.add(player.id);
    recallParty(player);
    showTrayBalls(block, machine, party);
    setState(block, "lota:active", true);
    actionBar(player, "cobblemon.healingmachine.healing");
    try {
        block.dimension.playSound("lota.healing_machine.active", {
            x: block.location.x + 0.5,
            y: block.location.y + 0.5,
            z: block.location.z + 0.5
        });
    } catch (error) {}
    setState(block, "lota:heal_frame", 0);
    for (let tick = 0; tick < HEAL_TICKS; tick += 4) {
        system.runTimeout(() => {
            try {
                const current = block.dimension.getBlock(block.location);
                if (current?.typeId !== BLOCK_ID || !machine.active) return;
                setState(current, "lota:heal_frame", Math.min(5, tick / 4));
                current.dimension.spawnParticle("minecraft:villager_happy", {
                    x: current.location.x + 0.35 + Math.random() * 0.3,
                    y: current.location.y + 0.9,
                    z: current.location.z + 0.35 + Math.random() * 0.3
                });
            } catch (error) {}
        }, tick);
    }
    system.runTimeout(() => {
        try {
            const current = block.dimension.getBlock(block.location);
            if (current?.typeId === BLOCK_ID) completeHealing(current, machine, player);
            else healingPlayers.delete(player.id);
        } catch (error) {
            healingPlayers.delete(player.id);
        }
    }, HEAL_TICKS);
}

function useMachine(player, block) {
    if (!player?.isValid || block?.typeId !== BLOCK_ID) return;
    const machine = resolveMachine(block);
    const displayedCharge = Number(block.permutation.getState("lota:charge")) || 0;
    machine.preHealChargeState = displayedCharge;
    if (isCreative(player)) {
        machine.infinite = true;
        machine.charge = FULL_CHARGE;
    }
    if (machine.active) {
        actionBar(player, "cobblemon.healingmachine.alreadyinuse");
        return;
    }
    if (player.hasTag(BATTLE_TAG)) {
        actionBar(player, "cobblemon.healingmachine.inbattle");
        return;
    }
    const party = loadPartyFromPlayer(player);
    if (!party.length) {
        actionBar(player, "cobblemon.healingmachine.nopokemon");
        return;
    }
    if (!party.some(canBeHealed)) {
        actionBar(player, "cobblemon.healingmachine.alreadyhealed");
        return;
    }
    if (healingPlayers.has(player.id)) {
        actionBar(player, "cobblemon.healingmachine.alreadyhealing");
        return;
    }
    const need = healingNeed(party);
    if (!machine.infinite && machine.charge < need) {
        const missingPercent = Math.max(0, Math.ceil(((need - machine.charge) / party.length) * 100));
        actionBar(player, "cobblemon.healingmachine.notenoughcharge", [`${missingPercent}%`]);
        return;
    }
    activate(block, player, machine, party);
}

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    if (event.block.typeId !== BLOCK_ID || event.isFirstEvent === false) return;
    event.cancel = true;
    const player = event.player;
    const location = { ...event.block.location };
    const dimension = event.block.dimension;
    system.run(() => useMachine(player, dimension.getBlock(location)));
});

system.beforeEvents.startup.subscribe(event => {
    event.blockComponentRegistry.registerCustomComponent("lota:healing_machine_component", {
        onTick: eventData => tickMachine(eventData.block)
    });
});

world.afterEvents.playerPlaceBlock.subscribe(event => {
    if (event.block.typeId !== BLOCK_ID) return;
    const machine = resolveMachine(event.block);
    machine.infinite = isCreative(event.player);
    if (machine.infinite) {
        machine.charge = FULL_CHARGE;
    }
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    if (event.brokenBlockPermutation.type.id !== BLOCK_ID) return;
    const { x, y, z } = event.block.location;
    const id = `${event.block.dimension.id}:${x},${y},${z}`;
    const machine = machines.get(id);
    if (machine) clearTrayBalls(machine);
    machines.delete(id);
});

world.afterEvents.playerLeave.subscribe(event => healingPlayers.delete(event.playerId));
