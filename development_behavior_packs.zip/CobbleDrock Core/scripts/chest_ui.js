import { world, system, ItemStack } from "@minecraft/server";

const ANCHOR = "lota:ui_anchor";
const ANCHOR_XL = "lota:ui_anchor_xl";
const BTN = "lota:ui_button";
const BLANK = "lota:ui_blank";
const HIDDEN = "x9999y9999";
const VISIBLE = "x0000y0000";
const SENTINEL = 2;
const GLUE = 1.3;
const ANCHOR_HALF_H = 0.125;
const TICK = 2;
const REARM_TICKS = 100;
const LOST_GRACE = 30;
const SWEEP_TICKS = 200;
const RETRY_TICKS = 40;
const MAX_LORE = 50;

const screens = new Map();
const fixedHooks = new Map();
const sessions = new Map();
const retryAt = new Map();


export function chestKeys(title) {
    const out = new Map();
    for (const tok of String(title ?? "").split("|")) {
        const c = tok.indexOf(":");
        if (c > 0) out.set(tok.slice(0, c), tok.slice(c + 1));
    }
    return out;
}

export function chestTexture(entry, keys) {
    const [, key, tpl, vals] = entry;
    const v = keys.get(key);
    if (v === undefined || v === "") return null;
    if (tpl) {
        if (vals && !vals.includes(v)) return null;
        return tpl[0] + v + tpl[1];
    }
    return (vals && vals[v]) || null;
}


function paintData(c, slot, text) {
    const st = new ItemStack(BLANK, 1);
    st.nameTag = text;
    try { c.setItem(slot, st); return true; } catch { return false; }
}

function paintText(c, slot, text) {
    const st = new ItemStack(BLANK, 1);
    st.nameTag = "§f";
    st.setLore(["§r" + String(text ?? "").slice(0, MAX_LORE)]);
    try { c.setItem(slot, st); return true; } catch { return false; }
}

function paintButton(c, slot) {
    const st = new ItemStack(BTN, SENTINEL);
    st.nameTag = "§f";
    try { c.setItem(slot, st); return true; } catch { return false; }
}

function wrapLine(line, limit) {
    const out = [];
    let rest = line;
    while (rest.length > limit) {
        let cut = rest.lastIndexOf("||", limit - 1);
        if (cut > 0) cut += 1;
        else {
            const sp = rest.lastIndexOf(" ", limit);
            cut = sp > 0 ? sp + 1 : limit;
        }
        out.push(rest.slice(0, cut));
        rest = rest.slice(cut);
    }
    if (rest) out.push(rest);
    return out;
}

export function loreLines(text) {
    const lines = [];
    for (const raw of String(text ?? "").split("\n")) {
        if (raw === "") { lines.push("§r"); continue; }
        for (const part of wrapLine(raw, MAX_LORE - 2)) lines.push("§r" + part);
    }
    if (lines.length > 20) lines.splice(19, lines.length - 20);
    return lines;
}

function paintLines(c, slot, text) {
    const st = new ItemStack(BLANK, 1);
    st.nameTag = "§f";
    st.setLore(loreLines(text));
    try { c.setItem(slot, st); return true; } catch { return false; }
}

function paintTextButton(c, slot, text) {
    const st = new ItemStack(BTN, SENTINEL);
    st.nameTag = "§f";
    st.setLore(loreLines(text));
    try { c.setItem(slot, st); return true; } catch { return false; }
}

function paintOnce(session, slot, payload, paint) {
    if (session.frame.get(slot) === payload && !session.dirty.has(slot)) return true;
    if (!paint()) return false;
    session.frame.set(slot, payload);
    return true;
}

function drawFrame(session, view) {
    const c = session.container;
    const U = session.def.layout;
    const title = String(view.title ?? "");
    const keys = chestKeys(title);
    const lines = view.lines ?? [];

    for (const e of U.tex) {
        const path = chestTexture(e, keys);
        const tag = path ? VISIBLE + path : HIDDEN;
        if (!paintOnce(session, e[0], "t" + tag, () => paintData(c, e[0], tag))) return false;
    }
    for (const [slot, marker] of U.vis) {
        const tag = title.includes(marker) ? VISIBLE : HIDDEN;
        if (!paintOnce(session, slot, "v" + tag, () => paintData(c, slot, tag))) return false;
    }
    for (const slot of U.st ?? []) {
        const s = String(title);
        if (!paintOnce(session, slot, "s" + s, () => paintData(c, slot, s))) return false;
    }
    for (const [slot, line] of U.txt) {
        const s = String(lines[line] ?? "");
        if (!paintOnce(session, slot, "x" + s, () => paintText(c, slot, s))) return false;
    }
    for (const [slot, b] of U.cap) {
        const s = String(view.buttons?.[b] ?? "");
        if (!paintOnce(session, slot, "c" + s, () => paintText(c, slot, s))) return false;
    }
    for (const [slot, key] of U.ic ?? []) {
        const path = view.icons?.[key];
        const tag = path ? VISIBLE + path : HIDDEN;
        if (!paintOnce(session, slot, "i" + tag, () => paintData(c, slot, tag))) return false;
    }
    for (const [slot, key] of U.ml ?? []) {
        const text = String(view.multi?.[key] ?? "");
        if (!paintOnce(session, slot, "m" + text, () => paintLines(c, slot, text))) return false;
    }
    session.buttons.clear();
    for (const [slot, b] of U.btn) {
        if (!paintOnce(session, slot, "b", () => paintButton(c, slot))) return false;
        session.buttons.set(slot, b);
    }
    for (const [slot, b] of U.tb ?? []) {
        const text = String(view.buttons?.[b] ?? "");
        if (!paintOnce(session, slot, "T" + text, () => paintTextButton(c, slot, text))) return false;
        session.buttons.set(slot, b);
    }
    session.dirty.clear();
    return true;
}

function redraw(session) {
    let view;
    try { view = session.def.view(session.player, session.state); }
    catch (e) { console.warn(`[chest_ui] view(${session.def.key}) failed: ${e}`); return false; }
    return drawFrame(session, view);
}


function anchorAt(player) {
    const head = player.getHeadLocation();
    const v = player.getViewDirection();
    return {
        x: head.x + v.x * GLUE,
        y: head.y + v.y * GLUE - ANCHOR_HALF_H,
        z: head.z + v.z * GLUE
    };
}

function scrub(player) {
    let found = false;
    try {
        const inv = player.getComponent("minecraft:inventory")?.container;
        if (inv) {
            for (let i = 0; i < inv.size; i++) {
                const it = inv.getItem(i);
                if (it && (it.typeId === BTN || it.typeId === BLANK)) { inv.setItem(i, undefined); found = true; }
            }
        }
    } catch { }
    try {
        const cur = player.getComponent("minecraft:cursor_inventory");
        if (cur?.item && (cur.item.typeId === BTN || cur.item.typeId === BLANK)) { cur.clear(); found = true; }
    } catch { }
    return found;
}

let spawnWarned = false;

function spawnAnchor(player, title, type = ANCHOR) {
    let loc;
    try { loc = anchorAt(player); } catch { return null; }
    try { if (!player.dimension.isChunkLoaded(loc)) return null; } catch { }
    let entity;
    try { entity = player.dimension.spawnEntity(type, loc); }
    catch (e) {
        if (!spawnWarned) {
            spawnWarned = true;
            console.warn(`[chest_ui] cannot spawn ${type}: ${e}`);
        }
        return null;
    }
    try { entity.nameTag = title; } catch { }
    let container;
    try { container = entity.getComponent("minecraft:inventory")?.container; } catch { }
    if (!container) { try { entity.remove(); } catch { } return null; }
    return { entity, container };
}

function removeEntity(entity) {
    try { if (entity?.isValid) entity.remove(); } catch { }
}


export function registerChestScreen(def) {
    if (!def?.key || !def.layout?.title) throw new Error("chest screen needs key + layout.title");
    screens.set(def.key, def);
}

export function chestScreenActive(player, key) {
    const s = sessions.get(player?.id);
    return !!s && (key === undefined || s.def.key === key);
}

export function refreshChestScreen(player, key) {
    const s = sessions.get(player?.id);
    if (!s || (key !== undefined && s.def.key !== key)) return false;
    return redraw(s);
}

export function closeChestScreen(player) {
    const id = typeof player === "string" ? player : player?.id;
    const s = sessions.get(id);
    sessions.delete(id);
    if (!s) return;
    let where;
    if (s.fixed) { try { where = { dimension: s.entity.dimension, location: { ...s.entity.location } }; } catch { } }
    removeEntity(s.entity);
    if (s.player?.isValid) scrub(s.player);
    if (s.fixed && where) { try { s.onRelease?.(where.dimension, where.location); } catch (e) { console.warn(`[chest_ui] onRelease failed: ${e}`); } }
}

export function registerFixedAnchor(typeId, hook) {
    fixedHooks.set(typeId, hook);
}

export function attachChestScreen(player, key, entity, opts = {}) {
    const def = screens.get(key);
    if (!def || !player?.isValid || !entity?.isValid) return false;
    let container;
    try { container = entity.getComponent("minecraft:inventory")?.container; } catch { }
    if (!container) return false;
    if (sessions.has(player.id)) closeChestScreen(player);
    const now = system.currentTick;
    const s = {
        player, playerId: player.id, def, state: opts.state ?? def.create(player),
        entity, container, fixed: true, onRelease: opts.onRelease,
        buttons: new Map(), frame: new Map(), dirty: new Set(),
        holdUntil: now + (opts.hold ?? 1200), lost: 0, arm: 0, armFlip: false,
        activeUntil: now + 200, nextPoll: 0, lastTick: now
    };
    sessions.set(player.id, s);
    scrub(player);
    if (!redraw(s)) { closeChestScreen(player); return false; }
    return true;
}

export function openChestScreen(player, key, opts = {}) {
    const def = screens.get(key);
    if (!def || !player?.isValid) return false;
    let s = sessions.get(player.id);
    if (s && s.def.key !== key) { closeChestScreen(player); s = undefined; }
    const now = system.currentTick;
    if (s) {
        if (opts.hold) s.holdUntil = Math.max(s.holdUntil, now + opts.hold);
        if (opts.state) { s.state = opts.state; s.frame.clear(); redraw(s); }
        return true;
    }
    const made = spawnAnchor(player, def.layout.title, def.anchor ?? ANCHOR);
    if (!made) return false;
    s = {
        player, playerId: player.id, def, state: opts.state ?? def.create(player),
        entity: made.entity, container: made.container,
        buttons: new Map(), frame: new Map(), dirty: new Set(),
        holdUntil: now + (opts.hold ?? 0), lost: 0, arm: 0, armFlip: false,
        activeUntil: 0, nextPoll: 0, lastTick: now
    };
    sessions.set(player.id, s);
    scrub(player);
    if (!redraw(s)) { closeChestScreen(player); return false; }
    return true;
}


function tickSession(s, now) {
    const p = s.player;
    if (!p?.isValid || !s.entity?.isValid || !s.container?.isValid) {
        closeChestScreen(s.playerId);
        return;
    }

    const active = now < s.activeUntil;
    const slow = (now % TICK) === 0;
    if (!active && !slow) return;
    const dt = Math.max(1, now - s.lastTick);
    s.lastTick = now;

    let wanted = false;
    try { wanted = s.def.wants(p) || now < s.holdUntil; } catch { wanted = false; }
    if (!wanted) {
        s.lost += dt;
        if (s.lost >= LOST_GRACE) { closeChestScreen(p); return; }
    } else {
        s.lost = 0;
    }

    if (slow && !s.fixed) {
        try { s.entity.teleport(anchorAt(p), { dimension: p.dimension }); }
        catch { }
    }
    const pushed = scrub(p);

    if (!s.fixed && (s.arm += dt) >= REARM_TICKS) {
        s.arm = 0;
        s.armFlip = !s.armFlip;
        try {
            s.entity.triggerEvent(s.armFlip ? "lota:ui_helper_life_b" : "lota:ui_helper_life_a");
        } catch { }
    }

    if (!pushed && now < s.nextPoll) return;
    s.nextPoll = now + (active ? 10 : 20);
    for (const [slot, b] of s.buttons) {
        let it;
        try { it = s.container.getItem(slot); } catch { return; }
        if (it && it.typeId === BTN && it.amount === SENTINEL) continue;
        s.dirty.add(slot);
        s.holdUntil = Math.max(s.holdUntil, now + 1200);
        s.activeUntil = now + 200;
        scrub(p);
        let result = "redraw";
        try { result = s.def.press(p, s.state, b) ?? "redraw"; }
        catch (e) { console.warn(`[chest_ui] press(${s.def.key}) failed: ${e}`); }
        if (result === "close") { closeChestScreen(p); return; }
        if (!redraw(s)) { closeChestScreen(p); return; }
        break;
    }
}

system.runInterval(() => {
    const now = system.currentTick;

    for (const [id, s] of [...sessions]) {
        if (!s.player?.isValid) closeChestScreen(id);
    }

    for (const player of world.getAllPlayers()) {
        if (!player.isValid) continue;
        const s = sessions.get(player.id);
        if (s) { tickSession(s, now); continue; }
        if (now % TICK) continue;
        for (const def of screens.values()) {
            let want = false;
            try { want = def.wants(player); } catch { want = false; }
            if (!want) continue;
            if ((retryAt.get(player.id) ?? 0) > now) break;
            if (!openChestScreen(player, def.key)) retryAt.set(player.id, now + RETRY_TICKS);
            else retryAt.delete(player.id);
            break;
        }
    }
}, 1);

system.runInterval(() => {
    const owned = new Set();
    for (const s of sessions.values()) { try { owned.add(s.entity.id); } catch { } }
    for (const dim of ["overworld", "nether", "the_end"]) {
        let list = [];
        try {
            list = [
                ...world.getDimension(dim).getEntities({ type: ANCHOR }),
                ...world.getDimension(dim).getEntities({ type: ANCHOR_XL })
            ];
        } catch { continue; }
        for (const e of list) {
            let id; try { id = e.id; } catch { continue; }
            if (!owned.has(id)) removeEntity(e);
        }
    }
}, SWEEP_TICKS);

world.afterEvents.playerInteractWithEntity?.subscribe((ev) => {
    let hook;
    try { hook = fixedHooks.get(ev.target?.typeId); } catch { hook = undefined; }
    if (hook) {
        try { hook(ev.player, ev.target); }
        catch (e) { console.warn(`[chest_ui] fixed anchor hook failed: ${e}`); }
        return;
    }
    const s = sessions.get(ev.player?.id);
    if (!s) return;
    let same = false;
    try { same = ev.target?.id === s.entity?.id; } catch { same = false; }
    if (!same) return;
    try { s.def.onOpen?.(s.player, s.state); }
    catch (e) { console.warn(`[chest_ui] onOpen(${s.def.key}) failed: ${e}`); }
    s.activeUntil = system.currentTick + 200;
    system.run(() => { if (sessions.get(s.playerId) === s) redraw(s); });
});

world.afterEvents.playerLeave.subscribe((ev) => {
    retryAt.delete(ev.playerId);
    closeChestScreen(ev.playerId);
});
