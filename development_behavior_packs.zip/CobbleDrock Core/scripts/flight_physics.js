export const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const toward = (value, target, amount) => value + clamp(target - value, -amount, amount);

export function rideStat(profile, stat, maximum, minimum, boosts = {}) {
    const [low, high = low] = String(profile.stats[stat] || '0').split('-').map(Number);
    const value = Math.min(high, low + Math.max(0, Number(boosts[stat]) || 0));
    return minimum + (maximum - minimum) * value / 100;
}

export function flightParameters(profile, boosts = {}) {
    const stat = (name, max, min) => rideStat(profile, name, max, min, boosts);
    if (profile.style === 'hover') {
        const speed=stat('SPEED',20,1)/20;
        return {style:'hover',speed,acceleration:speed/(stat('ACCELERATION',1,6)*20),
            multiplier:1,vertical:speed,staminaSeconds:stat('STAMINA',60,0),
            hoverHeight:stat('JUMP',32,2),turnPerTick:stat('SKILL',270,45)/20};
    }
    const rocket = profile.style === 'rocket', jet = profile.style === 'jet';
    const speed = rocket ? stat('SPEED', .5, .1) : stat('SPEED', jet ? 24 : 20, 4) / 20;
    return {
        style:profile.style, speed,
        acceleration:rocket ? stat('ACCELERATION',1/(20*1.5),1/(20*3))*.5 : speed/(stat('ACCELERATION',2,8)*20),
        multiplier:rocket ? 5 : stat('JUMP',2,1),
        vertical:rocket ? stat('JUMP',4,1) : speed/2,
        staminaSeconds:stat('STAMINA',rocket ? 96 : jet ? 120 : 80,rocket ? 1 : jet ? 4 : 0),
        turnPerTick:stat('SKILL',jet ? 50 : 45,jet ? 25 : 10)/20
    };
}

export function newFlightState(yaw = 0, stamina = 1) {
    return {forward:0, vertical:0, yaw, pitch:0, stamina, noStaminaTicks:0};
}

export function stepFlight(state, input, params) {
    const next = {...state};
    const forward = clamp(Number(input.forward)||0,-1,1);
    const jump = input.jump === true;
    const powered = state.stamina > 0;
    const boost = input.boost === true && powered && params.style !== 'bird';
    const yawDelta = (((Number(input.yaw) - state.yaw + 180) % 360 + 360) % 360) - 180;
    next.yaw = state.yaw + clamp(yawDelta,-params.turnPerTick,params.turnPerTick);
    next.pitch = toward(state.pitch,clamp(Number(input.pitch)||0,-80,80),params.turnPerTick);
    if (params.style === 'hover') {
        const raw=[clamp(Number(input.strafe)||0,-1,1),powered ? (jump ? 1 : 0) : -1,forward];
        const size=Math.hypot(...raw),unit=raw.map(v=>size ? v/size : 0);
        const vel=[state.lateral||0,state.vertical,state.forward],length=Math.hypot(...vel);
        const dot=length ? unit.reduce((sum,v,i)=>sum+v*vel[i]/length,0) : 0;
        const friction=size ? .5*(1-dot) : 1;
        const thrust=params.acceleration*(.5+.5*clamp(unit[2],0,1));
        const moved=vel.map((v,i)=>v*(1-.02*friction)+unit[i]*thrust);
        const scale=Math.min(1,params.speed/Math.max(1e-9,Math.hypot(...moved)));
        [next.lateral,next.vertical,next.forward]=moved.map(v=>v*scale);
        next.pitch=0;
        next.stamina=clamp(state.stamina+(input.tooHigh ? -1/(Math.max(.05,params.staminaSeconds)*20) : 1/40),0,1);
        const yaw=next.yaw*Math.PI/180;
        return {state:next,velocity:{x:-Math.sin(yaw)*next.forward+Math.cos(yaw)*next.lateral,
            y:next.vertical,z:Math.cos(yaw)*next.forward+Math.sin(yaw)*next.lateral}};
    }
    const pitch = next.pitch*Math.PI/180;
    if (params.style === 'bird') {
        if (forward && powered && (forward < 0 || next.forward < params.speed))
            next.forward = forward > 0 ? Math.min(params.speed,next.forward+params.acceleration) : next.forward-params.acceleration;
        const glide = Math.sin(pitch)*.25;
        if (glide > 0) next.forward += .0332*glide;
        else if (forward <= 0) next.forward *= 1-glide*-.0166*2;
        const limit = glide > 0 || next.forward > params.speed ? params.speed*params.multiplier : params.speed;
        next.forward = clamp(next.forward,-params.speed/3,limit);
        next.forward = toward(next.forward,0,.0015);
        const vertical = powered && Math.hypot(state.forward,state.vertical)<.3 && jump ? 1 : 0;
        next.vertical = vertical ? clamp(next.vertical+params.acceleration,-params.vertical,params.vertical)
            : next.vertical*(1-params.vertical/20);
    } else if (params.style === 'jet') {
        const min = params.speed*.5;
        if (boost) next.forward = Math.min(next.forward+params.acceleration*params.multiplier,params.speed*params.multiplier);
        else if (next.forward < min || (powered && forward>0 && next.forward<params.speed))
            next.forward += params.acceleration*Math.max(1-(next.forward-min)/(params.speed-min),0);
        else if (forward<0 || !powered) next.forward = Math.max(min,next.forward-.005);
        next.forward = clamp(next.forward,0,params.speed*params.multiplier);
        next.vertical = 0;
    } else {
        const limit = params.speed*(boost ? 5 : 1);
        if (powered && forward) next.forward += params.acceleration*Math.sign(forward)*(boost ? 5/1.5 : 1);
        else next.forward = toward(next.forward,0,params.acceleration);
        next.forward = clamp(next.forward,-limit,limit);
        if (boost && !jump && next.vertical>-.125) next.vertical -= params.acceleration*.7;
        else if (boost && next.vertical<params.vertical) next.vertical += jump ? params.acceleration : 0;
        else if (jump && powered) next.vertical = Math.min(params.vertical,next.vertical+params.acceleration*params.vertical*(next.vertical<0 ? 3 : 1));
        else next.vertical = Math.max(-2,next.vertical-.0588);
        next.pitch = 0;
    }
    next.noStaminaTicks = powered ? 0 : state.noStaminaTicks+1;
    const drain = params.style === 'bird' ? (forward || jump ? 1 : .5) : params.style === 'rocket' && !boost ? 0 : 1;
    next.stamina = clamp(state.stamina-drain/(Math.max(1,params.staminaSeconds)*20),0,1);
    const yaw = next.yaw*Math.PI/180;
    const horizontal = next.forward*Math.cos(next.pitch*Math.PI/180);
    const fall = !powered ? -.3*Math.min(1,next.noStaminaTicks/140) : 0;
    return {state:next, velocity:{x:-Math.sin(yaw)*horizontal,
        y:-Math.sin(next.pitch*Math.PI/180)*next.forward+next.vertical+fall,
        z:Math.cos(yaw)*horizontal}};
}

export function jumpTransition(state, tick, pressed, inWater = false) {
    if (!pressed || inWater) return {...state, takeoff:false};
    const double = Number.isFinite(state.lastJump) && tick-state.lastJump>0 && tick-state.lastJump<=7;
    return {lastJump:double ? undefined : tick,takeoff:double};
}

