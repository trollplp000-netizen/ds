

import { MOVE_DATA } from "./move_registry.js";

const MAX_FRIENDSHIP = 255;

export const STATUS_GROUPS = Object.freeze({
    poison: ["psn", "poison", "poisoned", "tox", "toxic", "badlypoisoned"],
    sleep: ["slp", "sleep", "asleep"],
    burn: ["brn", "burn", "burned"],
    frozen: ["frz", "freeze", "frozen"],
    paralysis: ["par", "paralysis", "paralyzed"]
});

export const NATURE_LOWERED_STATS = Object.freeze({
    lonely: "defence", brave: "speed", adamant: "specialAttack", naughty: "specialDefence",
    bold: "attack", relaxed: "speed", impish: "specialAttack", lax: "specialDefence",
    timid: "attack", hasty: "defence", jolly: "specialAttack", naive: "specialDefence",
    modest: "attack", mild: "defence", quiet: "speed", rash: "specialDefence",
    calm: "attack", gentle: "defence", sassy: "speed", careful: "specialAttack"
});

export const NATURE_BOOSTED_STATS = Object.freeze({
    lonely: "attack", brave: "attack", adamant: "attack", naughty: "attack",
    bold: "defence", relaxed: "defence", impish: "defence", lax: "defence",
    timid: "speed", hasty: "speed", jolly: "speed", naive: "speed",
    modest: "specialAttack", mild: "specialAttack", quiet: "specialAttack", rash: "specialAttack",
    calm: "specialDefence", gentle: "specialDefence", sassy: "specialDefence", careful: "specialDefence"
});

export const ALL_NATURES = Object.freeze([
    "adamant", "bashful", "bold", "brave", "calm", "careful", "docile", "gentle",
    "hardy", "hasty", "impish", "jolly", "lax", "lonely", "mild", "modest",
    "naive", "naughty", "quiet", "quirky", "rash", "relaxed", "sassy", "serious", "timid"
]);

export function cleanStatus(value) {
    const status = String(value || "NONE").toLowerCase().replace(/[^a-z]/g, "");
    return status === "none" ? "" : status;
}

export function pokemonName(pokemon) {
    return String(pokemon?.nickname || pokemon?.species || "Pokemon")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, c => c.toUpperCase());
}

export function livingPokemon(pokemon) {
    return !!pokemon && Number(pokemon.currentHp) > 0;
}

export function damagedLivingPokemon(pokemon) {
    return livingPokemon(pokemon) && Number(pokemon.currentHp) < Number(pokemon.maxHp);
}

export function faintedPokemon(pokemon) {
    return !!pokemon && Number(pokemon.currentHp) <= 0;
}

export function hasPersistentStatus(pokemon, accepted = undefined) {
    const status = cleanStatus(pokemon?.statusCondition);
    if (!status) return false;
    if (!accepted) return true;
    return accepted.some(group => group.includes(status));
}

export function missingPpMoves(pokemon) {
    return (pokemon?.moves || []).filter(move => Number(move?.pp) < Number(move?.maxPp));
}

export function healPokemonHp(pokemon, amount) {
    const before = Math.max(0, Number(pokemon.currentHp) || 0);
    const maximum = Math.max(1, Number(pokemon.maxHp) || 1);
    pokemon.currentHp = Math.min(maximum, before + Math.max(0, Math.floor(Number(amount) || 0)));
    return Math.max(0, pokemon.currentHp - before);
}

export function raiseFriendship(pokemon, amount = 0) {
    const before = Math.max(0, Math.floor(Number(pokemon.friendship) || 0));
    const multiplier = amount > 0 && String(pokemon?.caughtBall || "").replace(/^.*:/, "") === "luxury_ball" ? 2 : 1;
    pokemon.friendship = Math.max(0, Math.min(MAX_FRIENDSHIP, before + amount * multiplier));
    return pokemon.friendship > before;
}

export function calculateFriendshipRaiseAmount(pokemon) {
    const current = Math.max(0, Math.floor(Number(pokemon?.friendship) || 0));
    if (current < 100) return 10;
    if (current < 200) return 5;
    return 1;
}

export function getEffectiveNature(pokemon) {
    return String(pokemon?.mintedNature || pokemon?.nature || "hardy").toLowerCase();
}

export function canUseHpBerry(pokemon) {
    return damagedLivingPokemon(pokemon);
}

export function applyOranBerry(pokemon) {
    if (!canUseHpBerry(pokemon)) return undefined;
    const healed = healPokemonHp(pokemon, 10);
    return {
        success: true,
        healed,
        messages: [`${pokemonName(pokemon)} regained ${healed} HP!`]
    };
}

export function applySitrusBerry(pokemon) {
    if (!canUseHpBerry(pokemon)) return undefined;
    const maxHp = Math.max(1, Number(pokemon.maxHp) || 1);
    const healAmount = Math.floor(maxHp / 4);
    const healed = healPokemonHp(pokemon, Math.max(1, healAmount));
    return {
        success: true,
        healed,
        messages: [`${pokemonName(pokemon)} regained ${healed} HP!`]
    };
}

export function applyFlavorPortionBerry(pokemon, dislikedStat) {
    if (!canUseHpBerry(pokemon)) return undefined;
    const maxHp = Math.max(1, Number(pokemon.maxHp) || 1);
    const healAmount = Math.floor(maxHp * 0.33);
    const healed = healPokemonHp(pokemon, Math.max(1, healAmount));
    const effectiveNature = getEffectiveNature(pokemon);
    const disliked = NATURE_LOWERED_STATS[effectiveNature] === dislikedStat;
    
    if (disliked) {
        const state = pokemon.battleState && typeof pokemon.battleState === "object"
            ? pokemon.battleState
            : (pokemon.battleState = {});
        state.confusionTurns = 2 + Math.floor(Math.random() * 4);
    }

    return {
        success: true,
        healed,
        confused: disliked,
        messages: [
            `${pokemonName(pokemon)} regained ${healed} HP!`,
            ...(disliked ? [`${pokemonName(pokemon)} became confused by the bitter taste!`] : [])
        ]
    };
}

export function canCureStatus(pokemon, acceptedGroups, options = {}) {
    if (!livingPokemon(pokemon)) return false;
    if (acceptedGroups === "all" && hasPersistentStatus(pokemon)) return true;
    if (Array.isArray(acceptedGroups)) {
        const groups = acceptedGroups.map(g => STATUS_GROUPS[g]).filter(Boolean);
        if (hasPersistentStatus(pokemon, groups)) return true;
    }
    if (options.confusion && Number(pokemon?.battleState?.confusionTurns) > 0) return true;
    if (options.infatuation && (pokemon?.battleState?.infatuated || Number(pokemon?.battleState?.infatuationTurns) > 0)) return true;
    return false;
}

export function applyStatusCureBerry(pokemon, acceptedGroups, options = {}) {
    if (!canCureStatus(pokemon, acceptedGroups, options)) return undefined;
    let cured = false;
    if (acceptedGroups === "all" || Array.isArray(acceptedGroups)) {
        if (hasPersistentStatus(pokemon, acceptedGroups === "all" ? undefined : acceptedGroups.map(g => STATUS_GROUPS[g]))) {
            pokemon.statusCondition = "NONE";
            cured = true;
        }
    }
    if (options.confusion && pokemon.battleState?.confusionTurns) {
        delete pokemon.battleState.confusionTurns;
        cured = true;
    }
    if (options.infatuation && pokemon.battleState) {
        delete pokemon.battleState.infatuated;
        delete pokemon.battleState.infatuationTurns;
        cured = true;
    }
    return {
        success: cured,
        messages: [`${pokemonName(pokemon)} was cured of its status!`]
    };
}

export function canRestorePp(pokemon, moveIndex = undefined) {
    if (!livingPokemon(pokemon)) return false;
    if (Number.isFinite(moveIndex) && moveIndex >= 0) {
        const move = pokemon?.moves?.[moveIndex];
        return !!move && Number(move.pp) < Number(move.maxPp);
    }
    return missingPpMoves(pokemon).length > 0;
}

export function applyPpRestoreBerry(pokemon, moveIndex = undefined, amount = 10) {
    if (!canRestorePp(pokemon, moveIndex)) return undefined;
    let restoredMoveName = "its moves";
    if (Number.isFinite(moveIndex) && moveIndex >= 0 && pokemon.moves?.[moveIndex]) {
        const move = pokemon.moves[moveIndex];
        move.pp = Math.min(Number(move.maxPp), Number(move.pp) + amount);
        restoredMoveName = String(move.name || move.id || "The move");
    } else {
        const targets = missingPpMoves(pokemon);
        if (targets.length === 0) return undefined;
        const move = targets[0];
        move.pp = Math.min(Number(move.maxPp), Number(move.pp) + amount);
        restoredMoveName = String(move.name || move.id || "The move");
    }
    return {
        success: true,
        messages: [`${pokemonName(pokemon)}'s ${restoredMoveName} had its PP restored!`]
    };
}

export const EV_STAT_MAP = Object.freeze({
    pomeg_berry: "hp",
    kelpsy_berry: "attack",
    qualot_berry: "defence",
    hondew_berry: "specialAttack",
    grepa_berry: "specialDefence",
    tamato_berry: "speed"
});

export const EV_STAT_LABELS = Object.freeze({
    hp: "HP",
    attack: "Attack",
    defence: "Defense",
    specialAttack: "Sp. Atk",
    specialDefence: "Sp. Def",
    speed: "Speed"
});

export function canUseFriendshipBerry(pokemon, berryId) {
    if (!livingPokemon(pokemon)) return false;
    const stat = EV_STAT_MAP[berryId];
    if (!stat) return false;
    const currentEv = Number(pokemon?.evs?.[stat]) || 0;
    const currentFriendship = Number(pokemon?.friendship) || 0;
    return currentEv > 0 || currentFriendship < MAX_FRIENDSHIP;
}

export function applyFriendshipBerry(pokemon, berryId) {
    if (!canUseFriendshipBerry(pokemon, berryId)) return undefined;
    const stat = EV_STAT_MAP[berryId];
    const statLabel = EV_STAT_LABELS[stat] || "Stat";
    
    if (!pokemon.evs) pokemon.evs = {};
    const beforeEv = Number(pokemon.evs[stat]) || 0;
    const evLowerAmount = Math.min(beforeEv, 10);
    pokemon.evs[stat] = Math.max(0, beforeEv - evLowerAmount);

    const friendshipAmount = calculateFriendshipRaiseAmount(pokemon);
    const raised = raiseFriendship(pokemon, friendshipAmount);

    const messages = [];
    if (evLowerAmount > 0) {
        messages.push(`${pokemonName(pokemon)}'s ${statLabel} base stat fell!`);
    }
    if (raised) {
        messages.push(`${pokemonName(pokemon)} is growing friendlier!`);
    }
    if (messages.length === 0) {
        messages.push(`${pokemonName(pokemon)} happily ate the berry.`);
    }

    return {
        success: true,
        evLowered: evLowerAmount > 0,
        friendshipRaised: raised,
        messages
    };
}

export function canUseNatureMint(pokemon, targetNature) {
    if (!livingPokemon(pokemon) || !targetNature) return false;
    const effective = getEffectiveNature(pokemon);
    return effective !== String(targetNature).toLowerCase();
}

export function applyNatureMint(pokemon, targetNature) {
    const cleanTarget = String(targetNature || "").toLowerCase().replace(/_mint$/, "");
    if (!canUseNatureMint(pokemon, cleanTarget)) {
        return {
            success: false,
            sameNature: true,
            messages: [`${pokemonName(pokemon)} already has the stat growth of ${cleanTarget.toUpperCase()} nature.`]
        };
    }

    pokemon.mintedNature = cleanTarget;
    return {
        success: true,
        targetNature: cleanTarget,
        messages: [`${pokemonName(pokemon)}'s nature stat growth changed to ${cleanTarget.toUpperCase()}!`]
    };
}
