import { offerPokemonTrade } from "./pokemon_trade.js";
import { ItemStack, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    itemEvolutionOptions,
    queueHeldItemEvolutions,
    queueItemEvolution,
    setEvolutionContextProvider
} from "./evolution.js";
import { speciesData } from "./battle_math.js";
import { openPartyPokemonSummary, recallPartyPokemon, recallPartyPokemonAnimated, replacePartyPokemonSummon } from "./pokemon_compass.js";
import { addPokemonToPC, loadPartyFromPlayer, loadPokemonFromEntity, savePartyToPlayer, savePokemonToEntity } from "./storage.js";
import { isHoldableItem, normalizeHeldItemId } from "./held_items.js";
import { consumePokemonInteractionClaim } from "./pokemon_interaction_claims.js";
import {
    isOutsideMegaEvolved,
    megaFormForPokemon,
    outsideMegaEvolutionFailure,
    toggleOutsideMegaEvolution
} from "./mega_evolution.js";
import { playOriginalPokemonBattleAnimation } from "./battle_visual_effects.js";
import { pokemonAddonActions, showPokemonAddonActions } from "./addon_api.js";
import { canShoulderMount, toggleShoulderMount } from "./shoulder_mount.js";
import {
    fuseKyurem,
    reconcileSpecialForm,
    specialFormName,
    specialFormUseAction,
    toggleInteractionForm,
    unfuseKyurem
} from "./special_forms.js";
import { teachMoveWithHeldDisc } from "./tm_machine_system.js";

const INTERACT_TITLE = "cobbledrock.interact";
const EMPTY_ACTION = "|EMPTY|";
const openWheels = new Set();
const outsideMegaSequences = new Set();
const MEGA_MODEL_HIDE_TICKS = 20;
const MEGA_FORM_APPLY_TICKS = 126;
const MEGA_CRY_TICKS = 158;
const MEGA_SEQUENCE_END_TICKS = 170;

const VILLAGE_STRUCTURE_TAG = "#minecraft:village";
const VILLAGE_SCAN_RADIUS = 48;
const VILLAGE_MARKER_ENTITIES = ["minecraft:villager", "minecraft:iron_golem"];

function villageStructureTags(player) {
    if (!player?.isValid) return [];
    for (const typeId of VILLAGE_MARKER_ENTITIES) {
        try {
            const found = player.dimension.getEntities({
                type: typeId,
                location: player.location,
                maxDistance: VILLAGE_SCAN_RADIUS,
                closest: 1
            });
            if (found.length) return [VILLAGE_STRUCTURE_TAG];
        } catch (error) {}
    }
    return [];
}

setEvolutionContextProvider(pokemon => {
    const player = world.getAllPlayers().find(candidate => candidate.id === String(pokemon?.originalTrainer?.uuid || ""));
    let isRaining = false;
    try {
        const weather = String(player?.dimension?.getWeather?.() || "").toLowerCase();
        isRaining = weather.includes("rain") || weather.includes("thunder");
    } catch (error) {}
    return {
        player,
        time: world.getTimeOfDay(),
        moonPhase: world.getMoonPhase?.(),
        structureTags: () => villageStructureTags(player),
        party: player ? loadPartyFromPlayer(player) : [],
        isRaining
    };
});

const WHEEL_ICONS = Object.freeze({
    ride: "textures/gui/interact/interact_wheel_icon_ride",
    use: "textures/gui/interact/interact_wheel_icon_exclamation",
    held: "textures/gui/interact/interact_wheel_icon_held_item",
    summary: "textures/gui/interact/interact_wheel_icon_exclamation",
    recall: "textures/items/poke_ball",
    mega: "textures/items/mega/mega_stone",
    addons: "textures/gui/interact/interact_wheel_icon_exclamation",
    trade: "textures/gui/interact/interact_wheel_icon_trade",
    close: "textures/ui/cancel"
});

function cleanId(value) {
    return String(value || "").replace(/^cobblemon:/, "").replace(/^lota:/, "").toLowerCase();
}

function titleCase(value) {
    return cleanId(value).replace(/[_-]+/g, " ").replace(/\b\w/g, letter => letter.toUpperCase());
}

function itemDisplayName(typeId) {
    return String(typeId || "").replace(/^[a-z_]+:/, "").replace(/[_-]+/g, " ").replace(/\b\w/g, letter => letter.toUpperCase());
}

function pokemonName(pokemon) {
    return pokemon?.nickname || speciesData(pokemon)?.name || titleCase(pokemon?.species || "Pokemon");
}

function bedrockItemId(value) {
    const raw = String(value || "");
    if (!raw) return "";
    if (raw.startsWith("minecraft:") || raw.startsWith("lota:")) return raw;
    return `lota:${cleanId(raw)}`;
}

function playerInventory(player) {
    return player.getComponent("minecraft:inventory")?.container;
}

function handState(player) {
    const container = playerInventory(player);
    const slot = Math.max(0, Math.floor(Number(player.selectedSlotIndex) || 0));
    return { container, slot, stack: container?.getItem(slot) };
}

function isCreativePlayer(player) {
    try { return String(player.getGameMode()).toLowerCase() === "creative"; } catch (error) { return false; }
}

function consumeOneFromHand(player, expectedTypeId) {
    const { container, slot, stack } = handState(player);
    if (!container || !stack || stack.typeId !== expectedTypeId) return false;
    if (isCreativePlayer(player)) return true;
    if (stack.amount <= 1) {
        container.setItem(slot, undefined);
    } else {
        stack.amount -= 1;
        container.setItem(slot, stack);
    }
    return true;
}

function itemStackData(stack) {
    const data = {};
    try { if (stack.nameTag) data.nameTag = stack.nameTag; } catch (error) {}
    try {
        const lore = stack.getLore();
        if (lore.length) data.lore = lore;
    } catch (error) {}
    try {
        const damage = Number(stack.getComponent("minecraft:durability")?.damage);
        if (Number.isFinite(damage) && damage > 0) data.damage = damage;
    } catch (error) {}
    try {
        const dynamicProperties = {};
        for (const id of stack.getDynamicPropertyIds()) dynamicProperties[id] = stack.getDynamicProperty(id);
        if (Object.keys(dynamicProperties).length) data.dynamicProperties = dynamicProperties;
    } catch (error) {}
    return data;
}

function restoredItemStack(itemTypeId, storedData = undefined) {
    const item = new ItemStack(bedrockItemId(itemTypeId), 1);
    if (!storedData) return item;
    try { if (storedData.nameTag) item.nameTag = String(storedData.nameTag); } catch (error) {}
    try { if (Array.isArray(storedData.lore)) item.setLore(storedData.lore.map(String)); } catch (error) {}
    try {
        const durability = item.getComponent("minecraft:durability");
        if (durability && Number.isFinite(Number(storedData.damage))) durability.damage = Number(storedData.damage);
    } catch (error) {}
    try {
        for (const [id, value] of Object.entries(storedData.dynamicProperties || {})) item.setDynamicProperty(id, value);
    } catch (error) {}
    return item;
}

function announceHeldItemChange(player, source, pokemon, previousItem, newItem) {
    const had = !!previousItem;
    const has = !!newItem;
    if (!had && !has) return;
    const key = !has ? "cobblemon.held_item.take"
        : !had ? "cobblemon.held_item.give"
            : "cobblemon.held_item.replace";
    const args = !has ? [titleCase(previousItem), pokemonName(pokemon)]
        : !had ? [pokemonName(pokemon), titleCase(newItem)]
            : [titleCase(previousItem), pokemonName(pokemon), titleCase(newItem)];
    player.sendMessage({ translate: key, with: args });
    try {
        const dimension = source?.dimension || player.dimension;
        dimension.playSound("random.pop", source?.location || player.location, { volume: 0.6, pitch: 1.4 });
    } catch (error) {}
}

function returnItemToPlayer(player, itemTypeId, storedData = undefined) {
    const typeId = bedrockItemId(itemTypeId);
    if (!typeId) return true;
    try {
        const item = restoredItemStack(typeId, storedData);
        const leftover = playerInventory(player)?.addItem(item);
        if (leftover) player.dimension.spawnItem(leftover, player.location);
        return true;
    } catch (error) {
        player.sendMessage(`§cCould not return ${titleCase(itemTypeId)} because that item is unavailable in this pack.`);
        return false;
    }
}

function partyPokemonForEntity(player, entity) {
    const entityPokemon = loadPokemonFromEntity(entity);
    if (!entityPokemon?.uuid) return null;
    const party = loadPartyFromPlayer(player);
    const slot = party.findIndex(pokemon => pokemon?.uuid === entityPokemon.uuid);
    if (slot < 0) return null;
    return { party, slot, pokemon: party[slot] };
}

function interactionOwner(entity) {
    return String(entity.getDynamicProperty("lota:party_owner_id") || "");
}

function isInBattle(entity) {
    try {
        return entity.hasTag("lota:in_battle") || entity.getProperty("lota:in_battle") === true;
    } catch (error) {
        return false;
    }
}

function canRide(player, entity) {
    if (!entity.getComponent("minecraft:rideable")) return false;
    return !player.getComponent("minecraft:riding")?.entityRidingOn;
}

function validEntity(entity) {
    try { return !!entity && entity.isValid; } catch (error) { return false; }
}

function hasRiders(entity) {
    try { return (entity.getComponent("minecraft:rideable")?.getRiders?.() || []).length > 0; }
    catch (error) { return false; }
}

function megaEffectDimensions(entity) {
    let width = 0.8;
    let height = 1;
    try {
        const bounds = entity.getAABB?.();
        const extent = bounds?.extent;
        if (extent) {
            width = Math.max(Number(extent.x) || 0, Number(extent.z) || 0) * 2 || width;
            height = (Number(extent.y) || 0) * 2 || height;
        }
    } catch (error) {}
    try {
        const collision = entity.getComponent("minecraft:collision_box");
        width = Number(collision?.width) || width;
        height = Number(collision?.height) || height;
    } catch (error) {}
    const scale = Math.max(1.35, Math.min(3.4, Math.max(width, height * 0.6)));
    return {
        effect: scale < 1.65
            ? "cobblemon:mega_evolution_small"
            : (scale > 2.2 ? "cobblemon:mega_evolution_large" : "cobblemon:mega_evolution"),
        anchorY: Math.max(0.45, Math.min(1.35, height * 0.32))
    };
}

function playMegaEvolutionEffect(entity) {
    if (!validEntity(entity)) return;
    const dimensions = megaEffectDimensions(entity);
    const location = {
        x: entity.location.x,
        y: entity.location.y + dimensions.anchorY,
        z: entity.location.z
    };
    try { entity.dimension.spawnParticle(dimensions.effect, location); } catch (error) {}
    try { entity.dimension.playSound("lota.mega_evolution", location, { volume: 0.3, pitch: 0.55 }); } catch (error) {}
}

function completeKyuremFusion(player, entity, state, partnerUuid) {
    const partnerIndex = state.party.findIndex(candidate => candidate?.uuid === partnerUuid);
    if (partnerIndex < 0 || partnerIndex === state.slot) {
        player.sendMessage("§cThe selected fusion partner is no longer in your party.");
        return;
    }
    runSpecialFormChangeSequence(player, entity, state.pokemon.uuid, ({ party, slot, pokemon }) => {
        const freshPartnerIndex = party.findIndex(candidate => candidate?.uuid === partnerUuid);
        if (freshPartnerIndex < 0 || freshPartnerIndex === slot) {
            return { error: "The selected fusion partner is no longer in your party." };
        }
        const partner = party[freshPartnerIndex];
        const result = fuseKyurem(pokemon, partner);
        if (!result) return { error: "Kyurem cannot fuse with that Pokemon." };
        party.splice(freshPartnerIndex, 1);
        return {
            message: `Kyurem fused with ${pokemonName(partner)} and became ${specialFormName(pokemon)} Kyurem!`
        };
    });
}

function useDnaSplicer(player, entity, state, action) {
    if (action.mode === "unfuse") {
        const storedPartner = state.pokemon?.fusionState?.partner;
        if (!storedPartner) {
            player.sendMessage("§cKyurem's fusion partner data is missing.");
            return;
        }
        runSpecialFormChangeSequence(player, entity, state.pokemon.uuid, ({ party, pokemon }) => {
            const currentPartner = pokemon?.fusionState?.partner;
            if (!currentPartner) return { error: "Kyurem's fusion partner data is missing." };
            let storageMessage = "returned to your party";
            if (party.length >= 6) {
                const stored = addPokemonToPC(player, JSON.parse(JSON.stringify(currentPartner)));
                if (!stored.success) {
                    return { error: "There is no safe storage space for Kyurem's fusion partner." };
                }
                storageMessage = `was sent to PC Box ${stored.box + 1}`;
            }
            const result = unfuseKyurem(pokemon);
            if (!result) return { error: "Kyurem could not separate from its fusion partner." };
            if (party.length < 6) party.push(result.partner);
            return {
                message: `Kyurem separated from ${pokemonName(result.partner)}. ${pokemonName(result.partner)} ${storageMessage}.`
            };
        });
        return;
    }

    const partners = state.party.filter(candidate => ["reshiram", "zekrom"].includes(cleanId(candidate?.species)));
    if (!partners.length) {
        player.sendMessage("§cKeep Reshiram or Zekrom in the party with Kyurem to use the DNA Splicers.");
        return;
    }
    if (partners.length === 1) return completeKyuremFusion(player, entity, state, partners[0].uuid);
    new ActionFormData()
        .title("DNA Splicers")
        .body("Choose the Pokemon that will fuse with Kyurem.")
        .button(pokemonName(partners[0]))
        .button(pokemonName(partners[1]))
        .show(player)
        .then(response => {
            if (response.canceled || !entity?.isValid) return;
            const fresh = partyPokemonForEntity(player, entity);
            if (!fresh) return;
            const selected = partners[Math.floor(Number(response.selection))];
            if (selected) completeKyuremFusion(player, entity, fresh, selected.uuid);
        })
        .catch(error => console.warn(`DNA Splicers menu failed: ${error}`));
}

function completeSpecialFormUse(player, entity, state, itemTypeId) {
    const action = specialFormUseAction(state.pokemon, itemTypeId);
    if (!action) return;
    const currentHand = handState(player).stack;
    if (!currentHand || currentHand.typeId !== itemTypeId) {
        player.sendMessage("§cKeep the form-change item in your hand while choosing the action.");
        return;
    }
    if (action.item === "dna_splicer") return useDnaSplicer(player, entity, state, action);
    runSpecialFormChangeSequence(player, entity, state.pokemon.uuid, ({ pokemon }) => {
        const held = handState(player).stack;
        if (!held || held.typeId !== itemTypeId) {
            return { error: "Keep the form-change item in your hand until the transformation finishes." };
        }
        if (!specialFormUseAction(pokemon, itemTypeId)) {
            return { error: "That form change is no longer available." };
        }
        const result = toggleInteractionForm(pokemon, itemTypeId);
        if (!result) return { error: "That form change could not be completed." };
        const form = result.mode === "transform" ? `${specialFormName(pokemon)} form` : "ordinary form";
        return { message: `${pokemonName(pokemon)} changed to its ${form}.` };
    });
}

function setMegaModelVisible(entity, visible, durationTicks = MEGA_SEQUENCE_END_TICKS) {
    if (!validEntity(entity)) return;
    try {
        if (visible) entity.removeEffect("invisibility");
        else entity.addEffect("invisibility", Math.max(1, Math.floor(durationTicks)), {
            amplifier: 0,
            showParticles: false
        });
    } catch (error) {}
}

function outsideMegaPose(entity) {
    if (!validEntity(entity)) return undefined;
    let rotation;
    try { rotation = entity.getRotation(); } catch (error) {}
    return {
        dimension: entity.dimension,
        location: { ...entity.location },
        rotation
    };
}

function lockOutsideMegaEntity(entity, pose, savedMovement) {
    if (!validEntity(entity) || !pose?.location || !pose?.dimension) return false;
    try {
        const movement = entity.getComponent("minecraft:movement");
        if (movement && !savedMovement.has(entity.id)) {
            const value = Number(movement.currentValue);
            savedMovement.set(entity.id, { entity, value: Number.isFinite(value) ? value : undefined });
        }
        movement?.setCurrentValue(0);
    } catch (error) {}
    try { entity.clearVelocity(); } catch (error) {}
    try {
        const options = { dimension: pose.dimension, keepVelocity: false };
        if (pose.rotation) options.rotation = pose.rotation;
        entity.teleport(pose.location, options);
        return true;
    } catch (error) {
        return false;
    }
}

function restoreOutsideMegaMovement(savedMovement) {
    for (const saved of savedMovement.values()) {
        if (!validEntity(saved.entity) || saved.value === undefined) continue;
        try { saved.entity.getComponent("minecraft:movement")?.setCurrentValue(saved.value); } catch (error) {}
    }
    savedMovement.clear();
}

function beginOutsideFormSequence(player, originalEntity, pokemonUuid) {
    const sequenceKey = `${player.id}:${pokemonUuid}`;
    if (outsideMegaSequences.has(sequenceKey)) {
        player.sendMessage("§7This Pokemon is already changing form.");
        return undefined;
    }
    const entityPose = outsideMegaPose(originalEntity);
    if (!entityPose) return undefined;

    const sequence = {
        key: sequenceKey,
        player,
        originalEntity,
        currentEntity: originalEntity,
        entityPose,
        savedMovement: new Map(),
        lockRunId: undefined
    };
    sequence.isCurrent = () => outsideMegaSequences.has(sequence.key);
    sequence.lockActors = () => {
        const currentEntity = validEntity(sequence.currentEntity) ? sequence.currentEntity : sequence.originalEntity;
        lockOutsideMegaEntity(currentEntity, sequence.entityPose, sequence.savedMovement);
    };
    sequence.release = () => {
        if (sequence.lockRunId !== undefined) {
            system.clearRun(sequence.lockRunId);
            sequence.lockRunId = undefined;
        }
        restoreOutsideMegaMovement(sequence.savedMovement);
    };
    sequence.finish = () => {
        sequence.release();
        outsideMegaSequences.delete(sequence.key);
    };

    outsideMegaSequences.add(sequence.key);
    sequence.lockActors();
    sequence.lockRunId = system.runInterval(() => {
        if (!sequence.isCurrent()) {
            sequence.release();
            return;
        }
        sequence.lockActors();
    }, 1);
    return sequence;
}

function stopOutsideFormSequence(sequence, entity, errorMessage = undefined) {
    setMegaModelVisible(entity, true);
    sequence.finish();
    if (errorMessage && sequence.player?.isValid) sequence.player.sendMessage(`§c${errorMessage}`);
}

function runSpecialFormChangeSequence(player, originalEntity, pokemonUuid, applyChange) {
    if (hasRiders(originalEntity)) {
        player.sendMessage("§cDismount before changing this Pokemon's form.");
        return;
    }
    const sequence = beginOutsideFormSequence(player, originalEntity, pokemonUuid);
    if (!sequence) return;
    let changed = false;

    playMegaEvolutionEffect(originalEntity);
    system.runTimeout(() => {
        if (!sequence.isCurrent()) return;
        setMegaModelVisible(originalEntity, false, MEGA_SEQUENCE_END_TICKS - MEGA_MODEL_HIDE_TICKS);
    }, MEGA_MODEL_HIDE_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent() || !player?.isValid) return;
        const party = loadPartyFromPlayer(player);
        const slot = party.findIndex(pokemon => pokemon?.uuid === pokemonUuid);
        const pokemon = party[slot];
        const currentEntity = validEntity(originalEntity) ? originalEntity : undefined;
        if (!pokemon || !currentEntity) {
            stopOutsideFormSequence(sequence, originalEntity, "The form change stopped because the summoned Pokemon is unavailable.");
            return;
        }

        let result;
        try { result = applyChange({ party, slot, pokemon }); }
        catch (error) {
            console.warn(`Special form change failed: ${error}`);
            result = { error: "That form change could not be completed." };
        }
        if (!result || result.error) {
            stopOutsideFormSequence(sequence, currentEntity, result?.error || "That form change could not be completed.");
            return;
        }

        savePartyToPlayer(player, party);
        savePokemonToEntity(currentEntity, pokemon);
        setMegaModelVisible(currentEntity, true);
        changed = true;
        player.sendMessage(typeof result.message === "string" ? `§a${result.message}` : result.message);
    }, MEGA_FORM_APPLY_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent() || !changed || !validEntity(originalEntity)) return;
        playOriginalPokemonBattleAnimation(originalEntity, "cry");
    }, MEGA_CRY_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent()) return;
        setMegaModelVisible(originalEntity, true);
        sequence.finish();
    }, MEGA_SEQUENCE_END_TICKS);
}

function runOutsideMegaEvolutionSequence(player, originalEntity, pokemonUuid) {
    const state = partyPokemonForEntity(player, originalEntity);
    if (!state || state.pokemon.uuid !== pokemonUuid) return;
    const failure = outsideMegaEvolutionFailure(player, state.pokemon, state.party);
    if (failure) {
        player.sendMessage(`§c${failure}`);
        return;
    }
    if (hasRiders(originalEntity)) {
        player.sendMessage("§cDismount before changing this Pokemon's form.");
        return;
    }
    const sequence = beginOutsideFormSequence(player, originalEntity, pokemonUuid);
    if (!sequence) return;
    let replacement;
    let changed = false;
    playMegaEvolutionEffect(originalEntity);

    system.runTimeout(() => {
        if (!sequence.isCurrent()) return;
        setMegaModelVisible(originalEntity, false, MEGA_SEQUENCE_END_TICKS - MEGA_MODEL_HIDE_TICKS);
    }, MEGA_MODEL_HIDE_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent() || !player?.isValid) return;
        const party = loadPartyFromPlayer(player);
        const slot = party.findIndex(pokemon => pokemon?.uuid === pokemonUuid);
        const pokemon = party[slot];
        const currentEntity = validEntity(originalEntity) ? originalEntity : undefined;
        if (!pokemon || !currentEntity) {
            stopOutsideFormSequence(sequence, originalEntity, "Mega Evolution stopped because the summoned Pokemon is unavailable.");
            return;
        }
        const abilityBefore = pokemon.ability;
        const megaStateBefore = pokemon.megaState ? { ...pokemon.megaState } : undefined;
        const nameBefore = pokemonName(pokemon);
        const result = toggleOutsideMegaEvolution(player, pokemon, party);
        if (!result.success) {
            stopOutsideFormSequence(sequence, originalEntity, result.message);
            return;
        }

        lockOutsideMegaEntity(currentEntity, sequence.entityPose, sequence.savedMovement);
        replacement = replacePartyPokemonSummon(player, pokemon, currentEntity);
        if (!validEntity(replacement)) {
            pokemon.ability = abilityBefore;
            if (megaStateBefore) pokemon.megaState = megaStateBefore;
            else delete pokemon.megaState;
            savePartyToPlayer(player, party);
            if (validEntity(currentEntity)) savePokemonToEntity(currentEntity, pokemon);
            stopOutsideFormSequence(sequence, currentEntity, "Mega Evolution could not replace the summoned Pokemon model.");
            return;
        }
        sequence.currentEntity = replacement;
        sequence.lockActors();

        savePartyToPlayer(player, party);
        setMegaModelVisible(replacement, true);
        changed = true;
        if (result.mode === "evolve") {
            player.sendMessage(`§a${nameBefore} Mega Evolved into ${result.form?.name || "its Mega form"}!`);
        } else {
            player.sendMessage(`§a${pokemonName(pokemon)} returned to its normal form.`);
        }
    }, MEGA_FORM_APPLY_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent() || !changed || !validEntity(replacement)) return;
        setMegaModelVisible(replacement, true);
        playOriginalPokemonBattleAnimation(replacement, "cry");
    }, MEGA_CRY_TICKS);

    system.runTimeout(() => {
        if (!sequence.isCurrent()) return;
        setMegaModelVisible(validEntity(replacement) ? replacement : originalEntity, true);
        sequence.finish();
    }, MEGA_SEQUENCE_END_TICKS);
}

function completeItemEvolution(player, entity, state, evolution, handTypeId) {
    if (isOutsideMegaEvolved(state.pokemon)) {
        player.sendMessage("§cRevert Mega Evolution before changing its held item.");
        return;
    }
    if (evolution.variant === "trade") {
        const queued = queueItemEvolution(state.pokemon, evolution.id, handTypeId, player);
        if (!queued) {
            player.sendMessage("§cThat evolution is no longer available.");
            return;
        }
        if (!consumeOneFromHand(player, handTypeId)) {
            state.pokemon.pendingEvolutions = (state.pokemon.pendingEvolutions || []).filter(entry => entry?.id !== queued.id);
            player.sendMessage("§cKeep the Link Cable in your hand while choosing the action.");
            return;
        }
        savePartyToPlayer(player, state.party);
        savePokemonToEntity(entity, state.pokemon);
        player.sendMessage(`§a${pokemonName(state.pokemon)} is ready to evolve! Open the party menu and press Evolve.`);
        return;
    }

    if (["scroll_of_darkness", "scroll_of_waters"].includes(cleanId(handTypeId))) {
        const queued = queueItemEvolution(state.pokemon, evolution.id, handTypeId, player);
        if (!queued) {
            player.sendMessage("§cThat evolution is no longer available.");
            return;
        }
        savePartyToPlayer(player, state.party);
        savePokemonToEntity(entity, state.pokemon);
        player.sendMessage(`§a${pokemonName(state.pokemon)} is ready to evolve! The scroll was not consumed.`);
        return;
    }

    const oldForm = specialFormName(state.pokemon);
    const oldHeldItem = state.pokemon.heldItem;
    if (normalizeHeldItemId(oldHeldItem) === normalizeHeldItemId(handTypeId)) {
        player.sendMessage({
            translate: "cobblemon.held_item.already_holding",
            with: [pokemonName(state.pokemon), itemDisplayName(handTypeId)]
        });
        return;
    }

    const { stack } = handState(player);
    const newHeldItemData = stack ? itemStackData(stack) : undefined;
    if (!consumeOneFromHand(player, handTypeId)) {
        player.sendMessage("§cKeep the evolution item in your hand while choosing the action.");
        return;
    }
    if (oldHeldItem && !returnItemToPlayer(player, oldHeldItem, state.pokemon.heldItemData)) {
        returnItemToPlayer(player, handTypeId, newHeldItemData);
        return;
    }

    state.pokemon.heldItem = handTypeId;
    state.pokemon.heldItemData = newHeldItemData;
    const queued = queueHeldItemEvolutions(state.pokemon, player);
    savePartyToPlayer(player, state.party);
    savePokemonToEntity(entity, state.pokemon);

    if (oldForm !== specialFormName(state.pokemon)) playMegaEvolutionEffect(entity);

    if (queued.length) {
        player.sendMessage(`§a${pokemonName(state.pokemon)} is ready to evolve! Open the party menu and press Evolve.`);
    } else {
        announceHeldItemChange(player, entity, state.pokemon, oldHeldItem, handTypeId);
    }
}

function changeHeldItem(player, entity, state) {
    if (isOutsideMegaEvolved(state.pokemon)) {
        player.sendMessage("§cRevert Mega Evolution before changing its held item.");
        return;
    }
    const { stack } = handState(player);
    const oldForm = specialFormName(state.pokemon);
    const oldHeldItem = state.pokemon.heldItem;

    if (!stack) {
        if (!oldHeldItem) {
            player.sendMessage("§7Hold an item to give it to your Pokemon.");
            return;
        }
        const preview = JSON.parse(JSON.stringify(state.pokemon));
        delete preview.heldItem;
        delete preview.heldItemData;
        reconcileSpecialForm(preview);
        if (oldForm !== specialFormName(preview)) {
            runSpecialFormChangeSequence(player, entity, state.pokemon.uuid, ({ pokemon }) => {
                if (normalizeHeldItemId(pokemon.heldItem) !== normalizeHeldItemId(oldHeldItem)) {
                    return { error: "That Pokemon's held item changed before the transformation finished." };
                }
                if (!returnItemToPlayer(player, oldHeldItem, pokemon.heldItemData)) {
                    return { error: `Could not return ${titleCase(oldHeldItem)}.` };
                }
                delete pokemon.heldItem;
                delete pokemon.heldItemData;
                reconcileSpecialForm(pokemon);
                return { message: { translate: "cobblemon.held_item.take", with: [itemDisplayName(oldHeldItem), pokemonName(pokemon)] } };
            });
            return;
        }
        if (!returnItemToPlayer(player, oldHeldItem, state.pokemon.heldItemData)) return;
        delete state.pokemon.heldItem;
        delete state.pokemon.heldItemData;
        savePartyToPlayer(player, state.party);
        savePokemonToEntity(entity, state.pokemon);
        if (oldForm !== specialFormName(state.pokemon)) playMegaEvolutionEffect(entity);
        announceHeldItemChange(player, entity, state.pokemon, oldHeldItem, undefined);
        return;
    }

    const newHeldItem = stack.typeId;
    if (!isHoldableItem(newHeldItem)) {
        player.sendMessage({
            translate: "cobblemon.held_item.forbidden",
            with: [itemDisplayName(newHeldItem), pokemonName(state.pokemon)]
        });
        return;
    }
    if (normalizeHeldItemId(oldHeldItem) === normalizeHeldItemId(newHeldItem)) {
        player.sendMessage({
            translate: "cobblemon.held_item.already_holding",
            with: [pokemonName(state.pokemon), itemDisplayName(newHeldItem)]
        });
        return;
    }
    const newHeldItemData = itemStackData(stack);
    const preview = JSON.parse(JSON.stringify(state.pokemon));
    preview.heldItem = newHeldItem;
    preview.heldItemData = newHeldItemData;
    reconcileSpecialForm(preview);
    if (oldForm !== specialFormName(preview)) {
        runSpecialFormChangeSequence(player, entity, state.pokemon.uuid, ({ pokemon }) => {
            const currentHand = handState(player).stack;
            if (!currentHand || currentHand.typeId !== newHeldItem) {
                return { error: "Keep the form-change item in your hand until the transformation finishes." };
            }
            if (normalizeHeldItemId(pokemon.heldItem) !== normalizeHeldItemId(oldHeldItem)) {
                return { error: "That Pokemon's held item changed before the transformation finished." };
            }
            const currentItemData = itemStackData(currentHand);
            if (!consumeOneFromHand(player, newHeldItem)) {
                return { error: "Keep the form-change item in your hand until the transformation finishes." };
            }
            if (oldHeldItem && !returnItemToPlayer(player, oldHeldItem, pokemon.heldItemData)) {
                returnItemToPlayer(player, newHeldItem, currentItemData);
                return { error: `Could not return ${titleCase(oldHeldItem)}.` };
            }
            pokemon.heldItem = newHeldItem;
            pokemon.heldItemData = currentItemData;
            const queued = queueHeldItemEvolutions(pokemon, player);
            reconcileSpecialForm(pokemon);
            if (queued.length) {
                return { message: `${pokemonName(pokemon)} is ready to evolve! Open the party menu and press Evolve.` };
            }
            return {
                message: {
                    translate: oldHeldItem ? "cobblemon.held_item.replace" : "cobblemon.held_item.give",
                    with: oldHeldItem
                        ? [itemDisplayName(oldHeldItem), pokemonName(pokemon), itemDisplayName(newHeldItem)]
                        : [pokemonName(pokemon), itemDisplayName(newHeldItem)]
                }
            };
        });
        return;
    }
    if (!consumeOneFromHand(player, newHeldItem)) return;
    if (oldHeldItem && !returnItemToPlayer(player, oldHeldItem, state.pokemon.heldItemData)) {
        returnItemToPlayer(player, newHeldItem, newHeldItemData);
        return;
    }
    state.pokemon.heldItem = newHeldItem;
    state.pokemon.heldItemData = newHeldItemData;
    const queued = queueHeldItemEvolutions(state.pokemon, player);
    savePartyToPlayer(player, state.party);
    savePokemonToEntity(entity, state.pokemon);
    if (oldForm !== specialFormName(state.pokemon)) playMegaEvolutionEffect(entity);

    if (queued.length) {
        player.sendMessage(`§a${pokemonName(state.pokemon)} is ready to evolve! Open the party menu and press Evolve.`);
        return;
    }
    announceHeldItemChange(player, entity, state.pokemon, oldHeldItem, newHeldItem);
}

function mountPokemon(player, entity) {
    try {
        const rideable = entity.getComponent("minecraft:rideable");
        if (!rideable?.addRider(player)) player.sendMessage("§cThis Pokemon cannot be ridden right now.");
    } catch (error) {
        player.sendMessage("§cThis Pokemon cannot be ridden right now.");
    }
}

function addWheelButton(form, label, icon = undefined) {
    if (label === EMPTY_ACTION || !icon) form.button(label);
    else form.button(label, icon);
}

function showTradeOrAddonActions(player, pokemon, entity) {
    new ActionFormData()
        .title("Pokemon actions")
        .body(pokemonName(pokemon))
        .button("Trade")
        .button("Add-ons")
        .show(player)
        .then(response => {
            if (response.canceled || !player?.isValid) return;
            if (response.selection === 0) return offerPokemonTrade(player, pokemon.uuid);
            if (response.selection === 1) return showPokemonAddonActions(player, pokemon, entity);
        })
        .catch(error => console.warn(`Pokemon action menu failed: ${error}`));
}

export function showPokemonInteractWheel(player, entity) {
    if (!player?.isValid || !entity?.isValid || openWheels.has(player.id)) return false;
    if (interactionOwner(entity) !== player.id) {
        player.sendMessage("§cYou can only interact with your own Pokemon.");
        return false;
    }
    if (isInBattle(entity)) {
        player.sendMessage("§cYou cannot use the interaction wheel during battle.");
        return false;
    }

    const state = partyPokemonForEntity(player, entity);
    if (!state) {
        player.sendMessage("§cThis summoned Pokemon is no longer in your party.");
        return false;
    }

    const { stack } = handState(player);
    const evolutionOptions = stack ? itemEvolutionOptions(state.pokemon, stack.typeId, player) : [];
    const specialAction = stack ? specialFormUseAction(state.pokemon, stack.typeId) : null;
    const held = state.pokemon.heldItem ? titleCase(state.pokemon.heldItem) : "None";
    const useLabel = specialAction?.label || (evolutionOptions.length
        ? `Use ${titleCase(stack.typeId)} → ${speciesData(evolutionOptions[0].result)?.name || titleCase(evolutionOptions[0].result)}`
        : EMPTY_ACTION);
    const rideAvailable = canRide(player, entity);
    const shoulderAvailable = canShoulderMount(entity);
    const megaLabel = isOutsideMegaEvolved(state.pokemon)
        ? { translate: "lota.ui.interact.mega_revert" }
        : (megaFormForPokemon(state.pokemon) ? { translate: "lota.ui.interact.mega_evolve" } : EMPTY_ACTION);
    const addonActionsAvailable = pokemonAddonActions(state.pokemon).length > 0;
    let button3Label = megaLabel;
    let button3Icon = WHEEL_ICONS.mega;
    if (megaLabel === EMPTY_ACTION && shoulderAvailable) {
        button3Label = "Shoulder Mount";
        button3Icon = WHEEL_ICONS.ride;
    }

    const form = new ActionFormData()
        .title(INTERACT_TITLE)
        .body({ rawtext: [
            { text: `${pokemonName(state.pokemon)}\n` },
            { translate: "cobblemon.held_item" },
            { text: `: ${held}` }
        ] });
    addWheelButton(form, { translate: "gui.close" }, WHEEL_ICONS.close);
    addWheelButton(form, useLabel, WHEEL_ICONS.use);
    addWheelButton(form, { translate: "cobblemon.ui.interact.give.item" }, WHEEL_ICONS.held);
    addWheelButton(form, button3Label, button3Icon);
    addWheelButton(form, { translate: "lota.ui.interact.recall" }, WHEEL_ICONS.recall);
    addWheelButton(form, addonActionsAvailable ? "Trade / Add-ons" : "Trade", WHEEL_ICONS.trade);
    addWheelButton(form, { translate: "cobblemon.ui.summary.title" }, WHEEL_ICONS.summary);
    addWheelButton(form, rideAvailable ? { translate: "cobblemon.ui.interact.ride" } : EMPTY_ACTION, WHEEL_ICONS.ride);

    openWheels.add(player.id);
    form.show(player).then(response => {
        openWheels.delete(player.id);
        if (response.canceled || !entity?.isValid) return;
        if (interactionOwner(entity) !== player.id || isInBattle(entity)) return;
        const fresh = partyPokemonForEntity(player, entity);
        if (!fresh) return;
        Object.assign(state, fresh);
        const selection = Math.floor(Number(response.selection));
        if (selection === 1 && stack) {
            if (specialAction) return completeSpecialFormUse(player, entity, state, stack.typeId);
            if (evolutionOptions[0]) return completeItemEvolution(player, entity, state, evolutionOptions[0], stack.typeId);
        }
        if (selection === 2) {
            changeHeldItem(player, entity, state);
            if (entity?.isValid) system.run(() => showPokemonInteractWheel(player, entity));
            return;
        }
        if (selection === 3) {
            if (megaLabel !== EMPTY_ACTION) return runOutsideMegaEvolutionSequence(player, entity, state.pokemon.uuid);
            if (shoulderAvailable) return toggleShoulderMount(player, entity);
            return;
        }
        if (selection === 4) return recallPartyPokemon(player, state.pokemon);
        if (selection === 5) {
            if (addonActionsAvailable) return showTradeOrAddonActions(player, state.pokemon, entity);
            return offerPokemonTrade(player, state.pokemon.uuid);
        }
        if (selection === 6) return openPartyPokemonSummary(player, state.pokemon.uuid);
        if (selection === 7 && rideAvailable) return mountPokemon(player, entity);
    }).catch(error => {
        openWheels.delete(player.id);
        console.warn(`Pokemon interaction wheel failed: ${error}`);
    });
    return true;
}

function teachHeldDisc(player, entity) {
    if (!validEntity(entity)) return false;
    if (interactionOwner(entity) !== player.id) return false;
    if (isInBattle(entity)) return false;
    const state = partyPokemonForEntity(player, entity);
    if (!state) return false;
    return teachMoveWithHeldDisc(player, state.pokemon);
}
function sneakRecallPokemon(player, entity) {
    if (!player?.isValid || !entity?.isValid) return false;
    if (handState(player).stack) return false;
    if (interactionOwner(entity) !== player.id) return false;
    if (isInBattle(entity)) return false;
    const state = partyPokemonForEntity(player, entity);
    if (!state) return false;
    return recallPartyPokemonAnimated(player, state.pokemon, entity);
}

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    const entity = event.target;
    if (!entity?.hasTag("lota:party_pokemon")) return;
    event.cancel = true;
    const player = event.player;
    system.run(() => {
        if (consumePokemonInteractionClaim(player, entity)) return;
        if (player.isSneaking && sneakRecallPokemon(player, entity)) return;
        if (teachHeldDisc(player, entity)) return;
        showPokemonInteractWheel(player, entity);
    });
});

world.afterEvents.playerLeave.subscribe(event => {
    openWheels.delete(event.playerId);
    for (const key of outsideMegaSequences) {
        if (key.startsWith(`${event.playerId}:`)) outsideMegaSequences.delete(key);
    }
});
