export function capturePartyReference(currentParty, loadStoredParty) {
    if (Array.isArray(currentParty)) return currentParty;
    const stored = typeof loadStoredParty === "function" ? loadStoredParty() : [];
    return Array.isArray(stored) ? stored : [];
}
