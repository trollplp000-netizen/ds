import { BlockPermutation, ItemStack, system, world } from "@minecraft/server";

const APRICORN_COLORS = ["black", "blue", "green", "pink", "red", "white", "yellow"];
const APRICORN_LOG = "lota:apricorn_log";
const APRICORN_LEAVES = "lota:apricorn_leaves";
const APRICORN_FRUIT = "lota:apricorn_fruit";
const APRICORN_SAPLING = "lota:apricorn_sapling";
const COLOR_STATE = "lota:apricorn_color";
const GROWTH_STATE = "lota:growth_stage";
const NATURAL_STATE = "lota:natural";
const FACING_STATE = "lota:facing";
const BLOCK_FACE_STATE = "minecraft:block_face";
const CARDINAL_DIRECTION_STATE = "minecraft:cardinal_direction";
const MAX_FRUIT_AGE = 3;
const APRICORN_PLANT_IDS = new Set(APRICORN_COLORS.map(color => `lota:${color}_apricorn_plant`));
const SOIL_BLOCKS = new Set([
    "minecraft:grass_block",
    "minecraft:dirt",
    "minecraft:coarse_dirt",
    "minecraft:podzol",
    "minecraft:mycelium",
    "minecraft:dirt_with_roots",
    "minecraft:mud",
    "minecraft:muddy_mangrove_roots"
]);
const REPLACEABLE_BLOCKS = new Set([
    "minecraft:air",
    "minecraft:short_grass",
    "minecraft:tallgrass",
    "minecraft:fern",
    "minecraft:large_fern",
    "minecraft:snow_layer",
    APRICORN_LEAVES,
    APRICORN_SAPLING,
    ...APRICORN_PLANT_IDS
]);
const CARDINAL_BLOCK_FACES = new Set(["north", "south", "west", "east"]);
const CANDIDATE_SUPPORT_OFFSETS = {
    north: { x: 0, y: 0, z: -1 },
    south: { x: 0, y: 0, z: 1 },
    west: { x: -1, y: 0, z: 0 },
    east: { x: 1, y: 0, z: 0 }
};
const FRUIT_SUPPORT_OFFSETS = {
    north: { x: 0, y: 0, z: 1 },
    south: { x: 0, y: 0, z: -1 },
    west: { x: 1, y: 0, z: 0 },
    east: { x: -1, y: 0, z: 0 }
};
const BLOCK_FACE_BY_SUPPORT = {
    north: "south",
    south: "north",
    west: "east",
    east: "west"
};

function getBlock(dimension, origin, x = 0, y = 0, z = 0) {
    try {
        return dimension.getBlock({ x: origin.x + x, y: origin.y + y, z: origin.z + z });
    } catch (error) {
        return undefined;
    }
}

function selectedItem(player) {
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        return { container, slot: player.selectedSlotIndex, item: container?.getItem(player.selectedSlotIndex) };
    } catch (error) {
        return { container: undefined, slot: -1, item: undefined };
    }
}

function isCreative(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function consumeInventorySlot(player, slot, expectedTypeId) {
    if (isCreative(player)) return true;
    let container;
    let item;
    try {
        container = player.getComponent("minecraft:inventory")?.container;
        item = container?.getItem(slot);
    } catch (error) {
        return false;
    }
    if (!container || !item || item.typeId !== expectedTypeId) return false;
    if (item.amount <= 1) container.setItem(slot, undefined);
    else {
        item.amount -= 1;
        container.setItem(slot, item);
    }
    return true;
}

function consumeSelectedItem(player, expectedTypeId) {
    return consumeInventorySlot(player, player.selectedSlotIndex, expectedTypeId);
}

function fruitItem(color) {
    return `lota:${color}_apricorn`;
}

function seedItem(color) {
    return `lota:${color}_apricorn_seed`;
}

function fruitPermutation(color, age, facing) {
    return BlockPermutation.resolve(APRICORN_FRUIT, {
        [COLOR_STATE]: color,
        [GROWTH_STATE]: Math.max(0, Math.min(MAX_FRUIT_AGE, Math.floor(age))),
        [FACING_STATE]: facing,
        [BLOCK_FACE_STATE]: facing,
        [CARDINAL_DIRECTION_STATE]: facing
    });
}

function saplingPermutation(color, stage = 0, natural = false) {
    return BlockPermutation.resolve(APRICORN_SAPLING, {
        [COLOR_STATE]: color,
        [GROWTH_STATE]: Math.max(0, Math.min(1, Math.floor(stage))),
        [NATURAL_STATE]: Boolean(natural)
    });
}

function colorFromPlantBlock(blockId) {
    const match = /^lota:(black|blue|green|pink|red|white|yellow)_apricorn_plant$/.exec(String(blockId || ""));
    return match?.[1];
}

function blockFace(block) {
    try {
        return String(block.permutation.getState(BLOCK_FACE_STATE));
    } catch (error) {
        return "";
    }
}

function apricornColor(block) {
    const plantColor = colorFromPlantBlock(block?.typeId);
    if (plantColor) return plantColor;
    try {
        return String(block.permutation.getState(COLOR_STATE));
    } catch (error) {
        return "";
    }
}

function fruitFacing(block) {
    const nativeFace = blockFace(block);
    if (CARDINAL_BLOCK_FACES.has(nativeFace)) return nativeFace;
    try {
        const legacyFacing = String(block.permutation.getState(FACING_STATE));
        return CARDINAL_BLOCK_FACES.has(legacyFacing) ? legacyFacing : "";
    } catch (error) {
        return "";
    }
}

function isApricornFruitBlock(block) {
    return Boolean(block) && (
        block.typeId === APRICORN_FRUIT
        || (APRICORN_PLANT_IDS.has(block.typeId) && CARDINAL_BLOCK_FACES.has(blockFace(block)))
    );
}

function isApricornSaplingBlock(block) {
    return Boolean(block) && (
        block.typeId === APRICORN_SAPLING
        || (APRICORN_PLANT_IDS.has(block.typeId) && blockFace(block) === "up")
    );
}

function hasApricornLeafSupport(block) {
    if (!block) return false;
    if (APRICORN_PLANT_IDS.has(block.typeId)) {
        const supportOffset = FRUIT_SUPPORT_OFFSETS[fruitFacing(block)];
        return Boolean(supportOffset
            && getBlock(block.dimension, block.location, supportOffset.x, 0, supportOffset.z)?.typeId === APRICORN_LEAVES);
    }
    for (const offset of Object.values(CANDIDATE_SUPPORT_OFFSETS)) {
        if (getBlock(block.dimension, block.location, offset.x, 0, offset.z)?.typeId === APRICORN_LEAVES) return true;
    }
    return false;
}

function playHarvestSound(player) {
    try {
        player?.playSound("random.pop", { volume: 0.7, pitch: 1.4 });
    } catch (error) {}
}

function spawnDrop(dimension, location, itemId, amount = 1) {
    try {
        dimension.spawnItem(new ItemStack(itemId, amount), {
            x: location.x + 0.5,
            y: location.y + 0.35,
            z: location.z + 0.5
        });
    } catch (error) {
        console.warn(`Apricorn drop failed for '${itemId}': ${error}`);
    }
}

function harvestApricorn(block, player) {
    if (!isApricornFruitBlock(block)) return false;
    const age = Number(block.permutation.getState(GROWTH_STATE));
    if (age !== MAX_FRUIT_AGE) return false;
    const color = apricornColor(block);
    const facing = fruitFacing(block);
    if (!APRICORN_COLORS.includes(color) || !CARDINAL_BLOCK_FACES.has(facing)) return false;

    spawnDrop(block.dimension, block.location, fruitItem(color));
    if (Math.random() < 0.1) spawnDrop(block.dimension, block.location, seedItem(color));
    block.setPermutation(block.permutation.withState(GROWTH_STATE, 0));
    playHarvestSound(player);
    return true;
}

function growFruit(block) {
    if (!isApricornFruitBlock(block)) return;
    const facing = fruitFacing(block);
    if (!hasApricornLeafSupport(block)) {
        block.setType("minecraft:air");
        return;
    }

    const age = Number(block.permutation.getState(GROWTH_STATE));
    if (age >= MAX_FRUIT_AGE || Math.random() >= 0.2) return;
    block.setPermutation(block.permutation.withState(GROWTH_STATE, age + 1));
}

function decayLeaves(block) {
    if (!block || block.typeId !== APRICORN_LEAVES) return;
    for (let y = -5; y <= 5; y++) {
        for (let x = -3; x <= 3; x++) {
            for (let z = -3; z <= 3; z++) {
                if (Math.abs(x) + Math.abs(y) + Math.abs(z) > 6) continue;
                if (getBlock(block.dimension, block.location, x, y, z)?.typeId === APRICORN_LOG) return;
            }
        }
    }
    block.setType("minecraft:air");
}

function setLeafIfClear(dimension, origin, x, y, z) {
    const block = getBlock(dimension, origin, x, y, z);
    if (!block || !REPLACEABLE_BLOCKS.has(block.typeId)) return false;
    block.setType(APRICORN_LEAVES);
    return true;
}

function shuffle(values) {
    for (let index = values.length - 1; index > 0; index--) {
        const swap = Math.floor(Math.random() * (index + 1));
        [values[index], values[swap]] = [values[swap], values[index]];
    }
    return values;
}

function fruitCandidatesForLeaf(origin, x, y, z) {
    const candidates = [];
    for (const direction of [
        { x: 0, z: -1, facing: "south" },
        { x: 1, z: 0, facing: "west" },
        { x: 0, z: 1, facing: "north" },
        { x: -1, z: 0, facing: "east" }
    ]) {
        const candidate = { x: x + direction.x, y, z: z + direction.z, facing: direction.facing };
        const target = getBlock(origin.dimension, origin.location, candidate.x, candidate.y, candidate.z);
        if (target?.typeId === "minecraft:air") candidates.push(candidate);
    }
    return candidates;
}

function growApricornTree(sapling) {
    if (!isApricornSaplingBlock(sapling)) return false;
    const dimension = sapling.dimension;
    const origin = { ...sapling.location };
    const color = apricornColor(sapling);
    const natural = sapling.typeId === APRICORN_SAPLING
        && sapling.permutation.getState(NATURAL_STATE) === true;
    if (!APRICORN_COLORS.includes(color)) return false;

    const soil = getBlock(dimension, origin, 0, -1, 0);
    if (!soil || !SOIL_BLOCKS.has(soil.typeId)) return false;
    for (let y = 0; y <= 5; y++) {
        const trunkSpace = getBlock(dimension, origin, 0, y, 0);
        if (!trunkSpace || !REPLACEABLE_BLOCKS.has(trunkSpace.typeId)) return false;
    }

    for (let y = 0; y <= 4; y++) getBlock(dimension, origin, 0, y, 0)?.setType(APRICORN_LOG);

    for (let y = 1; y <= 4; y++) {
        for (let x = -1; x <= 1; x++) {
            for (let z = -1; z <= 1; z++) {
                if (x !== 0 || z !== 0) setLeafIfClear(dimension, origin, x, y, z);
            }
        }
    }

    const layerOneDirections = shuffle([
        { x: 2, z: 0 }, { x: -2, z: 0 }, { x: 0, z: 2 }, { x: 0, z: -2 }
    ]);
    const extender = layerOneDirections[0];
    setLeafIfClear(dimension, origin, extender.x, 1, extender.z);
    setLeafIfClear(dimension, origin, extender.x + (extender.x === 0 ? (Math.random() < 0.5 ? 1 : -1) : 0), 1,
        extender.z + (extender.z === 0 ? (Math.random() < 0.5 ? 1 : -1) : 0));

    const cardinalOuterLeaves = [
        { x: 2, z: 0 }, { x: -2, z: 0 }, { x: 0, z: 2 }, { x: 0, z: -2 },
    ];
    const offAxisOuterLeaves = [
        { x: 1, z: 2 }, { x: -1, z: 2 }, { x: 1, z: -2 }, { x: -1, z: -2 },
        { x: 2, z: 1 }, { x: 2, z: -1 }, { x: -2, z: 1 }, { x: -2, z: -1 }
    ];
    const outerLeaves = [...cardinalOuterLeaves, ...offAxisOuterLeaves];
    for (const offset of outerLeaves) {
        setLeafIfClear(dimension, origin, offset.x, 2, offset.z);
        setLeafIfClear(dimension, origin, offset.x, 3, offset.z);
    }

    setLeafIfClear(dimension, origin, 0, 5, 0);
    setLeafIfClear(dimension, origin, 1, 5, 0);
    setLeafIfClear(dimension, origin, -1, 5, 0);
    setLeafIfClear(dimension, origin, 0, 5, 1);
    setLeafIfClear(dimension, origin, 0, 5, -1);

    const crownDirections = shuffle([
        { x: 2, z: 0 }, { x: -2, z: 0 }, { x: 0, z: 2 }, { x: 0, z: -2 }
    ]).slice(0, 2 + Math.floor(Math.random() * 2));
    for (const offset of crownDirections) {
        const side = Math.random() < 0.5 ? 1 : -1;
        const companion = {
            x: offset.x + (offset.x === 0 ? side : 0),
            z: offset.z + (offset.z === 0 ? side : 0)
        };
        if (Math.random() < 1 / 3) {
            setLeafIfClear(dimension, origin, offset.x, 4, offset.z);
            setLeafIfClear(dimension, origin, companion.x, 4, companion.z);
        } else if (Math.random() < 0.5) setLeafIfClear(dimension, origin, offset.x, 4, offset.z);
        else setLeafIfClear(dimension, origin, companion.x, 4, companion.z);
    }

    const originBlock = { dimension, location: origin };
    const fruitCandidateGroups = [];
    for (const offset of cardinalOuterLeaves) {
        const outward = offset.x !== 0
            ? { x: Math.sign(offset.x), z: 0, facing: offset.x > 0 ? "west" : "east" }
            : { x: 0, z: Math.sign(offset.z), facing: offset.z > 0 ? "north" : "south" };
        const candidates = [];
        for (const y of [2, 3]) {
            const candidate = { x: offset.x + outward.x, y, z: offset.z + outward.z, facing: outward.facing };
            if (getBlock(dimension, origin, candidate.x, candidate.y, candidate.z)?.typeId === "minecraft:air") {
                candidates.push(candidate);
            }
        }
        fruitCandidateGroups.push(candidates);
    }
    for (const offset of offAxisOuterLeaves) {
        const candidates = [];
        for (const y of [2, 3]) candidates.push(...fruitCandidatesForLeaf(originBlock, offset.x, y, offset.z));
        fruitCandidateGroups.push(candidates);
    }
    const selectedGroups = shuffle(fruitCandidateGroups.filter(group => group.length > 0)).slice(0, 8);
    for (const group of selectedGroups) {
        const candidate = group[Math.floor(Math.random() * group.length)];
        const target = getBlock(dimension, origin, candidate.x, candidate.y, candidate.z);
        if (!target || target.typeId !== "minecraft:air") continue;
        const supportOffset = CANDIDATE_SUPPORT_OFFSETS[candidate.facing];
        const support = supportOffset
            ? getBlock(dimension, target.location, supportOffset.x, 0, supportOffset.z)
            : undefined;
        if (!support || support.typeId !== APRICORN_LEAVES) continue;
        const blockFace = BLOCK_FACE_BY_SUPPORT[candidate.facing];
        if (!blockFace) continue;
        target.setPermutation(fruitPermutation(color, natural ? Math.floor(Math.random() * 4) : 0, blockFace));
    }
    return true;
}

function growSapling(block) {
    if (!isApricornSaplingBlock(block)) return;
    const soil = getBlock(block.dimension, block.location, 0, -1, 0);
    if (!soil || !SOIL_BLOCKS.has(soil.typeId)) {
        const color = apricornColor(block);
        if (APRICORN_COLORS.includes(color)) spawnDrop(block.dimension, block.location, seedItem(color));
        block.setType("minecraft:air");
        return;
    }
    if (block.permutation.getState(NATURAL_STATE) === true) {
        growApricornTree(block);
        return;
    }
    const light = block.dimension.getLightLevel({ x: block.location.x, y: block.location.y + 1, z: block.location.z });
    if (Number(light) < 9 || Math.random() >= 1 / 7) return;
    const stage = Number(block.permutation.getState(GROWTH_STATE));
    if (stage <= 0) block.setPermutation(block.permutation.withState(GROWTH_STATE, 1));
    else growApricornTree(block);
}

function applyBoneMeal(block, player, growAction) {
    const { item } = selectedItem(player);
    if (item?.typeId !== "minecraft:bone_meal") return false;
    if (!consumeSelectedItem(player, "minecraft:bone_meal")) return false;
    growAction(block);
    try {
        block.dimension.spawnParticle("minecraft:crop_growth_emitter", {
            x: block.location.x + 0.5,
            y: block.location.y + 0.5,
            z: block.location.z + 0.5
        });
    } catch (error) {}
    return true;
}

function forceGrowFruit(block) {
    const age = Number(block.permutation.getState(GROWTH_STATE));
    if (age < MAX_FRUIT_AGE) block.setPermutation(block.permutation.withState(GROWTH_STATE, age + 1));
}

function forceGrowSapling(block) {
    const stage = Number(block.permutation.getState(GROWTH_STATE));
    if (stage <= 0) block.setPermutation(block.permutation.withState(GROWTH_STATE, 1));
    else growApricornTree(block);
}

function tickApricornPlant(block) {
    if (isApricornFruitBlock(block)) growFruit(block);
    else growSapling(block);
}

function interactWithApricornPlant(block, player) {
    if (!player) return;
    if (isApricornFruitBlock(block)) {
        const age = Number(block.permutation.getState(GROWTH_STATE));
        if (age < MAX_FRUIT_AGE && applyBoneMeal(block, player, forceGrowFruit)) return;
        if (age === MAX_FRUIT_AGE) harvestApricorn(block, player);
        return;
    }
    applyBoneMeal(block, player, forceGrowSapling);
}

system.beforeEvents.startup.subscribe(event => {
    event.blockComponentRegistry.registerCustomComponent("lota:apricorn_fruit_component", {
        onTick: eventData => growFruit(eventData.block),
        onPlayerInteract: eventData => {
            const { block, player } = eventData;
            if (!player) return;
            const age = Number(block.permutation.getState(GROWTH_STATE));
            if (age < MAX_FRUIT_AGE && applyBoneMeal(block, player, forceGrowFruit)) return;
            if (age === MAX_FRUIT_AGE) harvestApricorn(block, player);
        }
    });
    event.blockComponentRegistry.registerCustomComponent("lota:apricorn_sapling_component", {
        onTick: eventData => growSapling(eventData.block),
        onPlayerInteract: eventData => {
            if (eventData.player) applyBoneMeal(eventData.block, eventData.player, forceGrowSapling);
        }
    });
    event.blockComponentRegistry.registerCustomComponent("lota:apricorn_plant_component", {
        onTick: eventData => tickApricornPlant(eventData.block),
        onPlayerInteract: eventData => interactWithApricornPlant(eventData.block, eventData.player)
    });
    event.blockComponentRegistry.registerCustomComponent("lota:apricorn_leaves_component", {
        onTick: eventData => decayLeaves(eventData.block)
    });
});

world.beforeEvents.playerBreakBlock.subscribe(event => {
    const dimension = event.block.dimension;
    const location = { ...event.block.location };
    if (isApricornFruitBlock(event.block)) {
        if (Number(event.block.permutation.getState(GROWTH_STATE)) !== MAX_FRUIT_AGE) return;
        event.cancel = true;
        const player = event.player;
        system.run(() => harvestApricorn(dimension.getBlock(location), player));
        return;
    }

    if (isApricornSaplingBlock(event.block)) {
        const color = apricornColor(event.block);
        if (event.block.typeId === APRICORN_SAPLING
            && !isCreative(event.player)
            && APRICORN_COLORS.includes(color)) {
            system.run(() => spawnDrop(dimension, location, seedItem(color)));
        }
        return;
    }
    if (event.block.typeId !== APRICORN_LEAVES) return;

    system.run(() => {
        for (const offset of Object.values(CANDIDATE_SUPPORT_OFFSETS)) {
            const fruit = getBlock(dimension, location, offset.x, 0, offset.z);
            if (!isApricornFruitBlock(fruit)) continue;
            if (!hasApricornLeafSupport(fruit)) fruit.setType("minecraft:air");
        }
    });
});
