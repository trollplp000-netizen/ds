import { system, world } from "@minecraft/server";
import { MOVE_DATA } from "./move_registry.js";
import { addPokemonExperience } from "./experience.js";
import { partyEffectsFor } from "./party_hud_effects.js";
import { getEffectiveLevelCap } from "./level_cap.js";
import { buildFieldPartySelectionForm } from "./party_target_form.js";
import { claimPokemonInteraction } from "./pokemon_interaction_claims.js";
import {
    EXPERIENCE_ITEM_IDS,
    EXPERIENCE_ITEM_ID_SET,
    experienceItemYield,
    withExperienceItemTooltip
} from "./experience_item_data.js";
import {
    loadPartyFromPlayer,
    savePartyToPlayer,
    savePokemonToEntity
} from "./storage.js";

const selectionSessions = new Map();
const directUseSuppression = new Map();

function pokemonName(pokemon) {
    return String(pokemon?.nickname || pokemon?.species || "Pokemon").replace(/^lota:/, "");
}

function moveName(moveId) {
    const id = String(moveId || "").replace(/^.*:/, "").toLowerCase();
    return String(MOVE_DATA[id]?.name || id || "Move");
}

function selectedInventorySlot(player) {
    return Math.max(0, Math.floor(Number(player?.selectedSlotIndex) || 0));
}

function heldStack(player, slot = selectedInventorySlot(player)) {
    try {
        return player.getComponent("minecraft:inventory")?.container?.getItem(slot);
    } catch (error) {
        return undefined;
    }
}

function isCreativePlayer(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function consumeHeldItem(player, slot, itemId) {
    if (isCreativePlayer(player)) return true;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const stack = container?.getItem(slot);
        if (!container || stack?.typeId !== itemId) return false;
        if (stack.amount <= 1) container.setItem(slot, undefined);
        else {
            stack.amount -= 1;
            container.setItem(slot, stack);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function findPartySlotByUuid(party, uuid) {
    return party.findIndex(pokemon => pokemon && String(pokemon.uuid || "") === String(uuid || ""));
}

function findSummonedPokemon(player, uuid) {
    if (!uuid) return undefined;
    try {
        for (const entity of player.dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            if (!entity?.isValid) continue;
            if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== player.id) continue;
            const data = JSON.parse(String(entity.getDynamicProperty("lota:pokemon_data") || "{}"));
            if (String(data.uuid || "") === String(uuid)) return entity;
        }
    } catch (error) {}
    return undefined;
}

function syncSummonedPokemon(player, pokemon, preferredEntity = undefined) {
    const entity = preferredEntity?.isValid ? preferredEntity : findSummonedPokemon(player, pokemon?.uuid);
    if (!entity) return;
    try {
        savePokemonToEntity(entity, pokemon);
        entity.nameTag = `§f${pokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        entity.dimension.playSound("lota.item.medicine_candy_use", entity.location, {
            volume: 1,
            pitch: 1
        });
    } catch (error) {}
}

function applyExperienceItem(player, itemId, inventorySlot, partySlot, preferredEntity = undefined) {
    const stack = heldStack(player, inventorySlot);
    if (stack?.typeId !== itemId) {
        player.sendMessage("§cYou are no longer holding that item.");
        return false;
    }

    const party = loadPartyFromPlayer(player);
    const pokemon = party[partySlot];
    if (!pokemon) return false;
    const yieldAmount = experienceItemYield(itemId, pokemon);
    if (yieldAmount <= 0) {
        player.sendMessage("§7No effect.");
        return false;
    }

    const levelCap = getEffectiveLevelCap(player);
    const result = addPokemonExperience(pokemon, yieldAmount, levelCap);
    if (result.amount <= 0) {
        player.sendMessage(result.capped ? `§e${pokemonName(pokemon)} is already Lv.${levelCap}.` : "§7No effect.");
        return false;
    }
    if (!consumeHeldItem(player, inventorySlot, itemId)) {
        player.sendMessage("§cYou are no longer holding that item.");
        return false;
    }
    partyEffectsFor(player.id)?.expGained(pokemon.uuid, result);
    if (!savePartyToPlayer(player, party)) {
        player.sendMessage("§cFailed to save Pokemon data.");
        return false;
    }

    syncSummonedPokemon(player, pokemon, preferredEntity);
    if (result.newLevel > result.oldLevel) {
        player.sendMessage(`§a${pokemonName(pokemon)} reached Lv.${result.newLevel}!`);
    } else {
        player.sendMessage(`§a${pokemonName(pokemon)} gained ${result.amount} EXP.`);
    }
    for (const moveId of result.learnedMoves || []) {
        player.sendMessage(`§b${pokemonName(pokemon)} learned ${moveName(moveId)}!`);
    }
    if (result.queuedEvolutions?.length) {
        player.sendMessage(`§a${pokemonName(pokemon)} appears ready to evolve!`);
    }
    return true;
}

function showPartySelection(player, itemId, inventorySlot) {
    if (selectionSessions.has(player.id)) return;
    const party = loadPartyFromPlayer(player);
    if (!party.some(Boolean)) return;

    const session = { itemId, inventorySlot, formOpen: true };
    selectionSessions.set(player.id, session);
    const form = buildFieldPartySelectionForm(player, party);

    form.show(player).then(response => {
        selectionSessions.delete(player.id);
        if (response.canceled) return;
        const partySlot = Math.floor(Number(response.selection));
        if (partySlot >= 0 && partySlot < 6 && party[partySlot]) {
            applyExperienceItem(player, itemId, inventorySlot, partySlot);
        }
    }).catch(error => {
        selectionSessions.delete(player.id);
        console.warn(`Experience item party selection failed: ${error}`);
    });
}

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    const itemId = String(event.itemStack?.typeId || "");
    if (!EXPERIENCE_ITEM_ID_SET.has(itemId) || event.player?.isSneaking) return;
    if (event.player.hasTag("lota:battle_player")) return;
    const target = event.target;
    if (!target?.hasTag("lota:party_pokemon")) return;
    if (String(target.getDynamicProperty("lota:party_owner_id") || "") !== event.player.id) return;
    if (!claimPokemonInteraction(event.player, target)) return;

    let data;
    try { data = JSON.parse(String(target.getDynamicProperty("lota:pokemon_data") || "{}")); } catch (error) { return; }
    const inventorySlot = selectedInventorySlot(event.player);
    event.cancel = true;
    directUseSuppression.set(event.player.id, system.currentTick + 2);
    system.run(() => {
        const party = loadPartyFromPlayer(event.player);
        const partySlot = findPartySlotByUuid(party, data.uuid);
        if (partySlot >= 0) applyExperienceItem(event.player, itemId, inventorySlot, partySlot, target);
    });
});

world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    const itemId = String(event.itemStack?.typeId || "");
    if (!player || !EXPERIENCE_ITEM_ID_SET.has(itemId) || player.isSneaking) return;
    if (player.hasTag("lota:battle_player")) return;
    const suppressedUntil = directUseSuppression.get(player.id) || -1;
    if (suppressedUntil >= system.currentTick) return;
    directUseSuppression.delete(player.id);
    showPartySelection(player, itemId, selectedInventorySlot(player));
});

function decorateChangedExperienceItem(event) {
    const expected = event.itemStack;
    if (!expected || !EXPERIENCE_ITEM_ID_SET.has(expected.typeId)) return;
    system.run(() => {
        const player = event.player;
        if (!player?.isValid) return;
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) return;
        const candidates = [event.slot];
        if (event.inventoryType === "Inventory" && event.slot + 9 < container.size) candidates.push(event.slot + 9);
        const matchingSlots = [...new Set(candidates)].filter(slot => {
            const stack = container.getItem(slot);
            return stack?.typeId === expected.typeId && stack.amount === expected.amount;
        });
        if (matchingSlots.length !== 1) return;
        const slot = matchingSlots[0];
        const stack = container.getItem(slot);
        try {
            const lore = withExperienceItemTooltip(stack.typeId, stack.getRawLore());
            if (!lore) return;
            stack.setLore(lore);
            container.setItem(slot, stack);
        } catch (error) {
            console.warn(`Experience item tooltip failed for ${stack.typeId}: ${error}`);
        }
    });
}

const inventoryChange = world.afterEvents.playerInventoryItemChange;
if (inventoryChange?.subscribe) {
    inventoryChange.subscribe(decorateChangedExperienceItem, { includeItems: EXPERIENCE_ITEM_IDS });
}

world.afterEvents.playerLeave.subscribe(event => {
    selectionSessions.delete(event.playerId);
    directUseSuppression.delete(event.playerId);
});
