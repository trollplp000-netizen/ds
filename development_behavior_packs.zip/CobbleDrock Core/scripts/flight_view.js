const clamp = (v,a,b) => Math.max(a,Math.min(b,v));

export function flightBank(previous, yawChange, speed, maximumSpeed) {
    const strength=clamp(Math.abs(speed)/Math.max(.01,maximumSpeed),0,1);
    const target=clamp(-yawChange*18,-50,50)*strength;
    return previous+clamp(target-previous,-3,3);
}

export function flightCameraView(location, yaw, pitch, seatHeight=1.5, distance=6) {
    const y=yaw*Math.PI/180,p=clamp(pitch,-75,75)*Math.PI/180;
    const forward={x:-Math.sin(y)*Math.cos(p),y:-Math.sin(p),z:Math.cos(y)*Math.cos(p)};
    const focus={x:location.x,y:location.y+seatHeight+.6,z:location.z};
    return {location:{x:focus.x-forward.x*distance,y:focus.y-forward.y*distance+.7,z:focus.z-forward.z*distance},
        facingLocation:{x:focus.x+forward.x*3,y:focus.y+forward.y*3,z:focus.z+forward.z*3}};
}

