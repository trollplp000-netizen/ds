import { buildBattlePartySelectionForm } from "./battle_system.js";

export const FIELD_PARTY_FORM_TITLE = "cobbledrock.party.select";

export function buildFieldPartySelectionForm(player, party) {
    return buildBattlePartySelectionForm(party, { player }).title(FIELD_PARTY_FORM_TITLE);
}
