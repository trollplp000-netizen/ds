import { ItemStack, system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData, uiManager } from "@minecraft/server-ui";
import { TM_MOVES, TM_LEARNSETS, TM_TYPES } from "./tm_data.js";
import { MOVE_DATA } from "./battle_moves.js";
import { loadPartyFromPlayer, savePartyToPlayer } from "./storage.js";
import { speciesData } from "./battle_math.js";
import { itemTexturePath } from "./tm_item_textures.js";
import {
    chestScreenActive, closeChestScreen, openChestScreen, refreshChestScreen, registerChestScreen
} from "./chest_ui.js";
import {
    TM_CHEST_TITLE, TM_CHEST_SLOT_COUNT, TM_CHEST_STATE_SLOT,
    TM_CHEST_BTN, TM_CHEST_TB, TM_CHEST_CAP, TM_CHEST_IC
} from "./tm_chest_layout.js";

const BLOCK_ID = "lota:tm_machine";
const TM_TITLE_ROOT = "cobbledrock.tm";

const TM_CHEST_KEY = "tm";
const MENU_FORM_TAG = "lota:menu_form";
const DESC_WIDTH_FORM = 58;
const DESC_WIDTH_CHEST = 46;

class TmViewRecorder {
    constructor() { this.buttons = []; this.icons = {}; }
    button(text, icon) {
        const index = this.buttons.length;
        this.buttons.push(text === undefined || text === null ? " " : String(text));
        if (icon) this.icons[index] = icon;
        return this;
    }
    toChestView(title) { return { title, buttons: this.buttons, icons: this.icons }; }
    toActionForm(title) {
        const form = new ActionFormData().title(title);
        for (let i = 0; i < this.buttons.length; i++) form.button(this.buttons[i], this.icons[i]);
        return form;
    }
}

const MODE_TYPE = 1;
const MODE_MOVE = 2;
const MODE_BURN = 3;

const BURN_PROGRESS_PER_TICK = 2;
const BURN_TOTAL_TIME = 200;
const CRAFT_TICKS = 10;
const RESET_DISC_TICKS = 4;
const TOTAL_PROCESS_TIME =
    BURN_TOTAL_TIME + (CRAFT_TICKS + RESET_DISC_TICKS) * BURN_PROGRESS_PER_TICK;


const RESULT_SLOT = 0;
const BLANK_TM_SLOT = 1;
const INGREDIENT_SLOTS = [2, 3, 4];
const MACHINE_SLOT_COUNT = 5;

const BLANK_TM_ITEM = "lota:blank_tm";
const TM_ITEM_PREFIX = "lota:tm_";
const TM_MOVE_PROPERTY = "lota:tm_move";

const IDX_PARTY = 0;
const IDX_TYPE = 6;
const IDX_MOVE = 26;
const IDX_BACK = 62;
const IDX_START = 63;
const IDX_SEARCH = 64;
const IDX_SELMOVE = 65;
const IDX_MACHINE = 66;
const IDX_INVENTORY = 71;
const IDX_TITLE = 107;
const IDX_POWER = 108;
const IDX_ACCURACY = 109;
const IDX_EFFECT = 110;
const IDX_DESC = 111;
const IDX_RECIPE = 116;
const IDX_DISC = 119;
const IDX_PROGRESS = 120;
const IDX_MOVE_TYPE_ICON = 121;
const IDX_MOVE_CATEGORY = 157;
const IDX_MOVE_PP = 193;
const IDX_SELMOVE_BG = 229;
const IDX_SELMOVE_TYPE = 230;
const IDX_SELMOVE_CATEGORY = 231;
const IDX_SELMOVE_NAME = 232;
const IDX_SELMOVE_PP = 233;
const IDX_PARTY_CARRIER = 234;
const IDX_DISC_SPIN = 276;
const BUTTON_COUNT = 277;

const PARTY_CARRIERS = 7;
const MOVE_ROWS_TOTAL = 36;
const TYPE_ROWS = 5;
const TYPE_COLS = 4;
const TYPE_CELLS = TYPE_ROWS * TYPE_COLS;
const TYPE_ENTRIES = [null, ...TM_TYPES];
const DESC_LINES = 5;
const RECIPE_SLOTS = 3;
const PROGRESS_STEPS = 27;
const SCREEN_SAVER_TICKS = 1200;

const BURN_LOOP_TICKS = 60;

const TYPE_SET = new Set(TM_TYPES);
const sessions = new Map();
const activeMachines = new Map();
const burnLoopAt = new Map();

function machineKey(block) {
    return `lota:tm:${block.dimension.id}:${block.x}:${block.y}:${block.z}`;
}

function newMachine() {
    return {
        items: new Array(MACHINE_SLOT_COUNT).fill(null),
        activeMove: "",
        burnProgress: 0,
        burnActive: false,
        repeatProcess: false
    };
}

function normalizeItem(entry) {
    if (!entry || typeof entry !== "object") return null;
    const id = String(entry.id || "");
    const amount = Math.max(1, Math.floor(Number(entry.amount) || 1));
    if (!id) return null;
    const out = { id, amount };
    if (entry.move) out.move = String(entry.move);
    return out;
}

function loadMachine(block) {
    try {
        const raw = world.getDynamicProperty(machineKey(block));
        if (!raw) return newMachine();
        const parsed = JSON.parse(String(raw));
        const machine = newMachine();
        if (Array.isArray(parsed?.items)) {
            for (let i = 0; i < MACHINE_SLOT_COUNT; i++) {
                machine.items[i] = normalizeItem(parsed.items[i]);
            }
        }
        machine.activeMove = String(parsed?.activeMove || "");
        machine.burnProgress = Math.max(0, Math.floor(Number(parsed?.burnProgress) || 0));
        machine.burnActive = Boolean(parsed?.burnActive);
        machine.repeatProcess = Boolean(parsed?.repeatProcess);
        return machine;
    } catch (error) {
        return newMachine();
    }
}

function saveMachine(block, machine) {
    try {
        world.setDynamicProperty(machineKey(block), JSON.stringify(machine));
        return true;
    } catch (error) {
        console.warn(`TM machine save failed: ${error}`);
        return false;
    }
}

export function tmMoveFromStack(item) {
    if (!item) return undefined;
    try {
        const dynamic = item.getDynamicProperty?.(TM_MOVE_PROPERTY);
        if (typeof dynamic === "string" && TM_MOVES[dynamic]) return dynamic;
    } catch (error) {}
    try {
        const lore = item.getLore?.() || [];
        const marker = lore.find(line => String(line).startsWith("tm_move:"));
        const move = marker ? String(marker).slice("tm_move:".length).trim() : "";
        if (move && TM_MOVES[move]) return move;
    } catch (error) {}
    return undefined;
}

function sameItemIdentity(a, b) {
    if (!a || !b || a.typeId !== b.typeId) return false;
    if (!String(a.typeId).startsWith(TM_ITEM_PREFIX)) return true;
    const aMove = tmMoveFromStack(a);
    const bMove = tmMoveFromStack(b);
    return Boolean(aMove && bMove && aMove === bMove);
}

function removeFromInventoryStack(player, stack, amount) {
    const container = inventoryContainer(player);
    if (!container) return false;
    let remaining = amount;
    for (let slot = container.size - 1; slot >= 0 && remaining > 0; slot--) {
        const item = container.getItem(slot);
        if (!sameItemIdentity(item, stack)) continue;
        const take = Math.min(remaining, item.amount);
        remaining -= take;
        if (item.amount <= take) container.setItem(slot, undefined);
        else { item.amount -= take; container.setItem(slot, item); }
    }
    return remaining === 0;
}

function syncBlockState(block, machine) {
    try {
        const perm = block.permutation;
        let next = perm;
        const empty = !machine.items[BLANK_TM_SLOT];
        const dispensed = Boolean(machine.items[RESULT_SLOT]);
        const active = Boolean(machine.burnActive);

        if (perm.getState("lota:tm_empty") !== empty) next = next.withState("lota:tm_empty", empty);
        if (perm.getState("lota:tm_dispensed") !== dispensed) next = next.withState("lota:tm_dispensed", dispensed);
        if (perm.getState("lota:tm_active") !== active) next = next.withState("lota:tm_active", active);
        if (next !== perm) block.setPermutation(next);
    } catch (error) {}
}

function playSound(player, id, location) {
    try {
        if (player?.isValid) player.playSound(id, location ? { location } : undefined);
    } catch (error) {}
}

function actionBar(player, message) {
    try { player?.onScreenDisplay?.setActionBar(message); } catch (error) {}
}

function isCreativePlayer(player) {
    try { return String(player?.getGameMode?.() || "").toLowerCase() === "creative"; }
    catch (error) { return false; }
}

function playSoundAt(dimensionId, id, location) {
    try {
        world.getDimension(dimensionId).playSound(id, location, { volume: 1, pitch: 1 });
    } catch (error) {}
}

function burnRatio(machine) {
    if (!machine.burnProgress) return 0;
    return Math.max(0, Math.min(1, machine.burnProgress / BURN_TOTAL_TIME));
}

function postCraftTicks(machine) {
    return machine.burnProgress >= BURN_TOTAL_TIME ? machine.burnProgress - BURN_TOTAL_TIME : 0;
}

function advanceBurnProgress(machine) {
    if (machine.burnProgress < TOTAL_PROCESS_TIME) {
        const step = machine.burnProgress >= BURN_TOTAL_TIME ? 1 : BURN_PROGRESS_PER_TICK;
        machine.burnProgress += step * 2;
    }
    return postCraftTicks(machine);
}

function tmType(move) {
    const type = TM_MOVES[move]?.type;
    return TYPE_SET.has(type) ? type : "normal";
}

function moveName(move) {
    return String(MOVE_DATA[move]?.name || move);
}

function moveCategory(move) {
    const category = String(MOVE_DATA[move]?.category || "status");
    return ["physical", "special", "status"].includes(category) ? category : "status";
}

function speciesKey(pokemon) {
    return String(pokemon?.species || "unknown").replace(/^.*:/, "").toLowerCase();
}

function pokemonDisplayName(pokemon) {
    const nickname = String(pokemon?.nickname || "").trim();
    if (nickname) return nickname;
    return `cobblemon.species.${speciesKey(pokemon)}.name`;
}

function pokemonDex(pokemon) {
    try {
        const direct = Math.floor(Number(pokemon?.pokedex));
        if (Number.isInteger(direct) && direct > 0) return direct;
        const dex = Math.floor(Number(speciesData(speciesKey(pokemon))?.pokedex));
        return Number.isInteger(dex) && dex > 0 ? dex : 0;
    } catch (error) {
        return 0;
    }
}

function spriteSheetTexture(pokemon) {
    const dex = pokemonDex(pokemon);
    return dex ? `textures/gui/pc/pc_sprite/${String(dex).padStart(4, "0")}` : undefined;
}

function ppText(move) {
    const max = Math.max(0, Number(MOVE_DATA[move]?.pp) || 0);
    return `${max}/${max}`;
}

function caughtBallTexture(pokemon) {
    const ball = String(pokemon?.caughtBall || pokemon?.ball || "").trim();
    if (!ball) return undefined;
    return `textures/gui/ball/${ball.replace(/^.*:/, "").toLowerCase()}`;
}

function heldItemTexture(pokemon) {
    const held = pokemon?.heldItem;
    const id = String(typeof held === "string" ? held : held?.id || "").trim();
    if (!id) return undefined;
    return `textures/items/${id.replace(/^.*:/, "").toLowerCase()}`;
}

function genderTexture(pokemon) {
    const gender = String(pokemon?.gender || "").toUpperCase();
    if (!gender || gender === "GENDERLESS") return undefined;
    if (gender === "MALE" || gender === "M") return "textures/gui/pc/gender_icon_male";
    if (gender === "FEMALE" || gender === "F") return "textures/gui/pc/gender_icon_female";
    return undefined;
}

export const CAN_LEARN = 0;
export const CANNOT_LEARN = 1;
export const LEARNED = 2;

function allAccessibleMoves(pokemon) {
    const known = (Array.isArray(pokemon?.moves) ? pokemon.moves : [])
        .map(move => String(typeof move === "string" ? move : move?.id || "").toLowerCase());
    const benched = (Array.isArray(pokemon?.benchedMoves) ? pokemon.benchedMoves : [])
        .map(move => String(move).toLowerCase());
    return new Set([...known, ...benched].filter(Boolean));
}

export function canLearnTMMove(move, pokemon) {
    const moveId = String(move).toLowerCase();
    const accessible = allAccessibleMoves(pokemon);
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const levelMoves = speciesData(pokemon)?.levelMoves;
    if (Array.isArray(levelMoves) && levelMoves.some(entry => Number(entry?.level) <= level &&
        String(entry?.id || "").toLowerCase() === moveId)) return LEARNED;
    if (accessible.has(moveId)) return LEARNED;
    const formKey = pokemon?.aspects?.some(a => String(a).toLowerCase() === "alolan")
        ? `${speciesKey(pokemon)}-alolan` : speciesKey(pokemon);
    const learnable = TM_LEARNSETS[formKey] || TM_LEARNSETS[speciesKey(pokemon)];
    if (speciesKey(pokemon) === "sandshrew" && formKey.endsWith("-alolan")) {
        if (moveId === "icebeam") return CAN_LEARN;
        if (moveId === "stoneedge") return CANNOT_LEARN;
    }
    return Array.isArray(learnable) && learnable.includes(moveId) ? CAN_LEARN : CANNOT_LEARN;
}

function filterTms(session, player, learned = undefined) {
    const search = String(session.search || "").trim().toLowerCase();
    let list = Object.keys(TM_MOVES);
    if (session.sortType) list = list.filter(move => TM_MOVES[move].type === session.sortType);
    if (search) {
        list = list.filter(move =>
            moveName(move).toLowerCase().includes(search) || move.includes(search));
    }
    if (session.pokemon) {
        const learnable = TM_LEARNSETS[speciesKey(session.pokemon)] || [];
        const learnableSet = Array.isArray(learnable) ? new Set(learnable) : undefined;
        list = list.filter(move => learnableSet ? learnableSet.has(move) : learnable.includes(move));
    }
    const unlocked = learned || learnedTms(player);
    list = list.filter(move => {
        const obtain = TM_MOVES[move].obtain || [];
        return obtain.includes("default") || unlocked.has(move) || session.unlockAll;
    });
    if (!session.sortType && list.length > 1) {
        const sortKeys = new Map(list.map(move => [move, {
            type: TM_TYPES.indexOf(tmType(move)), name: moveName(move)
        }]));
        list.sort((a, b) => {
            const ka = sortKeys.get(a);
            const kb = sortKeys.get(b);
            return ka.type === kb.type ? ka.name.localeCompare(kb.name) : ka.type - kb.type;
        });
    }
    return list;
}

function learnedTms(player) {
    try {
        const raw = player.getDynamicProperty("lota:tm_learned");
        const list = raw ? JSON.parse(String(raw)) : [];
        return new Set(Array.isArray(list) ? list.map(String) : []);
    } catch (error) {
        return new Set();
    }
}

function saveLearnedTms(player, set) {
    try {
        player.setDynamicProperty("lota:tm_learned", JSON.stringify([...set]));
    } catch (error) {}
}

function syncLearnedFromParty(player, party = loadPartyFromPlayer(player)) {
    const learned = learnedTms(player);
    let changed = false;
    for (const pokemon of party) {
        if (!pokemon) continue;
        const moves = allAccessibleMoves(pokemon);
        const level = Math.max(1, Math.floor(Number(pokemon.level) || 1));
        const levelMoves = speciesData(pokemon)?.levelMoves;
        if (Array.isArray(levelMoves)) {
            for (const entry of levelMoves) {
                if (Number(entry?.level) <= level && entry?.id) moves.add(String(entry.id).toLowerCase());
            }
        }
        for (const move of moves) {
            if (TM_MOVES[move] && !learned.has(move)) {
                learned.add(move);
                changed = true;
            }
        }
    }
    if (changed) saveLearnedTms(player, learned);
    return learned;
}

function pokemonNameText(pokemon) {
    const nickname = String(pokemon?.nickname || "").trim();
    if (nickname) return nickname;
    const key = speciesKey(pokemon);
    return key.charAt(0).toUpperCase() + key.slice(1);
}

function tmItemFor(move) {
    const item = new ItemStack(`lota:tm_${tmType(move)}`, 1);
    try { item.setDynamicProperty(TM_MOVE_PROPERTY, move); } catch (error) {}
    try { item.setLore([moveName(move), `tm_move:${move}`]); } catch (error) {}
    return item;
}

function entryToStack(entry) {
    if (!entry) return undefined;
    if (String(entry.id).startsWith(TM_ITEM_PREFIX) && entry.move) {
        const stack = tmItemFor(entry.move);
        try { stack.amount = entry.amount; } catch (error) {}
        return stack;
    }
    try {
        return new ItemStack(entry.id, entry.amount);
    } catch (error) {
        return undefined;
    }
}

function isRoundTrippableItem(item) {
    if (!item) return false;
    try {
        if (item.nameTag) return false;
        if (item.getLore?.().length) return false;
        const enchantable = item.getComponent?.("minecraft:enchantable");
        if (enchantable?.getEnchantments?.().length) return false;
    } catch (error) {
        return false;
    }
    return true;
}

function entryTexture(entry) {
    if (!entry) return undefined;
    return itemTexturePath(entry.id);
}

function inventoryContainer(player) {
    try {
        return player.getComponent("minecraft:inventory")?.container;
    } catch (error) {
        return undefined;
    }
}

function countInInventory(player, id) {
    const container = inventoryContainer(player);
    if (!container) return 0;
    return countInContainer(container, id);
}

function countInContainer(container, id) {
    if (!container) return 0;
    let total = 0;
    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        if (item && item.typeId === id) total += item.amount;
    }
    return total;
}

function hasRoundTrippableItem(container, id, amount) {
    if (!container) return false;
    let available = 0;
    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        if (!item || item.typeId !== id || !isRoundTrippableItem(item)) continue;
        available += item.amount;
        if (available >= amount) return true;
    }
    return false;
}

function takeFromInventory(player, id, amount, predicate) {
    const container = inventoryContainer(player);
    if (!container) return false;
    return takeFromContainer(container, id, amount, predicate);
}

function takeFromContainer(container, id, amount, predicate) {
    const requested = Math.max(0, Math.floor(Number(amount) || 0));
    if (requested === 0) return true;

    let available = 0;
    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        if (item && item.typeId === id && (!predicate || predicate(item))) available += item.amount;
    }
    if (available < requested) return false;

    let remaining = requested;
    for (let slot = 0; slot < container.size && remaining > 0; slot++) {
        const item = container.getItem(slot);
        if (!item || item.typeId !== id || (predicate && !predicate(item))) continue;
        const take = Math.min(remaining, item.amount);
        remaining -= take;
        if (item.amount - take <= 0) {
            container.setItem(slot, undefined);
        } else {
            item.amount -= take;
            container.setItem(slot, item);
        }
    }
    return remaining === 0;
}

function giveToInventory(player, stack) {
    if (!stack) return false;
    const container = inventoryContainer(player);
    if (!container) return false;
    try {
        player.__tmLastDelivered = [];
        const requestedAmount = stack.amount;
        const remainder = container.addItem(stack);
        if (!remainder || remainder.amount <= 0) return true;

        try {
            const spawned = player.dimension.spawnItem(remainder, player.location);
            if (spawned) player.__tmLastDelivered.push(spawned);
            return true;
        } catch (spawnError) {
            const accepted = Math.max(0, requestedAmount - remainder.amount);
            removeFromInventoryStack(player, stack, accepted);
            return false;
        }
    } catch (error) {
        return false;
    }
}

function rollbackDelivered(player) {
    for (const entity of player?.__tmLastDelivered || []) {
        try { entity.remove?.(); } catch (error) {}
    }
    if (player) player.__tmLastDelivered = [];
}

function recipeFor(move) {
    const recipe = TM_MOVES[move]?.recipe;
    return Array.isArray(recipe) ? recipe.slice(0, 3) : [];
}

function ingredientSatisfied(machine, move) {
    const recipe = recipeFor(move);
    for (let i = 0; i < recipe.length; i++) {
        const entry = machine.items[INGREDIENT_SLOTS[i]];
        if (!entry) return false;
        if (!recipe[i].items.includes(entry.id)) return false;
        if (entry.amount < recipe[i].count) return false;
    }
    return true;
}

function canCraft(machine) {
    const move = machine.activeMove;
    if (!TM_MOVES[move]) return false;
    const output = machine.items[RESULT_SLOT];
    if (output) {
        if (output.id !== `lota:tm_${tmType(move)}` || output.move !== move) return false;
        if (output.amount >= 16) return false;
    }
    if (!machine.items[BLANK_TM_SLOT] || machine.items[BLANK_TM_SLOT].id !== BLANK_TM_ITEM) return false;
    return ingredientSatisfied(machine, move);
}

function stopBurnIfInvalid(block, machine) {
    return false;
}

function craftTM(block, machine) {
    const move = machine.activeMove;
    if (!canCraft(machine)) return;
    const blank = machine.items[BLANK_TM_SLOT];
    blank.amount -= 1;
    if (blank.amount <= 0) machine.items[BLANK_TM_SLOT] = null;

    const recipe = recipeFor(move);
    for (let i = 0; i < recipe.length; i++) {
        const entry = machine.items[INGREDIENT_SLOTS[i]];
        if (!entry) continue;
        entry.amount -= recipe[i].count;
        if (entry.amount <= 0) machine.items[INGREDIENT_SLOTS[i]] = null;
    }

    const output = machine.items[RESULT_SLOT];
    if (output) output.amount += 1;
    else machine.items[RESULT_SLOT] = { id: `lota:tm_${tmType(move)}`, amount: 1, move };
}

function tickMachines() {
    if (activeMachines.size === 0) return;
    for (const [key, position] of [...activeMachines.entries()]) {
        let block;
        try {
            block = world.getDimension(position.dimensionId).getBlock(position);
        } catch (error) {
            activeMachines.delete(key);
            burnLoopAt.delete(key);
            continue;
        }
        if (!block || block.typeId !== BLOCK_ID) {
            activeMachines.delete(key);
            burnLoopAt.delete(key);
            continue;
        }
        const machine = loadMachine(block);
        if (!machine.burnActive) {
            let powered = false;
            try { powered = Number(block.getRedstonePower?.() || 0) > 0; } catch (error) {}
            if (powered && canCraft(machine)) {
                machine.burnActive = true;
                machine.burnProgress = 0;
                activeMachines.set(key, position);
                saveMachine(block, machine);
                syncBlockState(block, machine);
                refreshViewers(key);
            } else {
                syncBlockState(block, machine);
            }
            continue;
        }

        const loopDue = system.currentTick - (burnLoopAt.get(key) || -BURN_LOOP_TICKS);
        if (loopDue >= BURN_LOOP_TICKS) {
            burnLoopAt.set(key, system.currentTick);
            playSoundAt(position.dimensionId, "cobblemon.tm_machine.burn_loop", {
                x: position.x + 0.5, y: position.y + 0.5, z: position.z + 0.5
            });
        }

        const post = advanceBurnProgress(machine);
        if (post > 0) {
            if (post >= CRAFT_TICKS && post < CRAFT_TICKS + 2) {
                craftTM(block, machine);
                playSoundAt(position.dimensionId, "cobblemon.tm_machine.craft", {
                    x: position.x + 0.5, y: position.y + 0.5, z: position.z + 0.5
                });
            }
            if (post >= CRAFT_TICKS + RESET_DISC_TICKS) {
                machine.burnProgress = 0;
                let powered = false;
                try { powered = Number(block.getRedstonePower?.() || 0) > 0; } catch (error) {}
                const keepRunning = powered && canCraft(machine);
                machine.burnActive = keepRunning;
                if (keepRunning) activeMachines.set(key, position);
                else { activeMachines.delete(key); burnLoopAt.delete(key); }
                refreshViewers(key);
            }
        }

        saveMachine(block, machine);
        syncBlockState(block, machine);
    }
}

function refreshViewers(machineKeyValue) {
    for (const session of sessions.values()) {
        if (!session.block) continue;
        const key = `lota:tm:${session.block.dimensionId}:${session.block.x}` +
                    `:${session.block.y}:${session.block.z}`;
        if (key !== machineKeyValue) continue;
        repaintTM(uiPlayer(session.playerId), session);
    }
}

function buildTitle(session, machine) {
    let title = TM_TITLE_ROOT;
    title += session.mode === MODE_TYPE ? "#TYSEL" : (session.mode === MODE_MOVE ? "#MVSEL" : "#BURN");
    if (session.mode === MODE_MOVE && session.sortType) title += "#SORTED";
    if (session.mode === MODE_BURN) {
        const spinning = machine.burnActive && burnRatio(machine) < 1;
        title += spinning ? "#ROT" : "#NRM";
    }
    if (session.screenSaver) title += "#SAVER";
    return title;
}

function titleTextFor(session) {
    if (session.mode === MODE_MOVE) {
        if (session.pokemon) return pokemonDisplayName(session.pokemon);
        if (session.sortType) return `cobblemon.type.${session.sortType}`;
        return "cobblemon.ui.moves";
    }
    return "block.cobblemon.tm_machine";
}

function slotButtonText(entry) {
    if (!entry || entry.amount <= 1) return "";
    return String(entry.amount);
}

function uiPlayer(playerId) {
    if (!playerId) return undefined;
    try {
        if (typeof world.getEntity === "function") {
            const found = world.getEntity(playerId);
            if (found) return found;
        }
    } catch (error) {}
    return world.getAllPlayers().find(p => p.id === playerId);
}

function sameBlock(a, b) {
    return Boolean(a && b) && a.x === b.x && a.y === b.y && a.z === b.z
        && a.dimensionId === b.dimension.id;
}

function scheduleShow(player, session) {
    if (session.busy) { session.queued = true; return; }
    system.run(() => {
        if (sessions.get(player.id) !== session) return;
        if (!player.isValid) return closeSession(player, session);
        showTM(player, session);
    });
}

function repaintTM(player, session) {
    if (!player?.isValid) return;
    if (sessions.get(player.id) !== session) return;
    if (session.chest) return showTM(player, session);
    if (!session.formOpen) return;
    session.repainting = true;
    try {
        uiManager.closeAllForms(player);
    } catch (error) {
        session.repainting = false;
    }
}

function reopenTM(player, session) {
    session.busy = true;
    try { uiManager.closeAllForms(player); } catch (error) {}
    system.run(() => {
        if (sessions.get(player.id) !== session) { session.busy = false; return; }
        session.busy = false;
        if (!player.isValid) return closeSession(player, session);
        showTM(player, session);
    });
}

function showTM(player, session) {
    if (!player?.isValid) return;
    if (sessions.get(player.id) !== session) return;
    if (session.formOpen || session.busy) { session.queued = true; return; }

    const block = session.block
        ? world.getDimension(session.block.dimensionId).getBlock(session.block)
        : undefined;
    if (!block || block.typeId !== BLOCK_ID) return closeSession(player, session);

    const machine = loadMachine(block);
    const party = loadPartyFromPlayer(player);
    const learned = syncLearnedFromParty(player, party);
    const tms = filterTms(session, player, learned);

    const renderToken = ++session.renderToken;
    const screenTitle = buildTitle(session, machine);
    const form = new TmViewRecorder();
    const heldMove = heldTmMove(player);

    for (let i = 0; i < 6; i++) {
        const pokemon = party[i] || null;
        let art = "textures/gui/tmmachine/party_slot";
        if (!pokemon) {
            art = "textures/gui/tmmachine/party_slot_disabled";
        } else {
            const teachable = heldMove ? canLearnTMMove(heldMove, pokemon) : null;
            if (teachable === CAN_LEARN) {
                art = session.mode === MODE_TYPE || heldMove
                    ? "textures/gui/tmmachine/party_slot_learnable"
                    : "textures/gui/tmmachine/party_slot_learnable_disabled";
            } else if (teachable === CANNOT_LEARN) {
                art = "textures/gui/tmmachine/party_slot_disabled";
            } else if (teachable === LEARNED) {
                art = "textures/gui/tmmachine/party_slot_learned";
            }
        }
        form.button(" ", art);
    }

    for (let cell = 0; cell < TYPE_CELLS; cell++) {
        if (cell >= TYPE_ENTRIES.length) { form.button(" "); continue; }
        const entry = TYPE_ENTRIES[cell];
        form.button(" ", entry
            ? `textures/gui/tmmachine/type_icon_${entry}`
            : "textures/gui/tmmachine/type_icon_all");
    }

    for (let row = 0; row < MOVE_ROWS_TOTAL; row++) {
        const move = tms[row];
        if (!move) { form.button(" "); continue; }
        const disabled = Boolean(heldMove) && heldMove !== move;
        const art = disabled
            ? `textures/gui/tmmachine/move_disabled_${tmType(move)}`
            : `textures/gui/tmmachine/move_${tmType(move)}`;
        const selected = machine.activeMove === move ? "|SEL" : "";
        form.button(`cobblemon.move.${move}${selected}`, art);
    }

    form.button(" ", "textures/gui/tmmachine/icon_back");
    const disabled = !machine.burnActive && !canCraft(machine);
    const startArt = disabled
        ? "textures/gui/tmmachine/start_disabled"
        : (machine.burnActive ? "textures/gui/tmmachine/start_stop"
                              : "textures/gui/tmmachine/start_normal");
    form.button(" ", startArt);
    form.button(session.search || "cobblemon.ui.pokedex.search",
                "textures/gui/tmmachine/icon_search");
    form.button(" ", machine.activeMove
        ? `textures/gui/tmmachine/move_${tmType(machine.activeMove)}`
        : undefined);

    for (let i = 0; i < MACHINE_SLOT_COUNT; i++) {
        const entry = machine.items[i];
        form.button(slotButtonText(entry), entryTexture(entry));
    }

    const container = inventoryContainer(player);
    for (let i = 0; i < 36; i++) {
        const item = container?.getItem(i);
        form.button(item ? String(item.amount) : " ",
                    item ? itemTexturePath(item.typeId) : undefined);
    }

    form.button(titleTextFor(session));

    const move = machine.activeMove;
    const stats = move ? MOVE_DATA[move] : undefined;
    const power = move && Number(stats?.power) > 0
        ? String(Math.floor(Number(stats.power))) : "\u2014";
    const accuracy = move ? `${Math.round(Number(stats?.accuracy) || 0)}%` : "\u2014";
    const effectChance = Number(stats?.secondaries?.[0]?.chance);
    const effect = move ? `${Math.round(Number.isFinite(effectChance) ? effectChance : 0)}%`
                        : "\u2014";
    form.button(power);
    form.button(accuracy);
    form.button(effect);

    const description = String(stats?.description || "");
    const lines = wrapText(description, session.chest ? DESC_WIDTH_CHEST : DESC_WIDTH_FORM, DESC_LINES);
    for (let i = 0; i < DESC_LINES; i++) form.button(lines[i] || " ");

    const recipe = recipeFor(move);
    for (let i = 0; i < RECIPE_SLOTS; i++) {
        const entry = recipe[i];
        form.button(" ", entry ? itemTexturePath(entry.items[0]) : undefined);
    }

    const discType = move ? tmType(move) : "normal";
    form.button(" ", `textures/gui/tmmachine/disc_${discType}`);
    form.button(String(Math.max(1, Math.min(PROGRESS_STEPS,
        Math.ceil(burnRatio(machine) * PROGRESS_STEPS)))));

    for (let row = 0; row < MOVE_ROWS_TOTAL; row++) {
        const rowMove = tms[row];
        form.button(" ", rowMove ? `textures/gui/tmmachine/type_icon_${tmType(rowMove)}` : undefined);
    }
    for (let row = 0; row < MOVE_ROWS_TOTAL; row++) {
        const rowMove = tms[row];
        form.button(" ", rowMove ? `textures/gui/tmmachine/category_${moveCategory(rowMove)}` : undefined);
    }
    for (let row = 0; row < MOVE_ROWS_TOTAL; row++) {
        const rowMove = tms[row];
        form.button(rowMove ? ppText(rowMove) : " ");
    }

    form.button(" ", move ? `textures/gui/tmmachine/move_${tmType(move)}` : undefined);
    form.button(" ", move ? `textures/gui/tmmachine/type_icon_${tmType(move)}` : undefined);
    form.button(" ", move ? `textures/gui/tmmachine/category_${moveCategory(move)}` : undefined);
    form.button(move ? `cobblemon.move.${move}` : " ");
    form.button(move ? ppText(move) : " ");

    for (let i = 0; i < 6; i++) {
        const pokemon = party[i] || null;
        if (!pokemon) {
            for (let c = 0; c < 7; c++) form.button(" ");
            continue;
        }
        const teachable = heldMove ? canLearnTMMove(heldMove, pokemon) : null;
        form.button(" ", spriteSheetTexture(pokemon));
        form.button(`Lv.${Math.max(1, Math.floor(Number(pokemon.level) || 1))}`);
        form.button(pokemonDisplayName(pokemon));
        form.button(teachable === CAN_LEARN ? "cobblemon.ui.tm_machine.can_learn"
            : teachable === CANNOT_LEARN ? "cobblemon.ui.tm_machine.cannot_learn"
            : teachable === LEARNED ? "cobblemon.ui.tm_machine.learned" : " ");
        form.button(" ", caughtBallTexture(pokemon));
        form.button(" ", heldItemTexture(pokemon));
        form.button(" ", genderTexture(pokemon));
    }

    form.button(" ", `textures/gui/tmmachine/disc_spin_${discType}`);

    if (session.chest) {
        session.view = form.toChestView(screenTitle);
        sessions.set(player.id, session);
        if (!session.pressing) refreshChestScreen(player, TM_CHEST_KEY);
        return;
    }
    const actionForm = form.toActionForm(screenTitle);

    session.formOpen = true;
    session.busy = true;
    sessions.set(player.id, session);

    const replayQueued = () => {
        if (!session.queued) return;
        session.queued = false;
        if (sessions.get(session.playerId) !== session) return;
        const target = uiPlayer(session.playerId);
        if (target) scheduleShow(target, session);
    };

    actionForm.show(player).then(response => {
        if (sessions.get(player.id) !== session) return;
        if (renderToken !== session.renderToken) {
            session.formOpen = false;
            session.busy = false;
            return replayQueued();
        }
        session.formOpen = false;
        session.busy = false;
        if (session.repainting) {
            session.repainting = false;
            return scheduleShow(player, session);
        }
        if (response.canceled) {
            closeSession(player, session);
            return;
        }
        const selection = Math.floor(Number(response.selection));
        handleSelection(player, session, selection);
        replayQueued();
    }).catch(error => {
        if (sessions.get(player.id) !== session) return;
        session.repainting = false;
        if (renderToken !== session.renderToken) { session.busy = false; return replayQueued(); }
        session.formOpen = false;
        session.busy = false;
        console.warn(`TM machine form failed: ${error}`);
        closeSession(player, session);
        replayQueued();
    });
}

function wrapText(text, width, maxLines) {
    const words = String(text || "").split(/\s+/).filter(Boolean);
    const lines = [];
    let current = "";
    for (const word of words) {
        if (!current) { current = word; continue; }
        if (current.length + 1 + word.length <= width) current += ` ${word}`;
        else { lines.push(current); current = word; }
        if (lines.length >= maxLines) break;
    }
    if (current && lines.length < maxLines) lines.push(current);
    return lines;
}

function heldTmMove(player) {
    const container = inventoryContainer(player);
    if (!container) return undefined;
    const slot = Math.max(0, Math.floor(Number(player.selectedSlotIndex) || 0));
    const item = container.getItem(slot);
    if (!item || !String(item.typeId).startsWith(TM_ITEM_PREFIX)) return undefined;
    return tmMoveFromStack(item);
}

function handleSelection(player, session, selection) {
    session.openedAt = system.currentTick;
    if (session.screenSaver) session.screenSaver = false;
    if (!Number.isFinite(selection) || selection < 0 || selection >= BUTTON_COUNT) {
        return showTM(player, session);
    }
    const block = session.block
        ? world.getDimension(session.block.dimensionId).getBlock(session.block)
        : undefined;
    if (!block || block.typeId !== BLOCK_ID) return closeSession(player, session);
    const machine = loadMachine(block);
    const party = loadPartyFromPlayer(player);

    if (selection >= IDX_PARTY && selection < IDX_PARTY + 6) {
        return handlePartyClick(player, session, block, machine, party, selection - IDX_PARTY);
    }

    if (selection >= IDX_TYPE && selection < IDX_TYPE + TYPE_CELLS) {
        const entry = TYPE_ENTRIES[selection - IDX_TYPE];
        if (entry === undefined) return showTM(player, session);
        session.sortType = entry;
        session.pokemon = null;
        session.mode = MODE_MOVE;
        playSound(player, "random.click");
        return showTM(player, session);
    }

    if (selection >= IDX_MOVE && selection < IDX_MOVE + MOVE_ROWS_TOTAL) {
        const tms = filterTms(session, player);
        const move = tms[selection - IDX_MOVE];
        if (!move) return showTM(player, session);
        const heldMove = heldTmMove(player);
        if (heldMove && heldMove !== move) return showTM(player, session);
        machine.activeMove = move;
        machine.burnProgress = 0;
        machine.burnActive = false;
        saveMachine(block, machine);
        syncBlockState(block, machine);
        session.mode = MODE_BURN;
        playSound(player, "random.click");
        return showTM(player, session);
    }

    if (selection === IDX_BACK) {
        if (session.mode === MODE_BURN) {
            session.mode = MODE_MOVE;
            return showTM(player, session);
        }
        session.mode = MODE_TYPE;
        session.sortType = null;
        session.pokemon = null;
        return showTM(player, session);
    }
    if (selection === IDX_START) {
        session.mode = MODE_BURN;
        if (machine.activeMove && (machine.burnActive || canCraft(machine))) {
            machine.burnActive = !machine.burnActive;
            if (machine.burnActive) {
                if (machine.burnProgress >= TOTAL_PROCESS_TIME) machine.burnProgress = 0;
                activeMachines.set(machineKey(block), {
                    dimensionId: block.dimension.id, x: block.x, y: block.y, z: block.z
                });
                playSound(player, "cobblemon.tm_machine.start");
            }
            saveMachine(block, machine);
            syncBlockState(block, machine);
        }
        return showTM(player, session);
    }
    if (selection === IDX_SEARCH) return showSearch(player, session);
    if (selection === IDX_SELMOVE) {
        session.mode = MODE_MOVE;
        return showTM(player, session);
    }

    if (selection >= IDX_MACHINE && selection < IDX_MACHINE + MACHINE_SLOT_COUNT) {
        session.mode = machine.activeMove ? MODE_BURN : MODE_TYPE;
        return handleMachineSlot(player, session, block, machine,
                                 selection - IDX_MACHINE);
    }

    if (selection >= IDX_INVENTORY && selection < IDX_INVENTORY + 36) {
        session.mode = machine.activeMove ? MODE_BURN : MODE_TYPE;
        return handleInventorySlot(player, session, block, machine,
                                   selection - IDX_INVENTORY);
    }

    return showTM(player, session);
}

function handlePartyClick(player, session, block, machine, party, index) {
    const pokemon = party[index];
    if (!pokemon) return showTM(player, session);

    if (heldTmMove(player)) {
        teachMoveWithHeldDisc(player, pokemon);
        return showTM(player, session);
    }

    if (session.mode !== MODE_BURN) {
        session.pokemon = pokemon;
        session.sortType = null;
        session.mode = MODE_MOVE;
        playSound(player, "random.click");
    }
    return showTM(player, session);
}

export function teachMove(player, pokemon, move) {
    const party = loadPartyFromPlayer(player);
    const slot = party.findIndex(entry => entry && String(entry.uuid) === String(pokemon?.uuid));
    if (slot < 0) return false;

    const target = party[slot];
    const moves = Array.isArray(target.moves) ? target.moves.slice() : [];
    if (moves.length < 4) {
        const pp = Number(MOVE_DATA[move]?.pp) || 0;
        moves.push({ id: move, pp, maxPp: pp });
    } else {
        const benched = Array.isArray(target.benchedMoves) ? target.benchedMoves.slice() : [];
        if (!benched.includes(move)) benched.push(move);
        target.benchedMoves = benched;
    }
    target.moves = moves;
    party[slot] = target;
    if (!savePartyToPlayer(player, party)) return false;

    const learned = learnedTms(player);
    if (TM_MOVES[move]) { learned.add(move); saveLearnedTms(player, learned); }

    consumeHeldTm(player, move);

    actionBar(player, {
        translate: "cobblemon.tms.teach_move",
        with: [pokemonNameText(target), moveName(move)]
    });
    playSound(player, "cobblemon.tm_machine.craft");
    return true;
}

function consumeHeldTm(player, move) {
    if (isCreativePlayer(player)) return;
    try {
        const container = inventoryContainer(player);
        const held = Math.max(0, Math.floor(Number(player.selectedSlotIndex) || 0));
        const item = container?.getItem(held);
        if (!item || !String(item.typeId).startsWith(TM_ITEM_PREFIX)) return;
        const heldMove = tmMoveFromStack(item);
        if (heldMove && heldMove !== move) return;
        if (item.amount <= 1) container.setItem(held, undefined);
        else { item.amount -= 1; container.setItem(held, item); }
    } catch (error) {}
}

export function teachMoveWithHeldDisc(player, pokemon) {
    const move = heldTmMove(player);
    if (!move) return false;
    const result = canLearnTMMove(move, pokemon);
    if (result === LEARNED) {
        actionBar(player, {
            translate: "cobblemon.tms.already_known",
            with: [pokemonNameText(pokemon), moveName(move)]
        });
        return false;
    }
    if (result !== CAN_LEARN) {
        actionBar(player, {
            translate: "cobblemon.tms.cannot_learn",
            with: [pokemonNameText(pokemon), moveName(move)]
        });
        return false;
    }
    return teachMove(player, pokemon, move);
}

function handleMachineSlot(player, session, block, machine, index) {
    const entry = machine.items[index];

    if (index === RESULT_SLOT) {
        if (entry) {
            const stack = entryToStack(entry);
            if (stack && giveToInventory(player, stack)) {
                machine.items[index] = null;
                if (!saveMachine(block, machine)) {
                    machine.items[index] = entry;
                    removeFromInventoryStack(player, stack, stack.amount);
                    rollbackDelivered(player);
                }
                syncBlockState(block, machine);
                playSound(player, "cobblemon.tm_machine.tm_retrieve");
            }
        }
        return showTM(player, session);
    }

    if (index === BLANK_TM_SLOT) {
        const before = entry ? { ...entry } : null;
        let movedOut;
        let movedIn;
        if (entry) {
            const stack = entryToStack(entry);
            if (stack && giveToInventory(player, stack)) {
                machine.items[index] = null;
                movedOut = stack;
                playSound(player, "cobblemon.tm_machine.tm_retrieve");
            }
        } else if (hasRoundTrippableItem(inventoryContainer(player), BLANK_TM_ITEM, 1)
                   && takeFromInventory(player, BLANK_TM_ITEM, 1, isRoundTrippableItem)) {
            machine.items[index] = { id: BLANK_TM_ITEM, amount: 1 };
            movedIn = { id: BLANK_TM_ITEM, amount: 1 };
            playSound(player, "cobblemon.tm_machine.tm_insert");
        }
        stopBurnIfInvalid(block, machine);
        if (!saveMachine(block, machine)) {
            machine.items[index] = before;
            if (movedOut) removeFromInventoryStack(player, movedOut, movedOut.amount);
            if (movedIn) giveToInventory(player, new ItemStack(BLANK_TM_ITEM, 1));
        }
        syncBlockState(block, machine);
        return showTM(player, session);
    }

    const recipe = recipeFor(machine.activeMove);
    const recipeEntry = recipe[index - INGREDIENT_SLOTS[0]];
    const beforeIngredient = entry ? { ...entry } : null;
    let movedIngredientOut;
    let movedIngredientIn;
    if (entry) {
        const stack = entryToStack(entry);
        if (stack && giveToInventory(player, stack)) {
            machine.items[index] = null;
            movedIngredientOut = stack;
            playSound(player, "cobblemon.tm_machine.item_retrieve");
        }
    } else if (recipeEntry) {
        const wanted = recipeEntry.count;
        const inventory = inventoryContainer(player);
        const available = recipeEntry.items.find(id =>
            hasRoundTrippableItem(inventory, id, wanted));
        if (available && takeFromInventory(player, available, wanted, isRoundTrippableItem)) {
            machine.items[index] = { id: available, amount: wanted };
            movedIngredientIn = { id: available, amount: wanted };
            playSound(player, "cobblemon.tm_machine.item_insert");
        }
    }
    stopBurnIfInvalid(block, machine);
    if (!saveMachine(block, machine)) {
        machine.items[index] = beforeIngredient;
        if (movedIngredientOut) removeFromInventoryStack(player, movedIngredientOut, movedIngredientOut.amount);
        if (movedIngredientIn) giveToInventory(player, new ItemStack(movedIngredientIn.id, movedIngredientIn.amount));
    }
    syncBlockState(block, machine);
    return showTM(player, session);
}

function handleInventorySlot(player, session, block, machine, slot) {
    const container = inventoryContainer(player);
    const item = container?.getItem(slot);
    if (!item) return showTM(player, session);
    const id = String(item.typeId);

    const machineBefore = machine.items.map(entry => entry ? { ...entry } : null);
    let inventoryBefore;
    try {
        inventoryBefore = typeof item.clone === "function"
            ? item.clone()
            : { ...item };
    } catch (error) {
        inventoryBefore = { ...item };
    }

    if (!isRoundTrippableItem(item)) return showTM(player, session);
    if (id === BLANK_TM_ITEM && !machine.items[BLANK_TM_SLOT]) {
        machine.items[BLANK_TM_SLOT] = { id, amount: 1 };
        consumeInventorySlot(container, slot, 1);
        playSound(player, "cobblemon.tm_machine.tm_insert");
    } else {
        const recipe = recipeFor(machine.activeMove);
        for (let i = 0; i < recipe.length; i++) {
            const target = INGREDIENT_SLOTS[i];
            if (machine.items[target]) continue;
            if (!recipe[i].items.includes(id)) continue;
            const wanted = Math.min(recipe[i].count, item.amount);
            if (wanted < recipe[i].count) break;
            machine.items[target] = { id, amount: wanted };
            consumeInventorySlot(container, slot, wanted);
            playSound(player, "cobblemon.tm_machine.item_insert");
            break;
        }
    }

    stopBurnIfInvalid(block, machine);
    if (!saveMachine(block, machine)) {
        machine.items = machineBefore;
        try { container.setItem(slot, inventoryBefore); } catch (error) {}
    }
    syncBlockState(block, machine);
    return showTM(player, session);
}

function consumeInventorySlot(container, slot, amount) {
    try {
        const item = container.getItem(slot);
        if (!item) return;
        if (item.amount - amount <= 0) container.setItem(slot, undefined);
        else { item.amount -= amount; container.setItem(slot, item); }
    } catch (error) {}
}

function showSearch(player, session) {
    if (sessions.get(player.id) !== session) return;
    if (!player?.isValid) return;
    if (session.chest) {
        session.chest = false;
        if (chestScreenActive(player, TM_CHEST_KEY)) closeChestScreen(player);
        session.mode = MODE_MOVE;
        session.returnToChest = true;
        system.runTimeout(() => {
            if (sessions.get(player.id) !== session || !player.isValid) return;
            showSearch(player, session);
        }, 8);
        return;
    }
    session.mode = MODE_MOVE;
    session.renderToken++;
    session.busy = true;
    session.queued = false;
    const form = new ModalFormData().title("cobblemon.ui.pokedex.search");
    try {
        form.textField("cobblemon.ui.pokedex.search", "cobblemon.ui.pokedex.search",
                       { defaultValue: session.search || "" });
    } catch (error) {
        form.textField("Search", "Search", { defaultValue: session.search || "" });
    }
    form.show(player).then(response => {
        session.busy = false;
        if (sessions.get(player.id) !== session) return;
        if (!response.canceled && Array.isArray(response.formValues)) {
            session.search = String(response.formValues[0] || "");
        }
        return backToScreen(player, session);
    }).catch(() => {
        session.busy = false;
        backToScreen(player, session);
    });
}

function tmChestMenuOn(player) {
    try { return !player.hasTag(MENU_FORM_TAG); } catch (error) { return true; }
}

function startTmChest(player, session) {
    if (!tmChestMenuOn(player)) return false;
    session.chest = true;
    session.formOpen = false;
    session.busy = false;
    session.queued = false;
    session.view = undefined;
    session.chestSince = system.currentTick;
    session.baseline = undefined;
    sessions.set(player.id, session);
    showTM(player, session);
    if (!session.view || !openChestScreen(player, TM_CHEST_KEY, { hold: 1200, state: { session } })) {
        session.chest = false;
        return false;
    }
    return true;
}

function backToScreen(player, session) {
    if (sessions.get(player.id) !== session) return;
    if (session.returnToChest) {
        session.returnToChest = false;
        if (startTmChest(player, session)) return;
    }
    scheduleShow(player, session);
}

registerChestScreen({
    key: TM_CHEST_KEY,
    anchor: "lota:ui_anchor_xl",
    layout: Object.freeze({
        title: TM_CHEST_TITLE,
        n: TM_CHEST_SLOT_COUNT,
        tex: [], vis: [], txt: [], ml: [],
        cap: TM_CHEST_CAP,
        st: [TM_CHEST_STATE_SLOT],
        tb: TM_CHEST_TB,
        btn: TM_CHEST_BTN,
        ic: TM_CHEST_IC
    }),
    wants: () => false,
    create: player => ({ session: sessions.get(player.id) || null }),
    view: (player, state) => state?.session?.view
        ?? { title: "", buttons: [], icons: {} },
    press: (player, state, button) => {
        const session = state?.session;
        if (!session || sessions.get(player.id) !== session || !session.chest) return "close";
        session.pressing = true;
        try { handleSelection(player, session, button); }
        finally { session.pressing = false; }
        return sessions.get(player.id) === session && session.chest ? "redraw" : "close";
    }
});

function newSession(block) {
    return {
        playerId: undefined,
        block: { dimensionId: block.dimension.id, x: block.x, y: block.y, z: block.z },
        mode: MODE_TYPE,
        sortType: null,
        pokemon: null,
        search: "",
        screenSaver: false,
        unlockAll: false,
        formOpen: false,
        busy: false,
        queued: false,
        repainting: false,
        renderToken: 0
    };
}

function setLid(position, open, player) {
    try {
        const block = world.getDimension(position.dimensionId).getBlock(position);
        if (!block || block.typeId !== BLOCK_ID) return;
        if (block.permutation.getState("lota:tm_open") === open) return;
        block.setPermutation(block.permutation.withState("lota:tm_open", open));
        playSound(player, open ? "cobblemon.tm_machine.open" : "cobblemon.tm_machine.close");
    } catch (error) {}
}

function releaseLid(session, player) {
    if (!session?.block) return;
    for (const other of sessions.values()) {
        const a = other.block, b = session.block;
        if (other !== session && a && a.x === b.x && a.y === b.y && a.z === b.z
            && a.dimensionId === b.dimensionId) return;
    }
    setLid(session.block, false, player);
}

function closeSession(player, session) {
    if (sessions.get(player.id) === session) {
        sessions.delete(player.id);
        if (session.chest) {
            session.chest = false;
            try { if (chestScreenActive(player, TM_CHEST_KEY)) closeChestScreen(player); } catch (error) {}
        }
        releaseLid(session, player);
    }
}

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const block = event.block;
    if (!block || block.typeId !== BLOCK_ID) return;
    const player = event.player;
    if (!player) return;

    const sneaking = Boolean(player.isSneaking);

    if (sneaking) {
        event.cancel = true;
        system.run(() => {
            try {
                const current = block.permutation.getState("lota:tm_open");
                block.setPermutation(block.permutation.withState("lota:tm_open", !current));
                playSound(player, current ? "cobblemon.tm_machine.close" : "cobblemon.tm_machine.open");
            } catch (error) {}
        });
        return;
    }

    event.cancel = true;
    system.run(() => {
        const existing = sessions.get(player.id);
        if (existing && sameBlock(existing.block, block)
            && (existing.formOpen || existing.busy)) {
            return scheduleShow(player, existing);
        }
        if (existing?.chest && sameBlock(existing.block, block)
            && chestScreenActive(player, TM_CHEST_KEY)) {
            return showTM(player, existing);
        }

        const machine = loadMachine(block);
        const session = existing && sameBlock(existing.block, block) ? existing : newSession(block);
        session.playerId = player.id;
        session.mode = machine.activeMove ? MODE_BURN : MODE_TYPE;
        session.sortType = machine.activeMove ? tmType(machine.activeMove) : null;
        session.search = "";
        session.pokemon = null;
        session.screenSaver = false;
        session.busy = false;
        session.queued = false;
        session.repainting = false;
        activeMachines.set(machineKey(block), {
            dimensionId: block.dimension.id, x: block.x, y: block.y, z: block.z
        });
        session.openedAt = system.currentTick;
        syncBlockState(block, machine);
        sessions.set(player.id, session);
        setLid(session.block, true, player);
        session.chest = false;
        session.returnToChest = false;
        if (!startTmChest(player, session)) {
            session.chest = false;
            reopenTM(player, session);
        }
    });
});

function dropAndClearMachine(block) {
    const key = machineKey(block);
    const machine = loadMachine(block);
    activeMachines.delete(key);
    burnLoopAt.delete(key);
    try {
        for (const entry of machine.items) {
            const stack = entryToStack(entry);
            if (stack) block.dimension.spawnItem(stack, {
                x: block.x + 0.5, y: block.y + 0.5, z: block.z + 0.5
            });
        }
        world.setDynamicProperty(key, undefined);
    } catch (error) {
        console.warn(`TM machine drop failed: ${error}`);
    }
}

world.beforeEvents.playerBreakBlock.subscribe(event => {
    if (event.block?.typeId !== BLOCK_ID) return;
    const block = event.block;
    system.run(() => {
        for (const [playerId, session] of [...sessions]) {
            const at = session.block;
            if (at && at.x === block.x && at.y === block.y && at.z === block.z
                && at.dimensionId === block.dimension.id) {
                const who = uiPlayer(playerId);
                closeSession(who?.isValid ? who : { id: playerId }, session);
            }
        }
        try { dropAndClearMachine(block); } catch (error) {}
    });
});

system.runInterval(() => {
    for (const session of sessions.values()) {
        if (!session.chest && !session.formOpen && !session.busy) continue;
        if (!session.openedAt) { session.openedAt = system.currentTick; continue; }
        const idle = system.currentTick - session.openedAt > SCREEN_SAVER_TICKS;
        if (idle === session.screenSaver) continue;
        session.screenSaver = idle;
        const player = uiPlayer(session.playerId);
        if (player) scheduleShow(player, session);
    }
}, 40);

system.runInterval(tickMachines, 2);

const CLOSE_GRACE_TICKS = 20;
const CLOSE_MOVE_BLOCKS = 0.3;
const CLOSE_TURN_DEGREES = 4;

function angleDelta(a, b) {
    let d = Math.abs(a - b) % 360;
    return d > 180 ? 360 - d : d;
}

function playerLeftScreen(player, session) {
    let location, rotation;
    try { location = player.location; rotation = player.getRotation(); } catch (error) { return false; }
    const now = system.currentTick;
    if (!session.baseline || now - (session.chestSince || 0) < CLOSE_GRACE_TICKS) {
        session.baseline = { x: location.x, y: location.y, z: location.z, yaw: rotation.y, pitch: rotation.x };
        return false;
    }
    const base = session.baseline;
    const moved = Math.hypot(location.x - base.x, location.y - base.y, location.z - base.z);
    const turned = Math.max(angleDelta(rotation.y, base.yaw), angleDelta(rotation.x, base.pitch));
    return moved > CLOSE_MOVE_BLOCKS || turned > CLOSE_TURN_DEGREES;
}

system.runInterval(() => {
    for (const [playerId, session] of [...sessions]) {
        if (!session.chest) continue;
        const player = uiPlayer(playerId);
        const handle = player?.isValid ? player : { id: playerId };
        if (!player?.isValid || !chestScreenActive(player, TM_CHEST_KEY)) {
            closeSession(handle, session);
            continue;
        }
        let blockGone = false;
        try {
            const at = world.getDimension(session.block.dimensionId).getBlock(session.block);
            blockGone = !at || at.typeId !== BLOCK_ID;
        } catch (error) {}
        if (blockGone || playerLeftScreen(player, session)) closeSession(handle, session);
    }
}, 5);

world.afterEvents.playerLeave.subscribe(event => {
    const session = sessions.get(event.playerId);
    sessions.delete(event.playerId);
    if (session) releaseLid(session);
});

export const __tmMachineTest = Object.freeze({
    countInContainer,
    takeFromContainer,
    giveToInventory,
    saveMachine,
    tmMoveFromStack,
    isRoundTrippableItem,
    normalizeItem,
    recipeFor,
    canCraft,
    craftTM,
    canLearnTMMove,
    teachMove,
    teachMoveWithHeldDisc,
    heldTmMove,
    CAN_LEARN,
    CANNOT_LEARN,
    LEARNED,
    burnRatio,
    postCraftTicks,
    advanceBurnProgress
});
