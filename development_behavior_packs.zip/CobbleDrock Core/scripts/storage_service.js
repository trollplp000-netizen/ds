import {
    loadPartyFromPlayer,
    savePartyToPlayer,
    loadPCFromPlayer,
    savePCToPlayer,
    PC_BOX_SIZE,
    PC_BOX_COUNT,
    generateUUID
} from "./storage.js";
import { MAX_PARTY_SIZE } from "./storage_consts.js";

export { MAX_PARTY_SIZE };
export const STORAGE_VERSION = 2;
export const STORAGE_VERSION_PROPERTY = "lota:storage_version";
export const STARTER_CHOSEN_PROPERTY = "lota:starter_chosen";
export const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";
export const STORAGE_BACKUP_PROPERTY = "lota:storage_backup_v1";

export const STORE_RESULT = Object.freeze({
    PARTY_FULL: "PARTY_FULL",
    PC_FULL: "PC_FULL",
    INVALID_SLOT: "INVALID_SLOT",
    DUPLICATE_ID: "DUPLICATE_ID",
    SAVE_FAILED: "SAVE_FAILED",
    LOCKED: "LOCKED",
    INVALID_POKEMON: "INVALID_POKEMON"
});

function safeId(player) {
    try { return player?.name ?? String(player?.id ?? "unknown"); } catch (error) { return "unknown"; }
}

export function logStorage(operation, details = {}) {
    try {
        const parts = [`[Storage] Operation=${operation}`];
        for (const [key, value] of Object.entries(details)) parts.push(`${key}=${value}`);
        console.log(parts.join(" "));
    } catch (error) {}
}

export function logStorageIssue(code, details = {}) {
    try {
        const parts = [`[StorageValidator] ${code}`];
        for (const [key, value] of Object.entries(details)) parts.push(`${key}=${value}`);
        console.warn(parts.join(" "));
    } catch (error) {}
}

export function pokemonUuid(entry) {
    return String(entry?.uuid || "");
}

export function isValidPokemonEntry(entry) {
    return !!entry
        && typeof entry === "object"
        && typeof entry.uuid === "string"
        && entry.uuid.length > 0
        && typeof entry.species === "string"
        && entry.species.length > 0;
}

export function isValidPartySlot(slot, partyLength) {
    return Number.isInteger(slot) && slot >= 0 && slot < Math.min(partyLength, MAX_PARTY_SIZE);
}

export function isValidPCSlot(box, slot) {
    return Number.isInteger(box) && Number.isInteger(slot)
        && box >= 0 && box < PC_BOX_COUNT
        && slot >= 0 && slot < PC_BOX_SIZE;
}

function cloneContainer(value) {
    return JSON.parse(JSON.stringify(value ?? []));
}

const playerLocks = new Set();

function lockKey(player, key) {
    return `${player?.id ?? "unknown"}:${key}`;
}

export function isPlayerLocked(player, key) {
    return playerLocks.has(lockKey(player, key));
}

export function withPlayerLock(player, key, fn) {
    const lock = lockKey(player, key);
    if (playerLocks.has(lock)) {
        return { success: false, reason: STORE_RESULT.LOCKED };
    }
    playerLocks.add(lock);
    try {
        return fn();
    } finally {
        playerLocks.delete(lock);
    }
}

export function findFirstEmptyPCSlot(player, preloadedBoxes = undefined) {
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const box = Array.isArray(preloadedBoxes?.[boxIndex])
            ? preloadedBoxes[boxIndex]
            : loadPCFromPlayer(player, boxIndex);
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            if (!box[slot]) return { box: boxIndex, slot };
        }
    }
    return null;
}

export function collectIdLocations(player, preloaded = {}) {
    const locations = new Map();
    const party = Array.isArray(preloaded.party) ? preloaded.party : loadPartyFromPlayer(player);
    party.forEach((entry, slot) => {
        const uuid = pokemonUuid(entry);
        if (!uuid) return;
        if (!locations.has(uuid)) locations.set(uuid, []);
        locations.get(uuid).push({ area: "party", slot });
    });
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const box = Array.isArray(preloaded.boxes?.[boxIndex])
            ? preloaded.boxes[boxIndex]
            : loadPCFromPlayer(player, boxIndex);
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            const uuid = pokemonUuid(box[slot]);
            if (!uuid) continue;
            if (!locations.has(uuid)) locations.set(uuid, []);
            locations.get(uuid).push({ area: "pc", box: boxIndex, slot });
        }
    }
    return locations;
}

export function storePokemon(player, pokemon, currentParty = undefined) {
    if (!isValidPokemonEntry(pokemon) && !pokemonUuid(pokemon)) {
        return { success: false, reason: STORE_RESULT.INVALID_POKEMON };
    }
    if (!pokemon.uuid) {
        try { pokemon.uuid = generateUUID(); } catch (error) {}
    }
    if (!pokemonUuid(pokemon)) {
        return { success: false, reason: STORE_RESULT.INVALID_POKEMON };
    }

    const locations = collectIdLocations(player);
    if (locations.has(pokemon.uuid)) {
        logStorageIssue("duplicatePokemonId", {
            Player: safeId(player),
            PokemonId: pokemon.uuid,
            locations: locations.get(pokemon.uuid).map(where => where.area === "party" ? `PARTY:${where.slot}` : `PC:${where.box}:${where.slot}`).join(",")
        });
        return { success: false, reason: STORE_RESULT.DUPLICATE_ID };
    }

    const party = Array.isArray(currentParty) ? currentParty : loadPartyFromPlayer(player);
    if (party.length < MAX_PARTY_SIZE) {
        party.push(pokemon);
        if (savePartyToPlayer(player, party)) {
            const slot = party.length - 1;
            logStorage("STORE", { Player: safeId(player), PokemonId: pokemon.uuid, To: `PARTY:${slot}`, Result: "SUCCESS" });
            return { success: true, location: "PARTY", slot };
        }
        party.pop();
        logStorage("STORE", { Player: safeId(player), PokemonId: pokemon.uuid, To: "PARTY", Result: "SAVE_FAILED, trying PC" });
    }

    const target = findFirstEmptyPCSlot(player);
    if (!target) {
        logStorage("STORE", { Player: safeId(player), PokemonId: pokemon.uuid, Result: "PC_FULL" });
        return { success: false, reason: STORE_RESULT.PC_FULL };
    }
    const box = loadPCFromPlayer(player, target.box);
    if (box[target.slot]) {
        const retry = findFirstEmptyPCSlot(player);
        if (!retry) return { success: false, reason: STORE_RESULT.PC_FULL };
        return storePokemonAt(player, pokemon, retry.box, retry.slot);
    }
    return storePokemonAt(player, pokemon, target.box, target.slot);
}

export function storePokemonInPC(player, pokemon) {
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const box = loadPCFromPlayer(player, boxIndex);
        let slot = -1;
        for (let candidate = 0; candidate < PC_BOX_SIZE; candidate++) {
            if (!box[candidate]) {
                slot = candidate;
                break;
            }
        }
        if (slot < 0) continue;
        box[slot] = pokemon;
        if (!savePCToPlayer(player, boxIndex, box)) continue;
        logStorage("STORE", { Player: safeId(player), PokemonId: pokemonUuid(pokemon), To: `PC:${boxIndex}:${slot}`, Result: "SUCCESS" });
        return { success: true, box: boxIndex, slot };
    }
    logStorage("STORE", { Player: safeId(player), PokemonId: pokemonUuid(pokemon), Result: "PC_FULL_OR_UNWRITABLE" });
    return { success: false, reason: STORE_RESULT.PC_FULL };
}

function storePokemonAt(player, pokemon, box, slot) {
    const targetBox = loadPCFromPlayer(player, box);
    if (targetBox[slot]) return { success: false, reason: STORE_RESULT.INVALID_SLOT };
    targetBox[slot] = pokemon;
    if (!savePCToPlayer(player, box, targetBox)) {
        return { success: false, reason: STORE_RESULT.SAVE_FAILED };
    }
    logStorage("STORE", { Player: safeId(player), PokemonId: pokemon.uuid, To: `PC:${box}:${slot}`, Result: "SUCCESS" });
    return { success: true, location: "PC", box, slot };
}

export function commitStores(player, writes) {
    const saved = [];
    for (let index = 0; index < writes.length; index++) {
        const write = writes[index];
        const ok = write.kind === "party"
            ? savePartyToPlayer(player, write.data)
            : savePCToPlayer(player, write.box, write.data);
        if (!ok) {
            let rolledBack = true;
            for (let done = saved.length - 1; done >= 0; done--) {
                const prev = saved[done];
                const restoreOk = prev.kind === "party"
                    ? savePartyToPlayer(player, prev.prev)
                    : savePCToPlayer(player, prev.box, prev.prev);
                if (!restoreOk) rolledBack = false;
            }
            logStorage("COMMIT", {
                Player: safeId(player),
                Writes: writes.length,
                FailedAt: index,
                RolledBack: rolledBack,
                Result: "SAVE_FAILED"
            });
            return { ok: false, reason: STORE_RESULT.SAVE_FAILED, rolledBack };
        }
        saved.push(write);
    }
    return { ok: true };
}

export function commitPartyAndBox(player, party, boxIndex, box, prevParty, prevBox) {
    return commitStores(player, [
        { kind: "party", data: party, prev: prevParty },
        { kind: "pc", box: boxIndex, data: box, prev: prevBox }
    ]);
}

export function commitTwoBoxes(player, boxA, dataA, prevA, boxB, dataB, prevB) {
    return commitStores(player, [
        { kind: "pc", box: boxA, data: dataA, prev: prevA },
        { kind: "pc", box: boxB, data: dataB, prev: prevB }
    ]);
}

function describeLocation(where) {
    return where.area === "party" ? `PARTY:${where.slot}` : `PC:${where.box}:${where.slot}`;
}

export function movePartyToPC(player, partySlot, destBox, destSlot) {
    return withPlayerLock(player, "move", () => {
        const party = loadPartyFromPlayer(player);
        if (!isValidPartySlot(partySlot, party.length)) {
            return { success: false, reason: STORE_RESULT.INVALID_SLOT };
        }
        if (!isValidPCSlot(destBox, destSlot)) {
            return { success: false, reason: STORE_RESULT.INVALID_SLOT };
        }
        const moving = party[partySlot];
        if (!isValidPokemonEntry(moving)) {
            return { success: false, reason: STORE_RESULT.INVALID_POKEMON };
        }
        const box = loadPCFromPlayer(player, destBox);
        const displaced = box[destSlot] || null;
        const prevParty = cloneContainer(party);
        const prevBox = cloneContainer(box);
        if (displaced) {
            party[partySlot] = displaced;
        } else {
            party.splice(partySlot, 1);
        }
        box[destSlot] = moving;
        const commit = commitPartyAndBox(player, party, destBox, box, prevParty, prevBox);
        if (!commit.ok) {
            return { success: false, reason: commit.reason, rolledBack: commit.rolledBack };
        }
        clampSelectedSlot(player, party);
        logStorage("MOVE", {
            Player: safeId(player),
            PokemonId: moving.uuid,
            From: `PARTY:${partySlot}`,
            To: `PC:${destBox}:${destSlot}`,
            Result: "SUCCESS"
        });
        return { success: true, moved: moving, displaced };
    });
}

export function movePCToParty(player, srcBox, srcSlot, partySlot = undefined) {
    return withPlayerLock(player, "move", () => {
        if (!isValidPCSlot(srcBox, srcSlot)) {
            return { success: false, reason: STORE_RESULT.INVALID_SLOT };
        }
        const party = loadPartyFromPlayer(player);
        const box = loadPCFromPlayer(player, srcBox);
        const moving = box[srcSlot];
        if (!isValidPokemonEntry(moving)) {
            return { success: false, reason: STORE_RESULT.INVALID_POKEMON };
        }
        if (partySlot === undefined) {
            if (party.length >= MAX_PARTY_SIZE) {
                return { success: false, reason: STORE_RESULT.PARTY_FULL };
            }
            const prevParty = cloneContainer(party);
            const prevBox = cloneContainer(box);
            party.push(moving);
            box[srcSlot] = null;
            const commit = commitPartyAndBox(player, party, srcBox, box, prevParty, prevBox);
            if (!commit.ok) {
                return { success: false, reason: commit.reason, rolledBack: commit.rolledBack };
            }
            clampSelectedSlot(player, party);
            logStorage("MOVE", {
                Player: safeId(player),
                PokemonId: moving.uuid,
                From: `PC:${srcBox}:${srcSlot}`,
                To: `PARTY:${party.length - 1}`,
                Result: "SUCCESS"
            });
            return { success: true, moved: moving, slot: party.length - 1 };
        }
        if (!isValidPartySlot(partySlot, Math.max(party.length, 1)) && partySlot !== party.length) {
            return { success: false, reason: STORE_RESULT.INVALID_SLOT };
        }
        const prevParty = cloneContainer(party);
        const prevBox = cloneContainer(box);
        const displaced = party[partySlot] || null;
        party[partySlot] = moving;
        box[srcSlot] = displaced;
        const commit = commitPartyAndBox(player, party, srcBox, box, prevParty, prevBox);
        if (!commit.ok) {
            return { success: false, reason: commit.reason, rolledBack: commit.rolledBack };
        }
        clampSelectedSlot(player, party);
        logStorage("MOVE", {
            Player: safeId(player),
            PokemonId: moving.uuid,
            From: `PC:${srcBox}:${srcSlot}`,
            To: `PARTY:${partySlot}`,
            Result: "SUCCESS"
        });
        return { success: true, moved: moving, displaced };
    });
}

export function movePCToPC(player, srcBox, srcSlot, destBox, destSlot) {
    return withPlayerLock(player, "move", () => {
        if (!isValidPCSlot(srcBox, srcSlot) || !isValidPCSlot(destBox, destSlot)) {
            return { success: false, reason: STORE_RESULT.INVALID_SLOT };
        }
        if (srcBox === destBox && srcSlot === destSlot) {
            return { success: true, moved: null, noop: true };
        }
        const sourceBox = loadPCFromPlayer(player, srcBox);
        const dest = srcBox === destBox ? sourceBox : loadPCFromPlayer(player, destBox);
        const moving = sourceBox[srcSlot];
        if (!isValidPokemonEntry(moving)) {
            return { success: false, reason: STORE_RESULT.INVALID_POKEMON };
        }
        const prevSource = cloneContainer(sourceBox);
        const prevDest = srcBox === destBox ? prevSource : cloneContainer(dest);
        const displaced = dest[destSlot] || null;
        sourceBox[srcSlot] = displaced;
        dest[destSlot] = moving;
        let commit;
        if (srcBox === destBox) {
            commit = savePCToPlayer(player, srcBox, sourceBox)
                ? { ok: true }
                : { ok: false, reason: STORE_RESULT.SAVE_FAILED, rolledBack: savePCToPlayer(player, srcBox, prevSource) };
        } else {
            commit = commitTwoBoxes(player, srcBox, sourceBox, prevSource, destBox, dest, prevDest);
        }
        if (!commit.ok) {
            return { success: false, reason: commit.reason, rolledBack: commit.rolledBack };
        }
        logStorage("MOVE", {
            Player: safeId(player),
            PokemonId: moving.uuid,
            From: `PC:${srcBox}:${srcSlot}`,
            To: `PC:${destBox}:${destSlot}`,
            Result: "SUCCESS"
        });
        return { success: true, moved: moving, displaced };
    });
}

export function clampSelectedSlot(player, party) {
    try {
        if (!party.length) {
            player.setDynamicProperty(SELECTED_SLOT_PROPERTY, 0);
            return;
        }
        const current = Math.floor(Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY)) || 0);
        if (!Number.isInteger(current) || current < 0 || current >= party.length) {
            player.setDynamicProperty(SELECTED_SLOT_PROPERTY, Math.max(0, party.length - 1));
        }
    } catch (error) {}
}

export function isPokemonInParty(player, pokemonUuid, preloadedParty = undefined) {
    const uuid = String(pokemonUuid || "");
    if (!uuid) return false;
    const party = Array.isArray(preloadedParty) ? preloadedParty : loadPartyFromPlayer(player);
    return party.some(entry => String(entry?.uuid || "") === uuid);
}

export function validateSummonTarget(player, pokemonUuid) {
    if (!pokemonUuid) return { ok: false, reason: STORE_RESULT.INVALID_POKEMON };
    const party = loadPartyFromPlayer(player);
    const entry = party.find(item => String(item?.uuid || "") === String(pokemonUuid));
    if (!entry) return { ok: false, reason: "NOT_IN_PARTY" };
    if (!isValidPokemonEntry(entry)) return { ok: false, reason: STORE_RESULT.INVALID_POKEMON };
    return { ok: true, pokemon: entry };
}

export function validatePlayerStorage(player) {
    const issues = [];
    let party;
    try {
        party = loadPartyFromPlayer(player);
    } catch (error) {
        issues.push({ code: "PARTY_UNREADABLE", detail: String(error) });
        party = [];
    }
    if (!Array.isArray(party)) {
        issues.push({ code: "PARTY_INVALID_SHAPE" });
        party = [];
    }
    if (party.length > MAX_PARTY_SIZE) {
        issues.push({ code: "PARTY_OVERFLOW", size: party.length });
        logStorageIssue("PartySize", { Player: safeId(player), PartySize: party.length });
    }
    const boxes = [];
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        let box;
        try {
            box = loadPCFromPlayer(player, boxIndex);
        } catch (error) {
            issues.push({ code: "PC_BOX_UNREADABLE", box: boxIndex, detail: String(error) });
            box = null;
        }
        if (!Array.isArray(box) || box.length !== PC_BOX_SIZE) {
            issues.push({ code: "PC_BOX_INVALID_SHAPE", box: boxIndex });
            box = Array.isArray(box) ? box : [];
        }
        boxes.push(box);
    }

    const seen = new Map();
    const record = (uuid, where) => {
        if (!seen.has(uuid)) seen.set(uuid, []);
        seen.get(uuid).push(where);
    };
    party.forEach((entry, slot) => {
        if (!entry) {
            issues.push({ code: "PARTY_NULL_HOLE", slot });
            return;
        }
        if (!isValidPokemonEntry(entry)) {
            issues.push({ code: "PARTY_INVALID_ENTRY", slot });
            return;
        }
        record(entry.uuid, { area: "party", slot });
    });
    boxes.forEach((box, boxIndex) => {
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            const entry = box[slot];
            if (!entry) continue;
            if (!isValidPokemonEntry(entry)) {
                issues.push({ code: "PC_INVALID_ENTRY", box: boxIndex, slot });
                continue;
            }
            record(entry.uuid, { area: "pc", box: boxIndex, slot });
        }
    });
    for (const [uuid, where] of seen) {
        if (where.length > 1) {
            issues.push({ code: "DUPLICATE_ID", uuid, locations: where });
            logStorageIssue("duplicatePokemonId", {
                Player: safeId(player),
                duplicatePokemonId: uuid,
                locations: where.map(describeLocation).join(",")
            });
        }
    }
    const partyIds = new Set(party.filter(isValidPokemonEntry).map(entry => entry.uuid));
    boxes.forEach((box, boxIndex) => {
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            const entry = box[slot];
            if (isValidPokemonEntry(entry) && partyIds.has(entry.uuid)) {
                issues.push({ code: "PARTY_PC_OVERLAP", uuid: entry.uuid, box: boxIndex, slot });
            }
        }
    });
    return { ok: issues.length === 0, issues, party, boxes };
}

export function quarantineEntry(player, entry, reason) {
    try {
        const key = "lota:pc_quarantine";
        let list = [];
        try {
            const raw = player.getDynamicProperty(key);
            if (raw) list = JSON.parse(String(raw));
        } catch (error) { list = []; }
        if (!Array.isArray(list)) list = [];
        list.push({ reason, at: Date.now(), entry });
        while (list.length > 1) {
            try {
                player.setDynamicProperty(key, JSON.stringify(list));
                return true;
            } catch (error) {
                list.shift();
            }
        }
        try {
            player.setDynamicProperty(key, JSON.stringify(list));
            return true;
        } catch (error) {
            return false;
        }
    } catch (error) {
        return false;
    }
}

export function repairPlayerStorage(player, report = undefined) {
    const result = report || validatePlayerStorage(player);
    const actions = [];
    let party = Array.isArray(result.party) ? result.party.slice() : loadPartyFromPlayer(player);
    const boxes = Array.isArray(result.boxes)
        ? result.boxes.map(box => (Array.isArray(box) ? box.slice() : []))
        : [];

    const compacted = [];
    party.forEach((entry, slot) => {
        if (!entry) {
            actions.push({ action: "PARTY_HOLE_COMPACTED", slot });
            return;
        }
        if (!isValidPokemonEntry(entry)) {
            quarantineEntry(player, entry, "PARTY_INVALID_ENTRY");
            actions.push({ action: "PARTY_INVALID_QUARANTINED", slot });
            return;
        }
        compacted.push(entry);
    });
    party = compacted;

    if (party.length > MAX_PARTY_SIZE) {
        const keep = party.slice(0, MAX_PARTY_SIZE);
        const overflow = party.slice(MAX_PARTY_SIZE);
        const moved = [];
        const leftover = [];
        for (const entry of overflow) {
            const target = findFirstEmptyPCSlotIn(boxes);
            if (!target) {
                leftover.push(entry);
                continue;
            }
            ensureBoxShape(boxes, target.box);
            boxes[target.box][target.slot] = entry;
            moved.push({ uuid: entry.uuid, to: `PC:${target.box}:${target.slot}` });
        }
        party = keep.concat(leftover);
        actions.push({ action: "PARTY_OVERFLOW_REPAIRED", kept: keep.length, movedToPC: moved.length, leftover: leftover.length, moved });
        logStorage("REPAIR", { Player: safeId(player), Action: "PARTY_OVERFLOW", Kept: keep.length, MovedToPC: moved.length, Leftover: leftover.length });
    }

    const keptIds = new Set();
    const dedupedParty = [];
    for (const entry of party) {
        if (keptIds.has(entry.uuid)) {
            quarantineEntry(player, entry, "PARTY_DUP_ID");
            actions.push({ action: "PARTY_DUP_QUARANTINED", uuid: entry.uuid });
            continue;
        }
        keptIds.add(entry.uuid);
        dedupedParty.push(entry);
    }
    party = dedupedParty;
    for (let boxIndex = 0; boxIndex < boxes.length; boxIndex++) {
        ensureBoxShape(boxes, boxIndex);
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            const entry = boxes[boxIndex][slot];
            if (!entry) continue;
            if (!isValidPokemonEntry(entry)) {
                quarantineEntry(player, entry, "PC_INVALID_ENTRY");
                boxes[boxIndex][slot] = null;
                actions.push({ action: "PC_INVALID_QUARANTINED", box: boxIndex, slot });
                continue;
            }
            if (keptIds.has(entry.uuid)) {
                boxes[boxIndex][slot] = null;
                actions.push({ action: "PC_DUP_REFERENCE_REMOVED", uuid: entry.uuid, box: boxIndex, slot });
                continue;
            }
            keptIds.add(entry.uuid);
        }
    }

    const origParty = Array.isArray(result.party) ? result.party : [];
    const origBoxes = Array.isArray(result.boxes) ? result.boxes : [];
    const writes = [];
    if (JSON.stringify(party) !== JSON.stringify(origParty)) {
        writes.push({ kind: "party", data: party, prev: loadPartyFromPlayer(player) });
    }
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        ensureBoxShape(boxes, boxIndex);
        const before = Array.isArray(origBoxes[boxIndex]) ? origBoxes[boxIndex] : [];
        if (JSON.stringify(boxes[boxIndex]) !== JSON.stringify(before)) {
            writes.push({ kind: "pc", box: boxIndex, data: boxes[boxIndex], prev: loadPCFromPlayer(player, boxIndex) });
        }
    }
    const commit = commitStores(player, writes);
    if (!commit.ok) {
        logStorage("REPAIR", { Player: safeId(player), Result: "SAVE_FAILED", RolledBack: commit.rolledBack });
        return { repaired: false, actions, reason: commit.reason, rolledBack: commit.rolledBack };
    }
    clampSelectedSlot(player, party);
    logStorage("REPAIR", { Player: safeId(player), Actions: actions.length, Result: "SUCCESS" });
    return { repaired: true, actions };
}

function ensureBoxShape(boxes, boxIndex) {
    if (!Array.isArray(boxes[boxIndex])) boxes[boxIndex] = [];
    while (boxes[boxIndex].length < PC_BOX_SIZE) boxes[boxIndex].push(null);
    if (boxes[boxIndex].length > PC_BOX_SIZE) boxes[boxIndex].length = PC_BOX_SIZE;
}

function findFirstEmptyPCSlotIn(boxes) {
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const box = boxes[boxIndex] || [];
        for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
            if (!box[slot]) return { box: boxIndex, slot };
        }
    }
    return null;
}

export function getStorageVersion(player) {
    try {
        const raw = player.getDynamicProperty(STORAGE_VERSION_PROPERTY);
        const version = Math.floor(Number(raw) || 0);
        return Number.isFinite(version) ? version : 0;
    } catch (error) {
        return 0;
    }
}

function backupPreMigration(player) {
    try {
        const backup = { at: Date.now(), party: null, boxes: {} };
        try { backup.party = JSON.parse(String(player.getDynamicProperty("lota:party_data") || "[]")); }
        catch (error) { backup.party = "<unreadable>"; }
        for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
            try {
                const raw = player.getDynamicProperty(`lota:pc_box_${boxIndex}`);
                if (raw) backup.boxes[boxIndex] = JSON.parse(String(raw));
            } catch (error) { backup.boxes[boxIndex] = "<unreadable>"; }
        }
        try {
            player.setDynamicProperty(STORAGE_BACKUP_PROPERTY, JSON.stringify(backup));
        } catch (sizeError) {
            const summary = { at: backup.at, partial: true, boxes: {} };
            for (const [boxIndex, content] of Object.entries(backup.boxes)) {
                summary.boxes[boxIndex] = Array.isArray(content)
                    ? content.map(entry => (entry && entry.uuid) || null)
                    : content;
            }
            player.setDynamicProperty(STORAGE_BACKUP_PROPERTY, JSON.stringify(summary));
        }
        return true;
    } catch (error) {
        logStorage("BACKUP", { Player: safeId(player), Result: `SKIPPED (${error})` });
        return false;
    }
}

function hasChosenStarterFlag(player) {
    try {
        const value = player.getDynamicProperty(STARTER_CHOSEN_PROPERTY);
        return value === true || String(value || "").toLowerCase() === "true";
    } catch (error) {
        return false;
    }
}

function playerHasAnyValidPokemon(player, validation) {
    if (validation?.party?.some(isValidPokemonEntry)) return true;
    for (const box of validation?.boxes || []) {
        if (Array.isArray(box) && box.some(isValidPokemonEntry)) return true;
    }
    return false;
}

export function migrateLegacyStarterState(player, validation) {
    if (getStorageVersion(player) >= STORAGE_VERSION) return { migrated: false, reason: "CURRENT" };
    backupPreMigration(player);
    let migrated = false;
    if (!hasChosenStarterFlag(player) && playerHasAnyValidPokemon(player, validation)) {
        try {
            player.setDynamicProperty(STARTER_CHOSEN_PROPERTY, true);
            migrated = true;
            logStorage("MIGRATE", { Player: safeId(player), StarterFlag: "false->true (legacy pokemon present)" });
        } catch (error) {
            logStorage("MIGRATE", { Player: safeId(player), Result: `FLAG_FAILED (${error})` });
        }
    }
    try {
        player.setDynamicProperty(STORAGE_VERSION_PROPERTY, STORAGE_VERSION);
    } catch (error) {}
    return { migrated, reason: migrated ? "LEGACY_POKEMON_PRESENT" : "NO_LEGACY_POKEMON" };
}

export function runPlayerStorageMaintenance(player) {
    const startedAt = Date.now();
    try {
        if (!player?.isValid) return { ran: false, reason: "INVALID_PLAYER" };
        const validation = validatePlayerStorage(player);
        const migration = migrateLegacyStarterState(player, validation);
        let repair = { repaired: true, actions: [] };
        if (!validation.ok) {
            repair = repairPlayerStorage(player, validation);
        }
        try {
            if (getStorageVersion(player) < STORAGE_VERSION) {
                player.setDynamicProperty(STORAGE_VERSION_PROPERTY, STORAGE_VERSION);
            }
        } catch (error) {}
        logStorage("MAINTENANCE", {
            Player: safeId(player),
            Issues: validation.issues.length,
            Migrated: migration.migrated,
            RepairActions: repair.actions?.length ?? 0,
            Repaired: repair.repaired,
            Ms: Date.now() - startedAt
        });
        return { ran: true, issues: validation.issues, migration, repair };
    } catch (error) {
        console.error(`[Storage] Maintenance failed: ${error}`);
        return { ran: false, reason: String(error) };
    }
}
