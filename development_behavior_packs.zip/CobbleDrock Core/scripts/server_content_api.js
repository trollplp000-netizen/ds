import { ScriptEventSource, system, world } from "@minecraft/server";
import { startTrainerBattle } from "./battle_system.js";
import { calculateMaxHp, normalizePokemonForBattle, speciesData, speciesKey } from "./battle_math.js";
import { moveData } from "./move_registry.js";
import { clearHudTitleTransient, setHudTitleTransient } from "./hud_title_bridge.js";
import {
    generateRandomPokemon,
    addPokemonToPlayerParty,
    loadPartyFromPlayer,
    savePartyToPlayer,
    savePokemonToEntity
} from "./storage.js";
import { itemEvolutionOptions, queueItemEvolution } from "./evolution.js";
import { recallPartyPokemon } from "./pokemon_compass.js";
import { TRADE_EVOLUTION_ITEM } from "./conditional_evolution_data.js";
import {
    clearNaturalSpawnsInZone,
    removeNaturalSpawnZone,
    upsertNaturalSpawnZone
} from "./natural_spawn_zones.js";
import { setExternalLevelCap } from "./level_cap.js";
import { applyWildPokemonNameTags } from "./pokemon_nametag_display.js";

export const CONTENT_API_VERSION = 1;
export const TRAINER_REQUEST_EVENT = "lota:server_trainer_battle_request_v1";
export const TRAINER_RESULT_EVENT = "lota:server_trainer_battle_result_v1";
export const HUD_REQUEST_EVENT = "lota:server_hud_transient_v1";
export const NATURAL_SPAWN_ZONE_EVENT = "lota:server_natural_spawn_zone_v1";
export const POKEMON_SPAWN_API_VERSION = 2;
export const POKEMON_SPAWN_REQUEST_EVENT = "lota:server_pokemon_spawn_request_v2";
export const POKEMON_SPAWN_RESULT_EVENT = "lota:server_pokemon_spawn_result_v2";
export const TRADE_API_VERSION = 2;
export const TRADE_REQUEST_EVENT = "lota:server_pokemon_trade_request_v2";
export const TRADE_RESULT_EVENT = "lota:server_pokemon_trade_result_v2";
export const POKEMON_GRANT_API_VERSION = 1;
export const POKEMON_GRANT_REQUEST_EVENT = "lota:server_pokemon_grant_request_v1";
export const POKEMON_GRANT_RESULT_EVENT = "lota:server_pokemon_grant_result_v1";
export const PARTY_HEAL_API_VERSION = 1;
export const PARTY_HEAL_REQUEST_EVENT = "lota:server_party_heal_request_v1";
export const PARTY_HEAL_RESULT_EVENT = "lota:server_party_heal_result_v1";
export const LEVEL_CAP_SYNC_EVENT = "lota:server_level_cap_sync_v1";

const MAX_TRAINER_PARTY_SIZE = 6;
const MAX_TRAINER_REQUEST_CHUNKS = 32;
const MAX_TRAINER_REQUEST_CHUNK_LENGTH = 1200;
const MAX_TRAINER_REQUEST_LENGTH = MAX_TRAINER_REQUEST_CHUNKS * MAX_TRAINER_REQUEST_CHUNK_LENGTH;
const TRAINER_REQUEST_TTL_TICKS = 200;
const MAX_HUD_KEY_LENGTH = 64;
const MAX_HUD_TOKEN_LENGTH = 256;
const pendingTrainerRequests = new Map();
const recentPokemonSpawnRequests = new Map();
const POKEMON_SPAWN_REQUEST_TTL_TICKS = 400;
const MAX_POKEMON_SPAWN_DISTANCE = 96;
const POKEMON_DUPLICATE_RADIUS = 64;
const MAX_TRADE_DISTANCE = 12;
const recentTradeRequests = new Map();
const TRADE_REQUEST_TTL_TICKS = 400;
const recentPokemonGrantRequests = new Map();
const POKEMON_GRANT_REQUEST_TTL_TICKS = 400;
const recentPartyHealRequests = new Map();

function parseMessage(message) {
    try {
        const value = JSON.parse(String(message || "{}"));
        return value && typeof value === "object" ? value : undefined;
    } catch (error) {
        return undefined;
    }
}

function playerById(playerId) {
    const id = String(playerId || "");
    if (!id) return undefined;
    return world.getAllPlayers().find(player => String(player.id) === id);
}

function finiteLocation(value) {
    if (!value || typeof value !== "object") return undefined;
    const location = {
        x: Number(value.x),
        y: Number(value.y),
        z: Number(value.z)
    };
    return Object.values(location).every(Number.isFinite) ? location : undefined;
}

function cleanText(value, fallback, maximumLength = 80) {
    const text = String(value || "").trim();
    return (text || fallback).slice(0, maximumLength);
}

function fixedTrainerPokemon(source, trainerName) {
    const species = cleanText(source?.species, "").replace(/^lota:/, "").toLowerCase();
    const data = speciesData(species);
    if (!data) throw new Error(`Unknown trainer species '${species || "empty"}'.`);

    const level = Math.max(1, Math.min(100, Math.floor(Number(source?.level) || 1)));
    const pokemon = generateRandomPokemon(`lota:${species}`, level);
    pokemon.nickname = data.name || species;
    pokemon.gender = cleanText(source?.gender, pokemon.gender || "GENDERLESS", 16);
    pokemon.nature = cleanText(source?.nature, pokemon.nature || "hardy", 32);
    pokemon.mintedNature = pokemon.nature;
    pokemon.ability = cleanText(source?.ability, pokemon.ability || "", 64);
    pokemon.ivs = { ...(source?.ivs || {}) };
    pokemon.evs = { ...(source?.evs || {}) };
    pokemon.isShiny = source?.isShiny === true;
    pokemon.aspects = Array.isArray(source?.aspects)
        ? source.aspects.map(value => cleanText(value, "", 32)).filter(Boolean).slice(0, 12)
        : [pokemon.isShiny ? "shiny" : "normal", String(pokemon.gender).toLowerCase()];
    pokemon.heldItem = cleanText(source?.heldItem || source?.heldItems?.[0], "", 64);
    pokemon.moves = (Array.isArray(source?.moves) ? source.moves : [])
        .map(value => cleanText(typeof value === "string" ? value : value?.id, "", 64))
        .filter(Boolean)
        .slice(0, 4)
        .map(id => {
            const pp = Math.max(1, Number(moveData(id)?.pp) || 1);
            return { id, pp, maxPp: pp };
        });
    pokemon.originalTrainer = {
        name: trainerName,
        uuid: `server:${trainerName.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 48)}`,
        type: "NPC"
    };
    normalizePokemonForBattle(pokemon);
    pokemon.maxHp = calculateMaxHp(pokemon);
    pokemon.currentHp = pokemon.maxHp;
    return pokemon;
}

function publishTrainerResult(player, requestId, outcome, detail = "") {
    if (!player?.isValid) return;
    const result = {
        version: CONTENT_API_VERSION,
        requestId: cleanText(requestId, "", 128),
        playerId: String(player.id),
        outcome: cleanText(outcome, "rejected", 24),
        detail: cleanText(detail, "", 160)
    };
    if (result.outcome === "rejected") {
        console.warn(`[ServerContentAPI] Trainer request '${result.requestId}' rejected: ${result.detail || "unspecified"}`);
    }
    try { system.sendScriptEvent(TRAINER_RESULT_EVENT, JSON.stringify(result)); }
    catch (error) { console.warn(`[ServerContentAPI] Trainer result event failed: ${error}`); }
}

function trainerEntityById(entityId) {
    try { return world.getEntity(String(entityId || "")); }
    catch (error) { return undefined; }
}

function handleTrainerRequest(request, envelope) {
    const player = playerById(envelope?.playerId);
    if (!player?.isValid) return;

    const requestId = cleanText(request?.requestId, "", 128);
    if (Number(request?.version) !== CONTENT_API_VERSION
        || requestId !== cleanText(envelope?.requestId, "", 128)
        || String(request?.playerId || "") !== String(player.id)) {
        return publishTrainerResult(player, requestId || envelope?.requestId, "rejected", "request_mismatch");
    }

    const trainer = trainerEntityById(request.trainerEntityId);
    if (!trainer?.isValid) return publishTrainerResult(player, requestId, "rejected", "trainer_unavailable");

    const trainerName = cleanText(request.trainerName, "Trainer", 80);
    let party;
    try {
        party = (Array.isArray(request.party) ? request.party : [])
            .slice(0, MAX_TRAINER_PARTY_SIZE)
            .map(source => fixedTrainerPokemon(source, trainerName));
    } catch (error) {
        console.warn(`[ServerContentAPI] Trainer party rejected: ${error}`);
        return publishTrainerResult(player, requestId, "rejected", "invalid_party");
    }
    if (!party.length) return publishTrainerResult(player, requestId, "rejected", "empty_party");

    const started = startTrainerBattle(player, trainer, {
        trainerName,
        party,
        levelCap: Math.max(1, Math.min(100, Math.floor(Number(request.levelCap) || 100))),
        enforceLevelCap: request.enforceLevelCap === true,
        bag: Array.isArray(request.bag) ? request.bag.slice(0, 16) : [],
        maxItemUses: Math.max(0, Math.min(16, Math.floor(Number(request.maxItemUses) || 0))),
        ai: request.ai && typeof request.ai === "object" ? { ...request.ai } : {},
        cameraSideScale: Number.isFinite(Number(request.cameraSideScale))
            ? Math.max(-1, Math.min(1, Number(request.cameraSideScale)))
            : 1,
        opponentLocation: finiteLocation(request.opponentLocation),
        playerPokemonLocation: finiteLocation(request.playerPokemonLocation),
        playerLocation: finiteLocation(request.playerLocation),
        onVictory: winner => publishTrainerResult(winner, requestId, "victory"),
        onLoss: loser => publishTrainerResult(loser, requestId, "loss"),
        onAbort: (battler, session, detail) => publishTrainerResult(
            battler,
            requestId,
            "rejected",
            cleanText(detail, "battle_aborted", 64)
        )
    });
    publishTrainerResult(player, requestId, started ? "started" : "rejected", started ? "" : "battle_unavailable");
}

function receiveTrainerRequestChunk(chunk) {
    const requestId = cleanText(chunk?.requestId, "", 128);
    const playerId = String(chunk?.playerId || "");
    const player = playerById(playerId);
    if (!player?.isValid || !requestId) return;

    const index = Number(chunk?.index);
    const total = Number(chunk?.total);
    const data = typeof chunk?.data === "string" ? chunk.data : undefined;
    if (Number(chunk?.version) !== CONTENT_API_VERSION
        || !Number.isInteger(index)
        || !Number.isInteger(total)
        || total < 1
        || total > MAX_TRAINER_REQUEST_CHUNKS
        || index < 0
        || index >= total
        || data === undefined
        || data.length > MAX_TRAINER_REQUEST_CHUNK_LENGTH) {
        return publishTrainerResult(player, requestId, "rejected", "invalid_request_chunk");
    }

    const key = `${playerId}:${requestId}`;
    let pending = pendingTrainerRequests.get(key);
    if (!pending) {
        pending = {
            playerId,
            requestId,
            total,
            parts: new Array(total),
            received: 0,
            updatedTick: system.currentTick
        };
        pendingTrainerRequests.set(key, pending);
    }
    if (pending.total !== total) {
        pendingTrainerRequests.delete(key);
        return publishTrainerResult(player, requestId, "rejected", "request_chunk_mismatch");
    }
    if (pending.parts[index] !== undefined) {
        if (pending.parts[index] !== data) {
            pendingTrainerRequests.delete(key);
            return publishTrainerResult(player, requestId, "rejected", "request_chunk_mismatch");
        }
        pending.updatedTick = system.currentTick;
        return;
    }

    pending.parts[index] = data;
    pending.received++;
    pending.updatedTick = system.currentTick;
    if (pending.received !== pending.total) return;
    pendingTrainerRequests.delete(key);

    const serialized = pending.parts.join("");
    if (serialized.length > MAX_TRAINER_REQUEST_LENGTH) {
        return publishTrainerResult(player, requestId, "rejected", "request_too_large");
    }
    const request = parseMessage(serialized);
    if (!request) return publishTrainerResult(player, requestId, "rejected", "invalid_request");
    system.run(() => handleTrainerRequest(request, { requestId, playerId }));
}

function handleHudRequest(request) {
    if (Number(request?.version) !== CONTENT_API_VERSION) return;
    const player = playerById(request.playerId);
    if (!player?.isValid) return;
    const key = cleanText(request.key, "", MAX_HUD_KEY_LENGTH);
    if (!key) return;
    if (request.action === "clear") {
        clearHudTitleTransient(player, key);
        return;
    }
    const token = cleanText(request.token, "", MAX_HUD_TOKEN_LENGTH);
    if (token) setHudTitleTransient(player, key, token);
}

function handleNaturalSpawnZoneRequest(request) {
    if (Number(request?.version) !== CONTENT_API_VERSION) return;
    if (request.action === "remove") {
        removeNaturalSpawnZone(request.zoneId);
        return;
    }
    if (request.action === "upsert" && upsertNaturalSpawnZone(request)
        && request.cleanupExisting === true) {
        clearNaturalSpawnsInZone(request.zoneId);
    }
}

function publishPokemonSpawnResult(player, requestId, outcome, detail = "", entity = undefined, species = "") {
    if (!player?.isValid) return;
    const result = {
        version: POKEMON_SPAWN_API_VERSION,
        requestId: cleanText(requestId, "", 128),
        playerId: String(player.id),
        outcome: cleanText(outcome, "rejected", 24),
        detail: cleanText(detail, "", 160),
        species: cleanText(species, "", 64),
        entityId: entity?.isValid ? String(entity.id) : ""
    };
    if (result.outcome === "rejected") {
        console.warn(`[ServerContentAPI] Pokémon spawn request '${result.requestId}' rejected: ${result.detail || "unspecified"}`);
    }
    try { system.sendScriptEvent(POKEMON_SPAWN_RESULT_EVENT, JSON.stringify(result)); }
    catch (error) { console.warn(`[ServerContentAPI] Pokémon spawn result event failed: ${error}`); }
}

function pokemonSpawnDistance(player, location) {
    const dx = Number(player.location.x) - location.x;
    const dy = Number(player.location.y) - location.y;
    const dz = Number(player.location.z) - location.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function handlePokemonSpawnRequest(request) {
    if (Number(request?.version) !== POKEMON_SPAWN_API_VERSION) return;
    const player = playerById(request.playerId);
    if (!player?.isValid) return;
    const requestId = cleanText(request.requestId, "", 128);
    if (!requestId) return publishPokemonSpawnResult(player, requestId, "rejected", "missing_request_id");
    const replayKey = `${player.id}:${requestId}`;
    if (recentPokemonSpawnRequests.has(replayKey)) {
        return publishPokemonSpawnResult(player, requestId, "rejected", "duplicate_request");
    }
    recentPokemonSpawnRequests.set(replayKey, system.currentTick);

    const species = cleanText(request.species, "", 64).replace(/^lota:/, "").toLowerCase();
    const data = speciesData(species);
    if (!data) return publishPokemonSpawnResult(player, requestId, "rejected", "unknown_species", undefined, species);
    if (String(request.dimensionId || "") !== String(player.dimension.id)) {
        return publishPokemonSpawnResult(player, requestId, "rejected", "dimension_mismatch", undefined, species);
    }
    const location = finiteLocation(request.location);
    if (!location || pokemonSpawnDistance(player, location) > MAX_POKEMON_SPAWN_DISTANCE) {
        return publishPokemonSpawnResult(player, requestId, "rejected", "location_out_of_range", undefined, species);
    }
    const level = Math.floor(Number(request.level));
    if (!Number.isInteger(level) || level < 1 || level > 100) {
        return publishPokemonSpawnResult(player, requestId, "rejected", "invalid_level", undefined, species);
    }
    const requestedDuplicateRadius = Number.isFinite(Number(request.duplicateRadius))
        ? Number(request.duplicateRadius)
        : POKEMON_DUPLICATE_RADIUS;
    const duplicateRadius = Math.max(0, Math.min(128, requestedDuplicateRadius));
    if (duplicateRadius > 0) {
        try {
            const nearby = player.dimension.getEntities({
                type: `lota:${species}`,
                location,
                maxDistance: duplicateRadius
            });
            if (nearby.some(entity => entity?.isValid)) {
                return publishPokemonSpawnResult(player, requestId, "rejected", "species_already_nearby", undefined, species);
            }
        } catch (error) {
            return publishPokemonSpawnResult(player, requestId, "rejected", "duplicate_check_failed", undefined, species);
        }
    }

    let entity;
    try {
        const pokemon = generateRandomPokemon(`lota:${species}`, level);
        pokemon.nickname = data.name || species;
        if (typeof request.isShiny === "boolean") pokemon.isShiny = request.isShiny;
        if (request.form) pokemon.form = cleanText(request.form, pokemon.form || "normal", 32);
        if (request.nature) {
            pokemon.nature = cleanText(request.nature, pokemon.nature || "hardy", 32);
            pokemon.mintedNature = pokemon.nature;
        }
        if (request.ability) pokemon.ability = cleanText(request.ability, pokemon.ability || "", 64);
        if (request.heldItem) pokemon.heldItem = cleanText(request.heldItem, "", 96);
        const requestedIvs = request.ivs && typeof request.ivs === "object" ? request.ivs : {};
        const requestedEvs = request.evs && typeof request.evs === "object" ? request.evs : {};
        const statKeys = ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"];
        pokemon.ivs ||= {};
        pokemon.evs ||= {};
        for (const stat of statKeys) {
            if (Number.isFinite(Number(requestedIvs[stat]))) {
                pokemon.ivs[stat] = Math.max(0, Math.min(31, Math.floor(Number(requestedIvs[stat]))));
            }
            if (Number.isFinite(Number(requestedEvs[stat]))) {
                pokemon.evs[stat] = Math.max(0, Math.min(252, Math.floor(Number(requestedEvs[stat]))));
            }
        }
        const minimumPerfectIvs = Math.max(0, Math.min(6, Math.floor(Number(request.minPerfectIvs) || 0)));
        const shuffledStats = [...statKeys].sort(() => Math.random() - 0.5);
        let perfectCount = statKeys.filter(stat => Number(pokemon.ivs[stat]) === 31).length;
        for (const stat of shuffledStats) {
            if (perfectCount >= minimumPerfectIvs) break;
            if (Number(pokemon.ivs[stat]) === 31) continue;
            pokemon.ivs[stat] = 31;
            perfectCount++;
        }
        const requestedAspects = Array.isArray(request.aspects)
            ? request.aspects.map(value => cleanText(value, "", 32)).filter(Boolean).slice(0, 12)
            : [];
        pokemon.aspects = [...new Set([...(pokemon.aspects || []), ...requestedAspects])];
        const requestedMoves = (Array.isArray(request.moves) ? request.moves : [])
            .map(value => cleanText(value, "", 64))
            .filter(value => moveData(value))
            .slice(0, 4);
        if (requestedMoves.length) {
            pokemon.moves = requestedMoves.map(id => {
                const pp = Math.max(1, Number(moveData(id)?.pp) || 1);
                return { id, pp, maxPp: pp };
            });
        }
        normalizePokemonForBattle(pokemon);
        pokemon.maxHp = calculateMaxHp(pokemon);
        pokemon.currentHp = pokemon.maxHp;

        entity = player.dimension.spawnEntity(`lota:${species}`, location);
        savePokemonToEntity(entity, pokemon);
        try { entity.setProperty("lota:scale_factor", 0.9 + Math.random() * 0.2); } catch (error) {}
        try { entity.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
        applyWildPokemonNameTags(entity, pokemon);
        publishPokemonSpawnResult(player, requestId, "spawned", "", entity, species);
    } catch (error) {
        try { if (entity?.isValid) entity.remove(); } catch (removeError) {}
        console.warn(`[ServerContentAPI] Pokémon spawn failed for '${species}': ${error}`);
        publishPokemonSpawnResult(player, requestId, "rejected", "spawn_failed", undefined, species);
    }
}

function publishPartyHealResult(request, outcome, detail = "", healed = 0) {
    try {
        system.sendScriptEvent(PARTY_HEAL_RESULT_EVENT, JSON.stringify({
            version: PARTY_HEAL_API_VERSION,
            requestId: cleanText(request?.requestId, "", 128),
            playerId: cleanText(request?.playerId, "", 80),
            outcome: cleanText(outcome, "rejected", 24),
            detail: cleanText(detail, "", 160),
            healed: Math.max(0, Math.floor(Number(healed) || 0))
        }));
    } catch (error) {
        console.warn(`[ServerContentAPI] Party heal result failed: ${error}`);
    }
}

function handlePartyHealRequest(request) {
    if (Number(request?.version) !== PARTY_HEAL_API_VERSION) return;
    const requestId = cleanText(request.requestId, "", 128);
    if (!requestId) return;
    if (recentPartyHealRequests.has(requestId)) return publishPartyHealResult(request, "rejected", "duplicate_request");
    recentPartyHealRequests.set(requestId, system.currentTick);
    const player = playerById(request.playerId);
    if (!player?.isValid) return publishPartyHealResult(request, "rejected", "player_unavailable");
    const party = loadPartyFromPlayer(player);
    if (!party.length) return publishPartyHealResult(request, "rejected", "empty_party");
    let healed = 0;
    for (const pokemon of party) {
        if (!pokemon) continue;
        pokemon.maxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1));
        pokemon.currentHp = pokemon.maxHp;
        pokemon.statusCondition = "NONE";
        if (Array.isArray(pokemon.moves)) {
            for (const move of pokemon.moves) {
                if (!move) continue;
                move.maxPp = Math.max(0, Math.floor(Number(move.maxPp) || Number(move.pp) || 0));
                move.pp = move.maxPp;
            }
        }
        healed++;
    }
    if (!savePartyToPlayer(player, party)) return publishPartyHealResult(request, "rejected", "save_failed");
    publishPartyHealResult(request, "healed", "", healed);
}

function publishPokemonGrantResult(request, outcome, detail = "", extra = {}) {
    const result = {
        version: POKEMON_GRANT_API_VERSION,
        requestId: cleanText(request?.requestId, "", 128),
        playerId: cleanText(request?.playerId, "", 80),
        outcome: cleanText(outcome, "rejected", 24),
        detail: cleanText(detail, "", 160),
        ...extra
    };
    try { system.sendScriptEvent(POKEMON_GRANT_RESULT_EVENT, JSON.stringify(result)); }
    catch (error) { console.warn(`[ServerContentAPI] Pokemon grant result failed: ${error}`); }
}

function guaranteePerfectIvs(pokemon, requestedCount) {
    const keys = ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"];
    const count = Math.max(0, Math.min(keys.length, Math.floor(Number(requestedCount) || 0)));
    for (let index = keys.length - 1; index > 0; index--) {
        const swap = Math.floor(Math.random() * (index + 1));
        [keys[index], keys[swap]] = [keys[swap], keys[index]];
    }
    for (const key of keys.slice(0, count)) pokemon.ivs[key] = 31;
}

function handlePokemonGrantRequest(request) {
    if (Number(request?.version) !== POKEMON_GRANT_API_VERSION) return;
    const requestId = cleanText(request.requestId, "", 128);
    if (!requestId) return;
    if (recentPokemonGrantRequests.has(requestId)) return publishPokemonGrantResult(request, "rejected", "duplicate_request");
    recentPokemonGrantRequests.set(requestId, system.currentTick);
    const player = playerById(request.playerId);
    if (!player?.isValid) return publishPokemonGrantResult(request, "rejected", "player_unavailable");
    const species = cleanText(request.species, "", 64).replace(/^.*:/, "").toLowerCase();
    const data = speciesData(species);
    if (!data) return publishPokemonGrantResult(request, "rejected", "unknown_species");
    const level = Math.max(1, Math.min(100, Math.floor(Number(request.level) || 5)));
    try {
        const pokemon = generateRandomPokemon(`lota:${species}`, level);
        pokemon.nickname = data.name || pokemon.nickname || species;
        pokemon.isShiny = request.isShiny === true;
        pokemon.aspects = (Array.isArray(pokemon.aspects) ? pokemon.aspects : [])
            .filter(aspect => aspect !== "shiny" && aspect !== "normal");
        pokemon.aspects.unshift(pokemon.isShiny ? "shiny" : "normal");
        pokemon.caughtBall = cleanText(request.caughtBall, "poke_ball", 48).replace(/^.*:/, "");
        guaranteePerfectIvs(pokemon, request.minPerfectIvs);
        normalizePokemonForBattle(pokemon);
        pokemon.maxHp = calculateMaxHp(pokemon);
        pokemon.currentHp = pokemon.maxHp;
        const storage = addPokemonToPlayerParty(player, pokemon);
        if (!storage.success) return publishPokemonGrantResult(request, "rejected", "storage_full");
        publishPokemonGrantResult(request, "granted", "", {
            pokemon: pokemonSummary(pokemon, storage.slot),
            storage
        });
    } catch (error) {
        console.warn(`[ServerContentAPI] Pokemon grant failed for '${species}': ${error}`);
        publishPokemonGrantResult(request, "rejected", "grant_failed");
    }
}

const TRADE_STAT_KEYS = ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"];

function titleCase(value) {
    return String(value || "-")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

function tradeStatColumn(source) {
    const stats = source && typeof source === "object" ? source : {};
    return TRADE_STAT_KEYS.map(stat => Math.max(0, Math.floor(Number(stats[stat]) || 0)));
}

function pokemonSummary(pokemon, slot) {
    if (!pokemon) return null;
    const species = cleanText(pokemon.species, "", 64).replace(/^lota:/, "").replace(/^cobblemon:/, "");
    const data = speciesData(species) || {};
    return {
        slot,
        uuid: cleanText(pokemon.uuid, "", 64),
        species,
        name: cleanText(pokemon.nickname, "", 80)
            || cleanText(data.name, "", 80)
            || titleCase(species),
        pokedex: Math.max(0, Math.floor(Number(data.pokedex) || 0)),
        level: Math.max(1, Math.min(100, Math.floor(Number(pokemon.level) || 1))),
        gender: cleanText(pokemon.gender, "GENDERLESS", 16),
        isShiny: pokemon.isShiny === true,
        heldItem: cleanText(pokemon.heldItem, "", 96),
        nature: cleanText(pokemon.mintedNature || pokemon.nature, "-", 48),
        ability: cleanText(pokemon.ability, "-", 64),
        types: Array.isArray(data.types) ? data.types.slice(0, 2).map(type => cleanText(type, "", 24)) : [],
        caughtBall: cleanText(pokemon.caughtBall, "", 48).replace(/^.*:/, ""),
        moves: (Array.isArray(pokemon.moves) ? pokemon.moves.slice(0, 4) : [])
            .map(move => cleanText(typeof move === "string" ? move : move?.id, "", 48))
            .filter(Boolean),
        ivs: tradeStatColumn(pokemon.ivs),
        evs: tradeStatColumn(pokemon.evs),
        tradeable: pokemon.tradeable !== false
    };
}

export const __tradeDataTest = { pokemonSummary, tradeStatColumn };

function publishTradeResult(request, outcome, detail = "", extra = {}) {
    const result = {
        version: TRADE_API_VERSION,
        requestId: cleanText(request?.requestId, "", 128),
        outcome: cleanText(outcome, "rejected", 24),
        detail: cleanText(detail, "", 160),
        ...extra
    };
    if (!request?.requestId) return result;
    try { system.sendScriptEvent(TRADE_RESULT_EVENT, JSON.stringify(result)); }
    catch (error) { console.warn(`[ServerContentAPI] Trade result event failed: ${error}`); }
    return result;
}

function tradeDistanceValid(playerOne, playerTwo) {
    if (playerOne.dimension.id !== playerTwo.dimension.id) return false;
    return Math.hypot(
        playerOne.location.x - playerTwo.location.x,
        playerOne.location.y - playerTwo.location.y,
        playerOne.location.z - playerTwo.location.z
    ) <= MAX_TRADE_DISTANCE;
}

function performTradeEvolution(pokemon, counterpart, recipient) {
    const counterpartSpecies = cleanText(counterpart?.species, "", 64).replace(/^.*:/, "").toLowerCase();
    const option = itemEvolutionOptions(pokemon, TRADE_EVOLUTION_ITEM, { player: recipient })
        .find(candidate => !candidate.requiredContext
            || cleanText(candidate.requiredContext, "", 64).replace(/^.*:/, "").toLowerCase() === counterpartSpecies);
    if (!option) return undefined;
    const queued = queueItemEvolution(pokemon, option.id, TRADE_EVOLUTION_ITEM, { player: recipient });
    if (!queued) return undefined;
    const oldSpecies = speciesKey(pokemon);
    return {
        id: queued.id,
        oldSpecies,
        result: queued.result,
        oldName: pokemon.nickname || speciesData(oldSpecies)?.name || oldSpecies,
        newName: speciesData(queued.result)?.name || queued.result,
        pending: true
    };
}

function handleTradeSnapshot(request) {
    const playerIds = Array.isArray(request.playerIds)
        ? [...new Set(request.playerIds.map(String))].slice(0, 2)
        : [];
    if (!playerIds.length) return publishTradeResult(request, "rejected", "missing_players");
    const players = playerIds.map(playerById);
    if (players.some(player => !player?.isValid)) return publishTradeResult(request, "rejected", "player_unavailable");
    return publishTradeResult(request, "snapshot", "", {
        players: players.map(player => ({
            playerId: String(player.id),
            name: cleanText(player.name, "Trainer", 80),
            party: loadPartyFromPlayer(player).map(pokemonSummary).filter(Boolean)
        }))
    });
}

function handleTradeExecute(request) {
    const playerOne = playerById(request.playerOneId);
    const playerTwo = playerById(request.playerTwoId);
    if (!playerOne?.isValid || !playerTwo?.isValid || playerOne.id === playerTwo.id) {
        return publishTradeResult(request, "rejected", "player_unavailable");
    }
    if (playerOne.hasTag("lota:battle_player") || playerTwo.hasTag("lota:battle_player")) {
        return publishTradeResult(request, "rejected", "player_in_battle");
    }
    if (!tradeDistanceValid(playerOne, playerTwo)) {
        return publishTradeResult(request, "rejected", "players_too_far_apart");
    }

    const originalPartyOne = loadPartyFromPlayer(playerOne);
    const originalPartyTwo = loadPartyFromPlayer(playerTwo);
    const partyOne = JSON.parse(JSON.stringify(originalPartyOne));
    const partyTwo = JSON.parse(JSON.stringify(originalPartyTwo));
    const slotOne = Number(request.slotOne);
    const slotTwo = Number(request.slotTwo);
    if (!Number.isInteger(slotOne) || !Number.isInteger(slotTwo)
        || slotOne < 0 || slotOne >= 6 || slotTwo < 0 || slotTwo >= 6) {
        return publishTradeResult(request, "rejected", "pokemon_unavailable");
    }
    const pokemonOne = partyOne[slotOne];
    const pokemonTwo = partyTwo[slotTwo];
    if (!pokemonOne || !pokemonTwo) return publishTradeResult(request, "rejected", "pokemon_unavailable");
    if (pokemonOne.fusionState?.partner || pokemonTwo.fusionState?.partner) {
        return publishTradeResult(request, "rejected", "unfuse_kyurem_first");
    }
    if (!pokemonOne.uuid || !pokemonTwo.uuid || pokemonOne.uuid === pokemonTwo.uuid
        || String(pokemonOne.uuid || "") !== String(request.uuidOne || "")
        || String(pokemonTwo.uuid || "") !== String(request.uuidTwo || "")) {
        return publishTradeResult(request, "rejected", "party_changed");
    }

    if ((request.expectedOne && JSON.stringify(pokemonSummary(pokemonOne, slotOne)) !== JSON.stringify(request.expectedOne))
        || (request.expectedTwo && JSON.stringify(pokemonSummary(pokemonTwo, slotTwo)) !== JSON.stringify(request.expectedTwo))) {
        return publishTradeResult(request, "rejected", "party_changed");
    }
    const evolutionOne = performTradeEvolution(pokemonOne, originalPartyTwo[slotTwo], playerTwo);
    const evolutionTwo = performTradeEvolution(pokemonTwo, originalPartyOne[slotOne], playerOne);
    partyOne[slotOne] = pokemonTwo;
    partyTwo[slotTwo] = pokemonOne;
    recallPartyPokemon(playerOne, originalPartyOne[slotOne]);
    recallPartyPokemon(playerTwo, originalPartyTwo[slotTwo]);
    if (!savePartyToPlayer(playerOne, partyOne) || !savePartyToPlayer(playerTwo, partyTwo)) {
        savePartyToPlayer(playerOne, originalPartyOne);
        savePartyToPlayer(playerTwo, originalPartyTwo);
        return publishTradeResult(request, "rejected", "save_failed");
    }

    return publishTradeResult(request, "completed", "", {
        playerOneId: String(playerOne.id),
        playerTwoId: String(playerTwo.id),
        receivedByOne: pokemonSummary(pokemonTwo, slotOne),
        receivedByTwo: pokemonSummary(pokemonOne, slotTwo),
        evolutions: [evolutionOne, evolutionTwo].filter(Boolean).map(result => ({
            oldSpecies: result.oldSpecies,
            result: result.result,
            oldName: result.oldName,
            newName: result.newName
        }))
    });
}

export function requestPartySnapshot(playerIds) {
    return handleTradeSnapshot({ playerIds });
}

export function executeTrade(requesterId, payload) {
    if (String(requesterId) !== String(payload?.playerOneId)) {
        return publishTradeResult({}, "rejected", "invalid_requester");
    }
    return handleTradeExecute(payload);
}

function handleTradeRequest(request) {
    if (Number(request?.version) !== TRADE_API_VERSION) return;
    const requestId = cleanText(request.requestId, "", 128);
    if (!requestId) return;
    const replayKey = `${request.action}:${requestId}`;
    if (recentTradeRequests.has(replayKey)) return publishTradeResult(request, "rejected", "duplicate_request");
    recentTradeRequests.set(replayKey, system.currentTick);
    if (request.action === "snapshot") return handleTradeSnapshot(request);
    if (request.action === "execute") return handleTradeExecute(request);
    publishTradeResult(request, "rejected", "unknown_action");
}

function handleLevelCapSync(request) {
    if (Number(request?.version) !== CONTENT_API_VERSION) return;
    const player = playerById(request.playerId);
    if (!player?.isValid) return;
    setExternalLevelCap(player, request.levelCap);
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.sourceType !== ScriptEventSource.Server) return;
    if (event.id === TRAINER_REQUEST_EVENT) {
        const chunk = parseMessage(event.message);
        if (chunk) receiveTrainerRequestChunk(chunk);
        return;
    }
    if (event.id === HUD_REQUEST_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handleHudRequest(request));
        return;
    }
    if (event.id === NATURAL_SPAWN_ZONE_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handleNaturalSpawnZoneRequest(request));
        return;
    }
    if (event.id === POKEMON_SPAWN_REQUEST_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handlePokemonSpawnRequest(request));
        return;
    }
    if (event.id === TRADE_REQUEST_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handleTradeRequest(request));
        return;
    }
    if (event.id === POKEMON_GRANT_REQUEST_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handlePokemonGrantRequest(request));
        return;
    }
    if (event.id === PARTY_HEAL_REQUEST_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handlePartyHealRequest(request));
        return;
    }
    if (event.id === LEVEL_CAP_SYNC_EVENT) {
        const request = parseMessage(event.message);
        if (request) system.run(() => handleLevelCapSync(request));
    }
});

system.runInterval(() => {
    for (const [key, pending] of pendingTrainerRequests) {
        if (system.currentTick - pending.updatedTick > TRAINER_REQUEST_TTL_TICKS) {
            pendingTrainerRequests.delete(key);
        }
    }
    for (const [key, tick] of recentPokemonSpawnRequests) {
        if (system.currentTick - tick > POKEMON_SPAWN_REQUEST_TTL_TICKS) {
            recentPokemonSpawnRequests.delete(key);
        }
    }
    for (const [key, tick] of recentTradeRequests) {
        if (system.currentTick - tick > TRADE_REQUEST_TTL_TICKS) recentTradeRequests.delete(key);
    }
    for (const [key, tick] of recentPokemonGrantRequests) {
        if (system.currentTick - tick > POKEMON_GRANT_REQUEST_TTL_TICKS) recentPokemonGrantRequests.delete(key);
    }
    for (const [key, tick] of recentPartyHealRequests) {
        if (system.currentTick - tick > POKEMON_GRANT_REQUEST_TTL_TICKS) recentPartyHealRequests.delete(key);
    }
}, 100);
