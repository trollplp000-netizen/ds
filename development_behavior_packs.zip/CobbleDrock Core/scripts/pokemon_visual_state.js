import { POKEMON_MODEL_VARIANTS, POKEMON_ASPECT_FEATURES } from './pokemon_model_variants.js';

export function pokemonVisualAspects(pokemon) {
    const aspects = new Set((pokemon?.aspects || []).map(value => String(value).toLowerCase()));
    for (const megaAspect of [pokemon?.battleState?.megaAspect, pokemon?.megaState?.megaAspect]) {
        if (megaAspect) aspects.add(String(megaAspect).toLowerCase());
    }
    const tokens = String(pokemon?.form || '').toLowerCase().split(/\s+/);
    for (const token of tokens) {
        if (token && token !== 'normal' && !token.includes('=')) aspects.add(token);
    }
    for (const feature of Object.values(POKEMON_ASPECT_FEATURES)) {
        for (const key of feature.keys) {
            const token = [...tokens, ...aspects].find(value => value.startsWith(`${key}=`));
            const value = token?.slice(key.length + 1) ?? pokemon?.spawnProperties?.[key] ?? pokemon?.evolutionProperties?.[key] ?? pokemon?.[key];
            if (feature.type === 'choice' && feature.choices.includes(String(value))) {
                aspects.add(String(feature.aspectFormat || '{{choice}}').replace('{{choice}}', String(value)));
            } else if (feature.type === 'flag' && (value === true || value === 'true' || aspects.has(key))) {
                aspects.add(String(feature.aspect || feature.aspectFormat || key));
            }
        }
    }
    aspects.delete('female');
    aspects.delete('male');
    const gender = String(pokemon?.gender || '').toLowerCase();
    if (gender === 'female' || gender === 'male') aspects.add(gender);
    return aspects;
}

export function pokemonModelVariant(pokemon) {
    if (!pokemon || typeof pokemon === 'string') return null;
    const species = String(pokemon.species || '').replace(/^lota:/, '').toLowerCase();
    const aspects = pokemonVisualAspects(pokemon);
    return POKEMON_MODEL_VARIANTS[species]?.find(form => form.aspects.every(aspect => aspects.has(aspect))) || null;
}

export function pokemonGenderRatio(species, definition) {
    const key = String(species || '').replace(/^lota:/, '').toLowerCase();
    const ratio = Number(definition?.maleRatio);
    const genderForms = POKEMON_MODEL_VARIANTS[key]?.filter(form => form.aspects.every(aspect => ['female', 'male'].includes(aspect))) || [];
    const ratios = [ratio, ...genderForms.map(form => Number(form.data.maleRatio))];
    if (ratios.includes(0) && ratios.includes(1)) return 0.5;
    return Number.isFinite(ratio) ? ratio : 0.5;
}

export function applyPokemonVisualState(entity, pokemon) {
    if (!entity || !pokemon) return;
    try { entity.setProperty('lota:is_shiny', pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
    const species = String(pokemon.species || '').replace(/^lota:/, '').toLowerCase();
    if (POKEMON_MODEL_VARIANTS[species]) {
        try { entity.setProperty('lota:form_index', pokemonModelVariant(pokemon)?.index || 0); } catch (error) {}
    }
}
