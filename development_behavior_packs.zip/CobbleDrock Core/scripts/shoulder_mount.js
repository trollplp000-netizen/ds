import { system, world } from "@minecraft/server";
import { loadPartyFromPlayer, loadPokemonFromEntity } from "./storage.js";

const SHOULDER_SPECIES = ["caterpie","eevee","mew","nidoranf","nidoranm","pidgey","pikachu","spearow","squirtle","weedle","zubat","bellossom","cleffa","igglybuff","larvitar","murkrow","pichu","smoochum","spinarak","teddiursa","totodile","tyrogue","unown","wooper","anorith","beldum","minun","plusle","ralts","sableye","shuppet","skitty","swablu","taillow","zigzagoon","budew","chatot","chingling","combee","kricketot","mimejr","pachirisu","riolu","starly","turtwig","archen","dwebble","elgyem","joltik","litwick","petilil","pidove","purrloin","roggenrola","sewaddle","solosis","tepig","tynamo","vanillite","zorua","dedenne","flabebe","fletchling","klefki","scatterbug","skrelp","comfey","cutiefly","fomantis","litten","mimikyu","morelull","popplio","togedemaru","alcremie","dreepy","milcery","rookidee","sizzlipede","sobble","capsakid","charcadet","flittle","glimmet","maushold","shroodle","sprigatito","squawkabilly","tadbulb","tatsugiri","tinkatink"];
const eligible = new Set(SHOULDER_SPECIES.map(name => `lota:${name}`));
const mounted = new Map();
const tag = "lota:shoulder_mounted";

export function canShoulderMount(entity) {
    return eligible.has(entity?.typeId);
}

export function releaseShoulderMount(entity) {
    mounted.delete(entity.id);
    if (!entity.isValid) return;
    entity.removeTag(tag);
    entity.setDynamicProperty("lota:shoulder_owner", undefined);
    entity.setDynamicProperty("lota:shoulder_side", undefined);
    entity.triggerEvent("lota:shoulder_release");
}
const detach = releaseShoulderMount;

export function toggleShoulderMount(player, entity) {
    if (!entity?.isValid || !canShoulderMount(entity)
        || entity.getDynamicProperty("lota:party_owner_id") !== player.id
        || player.hasTag("lota:battle_player") || entity.hasTag("lota:in_battle")) return false;
    if (entity.hasTag(tag)) { detach(entity); return true; }
    if (player.getComponent("minecraft:riding")?.entityRidingOn) return false;
    const pokemon = loadPokemonFromEntity(entity);
    if (!pokemon || Number(pokemon.currentHp) <= 0) return false;
    const occupied = [...mounted.values()].filter(state => state.ownerId === player.id);
    if (occupied.length >= 2) { player.sendMessage("§eBoth shoulders are occupied."); return false; }
    const side = occupied.some(state => state.side === -1) ? 1 : -1;
    entity.triggerEvent("lota:shoulder_mount");
    entity.addTag(tag);
    entity.setDynamicProperty("lota:shoulder_owner", player.id);
    entity.setDynamicProperty("lota:shoulder_side", side);
    mounted.set(entity.id, { entity, ownerId: player.id, uuid: pokemon.uuid, side });
    player.sendMessage("§aPokemon mounted on your shoulder. Sneak to release.");
    return true;
}

system.runInterval(() => {
    if (mounted.size === 0) return;
    const players = new Map(world.getAllPlayers().map(player => [player.id, player]));
    for (const state of mounted.values()) {
        const { entity, ownerId, uuid, side } = state;
        try {
            const player = players.get(ownerId);
            if (!entity.isValid) { mounted.delete(entity.id); continue; }
            if (!player || player.isSneaking || player.hasTag("lota:battle_player")
                || entity.hasTag("lota:in_battle") || player.getComponent("minecraft:riding")?.entityRidingOn
                || !loadPartyFromPlayer(player).some(p => p.uuid === uuid && Number(p.currentHp) > 0)) {
                detach(entity); continue;
            }
            const yaw = player.getRotation().y * Math.PI / 180;
            const head = player.getHeadLocation();
            entity.clearVelocity();
            entity.teleport({ x: head.x + Math.cos(yaw) * side * 0.42, y: head.y - 0.35, z: head.z + Math.sin(yaw) * side * 0.42 },
                { dimension: player.dimension, rotation: { x: 0, y: player.getRotation().y } });
        } catch { try { detach(entity); } catch { mounted.delete(entity.id); } }
    }
}, 1);

system.runInterval(() => {
    for (const name of ["overworld", "nether", "the_end"]) {
        for (const entity of world.getDimension(name).getEntities({ tags: [tag] })) {
            if (!mounted.has(entity.id)) detach(entity);
        }
    }
}, 40);

world.afterEvents.playerLeave.subscribe(event => {
    for (const state of mounted.values()) if (state.ownerId === event.playerId) detach(state.entity);
});
