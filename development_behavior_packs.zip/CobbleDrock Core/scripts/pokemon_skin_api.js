import { ScriptEventSource, system, world } from "@minecraft/server";
import { activeMegaSpecies } from "./mega_evolution.js";
import {
    loadPartyFromPlayer,
    loadPokemonFromEntity,
    savePartyToPlayer,
    savePokemonToEntity
} from "./storage.js";

export const POKEMON_SKIN_API_VERSION = 1;
export const POKEMON_SKIN_REQUEST_EVENT = "lota:server_pokemon_skin_request_v1";
export const POKEMON_SKIN_RESULT_EVENT = "lota:server_pokemon_skin_result_v1";
export const POKEMON_APPEARANCE_EVENT = "lota:server_pokemon_appearance_v1";
export const POKEMON_SKIN_INDEX_PROPERTY = "lota:skin_index";

const MAX_SKIN_INDEX = 255;
const PARTY_DIMENSION_IDS = Object.freeze([
    "minecraft:overworld", "minecraft:nether", "minecraft:the_end",
    "overworld", "nether", "the_end",
    "lota:wild_world", "lota:island_world"
]);

function parseMessage(message) {
    try {
        const value = JSON.parse(String(message || "{}"));
        return value && typeof value === "object" ? value : undefined;
    } catch (error) {
        return undefined;
    }
}

function cleanText(value, maximumLength = 80) {
    return String(value || "").trim().slice(0, maximumLength);
}

function cleanSpecies(value) {
    return cleanText(value, 96).replace(/^.*:/, "").toLowerCase();
}

function cleanSkinKey(value) {
    const key = cleanText(value, 64).toLowerCase();
    return /^[a-z0-9][a-z0-9_.:-]{0,63}$/.test(key) ? key : "";
}

function playerById(playerId) {
    const id = String(playerId || "");
    return id ? world.getAllPlayers().find(player => String(player.id) === id) : undefined;
}

function partyDimensions() {
    const found = new Map();
    for (const dimensionId of PARTY_DIMENSION_IDS) {
        try {
            const dimension = world.getDimension(dimensionId);
            found.set(String(dimension.id), dimension);
        } catch (error) {}
    }
    return [...found.values()];
}

function summonedEntity(playerId, pokemonUuid) {
    for (const dimension of partyDimensions()) {
        for (const entity of dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            try {
                if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== String(playerId)) continue;
                if (loadPokemonFromEntity(entity)?.uuid === pokemonUuid) return entity;
            } catch (error) {}
        }
    }
    return undefined;
}

function skinRecord(pokemon) {
    const stored = pokemon?.cosmeticSkin;
    const skinIndex = Math.max(0, Math.min(MAX_SKIN_INDEX, Math.floor(Number(stored?.skinIndex) || 0)));
    return {
        providerId: skinIndex ? cleanSkinKey(stored?.providerId) : "",
        skinId: skinIndex ? cleanSkinKey(stored?.skinId) : "",
        skinIndex
    };
}

function pokemonAppearance(pokemon, entity = undefined, slot = -1) {
    const baseSpecies = cleanSpecies(pokemon?.species);
    const megaSpecies = activeMegaSpecies(pokemon);
    return {
        slot,
        pokemonUuid: cleanText(pokemon?.uuid, 96),
        entityId: entity?.isValid ? String(entity.id) : "",
        baseSpecies,
        runtimeSpecies: megaSpecies || baseSpecies,
        form: cleanText(pokemon?.form || "normal", 48),
        aspects: Array.isArray(pokemon?.aspects) ? pokemon.aspects.map(value => cleanText(value, 48)).filter(Boolean).slice(0, 16) : [],
        gender: cleanText(pokemon?.gender, 24),
        isShiny: pokemon?.isShiny === true,
        isMegaEvolved: !!megaSpecies,
        megaAspect: cleanText(pokemon?.megaState?.megaAspect || pokemon?.battleState?.megaAspect, 48),
        skin: skinRecord(pokemon)
    };
}

export function applyPokemonSkinToEntity(entity, pokemon) {
    if (!entity?.isValid || !pokemon) return false;
    const skin = skinRecord(pokemon);
    try { entity.setProperty(POKEMON_SKIN_INDEX_PROPERTY, skin.skinIndex); }
    catch (error) { return false; }
    try { entity.setDynamicProperty("lota:skin_provider", skin.providerId || undefined); } catch (error) {}
    try { entity.setDynamicProperty("lota:skin_id", skin.skinId || undefined); } catch (error) {}
    return true;
}

export function publishPokemonAppearanceEvent(action, playerOrId, pokemon, entity = undefined) {
    if (!pokemon?.uuid) return false;
    const playerId = typeof playerOrId === "string" ? playerOrId : String(playerOrId?.id || "");
    if (!playerId) return false;
    try {
        system.sendScriptEvent(POKEMON_APPEARANCE_EVENT, JSON.stringify({
            version: POKEMON_SKIN_API_VERSION,
            action: cleanText(action, 32),
            playerId,
            pokemon: pokemonAppearance(pokemon, entity)
        }));
        return true;
    } catch (error) {
        console.warn(`[PokemonSkinAPI] Appearance event failed: ${error}`);
        return false;
    }
}

function publishResult(player, request, outcome, detail = "", payload = {}) {
    if (!player?.isValid) return;
    try {
        system.sendScriptEvent(POKEMON_SKIN_RESULT_EVENT, JSON.stringify({
            version: POKEMON_SKIN_API_VERSION,
            requestId: cleanText(request?.requestId, 128),
            playerId: String(player.id),
            action: cleanText(request?.action || "get", 24),
            outcome,
            detail,
            ...payload
        }));
    } catch (error) {
        console.warn(`[PokemonSkinAPI] Result event failed: ${error}`);
    }
}

function requestedPokemon(request, party) {
    const pokemonUuid = cleanText(request?.pokemonUuid, 96);
    if (pokemonUuid) {
        const slot = party.findIndex(pokemon => pokemon?.uuid === pokemonUuid);
        return { slot, pokemon: party[slot] };
    }
    const slot = Math.floor(Number(request?.slot));
    return Number.isInteger(slot) && slot >= 0 && slot < party.length
        ? { slot, pokemon: party[slot] }
        : { slot: -1, pokemon: undefined };
}

function handleSkinRequest(request) {
    const player = playerById(request?.playerId);
    if (!player?.isValid) return;
    if (Number(request?.version) !== POKEMON_SKIN_API_VERSION) {
        return publishResult(player, request, "rejected", "unsupported_version");
    }
    if (!cleanText(request?.requestId, 128)) {
        return publishResult(player, request, "rejected", "missing_request_id");
    }

    const action = cleanText(request?.action || "get", 24).toLowerCase();
    const party = loadPartyFromPlayer(player);
    if (action === "list") {
        return publishResult(player, request, "ok", "", {
            party: party.map((pokemon, slot) => pokemonAppearance(
                pokemon,
                summonedEntity(player.id, pokemon.uuid),
                slot
            ))
        });
    }

    const selected = requestedPokemon(request, party);
    if (!selected.pokemon) return publishResult(player, request, "rejected", "pokemon_not_found");
    const entity = summonedEntity(player.id, selected.pokemon.uuid);
    if (action === "get") {
        return publishResult(player, request, "ok", "", {
            pokemon: pokemonAppearance(selected.pokemon, entity, selected.slot)
        });
    }

    if (action === "set") {
        const providerId = cleanSkinKey(request?.providerId);
        const skinId = cleanSkinKey(request?.skinId);
        const skinIndex = Math.floor(Number(request?.skinIndex));
        if (!providerId || !skinId || !Number.isInteger(skinIndex) || skinIndex < 1 || skinIndex > MAX_SKIN_INDEX) {
            return publishResult(player, request, "rejected", "invalid_skin");
        }
        selected.pokemon.cosmeticSkin = { providerId, skinId, skinIndex };
    } else if (action === "clear") {
        delete selected.pokemon.cosmeticSkin;
    } else {
        return publishResult(player, request, "rejected", "unknown_action");
    }

    if (!savePartyToPlayer(player, party)) return publishResult(player, request, "rejected", "save_failed");
    if (entity?.isValid) {
        savePokemonToEntity(entity, selected.pokemon);
        applyPokemonSkinToEntity(entity, selected.pokemon);
    }
    publishPokemonAppearanceEvent("skin_changed", player, selected.pokemon, entity);
    publishResult(player, request, "updated", "", {
        pokemon: pokemonAppearance(selected.pokemon, entity, selected.slot)
    });
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.sourceType !== ScriptEventSource.Server || event.id !== POKEMON_SKIN_REQUEST_EVENT) return;
    const request = parseMessage(event.message);
    if (request) system.run(() => handleSkinRequest(request));
});
