import { BREEDING_SPECIES } from "./breeding_data.js";
import { POKEMON_ASPECT_FEATURES } from "./pokemon_model_variants.js";
import { pokemonVisualAspects } from "./pokemon_visual_state.js";

export const COBBREEDING_REFERENCE_CONFIG = Object.freeze({
    minTicks: 8400,
    maxTicks: 18000,
    mirrorHerbTicks: 600,
    eggSlots: 3,
    hatchMultiplier: 1,
    shinyAlways: 8,
    shinyCrystal: 2,
    shinyMasuda: 2,
    hiddenAbilities: true,
    forcedAbilities: false,
    dittoRandomEgg: false,
    dittoAllowLegendary: false,
    dittoAllowParadox: false,
    dittoAllowUltraBeast: false,
    dittoAllowUndiscovered: false,
    allowHoppers: true,
    maxActivatedPastures: -1,
    encryptEggs: false,
    sizeVariations: true
});

export const BREEDING_CONFIG = COBBREEDING_REFERENCE_CONFIG;

export const BREEDING_STAT_KEYS = Object.freeze([
    "hp", "attack", "defence", "specialAttack", "specialDefence", "speed"
]);

const NATURES = Object.freeze([
    "hardy", "lonely", "brave", "adamant", "naughty", "bold", "docile", "relaxed", "impish", "lax",
    "timid", "hasty", "serious", "jolly", "naive", "modest", "mild", "quiet", "rash", "bashful",
    "calm", "gentle", "sassy", "careful", "quirky"
]);
const POWER_ITEMS = Object.freeze({
    power_weight: "hp", power_bracer: "attack", power_belt: "defence",
    power_lens: "specialAttack", power_band: "specialDefence", power_anklet: "speed"
});
const INHERITED_FEATURES = Object.freeze([
    "bagworm_cloak", "color", "dance_style", "fish_stripes", "striped", "magikarp_jump", "mooshtank",
    "region_bias", "alolan", "galarian", "hisuian", "paldean", "bull_breed", "tatsugiri_texture",
    "whiscash_nero", "wooper_heart"
]);

const cleanId = value => String(value || "").replace(/^.*:/, "").toLowerCase().replace(/[^a-z0-9_=-]/g, "");
const randomIndex = (length, random) => Math.min(length - 1, Math.floor(random() * length));
const pick = (values, random) => values[randomIndex(values.length, random)];
const itemId = pokemon => cleanId(pokemon?.heldItem || pokemon?.heldItemData?.typeId);
const gender = pokemon => String(pokemon?.gender || "").toUpperCase();
const species = pokemon => cleanId(pokemon?.species);

function aspectSet(pokemon) {
    return pokemonVisualAspects(pokemon);
}

export function breedingProfile(pokemonOrSpecies) {
    const pokemon = typeof pokemonOrSpecies === "string" ? { species: pokemonOrSpecies } : pokemonOrSpecies;
    const base = BREEDING_SPECIES[species(pokemon)];
    if (!base) return undefined;
    const aspects = aspectSet(pokemon);
    return base.forms.find(form => form.aspects.every(aspect => aspects.has(aspect))) || base;
}

function inheritedAspects(pokemon) {
    const present = aspectSet(pokemon), result = [];
    const definitions = [...new Set(INHERITED_FEATURES.map(name => POKEMON_ASPECT_FEATURES[name]
        || Object.values(POKEMON_ASPECT_FEATURES).find(feature => feature.keys?.includes(name))).filter(Boolean))];
    for (const feature of definitions) {
        if (feature.type === "choice") {
            for (const choice of feature.choices || []) {
                const aspect = String(feature.aspectFormat || "{{choice}}").replace("{{choice}}", choice);
                if (present.has(aspect) && !result.includes(aspect)) result.push(aspect);
            }
        } else if (feature.type === "flag") {
            const aspect = String(feature.aspect || feature.aspectFormat || feature.keys?.[0] || "");
            if (aspect && present.has(aspect) && !result.includes(aspect)) result.push(aspect);
        }
    }
    return result;
}

export function babyFor(pokemon) {
    let childSpecies = species(pokemon);
    let childAspects = inheritedAspects(pokemon);
    let profile = breedingProfile({ species: childSpecies, aspects: childAspects });
    const visited = new Set();
    while (profile?.preEvolution?.species && !visited.has(childSpecies)) {
        visited.add(childSpecies);
        childSpecies = profile.preEvolution.species;
        childAspects = [...new Set([...childAspects, ...(profile.preEvolution.aspects || [])])];
        profile = breedingProfile({ species: childSpecies, aspects: childAspects });
    }
    return profile ? { species: childSpecies, aspects: childAspects, profile } : undefined;
}

function hasGroup(profile, group) {
    return profile?.eggGroups?.includes(group);
}

export function breedingPair(left, right) {
    if (left?.neutered === true || right?.neutered === true) return undefined;
    const leftProfile = breedingProfile(left), rightProfile = breedingProfile(right);
    if (!leftProfile || !rightProfile || hasGroup(leftProfile, "undiscovered") || hasGroup(rightProfile, "undiscovered")) return undefined;
    const leftDitto = hasGroup(leftProfile, "ditto"), rightDitto = hasGroup(rightProfile, "ditto");
    if (leftDitto && rightDitto) return undefined;
    if (leftDitto || rightDitto) {
        const ancestor = leftDitto ? right : left;
        const ditto = leftDitto ? left : right;
        const baby = species(ancestor) === "manaphy"
            ? { species: "phione", aspects: [], profile: BREEDING_SPECIES.phione }
            : babyFor(ancestor);
        return baby?.profile ? { father: ancestor, mother: ditto, ancestor, ...baby } : undefined;
    }
    if (!leftProfile.eggGroups.some(group => rightProfile.eggGroups.includes(group))) return undefined;
    let father, mother;
    if (gender(left) === "MALE" && gender(right) === "FEMALE") [father, mother] = [left, right];
    else if (gender(right) === "MALE" && gender(left) === "FEMALE") [father, mother] = [right, left];
    else return undefined;
    const baby = babyFor(mother);
    return baby?.profile ? { father, mother, ancestor: mother, ...baby } : undefined;
}

export function possibleBreedingPairs(pokemon) {
    const result = [];
    for (let left = 0; left < pokemon.length; left++) {
        for (let right = left + 1; right < pokemon.length; right++) {
            const pair = breedingPair(pokemon[left], pokemon[right]);
            if (pair) result.push(pair);
        }
    }
    return result;
}

export function possibleBreedingChoices(pokemon) {
    const groups = new Map();
    for (const pair of possibleBreedingPairs(pokemon)) {
        const key = `${pair.species}|${[...(pair.aspects || [])].sort().join(",")}`;
        if (!groups.has(key)) groups.set(key, { species: pair.species, aspects: pair.aspects || [], pairs: [] });
        groups.get(key).pairs.push(pair);
    }
    for (const [first, second] of [["nidoranf", "nidoranm"], ["illumise", "volbeat"]]) {
        const firstKey = [...groups.keys()].find(key => key.startsWith(`${first}|`));
        const secondKey = [...groups.keys()].find(key => key.startsWith(`${second}|`));
        if (firstKey) groups.set(`${second}|`, { species: second, aspects: [], pairs: groups.get(firstKey).pairs });
        else if (secondKey) groups.set(`${first}|`, { species: first, aspects: [], pairs: groups.get(secondKey).pairs });
    }
    return [...groups.values()];
}

export function randomizedBreedingTicks(random = Math.random, config = BREEDING_CONFIG) {
    return config.minTicks + Math.floor(random() * (config.maxTicks - config.minTicks + 1));
}

export function hatchTicks(profile, config = BREEDING_CONFIG) {
    return Math.ceil(Math.max(1, Number(profile?.eggCycles) || 1) * 600 * config.hatchMultiplier);
}

export function inheritedIVs(pair, random = Math.random) {
    const result = Object.fromEntries(BREEDING_STAT_KEYS.map(stat => [stat, Math.floor(random() * 32)]));
    const remaining = [...BREEDING_STAT_KEYS];
    const powered = [pair.father, pair.mother].flatMap(parent => POWER_ITEMS[itemId(parent)] ? [{ parent, stat: POWER_ITEMS[itemId(parent)] }] : []);
    const first = powered.length ? pick(powered, random) : { parent: pick([pair.father, pair.mother], random), stat: pick(remaining, random) };
    result[first.stat] = Math.max(0, Math.min(31, Math.floor(Number(first.parent?.ivs?.[first.stat]) || 0)));
    remaining.splice(remaining.indexOf(first.stat), 1);
    const inheritedCount = [pair.father, pair.mother].some(parent => itemId(parent) === "destiny_knot") ? 5 : 3;
    while (remaining.length && BREEDING_STAT_KEYS.length - remaining.length < inheritedCount) {
        const stat = pick(remaining, random);
        remaining.splice(remaining.indexOf(stat), 1);
        const parent = pick([pair.father, pair.mother], random);
        result[stat] = Math.max(0, Math.min(31, Math.floor(Number(parent?.ivs?.[stat]) || 0)));
    }
    return result;
}

export function inheritedNature(pair, random = Math.random) {
    const holders = [pair.father, pair.mother].filter(parent => itemId(parent) === "everstone");
    return holders.length ? String(pick(holders, random).nature || "hardy").toLowerCase() : pick(NATURES, random);
}

export function inheritedBall(pair, random = Math.random) {
    let parent = pair.mother;
    if (species(pair.father) === species(pair.mother)) parent = pick([pair.father, pair.mother], random);
    if (species(pair.mother) === "ditto") parent = pair.father;
    const ball = cleanId(parent?.caughtBall || "poke_ball");
    return ["cherish_ball", "master_ball"].includes(ball) ? "poke_ball" : ball || "poke_ball";
}

export function inheritedAbility(pair, random = Math.random) {
    const pool = (pair.profile?.abilities || []).map(String);
    if (!pool.length) return "none";
    const old = cleanId(pair.ancestor?.ability);
    let inherited = pool.find(value => cleanId(value.replace(/^h:/, "")) === old) || pool[0];
    const hidden = inherited.startsWith("h:");
    const chance = hidden ? 0.6 : 0.8;
    if (random() >= chance) {
        const alternatives = pool.filter(value => value !== inherited);
        if (alternatives.length) inherited = pick(alternatives, random);
    }
    return inherited.replace(/^h:/, "");
}

function knownMoves(pokemon) {
    return [...(pokemon?.moves || []), ...(pokemon?.benchedMoves || []), ...(pokemon?.relearnableMoves || [])]
        .map(move => cleanId(typeof move === "string" ? move : move?.id)).filter(Boolean);
}

export function applyMirrorHerb(pokemon, accessibleMoves = knownMoves) {
    const available = new Set(pokemon.flatMap(parent => accessibleMoves(parent)));
    const changed = [];
    for (const target of pokemon) {
        if (itemId(target) !== "mirror_herb") continue;
        const baby = babyFor(target);
        const allowed = new Set(baby?.profile?.eggMoves || []);
        const known = new Set(knownMoves(target));
        const additions = [...available].filter(move => allowed.has(move) && !known.has(move));
        if (!additions.length) continue;
        if (!Array.isArray(target.benchedMoves)) target.benchedMoves = [];
        target.benchedMoves.push(...additions);
        changed.push(target);
    }
    return changed;
}

export function inheritedEggMoves(pair, accessibleMoves = knownMoves) {
    const allowed = new Set(pair.profile?.eggMoves || []), result = [];
    for (const id of [...accessibleMoves(pair.father), ...accessibleMoves(pair.mother)]) {
        if (allowed.has(id) && !result.includes(id)) result.push(id);
    }
    if (pair.species === "pichu" && [pair.father, pair.mother].some(parent => itemId(parent) === "light_ball")) {
        if (!result.includes("volttackle")) result.push("volttackle");
    }
    return result;
}

export function inheritedShiny(pair, baseRate, random = Math.random) {
    let odds = Math.max(1, Number(baseRate) || 4096) / BREEDING_CONFIG.shinyAlways;
    for (const parent of [pair.father, pair.mother]) if (parent?.isShiny) odds /= BREEDING_CONFIG.shinyCrystal;
    const fatherTrainer = String(pair.father?.originalTrainer?.uuid || pair.father?.originalTrainer?.name || "");
    const motherTrainer = String(pair.mother?.originalTrainer?.uuid || pair.mother?.originalTrainer?.name || "");
    if (fatherTrainer !== motherTrainer) odds /= BREEDING_CONFIG.shinyMasuda;
    return odds < 1 || Math.floor(random() * Math.max(1, Math.floor(odds))) === 0;
}
