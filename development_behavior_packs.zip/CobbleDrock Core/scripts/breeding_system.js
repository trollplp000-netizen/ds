import { ItemStack, system, world } from "@minecraft/server";
import { calculateMaxHp, speciesData } from "./battle_math.js";
import { CORE_CONFIG } from "./core_config.js";
import { MOVE_DATA } from "./move_registry.js";
import { markSpeciesCaptured } from "./capture_rate.js";
import { addPokemonToPlayerParty, generateRandomPokemon, generateUUID, loadPartyFromPlayer } from "./storage.js";
import { BREEDING_ABILITY_NAMES, BREEDING_POKE_BALL_NAMES } from "./breeding_display_data.js";
import {
    BREEDING_CONFIG, applyMirrorHerb, breedingProfile, hatchTicks, inheritedAbility, inheritedBall, inheritedEggMoves,
    inheritedIVs, inheritedNature, inheritedShiny, possibleBreedingChoices, possibleBreedingPairs, randomizedBreedingTicks
} from "./breeding_rules.js";

export const POKEMON_EGG_ITEM = "lota:pokemon_egg";
const EGG_PROPERTY = "lota:egg_v1";
const STATE_PREFIX = "lota:breed_v1:";
const HATCH_REDUCER_ABILITIES = new Set(["flamebody", "magmaarmor", "steamengine"]);

const clone = value => JSON.parse(JSON.stringify(value));
const cleanId = value => String(value || "").replace(/^.*:/, "").toLowerCase().replace(/[^a-z0-9_=-]/g, "");
const worldTick = () => {
    try { return Number(world.getAbsoluteTime()); } catch (error) { return Number(system.currentTick) || 0; }
};
const breedingKey = pastureKey => `${STATE_PREFIX}${String(pastureKey).replace(/^lota:pasture_v1:/, "")}`;
const EGG_IV_ROWS = Object.freeze([
    ["hp", "HP", "§a"],
    ["attack", "Attack", "§c"],
    ["defence", "Defense", "§6"],
    ["specialAttack", "Sp. Attack", "§d"],
    ["specialDefence", "Sp. Defense", "§e"],
    ["speed", "Speed", "§b"]
]);

function defaultState(pastureId) {
    const config = BREEDING_CONFIG;
    return { version: 1, pastureId, active: false, startedAt: -1, mirrorAt: worldTick(), requiredTicks: randomizedBreedingTicks(Math.random, config), eggs: [] };
}

function validPokemon(pokemon) {
    return pokemon && typeof pokemon === "object" && typeof pokemon.uuid === "string"
        && typeof pokemon.species === "string" && pokemon.ivs && Array.isArray(pokemon.moves);
}

function validState(state, pastureId) {
    const config = BREEDING_CONFIG;
    return state?.version === 1 && state.pastureId === pastureId && typeof state.active === "boolean"
        && Number.isFinite(state.startedAt) && Number.isInteger(state.requiredTicks)
        && (state.mirrorAt === undefined || Number.isFinite(state.mirrorAt))
        && state.requiredTicks > 0
        && Array.isArray(state.eggs) && state.eggs.length <= config.eggSlots
        && state.eggs.every(egg => typeof egg?.id === "string" && validPokemon(egg.pokemon)
            && Number.isInteger(egg.remainingTicks) && egg.remainingTicks > 0);
}

function readState(pastureKey, pastureId) {
    const config = BREEDING_CONFIG;
    try {
        const raw = world.getDynamicProperty(breedingKey(pastureKey));
        if (raw === undefined) return defaultState(pastureId);
        const state = JSON.parse(raw);
        if (validState(state, pastureId)) {
            let timingChanged = false;
            if (!Number.isFinite(state.mirrorAt)) {
                state.mirrorAt = worldTick();
                timingChanged = true;
            }
            if (state.requiredTicks < config.minTicks || state.requiredTicks > config.maxTicks) {
                state.startedAt = -1;
                state.requiredTicks = randomizedBreedingTicks(Math.random, config);
                timingChanged = true;
            }
            for (const egg of state.eggs) {
                const maximum = hatchTicks(breedingProfile(egg.pokemon), config);
                if (egg.remainingTicks > maximum) {
                    egg.remainingTicks = maximum;
                    timingChanged = true;
                }
            }
            if (timingChanged && !writeState(pastureKey, state)) return undefined;
            return state;
        }
        if (state?.version === 1 && typeof state.pastureId === "string" && state.pastureId !== pastureId) {
            return defaultState(pastureId);
        }
        console.warn(`[Breeding] Invalid state preserved for ${pastureKey}`);
    } catch (error) {
        console.warn(`[Breeding] Unreadable state preserved for ${pastureKey}: ${error}`);
    }
    return undefined;
}

function writeState(pastureKey, state) {
    const key = breedingKey(pastureKey);
    let previous;
    try {
        previous = world.getDynamicProperty(key);
        const serialized = state === undefined ? undefined : JSON.stringify(state);
        world.setDynamicProperty(key, serialized);
        if (world.getDynamicProperty(key) === serialized) return true;
    } catch (error) {
        console.warn(`[Breeding] State write failed for ${pastureKey}: ${error}`);
    }
    try { world.setDynamicProperty(key, previous); } catch (restoreError) {}
    return false;
}

function moveRecord(id) {
    const move = MOVE_DATA[id];
    return move ? { id, pp: move.pp, maxPp: move.pp } : undefined;
}

function accessibleMoveIds(pokemon) {
    const result = [], append = raw => {
        const id = cleanId(typeof raw === "string" ? raw : raw?.id);
        if (id && !result.includes(id)) result.push(id);
    };
    for (const move of pokemon?.moves || []) append(move);
    for (const move of pokemon?.benchedMoves || []) append(move);
    for (const move of pokemon?.relearnableMoves || []) append(move);
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    for (const move of speciesData(pokemon)?.levelMoves || []) {
        if (Math.floor(Number(move?.level) || 0) <= level) append(move);
    }
    return result;
}

function createEgg(pair, childSpecies = pair.species, childAspects = pair.aspects) {
    const config = BREEDING_CONFIG;
    const pokemon = generateRandomPokemon(`lota:${childSpecies}`, 1);
    const profile = breedingProfile({ species: childSpecies, aspects: childAspects }) || pair.profile;
    pokemon.ivs = inheritedIVs(pair);
    pokemon.nature = inheritedNature(pair);
    pokemon.mintedNature = pokemon.nature;
    pokemon.caughtBall = inheritedBall(pair);
    pokemon.ability = inheritedAbility({ ...pair, profile });
    pokemon.isShiny = inheritedShiny(pair, CORE_CONFIG.shinyRate);
    pokemon.aspects = [...new Set([
        "normal", String(pokemon.gender || "").toLowerCase(), ...childAspects, ...(pokemon.isShiny ? ["shiny"] : [])
    ].filter(Boolean))];
    const inherited = inheritedEggMoves({ ...pair, species: childSpecies, profile }, accessibleMoveIds);
    const initial = pokemon.moves.map(move => cleanId(move.id));
    const learned = [...new Set([...initial, ...inherited])].filter(id => MOVE_DATA[id]);
    pokemon.moves = learned.slice(-4).map(moveRecord).filter(Boolean);
    pokemon.benchedMoves = learned.slice(0, -4);
    pokemon.maxHp = calculateMaxHp(pokemon);
    pokemon.currentHp = pokemon.maxHp;
    pokemon.friendship = 120;
    pokemon.statusCondition = "NONE";
    return { id: generateUUID(), pokemon, remainingTicks: hatchTicks(profile, config) };
}

function resolvedPokemon(record, resolveMemberPokemon) {
    const result = [];
    for (const member of record.members) {
        const pokemon = resolveMemberPokemon(member);
        if (validPokemon(pokemon)) result.push(pokemon);
    }
    return result;
}

function supportedPairs(record, resolveMemberPokemon) {
    return possibleBreedingPairs(resolvedPokemon(record, resolveMemberPokemon))
        .filter(pair => !!speciesData(pair.species));
}

export function tickPastureBreeding(pastureKey, record, resolveMemberPokemon, persistMemberPokemon = undefined) {
    const config = BREEDING_CONFIG;
    const state = readState(pastureKey, record.id);
    if (!state) return false;
    const resolved = record.members.map(member => ({ member, pokemon: resolveMemberPokemon(member) }))
        .filter(entry => validPokemon(entry.pokemon));
    const now = worldTick();
    let changed = false;
    if (now - state.mirrorAt >= config.mirrorHerbTicks) {
        const learned = new Set(applyMirrorHerb(resolved.map(entry => entry.pokemon), accessibleMoveIds));
        let persisted = true;
        if (typeof persistMemberPokemon === "function") {
            for (const entry of resolved) {
                if (learned.has(entry.pokemon) && !persistMemberPokemon(entry.member, entry.pokemon)) persisted = false;
            }
        }
        if (learned.size === 0 || persisted || typeof persistMemberPokemon !== "function") {
            state.mirrorAt = now;
            changed = true;
        }
    }
    const choices = possibleBreedingChoices(resolved.map(entry => entry.pokemon))
        .filter(choice => !!speciesData(choice.species));
    if (!state.active || choices.length === 0) {
        if (state.startedAt !== -1) { state.startedAt = -1; changed = true; }
        return !changed || writeState(pastureKey, state);
    }
    if (state.startedAt < 0) {
        state.startedAt = worldTick();
        return writeState(pastureKey, state);
    }
    if (state.eggs.length >= config.eggSlots) return !changed || writeState(pastureKey, state);
    while (state.eggs.length < config.eggSlots && now - state.startedAt >= state.requiredTicks) {
        const choice = choices[Math.floor(Math.random() * choices.length)];
        const pair = choice.pairs[Math.floor(Math.random() * choice.pairs.length)];
        state.eggs.push(createEgg(pair, choice.species, choice.aspects));
        state.startedAt += state.requiredTicks;
        state.requiredTicks = randomizedBreedingTicks(Math.random, config);
        changed = true;
    }
    if (changed) state.startedAt = now;
    return !changed || writeState(pastureKey, state);
}

export function pastureBreedingView(pastureKey, record, resolveMemberPokemon) {
    const state = readState(pastureKey, record.id);
    if (!state) return undefined;
    const pairs = supportedPairs(record, resolveMemberPokemon);
    const remainingTicks = state.startedAt < 0 ? state.requiredTicks
        : Math.max(0, state.requiredTicks - (worldTick() - state.startedAt));
    return { active: state.active, eggs: clone(state.eggs), compatiblePairs: pairs.length, remainingTicks };
}

export function togglePastureBreeding(pastureKey, record) {
    const state = readState(pastureKey, record.id);
    if (!state) return undefined;
    state.active = !state.active;
    state.startedAt = -1;
    return writeState(pastureKey, state) ? state.active : undefined;
}

function titleCase(value) {
    return String(value || "")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

function displayForm(pokemon) {
    const explicit = cleanId(pokemon?.form);
    if (explicit && !["normal", "standard", "base"].includes(explicit)) return titleCase(explicit);
    const aspects = new Set((pokemon?.aspects || []).map(cleanId));
    for (const [aspect, name] of [
        ["alolan", "Alolan"], ["galarian", "Galarian"], ["hisuian", "Hisuian"], ["paldean", "Paldean"]
    ]) if (aspects.has(aspect)) return name;
    const named = [...aspects].find(aspect => /[-_](?:form|forme|style)$/.test(aspect));
    return named ? titleCase(named.replace(/[-_](?:form|forme|style)$/, "")) : undefined;
}

function eggSpeciesName(pokemon) {
    return speciesData(pokemon)?.name || titleCase(pokemon?.species) || "Pokémon";
}

function eggIvValues(pokemon) {
    return EGG_IV_ROWS.map(([key]) => Math.max(0, Math.min(31, Math.floor(Number(pokemon?.ivs?.[key]) || 0))));
}

export function eggDisplayName(egg) {
    const pokemon = egg?.pokemon || {};
    const values = eggIvValues(pokemon);
    let name = `${eggSpeciesName(pokemon)} Egg`;
    const aspects = new Set((pokemon.aspects || []).map(cleanId));
    if (pokemon.isShiny) name += aspects.has("radiant-radiant") ? " §b★§r" : " §e★§r";
    if (values.every(value => value === 31)) name += " §b🛆§r";
    else if (values.every(value => value === 0)) name += " §c⚠§r";
    const gender = String(egg?.displayGender || "").toUpperCase();
    if (gender === "MALE") name += " §b♂§r";
    else if (gender === "FEMALE") name += " §d♀§r";
    return name;
}

export function eggLore(egg) {
    const pokemon = egg?.pokemon || {};
    const total = Math.max(0, Math.ceil(Number(egg?.remainingTicks) / 20));
    const minutes = Math.floor(total / 60), seconds = total % 60;
    const nature = titleCase(pokemon.nature);
    const abilityId = cleanId(pokemon.ability);
    const ability = BREEDING_ABILITY_NAMES[abilityId] || titleCase(abilityId);
    const form = displayForm(pokemon);
    const ballId = cleanId(pokemon.caughtBall);
    const ball = BREEDING_POKE_BALL_NAMES[ballId] || titleCase(ballId);
    const values = eggIvValues(pokemon);
    const lore = [
        `§7Time Remaining: ${minutes}m ${seconds}s§r`,
        " ",
        `§eNature: §7${nature}§r`,
        `§eAbility: §7${ability}§r`
    ];
    if (form) lore.push(`§6Form: §7${form}§r`);
    lore.push(`§6Pokéball: §7${ball}§r`, " ");
    for (let index = 0; index < EGG_IV_ROWS.length; index++) {
        const [, label, color] = EGG_IV_ROWS[index];
        lore.push(`${color}${label}: §7${values[index]}§r`);
    }
    lore.push(`§7Average IV: ${Math.floor(values.reduce((sum, value) => sum + value, 0) / 6)}§r`);
    return lore;
}

function applyEggPresentation(item, egg) {
    item.nameTag = eggDisplayName(egg);
    item.setLore(eggLore(egg));
    return item;
}

function eggItem(egg) {
    const item = new ItemStack(POKEMON_EGG_ITEM, 1);
    item.setDynamicProperty(EGG_PROPERTY, JSON.stringify(egg));
    return applyEggPresentation(item, egg);
}

function deliverPastureEgg(container, pastureKey, record, index) {
    const state = readState(pastureKey, record.id);
    const egg = state?.eggs?.[index];
    if (!egg) return { success: false, reason: "missing" };
    let target = -1;
    try {
        for (let slot = 0; slot < container.size; slot++) if (!container.getItem(slot)) { target = slot; break; }
    } catch (error) {
        console.warn(`[Breeding] Egg collection failed: ${error}`);
        return { success: false, reason: "inventory" };
    }
    if (target < 0) return { success: false, reason: "full" };
    state.eggs.splice(index, 1);
    if (!writeState(pastureKey, state)) return { success: false, reason: "save" };
    try {
        container.setItem(target, eggItem(egg));
    } catch (error) {
        state.eggs.splice(index, 0, egg);
        writeState(pastureKey, state);
        console.warn(`[Breeding] Egg delivery failed and pasture state was restored: ${error}`);
        return { success: false, reason: "inventory" };
    }
    return { success: true, egg };
}

export function collectPastureEgg(player, pastureKey, record, index) {
    let container;
    try { container = player.getComponent("minecraft:inventory")?.container; } catch (error) {}
    return container ? deliverPastureEgg(container, pastureKey, record, index)
        : { success: false, reason: "inventory" };
}

export function pullPastureEgg(container, pastureKey, record) {
    if (!BREEDING_CONFIG.allowHoppers || !container) return { success: false, reason: "disabled" };
    return deliverPastureEgg(container, pastureKey, record, 0);
}

export function destroyPastureBreeding(pastureKey, pastureId) {
    const state = readState(pastureKey, pastureId);
    const drops = state?.eggs?.map(eggItem) || [];
    return writeState(pastureKey, undefined) ? drops : undefined;
}

function readEgg(stack) {
    if (stack?.typeId !== POKEMON_EGG_ITEM) return undefined;
    try {
        const egg = JSON.parse(stack.getDynamicProperty(EGG_PROPERTY));
        return typeof egg?.id === "string" && validPokemon(egg.pokemon) && Number.isInteger(egg.remainingTicks) ? egg : undefined;
    } catch (error) { return undefined; }
}

function hasHatchReducerAbility(player) {
    return loadPartyFromPlayer(player).some(pokemon => HATCH_REDUCER_ABILITIES.has(cleanId(pokemon?.ability)));
}

function hatch(player, container, slot, stack, egg) {
    const pokemon = clone(egg.pokemon);
    pokemon.uuid = generateUUID();
    try { container.setItem(slot, undefined); } catch (error) { return false; }
    const result = addPokemonToPlayerParty(player, pokemon);
    if (!result.success) {
        try { container.setItem(slot, stack); } catch (error) { console.warn(`[Breeding] Ready egg restoration failed: ${error}`); }
        return false;
    }
    try { markSpeciesCaptured(player, pokemon); } catch (error) { console.warn(`[Breeding] Pokédex update failed after hatching: ${error}`); }
    try { player.playSound("random.levelup", { pitch: 1.25, volume: 1 }); } catch (error) {}
    try {
        for (let i = 0; i < 8; i++) player.dimension.spawnParticle("minecraft:totem_particle", {
            x: player.location.x + (Math.random() - 0.5), y: player.location.y + 0.5 + Math.random(), z: player.location.z + (Math.random() - 0.5)
        });
    } catch (error) {}
    try { player.sendMessage({ translate: "cobbledrock.egg.hatched", with: [pokemon.nickname || cleanId(pokemon.species)] }); } catch (error) {}
    return true;
}

function tickPlayerEggs(player) {
    const config = BREEDING_CONFIG;
    let container;
    try { container = player.getComponent("minecraft:inventory")?.container; } catch (error) { return; }
    if (!container) return;
    const decrement = hasHatchReducerAbility(player) ? 40 : 20;
    for (let slot = 0; slot < container.size; slot++) {
        const stack = container.getItem(slot), egg = readEgg(stack);
        if (!egg) continue;
        egg.remainingTicks = Math.min(egg.remainingTicks, hatchTicks(breedingProfile(egg.pokemon), config));
        const ready = egg.remainingTicks <= 0;
        if (!ready) egg.remainingTicks = Math.max(0, egg.remainingTicks - decrement);
        if (ready && hatch(player, container, slot, stack, egg)) continue;
        try {
            stack.setDynamicProperty(EGG_PROPERTY, JSON.stringify(egg));
            applyEggPresentation(stack, egg);
            container.setItem(slot, stack);
        } catch (error) { console.warn(`[Breeding] Egg timer update failed: ${error}`); }
    }
}

system.runInterval(() => {
    for (const player of world.getAllPlayers()) tickPlayerEggs(player);
}, 20);
