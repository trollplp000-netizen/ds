import { SPECIES_DATA } from "./battle_species.js";
import { BERRY_IDS } from "./berry_mint_data.js";
import { SPECIAL_FORM_HELD_ITEMS } from "./special_forms.js";
import { itemTexturePath } from "./tm_item_textures.js";
import {
    HELD_ITEM_HUD_CODES,
    HELD_ITEM_HUD_CODE_BY_TEXTURE,
    HELD_ITEM_HUD_GENERIC_CODE
} from "./held_item_hud_codes.js";

const BERRIES = BERRY_IDS.map(id => ({
    itemId: `lota:${id}`,
    texture: `textures/items/${id}`
})).concat({ itemId: "lota:berry_juice", texture: "textures/items/berry_juice" });

const TYPE_GEMS = [
    "bug_gem",
    "dark_gem",
    "dragon_gem",
    "electric_gem",
    "fairy_gem",
    "fighting_gem",
    "fire_gem",
    "flying_gem",
    "ghost_gem",
    "grass_gem",
    "ground_gem",
    "ice_gem",
    "normal_gem",
    "poison_gem",
    "psychic_gem",
    "rock_gem",
    "steel_gem",
    "water_gem"
].map(id => ({ itemId: `lota:${id}`, texture: `textures/items/kanto_source_items/${id}` }));

const EVOLUTION_HELD_ITEMS = [
    "deep_sea_scale",
    "deep_sea_tooth",
    "dragon_scale",
    "kings_rock",
    "metal_coat",
    "prism_scale",
    "upgrade",
    "dubious_disc",
    "oval_stone",
    "reaper_cloth",
    "electirizer",
    "magmarizer",
    "protector",
    "whipped_dream",
    "sachet",
    "razor_fang",
    "razor_claw",
    "black_augurite",
    "peat_block",
    "shell_helmet",
    "cracked_pot",
    "chipped_pot",
    "unremarkable_teacup",
    "masterpiece_teacup",
    "strawberry_sweet",
    "love_sweet",
    "berry_sweet",
    "clover_sweet",
    "flower_sweet",
    "ribbon_sweet",
    "star_sweet"
].map(id => ({ itemId: `lota:${id}`, texture: `textures/items/evolution/${id}` }));

const EXPERIENCE_HELD_ITEMS = [
    { itemId: "lota:exp_share", texture: "textures/items/held_items/exp_share" }
];

const FORM_CHANGE_HELD_ITEMS = SPECIAL_FORM_HELD_ITEMS.map(id => ({
    itemId: `lota:${id}`,
    texture: `textures/items/special_forms/${id}`
}));

const VANILLA_HELD_ITEMS = [
    { itemId: "minecraft:bone", texture: "textures/items/bone" },
    { itemId: "minecraft:snowball", texture: "textures/items/snowball" }
];

const MEGA_STONES = [...new Set(
    Object.values(SPECIES_DATA)
        .map(record => String(record?.megaStone || ""))
        .filter(Boolean)
)].sort().map(id => ({ itemId: `lota:${id}`, texture: `textures/items/mega/${id}` }));

export const HELD_ITEMS = Object.freeze([
    ...BERRIES,
    ...TYPE_GEMS,
    ...EVOLUTION_HELD_ITEMS,
    ...MEGA_STONES,
    ...VANILLA_HELD_ITEMS,
    ...EXPERIENCE_HELD_ITEMS,
    ...FORM_CHANGE_HELD_ITEMS
].map((entry, index) => Object.freeze({
    ...entry,
    hudCode: HELD_ITEM_HUD_CODES[entry.itemId] || String(index + 1).padStart(2, "0")
})));

const HELD_ITEM_BY_ID = new Map(HELD_ITEMS.map(entry => [entry.itemId, entry]));

export function normalizeHeldItemId(value) {
    const raw = String(value || "").trim().toLowerCase();
    if (!raw) return "";
    if (raw.startsWith("minecraft:")) return raw;
    return `lota:${raw.replace(/^cobblemon:/, "").replace(/^lota:/, "")}`;
}

const CONTAINER_HELD_ITEMS = Object.freeze([
    "shulker_box",
    "white_shulker_box",
    "orange_shulker_box",
    "magenta_shulker_box",
    "light_blue_shulker_box",
    "yellow_shulker_box",
    "lime_shulker_box",
    "pink_shulker_box",
    "gray_shulker_box",
    "light_gray_shulker_box",
    "cyan_shulker_box",
    "purple_shulker_box",
    "blue_shulker_box",
    "brown_shulker_box",
    "green_shulker_box",
    "red_shulker_box",
    "black_shulker_box"
]);

const CONTAINER_HELD_ITEM_SET = new Set(CONTAINER_HELD_ITEMS);

export function isBlacklistedHeldItem(value) {
    const bare = String(value || "").trim().toLowerCase().replace(/^[a-z_]+:/, "");
    return bare ? CONTAINER_HELD_ITEM_SET.has(bare) : false;
}

export function isHoldableItem(value) {
    if (!String(value || "").trim()) return false;
    return !isBlacklistedHeldItem(value);
}

export function heldItemDefinition(value) {
    return HELD_ITEM_BY_ID.get(normalizeHeldItemId(value));
}

export function isAllowedHeldItem(value) {
    return !!heldItemDefinition(value);
}

export function heldItemHudCode(value) {
    const id = normalizeHeldItemId(value);
    if (!id) return "";
    const direct = HELD_ITEM_HUD_CODES[id];
    if (direct) return direct;
    const texture = heldItemIconPath(id);
    const byTexture = texture ? HELD_ITEM_HUD_CODE_BY_TEXTURE[texture] : undefined;
    return byTexture || heldItemDefinition(value)?.hudCode || HELD_ITEM_HUD_GENERIC_CODE;
}

export function heldItemPartyHudCode(value) {
    const id = normalizeHeldItemId(value);
    if (!id) return "";
    return HELD_ITEM_BY_ID.get(id)?.hudCode || HELD_ITEM_HUD_GENERIC_CODE;
}

export function heldItemTexturePath(value) {
    return heldItemDefinition(value)?.texture;
}

export function heldItemIconPath(value) {
    const registered = heldItemTexturePath(value);
    if (registered) return registered;
    const id = normalizeHeldItemId(value);
    if (!id) return undefined;
    return itemTexturePath(id);
}
