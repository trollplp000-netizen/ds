import { ItemLockMode, ItemStack, system, world } from "@minecraft/server";
import { shiftSelectedPartySlot } from "./pokemon_compass.js";
import { hasChosenStarter } from "./starter_selection.js";
import { isPokedexItem } from "./pokedex_system.js";


const LEFT_ID = "lota:party_slot_left";
const RIGHT_ID = "lota:party_slot_right";
const HOTBAR_SIZE = 9;
const CLICK_COOLDOWN_TICKS = 4;
const SWEEP_INTERVAL_TICKS = 40;

const SAVED = new Map();
const SNEAK_STATES = new Map();
const CLICK_COOLDOWNS = new Map();
const DEX_SUPPRESSED = new Set();

function isArrow(item) {
    return item?.typeId === LEFT_ID || item?.typeId === RIGHT_ID;
}

function inBattle(player) {
    try { return player.hasTag("lota:battle_player"); }
    catch (error) { return false; }
}

function containerOf(player) {
    try { return player.getComponent("minecraft:inventory")?.container; }
    catch (error) { return undefined; }
}

function holdingPokedex(player, container) {
    try {
        const box = container ?? containerOf(player);
        const held = box?.getItem(player.selectedSlotIndex);
        return !!held && isPokedexItem(held.typeId);
    } catch (error) {
        return false;
    }
}

function makeArrow(typeId) {
    const arrow = new ItemStack(typeId, 1);
    arrow.lockMode = ItemLockMode.slot;
    return arrow;
}

function showArrows(player) {
    if (SAVED.has(player.id) || inBattle(player)) return;
    if (!hasChosenStarter(player)) return;
    const container = containerOf(player);
    if (!container) return;
    if (holdingPokedex(player, container)) return;

    const selected = player.selectedSlotIndex;
    const leftSlot = (selected + HOTBAR_SIZE - 1) % HOTBAR_SIZE;
    const rightSlot = (selected + 1) % HOTBAR_SIZE;

    const entries = [];
    for (const [slot, typeId] of [[leftSlot, LEFT_ID], [selected, null], [rightSlot, RIGHT_ID]]) {
        const current = container.getItem(slot);
        entries.push({ slot, item: isArrow(current) ? undefined : current });
        container.setItem(slot, typeId ? makeArrow(typeId) : undefined);
    }
    SAVED.set(player.id, { entries });
}

function giveBack(player, container, item) {
    if (!item) return;
    const leftover = container.addItem(item);
    if (leftover) {
        try { player.dimension.spawnItem(leftover, player.location); } catch (error) {}
    }
}

function hideArrows(player) {
    const state = SAVED.get(player.id);
    if (!state) return;
    SAVED.delete(player.id);
    const container = containerOf(player);
    if (!container) return;

    for (const { slot, item } of state.entries) {
        const current = container.getItem(slot);
        if (!current || isArrow(current)) {
            container.setItem(slot, item);
        } else {
            giveBack(player, container, item);
        }
    }
}

function sweepStrayArrows(player) {
    if (SAVED.has(player.id)) return;
    const container = containerOf(player);
    if (!container) return;
    for (let slot = 0; slot < container.size; slot++) {
        if (isArrow(container.getItem(slot))) container.setItem(slot, undefined);
    }
}

function handleClick(player, itemStack) {
    if (!isArrow(itemStack)) return;
    const tick = system.currentTick;
    if ((CLICK_COOLDOWNS.get(player.id) ?? -CLICK_COOLDOWN_TICKS) + CLICK_COOLDOWN_TICKS > tick) return;
    CLICK_COOLDOWNS.set(player.id, tick);

    shiftSelectedPartySlot(player, itemStack.typeId === LEFT_ID ? -1 : 1);
}

world.afterEvents.itemUse.subscribe(event => handleClick(event.source, event.itemStack));
world.afterEvents.playerInteractWithBlock.subscribe(event => handleClick(event.player, event.itemStack));

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        if (!player.isValid) continue;
        const sneaking = !!player.isSneaking && !inBattle(player);
        const was = SNEAK_STATES.get(player.id) || false;
        if (sneaking && !was) {
            if (holdingPokedex(player)) DEX_SUPPRESSED.add(player.id);
            else showArrows(player);
        } else if (sneaking) {
            const dex = holdingPokedex(player);
            if (dex && SAVED.has(player.id)) {
                hideArrows(player);
                DEX_SUPPRESSED.add(player.id);
            } else if (!dex && DEX_SUPPRESSED.has(player.id)) {
                DEX_SUPPRESSED.delete(player.id);
                showArrows(player);
            }
        } else {
            DEX_SUPPRESSED.delete(player.id);
            if (was || SAVED.has(player.id)) hideArrows(player);
        }
        SNEAK_STATES.set(player.id, sneaking);
    }
}, 1);

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        if (player.isValid) sweepStrayArrows(player);
    }
}, SWEEP_INTERVAL_TICKS);

world.afterEvents.playerSpawn.subscribe(event => {
    system.run(() => { if (event.player?.isValid) sweepStrayArrows(event.player); });
});

world.beforeEvents.playerLeave.subscribe(event => {
    const player = event.player;
    system.run(() => { try { if (player?.isValid) hideArrows(player); } catch (error) {} });
});

world.afterEvents.playerLeave.subscribe(event => {
    SAVED.delete(event.playerId);
    SNEAK_STATES.delete(event.playerId);
    CLICK_COOLDOWNS.delete(event.playerId);
    DEX_SUPPRESSED.delete(event.playerId);
});
