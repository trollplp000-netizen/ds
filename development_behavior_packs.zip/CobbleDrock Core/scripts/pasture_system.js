import { ItemStack, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { generateUUID, savePCToPlayer, savePokemonToEntity, subscribePokemonStorageSaved, PC_BOX_COUNT, PC_BOX_SIZE } from "./storage.js";
import { pokemonFormTexture } from "./form_ui_textures.js";
import { battleEntityType } from "./mega_evolution.js";
import { applyPokemonSkinToEntity } from "./pokemon_skin_api.js";
import { spawnColoredFlame } from "./particle_utils.js";
import { PASTURE_PROFILES } from "./pasture_profiles.js";
import { attachChestScreen, chestScreenActive, closeChestScreen, openChestScreen, registerChestScreen, registerFixedAnchor } from "./chest_ui.js";
import { spriteSheetTexture } from "./pc_system.js";
import { PASTURE_CHEST_BTN, PASTURE_CHEST_CAP, PASTURE_CHEST_IC, PASTURE_CHEST_SLOT_COUNT, PASTURE_CHEST_STATE_SLOT, PASTURE_CHEST_TB, PASTURE_CHEST_TITLE } from "./pasture_chest_layout.js";
import {
    collectPastureEgg, destroyPastureBreeding, pastureBreedingView,
    pullPastureEgg, tickPastureBreeding, togglePastureBreeding
} from "./breeding_system.js";
import { PASTURE, PASTURE_PREFIX, PASTURE_TAG, pastureKey, canViewPasture, inPastureBounds,
    pastureAppearance, pastureBreedingSnapshot, mergePasturePendingMoves, validPastureRecord, writePastureRecord, resolvePastureMember,
    pasturablePokemon, findPasturePosition } from "./pasture_state.js";

const BLOCK = "lota:pasture", TOP = "lota:pasture_top", LINK = "lota:pasture_link_v1";
const CHEST_KEY = "pasture", ANCHOR_TYPE = "lota:pasture_anchor", MENU_FORM_TAG = "lota:menu_form";
const records = new Map(), sessions = new Map(), queuedOwners = new Set();
const loaded = new Map();
let initialized = false;
const clone = value => JSON.parse(JSON.stringify(value));
const playerById = id => world.getAllPlayers().find(player => player.id === id);
function blockAt(dimension, location) { try { return dimension.getBlock(location); } catch { return undefined; } }
function entityById(id) { try { return id ? world.getEntity(id) : undefined; } catch { return undefined; } }
function tell(player, key) { try { player.onScreenDisplay.setActionBar({ translate: key }); } catch {} }
function nameText(pokemon) {
    return pokemon?.nickname ? { text: pokemon.nickname } : { translate: `cobblemon.species.${String(pokemon?.species || "unknown").replace(/^.*:/, "")}.name` };
}
function pcSnapshot(player) {
    try {
        const party = JSON.parse(player.getDynamicProperty("lota:party_data") || "[]");
        if (!Array.isArray(party)) return undefined;
        const boxes = [], pokemon = new Map();
        for (let box = 0; box < PC_BOX_COUNT; box++) {
            const entries = JSON.parse(player.getDynamicProperty(`lota:pc_box_${box}`) || "[]");
            if (!Array.isArray(entries)) return undefined;
            boxes.push(entries);
            for (const entry of entries) if (entry?.uuid) pokemon.set(entry.uuid, entry);
        }
        return { boxes, pokemon, partyIds: new Set(party.filter(Boolean).map(entry => entry.uuid)) };
    } catch { return undefined; }
}
function initialize() {
    if (initialized) return;
    initialized = true;
    for (const key of world.getDynamicPropertyIds()) {
        if (!key.startsWith(PASTURE_PREFIX)) continue;
        try {
            const record = JSON.parse(world.getDynamicProperty(key));
            if (validPastureRecord(record, key)) records.set(key, record);
            else console.warn(`[Pasture] Invalid record preserved: ${key}`);
        } catch { console.warn(`[Pasture] Unreadable record preserved: ${key}`); }
    }
}
function save(key, record) {
    if (!writePastureRecord(world, key, record)) return false;
    if (record) records.set(key, record); else records.delete(key);
    return true;
}
function stopEntity(member) {
    const entity = entityById(member.entityId) || loaded.get(member.lease);
    loaded.delete(member.lease);
    try {
        if (entity?.isValid) {
            const at = { ...entity.location }, dimension = entity.dimension;
            entity.remove();
            spawnColoredFlame(dimension, at);
        }
    } catch {}
}
function removeMembers(key, predicate) {
    const record = records.get(key);
    if (!record) return true;
    const removed = record.members.filter(predicate);
    if (!removed.length) return true;
    const next = { ...record, members: record.members.filter(member => !predicate(member)) };
    if (!save(key, next)) return false;
    for (const member of removed) stopEntity(member);
    updateScreen(key);
    return true;
}
function currentBlock(record) { try { return blockAt(world.getDimension(record.dimensionId), record.location); } catch { return undefined; } }
function setBlockState(block, name, value) {
    try {
        if (block.permutation.getState(name) !== value) block.setPermutation(block.permutation.withState(name, value));
    } catch (error) {}
}
function updateScreen(key) {
    const record = records.get(key);
    if (!record) return;
    const bottom = currentBlock(record);
    if (bottom?.typeId !== BLOCK) return;
    const breeding = pastureBreedingView(key, record, breedingPokemon);
    setBlockState(bottom, "lota:has_egg", !!breeding?.eggs.length);
    setBlockState(bottom, "lota:breeding_activated", !!breeding?.active);
    const on = [...sessions.values()].some(session => session.key === key && (!session.chest || session.lit));
    for (const block of [bottom, blockAt(bottom.dimension, { ...record.location, y: record.location.y + 1 })]) {
        if (![BLOCK, TOP].includes(block?.typeId)) continue;
        setBlockState(block, "lota:active", on);
    }
}
function close(playerId) {
    const session = sessions.get(playerId);
    sessions.delete(playerId);
    if (session?.chest) { try { closeChestScreen(playerId); } catch {} }
    if (session) { updateScreen(session.key); try { playerById(playerId)?.playSound("cobblemon.pc.off"); } catch {} }
}
function destroyPasture(key) {
    const record = records.get(key);
    if (!record) return world.getDynamicProperty(key) === undefined;
    if (!save(key, undefined)) return false;
    const eggDrops = destroyPastureBreeding(key, record.id);
    if (Array.isArray(eggDrops)) {
        try {
            const dimension = world.getDimension(record.dimensionId);
            for (const item of eggDrops) dimension.spawnItem(item, {
                x: record.location.x + 0.5, y: record.location.y + 0.5, z: record.location.z + 0.5
            });
        } catch (error) { console.warn(`[Pasture] Egg inventory drop failed: ${error}`); }
    }
    for (const member of record.members) stopEntity(member);
    for (const [id, session] of [...sessions]) {
        if (session.key !== key) continue;
        sessions.delete(id);
        if (session.chest) { try { closeChestScreen(id); } catch {} }
    }
    try { removeAnchors(world.getDimension(record.dimensionId), record.location); } catch {}
    return true;
}
function reconcileOwner(player) {
    const snapshot = pcSnapshot(player);
    if (!snapshot) return;
    for (const [key, record] of records) {
        if (!record.members.some(member => member.ownerId === player.id)) continue;
        const removed = [], next = clone(record);
        next.members = next.members.filter(member => {
            if (member.ownerId !== player.id) return true;
            let pokemon = snapshot.pokemon.get(member.uuid);
            if (!pasturablePokemon(pokemon, snapshot.partyIds, false)) { removed.push(member); return false; }
            if (member.pendingMirrorMoves?.length) {
                const merged = mergePasturePendingMoves(pokemon, member.pendingMirrorMoves);
                if (merged.changed) {
                    const boxIndex = snapshot.boxes.findIndex(box => box.some(value => value?.uuid === member.uuid));
                    const slot = boxIndex < 0 ? -1 : snapshot.boxes[boxIndex].findIndex(value => value?.uuid === member.uuid);
                    if (slot < 0) return true;
                    const box = snapshot.boxes[boxIndex].slice();
                    box[slot] = merged.pokemon;
                    if (!savePCToPlayer(player, boxIndex, box)) return true;
                    snapshot.boxes[boxIndex] = box;
                    snapshot.pokemon.set(member.uuid, merged.pokemon);
                    pokemon = merged.pokemon;
                }
                delete member.pendingMirrorMoves;
            }
            member.appearance = pastureAppearance(pokemon);
            member.breeding = pastureBreedingSnapshot(pokemon);
            return true;
        });
        if (JSON.stringify(next) !== JSON.stringify(record) && !save(key, next)) continue;
        for (const member of removed) stopEntity(member);
        for (const member of next.members.filter(member => member.ownerId === player.id)) {
            const entity = entityById(member.entityId);
            if (entity?.isValid) applyAppearance(entity, member);
        }
        updateScreen(key);
    }
}
function queueOwner(player) {
    if (queuedOwners.has(player.id)) return;
    queuedOwners.add(player.id);
    system.run(() => { queuedOwners.delete(player.id); if (player.isValid) { initialize(); reconcileOwner(player); } });
}
function profileOf(pokemon) { return PASTURE_PROFILES[battleEntityType(pokemon)]; }
function occupiedIn(dimension) {
    return dimension.getEntities({ families: ["pokemon"] }).filter(entity => entity.isValid).map(entity => {
        const profile = PASTURE_PROFILES[entity.typeId] || { width: 1, height: 1 };
        return { ...entity.location, ...profile };
    });
}
function safePosition(record, pokemon) {
    const profile = profileOf(pokemon);
    if (!profile) return undefined;
    const dimension = world.getDimension(record.dimensionId);
    return findPasturePosition(record, profile, location => blockAt(dimension, location), occupiedIn(dimension));
}
function applyAppearance(entity, member) {
    if (!savePokemonToEntity(entity, member.appearance)) throw new Error("Pasture appearance write failed");
    applyPokemonSkinToEntity(entity, member.appearance);
    entity.nameTag = `§f${member.appearance.nickname || member.appearance.species.replace(/^.*:/, "")} Lv. ${member.appearance.level}§r`;
}
function spawnMember(key, lease) {
    const record = records.get(key), member = record?.members.find(member => member.lease === lease);
    if (!member || member.entityId) return false;
    const location = safePosition(record, member.appearance);
    if (!location) return false;
    let entity;
    try {
        const dimension = world.getDimension(record.dimensionId);
        entity = dimension.spawnEntity(battleEntityType(member.appearance), {
            x: record.location.x + 0.5, y: record.location.y, z: record.location.z + 0.5
        }, { spawnEvent: "lota:pasture_spawn" });
        entity.addTag(PASTURE_TAG);
        entity.addTag("lota:uncatchable");
        entity.addTag("lota:spawn_cap_exempt");
        entity.setDynamicProperty("lota:party_owner_id", member.ownerId);
        entity.setDynamicProperty(LINK, JSON.stringify({ key, pastureId: record.id, ownerId: member.ownerId, uuid: member.uuid, lease: member.lease }));
        applyAppearance(entity, member);
        entity.teleport(location);
        const next = clone(record), savedMember = next.members.find(value => value.lease === member.lease);
        savedMember.entityId = entity.id;
        if (!save(key, next)) throw new Error("Pasture entity ID write failed");
        loaded.set(member.lease, entity);
        spawnColoredFlame(dimension, location);
        return true;
    } catch (error) {
        try { if (entity?.isValid) entity.remove(); } catch {}
        console.warn(`[Pasture] Spawn deferred: ${error}`);
        return false;
    }
}
export function pasturePokemon(player, key, uuid) {
    initialize();
    reconcileOwner(player);
    const record = records.get(key), snapshot = pcSnapshot(player);
    if (!record || !canViewPasture(player, record) || currentBlock(record)?.typeId !== BLOCK || !snapshot) return false;
    const pokemon = snapshot.pokemon.get(uuid);
    const existing = [...records.values()].some(other => other.members.some(member => member.ownerId === player.id && member.uuid === uuid));
    if (!pasturablePokemon(pokemon, snapshot.partyIds, existing)) { tell(player, "cobbledrock.pasture.unavailable"); return false; }
    if (!profileOf(pokemon)) {
        console.warn(`[Pasture] No runtime collision profile for ${pokemon.species}`);
        tell(player, "cobbledrock.pasture.unsupported");
        return false;
    }
    if (record.members.length >= PASTURE.limit) { tell(player, "cobbledrock.pasture.full"); return false; }
    const region = occupiedIn(world.getDimension(record.dimensionId)).filter(position => Math.abs(position.x - record.location.x) < PASTURE.radius / 2 + position.width / 2 && Math.abs(position.z - record.location.z) < PASTURE.radius / 2 + position.width / 2);
    if (region.length >= PASTURE.perChunk * (PASTURE.radius / 16 * 2) ** 2) { tell(player, "cobblemon.pasture.too_many_nearby"); return false; }
    if (!safePosition(record, pokemon)) { tell(player, "cobbledrock.pasture.no_space"); return false; }
    const next = clone(record);
    const lease = generateUUID();
    next.members.push({ ownerId: player.id, ownerName: player.name, uuid, lease,
        appearance: pastureAppearance(pokemon), breeding: pastureBreedingSnapshot(pokemon) });
    if (!save(key, next)) { tell(player, "cobbledrock.pasture.save_failed"); return false; }
    const spawned = spawnMember(key, lease);
    if (!spawned) { removeMembers(key, member => member.ownerId === player.id && member.uuid === uuid); tell(player, "cobbledrock.pasture.spawn_failed"); }
    updateScreen(key);
    return spawned;
}
export function recallPasturePokemon(player, key, uuid = undefined) {
    const record = records.get(key);
    if (!record || !canViewPasture(player, record)) return false;
    const ok = removeMembers(key, member => member.ownerId === player.id && (uuid === undefined || member.uuid === uuid));
    if (!ok) tell(player, "cobbledrock.pasture.save_failed");
    return ok;
}
function validSession(player, session) {
    const record = records.get(session.key);
    return sessions.get(player.id) === session && record?.id === session.pastureId
        && canViewPasture(player, record) && currentBlock(record)?.typeId === BLOCK;
}
function breedingPokemon(member) {
    const owner = playerById(member.ownerId);
    const live = owner && pcSnapshot(owner)?.pokemon.get(member.uuid);
    return live || (member.breeding ? clone(member.breeding) : undefined);
}
function persistBreedingPokemon(member, pokemon) {
    const owner = playerById(member.ownerId);
    const snapshot = owner && pcSnapshot(owner);
    let pcSaved = false;
    if (snapshot) {
        for (let boxIndex = 0; boxIndex < snapshot.boxes.length; boxIndex++) {
            const slot = snapshot.boxes[boxIndex].findIndex(value => value?.uuid === member.uuid);
            if (slot < 0) continue;
            const box = snapshot.boxes[boxIndex].slice();
            box[slot] = clone(pokemon);
            pcSaved = savePCToPlayer(owner, boxIndex, box);
            break;
        }
    }
    for (const [key, record] of records) {
        const index = record.members.findIndex(value => value.lease === member.lease
            && value.ownerId === member.ownerId && value.uuid === member.uuid);
        if (index < 0) continue;
        const next = clone(record), target = next.members[index];
        const before = new Set((target.breeding?.benchedMoves || []).map(value => String(typeof value === "string" ? value : value?.id || "").replace(/^.*:/, "").toLowerCase()).filter(Boolean));
        const learned = (pokemon?.benchedMoves || []).map(value => String(typeof value === "string" ? value : value?.id || "").replace(/^.*:/, "").toLowerCase()).filter(id => id && !before.has(id));
        target.breeding = pastureBreedingSnapshot(pokemon);
        if (pcSaved) delete target.pendingMirrorMoves;
        else target.pendingMirrorMoves = [...new Set([...(target.pendingMirrorMoves || []), ...learned])];
        return save(key, next);
    }
    return pcSaved;
}
function showPasture(player, session) {
    if (!validSession(player, session) || session.open) { if (!session.open) close(player.id); return; }
    const snapshot = pcSnapshot(player), record = records.get(session.key);
    if (!snapshot) { tell(player, "cobbledrock.pasture.save_failed"); close(player.id); return; }
    const breeding = pastureBreedingView(session.key, record, breedingPokemon);
    if (breeding?.active && breeding.compatiblePairs === 0) {
        if (!session.warnedNoBreedingPair) {
            player.sendMessage({ translate: "cobbledrock.pasture.breeding_no_pair" });
            session.warnedNoBreedingPair = true;
        }
    } else session.warnedNoBreedingPair = false;
    const box = snapshot.boxes[session.box] || [];
    session.page = Math.min(session.page, Math.max(0, Math.ceil(record.members.length / 4) - 1));
    const visible = record.members.slice(session.page * 4, session.page * 4 + 4);
    const form = new ActionFormData().title("cobbledrock.pasture")
        .body(`Box ${session.box + 1}`);
    const boxIds = box.map(pokemon => pokemon?.uuid);
    for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
        const pokemon = box[slot];
        if (!pokemon) { form.button(""); continue; }
        const linked = pokemon && [...records.values()].some(r => r.members.some(m => m.ownerId === player.id && m.uuid === pokemon.uuid));
        const blocked = !pasturablePokemon(pokemon, snapshot.partyIds, linked);
        form.button(`${blocked ? "|LOCKED|" : ""}${linked ? "|PASTURED|" : ""}${pokemon?.nickname || ""}`, pokemonFormTexture(pokemon));
    }
    for (let i = 0; i < 4; i++) {
        const member = visible[i];
        if (!member) { form.button(""); continue; }
        form.button({ rawtext: [{ text: member.ownerId === player.id ? "§f" : "§7" }, nameText(member.appearance), { text: `\n${member.ownerName}§r` }] }, pokemonFormTexture(member.appearance));
    }
    for (const key of ["cobbledrock.pasture.previous_box", "cobbledrock.pasture.next_box", "cobbledrock.pasture.recall_all", "gui.close", "cobbledrock.pasture.previous", "cobbledrock.pasture.next"]) form.button({ translate: key });
    const preview = session.preview && snapshot.pokemon.get(session.preview);
    if (preview) form.button({ rawtext: [nameText(preview), { text: `\nLv. ${preview.level}` }] }, pokemonFormTexture(preview));
    else form.button("");
    form.button(`${record.members.length}/${PASTURE.limit}  [${session.page + 1}/${Math.max(1, Math.ceil(record.members.length / 4))}]`);
    form.button(box.some(pokemon => !!pokemon?.uuid) ? "" : { translate: "cobbledrock.pasture.empty_box" });
    form.button(`|BREEDING_${breeding?.active ? "ON" : "OFF"}|`, "textures/gui/breeding/breeding_button");
    session.open = true;
    updateScreen(session.key);
    form.show(player).then(response => {
        session.open = false;
        if (!validSession(player, session)) { close(player.id); return; }
        if (response.canceled) {
            if (String(response.cancelationReason).toLowerCase().includes("busy") && session.retries++ < 2) system.run(() => showPasture(player, session));
            else close(player.id);
            return;
        }
        session.retries = 0;
        const selection = response.selection;
        if (selection < 30 && boxIds[selection]) { session.preview = boxIds[selection]; pasturePokemon(player, session.key, boxIds[selection]); }
        else if (selection >= 30 && selection < 34 && visible[selection - 30]) {
            const member = visible[selection - 30];
            if (member.ownerId === player.id) { session.preview = member.uuid; recallPasturePokemon(player, session.key, member.uuid); }
        }
        else if (selection === 34) session.box = (session.box + PC_BOX_COUNT - 1) % PC_BOX_COUNT;
        else if (selection === 35) session.box = (session.box + 1) % PC_BOX_COUNT;
        else if (selection === 36) recallPasturePokemon(player, session.key);
        else if (selection === 37) { close(player.id); return; }
        else if (selection === 38) session.page = Math.max(0, session.page - 1);
        else if (selection === 39) session.page++;
        else if (selection === 43 && togglePastureBreeding(session.key, records.get(session.key)) === undefined) {
            tell(player, "cobbledrock.pasture.breeding_save_failed");
        }
        try { player.playSound("cobblemon.pc.click"); } catch {}
        system.run(() => showPasture(player, session));
    }).catch(error => { console.warn(`[Pasture] Form: ${error}`); close(player.id); });
}
const PASTURE_CHEST_LAYOUT = Object.freeze({
    title: PASTURE_CHEST_TITLE, n: PASTURE_CHEST_SLOT_COUNT,
    tex: [], vis: [], txt: [], ml: [],
    st: [PASTURE_CHEST_STATE_SLOT],
    cap: PASTURE_CHEST_CAP, ic: PASTURE_CHEST_IC, btn: PASTURE_CHEST_BTN, tb: PASTURE_CHEST_TB
});
function chestMenuOn(player) { try { return !player.hasTag(MENU_FORM_TAG); } catch { return true; } }
function plainName(pokemon) {
    if (pokemon?.nickname) return String(pokemon.nickname);
    return String(pokemon?.species || "unknown").replace(/^.*:/, "").replace(/[_-]+/g, " ").replace(/\b\w/g, letter => letter.toUpperCase());
}
function pastureModel(player, session) {
    const record = records.get(session.key), snapshot = pcSnapshot(player);
    if (!record || !snapshot) return undefined;
    const box = snapshot.boxes[session.box] || [];
    const pages = Math.max(1, Math.ceil(record.members.length / 4));
    session.page = Math.max(0, Math.min(session.page, pages - 1));
    return {
        record, snapshot, box, pages,
        boxIds: box.map(pokemon => pokemon?.uuid),
        visible: record.members.slice(session.page * 4, session.page * 4 + 4),
        breeding: pastureBreedingView(session.key, record, breedingPokemon)
    };
}
function pastureChestView(player, state) {
    const blank = { title: "|OK|", buttons: [], icons: {}, multi: {} };
    const session = state?.session;
    if (!session || !player?.isValid || !validSession(player, session)) return blank;
    const model = pastureModel(player, session);
    if (!model) return blank;
    const { record, snapshot, box, visible, pages, breeding } = model;
    if (breeding?.active && breeding.compatiblePairs === 0) {
        if (!session.warnedNoBreedingPair) {
            player.sendMessage({ translate: "cobbledrock.pasture.breeding_no_pair" });
            session.warnedNoBreedingPair = true;
        }
    } else session.warnedNoBreedingPair = false;
    const linked = new Set();
    for (const other of records.values()) for (const member of other.members) if (member.ownerId === player.id) linked.add(member.uuid);
    const buttons = [], icons = {};
    for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
        const pokemon = box[slot];
        if (!pokemon) { buttons[slot] = ""; continue; }
        const isLinked = linked.has(pokemon.uuid);
        const blocked = !pasturablePokemon(pokemon, snapshot.partyIds, isLinked);
        buttons[slot] = `${blocked ? "|LOCKED|" : ""}${isLinked ? "|PASTURED|" : ""}${pokemon.nickname || ""}`;
        icons[slot] = spriteSheetTexture(pokemon);
    }
    for (let i = 0; i < 4; i++) {
        const member = visible[i];
        if (!member) { buttons[30 + i] = ""; continue; }
        buttons[30 + i] = `|M|${member.ownerId === player.id ? "§f" : "§7"}${plainName(member.appearance)}\n${member.ownerName}§r`;
        icons[30 + i] = spriteSheetTexture(member.appearance);
    }
    const preview = session.preview && snapshot.pokemon.get(session.preview);
    if (preview) { buttons[40] = `${plainName(preview)} Lv. ${preview.level}`; icons[40] = spriteSheetTexture(preview); }
    else buttons[40] = "";
    buttons[41] = `${record.members.length}/${PASTURE.limit}  [${session.page + 1}/${pages}]`;
    buttons[43] = `|BREEDING_${breeding?.active ? "ON" : "OFF"}|`;
    buttons[44] = `Box ${session.box + 1}`;
    const empty = !box.some(pokemon => !!pokemon?.uuid);
    return { title: `|OK|${empty ? "|EMPTY|" : ""}`, buttons, icons, multi: {} };
}
function pastureChestPress(player, state, button) {
    const session = state?.session;
    if (!session || !validSession(player, session)) return "close";
    const model = pastureModel(player, session);
    if (!model) { tell(player, "cobbledrock.pasture.save_failed"); return "close"; }
    const { boxIds, visible } = model;
    if (button < 30) {
        if (boxIds[button]) { session.preview = boxIds[button]; pasturePokemon(player, session.key, boxIds[button]); }
    } else if (button < 34) {
        const member = visible[button - 30];
        if (member && member.ownerId === player.id) { session.preview = member.uuid; recallPasturePokemon(player, session.key, member.uuid); }
    }
    else if (button === 34) session.box = (session.box + PC_BOX_COUNT - 1) % PC_BOX_COUNT;
    else if (button === 35) session.box = (session.box + 1) % PC_BOX_COUNT;
    else if (button === 36) recallPasturePokemon(player, session.key);
    else if (button === 37) return "close";
    else if (button === 38) session.page = Math.max(0, session.page - 1);
    else if (button === 39) session.page++;
    else if (button === 43 && togglePastureBreeding(session.key, records.get(session.key)) === undefined) {
        tell(player, "cobbledrock.pasture.breeding_save_failed");
    }
    try { player.playSound("cobblemon.pc.click"); } catch {}
    return "redraw";
}
registerChestScreen({
    key: CHEST_KEY,
    layout: PASTURE_CHEST_LAYOUT,
    wants: () => false,
    create: player => ({ session: sessions.get(player.id) || null }),
    view: pastureChestView,
    press: pastureChestPress,
    onOpen: (player, state) => {
        const session = state?.session || sessions.get(player?.id);
        if (session) { session.lit = true; updateScreen(session.key); }
    }
});

function anchorsAt(dimension, bottom) {
    try {
        return dimension.getEntities({
            type: ANCHOR_TYPE,
            location: { x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 },
            maxDistance: 1.6
        });
    } catch { return []; }
}
function hideAnchor(entity) {
    try { if (!entity.getEffect("invisibility")) entity.addEffect("invisibility", 20000000, { amplifier: 0, showParticles: false }); } catch {}
}
function ensureAnchor(dimension, bottom) {
    try {
        const found = anchorsAt(dimension, bottom);
        if (found.length) {
            for (let index = 1; index < found.length; index++) { try { found[index].remove(); } catch {} }
            try {
                if (Math.abs(found[0].location.y - (bottom.y + 1)) > 0.05) found[0].teleport({ x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 });
            } catch {}
            hideAnchor(found[0]);
            return found[0];
        }
        const entity = dimension.spawnEntity(ANCHOR_TYPE, { x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 });
        try { entity.nameTag = PASTURE_CHEST_TITLE; } catch {}
        hideAnchor(entity);
        return entity;
    } catch { return undefined; }
}
function removeAnchors(dimension, bottom) {
    for (const entity of anchorsAt(dimension, bottom)) { try { entity.remove(); } catch {} }
}
function bottomBlockOfAnchor(entity) {
    try {
        const { x, y, z } = entity.location;
        const here = entity.dimension.getBlock({ x: Math.floor(x), y: Math.floor(y + 0.01), z: Math.floor(z) });
        if (here?.typeId === TOP) return entity.dimension.getBlock({ x: Math.floor(x), y: Math.floor(y + 0.01) - 1, z: Math.floor(z) });
        return here;
    } catch { return undefined; }
}

registerFixedAnchor(ANCHOR_TYPE, (player, entity) => {
    if (!player?.isValid || player.typeId !== "minecraft:player") return;
    const bottom = bottomBlockOfAnchor(entity);
    if (bottom?.typeId !== BLOCK) { try { entity.remove(); } catch {} return; }
    initialize();
    const key = pastureKey(bottom.dimension.id, bottom.location), record = records.get(key);
    if (!record || !canViewPasture(player, record)) return;
    for (const [playerId, other] of sessions) {
        if (playerId !== player.id && other.chest && other.key === key) { tell(player, "cobbledrock.pasture.busy"); return; }
    }
    const prior = sessions.get(player.id);
    if (prior) { sessions.delete(player.id); updateScreen(prior.key); }
    reconcileOwner(player);
    const session = { key, pastureId: record.id, box: 0, page: 0, retries: 0, open: false, chest: true, fixed: true, lit: true };
    sessions.set(player.id, session);
    const dimension = bottom.dimension, at = { ...bottom.location };
    const attached = attachChestScreen(player, CHEST_KEY, entity, {
        state: { session },
        hold: 1200,
        onRelease: () => system.run(() => {
            try { if (blockAt(dimension, at)?.typeId === BLOCK) ensureAnchor(dimension, at); } catch {}
        })
    });
    if (!attached) { sessions.delete(player.id); updateScreen(key); return; }
    updateScreen(key);
    try { player.playSound("cobblemon.pc.on"); } catch {}
});

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    if (event.target?.typeId !== ANCHOR_TYPE) return;
    const player = event.player, entity = event.target;
    let formUser = false;
    try { formUser = player.hasTag(MENU_FORM_TAG); } catch {}
    const bottom = bottomBlockOfAnchor(entity);
    initialize();
    const key = bottom?.typeId === BLOCK ? pastureKey(bottom.dimension.id, bottom.location) : undefined;
    const record = key ? records.get(key) : undefined;
    const allowed = !!record && canViewPasture(player, record);
    const busy = allowed && [...sessions].some(([playerId, other]) => playerId !== player.id && other.chest && other.key === key);
    if (!formUser && allowed && !busy) return;
    event.cancel = true;
    if (busy) { system.run(() => tell(player, "cobbledrock.pasture.busy")); return; }
    if (!formUser || !allowed) return;
    const dimension = bottom.dimension, at = { ...bottom.location };
    system.run(() => openPasture(player, blockAt(dimension, at)));
});

function startPastureChest(player, session) {
    if (!chestMenuOn(player)) return false;
    session.chest = true;
    session.lit = false;
    if (!openChestScreen(player, CHEST_KEY, { hold: 600, state: { session } })) { session.chest = false; return false; }
    return true;
}

system.runInterval(() => {
    for (const [playerId, session] of [...sessions]) {
        if (!session.chest) continue;
        const player = playerById(playerId);
        if (player?.isValid && chestScreenActive(player, CHEST_KEY)) continue;
        close(playerId);
    }
}, 10);

export function openPasture(player, block) {
    initialize();
    if (block?.typeId === TOP) block = blockAt(block.dimension, { ...block.location, y: block.location.y - 1 });
    if (block?.typeId !== BLOCK) return false;
    const key = pastureKey(block.dimension.id, block.location), record = records.get(key);
    if (!record || !canViewPasture(player, record)) return false;
    const existing = sessions.get(player.id);
    if (existing && !existing.chest) return false;
    if (existing) close(player.id);
    reconcileOwner(player);
    ensureAnchor(block.dimension, block.location);
    const session = { key, pastureId: record.id, box: 0, page: 0, retries: 0, open: false, chest: false, lit: false };
    sessions.set(player.id, session);
    if (startPastureChest(player, session)) return true;
    session.chest = false;
    try { player.playSound("cobblemon.pc.on"); } catch {}
    showPasture(player, session);
    return true;
}
function inspectEntity(entity) {
    if (!entity?.isValid || !entity.hasTag(PASTURE_TAG)) return;
    initialize();
    let link;
    try { link = JSON.parse(entity.getDynamicProperty(LINK)); } catch {}
    const member = resolvePastureMember(records.get(link?.key), link);
    if (!member || member.entityId !== entity.id) { try { entity.remove(); } catch {} return; }
    const owner = playerById(member.ownerId);
    if (owner) {
        const snapshot = pcSnapshot(owner);
        if (snapshot && !pasturablePokemon(snapshot.pokemon.get(member.uuid), snapshot.partyIds, false)) {
            removeMembers(link.key, value => value.lease === member.lease);
            return;
        }
    }
    loaded.set(member.lease, entity);
}
function tickPasture(block) {
    initialize();
    if (block.typeId === TOP) {
        const bottom = blockAt(block.dimension, { ...block.location, y: block.location.y - 1 });
        if (bottom && bottom.typeId !== BLOCK && destroyPasture(pastureKey(block.dimension.id, bottom.location))) block.setType("minecraft:air");
        return;
    }
    const key = pastureKey(block.dimension.id, block.location);
    let record = records.get(key);
    const top = blockAt(block.dimension, { ...block.location, y: block.location.y + 1 });
    if (!top) return;
    if (top.typeId !== TOP) {
        if (destroyPasture(key)) { block.setType("minecraft:air"); block.dimension.spawnItem(new ItemStack(BLOCK), { ...block.location, y: block.location.y + 0.5 }); }
        return;
    }
    if (!record) return;
    ensureAnchor(block.dimension, block.location);
    for (const original of record.members) {
        record = records.get(key);
        const member = record?.members.find(value => value.lease === original.lease);
        if (!member) continue;
        const entity = entityById(member.entityId);
        if (entity?.isValid) {
            loaded.set(member.lease, entity);
            if (!inPastureBounds(entity.location, record.location)) {
                const safe = safePosition(record, member.appearance);
                if (safe) { try { entity.teleport(safe); } catch {} }
                else { removeMembers(key, value => value.lease === member.lease); continue; }
            }
        } else if (!member.entityId) spawnMember(key, member.lease);
    }
    const beforeEggs = pastureBreedingView(key, records.get(key), breedingPokemon)?.eggs.length || 0;
    tickPastureBreeding(key, records.get(key), breedingPokemon, persistBreedingPokemon);
    const afterEggs = pastureBreedingView(key, records.get(key), breedingPokemon)?.eggs.length || 0;
    if (afterEggs > beforeEggs) {
        try { block.dimension.playSound("random.pop", { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 }); } catch (error) {}
    }
    if (afterEggs > 0) {
        const hopper = blockAt(block.dimension, { ...block.location, y: block.location.y - 1 });
        if (hopper?.typeId === "minecraft:hopper") {
            let container;
            try { container = hopper.getComponent("minecraft:inventory")?.container || hopper.getComponent("inventory")?.container; } catch (error) {}
            if (container) pullPastureEgg(container, key, records.get(key));
        }
    }
    updateScreen(key);
}
function placePasture(event) {
    initialize();
    const bottom = event.block, top = blockAt(bottom.dimension, { ...bottom.location, y: bottom.location.y + 1 });
    const key = pastureKey(bottom.dimension.id, bottom.location);
    if (!top?.isAir || (world.getDynamicProperty(key) !== undefined && !destroyPasture(key))) {
        bottom.setType("minecraft:air");
        if (String(event.player?.getGameMode()).toLowerCase() !== "creative") bottom.dimension.spawnItem(new ItemStack(BLOCK), { ...bottom.location, y: bottom.location.y + 0.5 });
        return;
    }
    const record = { version: 1, id: generateUUID(), dimensionId: bottom.dimension.id, location: { ...bottom.location },
        facing: bottom.permutation.getState("minecraft:cardinal_direction"), ownerId: event.player?.id || "", members: [] };
    if (!save(key, record)) {
        bottom.setType("minecraft:air");
        if (String(event.player?.getGameMode()).toLowerCase() !== "creative") bottom.dimension.spawnItem(new ItemStack(BLOCK), { ...bottom.location, y: bottom.location.y + 0.5 });
        return;
    }
    try {
        top.setType(TOP);
        top.setPermutation(top.permutation.withState("minecraft:cardinal_direction", record.facing));
        ensureAnchor(bottom.dimension, bottom.location);
    } catch (error) {
        destroyPasture(key);
        bottom.setType("minecraft:air");
        if (String(event.player?.getGameMode()).toLowerCase() !== "creative") bottom.dimension.spawnItem(new ItemStack(BLOCK), { ...bottom.location, y: bottom.location.y + 0.5 });
    }
}
system.beforeEvents.startup.subscribe(event => {
    event.blockComponentRegistry.registerCustomComponent("lota:pasture_component", {
        beforeOnPlayerPlace: event => {
            const top = blockAt(event.block.dimension, { ...event.block.location, y: event.block.location.y + 1 });
            if (!top?.isAir) event.cancel = true;
        },
        onTick: event => tickPasture(event.block)
    });
    event.blockComponentRegistry.registerCustomComponent("lota:pasture_top_component", { onTick: event => tickPasture(event.block) });
});
world.afterEvents.playerPlaceBlock.subscribe(event => { if (event.block.typeId === BLOCK) placePasture(event); });
function interactPasture(player, block, collectEgg) {
    if (block?.typeId === TOP) block = blockAt(block.dimension, { ...block.location, y: block.location.y - 1 });
    if (block?.typeId !== BLOCK) return;
    initialize();
    const key = pastureKey(block.dimension.id, block.location), record = records.get(key);
    if (!record || !canViewPasture(player, record)) return;
    const breeding = collectEgg && pastureBreedingView(key, record, breedingPokemon);
    if (breeding?.eggs?.length) {
        const result = collectPastureEgg(player, key, record, 0);
        if (!result.success) {
            tell(player, result.reason === "full" ? "cobbledrock.pasture.breeding_inventory_full" : "cobbledrock.pasture.breeding_collect_failed");
        } else {
            try { player.playSound("random.pop", { pitch: 1.2, volume: 0.8 }); } catch (error) {}
        }
        updateScreen(key);
        return;
    }
    openPasture(player, block);
}
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    if (![BLOCK, TOP].includes(event.block.typeId) || event.isFirstEvent === false) return;
    if (event.player.isSneaking && event.itemStack) return;
    event.cancel = true;
    const { player, block } = event, location = { ...block.location }, dimension = block.dimension;
    const collectEgg = block.typeId === BLOCK && !event.itemStack;
    system.run(() => interactPasture(player, blockAt(dimension, location), collectEgg));
});
world.afterEvents.playerBreakBlock.subscribe(event => {
    const type = event.brokenBlockPermutation.type.id;
    if (![BLOCK, TOP].includes(type)) return;
    initialize();
    const dimension = event.block.dimension, at = { ...event.block.location, y: event.block.location.y - (type === TOP ? 1 : 0) };
    destroyPasture(pastureKey(dimension.id, at));
    removeAnchors(dimension, at);
    const other = blockAt(dimension, { ...at, y: at.y + (type === BLOCK ? 1 : 0) });
    if (other?.typeId === (type === BLOCK ? TOP : BLOCK)) {
        other.setType("minecraft:air");
        if (type === TOP && String(event.player.getGameMode()).toLowerCase() !== "creative") dimension.spawnItem(new ItemStack(BLOCK), { ...at, y: at.y + 0.5 });
    }
});
world.afterEvents.explosion.subscribe(event => {
    initialize();
    for (const block of event.getImpactedBlocks()) {
        for (const y of [block.location.y, block.location.y - 1]) {
            const key = pastureKey(event.dimension.id, { ...block.location, y });
            const record = records.get(key), bottom = record && currentBlock(record);
            if (bottom && bottom.typeId !== BLOCK) destroyPasture(key);
        }
    }
});
world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    if (!event.target.hasTag(PASTURE_TAG)) return;
    event.cancel = true;
    const entity = event.target, player = event.player;
    system.run(() => {
        try {
            const link = JSON.parse(entity.getDynamicProperty(LINK)), record = records.get(link.key);
            if (record && canViewPasture(player, record)) openPasture(player, currentBlock(record));
        } catch {}
    });
});
world.afterEvents.entityLoad.subscribe(event => inspectEntity(event.entity));
world.afterEvents.entityDie.subscribe(event => {
    const entity = event.deadEntity;
    if (!entity.hasTag(PASTURE_TAG)) return;
    try {
        const link = JSON.parse(entity.getDynamicProperty(LINK));
        removeMembers(link.key, member => member.lease === link.lease);
    } catch {}
});
world.afterEvents.playerSpawn.subscribe(event => { if (event.initialSpawn) queueOwner(event.player); });
world.afterEvents.playerLeave.subscribe(event => close(event.playerId));
subscribePokemonStorageSaved(queueOwner);
system.run(() => {
    initialize();
    for (const player of world.getAllPlayers()) reconcileOwner(player);
    for (const id of ["overworld", "nether", "the_end"]) {
        try { for (const entity of world.getDimension(id).getEntities({ tags: [PASTURE_TAG] })) inspectEntity(entity); } catch {}
    }
});
system.runInterval(() => {
    for (const [playerId, session] of sessions) {
        const player = playerById(playerId);
        if (!player || !validSession(player, session)) close(playerId);
    }
    for (const [lease, entity] of loaded) {
        if (!entity?.isValid) { loaded.delete(lease); continue; }
        try {
            const link = JSON.parse(entity.getDynamicProperty(LINK)), record = records.get(link.key);
            if (!resolvePastureMember(record, link)) { entity.remove(); loaded.delete(lease); continue; }
            const block = currentBlock(record);
            if (block && block.typeId !== BLOCK) destroyPasture(link.key);
        } catch (error) { console.warn(`[Pasture] Reconcile: ${error}`); }
    }
}, PASTURE.ticks);
