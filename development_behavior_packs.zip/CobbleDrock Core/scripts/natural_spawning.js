import { system, world } from "@minecraft/server";
import { NATURAL_SPAWN_DATA } from "./natural_spawn_data.js";
import { pokemonGenderRatio, pokemonModelVariant, pokemonVisualAspects } from './pokemon_visual_state.js';
import { pokemonTimeRangeMatches } from './pokemon_time_ranges.js';
import {
    advanceLoadedNaturalAge,
    chooseNaturalSpawnLevel,
    createFluidConditionLocation,
    createEntityLimitQuery,
    createEntitySpatialIndex,
    createNaturalSpawnLocation,
    createSpawnZoneBounds,
    createStaggeredInitialAttemptTick,
    compileSpawnEntryGroups,
    filterPositionsOutsideMinimumDistance,
    highestNaturalSpawnPartyLevel,
    isEntityLimitCountReached,
    isNaturalSpawnFarEnoughFromPlayers,
    nearestIndexedEntityDistance,
    shouldNaturallyDespawn
} from "./natural_spawn_rules.js";
import {
    generateRandomPokemon,
    initialMovesForSpecies,
    loadPartyFromPlayer,
    savePokemonToEntity
} from "./storage.js";
import {
    doesNaturalSpawnAreaIntersectZone,
    hasNaturalSpawnZones,
    isNaturalSpawnAreaFullyBlocked,
    isNaturalSpawnLocationBlocked
} from "./natural_spawn_zones.js";
const CONFIG = NATURAL_SPAWN_DATA.config;
const ENTRY_GROUPS_BY_BUCKET_AND_POSITION = compileSpawnEntryGroups(NATURAL_SPAWN_DATA.entries);
const PLAYER_NEXT_ATTEMPT = new Map();
const ACTIVE_PLAYER_SPAWN_JOBS = new Map();
const WEATHER_BY_DIMENSION = new Map();
const BEDROCK_BIOME_SETS = new WeakMap();
const NORMALIZED_SELECTOR_ARRAYS = new WeakMap();
const NORMALIZED_SELECTOR_STRINGS = new Map();
const DIMENSION_IDS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];
const NATURAL_TAG = "lota:natural_spawn";
const INITIAL_SPAWN_DELAY_TICKS = 100;
let nextPlayerSpawnPhase = 0;

function isPokemonSpawningAllowed(player) {
    return DIMENSION_IDS.includes(player?.dimension?.id);
}

const NATURAL_BLOCK_PARTS = [
    "stone", "deepslate", "dirt", "grass", "podzol", "mycelium", "sand", "gravel",
    "clay", "terracotta", "mud", "moss", "snow", "ice", "netherrack", "nylium",
    "soul_sand", "soul_soil", "basalt", "blackstone", "end_stone", "calcite", "tuff",
    "dripstone", "sculk", "coral", "ore", "bedrock"
];
const PASSABLE_BLOCK_NAMES = new Set([
    "short_grass", "tallgrass", "fern", "large_fern", "deadbush", "dead_bush",
    "snow_layer", "tripwire", "reeds", "sugar_cane", "bamboo_sapling",
    "small_dripleaf", "big_dripleaf", "nether_sprouts", "crimson_fungus",
    "warped_fungus", "weeping_vines", "twisting_vines", "vine", "glow_lichen"
]);
const PASSABLE_BLOCK_SUFFIXES = [
    "_flower", "_sapling", "_torch", "_carpet", "_button", "_pressure_plate",
    "_rail", "_mushroom", "_roots", "_azalea"
];
const VILLAGE_BLOCK_SELECTORS = ["minecraft:bell", "minecraft:hay_block", "minecraft:composter"];
const OUTPOST_BLOCK_SELECTORS = ["minecraft:dark_oak_planks", "minecraft:cobblestone"];
const TRAIL_RUINS_BLOCK_SELECTORS = ["minecraft:suspicious_gravel", "minecraft:mud_bricks"];

function isValidEntity(entity) {
    try {
        return Boolean(entity?.isValid);
    } catch (error) {
        return false;
    }
}

function asArray(value) {
    if (value === undefined || value === null) return [];
    return Array.isArray(value) ? value : [value];
}

function weightedChoice(items, weightOf) {
    let total = 0;
    for (const item of items) total += Math.max(0, Number(weightOf(item)) || 0);
    if (total <= 0) return undefined;

    let roll = Math.random() * total;
    for (const item of items) {
        roll -= Math.max(0, Number(weightOf(item)) || 0);
        if (roll < 0) return item;
    }
    return items[items.length - 1];
}

function squaredDistance(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return dx * dx + dy * dy + dz * dz;
}

function blockType(block) {
    try {
        return String(block?.typeId || "minecraft:air").toLowerCase();
    } catch (error) {
        return "minecraft:air";
    }
}

function isAir(block, knownType = blockType(block)) {
    try {
        return Boolean(block?.isAir) || knownType.endsWith(":air");
    } catch (error) {
        return knownType.endsWith(":air");
    }
}

function isWater(block, knownType = blockType(block)) {
    const id = knownType;
    if (id === "minecraft:water" || id === "minecraft:flowing_water") return true;
    try {
        return Boolean(block?.isLiquid) && !id.includes("lava");
    } catch (error) {
        return false;
    }
}

function isLava(block, knownType = blockType(block)) {
    return knownType.includes("lava");
}

function isPassable(block, knownType = blockType(block)) {
    if (!block || isAir(block, knownType) || isWater(block, knownType) || isLava(block, knownType)) return true;
    const name = knownType.split(":").pop();
    if (PASSABLE_BLOCK_NAMES.has(name)) return true;
    return PASSABLE_BLOCK_SUFFIXES.some(suffix => name.endsWith(suffix));
}

function isSolidFloor(block, knownType = blockType(block)) {
    return Boolean(block)
        && !isPassable(block, knownType)
        && !isWater(block, knownType)
        && !isLava(block, knownType);
}

function safeGetBlock(dimension, location) {
    try {
        return dimension.getBlock(location);
    } catch (error) {
        return undefined;
    }
}

function dimensionHeightRange(dimension) {
    try {
        return dimension.heightRange;
    } catch (error) {
        return { min: -64, max: 320 };
    }
}

function isValidZoneStart(dimension, x, y, z) {
    const range = dimensionHeightRange(dimension);
    if (y < range.min || y + 1 >= range.max) return false;
    const middle = safeGetBlock(dimension, { x, y, z });
    const above = safeGetBlock(dimension, { x, y: y + 1, z });
    return Boolean(middle) && !isAir(middle) && isPassable(above) && !isWater(above) && !isLava(above);
}

function findCorrectedBaseY(dimension, x, startY, z) {
    const maxCorrection = CONFIG.maxVerticalCorrectionBlocks;
    const originalY = Math.floor(startY);
    if (isValidZoneStart(dimension, x, originalY, z)) return originalY;
    for (let distance = 1; distance <= maxCorrection; distance++) {
        const aboveY = originalY + distance;
        if (isValidZoneStart(dimension, x, aboveY, z)) return aboveY;
        const belowY = originalY - distance;
        if (isValidZoneStart(dimension, x, belowY, z)) return belowY;
    }
    return undefined;
}

function blockKey(x, y, z) {
    return `${x}|${y}|${z}`;
}

function createScanContext(player) {
    const velocity = player.getVelocity();
    const horizontalSpeed = Math.hypot(velocity.x, velocity.z);
    const temporaryAngle = Math.atan(velocity.z / velocity.x) + (Math.random() - 0.5) * Math.PI;
    const baseAngle = horizontalSpeed < 0.1
        ? Math.random() * Math.PI * 2
        : velocity.x < 0 ? Math.PI - temporaryAngle : temporaryAngle;
    const distance = CONFIG.minimumSpawningZoneDistanceFromPlayer
        + Math.random() * (CONFIG.maximumSpawningZoneDistanceFromPlayer - CONFIG.minimumSpawningZoneDistanceFromPlayer);
    const targetX = player.location.x + Math.cos(baseAngle) * distance;
    const targetZ = player.location.z + Math.sin(baseAngle) * distance;
    const requested = createSpawnZoneBounds(targetX, targetZ, player.location.y, CONFIG);
    const correctedY = findCorrectedBaseY(player.dimension, requested.minX, requested.minY, requested.minZ);
    if (correctedY === undefined) return undefined;

    const range = dimensionHeightRange(player.dimension);
    const minX = requested.minX;
    const minZ = requested.minZ;
    const minY = Math.max(range.min, correctedY);
    const height = Math.min(requested.height, range.max - minY);
    if (height < 1) return undefined;

    const minCorner = { x: minX, y: minY, z: minZ };
    const maxCorner = {
        x: minX + requested.length - 1,
        y: minY + height - 1,
        z: minZ + requested.width - 1
    };
    try {
        if (!player.dimension.isChunkLoaded(minCorner) || !player.dimension.isChunkLoaded(maxCorner)) return undefined;
    } catch (error) {
    }

    return {
        dimension: player.dimension,
        minX,
        minY,
        minZ,
        maxX: maxCorner.x,
        maxY: maxCorner.y,
        maxZ: maxCorner.z,
        center: {
            x: minX + requested.length / 2,
            y: minY + height / 2,
            z: minZ + requested.width / 2
        },
        blockCache: new Map(),
        blockFactsCache: new WeakMap(),
        waterDepthCache: new Map(),
        biomeCache: new Map(),
        lightCache: new Map(),
        skyLightCache: new Map(),
        topBlockCache: new Map(),
        nearbyCache: new Map(),
        time: world.getTimeOfDay(),
        moonPhase: Number(world.getMoonPhase()),
        weather: currentDimensionWeather(player.dimension)
    };
}

function cachedBlock(scan, x, y, z) {
    const key = blockKey(x, y, z);
    if (!scan.blockCache.has(key)) {
        scan.blockCache.set(key, safeGetBlock(scan.dimension, { x, y, z }));
    }
    return scan.blockCache.get(key);
}

function createBlockFacts(block) {
    const id = blockType(block);
    const air = isAir(block, id);
    const water = isWater(block, id);
    const lava = isLava(block, id);
    const passable = !block || air || water || lava || isPassable(block, id);
    let sourceWater = false;
    if (water) {
        try {
            const depth = block.permutation?.getState?.("liquid_depth");
            sourceWater = depth === undefined || Number(depth) === 0;
        } catch (error) {
            sourceWater = true;
        }
    }
    return {
        id,
        water,
        lava,
        passable,
        sourceWater,
        solidFloor: Boolean(block) && !passable && !water && !lava
    };
}

function blockFacts(scan, block) {
    if (!block || (typeof block !== "object" && typeof block !== "function")) {
        return createBlockFacts(block);
    }
    let facts = scan.blockFactsCache.get(block);
    if (!facts) {
        facts = createBlockFacts(block);
        scan.blockFactsCache.set(block, facts);
    }
    return facts;
}

function cachedBlockFacts(scan, x, y, z) {
    return blockFacts(scan, cachedBlock(scan, x, y, z));
}

function waterDepth(scan, x, y, z) {
    const key = blockKey(x, y, z);
    if (scan.waterDepthCache.has(key)) return scan.waterDepthCache.get(key);
    let depth = 0;
    const range = dimensionHeightRange(scan.dimension);
    for (let checkY = y; checkY >= range.min; checkY--) {
        if (!cachedBlockFacts(scan, x, checkY, z).water) break;
        const cached = scan.waterDepthCache.get(blockKey(x, checkY, z));
        if (cached !== undefined) {
            depth += cached;
            break;
        }
        depth++;
    }
    scan.waterDepthCache.set(key, depth);
    return depth;
}

function* collectSpawnablePositionsJob(scan) {
    const positions = [];
    for (let x = scan.minX; x <= scan.maxX; x++) {
        for (let z = scan.minZ; z <= scan.maxZ; z++) {
            for (let y = scan.minY; y <= scan.maxY; y++) {
                const block = cachedBlock(scan, x, y, z);
                const above = cachedBlock(scan, x, y + 1, z);
                const facts = blockFacts(scan, block);
                const aboveFacts = blockFacts(scan, above);

                if (facts.solidFloor && aboveFacts.passable && !aboveFacts.water && !aboveFacts.lava) {
                    positions.push(createPosition("grounded", x, y, z, block, undefined, 0));
                } else if (facts.solidFloor && aboveFacts.sourceWater) {
                    positions.push(createPosition("seafloor", x, y, z, block, "minecraft:water", waterDepth(scan, x, y + 1, z)));
                } else if (facts.sourceWater
                    && cachedBlockFacts(scan, x, y - 1, z).sourceWater
                    && aboveFacts.sourceWater) {
                    const depth = waterDepth(scan, x, y, z);
                    positions.push(createPosition("submerged", x, y, z, cachedBlock(scan, x, y - 1, z), "minecraft:water", depth));
                } else if (facts.water && !aboveFacts.water && !aboveFacts.lava && aboveFacts.passable) {
                    const depth = waterDepth(scan, x, y, z);
                    positions.push(createPosition("surface", x, y, z, block, "minecraft:water", depth));
                }
                yield;
            }
        }
    }
    return positions;
}

function createPosition(positionType, x, y, z, baseBlock, fluid, depth) {
    return {
        positionType,
        blockLocation: { x, y, z },
        fluidConditionLocation: createFluidConditionLocation(positionType, x, y, z),
        location: createNaturalSpawnLocation(positionType, x, y, z),
        baseBlock,
        fluid,
        depth
    };
}

function removePositionsNearLivingEntities(scan, positions, causeEntity) {
    let living = [];
    try {
        const padding = CONFIG.minimumDistanceBetweenEntities / 2;
        living = scan.dimension.getEntities({
            location: { x: scan.minX - padding, y: scan.minY - padding, z: scan.minZ - padding },
            volume: {
                x: (scan.maxX - scan.minX + 1) + CONFIG.minimumDistanceBetweenEntities,
                y: (scan.maxY - scan.minY + 1) + CONFIG.minimumDistanceBetweenEntities,
                z: (scan.maxZ - scan.minZ + 1) + CONFIG.minimumDistanceBetweenEntities
            }
        }).filter(entity => {
            try {
                return entity.id !== causeEntity?.id && isValidEntity(entity) && Boolean(entity.getComponent("minecraft:health"));
            } catch (error) {
                return false;
            }
        });
    } catch (error) {
        return positions;
    }

    const minDistanceSquared = CONFIG.minimumDistanceBetweenEntities ** 2;
    return positions.filter(position => !living.some(entity => squaredDistance(position.blockLocation, entity.location) < minDistanceSquared));
}

function removePositionsNearPlayers(positions, causePlayer, players) {
    return positions.filter(position => isNaturalSpawnFarEnoughFromPlayers(
        position.location,
        causePlayer?.id,
        players,
        CONFIG
    ));
}

function isEntityLimitReached(scan) {
    try {
        const query = createEntityLimitQuery(scan.center, dimensionHeightRange(scan.dimension), CONFIG);
        const pokemon = scan.dimension.getEntities(query);
        return isEntityLimitCountReached(pokemon.length, CONFIG);
    } catch (error) {
        return true;
    }
}

function normalizeWeather(value) {
    const text = String(value || "clear").toLowerCase();
    if (text.includes("thunder")) return "thunder";
    if (text.includes("rain")) return "rain";
    return "clear";
}

function currentDimensionWeather(dimension) {
    try {
        if (typeof dimension?.getWeather === "function") {
            return normalizeWeather(dimension.getWeather());
        }
    } catch (error) {}
    return WEATHER_BY_DIMENSION.get(dimension?.id) || "clear";
}

function timeRangeMatches(name, time) {
    return pokemonTimeRangeMatches(time, name || 'any');
}

function cachedBiomeId(scan, location) {
    const key = blockKey(location.x, location.y, location.z);
    if (!scan.biomeCache.has(key)) {
        let biomeId = "";
        try {
            biomeId = scan.dimension.getBiome(location).id;
        } catch (error) {}
        scan.biomeCache.set(key, biomeId);
    }
    return scan.biomeCache.get(key);
}

function cachedLight(scan, location, sky) {
    const cache = sky ? scan.skyLightCache : scan.lightCache;
    const key = blockKey(location.x, location.y, location.z);
    if (!cache.has(key)) {
        let level = 0;
        try {
            level = sky
                ? scan.dimension.getSkyLightLevel(location)
                : scan.dimension.getLightLevel(location);
        } catch (error) {}
        cache.set(key, level);
    }
    return cache.get(key);
}

function canSeeSky(scan, location) {
    const key = `${location.x}|${location.z}`;
    if (!scan.topBlockCache.has(key)) {
        let topY = Number.POSITIVE_INFINITY;
        try {
            topY = scan.dimension.getTopmostBlock({ x: location.x, z: location.z })?.location.y ?? topY;
        } catch (error) {}
        scan.topBlockCache.set(key, topY);
    }
    return location.y >= scan.topBlockCache.get(key);
}

function normalizedBlockSelectors(selector) {
    if (Array.isArray(selector)) {
        let normalized = NORMALIZED_SELECTOR_ARRAYS.get(selector);
        if (!normalized) {
            normalized = selector.map(value => String(value).toLowerCase());
            NORMALIZED_SELECTOR_ARRAYS.set(selector, normalized);
        }
        return normalized;
    }

    const key = String(selector);
    if (!NORMALIZED_SELECTOR_STRINGS.has(key)) {
        NORMALIZED_SELECTOR_STRINGS.set(key, [key.toLowerCase()]);
    }
    return NORMALIZED_SELECTOR_STRINGS.get(key);
}

function selectorMatchesBlock(scan, selector, block) {
    const facts = blockFacts(scan, block);
    return normalizedBlockSelectors(selector).some(value => singleSelectorMatchesBlock(value, facts));
}

function singleSelectorMatchesBlock(selector, facts) {
    const { id } = facts;
    if (!selector) return false;
    if (!selector.startsWith("#")) {
        if (selector === "minecraft:flowing_water") return facts.water;
        if (selector === "minecraft:water") return facts.water;
        if (selector === "minecraft:lava") return facts.lava;
        if (selector === "minecraft:double_smooth_stone_slab") return id.includes("double") && id.includes("stone") && id.includes("slab");
        return id === selector;
    }

    if (selector === "#minecraft:water") return facts.water;
    if (selector === "#minecraft:lava") return facts.lava;
    if (selector.includes("natural")) return facts.solidFloor && NATURAL_BLOCK_PARTS.some(part => id.includes(part));
    if (selector.includes("leaves")) return id.includes("leaves") || id.includes("leaf");
    if (selector.includes("wool_carpets")) return id.includes("carpet");
    if (selector.includes("wool")) return id.includes("wool");
    if (selector.includes("iron_ores")) return id.includes("iron_ore");
    if (selector.includes("redstone")) return id.includes("redstone") || id.includes("repeater") || id.includes("comparator");
    if (selector.includes("concrete")) return id.includes("concrete");
    if (selector.includes("apricorns")) return id.includes("apricorn");
    if (selector.includes("saccharine_trees")) return id.includes("saccharine");
    if (selector.includes("ocean_ruin_blocks")) {
        return id.includes("prismarine") || id.includes("sandstone") || id.includes("stone_brick") || id.includes("magma");
    }
    if (selector.includes("mansion_blocks")) {
        return id.includes("dark_oak") || id.includes("cobblestone") || id.includes("wool") || id.includes("carpet");
    }
    return false;
}

function conditionBiomeMatches(condition, biomeId) {
    const mapped = condition?.bedrockBiomes;
    if (!Array.isArray(mapped)) return mapped !== undefined && mapped === biomeId;
    let biomeSet = BEDROCK_BIOME_SETS.get(condition);
    if (!biomeSet) {
        biomeSet = new Set(mapped);
        BEDROCK_BIOME_SETS.set(condition, biomeSet);
    }
    return biomeSet.has(biomeId);
}

function nearbyHasSelector(scan, position, selector) {
    const selectorKey = JSON.stringify(selector);
    const key = `${position.blockLocation.x}|${position.blockLocation.y}|${position.blockLocation.z}|${selectorKey}`;
    if (scan.nearbyCache.has(key)) return scan.nearbyCache.get(key);

    const horizontal = CONFIG.maximumNearbyBlockHorizontalRange;
    const vertical = CONFIG.maximumNearbyBlockVerticalRange;
    let found = false;
    outer:
    for (let x = position.blockLocation.x - horizontal; x <= position.blockLocation.x + horizontal; x++) {
        for (let z = position.blockLocation.z - horizontal; z <= position.blockLocation.z + horizontal; z++) {
            for (let y = position.blockLocation.y - vertical; y <= position.blockLocation.y + vertical; y++) {
                if (selectorMatchesBlock(scan, selector, cachedBlock(scan, x, y, z))) {
                    found = true;
                    break outer;
                }
            }
        }
    }
    scan.nearbyCache.set(key, found);
    return found;
}

function structureMatches(scan, position, selector) {
    return asArray(selector).some(raw => {
        const value = String(raw).toLowerCase();
        if (value.includes("village")) {
            return nearbyHasSelector(scan, position, VILLAGE_BLOCK_SELECTORS);
        }
        if (value.includes("ocean_ruin")) return nearbyHasSelector(scan, position, "#cobblemon:ocean_ruin_blocks");
        if (value.includes("mansion")) return nearbyHasSelector(scan, position, "#cobblemon:mansion_blocks");
        if (value.includes("pillager_outpost")) {
            return nearbyHasSelector(scan, position, OUTPOST_BLOCK_SELECTORS);
        }
        if (value.includes("swamp_hut")) return nearbyHasSelector(scan, position, "minecraft:spruce_planks");
        if (value.includes("trail_ruins")) {
            return nearbyHasSelector(scan, position, TRAIL_RUINS_BLOCK_SELECTORS);
        }
        return false;
    });
}

function isSlimeChunk(location) {
    const chunkX = Math.floor(location.x / 16);
    const chunkZ = Math.floor(location.z / 16);
    let hash = Math.imul(chunkX, 0x1f1f1f1f) ^ Math.imul(chunkZ, 0x5f356495);
    hash ^= hash >>> 16;
    return (hash >>> 0) % 10 === 0;
}

function conditionMatches(scan, position, condition) {
    const location = position.blockLocation;
    const lightLocation = { x: location.x, y: location.y + 1, z: location.z };
    if (condition.minY !== undefined && location.y < Number(condition.minY)) return false;
    if (condition.maxY !== undefined && location.y > Number(condition.maxY)) return false;
    if (condition.isRaining !== undefined && (scan.weather !== "clear") !== Boolean(condition.isRaining)) return false;
    if (condition.isThundering !== undefined && (scan.weather === "thunder") !== Boolean(condition.isThundering)) return false;
    if (condition.timeRange !== undefined && !timeRangeMatches(condition.timeRange, scan.time)) return false;
    if (condition.moonPhase !== undefined && scan.moonPhase !== Number(condition.moonPhase)) return false;
    if (condition.isSlimeChunk !== undefined && isSlimeChunk(location) !== Boolean(condition.isSlimeChunk)) return false;
    if (condition.minDepth !== undefined && position.depth < Number(condition.minDepth)) return false;
    if (condition.maxDepth !== undefined && position.depth > Number(condition.maxDepth)) return false;
    if (condition.neededBaseBlocks !== undefined && !selectorMatchesBlock(scan, condition.neededBaseBlocks, position.baseBlock)) return false;
    if (condition.fluid !== undefined) {
        const fluidLocation = position.fluidConditionLocation || location;
        if (!selectorMatchesBlock(scan, condition.fluid, cachedBlock(scan, fluidLocation.x, fluidLocation.y, fluidLocation.z))) return false;
    }

    if (condition.biomes !== undefined && !conditionBiomeMatches(condition, cachedBiomeId(scan, location))) return false;

    const skyLight = condition.minSkyLight !== undefined || condition.maxSkyLight !== undefined
        ? cachedLight(scan, lightLocation, true)
        : undefined;
    if (condition.minSkyLight !== undefined && skyLight < Number(condition.minSkyLight)) return false;
    if (condition.maxSkyLight !== undefined && skyLight > Number(condition.maxSkyLight)) return false;

    const light = condition.minLight !== undefined || condition.maxLight !== undefined
        ? cachedLight(scan, lightLocation, false)
        : undefined;
    if (condition.minLight !== undefined && light < Number(condition.minLight)) return false;
    if (condition.maxLight !== undefined && light > Number(condition.maxLight)) return false;

    if (condition.canSeeSky !== undefined && canSeeSky(scan, lightLocation) !== Boolean(condition.canSeeSky)) return false;
    if (condition.neededNearbyBlocks !== undefined && !nearbyHasSelector(scan, position, condition.neededNearbyBlocks)) return false;
    if (condition.structures !== undefined && !structureMatches(scan, position, condition.structures)) return false;
    return true;
}

function conditionSetMatches(scan, position, conditions, anticonditions) {
    const positive = !conditions?.length || conditions.some(condition => conditionMatches(scan, position, condition));
    if (!positive) return false;
    return !anticonditions?.some(condition => conditionMatches(scan, position, condition));
}

function evaluateEntryRuleAtPosition(scan, position, entry) {
    if (!conditionSetMatches(scan, position, entry.conditions, entry.anticonditions)) return undefined;
    const multipliers = [];
    for (const multiplier of entry.weightMultipliers || []) {
        if (conditionSetMatches(scan, position, multiplier.conditions, multiplier.anticonditions)) {
            multipliers.push(Number(multiplier.multiplier) || 1);
        }
    }
    return multipliers;
}

function candidateWeight(match, candidate) {
    let weight = match.baseWeight;
    for (const multiplier of candidate.multipliers) weight *= multiplier;
    return weight;
}

function* buildSpawnSelectionJob(scan, positions, bucket) {
    const typeGroups = [];
    const positionsByType = new Map();
    for (const position of positions) {
        if (!positionsByType.has(position.positionType)) positionsByType.set(position.positionType, []);
        positionsByType.get(position.positionType).push(position);
    }
    for (const positionType of ["grounded", "submerged", "surface", "seafloor"]) {
        const typePositions = positionsByType.get(positionType) || [];
        const compiledEntries = ENTRY_GROUPS_BY_BUCKET_AND_POSITION.get(`${bucket}|${positionType}`);
        if (!typePositions.length || !compiledEntries?.orderedEntries.length) continue;

        const matches = [];
        const evaluations = new Map();
        for (const ruleGroup of compiledEntries.ruleGroups) {
            const weightedPositions = [];
            for (const position of typePositions) {
                const multipliers = evaluateEntryRuleAtPosition(scan, position, ruleGroup.representative);
                if (multipliers !== undefined) weightedPositions.push({ position, multipliers });
                yield;
            }
            evaluations.set(ruleGroup, { weightedPositions, maximumWeightsByBase: new Map() });
        }

        for (const { entry, ruleGroup } of compiledEntries.orderedEntries) {
            const evaluation = evaluations.get(ruleGroup);
            const { weightedPositions, maximumWeightsByBase } = evaluation;
            if (!weightedPositions.length) continue;
            const baseWeight = Number(entry.weight) || 0;
            if (!maximumWeightsByBase.has(baseWeight)) {
                const probe = { baseWeight };
                maximumWeightsByBase.set(baseWeight, weightedPositions.reduce(
                    (maximum, candidate) => Math.max(maximum, candidateWeight(probe, candidate)),
                    0
                ));
            }
            const maximumWeight = maximumWeightsByBase.get(baseWeight);
            if (maximumWeight <= 0) continue;
            matches.push({ entry, weightedPositions, baseWeight, maximumWeight });
        }
        if (matches.length) {
            typeGroups.push({
                positionType,
                matches,
                weight: (CONFIG.positionTypeWeights[positionType] || 1) * matches.length
            });
        }
    }

    return typeGroups;
}

function chooseSpawn(typeGroups) {
    const selectedType = weightedChoice(typeGroups, group => group.weight);
    if (!selectedType) return undefined;
    const selectedEntry = weightedChoice(selectedType.matches, match => match.maximumWeight);
    if (!selectedEntry) return undefined;
    const selectedPosition = weightedChoice(
        selectedEntry.weightedPositions,
        candidate => candidateWeight(selectedEntry, candidate)
    );
    if (!selectedPosition) return undefined;
    return { entry: selectedEntry.entry, position: selectedPosition.position };
}

function removeSelectionPositionsNear(typeGroups, selectedPosition) {
    const filteredBySource = new Map();
    for (const group of typeGroups) {
        for (const match of group.matches) {
            const source = match.weightedPositions;
            if (!filteredBySource.has(source)) {
                const weightedPositions = filterPositionsOutsideMinimumDistance(
                    source,
                    selectedPosition,
                    CONFIG.minimumDistanceBetweenEntities
                );
                filteredBySource.set(source, { weightedPositions, maximumWeightsByBase: new Map() });
            }
            const filtered = filteredBySource.get(source);
            match.weightedPositions = filtered.weightedPositions;
            if (!filtered.maximumWeightsByBase.has(match.baseWeight)) {
                filtered.maximumWeightsByBase.set(match.baseWeight, match.weightedPositions.reduce(
                    (maximum, candidate) => Math.max(maximum, candidateWeight(match, candidate)),
                    0
                ));
            }
            match.maximumWeight = filtered.maximumWeightsByBase.get(match.baseWeight);
        }
        group.matches = group.matches.filter(match => match.weightedPositions.length && match.maximumWeight > 0);
        group.weight = (CONFIG.positionTypeWeights[group.positionType] || 1) * group.matches.length;
    }
    return typeGroups.filter(group => group.matches.length && group.weight > 0);
}

function applySpawnProperties(pokemon, entry) {
    const tokens = String(entry.pokemon || entry.species).trim().split(/\s+/).slice(1);
    const properties = {};
    for (const token of tokens) {
        if (token.includes("=")) {
            const [key, value] = token.split("=", 2);
            properties[key] = value;
            pokemon.aspects.push(`${key}-${value}`);
        } else {
            pokemon.aspects.push(token);
            if (["alolan", "galarian", "hisuian", "paldean", "valencian"].includes(token)) pokemon.form = token;
        }
    }
    pokemon.aspects = [...new Set(pokemon.aspects)];
    pokemon.spawnProperties = properties;
    pokemon.spawnEntry = entry.id;
    pokemon.spawnBucket = entry.bucket;
    pokemon.spawnedNaturally = true;
}

function applyOriginalSpeciesGeneration(pokemon, entry) {
    const base = NATURAL_SPAWN_DATA.species?.[entry.species];
    if (!base) return;
    const form = (base.forms || []).find(candidate =>
        candidate.aspects?.length && !candidate.aspects.includes('female') && candidate.aspects.every(aspect => pokemonVisualAspects(pokemon).has(aspect))
    );
    const metadata = form || base;

    const maleRatio = pokemonGenderRatio(entry.species, metadata);
    const specifiedGender = String(pokemon.spawnProperties?.gender || String(entry.pokemon || '').match(/\b(male|female|genderless)\b/i)?.[1] || '').toUpperCase();
    pokemon.gender = ['MALE', 'FEMALE', 'GENDERLESS'].includes(specifiedGender) ? specifiedGender : maleRatio < 0 ? "GENDERLESS" : Math.random() < maleRatio ? "MALE" : "FEMALE";
    pokemon.aspects = pokemon.aspects.filter(aspect => !["male", "female", "genderless"].includes(aspect));
    pokemon.aspects.push(pokemon.gender.toLowerCase());
    const visualForm = pokemonModelVariant(pokemon)?.data;

    const originalAbilities = visualForm?.abilities || metadata.abilities;
    const ordinaryAbilities = asArray(originalAbilities).filter(ability => !String(ability).startsWith("h:"));
    const abilities = ordinaryAbilities.length ? ordinaryAbilities : asArray(originalAbilities).map(ability => String(ability).replace(/^h:/, ""));
    if (abilities.length) pokemon.ability = abilities[Math.floor(Math.random() * abilities.length)];

    pokemon.friendship = Number(visualForm?.baseFriendship ?? metadata.baseFriendship);
    if (visualForm) pokemon.moves = initialMovesForSpecies(entry.species, pokemon.level, visualForm);

    const baseHp = Math.max(1, Number(visualForm?.baseStats?.hp ?? metadata.baseHp) || 45);
    const hpIv = Math.max(0, Number(pokemon.ivs?.hp) || 0);
    const hpEv = Math.max(0, Number(pokemon.evs?.hp) || 0);
    pokemon.maxHp = Math.floor(((2 * baseHp + hpIv + Math.floor(hpEv / 4)) * pokemon.level) / 100) + pokemon.level + 10;
    pokemon.currentHp = pokemon.maxHp;
}

function spawnPokemon(player, players, selection, highestPartyLevel) {
    let entity;
    try {
        if (!isNaturalSpawnFarEnoughFromPlayers(
            selection.position.location,
            player.id,
            players,
            CONFIG
        )) return undefined;
        if (isNaturalSpawnLocationBlocked(player.dimension.id, selection.position.location)) return undefined;
        entity = player.dimension.spawnEntity(selection.entry.entityType, selection.position.location);
        entity.addTag(NATURAL_TAG);
        entity.setDynamicProperty("lota:natural_spawn_age", 0);
        entity.setDynamicProperty("lota:natural_spawn_entry", selection.entry.id);

        const level = chooseNaturalSpawnLevel(
            highestPartyLevel,
            selection.entry.minimumLevel,
            selection.entry.maximumLevel
        );
        const pokemon = generateRandomPokemon(selection.entry.entityType, level);
        applySpawnProperties(pokemon, selection.entry);
        applyOriginalSpeciesGeneration(pokemon, selection.entry);
        savePokemonToEntity(entity, pokemon);

        try { entity.setProperty("lota:scale_factor", 0.8 + Math.random() * 0.4); } catch (error) {}
        try { entity.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
        entity.nameTag = `§f${pokemon.nickname} Lv. ${pokemon.level}§r`;
        return entity;
    } catch (error) {
        try { if (isValidEntity(entity)) entity.remove(); } catch (removeError) {}
        console.warn(`[NaturalSpawning] Failed to spawn ${selection.entry.id}: ${error}`);
        return undefined;
    }
}

function chooseBucket() {
    return weightedChoice(CONFIG.buckets, bucket => bucket.weight)?.name;
}

function spawnPassStillValid(player, dimensionId) {
    return isValidEntity(player)
        && DIMENSION_IDS.includes(player?.dimension?.id)
        && player.dimension.id === dimensionId;
}

function spawnLocationStillReady(player, dimensionId, location) {
    if (!spawnPassStillValid(player, dimensionId) || !location) return false;
    const maximumDistance = CONFIG.maximumSpawningZoneDistanceFromPlayer
        + CONFIG.spawningZoneDiameter;
    const dx = Number(location.x) - Number(player.location.x);
    const dz = Number(location.z) - Number(player.location.z);
    if (!Number.isFinite(dx) || !Number.isFinite(dz)
        || dx * dx + dz * dz > maximumDistance * maximumDistance) return false;

    try {
        if (typeof player.dimension.isChunkLoaded === "function"
            && !player.dimension.isChunkLoaded(location)) return false;
        return Boolean(player.dimension.getBlock({
            x: Math.floor(location.x),
            y: Math.floor(location.y),
            z: Math.floor(location.z)
        }));
    } catch (error) {
        return false;
    }
}

function* runSpawnPassJob(player) {
    if (!isValidEntity(player)) return;
    const scan = createScanContext(player);
    const dimensionId = player.dimension.id;
    const intersectsBlockedZone = scan
        && doesNaturalSpawnAreaIntersectZone(dimensionId, scan);
    if (!scan
        || (intersectsBlockedZone && isNaturalSpawnAreaFullyBlocked(dimensionId, scan))
        || isEntityLimitReached(scan)) return;

    const collectedPositions = yield* collectSpawnablePositionsJob(scan);
    if (!spawnPassStillValid(player, dimensionId)) return;
    let players = [];
    try { players = scan.dimension.getPlayers(); } catch (error) { return; }
    let positions = removePositionsNearPlayers(
        removePositionsNearLivingEntities(
            scan,
            collectedPositions,
            player
        ),
        player,
        players
    );
    if (intersectsBlockedZone) {
        positions = positions.filter(position => !isNaturalSpawnLocationBlocked(dimensionId, position.location));
    }
    if (!positions.length) return;
    const bucket = chooseBucket();
    if (!bucket) return;
    const selectionData = yield* buildSpawnSelectionJob(scan, positions, bucket);
    if (!selectionData.length) return;
    if (!spawnPassStillValid(player, dimensionId)) return;
    const highestPartyLevel = highestNaturalSpawnPartyLevel(loadPartyFromPlayer(player));

    let spawned = 0;
    while (spawned < CONFIG.maximumSpawnsPerPass) {
        const selection = chooseSpawn(selectionData);
        if (!selection) break;
        removeSelectionPositionsNear(selectionData, selection.position);
        try { players = scan.dimension.getPlayers(); } catch (error) { break; }
        if (!spawnPassStillValid(player, dimensionId)) break;
        if (!spawnLocationStillReady(player, dimensionId, selection.position.location)) continue;
        if (isEntityLimitReached(scan)) break;
        const entity = spawnPokemon(player, players, selection, highestPartyLevel);
        if (!entity) break;
        spawned++;
        yield;
    }
}

function queueSpawnPass(player) {
    if (!isValidEntity(player)
        || !DIMENSION_IDS.includes(player?.dimension?.id)
        || ACTIVE_PLAYER_SPAWN_JOBS.has(player.id)) return false;
    const playerId = player.id;
    const token = { jobId: undefined, playerId, playerLabel: player.name || playerId };
    ACTIVE_PLAYER_SPAWN_JOBS.set(playerId, token);
    const guardedJob = (function* () {
        try {
            yield* runSpawnPassJob(player);
        } catch (error) {
            console.error(`[NaturalSpawning] Spawn pass failed for ${token.playerLabel}: ${error}`);
        } finally {
            if (ACTIVE_PLAYER_SPAWN_JOBS.get(playerId) === token) {
                ACTIVE_PLAYER_SPAWN_JOBS.delete(playerId);
            }
        }
    })();
    try {
        token.jobId = system.runJob(guardedJob);
        return true;
    } catch (error) {
        ACTIVE_PLAYER_SPAWN_JOBS.delete(playerId);
        console.error(`[NaturalSpawning] Failed to queue spawn pass for ${token.playerLabel}: ${error}`);
        return false;
    }
}

function tickPlayerSpawners() {
    const currentTick = system.currentTick;
    const activePlayers = new Set();
    const players = world.getAllPlayers();
    for (const player of players) {
        if (!isValidEntity(player)) continue;
        activePlayers.add(player.id);
        if (!isPokemonSpawningAllowed(player)) {
            PLAYER_NEXT_ATTEMPT.delete(player.id);
            continue;
        }
        if (!PLAYER_NEXT_ATTEMPT.has(player.id)) {
            PLAYER_NEXT_ATTEMPT.set(player.id, createStaggeredInitialAttemptTick(
                currentTick,
                INITIAL_SPAWN_DELAY_TICKS,
                CONFIG.ticksBetweenSpawnAttempts,
                nextPlayerSpawnPhase++
            ));
            continue;
        }
        if (currentTick < PLAYER_NEXT_ATTEMPT.get(player.id)) continue;
        PLAYER_NEXT_ATTEMPT.set(player.id, currentTick + CONFIG.ticksBetweenSpawnAttempts);
        queueSpawnPass(player);
    }
    for (const playerId of PLAYER_NEXT_ATTEMPT.keys()) {
        if (!activePlayers.has(playerId)) PLAYER_NEXT_ATTEMPT.delete(playerId);
    }
}

function tickNaturalDespawn() {
    for (const dimensionId of DIMENSION_IDS) {
        let dimension;
        try { dimension = world.getDimension(dimensionId); } catch (error) { continue; }
        let entities = [];
        try { entities = dimension.getEntities({ tags: [NATURAL_TAG] }); } catch (error) { continue; }
        if (!entities.length) continue;
        let players = [];
        try { players = dimension.getPlayers(); } catch (error) {}
        const playerIndex = createEntitySpatialIndex(players, CONFIG.despawnerFarDistance);
        const hasBlockedZones = hasNaturalSpawnZones(dimensionId);

        for (const entity of entities) {
            if (!isValidEntity(entity)) continue;
            const age = advanceLoadedNaturalAge(entity.getDynamicProperty("lota:natural_spawn_age"), 20);
            entity.setDynamicProperty("lota:natural_spawn_age", age);
            if (entity.hasTag("lota:in_battle") || entity.hasTag("lota:party_pokemon")) continue;
            if (hasBlockedZones && isNaturalSpawnLocationBlocked(dimensionId, entity.location)) {
                try { entity.remove(); } catch (error) {}
                continue;
            }
            if (age < CONFIG.despawnerMinAgeTicks) continue;
            try {
                const riders = entity.getComponent("minecraft:rideable")?.getRiders?.() || [];
                if (riders.length) continue;
            } catch (error) {}

            const distance = nearestIndexedEntityDistance(
                entity.location,
                playerIndex,
                CONFIG.despawnerFarDistance
            );
            if (shouldNaturallyDespawn(age, distance, CONFIG)) {
                try { entity.remove(); } catch (error) {}
            }
        }
    }
}

world.afterEvents.weatherChange.subscribe(event => {
    WEATHER_BY_DIMENSION.set(String(event.dimension), normalizeWeather(event.newWeather));
});

world.afterEvents.playerLeave.subscribe(event => {
    PLAYER_NEXT_ATTEMPT.delete(event.playerId);
    const token = ACTIVE_PLAYER_SPAWN_JOBS.get(event.playerId);
    ACTIVE_PLAYER_SPAWN_JOBS.delete(event.playerId);
    if (token?.jobId === undefined) return;
    try { system.clearJob(token.jobId); } catch (error) {}
});

system.runInterval(tickPlayerSpawners, 1);
system.runInterval(tickNaturalDespawn, 20);
