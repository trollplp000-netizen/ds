export const MOVE_DATA = Object.freeze({
    "absorb": {
        "id": "absorb",
        "name": "Absorb",
        "type": "grass",
        "category": "special",
        "power": 20,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "accelerock": {
        "id": "accelerock",
        "name": "Accelerock",
        "type": "rock",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "acid": {
        "id": "acid",
        "name": "Acid",
        "type": "poison",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the foe(s) Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "acidarmor": {
        "id": "acidarmor",
        "name": "Acid Armor",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 2 stages.",
        "shortDescription": "Raises the user's Defense by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 2
        }
    },
    "acidspray": {
        "id": "acidspray",
        "name": "Acid Spray",
        "type": "poison",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Defense by 2 stages.",
        "shortDescription": "100% chance to lower the target's Sp. Def by 2.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spd": -2
                }
            }
        ]
    },
    "acrobatics": {
        "id": "acrobatics",
        "name": "Acrobatics",
        "type": "flying",
        "category": "physical",
        "power": 55,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "any",
        "description": "Power doubles if the user has no held item.",
        "shortDescription": "Power doubles if the user has no held item.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ]
    },
    "acupressure": {
        "id": "acupressure",
        "name": "Acupressure",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "adjacentAllyOrSelf",
        "description": "Raises a random stat by 2 stages as long as the stat is not already at stage 6. The user can choose to use this move on itself or an adjacent ally. Fails if no stat stage can be raised or if used on an ally with a substitute.",
        "shortDescription": "Raises a random stat of the user or an ally by 2.",
        "flags": [
            "metronome"
        ]
    },
    "aerialace": {
        "id": "aerialace",
        "name": "Aerial Ace",
        "type": "flying",
        "category": "physical",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome",
            "slicing"
        ]
    },
    "aeroblast": {
        "id": "aeroblast",
        "name": "Aeroblast",
        "type": "flying",
        "category": "special",
        "power": 100,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "any",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "wind"
        ],
        "critRatio": 2
    },
    "afteryou": {
        "id": "afteryou",
        "name": "After You",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The target makes its move immediately after the user this turn, no matter the priority of its selected move. Fails if the target would have moved next anyway, or if the target already moved this turn.",
        "shortDescription": "The target makes its move right after the user.",
        "flags": [
            "bypasssub",
            "allyanim"
        ]
    },
    "agility": {
        "id": "agility",
        "name": "Agility",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Speed by 2 stages.",
        "shortDescription": "Raises the user's Speed by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spe": 2
        }
    },
    "aircutter": {
        "id": "aircutter",
        "name": "Air Cutter",
        "type": "flying",
        "category": "special",
        "power": 60,
        "accuracy": 95,
        "pp": 25,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "slicing",
            "wind"
        ],
        "critRatio": 2
    },
    "airslash": {
        "id": "airslash",
        "name": "Air Slash",
        "type": "flying",
        "category": "special",
        "power": 75,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "any",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "slicing"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "allyswitch": {
        "id": "allyswitch",
        "name": "Ally Switch",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 2,
        "target": "self",
        "description": "The user swaps positions with its ally. Fails if the user is the only Pokemon on its side. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails or if the user's last move used is not Ally Switch.",
        "shortDescription": "User and ally swap positions; using again can fail.",
        "flags": [
            "metronome"
        ]
    },
    "amnesia": {
        "id": "amnesia",
        "name": "Amnesia",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Defense by 2 stages.",
        "shortDescription": "Raises the user's Sp. Def by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spd": 2
        }
    },
    "anchorshot": {
        "id": "anchorshot",
        "name": "Anchor Shot",
        "type": "steel",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Prevents the target from switching out.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "ancientpower": {
        "id": "ancientpower",
        "name": "Ancient Power",
        "type": "rock",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to raise the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage.",
        "shortDescription": "10% chance to raise all stats by 1 (not acc/eva).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "selfBoosts": {
                    "atk": 1,
                    "def": 1,
                    "spa": 1,
                    "spd": 1,
                    "spe": 1
                }
            }
        ]
    },
    "appleacid": {
        "id": "appleacid",
        "name": "Apple Acid",
        "type": "grass",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "100% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "aquacutter": {
        "id": "aquacutter",
        "name": "Aqua Cutter",
        "type": "water",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "aquajet": {
        "id": "aquajet",
        "name": "Aqua Jet",
        "type": "water",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "aquaring": {
        "id": "aquaring",
        "name": "Aqua Ring",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "The user has 1/16 of its maximum HP, rounded down, restored at the end of each turn while it remains active. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down. If the user uses Baton Pass, the replacement will receive the healing effect.",
        "shortDescription": "User recovers 1/16 max HP per turn.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "volatileStatus": "aquaring"
    },
    "aquastep": {
        "id": "aquastep",
        "name": "Aqua Step",
        "type": "water",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Speed by 1 stage.",
        "shortDescription": "100% chance to raise the user's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "dance",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spe": 1
                }
            }
        ]
    },
    "aquatail": {
        "id": "aquatail",
        "name": "Aqua Tail",
        "type": "water",
        "category": "physical",
        "power": 90,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "armorcannon": {
        "id": "armorcannon",
        "name": "Armor Cannon",
        "type": "fire",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense and Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror"
        ],
        "selfBoosts": {
            "def": -1,
            "spd": -1
        }
    },
    "armthrust": {
        "id": "armthrust",
        "name": "Arm Thrust",
        "type": "fighting",
        "category": "physical",
        "power": 15,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "aromatherapy": {
        "id": "aromatherapy",
        "name": "Aromatherapy",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "allyTeam",
        "description": "Every Pokemon in the user's party is cured of its non-volatile status condition. Active Pokemon with the Sap Sipper Ability are not cured, unless they are the user.",
        "shortDescription": "Cures the user's party of all status conditions.",
        "flags": [
            "snatch",
            "distance",
            "metronome"
        ]
    },
    "aromaticmist": {
        "id": "aromaticmist",
        "name": "Aromatic Mist",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "adjacentAlly",
        "description": "Raises the target's Special Defense by 1 stage. Fails if there is no ally adjacent to the user.",
        "shortDescription": "Raises an ally's Sp. Def by 1.",
        "flags": [
            "bypasssub",
            "metronome"
        ],
        "boosts": {
            "spd": 1
        }
    },
    "assist": {
        "id": "assist",
        "name": "Assist",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "A random move among those known by the user's party members is selected for use. Does not select Assist, Baneful Bunker, Beak Blast, Belch, Bestow, Blazing Torque, Bounce, Celebrate, Chatter, Circle Throw, Combat Torque, Copycat, Counter, Covet, Destiny Bond, Detect, Dig, Dive, Dragon Tail, Endure, Feint, Fly, Focus Punch, Follow Me, Helping Hand, Hold Hands, King's Shield, Magical Torque, Mat Block, Me First, Metronome, Mimic, Mirror Coat, Mirror Move, Nature Power, Noxious Torque, Phantom Force, Protect, Rage Powder, Roar, Shadow Force, Shell Trap, Sketch, Sky Drop, Sleep Talk, Snatch, Spiky Shield, Spotlight, Struggle, Switcheroo, Tera Starstorm, Thief, Transform, Trick, Whirlwind, or Wicked Torque.",
        "shortDescription": "Uses a random move known by a team member.",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "assurance": {
        "id": "assurance",
        "name": "Assurance",
        "type": "dark",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target has already taken damage this turn, other than direct damage from Belly Drum, confusion, Curse, or Pain Split.",
        "shortDescription": "Power doubles if target was damaged this turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "astonish": {
        "id": "astonish",
        "name": "Astonish",
        "type": "ghost",
        "category": "physical",
        "power": 30,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "attackorder": {
        "id": "attackorder",
        "name": "Attack Order",
        "type": "bug",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "attract": {
        "id": "attract",
        "name": "Attract",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become infatuated, making it unable to attack 50% of the time. Fails if both the user and the target are the same gender, if either is genderless, or if the target is already infatuated. The effect ends when either the user or the target is no longer active. Pokemon with the Oblivious Ability or protected by the Aroma Veil Ability are immune.",
        "shortDescription": "A target of the opposite gender gets infatuated.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "attract"
    },
    "aurasphere": {
        "id": "aurasphere",
        "name": "Aura Sphere",
        "type": "fighting",
        "category": "special",
        "power": 80,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "bullet",
            "pulse"
        ]
    },
    "aurawheel": {
        "id": "aurawheel",
        "name": "Aura Wheel",
        "type": "electric",
        "category": "physical",
        "power": 110,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Speed by 1 stage. If the user is a Morpeko in Full Belly Mode, this move is Electric type. If the user is a Morpeko in Hangry Mode, this move is Dark type. This move cannot be used successfully unless the user's current form, while considering Transform, is Full Belly or Hangry Mode Morpeko.",
        "shortDescription": "Morpeko: Electric; Hangry: Dark; 100% +1 Spe.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spe": 1
                }
            }
        ]
    },
    "aurorabeam": {
        "id": "aurorabeam",
        "name": "Aurora Beam",
        "type": "ice",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "10% chance to lower the target's Attack by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "auroraveil": {
        "id": "auroraveil",
        "name": "Aurora Veil",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members take 0.5x damage from physical and special attacks, or 0.66x damage if in a Double Battle; does not reduce damage further with Reflect or Light Screen. Critical hits ignore this protection. It is removed from the user's side if the user or an ally is successfully hit by Brick Break, Psychic Fangs, or Defog. Brick Break and Psychic Fangs remove the effect before damage is calculated. Lasts for 8 turns if the user is holding Light Clay. Fails unless the weather is Hail.",
        "shortDescription": "For 5 turns, damage to allies halved. Snow only.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "auroraveil"
    },
    "autotomize": {
        "id": "autotomize",
        "name": "Autotomize",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Speed by 2 stages. If the user's Speed was changed, the user's weight is reduced by 100 kg as long as it remains active. This effect is stackable but cannot reduce the user's weight to less than 0.1 kg.",
        "shortDescription": "Raises the user's Speed by 2; user loses 100 kg.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spe": 2
        }
    },
    "avalanche": {
        "id": "avalanche",
        "name": "Avalanche",
        "type": "ice",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": -4,
        "target": "normal",
        "description": "Power doubles if the user was hit by the target this turn.",
        "shortDescription": "Power doubles if user is damaged by the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "axekick": {
        "id": "axekick",
        "name": "Axe Kick",
        "type": "fighting",
        "category": "physical",
        "power": 120,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to confuse the target. If this attack is not successful, the user loses half of its maximum HP, rounded down, as crash damage. Pokemon with the Magic Guard Ability are unaffected by crash damage.",
        "shortDescription": "30% confusion. User loses 50% max HP if miss.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "confusion"
            }
        ]
    },
    "babydolleyes": {
        "id": "babydolleyes",
        "name": "Baby-Doll Eyes",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "Lowers the target's Attack by 1 stage.",
        "shortDescription": "Lowers the target's Attack by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "atk": -1
        }
    },
    "banefulbunker": {
        "id": "banefulbunker",
        "name": "Baneful Bunker",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn, and Pokemon making contact with the user become poisoned. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Protects from moves. Contact: poison.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "banefulbunker"
    },
    "barbbarrage": {
        "id": "barbbarrage",
        "name": "Barb Barrage",
        "type": "poison",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to poison the target. Power doubles if the target is already poisoned.",
        "shortDescription": "50% psn. 2x power if target already poisoned.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "status": "psn"
            }
        ]
    },
    "barrage": {
        "id": "barrage",
        "name": "Barrage",
        "type": "normal",
        "category": "physical",
        "power": 15,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "barrier": {
        "id": "barrier",
        "name": "Barrier",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 2 stages.",
        "shortDescription": "Raises the user's Defense by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 2
        }
    },
    "batonpass": {
        "id": "batonpass",
        "name": "Baton Pass",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "self",
        "description": "The user is replaced with another Pokemon in its party. The selected Pokemon has the user's stat stage changes, confusion, and certain move effects transferred to it.",
        "shortDescription": "User switches, passing stat changes and more.",
        "flags": [
            "metronome"
        ],
        "selfSwitch": "copyvolatile"
    },
    "beakblast": {
        "id": "beakblast",
        "name": "Beak Blast",
        "type": "flying",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 15,
        "priority": -3,
        "target": "normal",
        "description": "If the user is hit by a contact move this turn before it can execute this move, the attacker is burned.",
        "shortDescription": "Burns on contact with the user before it moves.",
        "flags": [
            "protect",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failinstruct",
            "bullet"
        ]
    },
    "beatup": {
        "id": "beatup",
        "name": "Beat Up",
        "type": "dark",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits one time for the user and one time for each unfainted Pokemon without a non-volatile status condition in the user's party. The power of each hit is equal to 5+(X/10), where X is each participating Pokemon's base Attack; each hit is considered to come from the user.",
        "shortDescription": "All healthy allies aid in damaging the target.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "behemothbash": {
        "id": "behemothbash",
        "name": "Behemoth Bash",
        "type": "steel",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "failcopycat",
            "failmimic"
        ]
    },
    "behemothblade": {
        "id": "behemothblade",
        "name": "Behemoth Blade",
        "type": "steel",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "failcopycat",
            "failmimic",
            "slicing"
        ]
    },
    "belch": {
        "id": "belch",
        "name": "Belch",
        "type": "poison",
        "category": "special",
        "power": 120,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move cannot be selected until the user eats a Berry, either by eating one that was held, stealing and eating one off another Pokemon with Bug Bite or Pluck, or eating one that was thrown at it with Fling. Once the condition is met, this move can be selected and used for the rest of the battle even if the user gains or uses another item or switches out. Consuming a Berry with Natural Gift does not count for the purposes of eating one.",
        "shortDescription": "Cannot be selected until the user eats a Berry.",
        "flags": [
            "protect",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "bellydrum": {
        "id": "bellydrum",
        "name": "Belly Drum",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack by 12 stages in exchange for the user losing 1/2 of its maximum HP, rounded down. Fails if the user would faint or if its Attack stat stage is 6.",
        "shortDescription": "User loses 50% max HP. Maximizes Attack.",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "bestow": {
        "id": "bestow",
        "name": "Bestow",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The target receives the user's held item. Fails if the user has no item or is holding a Mail or Z-Crystal, if the target is already holding an item, if the user is a Kyogre holding a Blue Orb, a Groudon holding a Red Orb, a Giratina holding a Griseous Orb, an Arceus holding a Plate, a Genesect holding a Drive, a Silvally holding a Memory, a Pokemon that can Mega Evolve holding the Mega Stone for its species, or if the target is one of those Pokemon and the user is holding the respective item.",
        "shortDescription": "User passes its held item to the target.",
        "flags": [
            "mirror",
            "bypasssub",
            "allyanim",
            "noassist",
            "failcopycat"
        ]
    },
    "bide": {
        "id": "bide",
        "name": "Bide",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 1,
        "target": "self",
        "description": "The user spends two turns locked into this move and then, on the second turn after using this move, the user attacks the last Pokemon that hit it, inflicting double the damage in HP it lost to attacks during the two turns. If the last Pokemon that hit it is no longer active, the user attacks a random opposing Pokemon instead. If the user is prevented from moving during this move's use, the effect ends. This move does not check accuracy and does not ignore type immunity.",
        "shortDescription": "Waits 2 turns; deals double the damage taken.",
        "flags": [
            "contact",
            "protect",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ],
        "volatileStatus": "bide",
        "ignoreImmunity": true
    },
    "bind": {
        "id": "bind",
        "name": "Bind",
        "type": "normal",
        "category": "physical",
        "power": 15,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "bite": {
        "id": "bite",
        "name": "Bite",
        "type": "dark",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "bitterblade": {
        "id": "bitterblade",
        "name": "Bitter Blade",
        "type": "fire",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "heal",
            "metronome",
            "slicing"
        ],
        "drain": [
            1,
            2
        ]
    },
    "blazekick": {
        "id": "blazekick",
        "name": "Blaze Kick",
        "type": "fire",
        "category": "physical",
        "power": 85,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target and a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio. 10% chance to burn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ],
        "critRatio": 2
    },
    "bleakwindstorm": {
        "id": "bleakwindstorm",
        "name": "Bleakwind Storm",
        "type": "flying",
        "category": "special",
        "power": 100,
        "accuracy": 80,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 30% chance to lower the target's Speed by 1 stage. If the weather is Primordial Sea or Rain Dance, this move does not check accuracy. If this move is used against a Pokemon holding Utility Umbrella, this move's accuracy remains at 80%.",
        "shortDescription": "30% to lower foe(s) Speed by 1. Rain: can't miss.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "blizzard": {
        "id": "blizzard",
        "name": "Blizzard",
        "type": "ice",
        "category": "special",
        "power": 110,
        "accuracy": 70,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 10% chance to freeze the target. If the weather is Snow, this move does not check accuracy.",
        "shortDescription": "10% chance to freeze foe(s). Can't miss in Snow.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            }
        ]
    },
    "block": {
        "id": "block",
        "name": "Block",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Prevents the target from switching out.",
        "flags": [
            "reflectable",
            "mirror",
            "metronome"
        ],
        "trapTarget": true
    },
    "bloodmoon": {
        "id": "bloodmoon",
        "name": "Blood Moon",
        "type": "normal",
        "category": "special",
        "power": 140,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Cannot be selected the turn after it's used.",
        "shortDescription": "Cannot be selected the turn after it's used.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "cantusetwice"
        ]
    },
    "blueflare": {
        "id": "blueflare",
        "name": "Blue Flare",
        "type": "fire",
        "category": "special",
        "power": 130,
        "accuracy": 85,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to burn the target.",
        "shortDescription": "20% chance to burn the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "brn"
            }
        ]
    },
    "bodypress": {
        "id": "bodypress",
        "name": "Body Press",
        "type": "fighting",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Damage is calculated using the user's Defense stat as its Attack, including stat stage changes. Other effects that modify the Attack stat are used as normal.",
        "shortDescription": "Uses user's Def stat as Atk in damage calculation.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ]
    },
    "bodyslam": {
        "id": "bodyslam",
        "name": "Body Slam",
        "type": "normal",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "30% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "boltbeak": {
        "id": "boltbeak",
        "name": "Bolt Beak",
        "type": "electric",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user moves before the target.",
        "shortDescription": "Power doubles if user moves before the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "boltstrike": {
        "id": "boltstrike",
        "name": "Bolt Strike",
        "type": "electric",
        "category": "physical",
        "power": 130,
        "accuracy": 85,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to paralyze the target.",
        "shortDescription": "20% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "par"
            }
        ]
    },
    "boneclub": {
        "id": "boneclub",
        "name": "Bone Club",
        "type": "ground",
        "category": "physical",
        "power": 65,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to make the target flinch.",
        "shortDescription": "10% chance to make the target flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "bonemerang": {
        "id": "bonemerang",
        "name": "Bonemerang",
        "type": "ground",
        "category": "physical",
        "power": 50,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "bonerush": {
        "id": "bonerush",
        "name": "Bone Rush",
        "type": "ground",
        "category": "physical",
        "power": 25,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "boomburst": {
        "id": "boomburst",
        "name": "Boomburst",
        "type": "normal",
        "category": "special",
        "power": 140,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacent",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "bounce": {
        "id": "bounce",
        "name": "Bounce",
        "type": "flying",
        "category": "physical",
        "power": 85,
        "accuracy": 85,
        "pp": 5,
        "priority": 0,
        "target": "any",
        "description": "Has a 30% chance to paralyze the target. This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks other than Gust, Hurricane, Sky Uppercut, Smack Down, Thousand Arrows, Thunder, and Twister, and Gust and Twister have doubled power when used against it. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Bounces turn 1. Hits turn 2. 30% paralyze.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "gravity",
            "distance",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "branchpoke": {
        "id": "branchpoke",
        "name": "Branch Poke",
        "type": "grass",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ]
    },
    "bravebird": {
        "id": "bravebird",
        "name": "Brave Bird",
        "type": "flying",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "any",
        "description": "If the target lost HP, the user takes recoil damage equal to 33% the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 33% recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ],
        "recoil": [
            33,
            100
        ]
    },
    "breakingswipe": {
        "id": "breakingswipe",
        "name": "Breaking Swipe",
        "type": "dragon",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "brickbreak": {
        "id": "brickbreak",
        "name": "Brick Break",
        "type": "fighting",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If this attack does not miss, the effects of Reflect, Light Screen, and Aurora Veil end for the target's side of the field before damage is calculated.",
        "shortDescription": "Destroys screens, unless the target is immune.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "brine": {
        "id": "brine",
        "name": "Brine",
        "type": "water",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target has less than or equal to half of its maximum HP remaining.",
        "shortDescription": "Power doubles if the target's HP is 50% or less.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "brutalswing": {
        "id": "brutalswing",
        "name": "Brutal Swing",
        "type": "dark",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacent",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent Pokemon.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "bubble": {
        "id": "bubble",
        "name": "Bubble",
        "type": "water",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 10% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "10% chance to lower the foe(s) Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "bubblebeam": {
        "id": "bubblebeam",
        "name": "Bubble Beam",
        "type": "water",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "10% chance to lower the target's Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "bugbite": {
        "id": "bugbite",
        "name": "Bug Bite",
        "type": "bug",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful and the user has not fainted, it steals the target's held Berry if it is holding one and eats it immediately, gaining its effects even if the user's item is being ignored. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "User steals and eats the target's Berry.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "bugbuzz": {
        "id": "bugbuzz",
        "name": "Bug Buzz",
        "type": "bug",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "bulkup": {
        "id": "bulkup",
        "name": "Bulk Up",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and Defense by 1 stage.",
        "shortDescription": "Raises the user's Attack and Defense by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "def": 1
        }
    },
    "bulldoze": {
        "id": "bulldoze",
        "name": "Bulldoze",
        "type": "ground",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance lower adjacent Pkmn Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "bulletpunch": {
        "id": "bulletpunch",
        "name": "Bullet Punch",
        "type": "steel",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ]
    },
    "bulletseed": {
        "id": "bulletseed",
        "name": "Bullet Seed",
        "type": "grass",
        "category": "physical",
        "power": 25,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "burnup": {
        "id": "burnup",
        "name": "Burn Up",
        "type": "fire",
        "category": "special",
        "power": 130,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Fails unless the user is a Fire type. If this move is successful and the user is not Terastallized, the user's Fire type becomes typeless as long as it remains active.",
        "shortDescription": "User's Fire type becomes typeless; must be Fire.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ]
    },
    "calmmind": {
        "id": "calmmind",
        "name": "Calm Mind",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Attack and Special Defense by 1 stage.",
        "shortDescription": "Raises the user's Sp. Atk and Sp. Def by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spa": 1,
            "spd": 1
        }
    },
    "camouflage": {
        "id": "camouflage",
        "name": "Camouflage",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "The user's type changes based on the battle terrain. Normal type on the regular Wi-Fi terrain, Electric type during Electric Terrain, Fairy type during Misty Terrain, Grass type during Grassy Terrain, and Psychic type during Psychic Terrain. Fails if the user's type cannot be changed or if the user is already purely that type.",
        "shortDescription": "Changes user's type by terrain (default Normal).",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "captivate": {
        "id": "captivate",
        "name": "Captivate",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Special Attack by 2 stages. The target is unaffected if both the user and the target are the same gender, or if either is genderless. Pokemon with the Oblivious Ability are immune.",
        "shortDescription": "Lowers the foe(s) Sp. Atk by 2 if opposite gender.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "spa": -2
        }
    },
    "ceaselessedge": {
        "id": "ceaselessedge",
        "name": "Ceaseless Edge",
        "type": "dark",
        "category": "physical",
        "power": 65,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it sets up a hazard on the opposing side of the field, damaging each opposing Pokemon that switches in, unless it is a Flying-type Pokemon or has the Levitate Ability. A maximum of three layers may be set, and opponents lose 1/8 of their maximum HP with one layer, 1/6 of their maximum HP with two layers, and 1/4 of their maximum HP with three layers, all rounded down. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, or is hit by Defog.",
        "shortDescription": "Sets a layer of Spikes on the opposing side.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "sideCondition": "spikes",
        "sideConditionTarget": "foe"
    },
    "charge": {
        "id": "charge",
        "name": "Charge",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Defense by 1 stage. The user's next Electric-type attack will have its power doubled; the effect ends when the user is no longer active, or after the user attempts to use any Electric-type move besides Charge, even if it is not successful.",
        "shortDescription": "+1 SpD, user's next Electric move 2x power.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spd": 1
        },
        "volatileStatus": "charge"
    },
    "chargebeam": {
        "id": "chargebeam",
        "name": "Charge Beam",
        "type": "electric",
        "category": "special",
        "power": 50,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 70% chance to raise the user's Special Attack by 1 stage.",
        "shortDescription": "70% chance to raise the user's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 70,
                "selfBoosts": {
                    "spa": 1
                }
            }
        ]
    },
    "charm": {
        "id": "charm",
        "name": "Charm",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack by 2 stages.",
        "shortDescription": "Lowers the target's Attack by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "atk": -2
        }
    },
    "chatter": {
        "id": "chatter",
        "name": "Chatter",
        "type": "flying",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "Has a 100% chance to confuse the target.",
        "shortDescription": "100% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "distance",
            "bypasssub",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "confusion"
            }
        ]
    },
    "chillyreception": {
        "id": "chillyreception",
        "name": "Chilly Reception",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Snow. The user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if there are no unfainted party members.",
        "shortDescription": "Starts Snow. User switches out.",
        "selfSwitch": true,
        "weather": "snow"
    },
    "chipaway": {
        "id": "chipaway",
        "name": "Chip Away",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Ignores the target's stat stage changes, including evasiveness.",
        "shortDescription": "Ignores the target's stat stage changes.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "ignoreEvasion": true
    },
    "chloroblast": {
        "id": "chloroblast",
        "name": "Chloroblast",
        "type": "grass",
        "category": "special",
        "power": 150,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user loses 1/2 of its maximum HP, rounded up, unless the user has the Magic Guard Ability.",
        "shortDescription": "User loses 50% max HP.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "maxHpRecoil": [
            1,
            2
        ]
    },
    "circlethrow": {
        "id": "circlethrow",
        "name": "Circle Throw",
        "type": "fighting",
        "category": "physical",
        "power": 60,
        "accuracy": 90,
        "pp": 10,
        "priority": -6,
        "target": "normal",
        "description": "If both the user and the target have not fainted, the target is forced to switch out and be replaced with a random unfainted ally. This effect fails if the target is under the effect of Ingrain, has the Suction Cups Ability, or this move hit a substitute.",
        "shortDescription": "Forces the target to switch to a random ally.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "noassist",
            "failcopycat"
        ],
        "forceSwitch": true
    },
    "clamp": {
        "id": "clamp",
        "name": "Clamp",
        "type": "water",
        "category": "physical",
        "power": 35,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "clangingscales": {
        "id": "clangingscales",
        "name": "Clanging Scales",
        "type": "dragon",
        "category": "special",
        "power": 110,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the user's Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense by 1.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "clangoroussoul": {
        "id": "clangoroussoul",
        "name": "Clangorous Soul",
        "type": "dragon",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage in exchange for the user losing 33% of its maximum HP, rounded down. Fails if the user would faint or if its Attack, Defense, Special Attack, Special Defense, and Speed stat stages would not change.",
        "shortDescription": "User loses 33% of its max HP. +1 to all stats.",
        "flags": [
            "snatch",
            "sound",
            "dance"
        ],
        "boosts": {
            "atk": 1,
            "def": 1,
            "spa": 1,
            "spd": 1,
            "spe": 1
        }
    },
    "clearsmog": {
        "id": "clearsmog",
        "name": "Clear Smog",
        "type": "poison",
        "category": "special",
        "power": 50,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Resets all of the target's stat stages to 0.",
        "shortDescription": "Resets all of the target's stat stages to 0.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "closecombat": {
        "id": "closecombat",
        "name": "Close Combat",
        "type": "fighting",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense and Sp. Def by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfBoosts": {
            "def": -1,
            "spd": -1
        }
    },
    "coil": {
        "id": "coil",
        "name": "Coil",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack, Defense, and accuracy by 1 stage.",
        "shortDescription": "Raises user's Attack, Defense, accuracy by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "def": 1,
            "accuracy": 1
        }
    },
    "cometpunch": {
        "id": "cometpunch",
        "name": "Comet Punch",
        "type": "normal",
        "category": "physical",
        "power": 18,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "comeuppance": {
        "id": "comeuppance",
        "name": "Comeuppance",
        "type": "dark",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "scripted",
        "description": "Deals damage to the last opposing Pokemon to hit the user with a physical or special attack this turn equal to 1.5 times the HP lost by the user from that attack, rounded down. If the user did not lose HP from that attack, this move deals 1 HP of damage instead. If that opposing Pokemon's position is no longer in use and there is another opposing Pokemon on the field, the damage is done to it instead. Only the last hit of a multi-hit attack is counted. Fails if the user was not hit by an opposing Pokemon's physical or special attack this turn.",
        "shortDescription": "If hit by an attack, returns 1.5x damage.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "failmefirst"
        ]
    },
    "confide": {
        "id": "confide",
        "name": "Confide",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Special Attack by 1 stage.",
        "shortDescription": "Lowers the target's Sp. Atk by 1.",
        "flags": [
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "boosts": {
            "spa": -1
        }
    },
    "confuseray": {
        "id": "confuseray",
        "name": "Confuse Ray",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become confused.",
        "shortDescription": "Confuses the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "confusion"
    },
    "confusion": {
        "id": "confusion",
        "name": "Confusion",
        "type": "psychic",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to confuse the target.",
        "shortDescription": "10% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "confusion"
            }
        ]
    },
    "constrict": {
        "id": "constrict",
        "name": "Constrict",
        "type": "normal",
        "category": "physical",
        "power": 10,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "10% chance to lower the target's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "conversion": {
        "id": "conversion",
        "name": "Conversion",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "The user's type changes to match the original type of the move in its first move slot. Fails if the user cannot change its type, or if the type is one of the user's current types.",
        "shortDescription": "Changes user's type to match its first move.",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "conversion2": {
        "id": "conversion2",
        "name": "Conversion 2",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "The user's type changes to match a type that resists or is immune to the type of the last move used by the target, but not either of its current types. The determined type of the move is used rather than the original type. Fails if the target has not made a move, if the user cannot change its type, or if this move would only be able to select one of the user's current types.",
        "shortDescription": "Changes user's type to resist target's last move.",
        "flags": [
            "bypasssub",
            "metronome"
        ]
    },
    "copycat": {
        "id": "copycat",
        "name": "Copycat",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "The user uses the last move used by any Pokemon, including itself. Fails if no move has been used, or if the last move used was Assist, Baneful Bunker, Beak Blast, Behemoth Bash, Behemoth Blade, Belch, Bestow, Blazing Torque, Celebrate, Chatter, Circle Throw, Combat Torque, Copycat, Counter, Covet, Destiny Bond, Detect, Dragon Tail, Dynamax Cannon, Endure, Feint, Focus Punch, Follow Me, Helping Hand, Hold Hands, King's Shield, Magical Torque, Mat Block, Me First, Metronome, Mimic, Mirror Move, Nature Power, Noxious Torque, Protect, Rage Powder, Roar, Shell Trap, Sketch, Sleep Talk, Snatch, Spiky Shield, Spotlight, Struggle, Switcheroo, Tera Starstorm, Thief, Transform, Trick, Whirlwind, or Wicked Torque.",
        "shortDescription": "Uses the last move used in the battle.",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "cosmicpower": {
        "id": "cosmicpower",
        "name": "Cosmic Power",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Raises the user's Defense and Sp. Def by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 1,
            "spd": 1
        }
    },
    "cottonguard": {
        "id": "cottonguard",
        "name": "Cotton Guard",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 3 stages.",
        "shortDescription": "Raises the user's Defense by 3.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 3
        }
    },
    "cottonspore": {
        "id": "cottonspore",
        "name": "Cotton Spore",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Speed by 2 stages.",
        "shortDescription": "Lowers the target's Speed by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome",
            "powder"
        ],
        "boosts": {
            "spe": -2
        }
    },
    "counter": {
        "id": "counter",
        "name": "Counter",
        "type": "fighting",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": -5,
        "target": "scripted",
        "description": "Deals damage to the last opposing Pokemon to hit the user with a physical attack this turn equal to twice the HP lost by the user from that attack. If the user did not lose HP from the attack, this move deals 1 HP of damage instead. If that opposing Pokemon's position is no longer in use and there is another opposing Pokemon on the field, the damage is done to it instead. Only the last hit of a multi-hit attack is counted. Fails if the user was not hit by an opposing Pokemon's physical attack this turn.",
        "shortDescription": "If hit by physical attack, returns double damage.",
        "flags": [
            "contact",
            "protect",
            "failmefirst",
            "noassist",
            "failcopycat"
        ]
    },
    "courtchange": {
        "id": "courtchange",
        "name": "Court Change",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "Switches the Mist, Light Screen, Reflect, Spikes, Safeguard, Tailwind, Toxic Spikes, Stealth Rock, Water Pledge, Fire Pledge, Grass Pledge, Sticky Web, Aurora Veil, G-Max Steelsurge, G-Max Cannonade, G-Max Vine Lash, and G-Max Wildfire effects from the user's side to the opposing side and vice versa.",
        "shortDescription": "Swaps user's field effects with the opposing side.",
        "flags": [
            "mirror",
            "metronome"
        ]
    },
    "covet": {
        "id": "covet",
        "name": "Covet",
        "type": "normal",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "If this attack was successful and the user has not fainted, it steals the target's held item if the user is not holding one. The target's item is not stolen if it is a Mail or Z-Crystal, or if the target is a Kyogre holding a Blue Orb, a Groudon holding a Red Orb, a Giratina holding a Griseous Orb, an Arceus holding a Plate, a Genesect holding a Drive, a Silvally holding a Memory, or a Pokemon that can Mega Evolve holding the Mega Stone for its species. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "If the user has no item, it steals the target's.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "failmefirst",
            "noassist",
            "failcopycat"
        ]
    },
    "crabhammer": {
        "id": "crabhammer",
        "name": "Crabhammer",
        "type": "water",
        "category": "physical",
        "power": 100,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "craftyshield": {
        "id": "craftyshield",
        "name": "Crafty Shield",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 3,
        "target": "allySide",
        "description": "The user and its party members are protected from non-damaging attacks made by other Pokemon, including allies, during this turn. Fails if the user moves last this turn or if this move is already in effect for the user's side.",
        "shortDescription": "Protects allies from Status moves this turn.",
        "sideCondition": "craftyshield"
    },
    "crosschop": {
        "id": "crosschop",
        "name": "Cross Chop",
        "type": "fighting",
        "category": "physical",
        "power": 100,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "crosspoison": {
        "id": "crosspoison",
        "name": "Cross Poison",
        "type": "poison",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to poison the target and a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio. 10% chance to poison.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "psn"
            }
        ],
        "critRatio": 2
    },
    "crunch": {
        "id": "crunch",
        "name": "Crunch",
        "type": "dark",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "20% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 20,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "crushclaw": {
        "id": "crushclaw",
        "name": "Crush Claw",
        "type": "normal",
        "category": "physical",
        "power": 75,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "50% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "crushgrip": {
        "id": "crushgrip",
        "name": "Crush Grip",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 120 * (target's current HP / target's maximum HP), rounded half down, but not less than 1.",
        "shortDescription": "More power the more HP the target has left.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "curse": {
        "id": "curse",
        "name": "Curse",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If the user is not a Ghost type, lowers the user's Speed by 1 stage and raises the user's Attack and Defense by 1 stage. If the user is a Ghost type, the user loses 1/2 of its maximum HP, rounded down and even if it would cause fainting, in exchange for the target losing 1/4 of its maximum HP, rounded down, at the end of each turn while it is active. If the target uses Baton Pass, the replacement will continue to be affected. Fails if there is no target or if the target is already affected.",
        "shortDescription": "Curses if Ghost, else -1 Spe, +1 Atk, +1 Def.",
        "flags": [
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "curse"
    },
    "cut": {
        "id": "cut",
        "name": "Cut",
        "type": "normal",
        "category": "physical",
        "power": 50,
        "accuracy": 95,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "darkestlariat": {
        "id": "darkestlariat",
        "name": "Darkest Lariat",
        "type": "dark",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Ignores the target's stat stage changes, including evasiveness.",
        "shortDescription": "Ignores the target's stat stage changes.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "ignoreEvasion": true
    },
    "darkpulse": {
        "id": "darkpulse",
        "name": "Dark Pulse",
        "type": "dark",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "any",
        "description": "Has a 20% chance to make the target flinch.",
        "shortDescription": "20% chance to make the target flinch.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "pulse"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "flinch"
            }
        ]
    },
    "dazzlinggleam": {
        "id": "dazzlinggleam",
        "name": "Dazzling Gleam",
        "type": "fairy",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "decorate": {
        "id": "decorate",
        "name": "Decorate",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Raises the target's Attack and Special Attack by 2 stages.",
        "shortDescription": "Raises the target's Attack and Sp. Atk by 2.",
        "flags": [
            "allyanim"
        ],
        "boosts": {
            "atk": 2,
            "spa": 2
        }
    },
    "defendorder": {
        "id": "defendorder",
        "name": "Defend Order",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Raises the user's Defense and Sp. Def by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 1,
            "spd": 1
        }
    },
    "defensecurl": {
        "id": "defensecurl",
        "name": "Defense Curl",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 1 stage. As long as the user remains active, the power of the user's Ice Ball and Rollout will be doubled (this effect is not stackable).",
        "shortDescription": "Raises the user's Defense by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 1
        },
        "volatileStatus": "defensecurl"
    },
    "defog": {
        "id": "defog",
        "name": "Defog",
        "type": "flying",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's evasiveness by 1 stage. If this move is successful and whether or not the target's evasiveness was affected, the effects of Reflect, Light Screen, Aurora Veil, Safeguard, Mist, Spikes, Toxic Spikes, Stealth Rock, and Sticky Web end for the target's side, and the effects of Spikes, Toxic Spikes, Stealth Rock, and Sticky Web end for the user's side. Ignores a target's substitute, although a substitute will still block the lowering of evasiveness. If there is a terrain active and this move is successful, the terrain will be cleared.",
        "shortDescription": "-1 evasion; clears terrain and hazards on both sides.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ]
    },
    "destinybond": {
        "id": "destinybond",
        "name": "Destiny Bond",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "Until the user's next move, if an opposing Pokemon's attack knocks the user out, that Pokemon faints as well, unless the attack was Doom Desire or Future Sight. Fails if the user used this move successfully as its last move, disregarding moves used through the Dancer Ability.",
        "shortDescription": "If an opponent knocks out the user, it also faints.",
        "flags": [
            "bypasssub",
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "destinybond"
    },
    "detect": {
        "id": "detect",
        "name": "Detect",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Prevents moves from affecting the user this turn.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "protect"
    },
    "diamondstorm": {
        "id": "diamondstorm",
        "name": "Diamond Storm",
        "type": "rock",
        "category": "physical",
        "power": 100,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 50% chance to raise the user's Defense by 2 stages.",
        "shortDescription": "50% chance to raise user's Defense by 2.",
        "flags": [
            "protect",
            "mirror"
        ],
        "selfBoosts": {
            "def": 2
        }
    },
    "dig": {
        "id": "dig",
        "name": "Dig",
        "type": "ground",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks other than Earthquake and Magnitude but takes double damage from them, and is also unaffected by weather. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Digs underground turn 1, strikes turn 2.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "nonsky",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ]
    },
    "direclaw": {
        "id": "direclaw",
        "name": "Dire Claw",
        "type": "poison",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to cause the target to either fall asleep, become poisoned, or become paralyzed.",
        "shortDescription": "50% chance to sleep, poison, or paralyze target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "disable": {
        "id": "disable",
        "name": "Disable",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "For 4 turns, the target's last move used becomes disabled. Fails if one of the target's moves is already disabled, if the target has not made a move, if the target no longer knows the move, or if the move was a Max or G-Max Move.",
        "shortDescription": "For 4 turns, disables the target's last move used.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "disable"
    },
    "disarmingvoice": {
        "id": "disarmingvoice",
        "name": "Disarming Voice",
        "type": "fairy",
        "category": "special",
        "power": 40,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy. Hits foes.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "discharge": {
        "id": "discharge",
        "name": "Discharge",
        "type": "electric",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Has a 30% chance to paralyze the target.",
        "shortDescription": "30% chance to paralyze adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "dive": {
        "id": "dive",
        "name": "Dive",
        "type": "water",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks other than Surf and Whirlpool but takes double damage from them, and is also unaffected by weather. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Dives underwater turn 1, strikes turn 2.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "nonsky",
            "allyanim",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ]
    },
    "dizzypunch": {
        "id": "dizzypunch",
        "name": "Dizzy Punch",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to confuse the target.",
        "shortDescription": "20% chance to confuse the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "confusion"
            }
        ]
    },
    "doodle": {
        "id": "doodle",
        "name": "Doodle",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "adjacentFoe",
        "description": "The user and its ally's Abilities change to match the target's Ability. Does not change Ability if the user's or its ally's is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Multitype, Power Construct, RKS System, Schooling, Shields Down, Stance Change, Tera Shift, Zen Mode, Zero to Hero, or already matches the target. Fails if both the user and its ally's Ability already matches the target, or if the target's Ability is As One, Battle Bond, Comatose, Commander, Disguise, Embody Aspect, Flower Gift, Forecast, Hunger Switch, Ice Face, Illusion, Imposter, Multitype, Neutralizing Gas, Poison Puppeteer, Power Construct, Power of Alchemy, Protosynthesis, Quark Drive, Receiver, RKS System, Schooling, Shields Down, Stance Change, Tera Shell, Tera Shift, Teraform Zero, Trace, Wonder Guard, Zen Mode, or Zero to Hero.",
        "shortDescription": "User and ally's Abilities become target's Ability."
    },
    "doubleedge": {
        "id": "doubleedge",
        "name": "Double-Edge",
        "type": "normal",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 33% the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 33% recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            33,
            100
        ]
    },
    "doublehit": {
        "id": "doublehit",
        "name": "Double Hit",
        "type": "normal",
        "category": "physical",
        "power": 35,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "doubleironbash": {
        "id": "doubleironbash",
        "name": "Double Iron Bash",
        "type": "steel",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit. Has a 30% chance to make the target flinch.",
        "shortDescription": "Hits twice. 30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ],
        "multihit": 2
    },
    "doublekick": {
        "id": "doublekick",
        "name": "Double Kick",
        "type": "fighting",
        "category": "physical",
        "power": 30,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "doubleslap": {
        "id": "doubleslap",
        "name": "Double Slap",
        "type": "normal",
        "category": "physical",
        "power": 15,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "doubleteam": {
        "id": "doubleteam",
        "name": "Double Team",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's evasiveness by 1 stage.",
        "shortDescription": "Raises the user's evasiveness by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "evasion": 1
        }
    },
    "dragonascent": {
        "id": "dragonascent",
        "name": "Dragon Ascent",
        "type": "flying",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "any",
        "description": "Lowers the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense and Sp. Def by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance"
        ],
        "selfBoosts": {
            "def": -1,
            "spd": -1
        }
    },
    "dragonbreath": {
        "id": "dragonbreath",
        "name": "Dragon Breath",
        "type": "dragon",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target.",
        "shortDescription": "30% chance to paralyze the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "dragonclaw": {
        "id": "dragonclaw",
        "name": "Dragon Claw",
        "type": "dragon",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "dragondance": {
        "id": "dragondance",
        "name": "Dragon Dance",
        "type": "dragon",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and Speed by 1 stage.",
        "shortDescription": "Raises the user's Attack and Speed by 1.",
        "flags": [
            "snatch",
            "dance",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "spe": 1
        }
    },
    "dragondarts": {
        "id": "dragondarts",
        "name": "Dragon Darts",
        "type": "dragon",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit. In Double Battles, this move attempts to hit the targeted Pokemon and its ally once each. If hitting one of these Pokemon would be prevented by immunity, protection, semi-invulnerability, an Ability, or accuracy, it attempts to hit the other Pokemon twice instead. If this move is redirected, it hits that target twice.",
        "shortDescription": "Hits twice. Doubles: Tries to hit each foe once.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "noparentalbond"
        ],
        "multihit": 2
    },
    "dragonenergy": {
        "id": "dragonenergy",
        "name": "Dragon Energy",
        "type": "dragon",
        "category": "special",
        "power": 150,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Power is equal to (user's current HP * 150 / user's maximum HP), rounded down, but not less than 1.",
        "shortDescription": "Less power as user's HP decreases. Hits foe(s).",
        "flags": [
            "protect",
            "mirror"
        ]
    },
    "dragonpulse": {
        "id": "dragonpulse",
        "name": "Dragon Pulse",
        "type": "dragon",
        "category": "special",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "any",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "pulse"
        ]
    },
    "dragonrage": {
        "id": "dragonrage",
        "name": "Dragon Rage",
        "type": "dragon",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals 40 HP of damage to the target.",
        "shortDescription": "Deals 40 HP of damage to the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "fixedDamage": 40
    },
    "dragonrush": {
        "id": "dragonrush",
        "name": "Dragon Rush",
        "type": "dragon",
        "category": "physical",
        "power": 100,
        "accuracy": 75,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to make the target flinch. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "20% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "flinch"
            }
        ]
    },
    "dragontail": {
        "id": "dragontail",
        "name": "Dragon Tail",
        "type": "dragon",
        "category": "physical",
        "power": 60,
        "accuracy": 90,
        "pp": 10,
        "priority": -6,
        "target": "normal",
        "description": "If both the user and the target have not fainted, the target is forced to switch out and be replaced with a random unfainted ally. This effect fails if the target used Ingrain previously, has the Suction Cups Ability, or this move hit a substitute.",
        "shortDescription": "Forces the target to switch to a random ally.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "noassist",
            "failcopycat"
        ],
        "forceSwitch": true
    },
    "drainingkiss": {
        "id": "drainingkiss",
        "name": "Draining Kiss",
        "type": "fairy",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 3/4 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 75% of the damage dealt.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            3,
            4
        ]
    },
    "drainpunch": {
        "id": "drainpunch",
        "name": "Drain Punch",
        "type": "fighting",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "dreameater": {
        "id": "dreameater",
        "name": "Dream Eater",
        "type": "psychic",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The target is unaffected by this move unless it is asleep. The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User gains 1/2 HP inflicted. Sleeping target only.",
        "flags": [
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "drillpeck": {
        "id": "drillpeck",
        "name": "Drill Peck",
        "type": "flying",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ]
    },
    "drillrun": {
        "id": "drillrun",
        "name": "Drill Run",
        "type": "ground",
        "category": "physical",
        "power": 80,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "drumbeating": {
        "id": "drumbeating",
        "name": "Drum Beating",
        "type": "grass",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the target's Speed by 1.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "dualchop": {
        "id": "dualchop",
        "name": "Dual Chop",
        "type": "dragon",
        "category": "physical",
        "power": 40,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "dualwingbeat": {
        "id": "dualwingbeat",
        "name": "Dual Wingbeat",
        "type": "flying",
        "category": "physical",
        "power": 40,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "dynamaxcannon": {
        "id": "dynamaxcannon",
        "name": "Dynamax Cannon",
        "type": "dragon",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "failencore",
            "nosleeptalk",
            "failcopycat",
            "failmimic",
            "failinstruct",
            "noparentalbond"
        ]
    },
    "dynamicpunch": {
        "id": "dynamicpunch",
        "name": "Dynamic Punch",
        "type": "fighting",
        "category": "physical",
        "power": 100,
        "accuracy": 50,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to confuse the target.",
        "shortDescription": "100% chance to confuse the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "confusion"
            }
        ]
    },
    "earthpower": {
        "id": "earthpower",
        "name": "Earth Power",
        "type": "ground",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "earthquake": {
        "id": "earthquake",
        "name": "Earthquake",
        "type": "ground",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Damage doubles if the target is using Dig.",
        "shortDescription": "Hits adjacent Pokemon. Double damage on Dig.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "echoedvoice": {
        "id": "echoedvoice",
        "name": "Echoed Voice",
        "type": "normal",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "For every consecutive turn that this move is used by at least one Pokemon, this move's power is multiplied by the number of turns to pass, but not more than 5.",
        "shortDescription": "Power increases when used on consecutive turns.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "eerieimpulse": {
        "id": "eerieimpulse",
        "name": "Eerie Impulse",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Special Attack by 2 stages.",
        "shortDescription": "Lowers the target's Sp. Atk by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "spa": -2
        }
    },
    "eggbomb": {
        "id": "eggbomb",
        "name": "Egg Bomb",
        "type": "normal",
        "category": "physical",
        "power": 100,
        "accuracy": 75,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "electricterrain": {
        "id": "electricterrain",
        "name": "Electric Terrain",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the terrain becomes Electric Terrain. During the effect, the power of Electric-type attacks made by grounded Pokemon is multiplied by 1.3 and grounded Pokemon cannot fall asleep; Pokemon already asleep do not wake up. Grounded Pokemon cannot become affected by Yawn or fall asleep from its effect. Camouflage transforms the user into an Electric type, Nature Power becomes Thunderbolt, and Secret Power has a 30% chance to cause paralysis. Fails if the current terrain is Electric Terrain.",
        "shortDescription": "5 turns. Grounded: +Electric power, can't sleep.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "terrain": "electricterrain"
    },
    "electrify": {
        "id": "electrify",
        "name": "Electrify",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's move to become Electric type this turn. Among effects that can change a move's type, this effect happens last. Fails if the target already moved this turn.",
        "shortDescription": "Changes the target's move to Electric this turn.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "volatileStatus": "electrify"
    },
    "electroball": {
        "id": "electroball",
        "name": "Electro Ball",
        "type": "electric",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move depends on (user's current Speed / target's current Speed), rounded down. Power is equal to 150 if the result is 4 or more, 120 if 3, 80 if 2, 60 if 1, 40 if less than 1. If the target's current Speed is 0, this move's power is 40.",
        "shortDescription": "More power the faster the user is than the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "electroshot": {
        "id": "electroshot",
        "name": "Electro Shot",
        "type": "electric",
        "category": "special",
        "power": 130,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. Raises the user's Special Attack by 1 stage on the first turn. If the user is holding a Power Herb or the weather is Primordial Sea or Rain Dance, the move completes in one turn. If the user is holding Utility Umbrella and the weather is Primordial Sea or Rain Dance, the move still requires a turn to charge.",
        "shortDescription": "Raises Sp. Atk by 1, hits turn 2. Rain: no charge.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "electroweb": {
        "id": "electroweb",
        "name": "Electroweb",
        "type": "electric",
        "category": "special",
        "power": 55,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "embargo": {
        "id": "embargo",
        "name": "Embargo",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "For 5 turns, the target's held item has no effect. An item's effect of causing forme changes is unaffected, but any other effects from such items are negated. During the effect, Fling and Natural Gift are prevented from being used by the target. Items thrown at the target with Fling will still activate for it. If the target uses Baton Pass, the replacement will remain unable to use items.",
        "shortDescription": "For 5 turns, the target's item has no effect.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "embargo"
    },
    "ember": {
        "id": "ember",
        "name": "Ember",
        "type": "fire",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "encore": {
        "id": "encore",
        "name": "Encore",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "For its next 3 turns, the target is forced to repeat its last move used. If the affected move runs out of PP, the effect ends. Fails if the target is already under this effect, if it has not made a move, if the move has 0 PP, or if the move is Assist, Blazing Torque, Combat Torque, Copycat, Dynamax Cannon, Encore, Magical Torque, Me First, Metronome, Mimic, Mirror Move, Nature Power, Noxious Torque, Sketch, Sleep Talk, Struggle, Transform, or Wicked Torque.",
        "shortDescription": "Target repeats its last move for its next 3 turns.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome",
            "failencore"
        ],
        "volatileStatus": "encore"
    },
    "endeavor": {
        "id": "endeavor",
        "name": "Endeavor",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to (target's current HP - user's current HP). The target is unaffected if its current HP is less than or equal to the user's current HP.",
        "shortDescription": "Lowers the target's HP to the user's HP.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "noparentalbond"
        ]
    },
    "endure": {
        "id": "endure",
        "name": "Endure",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user will survive attacks made by other Pokemon during this turn with at least 1 HP. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "User survives attacks this turn with at least 1 HP.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "endure"
    },
    "energyball": {
        "id": "energyball",
        "name": "Energy Ball",
        "type": "grass",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "entrainment": {
        "id": "entrainment",
        "name": "Entrainment",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's Ability to become the same as the user's. Fails if the target's Ability is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Multitype, Power Construct, RKS System, Schooling, Shields Down, Stance Change, Tera Shift, Truant, Zen Mode, or Zero to Hero, or the same Ability as the user, or if the user's Ability is As One, Battle Bond, Comatose, Commander, Disguise, Embody Aspect, Flower Gift, Forecast, Hunger Switch, Ice Face, Illusion, Imposter, Multitype, Neutralizing Gas, Poison Puppeteer, Power Construct, Power of Alchemy, Protosynthesis, Quark Drive, Receiver, RKS System, Schooling, Shields Down, Stance Change, Tera Shell, Tera Shift, Teraform Zero, Trace, Wonder Guard, Zen Mode, or Zero to Hero.",
        "shortDescription": "The target's Ability changes to match the user's.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "eruption": {
        "id": "eruption",
        "name": "Eruption",
        "type": "fire",
        "category": "special",
        "power": 150,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Power is equal to (user's current HP * 150 / user's maximum HP), rounded down, but not less than 1.",
        "shortDescription": "Less power as user's HP decreases. Hits foe(s).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "esperwing": {
        "id": "esperwing",
        "name": "Esper Wing",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Speed by 1 stage and a higher chance for a critical hit.",
        "shortDescription": "100% chance to raise user Speed by 1. High crit.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spe": 1
                }
            }
        ],
        "critRatio": 2
    },
    "eternabeam": {
        "id": "eternabeam",
        "name": "Eternabeam",
        "type": "dragon",
        "category": "special",
        "power": 160,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "recharge",
            "protect",
            "mirror"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "expandingforce": {
        "id": "expandingforce",
        "name": "Expanding Force",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If the current terrain is Psychic Terrain and the user is grounded, this move hits all opposing Pokemon and has its power multiplied by 1.5.",
        "shortDescription": "User on Psychic Terrain: 1.5x power, hits foes.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "explosion": {
        "id": "explosion",
        "name": "Explosion",
        "type": "normal",
        "category": "physical",
        "power": 250,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacent",
        "description": "The user faints after using this move, even if this move fails for having no target. This move is prevented from executing if any active Pokemon has the Damp Ability.",
        "shortDescription": "Hits adjacent Pokemon. The user faints.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "noparentalbond"
        ],
        "selfdestruct": true
    },
    "extrasensory": {
        "id": "extrasensory",
        "name": "Extrasensory",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to make the target flinch.",
        "shortDescription": "10% chance to make the target flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "extremespeed": {
        "id": "extremespeed",
        "name": "Extreme Speed",
        "type": "normal",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 5,
        "priority": 2,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Nearly always goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "facade": {
        "id": "facade",
        "name": "Facade",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user is burned, paralyzed, or poisoned. The physical damage halving effect from the user's burn is ignored.",
        "shortDescription": "Power doubles if user is burn/poison/paralyzed.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "fairylock": {
        "id": "fairylock",
        "name": "Fairy Lock",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "Prevents all active Pokemon from switching next turn. A Pokemon can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. Fails if the effect is already active.",
        "shortDescription": "Prevents all Pokemon from switching next turn.",
        "flags": [
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "pseudoWeather": "fairylock"
    },
    "fairywind": {
        "id": "fairywind",
        "name": "Fairy Wind",
        "type": "fairy",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ]
    },
    "fakeout": {
        "id": "fakeout",
        "name": "Fake Out",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 10,
        "priority": 3,
        "target": "normal",
        "description": "Has a 100% chance to make the target flinch. Fails unless it is the user's first turn on the field.",
        "shortDescription": "Hits first. First turn out only. 100% flinch chance.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "flinch"
            }
        ]
    },
    "faketears": {
        "id": "faketears",
        "name": "Fake Tears",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Special Defense by 2 stages.",
        "shortDescription": "Lowers the target's Sp. Def by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "spd": -2
        }
    },
    "falsesurrender": {
        "id": "falsesurrender",
        "name": "False Surrender",
        "type": "dark",
        "category": "physical",
        "power": 80,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ]
    },
    "falseswipe": {
        "id": "falseswipe",
        "name": "False Swipe",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "Leaves the target with at least 1 HP.",
        "shortDescription": "Always leaves the target with at least 1 HP.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "featherdance": {
        "id": "featherdance",
        "name": "Feather Dance",
        "type": "flying",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack by 2 stages.",
        "shortDescription": "Lowers the target's Attack by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "dance",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "atk": -2
        }
    },
    "feint": {
        "id": "feint",
        "name": "Feint",
        "type": "normal",
        "category": "physical",
        "power": 30,
        "accuracy": 100,
        "pp": 10,
        "priority": 2,
        "target": "normal",
        "description": "If this move is successful, it breaks through the target's Baneful Bunker, Detect, King's Shield, Protect, or Spiky Shield for this turn, allowing other Pokemon to attack the target normally. If the target's side is protected by Crafty Shield, Mat Block, Quick Guard, or Wide Guard, that protection is also broken for this turn and other Pokemon may attack the target's side normally.",
        "shortDescription": "Nullifies Detect, Protect, and Quick/Wide Guard.",
        "flags": [
            "mirror",
            "noassist",
            "failcopycat"
        ],
        "breaksProtect": true
    },
    "feintattack": {
        "id": "feintattack",
        "name": "Feint Attack",
        "type": "dark",
        "category": "physical",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "fellstinger": {
        "id": "fellstinger",
        "name": "Fell Stinger",
        "type": "bug",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Raises the user's Attack by 3 stages if this move knocks out the target.",
        "shortDescription": "Raises user's Attack by 3 if this KOes the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "ficklebeam": {
        "id": "ficklebeam",
        "name": "Fickle Beam",
        "type": "dragon",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance this move's power is doubled.",
        "shortDescription": "Has a 30% chance this move's power is doubled.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "fierydance": {
        "id": "fierydance",
        "name": "Fiery Dance",
        "type": "fire",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to raise the user's Special Attack by 1 stage.",
        "shortDescription": "50% chance to raise the user's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "dance",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "selfBoosts": {
                    "spa": 1
                }
            }
        ]
    },
    "filletaway": {
        "id": "filletaway",
        "name": "Fillet Away",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack, Special Attack, and Speed by 2 stages in exchange for the user losing 1/2 of its maximum HP, rounded down. Fails if the user would faint or if its Attack, Special Attack, and Speed stat stages would not change.",
        "shortDescription": "+2 Attack, Sp. Atk, Speed for 1/2 user's max HP.",
        "flags": [
            "snatch"
        ],
        "boosts": {
            "atk": 2,
            "spa": 2,
            "spe": 2
        }
    },
    "finalgambit": {
        "id": "finalgambit",
        "name": "Final Gambit",
        "type": "fighting",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the user's current HP. If this move is successful, the user faints.",
        "shortDescription": "Does damage equal to the user's HP. User faints.",
        "flags": [
            "protect",
            "metronome",
            "noparentalbond"
        ],
        "selfdestruct": true
    },
    "fireblast": {
        "id": "fireblast",
        "name": "Fire Blast",
        "type": "fire",
        "category": "special",
        "power": 110,
        "accuracy": 85,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "firefang": {
        "id": "firefang",
        "name": "Fire Fang",
        "type": "fire",
        "category": "physical",
        "power": 65,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target and a 10% chance to make it flinch.",
        "shortDescription": "10% chance to burn. 10% chance to flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            },
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "firelash": {
        "id": "firelash",
        "name": "Fire Lash",
        "type": "fire",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "100% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "firepunch": {
        "id": "firepunch",
        "name": "Fire Punch",
        "type": "fire",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "firespin": {
        "id": "firespin",
        "name": "Fire Spin",
        "type": "fire",
        "category": "special",
        "power": 35,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "firstimpression": {
        "id": "firstimpression",
        "name": "First Impression",
        "type": "bug",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 2,
        "target": "normal",
        "description": "Fails unless it is the user's first turn on the field.",
        "shortDescription": "Hits first. First turn out only.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "fishiousrend": {
        "id": "fishiousrend",
        "name": "Fishious Rend",
        "type": "water",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user moves before the target.",
        "shortDescription": "Power doubles if user moves before the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ]
    },
    "fissure": {
        "id": "fissure",
        "name": "Fissure",
        "type": "ground",
        "category": "physical",
        "power": 0,
        "accuracy": 30,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the target's maximum HP. Ignores accuracy and evasiveness modifiers. This attack's accuracy is equal to (user's level - target's level + 30)%, and fails if the target is at a higher level. Pokemon with the Sturdy Ability are immune.",
        "shortDescription": "OHKOs the target. Fails if user is a lower level.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "ohko": true
    },
    "flail": {
        "id": "flail",
        "name": "Flail",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move is 20 if X is 33 to 48, 40 if X is 17 to 32, 80 if X is 10 to 16, 100 if X is 5 to 9, 150 if X is 2 to 4, and 200 if X is 0 or 1, where X is equal to (user's current HP * 48 / user's maximum HP), rounded down.",
        "shortDescription": "More power the less HP the user has left.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "flameburst": {
        "id": "flameburst",
        "name": "Flame Burst",
        "type": "fire",
        "category": "special",
        "power": 70,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the target's ally loses 1/16 of its maximum HP, rounded down, unless it has the Magic Guard Ability.",
        "shortDescription": "Damages Pokemon next to the target as well.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "flamecharge": {
        "id": "flamecharge",
        "name": "Flame Charge",
        "type": "fire",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Speed by 1 stage.",
        "shortDescription": "100% chance to raise the user's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spe": 1
                }
            }
        ]
    },
    "flamethrower": {
        "id": "flamethrower",
        "name": "Flamethrower",
        "type": "fire",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "flamewheel": {
        "id": "flamewheel",
        "name": "Flame Wheel",
        "type": "fire",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target. Thaws user.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "flareblitz": {
        "id": "flareblitz",
        "name": "Flare Blitz",
        "type": "fire",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target. If the target lost HP, the user takes recoil damage equal to 33% the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 33% recoil. 10% chance to burn. Thaws user.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ],
        "recoil": [
            33,
            100
        ]
    },
    "flash": {
        "id": "flash",
        "name": "Flash",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's accuracy by 1 stage.",
        "shortDescription": "Lowers the target's accuracy by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "accuracy": -1
        }
    },
    "flashcannon": {
        "id": "flashcannon",
        "name": "Flash Cannon",
        "type": "steel",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "flatter": {
        "id": "flatter",
        "name": "Flatter",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Raises the target's Special Attack by 1 stage and confuses it.",
        "shortDescription": "Raises the target's Sp. Atk by 1 and confuses it.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "spa": 1
        },
        "volatileStatus": "confusion"
    },
    "fling": {
        "id": "fling",
        "name": "Fling",
        "type": "dark",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move is based on the user's held item. The held item is lost and it activates for the target if applicable. If there is no target or the target avoids this move by protecting itself, the user's held item is still lost. The user can regain a thrown item with Recycle or the Harvest Ability. Fails if the user has no held item, if the held item cannot be thrown, if the user is under the effect of Embargo or Magic Room, or if the user has the Klutz Ability.",
        "shortDescription": "Flings the user's item at the target. Power varies.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "metronome",
            "noparentalbond"
        ]
    },
    "flipturn": {
        "id": "flipturn",
        "name": "Flip Turn",
        "type": "water",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful and the user has not fainted, the user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if there are no unfainted party members, or if the target switched out using an Eject Button or through the effect of the Emergency Exit or Wimp Out Abilities.",
        "shortDescription": "User switches out after damaging the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfSwitch": true
    },
    "floralhealing": {
        "id": "floralhealing",
        "name": "Floral Healing",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The target restores 1/2 of its maximum HP, rounded half up. If the terrain is Grassy Terrain, the target instead restores 2/3 of its maximum HP, rounded half down.",
        "shortDescription": "Heals the target by 50% of its max HP.",
        "flags": [
            "protect",
            "reflectable",
            "heal",
            "allyanim",
            "metronome"
        ]
    },
    "flowershield": {
        "id": "flowershield",
        "name": "Flower Shield",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "Raises the Defense of all active Grass-type Pokemon by 1 stage. Fails if there are no active Grass-type Pokemon.",
        "shortDescription": "Raises Defense by 1 of all active Grass types.",
        "flags": [
            "distance",
            "metronome"
        ]
    },
    "flowertrick": {
        "id": "flowertrick",
        "name": "Flower Trick",
        "type": "grass",
        "category": "physical",
        "power": 70,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move is always a critical hit unless the target is under the effect of Lucky Chant or has the Battle Armor or Shell Armor Abilities. This move does not check accuracy.",
        "shortDescription": "Always results in a critical hit; no accuracy check.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "willCrit": true
    },
    "fly": {
        "id": "fly",
        "name": "Fly",
        "type": "flying",
        "category": "physical",
        "power": 90,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "any",
        "description": "This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks other than Gust, Hurricane, Sky Uppercut, Smack Down, Thousand Arrows, Thunder, and Twister, and Gust and Twister have doubled power when used against it. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Flies up on first turn, then strikes the next turn.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "gravity",
            "distance",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ]
    },
    "flyingpress": {
        "id": "flyingpress",
        "name": "Flying Press",
        "type": "fighting",
        "category": "physical",
        "power": 100,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "any",
        "description": "This move combines Flying in its type effectiveness against the target. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "Combines Flying in its type effectiveness.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "gravity",
            "distance",
            "nonsky",
            "metronome"
        ]
    },
    "focusblast": {
        "id": "focusblast",
        "name": "Focus Blast",
        "type": "fighting",
        "category": "special",
        "power": 120,
        "accuracy": 70,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "focusenergy": {
        "id": "focusenergy",
        "name": "Focus Energy",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's chance for a critical hit by 2 stages. Fails if the user already has the effect. Baton Pass can be used to transfer this effect to an ally.",
        "shortDescription": "Raises the user's critical hit ratio by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "volatileStatus": "focusenergy"
    },
    "focuspunch": {
        "id": "focuspunch",
        "name": "Focus Punch",
        "type": "fighting",
        "category": "physical",
        "power": 150,
        "accuracy": 100,
        "pp": 20,
        "priority": -3,
        "target": "normal",
        "description": "The user loses its focus and does nothing if it is hit by a damaging attack this turn before it can execute the move.",
        "shortDescription": "Fails if the user takes damage before it hits.",
        "flags": [
            "contact",
            "protect",
            "punch",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failinstruct"
        ]
    },
    "followme": {
        "id": "followme",
        "name": "Follow Me",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 2,
        "target": "self",
        "description": "Until the end of the turn, all single-target attacks from the opposing side are redirected to the user. Such attacks are redirected to the user before they can be reflected by Magic Coat or the Magic Bounce Ability, or drawn in by the Lightning Rod or Storm Drain Abilities. Fails if it is not a Double Battle or Battle Royal. This effect is ignored while the user is under the effect of Sky Drop.",
        "shortDescription": "The foes' moves target the user on the turn used.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "followme"
    },
    "forcepalm": {
        "id": "forcepalm",
        "name": "Force Palm",
        "type": "fighting",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target.",
        "shortDescription": "30% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "foresight": {
        "id": "foresight",
        "name": "Foresight",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "As long as the target remains active, its evasiveness stat stage is ignored during accuracy checks against it if it is greater than 0, and Normal- and Fighting-type attacks can hit the target if it is a Ghost type. Fails if the target is already affected, or affected by Miracle Eye or Odor Sleuth.",
        "shortDescription": "Fighting, Normal hit Ghost. Evasiveness ignored.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "foresight"
    },
    "forestscurse": {
        "id": "forestscurse",
        "name": "Forest's Curse",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the Grass type to be added to the target, effectively making it have two or three types. Fails if the target is already a Grass type. If Trick-or-Treat adds a type to the target, it replaces the type added by this move and vice versa.",
        "shortDescription": "Adds Grass to the target's type(s).",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "foulplay": {
        "id": "foulplay",
        "name": "Foul Play",
        "type": "dark",
        "category": "physical",
        "power": 95,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Damage is calculated using the target's Attack stat, including stat stage changes. The user's Ability, item, and burn are used as normal.",
        "shortDescription": "Uses target's Attack stat in damage calculation.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "freezedry": {
        "id": "freezedry",
        "name": "Freeze-Dry",
        "type": "ice",
        "category": "special",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to freeze the target. This move's type effectiveness against Water is changed to be super effective no matter what this move's type is.",
        "shortDescription": "10% chance to freeze. Super effective on Water.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            }
        ]
    },
    "freezeshock": {
        "id": "freezeshock",
        "name": "Freeze Shock",
        "type": "ice",
        "category": "physical",
        "power": 140,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target. This attack charges on the first turn and executes on the second. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Charges turn 1. Hits turn 2. 30% paralyze.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "nosleeptalk",
            "failinstruct"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "frostbreath": {
        "id": "frostbreath",
        "name": "Frost Breath",
        "type": "ice",
        "category": "special",
        "power": 60,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move is always a critical hit unless the target is under the effect of Lucky Chant or has the Battle Armor or Shell Armor Abilities.",
        "shortDescription": "Always results in a critical hit.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "willCrit": true
    },
    "frustration": {
        "id": "frustration",
        "name": "Frustration",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to the greater of ((255 - user's Happiness) * 2/5), rounded down, or 1.",
        "shortDescription": "Max 102 power at minimum Happiness.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "furyattack": {
        "id": "furyattack",
        "name": "Fury Attack",
        "type": "normal",
        "category": "physical",
        "power": 15,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "furycutter": {
        "id": "furycutter",
        "name": "Fury Cutter",
        "type": "bug",
        "category": "physical",
        "power": 40,
        "accuracy": 95,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles with each successful hit, up to a maximum of 160 power. The power is reset if this move misses or another move is used.",
        "shortDescription": "Power doubles with each hit, up to 160.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "furyswipes": {
        "id": "furyswipes",
        "name": "Fury Swipes",
        "type": "normal",
        "category": "physical",
        "power": 18,
        "accuracy": 80,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "fusionbolt": {
        "id": "fusionbolt",
        "name": "Fusion Bolt",
        "type": "electric",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the last move used by any Pokemon this turn was Fusion Flare.",
        "shortDescription": "Power doubles if used after Fusion Flare this turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "fusionflare": {
        "id": "fusionflare",
        "name": "Fusion Flare",
        "type": "fire",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the last move used by any Pokemon this turn was Fusion Bolt.",
        "shortDescription": "Power doubles if used after Fusion Bolt this turn.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ]
    },
    "futuresight": {
        "id": "futuresight",
        "name": "Future Sight",
        "type": "psychic",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage two turns after this move is used. At the end of that turn, the damage is calculated at that time and dealt to the Pokemon at the position the target had when the move was used. If the user is no longer active at the time, damage is calculated based on the user's natural Special Attack stat, types, and level, with no boosts from its held item or Ability. Fails if this move or Doom Desire is already in effect for the target's position.",
        "shortDescription": "Hits two turns after being used.",
        "flags": [
            "allyanim",
            "metronome",
            "futuremove"
        ],
        "ignoreImmunity": true
    },
    "gastroacid": {
        "id": "gastroacid",
        "name": "Gastro Acid",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's Ability to be rendered ineffective as long as it remains active. If the target uses Baton Pass, the replacement will remain under this effect. If the target's Ability is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Multitype, Power Construct, RKS System, Schooling, Shields Down, Stance Change, Tera Shift, Zen Mode, or Zero to Hero, this move fails, and receiving the effect through Baton Pass ends the effect immediately.",
        "shortDescription": "Nullifies the target's Ability.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "volatileStatus": "gastroacid"
    },
    "geargrind": {
        "id": "geargrind",
        "name": "Gear Grind",
        "type": "steel",
        "category": "physical",
        "power": 50,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 2
    },
    "gearup": {
        "id": "gearup",
        "name": "Gear Up",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "allySide",
        "description": "Raises the Attack and Special Attack of Pokemon on the user's side with the Plus or Minus Abilities by 1 stage.",
        "shortDescription": "Raises Atk, Sp. Atk of allies with Plus/Minus by 1.",
        "flags": [
            "snatch",
            "bypasssub",
            "metronome"
        ]
    },
    "geomancy": {
        "id": "geomancy",
        "name": "Geomancy",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Attack, Special Defense, and Speed by 2 stages. This attack charges on the first turn and executes on the second. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Charges, then raises SpA, SpD, Spe by 2 turn 2.",
        "flags": [
            "charge",
            "nonsky",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ],
        "boosts": {
            "spa": 2,
            "spd": 2,
            "spe": 2
        }
    },
    "gigadrain": {
        "id": "gigadrain",
        "name": "Giga Drain",
        "type": "grass",
        "category": "special",
        "power": 75,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "gigaimpact": {
        "id": "gigaimpact",
        "name": "Giga Impact",
        "type": "normal",
        "category": "physical",
        "power": 150,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "contact",
            "recharge",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "gigatonhammer": {
        "id": "gigatonhammer",
        "name": "Gigaton Hammer",
        "type": "steel",
        "category": "physical",
        "power": 160,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Cannot be selected the turn after it's used.",
        "shortDescription": "Cannot be selected the turn after it's used.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "cantusetwice"
        ]
    },
    "glaciate": {
        "id": "glaciate",
        "name": "Glaciate",
        "type": "ice",
        "category": "special",
        "power": 65,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "glare": {
        "id": "glare",
        "name": "Glare",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Paralyzes the target.",
        "shortDescription": "Paralyzes the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "par"
    },
    "grassknot": {
        "id": "grassknot",
        "name": "Grass Knot",
        "type": "grass",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move's power is 20 if the target weighs less than 10 kg, 40 if less than 25 kg, 60 if less than 50 kg, 80 if less than 100 kg, 100 if less than 200 kg, and 120 if greater than or equal to 200 kg.",
        "shortDescription": "More power the heavier the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "grasswhistle": {
        "id": "grasswhistle",
        "name": "Grass Whistle",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 55,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "status": "slp"
    },
    "grassyterrain": {
        "id": "grassyterrain",
        "name": "Grassy Terrain",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the terrain becomes Grassy Terrain. During the effect, the power of Grass-type attacks used by grounded Pokemon is multiplied by 1.3, the power of Bulldoze, Earthquake, and Magnitude used against grounded Pokemon is multiplied by 0.5, and grounded Pokemon have 1/16 of their maximum HP, rounded down, restored at the end of each turn, including the last turn. Camouflage transforms the user into a Grass type, Nature Power becomes Energy Ball, and Secret Power has a 30% chance to cause sleep. Fails if the current terrain is Grassy Terrain.",
        "shortDescription": "5 turns. Grounded: +Grass power, +1/16 max HP.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "terrain": "grassyterrain"
    },
    "gravapple": {
        "id": "gravapple",
        "name": "Grav Apple",
        "type": "grass",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Defense by 1 stage. Power is multiplied by 1.5 during Gravity's effect.",
        "shortDescription": "Target: 100% -1 Def. During Gravity: 1.5x power.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "gravity": {
        "id": "gravity",
        "name": "Gravity",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the evasiveness of all active Pokemon is multiplied by 0.6. At the time of use, Bounce, Fly, Magnet Rise, Sky Drop, and Telekinesis end immediately for all active Pokemon. During the effect, Bounce, Fly, Flying Press, High Jump Kick, Jump Kick, Magnet Rise, Sky Drop, Splash, and Telekinesis are prevented from being used by all active Pokemon. Ground-type attacks, Spikes, Toxic Spikes, Sticky Web, and the Arena Trap Ability can affect Flying types or Pokemon with the Levitate Ability. Fails if this move is already in effect.",
        "shortDescription": "5 turns: no Ground immunities, 1.67x accuracy.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "pseudoWeather": "gravity"
    },
    "growl": {
        "id": "growl",
        "name": "Growl",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Attack by 1 stage.",
        "shortDescription": "Lowers the foe(s) Attack by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "boosts": {
            "atk": -1
        }
    },
    "growth": {
        "id": "growth",
        "name": "Growth",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and Special Attack by 1 stage. If the weather is Sunny Day or Desolate Land, this move raises the user's Attack and Special Attack by 2 stages. If the user is holding Utility Umbrella, this move will only raise the user's Attack and Special Attack by 1 stage, even if the weather is Sunny Day or Desolate Land.",
        "shortDescription": "Raises user's Attack and Sp. Atk by 1; 2 in Sun.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "spa": 1
        }
    },
    "grudge": {
        "id": "grudge",
        "name": "Grudge",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "Until the user's next turn, if an opposing Pokemon's attack knocks the user out, that move loses all its remaining PP.",
        "shortDescription": "If the user faints, the attack used loses all its PP.",
        "flags": [
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "grudge"
    },
    "guardsplit": {
        "id": "guardsplit",
        "name": "Guard Split",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user and the target have their Defense and Special Defense stats set to be equal to the average of the user and the target's Defense and Special Defense stats, respectively, rounded down. Stat stage changes are unaffected.",
        "shortDescription": "Averages Defense and Sp. Def stats with target.",
        "flags": [
            "protect",
            "allyanim",
            "metronome"
        ]
    },
    "guardswap": {
        "id": "guardswap",
        "name": "Guard Swap",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its Defense and Special Defense stat stage changes with the target.",
        "shortDescription": "Swaps Defense and Sp. Def changes with target.",
        "flags": [
            "protect",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "guillotine": {
        "id": "guillotine",
        "name": "Guillotine",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 30,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the target's maximum HP. Ignores accuracy and evasiveness modifiers. This attack's accuracy is equal to (user's level - target's level + 30)%, and fails if the target is at a higher level. Pokemon with the Sturdy Ability are immune.",
        "shortDescription": "OHKOs the target. Fails if user is a lower level.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "ohko": true
    },
    "gunkshot": {
        "id": "gunkshot",
        "name": "Gunk Shot",
        "type": "poison",
        "category": "physical",
        "power": 120,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to poison the target.",
        "shortDescription": "30% chance to poison the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "psn"
            }
        ]
    },
    "gust": {
        "id": "gust",
        "name": "Gust",
        "type": "flying",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "any",
        "description": "Power doubles if the target is using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop.",
        "shortDescription": "Power doubles during Bounce, Fly, and Sky Drop.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "wind"
        ]
    },
    "gyroball": {
        "id": "gyroball",
        "name": "Gyro Ball",
        "type": "steel",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to (25 * target's current Speed / user's current Speed) + 1, rounded down, but not more than 150. If the user's current Speed is 0, this move's power is 1.",
        "shortDescription": "More power the slower the user than the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "hail": {
        "id": "hail",
        "name": "Hail",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Hail. At the end of each turn except the last, all active Pokemon lose 1/16 of their maximum HP, rounded down, unless they are an Ice type or have the Ice Body, Magic Guard, Overcoat, or Snow Cloak Abilities. Lasts for 8 turns if the user is holding Icy Rock. Fails if the current weather is Hail.",
        "shortDescription": "For 5 turns, hail crashes down.",
        "flags": [
            "metronome"
        ],
        "weather": "hail"
    },
    "hammerarm": {
        "id": "hammerarm",
        "name": "Hammer Arm",
        "type": "fighting",
        "category": "physical",
        "power": 100,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Speed by 1 stage.",
        "shortDescription": "Lowers the user's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "selfBoosts": {
            "spe": -1
        }
    },
    "harden": {
        "id": "harden",
        "name": "Harden",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 1 stage.",
        "shortDescription": "Raises the user's Defense by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 1
        }
    },
    "haze": {
        "id": "haze",
        "name": "Haze",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "all",
        "description": "Resets the stat stages of all active Pokemon to 0.",
        "shortDescription": "Eliminates all stat changes.",
        "flags": [
            "bypasssub",
            "metronome"
        ]
    },
    "headbutt": {
        "id": "headbutt",
        "name": "Headbutt",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "headcharge": {
        "id": "headcharge",
        "name": "Head Charge",
        "type": "normal",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 1/4 the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 1/4 recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            1,
            4
        ]
    },
    "headlongrush": {
        "id": "headlongrush",
        "name": "Headlong Rush",
        "type": "ground",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Defense and Special Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense and Sp. Def by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "selfBoosts": {
            "def": -1,
            "spd": -1
        }
    },
    "headsmash": {
        "id": "headsmash",
        "name": "Head Smash",
        "type": "rock",
        "category": "physical",
        "power": 150,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 1/2 the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 1/2 recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            1,
            2
        ]
    },
    "healbell": {
        "id": "healbell",
        "name": "Heal Bell",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "allyTeam",
        "description": "Every Pokemon in the user's party is cured of its non-volatile status condition. Active Pokemon with the Soundproof Ability are not cured, unless they are the user.",
        "shortDescription": "Cures the user's party of all status conditions.",
        "flags": [
            "snatch",
            "sound",
            "distance",
            "bypasssub",
            "metronome"
        ]
    },
    "healblock": {
        "id": "healblock",
        "name": "Heal Block",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "For 5 turns, the target is prevented from restoring any HP as long as it remains active. During the effect, healing and draining moves are unusable, and Abilities and items that grant healing will not heal the user. If an affected Pokemon uses Baton Pass, the replacement will remain unable to restore its HP. Pain Split and the Regenerator Ability are unaffected.",
        "shortDescription": "For 5 turns, the foe(s) is prevented from healing.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "healblock"
    },
    "healingwish": {
        "id": "healingwish",
        "name": "Healing Wish",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user faints, and if the Pokemon brought out to replace it does not have full HP or has a non-volatile status condition, its HP is fully restored along with having any non-volatile status condition cured. The replacement is sent out at the end of the turn, and the healing happens before hazards take effect. This effect continues until a Pokemon that meets either of these conditions switches in at the user's position or gets swapped into the position with Ally Switch. Fails if the user is the last unfainted Pokemon in its party.",
        "shortDescription": "User faints. Next hurt Pokemon is fully healed.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "selfdestruct": true
    },
    "healorder": {
        "id": "healorder",
        "name": "Heal Order",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user by 50% of its max HP.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "heal": [
            1,
            2
        ]
    },
    "healpulse": {
        "id": "healpulse",
        "name": "Heal Pulse",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "any",
        "description": "The target restores 1/2 of its maximum HP, rounded half up. If the user has the Mega Launcher Ability, the target instead restores 3/4 of its maximum HP, rounded half down.",
        "shortDescription": "Heals the target by 50% of its max HP.",
        "flags": [
            "protect",
            "reflectable",
            "distance",
            "heal",
            "allyanim",
            "metronome",
            "pulse"
        ]
    },
    "heartstamp": {
        "id": "heartstamp",
        "name": "Heart Stamp",
        "type": "psychic",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "heatcrash": {
        "id": "heatcrash",
        "name": "Heat Crash",
        "type": "fire",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move depends on (user's weight / target's weight), rounded down. Power is equal to 120 if the result is 5 or more, 100 if 4, 80 if 3, 60 if 2, and 40 if 1 or less. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "More power the heavier the user than the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "heatwave": {
        "id": "heatwave",
        "name": "Heat Wave",
        "type": "fire",
        "category": "special",
        "power": 95,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the foe(s).",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "heavyslam": {
        "id": "heavyslam",
        "name": "Heavy Slam",
        "type": "steel",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move depends on (user's weight / target's weight), rounded down. Power is equal to 120 if the result is 5 or more, 100 if 4, 80 if 3, 60 if 2, and 40 if 1 or less. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "More power the heavier the user than the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "helpinghand": {
        "id": "helpinghand",
        "name": "Helping Hand",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 5,
        "target": "adjacentAlly",
        "description": "The power of the target's attack this turn is multiplied by 1.5 (this effect is stackable). Fails if there is no ally adjacent to the user or if the ally already moved this turn, but does not fail if the ally is using a two-turn move.",
        "shortDescription": "One adjacent ally's move power is 1.5x this turn.",
        "flags": [
            "bypasssub",
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "helpinghand"
    },
    "hex": {
        "id": "hex",
        "name": "Hex",
        "type": "ghost",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target has a non-volatile status condition.",
        "shortDescription": "Power doubles if the target has a status ailment.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "hiddenpower": {
        "id": "hiddenpower",
        "name": "Hidden Power",
        "type": "normal",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "This move's type depends on the user's individual values (IVs), and can be any type but Fairy and Normal.",
        "shortDescription": "Varies in type based on the user's IVs.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "highhorsepower": {
        "id": "highhorsepower",
        "name": "High Horsepower",
        "type": "ground",
        "category": "physical",
        "power": 95,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "highjumpkick": {
        "id": "highjumpkick",
        "name": "High Jump Kick",
        "type": "fighting",
        "category": "physical",
        "power": 130,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this attack is not successful, the user loses half of its maximum HP, rounded down, as crash damage. Pokemon with the Magic Guard Ability are unaffected by crash damage.",
        "shortDescription": "User is hurt by 50% of its max HP if it misses.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "gravity",
            "metronome"
        ]
    },
    "honeclaws": {
        "id": "honeclaws",
        "name": "Hone Claws",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and accuracy by 1 stage.",
        "shortDescription": "Raises the user's Attack and accuracy by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "accuracy": 1
        }
    },
    "hornattack": {
        "id": "hornattack",
        "name": "Horn Attack",
        "type": "normal",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "horndrill": {
        "id": "horndrill",
        "name": "Horn Drill",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 30,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the target's maximum HP. Ignores accuracy and evasiveness modifiers. This attack's accuracy is equal to (user's level - target's level + 30)%, and fails if the target is at a higher level. Pokemon with the Sturdy Ability are immune.",
        "shortDescription": "OHKOs the target. Fails if user is a lower level.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "ohko": true
    },
    "hornleech": {
        "id": "hornleech",
        "name": "Horn Leech",
        "type": "grass",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "howl": {
        "id": "howl",
        "name": "Howl",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "allies",
        "description": "Raises the Attack of the user and all allies 1 stage.",
        "shortDescription": "Raises the user's and ally's Attack by 1.",
        "flags": [
            "snatch",
            "sound",
            "metronome"
        ],
        "boosts": {
            "atk": 1
        }
    },
    "hurricane": {
        "id": "hurricane",
        "name": "Hurricane",
        "type": "flying",
        "category": "special",
        "power": 110,
        "accuracy": 70,
        "pp": 10,
        "priority": 0,
        "target": "any",
        "description": "Has a 30% chance to confuse the target. This move can hit a target using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop. If the weather is Primordial Sea or Rain Dance, this move does not check accuracy. If the weather is Desolate Land or Sunny Day, this move's accuracy is 50%. If this move is used against a Pokemon holding Utility Umbrella, this move's accuracy remains at 70%.",
        "shortDescription": "30% chance to confuse target. Can't miss in rain.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "confusion"
            }
        ]
    },
    "hydropump": {
        "id": "hydropump",
        "name": "Hydro Pump",
        "type": "water",
        "category": "special",
        "power": 110,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "hydrosteam": {
        "id": "hydrosteam",
        "name": "Hydro Steam",
        "type": "water",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the current weather is Sunny Day and the user is not holding Utility Umbrella, this move's damage is multiplied by 1.5 instead of halved for being Water type.",
        "shortDescription": "During Sunny Day: 1.5x damage instead of half.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ]
    },
    "hyperbeam": {
        "id": "hyperbeam",
        "name": "Hyper Beam",
        "type": "normal",
        "category": "special",
        "power": 150,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "recharge",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "hyperdrill": {
        "id": "hyperdrill",
        "name": "Hyper Drill",
        "type": "normal",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Bypasses protection without breaking it.",
        "shortDescription": "Bypasses protection without breaking it.",
        "flags": [
            "contact",
            "mirror"
        ]
    },
    "hyperfang": {
        "id": "hyperfang",
        "name": "Hyper Fang",
        "type": "normal",
        "category": "physical",
        "power": 80,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to make the target flinch.",
        "shortDescription": "10% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "hyperspacehole": {
        "id": "hyperspacehole",
        "name": "Hyperspace Hole",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it breaks through the target's Baneful Bunker, Detect, King's Shield, Protect, or Spiky Shield for this turn, allowing other Pokemon to attack the target normally. If the target's side is protected by Crafty Shield, Mat Block, Quick Guard, or Wide Guard, that protection is also broken for this turn and other Pokemon may attack the target's side normally.",
        "shortDescription": "Breaks the target's protection for this turn.",
        "flags": [
            "mirror",
            "bypasssub"
        ],
        "breaksProtect": true
    },
    "hypervoice": {
        "id": "hypervoice",
        "name": "Hyper Voice",
        "type": "normal",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "hypnosis": {
        "id": "hypnosis",
        "name": "Hypnosis",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 60,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "slp"
    },
    "iceball": {
        "id": "iceball",
        "name": "Ice Ball",
        "type": "ice",
        "category": "physical",
        "power": 30,
        "accuracy": 90,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user is locked into this move and cannot make another move until it misses, 5 turns have passed, or the attack cannot be used. Power doubles with each successful hit of this move and doubles again if Defense Curl was used previously by the user. If this move is called by Sleep Talk, the move is used for one turn.",
        "shortDescription": "Power doubles with each hit. Repeats for 5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "failinstruct",
            "bullet",
            "noparentalbond"
        ]
    },
    "icebeam": {
        "id": "icebeam",
        "name": "Ice Beam",
        "type": "ice",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to freeze the target.",
        "shortDescription": "10% chance to freeze the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            }
        ]
    },
    "iceburn": {
        "id": "iceburn",
        "name": "Ice Burn",
        "type": "ice",
        "category": "special",
        "power": 140,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to burn the target. This attack charges on the first turn and executes on the second. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Charges turn 1. Hits turn 2. 30% burn.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "nosleeptalk",
            "failinstruct"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "brn"
            }
        ]
    },
    "icefang": {
        "id": "icefang",
        "name": "Ice Fang",
        "type": "ice",
        "category": "physical",
        "power": 65,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to freeze the target and a 10% chance to make it flinch.",
        "shortDescription": "10% chance to freeze. 10% chance to flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            },
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "icehammer": {
        "id": "icehammer",
        "name": "Ice Hammer",
        "type": "ice",
        "category": "physical",
        "power": 100,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Speed by 1 stage.",
        "shortDescription": "Lowers the user's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "selfBoosts": {
            "spe": -1
        }
    },
    "icepunch": {
        "id": "icepunch",
        "name": "Ice Punch",
        "type": "ice",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to freeze the target.",
        "shortDescription": "10% chance to freeze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            }
        ]
    },
    "iceshard": {
        "id": "iceshard",
        "name": "Ice Shard",
        "type": "ice",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "icespinner": {
        "id": "icespinner",
        "name": "Ice Spinner",
        "type": "ice",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Ends the effects of Electric Terrain, Grassy Terrain, Misty Terrain, and Psychic Terrain.",
        "shortDescription": "Ends the effects of terrain.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "iciclecrash": {
        "id": "iciclecrash",
        "name": "Icicle Crash",
        "type": "ice",
        "category": "physical",
        "power": 85,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "iciclespear": {
        "id": "iciclespear",
        "name": "Icicle Spear",
        "type": "ice",
        "category": "physical",
        "power": 25,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "icywind": {
        "id": "icywind",
        "name": "Icy Wind",
        "type": "ice",
        "category": "special",
        "power": 55,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "imprison": {
        "id": "imprison",
        "name": "Imprison",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user prevents all opposing Pokemon from using any moves that the user also knows as long as the user remains active.",
        "shortDescription": "No foe can use any move known by the user.",
        "flags": [
            "snatch",
            "bypasssub",
            "metronome",
            "mustpressure"
        ],
        "volatileStatus": "imprison"
    },
    "incinerate": {
        "id": "incinerate",
        "name": "Incinerate",
        "type": "fire",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "The target loses its held item if it is a Berry or a Gem. This move cannot cause Pokemon with the Sticky Hold Ability to lose their held item. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "Destroys the foe(s) Berry/Gem.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "infernalparade": {
        "id": "infernalparade",
        "name": "Infernal Parade",
        "type": "ghost",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to burn the target. Power doubles if the target has a non-volatile status condition.",
        "shortDescription": "30% burn. 2x power if target is already statused.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "brn"
            }
        ],
        "doublePowerIfTargetStatus": true
    },
    "inferno": {
        "id": "inferno",
        "name": "Inferno",
        "type": "fire",
        "category": "special",
        "power": 100,
        "accuracy": 50,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to burn the target.",
        "shortDescription": "100% chance to burn the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "status": "brn"
            }
        ]
    },
    "infestation": {
        "id": "infestation",
        "name": "Infestation",
        "type": "bug",
        "category": "special",
        "power": 20,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "ingrain": {
        "id": "ingrain",
        "name": "Ingrain",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "The user has 1/16 of its maximum HP restored at the end of each turn, but it is prevented from switching out and other Pokemon cannot force the user to switch out. The user can still switch out if it uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the user leaves the field using Baton Pass, the replacement will remain trapped and still receive the healing effect. During the effect, the user can be hit normally by Ground-type attacks and be affected by Spikes, Toxic Spikes, and Sticky Web, even if the user is a Flying type or has the Levitate Ability.",
        "shortDescription": "Traps/grounds user; heals 1/16 max HP per turn.",
        "flags": [
            "snatch",
            "nonsky",
            "metronome"
        ],
        "volatileStatus": "ingrain"
    },
    "iondeluge": {
        "id": "iondeluge",
        "name": "Ion Deluge",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 25,
        "priority": 1,
        "target": "all",
        "description": "Causes Normal-type moves to become Electric type this turn. The effect happens after other effects that change a move's type.",
        "shortDescription": "Normal moves become Electric type this turn.",
        "flags": [
            "metronome"
        ],
        "pseudoWeather": "iondeluge"
    },
    "irondefense": {
        "id": "irondefense",
        "name": "Iron Defense",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 2 stages.",
        "shortDescription": "Raises the user's Defense by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 2
        }
    },
    "ironhead": {
        "id": "ironhead",
        "name": "Iron Head",
        "type": "steel",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "irontail": {
        "id": "irontail",
        "name": "Iron Tail",
        "type": "steel",
        "category": "physical",
        "power": 100,
        "accuracy": 75,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "30% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "jawlock": {
        "id": "jawlock",
        "name": "Jaw Lock",
        "type": "dark",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the user and the target from switching out. The user and the target can still switch out if either of them is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field.",
        "shortDescription": "Prevents both user and target from switching out.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ]
    },
    "jetpunch": {
        "id": "jetpunch",
        "name": "Jet Punch",
        "type": "water",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch"
        ]
    },
    "judgment": {
        "id": "judgment",
        "name": "Judgment",
        "type": "normal",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move's type depends on the user's held Plate.",
        "shortDescription": "Type varies based on the held Plate.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "jumpkick": {
        "id": "jumpkick",
        "name": "Jump Kick",
        "type": "fighting",
        "category": "physical",
        "power": 100,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this attack is not successful, the user loses half of its maximum HP, rounded down, as crash damage. Pokemon with the Magic Guard Ability are unaffected by crash damage.",
        "shortDescription": "User is hurt by 50% of its max HP if it misses.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "gravity",
            "metronome"
        ]
    },
    "junglehealing": {
        "id": "junglehealing",
        "name": "Jungle Healing",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "allies",
        "description": "Each Pokemon on the user's side restores 1/4 of its maximum HP, rounded half up, and has its status condition cured.",
        "shortDescription": "User and allies: healed 1/4 max HP, status cured.",
        "flags": [
            "heal",
            "bypasssub",
            "allyanim"
        ]
    },
    "karatechop": {
        "id": "karatechop",
        "name": "Karate Chop",
        "type": "fighting",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "kinesis": {
        "id": "kinesis",
        "name": "Kinesis",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 80,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's accuracy by 1 stage.",
        "shortDescription": "Lowers the target's accuracy by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "accuracy": -1
        }
    },
    "kingsshield": {
        "id": "kingsshield",
        "name": "King's Shield",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn, and Pokemon trying to make contact with the user have their Attack lowered by 1 stage. Non-damaging moves go through this protection. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Protects from damaging attacks. Contact: -1 Atk.",
        "flags": [
            "noassist",
            "failcopycat",
            "failinstruct"
        ],
        "volatileStatus": "kingsshield"
    },
    "knockoff": {
        "id": "knockoff",
        "name": "Knock Off",
        "type": "dark",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If the target is holding an item that can be removed from it, ignoring the Sticky Hold Ability, this move's power is multiplied by 1.5. If the user has not fainted, the target loses its held item. This move cannot cause Pokemon with the Sticky Hold Ability to lose their held item or cause a Kyogre, a Groudon, a Giratina, an Arceus, a Genesect, a Silvally, a Zacian, or a Zamazenta to lose their Blue Orb, Red Orb, Griseous Orb, Plate, Drive, Memory, Rusted Sword, or Rusted Shield respectively. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "1.5x damage if foe holds an item. Removes item.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "kowtowcleave": {
        "id": "kowtowcleave",
        "name": "Kowtow Cleave",
        "type": "dark",
        "category": "physical",
        "power": 85,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "laserfocus": {
        "id": "laserfocus",
        "name": "Laser Focus",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Until the end of the next turn, the user's attacks will be critical hits.",
        "shortDescription": "Until the end of the next turn, user's moves crit.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "volatileStatus": "laserfocus"
    },
    "lastresort": {
        "id": "lastresort",
        "name": "Last Resort",
        "type": "normal",
        "category": "physical",
        "power": 140,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "This move fails unless the user knows this move and at least one other move, and has used all the other moves it knows at least once each since it became active or Transformed.",
        "shortDescription": "Fails unless each known move has been used.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "lavaplume": {
        "id": "lavaplume",
        "name": "Lava Plume",
        "type": "fire",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Has a 30% chance to burn the target.",
        "shortDescription": "30% chance to burn adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "brn"
            }
        ]
    },
    "leafage": {
        "id": "leafage",
        "name": "Leafage",
        "type": "grass",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "leafblade": {
        "id": "leafblade",
        "name": "Leaf Blade",
        "type": "grass",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "leafstorm": {
        "id": "leafstorm",
        "name": "Leaf Storm",
        "type": "grass",
        "category": "special",
        "power": 130,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Special Attack by 2 stages.",
        "shortDescription": "Lowers the user's Sp. Atk by 2.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "selfBoosts": {
            "spa": -2
        }
    },
    "leaftornado": {
        "id": "leaftornado",
        "name": "Leaf Tornado",
        "type": "grass",
        "category": "special",
        "power": 65,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "50% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "leechlife": {
        "id": "leechlife",
        "name": "Leech Life",
        "type": "bug",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "leechseed": {
        "id": "leechseed",
        "name": "Leech Seed",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The Pokemon at the user's position steals 1/8 of the target's maximum HP, rounded down, at the end of each turn. If Big Root is held by the recipient, the HP recovered is 1.3x normal, rounded half down. If the target uses Baton Pass, the replacement will continue being leeched. If the target switches out or uses Mortal Spin or Rapid Spin successfully, the effect ends. Grass-type Pokemon are immune to this move on use, but not its effect.",
        "shortDescription": "1/8 of target's HP is restored to user every turn.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "leechseed"
    },
    "leer": {
        "id": "leer",
        "name": "Leer",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Defense by 1 stage.",
        "shortDescription": "Lowers the foe(s) Defense by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "def": -1
        }
    },
    "lick": {
        "id": "lick",
        "name": "Lick",
        "type": "ghost",
        "category": "physical",
        "power": 30,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target.",
        "shortDescription": "30% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "lifedew": {
        "id": "lifedew",
        "name": "Life Dew",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "allies",
        "description": "Each Pokemon on the user's side restores 1/4 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user and its allies by 1/4 their max HP.",
        "flags": [
            "snatch",
            "heal",
            "bypasssub"
        ],
        "heal": [
            1,
            4
        ]
    },
    "lightscreen": {
        "id": "lightscreen",
        "name": "Light Screen",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members take 0.5x damage from special attacks, or 0.66x damage if in a Double Battle. Damage is not reduced further with Aurora Veil. Critical hits ignore this effect. It is removed from the user's side if the user or an ally is successfully hit by Brick Break, Psychic Fangs, or Defog. Lasts for 8 turns if the user is holding Light Clay. Fails if the effect is already active on the user's side.",
        "shortDescription": "For 5 turns, special damage to allies is halved.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "lightscreen"
    },
    "liquidation": {
        "id": "liquidation",
        "name": "Liquidation",
        "type": "water",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "20% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "lockon": {
        "id": "lockon",
        "name": "Lock-On",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Until the end of the next turn, the target cannot avoid the user's moves, even if the target is in the middle of a two-turn move. The effect ends if either the user or the target leaves the field. Fails if this effect is active for the user.",
        "shortDescription": "User's next move will not miss the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "lovelykiss": {
        "id": "lovelykiss",
        "name": "Lovely Kiss",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 75,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "slp"
    },
    "lowkick": {
        "id": "lowkick",
        "name": "Low Kick",
        "type": "fighting",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move's power is 20 if the target weighs less than 10 kg, 40 if less than 25 kg, 60 if less than 50 kg, 80 if less than 100 kg, 100 if less than 200 kg, and 120 if greater than or equal to 200 kg.",
        "shortDescription": "More power the heavier the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "lowsweep": {
        "id": "lowsweep",
        "name": "Low Sweep",
        "type": "fighting",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the target's Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "luckychant": {
        "id": "luckychant",
        "name": "Lucky Chant",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members cannot be struck by a critical hit. Fails if the effect is already active on the user's side.",
        "shortDescription": "For 5 turns, shields user's party from critical hits.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "luckychant"
    },
    "luminacrash": {
        "id": "luminacrash",
        "name": "Lumina Crash",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Defense by 2 stages.",
        "shortDescription": "100% chance to lower the target's Sp. Def by 2.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spd": -2
                }
            }
        ]
    },
    "lunge": {
        "id": "lunge",
        "name": "Lunge",
        "type": "bug",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "100% chance to lower the target's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "lusterpurge": {
        "id": "lusterpurge",
        "name": "Luster Purge",
        "type": "psychic",
        "category": "special",
        "power": 95,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "50% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "machpunch": {
        "id": "machpunch",
        "name": "Mach Punch",
        "type": "fighting",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ]
    },
    "magicalleaf": {
        "id": "magicalleaf",
        "name": "Magical Leaf",
        "type": "grass",
        "category": "special",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "magiccoat": {
        "id": "magiccoat",
        "name": "Magic Coat",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 4,
        "target": "self",
        "description": "Until the end of the turn, the user is unaffected by certain non-damaging moves directed at it and will instead use such moves against the original user. Moves reflected in this way are unable to be reflected again by this or the Magic Bounce Ability's effect. Spikes, Stealth Rock, Sticky Web, and Toxic Spikes can only be reflected once per side, by the leftmost Pokemon under this or the Magic Bounce Ability's effect. The Lightning Rod and Storm Drain Abilities redirect their respective moves before this move takes effect.",
        "shortDescription": "Bounces back certain non-damaging moves.",
        "flags": [
            "metronome"
        ],
        "volatileStatus": "magiccoat"
    },
    "magicpowder": {
        "id": "magicpowder",
        "name": "Magic Powder",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become a Psychic type. Fails if the target is an Arceus or a Silvally, if the target is already purely Psychic type, or if the target is Terastallized.",
        "shortDescription": "Changes the target's type to Psychic.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome",
            "powder"
        ]
    },
    "magicroom": {
        "id": "magicroom",
        "name": "Magic Room",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the held items of all active Pokemon have no effect. An item's effect of causing forme changes is unaffected, but any other effects from such items are negated. During the effect, Fling and Natural Gift are prevented from being used by all active Pokemon. If this move is used during the effect, the effect ends.",
        "shortDescription": "For 5 turns, all held items have no effect.",
        "flags": [
            "mirror",
            "metronome"
        ],
        "pseudoWeather": "magicroom"
    },
    "magnetbomb": {
        "id": "magnetbomb",
        "name": "Magnet Bomb",
        "type": "steel",
        "category": "physical",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "magneticflux": {
        "id": "magneticflux",
        "name": "Magnetic Flux",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "allySide",
        "description": "Raises the Defense and Special Defense of Pokemon on the user's side with the Plus or Minus Abilities by 1 stage.",
        "shortDescription": "Raises Def, Sp. Def of allies with Plus/Minus by 1.",
        "flags": [
            "snatch",
            "distance",
            "bypasssub",
            "metronome"
        ]
    },
    "magnetrise": {
        "id": "magnetrise",
        "name": "Magnet Rise",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "For 5 turns, the user is immune to Ground-type attacks and the effects of Spikes, Toxic Spikes, Sticky Web, and the Arena Trap Ability as long as it remains active. If the user uses Baton Pass, the replacement will gain the effect. Ingrain, Smack Down, Thousand Arrows, and Iron Ball override this move if the user is under any of their effects. Fails if the user is already under this effect or the effects of Ingrain, Smack Down, or Thousand Arrows.",
        "shortDescription": "For 5 turns, the user has immunity to Ground.",
        "flags": [
            "snatch",
            "gravity",
            "metronome"
        ],
        "volatileStatus": "magnetrise"
    },
    "magnitude": {
        "id": "magnitude",
        "name": "Magnitude",
        "type": "ground",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "allAdjacent",
        "description": "The power of this move varies; 5% chances for 10 and 150 power, 10% chances for 30 and 110 power, 20% chances for 50 and 90 power, and 30% chance for 70 power. Damage doubles if the target is using Dig.",
        "shortDescription": "Hits adjacent Pokemon. Power varies; 2x on Dig.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "makeitrain": {
        "id": "makeitrain",
        "name": "Make It Rain",
        "type": "steel",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the user's Special Attack by 1 stage.",
        "shortDescription": "Lowers the user's Sp. Atk by 1. Hits foe(s).",
        "flags": [
            "protect",
            "mirror"
        ],
        "selfBoosts": {
            "spa": -1
        }
    },
    "matblock": {
        "id": "matblock",
        "name": "Mat Block",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "allySide",
        "description": "The user and its party members are protected from damaging attacks made by other Pokemon, including allies, during this turn. Fails unless it is the user's first turn on the field, if the user moves last this turn, or if this move is already in effect for the user's side.",
        "shortDescription": "Protects allies from damaging attacks. Turn 1 only.",
        "flags": [
            "snatch",
            "nonsky",
            "noassist",
            "failcopycat"
        ],
        "sideCondition": "matblock"
    },
    "matchagotcha": {
        "id": "matchagotcha",
        "name": "Matcha Gotcha",
        "type": "grass",
        "category": "special",
        "power": 80,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 20% chance to burn the target. The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down. The target thaws out if it is frozen.",
        "shortDescription": "20% burn. Recovers 50% dmg dealt. Thaws foe(s).",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "heal",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "brn"
            }
        ],
        "drain": [
            1,
            2
        ]
    },
    "meanlook": {
        "id": "meanlook",
        "name": "Mean Look",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Prevents the target from switching out.",
        "flags": [
            "reflectable",
            "mirror",
            "metronome"
        ],
        "trapTarget": true
    },
    "meditate": {
        "id": "meditate",
        "name": "Meditate",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack by 1 stage.",
        "shortDescription": "Raises the user's Attack by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1
        }
    },
    "mefirst": {
        "id": "mefirst",
        "name": "Me First",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "adjacentFoe",
        "description": "The user uses the move the target chose for use this turn against it, if possible, with its power multiplied by 1.5. The move must be a damaging move other than Beak Blast, Belch, Blazing Torque, Combat Torque, Comeuppance, Counter, Covet, Focus Punch, Magical Torque, Me First, Metal Burst, Mirror Coat, Noxious Torque, Shell Trap, Struggle, Thief, or Wicked Torque. Fails if the target moves before the user. Ignores the target's substitute for the purpose of copying the move.",
        "shortDescription": "Copies a foe at 1.5x power. User must be faster.",
        "flags": [
            "protect",
            "bypasssub",
            "failencore",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "megadrain": {
        "id": "megadrain",
        "name": "Mega Drain",
        "type": "grass",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "megahorn": {
        "id": "megahorn",
        "name": "Megahorn",
        "type": "bug",
        "category": "physical",
        "power": 120,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "megakick": {
        "id": "megakick",
        "name": "Mega Kick",
        "type": "normal",
        "category": "physical",
        "power": 120,
        "accuracy": 75,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "megapunch": {
        "id": "megapunch",
        "name": "Mega Punch",
        "type": "normal",
        "category": "physical",
        "power": 80,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ]
    },
    "memento": {
        "id": "memento",
        "name": "Memento",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack and Special Attack by 2 stages. The user faints unless this move misses or there is no target. Fails entirely if this move hits a substitute, but does not fail if the target's stats cannot be changed.",
        "shortDescription": "Lowers target's Attack, Sp. Atk by 2. User faints.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "atk": -2,
            "spa": -2
        },
        "selfdestruct": true
    },
    "metalburst": {
        "id": "metalburst",
        "name": "Metal Burst",
        "type": "steel",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "scripted",
        "description": "Deals damage to the last opposing Pokemon to hit the user with a physical or special attack this turn equal to 1.5 times the HP lost by the user from that attack, rounded down. If the user did not lose HP from that attack, this move deals 1 HP of damage instead. If that opposing Pokemon's position is no longer in use and there is another opposing Pokemon on the field, the damage is done to it instead. Only the last hit of a multi-hit attack is counted. Fails if the user was not hit by an opposing Pokemon's physical or special attack this turn.",
        "shortDescription": "If hit by an attack, returns 1.5x damage.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "failmefirst"
        ]
    },
    "metalclaw": {
        "id": "metalclaw",
        "name": "Metal Claw",
        "type": "steel",
        "category": "physical",
        "power": 50,
        "accuracy": 95,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to raise the user's Attack by 1 stage.",
        "shortDescription": "10% chance to raise the user's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "selfBoosts": {
                    "atk": 1
                }
            }
        ]
    },
    "metalsound": {
        "id": "metalsound",
        "name": "Metal Sound",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 85,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Special Defense by 2 stages.",
        "shortDescription": "Lowers the target's Sp. Def by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "spd": -2
        }
    },
    "meteorassault": {
        "id": "meteorassault",
        "name": "Meteor Assault",
        "type": "fighting",
        "category": "physical",
        "power": 150,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "recharge",
            "protect",
            "mirror",
            "failinstruct"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "meteormash": {
        "id": "meteormash",
        "name": "Meteor Mash",
        "type": "steel",
        "category": "physical",
        "power": 90,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to raise the user's Attack by 1 stage.",
        "shortDescription": "20% chance to raise the user's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "selfBoosts": {
                    "atk": 1
                }
            }
        ]
    },
    "metronome": {
        "id": "metronome",
        "name": "Metronome",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "A random move is selected for use, other than After You, Apple Acid, Armor Cannon, Assist, Astral Barrage, Aura Wheel, Baneful Bunker, Beak Blast, Behemoth Bash, Behemoth Blade, Belch, Bestow, Blazing Torque, Body Press, Branch Poke, Breaking Swipe, Celebrate, Chatter, Chilling Water, Chilly Reception, Clangorous Soul, Collision Course, Combat Torque, Comeuppance, Copycat, Counter, Covet, Crafty Shield, Decorate, Destiny Bond, Detect, Diamond Storm, Doodle, Double Iron Bash, Double Shock, Dragon Ascent, Dragon Energy, Drum Beating, Dynamax Cannon, Electro Drift, Endure, Eternabeam, False Surrender, Feint, Fiery Wrath, Fillet Away, Fleur Cannon, Focus Punch, Follow Me, Freeze Shock, Freezing Glare, Glacial Lance, Grav Apple, Helping Hand, Hold Hands, Hyper Drill, Hyperspace Fury, Hyperspace Hole, Ice Burn, Instruct, Jet Punch, Jungle Healing, King's Shield, Life Dew, Light of Ruin, Magical Torque, Make It Rain, Mat Block, Me First, Meteor Assault, Metronome, Mimic, Mind Blown, Mirror Coat, Mirror Move, Moongeist Beam, Nature Power, Nature's Madness, Noxious Torque, Obstruct, Order Up, Origin Pulse, Overdrive, Photon Geyser, Plasma Fists, Population Bomb, Pounce, Power Shift, Precipice Blades, Protect, Pyro Ball, Quash, Quick Guard, Rage Fist, Rage Powder, Raging Bull, Raging Fury, Relic Song, Revival Blessing, Ruination, Salt Cure, Secret Sword, Shed Tail, Shell Trap, Silk Trap, Sketch, Sleep Talk, Snap Trap, Snarl, Snatch, Snore, Snowscape, Spectral Thief, Spicy Extract, Spiky Shield, Spirit Break, Spotlight, Springtide Storm, Steam Eruption, Steel Beam, Strange Steam, Struggle, Sunsteel Strike, Surging Strikes, Switcheroo, Techno Blast, Tera Starstorm, Thief, Thousand Arrows, Thousand Waves, Thunder Cage, Thunderous Kick, Tidy Up, Trailblaze, Transform, Trick, Twin Beam, V-create, Wicked Blow, Wicked Torque, or Wide Guard.",
        "shortDescription": "Picks a random move.",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "milkdrink": {
        "id": "milkdrink",
        "name": "Milk Drink",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user by 50% of its max HP.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "heal": [
            1,
            2
        ]
    },
    "mimic": {
        "id": "mimic",
        "name": "Mimic",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "While the user remains active, this move is replaced by the last move used by the target. The copied move has the maximum PP for that move. Fails if the target has not made a move, if the user has Transformed, if the user already knows the move, or if the move is Assist, Behemoth Bash, Behemoth Blade, Belch, Blazing Torque, Celebrate, Chatter, Combat Torque, Copycat, Dynamax Cannon, Hold Hands, Magical Torque, Me First, Metronome, Mimic, Mirror Move, Nature Power, Noxious Torque, Sketch, Sleep Talk, Struggle, Tera Starstorm, Transform, or Wicked Torque.",
        "shortDescription": "The last move the target used replaces this one.",
        "flags": [
            "protect",
            "bypasssub",
            "allyanim",
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "mindreader": {
        "id": "mindreader",
        "name": "Mind Reader",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Until the end of the next turn, the target cannot avoid the user's moves, even if the target is in the middle of a two-turn move. The effect ends if either the user or the target leaves the field. Fails if this effect is active for the user.",
        "shortDescription": "User's next move will not miss the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "minimize": {
        "id": "minimize",
        "name": "Minimize",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's evasiveness by 2 stages. Whether or not the user's evasiveness was changed, Body Slam, Dragon Rush, Flying Press, Heat Crash, Heavy Slam, Malicious Moonsault, Steamroller, and Stomp will not check accuracy and have their damage doubled if used against the user while it is active.",
        "shortDescription": "Raises the user's evasiveness by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "evasion": 2
        },
        "volatileStatus": "minimize"
    },
    "miracleeye": {
        "id": "miracleeye",
        "name": "Miracle Eye",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "As long as the target remains active, its evasiveness stat stage is ignored during accuracy checks against it if it is greater than 0, and Psychic-type attacks can hit the target if it is a Dark type. Fails if the target is already affected, or affected by Foresight or Odor Sleuth.",
        "shortDescription": "Psychic hits Dark. Evasiveness ignored.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "miracleeye"
    },
    "mirrorcoat": {
        "id": "mirrorcoat",
        "name": "Mirror Coat",
        "type": "psychic",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": -5,
        "target": "scripted",
        "description": "Deals damage to the last opposing Pokemon to hit the user with a special attack this turn equal to twice the HP lost by the user from that attack. If the user did not lose HP from the attack, this move deals 1 HP of damage instead. If that opposing Pokemon's position is no longer in use and there is another opposing Pokemon on the field, the damage is done to it instead. Only the last hit of a multi-hit attack is counted. Fails if the user was not hit by an opposing Pokemon's special attack this turn.",
        "shortDescription": "If hit by special attack, returns double damage.",
        "flags": [
            "protect",
            "failmefirst",
            "noassist"
        ]
    },
    "mirrormove": {
        "id": "mirrormove",
        "name": "Mirror Move",
        "type": "flying",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "The user uses the last move used by the target. The copied move is used against that target, if possible. Fails if the target has not made a move, or if the last move used cannot be copied by this move.",
        "shortDescription": "User uses the target's last used move against it.",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "mirrorshot": {
        "id": "mirrorshot",
        "name": "Mirror Shot",
        "type": "steel",
        "category": "special",
        "power": 65,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "30% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "mist": {
        "id": "mist",
        "name": "Mist",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members are protected from having their stat stages lowered by other Pokemon. Fails if the effect is already active on the user's side.",
        "shortDescription": "For 5 turns, protects user's party from stat drops.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "mist"
    },
    "mistball": {
        "id": "mistball",
        "name": "Mist Ball",
        "type": "psychic",
        "category": "special",
        "power": 95,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "50% chance to lower the target's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "mistyterrain": {
        "id": "mistyterrain",
        "name": "Misty Terrain",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the terrain becomes Misty Terrain. During the effect, the power of Dragon-type attacks used against grounded Pokemon is multiplied by 0.5 and grounded Pokemon cannot be inflicted with a non-volatile status condition nor confusion. Grounded Pokemon can become affected by Yawn but cannot fall asleep from its effect. Camouflage transforms the user into a Fairy type, Nature Power becomes Moonblast, and Secret Power has a 30% chance to lower Special Attack by 1 stage. Fails if the current terrain is Misty Terrain.",
        "shortDescription": "5 turns. Can't status,-Dragon power vs grounded.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "terrain": "mistyterrain"
    },
    "moonblast": {
        "id": "moonblast",
        "name": "Moonblast",
        "type": "fairy",
        "category": "special",
        "power": 95,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "30% chance to lower the target's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "moonlight": {
        "id": "moonlight",
        "name": "Moonlight",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP if Delta Stream or no weather conditions are in effect or if the user is holding Utility Umbrella, 2/3 of its maximum HP if the weather is Desolate Land or Sunny Day, and 1/4 of its maximum HP if the weather is Primordial Sea, Rain Dance, Sandstorm, or Snow, all rounded half down.",
        "shortDescription": "Heals the user by a weather-dependent amount.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "morningsun": {
        "id": "morningsun",
        "name": "Morning Sun",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP if Delta Stream or no weather conditions are in effect or if the user is holding Utility Umbrella, 2/3 of its maximum HP if the weather is Desolate Land or Sunny Day, and 1/4 of its maximum HP if the weather is Primordial Sea, Rain Dance, Sandstorm, or Snow, all rounded half down.",
        "shortDescription": "Heals the user by a weather-dependent amount.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "mortalspin": {
        "id": "mortalspin",
        "name": "Mortal Spin",
        "type": "poison",
        "category": "physical",
        "power": 30,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "If this move is successful and the user has not fainted, the effects of Leech Seed and binding moves end for the user, and all hazards are removed from the user's side of the field. Has a 100% chance to poison the target.",
        "shortDescription": "Poisons foes, frees user from hazards/bind/leech.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "status": "psn"
            }
        ]
    },
    "mudbomb": {
        "id": "mudbomb",
        "name": "Mud Bomb",
        "type": "ground",
        "category": "special",
        "power": 65,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "30% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "muddywater": {
        "id": "muddywater",
        "name": "Muddy Water",
        "type": "water",
        "category": "special",
        "power": 90,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 30% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "30% chance to lower the foe(s) accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "mudshot": {
        "id": "mudshot",
        "name": "Mud Shot",
        "type": "ground",
        "category": "special",
        "power": 55,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the target's Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "mudslap": {
        "id": "mudslap",
        "name": "Mud-Slap",
        "type": "ground",
        "category": "special",
        "power": 20,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "100% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "mudsport": {
        "id": "mudsport",
        "name": "Mud Sport",
        "type": "ground",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, all Electric-type attacks used by any active Pokemon have their power multiplied by 0.33. Fails if this effect is already active.",
        "shortDescription": "For 5 turns, Electric-type attacks have 1/3 power.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "pseudoWeather": "mudsport"
    },
    "multiattack": {
        "id": "multiattack",
        "name": "Multi-Attack",
        "type": "normal",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move's type depends on the user's held Memory.",
        "shortDescription": "Type varies based on the held Memory.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "mysticalfire": {
        "id": "mysticalfire",
        "name": "Mystical Fire",
        "type": "fire",
        "category": "special",
        "power": 75,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "100% chance to lower the target's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "mysticalpower": {
        "id": "mysticalpower",
        "name": "Mystical Power",
        "type": "psychic",
        "category": "special",
        "power": 70,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Special Attack by 1 stage.",
        "shortDescription": "100% chance to raise the user's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spa": 1
                }
            }
        ]
    },
    "nastyplot": {
        "id": "nastyplot",
        "name": "Nasty Plot",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Attack by 2 stages.",
        "shortDescription": "Raises the user's Sp. Atk by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spa": 2
        }
    },
    "naturalgift": {
        "id": "naturalgift",
        "name": "Natural Gift",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The type and power of this move depend on the user's held Berry, and the Berry is lost. Fails if the user is not holding a Berry, if the user has the Klutz Ability, or if Embargo or Magic Room is in effect for the user.",
        "shortDescription": "Power and type depends on the user's Berry.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "naturepower": {
        "id": "naturepower",
        "name": "Nature Power",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move calls another move for use based on the battle terrain. Tri Attack on the regular Wi-Fi terrain, Thunderbolt during Electric Terrain, Moonblast during Misty Terrain, Energy Ball during Grassy Terrain, and Psychic during Psychic Terrain.",
        "shortDescription": "Attack depends on terrain (default Tri Attack).",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "needlearm": {
        "id": "needlearm",
        "name": "Needle Arm",
        "type": "grass",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "nightdaze": {
        "id": "nightdaze",
        "name": "Night Daze",
        "type": "dark",
        "category": "special",
        "power": 85,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 40% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "40% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 40,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "nightmare": {
        "id": "nightmare",
        "name": "Nightmare",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to lose 1/4 of its maximum HP, rounded down, at the end of each turn as long as it is asleep. This move does not affect the target unless it is asleep. The effect ends when the target wakes up, even if it falls asleep again in the same turn.",
        "shortDescription": "A sleeping target is hurt by 1/4 max HP per turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "nightmare"
    },
    "nightshade": {
        "id": "nightshade",
        "name": "Night Shade",
        "type": "ghost",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the user's level.",
        "shortDescription": "Does damage equal to the user's level.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "fixedDamage": "level"
    },
    "nightslash": {
        "id": "nightslash",
        "name": "Night Slash",
        "type": "dark",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "nobleroar": {
        "id": "nobleroar",
        "name": "Noble Roar",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack and Special Attack by 1 stage.",
        "shortDescription": "Lowers the target's Attack and Sp. Atk by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "boosts": {
            "atk": -1,
            "spa": -1
        }
    },
    "noretreat": {
        "id": "noretreat",
        "name": "No Retreat",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage, but it becomes prevented from switching out. The user can still switch out if it uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the user leaves the field using Baton Pass, the replacement will remain trapped. Fails if the user has already been prevented from switching by this effect.",
        "shortDescription": "Raises all stats by 1 (not acc/eva). Traps user.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "def": 1,
            "spa": 1,
            "spd": 1,
            "spe": 1
        },
        "volatileStatus": "noretreat"
    },
    "nuzzle": {
        "id": "nuzzle",
        "name": "Nuzzle",
        "type": "electric",
        "category": "physical",
        "power": 20,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to paralyze the target.",
        "shortDescription": "100% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "status": "par"
            }
        ]
    },
    "obstruct": {
        "id": "obstruct",
        "name": "Obstruct",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn, and Pokemon trying to make contact with the user have their Defense lowered by 2 stages. Non-damaging moves go through this protection. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Protects from damaging attacks. Contact: -2 Def.",
        "flags": [
            "failinstruct"
        ],
        "volatileStatus": "obstruct"
    },
    "octazooka": {
        "id": "octazooka",
        "name": "Octazooka",
        "type": "water",
        "category": "special",
        "power": 65,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's accuracy by 1 stage.",
        "shortDescription": "50% chance to lower the target's accuracy by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "accuracy": -1
                }
            }
        ]
    },
    "octolock": {
        "id": "octolock",
        "name": "Octolock",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. At the end of each turn during effect, the target's Defense and Special Defense are lowered by 1 stage. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Traps target, lowers Def and SpD by 1 each turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "octolock"
    },
    "odorsleuth": {
        "id": "odorsleuth",
        "name": "Odor Sleuth",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "As long as the target remains active, its evasiveness stat stage is ignored during accuracy checks against it if it is greater than 0, and Normal- and Fighting-type attacks can hit the target if it is a Ghost type. Fails if the target is already affected, or affected by Foresight or Miracle Eye.",
        "shortDescription": "Fighting, Normal hit Ghost. Evasiveness ignored.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome"
        ],
        "volatileStatus": "foresight"
    },
    "ominouswind": {
        "id": "ominouswind",
        "name": "Ominous Wind",
        "type": "ghost",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to raise the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage.",
        "shortDescription": "10% chance to raise all stats by 1 (not acc/eva).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "selfBoosts": {
                    "atk": 1,
                    "def": 1,
                    "spa": 1,
                    "spd": 1,
                    "spe": 1
                }
            }
        ]
    },
    "orderup": {
        "id": "orderup",
        "name": "Order Up",
        "type": "dragon",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If an ally Tatsugiri has activated its Commander Ability, this move raises the user's Attack by 1 stage if the Tatsugiri is Curly Form, Defense by 1 stage if Droopy Form, or Speed by 1 stage if Stretchy Form. The effect happens whether or not this move is successful, and even if the Tatsugiri that activated the effect has since fainted.",
        "shortDescription": "Curly|Droopy|Stretchy eaten: +1 Atk|Def|Spe.",
        "flags": [
            "protect"
        ]
    },
    "originpulse": {
        "id": "originpulse",
        "name": "Origin Pulse",
        "type": "water",
        "category": "special",
        "power": 110,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "pulse"
        ]
    },
    "outrage": {
        "id": "outrage",
        "name": "Outrage",
        "type": "dragon",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "randomNormal",
        "description": "The user spends two or three turns locked into this move and becomes confused immediately after its move on the last turn of the effect if it is not already. This move targets an opposing Pokemon at random on each turn. If the user is prevented from moving, is asleep at the beginning of a turn, or the attack is not successful against the target on the first turn of the effect or the second turn of a three-turn effect, the effect ends without causing confusion. If this move is called by Sleep Talk and the user is asleep, the move is used for one turn and does not confuse the user.",
        "shortDescription": "Lasts 2-3 turns. Confuses the user afterwards.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "failinstruct"
        ],
        "selfVolatileStatus": "lockedmove"
    },
    "overdrive": {
        "id": "overdrive",
        "name": "Overdrive",
        "type": "electric",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits foe(s).",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub"
        ]
    },
    "overheat": {
        "id": "overheat",
        "name": "Overheat",
        "type": "fire",
        "category": "special",
        "power": 130,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Special Attack by 2 stages.",
        "shortDescription": "Lowers the user's Sp. Atk by 2.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "selfBoosts": {
            "spa": -2
        }
    },
    "painsplit": {
        "id": "painsplit",
        "name": "Pain Split",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "The user and the target's HP become the average of their current HP, rounded down, but not more than the maximum HP of either one.",
        "shortDescription": "Shares HP of user and target equally.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "paraboliccharge": {
        "id": "paraboliccharge",
        "name": "Parabolic Charge",
        "type": "electric",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacent",
        "description": "The user recovers 1/2 the HP lost by the target, rounded half up. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down.",
        "shortDescription": "User recovers 50% of the damage dealt.",
        "flags": [
            "protect",
            "mirror",
            "heal",
            "metronome"
        ],
        "drain": [
            1,
            2
        ]
    },
    "partingshot": {
        "id": "partingshot",
        "name": "Parting Shot",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack and Special Attack by 1 stage. If this move is successful, the user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if the target's Attack and Special Attack stat stages were both unchanged, or if there are no unfainted party members.",
        "shortDescription": "Lowers target's Atk, Sp. Atk by 1. User switches.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "selfSwitch": true
    },
    "payback": {
        "id": "payback",
        "name": "Payback",
        "type": "dark",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user moves after the target this turn, including actions taken through Instruct or the Dancer Ability. Switching in does not count as an action.",
        "shortDescription": "Power doubles if the user moves after the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "payday": {
        "id": "payday",
        "name": "Pay Day",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Scatters coins.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "peck": {
        "id": "peck",
        "name": "Peck",
        "type": "flying",
        "category": "physical",
        "power": 35,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "any",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ]
    },
    "perishsong": {
        "id": "perishsong",
        "name": "Perish Song",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "all",
        "description": "Each active Pokemon receives a perish count of 4 if it doesn't already have a perish count. At the end of each turn including the turn used, the perish count of all active Pokemon lowers by 1 and Pokemon faint if the number reaches 0. The perish count is removed from Pokemon that switch out. If a Pokemon uses Baton Pass while it has a perish count, the replacement will gain the perish count and continue to count down.",
        "shortDescription": "All active Pokemon will faint in 3 turns.",
        "flags": [
            "sound",
            "distance",
            "bypasssub",
            "metronome"
        ]
    },
    "petalblizzard": {
        "id": "petalblizzard",
        "name": "Petal Blizzard",
        "type": "grass",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacent",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ]
    },
    "petaldance": {
        "id": "petaldance",
        "name": "Petal Dance",
        "type": "grass",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "randomNormal",
        "description": "The user spends two or three turns locked into this move and becomes confused immediately after its move on the last turn of the effect if it is not already. This move targets an opposing Pokemon at random on each turn. If the user is prevented from moving, is asleep at the beginning of a turn, or the attack is not successful against the target on the first turn of the effect or the second turn of a three-turn effect, the effect ends without causing confusion. If this move is called by Sleep Talk and the user is asleep, the move is used for one turn and does not confuse the user.",
        "shortDescription": "Lasts 2-3 turns. Confuses the user afterwards.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "dance",
            "metronome",
            "failinstruct"
        ],
        "selfVolatileStatus": "lockedmove"
    },
    "phantomforce": {
        "id": "phantomforce",
        "name": "Phantom Force",
        "type": "ghost",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it breaks through the target's Baneful Bunker, Detect, King's Shield, Protect, or Spiky Shield for this turn, allowing other Pokemon to attack the target normally. If the target's side is protected by Crafty Shield, Mat Block, Quick Guard, or Wide Guard, that protection is also broken for this turn and other Pokemon may attack the target's side normally. This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Disappears turn 1. Hits turn 2. Breaks protection.",
        "flags": [
            "contact",
            "charge",
            "mirror",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ],
        "breaksProtect": true
    },
    "pinmissile": {
        "id": "pinmissile",
        "name": "Pin Missile",
        "type": "bug",
        "category": "physical",
        "power": 25,
        "accuracy": 95,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "playnice": {
        "id": "playnice",
        "name": "Play Nice",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack by 1 stage.",
        "shortDescription": "Lowers the target's Attack by 1.",
        "flags": [
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "boosts": {
            "atk": -1
        }
    },
    "playrough": {
        "id": "playrough",
        "name": "Play Rough",
        "type": "fairy",
        "category": "physical",
        "power": 90,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "10% chance to lower the target's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "pluck": {
        "id": "pluck",
        "name": "Pluck",
        "type": "flying",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "If this move is successful and the user has not fainted, it steals the target's held Berry if it is holding one and eats it immediately, gaining its effects even if the user's item is being ignored. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "User steals and eats the target's Berry.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ]
    },
    "poisonfang": {
        "id": "poisonfang",
        "name": "Poison Fang",
        "type": "poison",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to badly poison the target.",
        "shortDescription": "50% chance to badly poison the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 50,
                "status": "tox"
            }
        ]
    },
    "poisongas": {
        "id": "poisongas",
        "name": "Poison Gas",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 90,
        "pp": 40,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Poisons the target.",
        "shortDescription": "Poisons the foe(s).",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "psn"
    },
    "poisonjab": {
        "id": "poisonjab",
        "name": "Poison Jab",
        "type": "poison",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to poison the target.",
        "shortDescription": "30% chance to poison the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "psn"
            }
        ]
    },
    "poisonpowder": {
        "id": "poisonpowder",
        "name": "Poison Powder",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 75,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "Poisons the target.",
        "shortDescription": "Poisons the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome",
            "powder"
        ],
        "status": "psn"
    },
    "poisonsting": {
        "id": "poisonsting",
        "name": "Poison Sting",
        "type": "poison",
        "category": "physical",
        "power": 15,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to poison the target.",
        "shortDescription": "30% chance to poison the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "psn"
            }
        ]
    },
    "poisontail": {
        "id": "poisontail",
        "name": "Poison Tail",
        "type": "poison",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to poison the target and a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio. 10% chance to poison.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "psn"
            }
        ],
        "critRatio": 2
    },
    "pollenpuff": {
        "id": "pollenpuff",
        "name": "Pollen Puff",
        "type": "bug",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the target is an ally, this move restores 1/2 of its maximum HP, rounded down, instead of dealing damage.",
        "shortDescription": "If the target is an ally, heals 50% of its max HP.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "metronome",
            "bullet"
        ]
    },
    "populationbomb": {
        "id": "populationbomb",
        "name": "Population Bomb",
        "type": "normal",
        "category": "physical",
        "power": 20,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits ten times. This move checks accuracy for each hit, and the attack ends if the target avoids a hit. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit ten times. If the user is holding Loaded Dice, this move hits four to ten times at random without checking accuracy between hits.",
        "shortDescription": "Hits 10 times. Each hit can miss.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "slicing"
        ],
        "multihit": 10
    },
    "pound": {
        "id": "pound",
        "name": "Pound",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "powder": {
        "id": "powder",
        "name": "Powder",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 1,
        "target": "normal",
        "description": "If the target uses a Fire-type move this turn, it is prevented from executing and the target loses 1/4 of its maximum HP, rounded half up. This effect does not happen if the Fire-type move is prevented by Primordial Sea.",
        "shortDescription": "If using a Fire move, target loses 1/4 max HP.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome",
            "powder"
        ],
        "volatileStatus": "powder"
    },
    "powdersnow": {
        "id": "powdersnow",
        "name": "Powder Snow",
        "type": "ice",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 10% chance to freeze the target.",
        "shortDescription": "10% chance to freeze the foe(s).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "frz"
            }
        ]
    },
    "powergem": {
        "id": "powergem",
        "name": "Power Gem",
        "type": "rock",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "powersplit": {
        "id": "powersplit",
        "name": "Power Split",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user and the target have their Attack and Special Attack stats set to be equal to the average of the user and the target's Attack and Special Attack stats, respectively, rounded down. Stat stage changes are unaffected.",
        "shortDescription": "Averages Attack and Sp. Atk stats with target.",
        "flags": [
            "protect",
            "allyanim",
            "metronome"
        ]
    },
    "powerswap": {
        "id": "powerswap",
        "name": "Power Swap",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its Attack and Special Attack stat stage changes with the target.",
        "shortDescription": "Swaps Attack and Sp. Atk stat stages with target.",
        "flags": [
            "protect",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "powertrick": {
        "id": "powertrick",
        "name": "Power Trick",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user swaps its Attack and Defense stats, and stat stage changes remain on their respective stats. This move can be used again to swap the stats back. If the user uses Baton Pass, the replacement will have its Attack and Defense stats swapped if the effect is active. If the user has its stats recalculated by changing forme while its stats are swapped, this effect is ignored but is still active for the purposes of Baton Pass.",
        "shortDescription": "Switches user's Attack and Defense stats.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "volatileStatus": "powertrick"
    },
    "powertrip": {
        "id": "powertrip",
        "name": "Power Trip",
        "type": "dark",
        "category": "physical",
        "power": 20,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 20+(X*20), where X is the user's total stat stage changes that are greater than 0.",
        "shortDescription": " + 20 power for each of the user's stat boosts.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "poweruppunch": {
        "id": "poweruppunch",
        "name": "Power-Up Punch",
        "type": "fighting",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Attack by 1 stage.",
        "shortDescription": "100% chance to raise the user's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "atk": 1
                }
            }
        ]
    },
    "powerwhip": {
        "id": "powerwhip",
        "name": "Power Whip",
        "type": "grass",
        "category": "physical",
        "power": 120,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "precipiceblades": {
        "id": "precipiceblades",
        "name": "Precipice Blades",
        "type": "ground",
        "category": "physical",
        "power": 120,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "No additional effect.",
        "shortDescription": "No additional effect. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "nonsky"
        ]
    },
    "present": {
        "id": "present",
        "name": "Present",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it deals damage or heals the target. 40% chance for 40 power, 30% chance for 80 power, 10% chance for 120 power, and 20% chance to heal the target by 1/4 of its maximum HP, rounded down.",
        "shortDescription": "40, 80, 120 power, or heals target 1/4 max HP.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "protect": {
        "id": "protect",
        "name": "Protect",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Prevents moves from affecting the user this turn.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "protect"
    },
    "psybeam": {
        "id": "psybeam",
        "name": "Psybeam",
        "type": "psychic",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to confuse the target.",
        "shortDescription": "10% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "confusion"
            }
        ]
    },
    "psyblade": {
        "id": "psyblade",
        "name": "Psyblade",
        "type": "psychic",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the current terrain is Electric Terrain, this move's power is multiplied by 1.5.",
        "shortDescription": "During Electric Terrain: 1.5x power.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "psychic": {
        "id": "psychic",
        "name": "Psychic",
        "type": "psychic",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "10% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "psychicfangs": {
        "id": "psychicfangs",
        "name": "Psychic Fangs",
        "type": "psychic",
        "category": "physical",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this attack does not miss, the effects of Reflect, Light Screen, and Aurora Veil end for the target's side of the field before damage is calculated.",
        "shortDescription": "Destroys screens, unless the target is immune.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ]
    },
    "psychicterrain": {
        "id": "psychicterrain",
        "name": "Psychic Terrain",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the terrain becomes Psychic Terrain. During the effect, the power of Psychic-type attacks made by grounded Pokemon is multiplied by 1.3 and grounded Pokemon cannot be hit by moves with priority greater than 0, unless the target is an ally. Camouflage transforms the user into a Psychic type, Nature Power becomes Psychic, and Secret Power has a 30% chance to lower the target's Speed by 1 stage. Fails if the current terrain is Psychic Terrain.",
        "shortDescription": "5 turns. Grounded: +Psychic power, priority-safe.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "terrain": "psychicterrain"
    },
    "psychocut": {
        "id": "psychocut",
        "name": "Psycho Cut",
        "type": "psychic",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "psychoshift": {
        "id": "psychoshift",
        "name": "Psycho Shift",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user's non-volatile status condition is transferred to the target, and the user is then cured. Fails if the user has no non-volatile status condition or if the target already has one.",
        "shortDescription": "Transfers the user's status ailment to the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "psychup": {
        "id": "psychup",
        "name": "Psych Up",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user copies all of the target's current stat stage changes.",
        "shortDescription": "Copies the target's current stat stages.",
        "flags": [
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "psyshieldbash": {
        "id": "psyshieldbash",
        "name": "Psyshield Bash",
        "type": "psychic",
        "category": "physical",
        "power": 70,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Defense by 1 stage.",
        "shortDescription": "100% chance to raise the user's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "def": 1
                }
            }
        ]
    },
    "psyshock": {
        "id": "psyshock",
        "name": "Psyshock",
        "type": "psychic",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target based on its Defense instead of Special Defense.",
        "shortDescription": "Damages target based on Defense, not Sp. Def.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "psystrike": {
        "id": "psystrike",
        "name": "Psystrike",
        "type": "psychic",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target based on its Defense instead of Special Defense.",
        "shortDescription": "Damages target based on Defense, not Sp. Def.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "psywave": {
        "id": "psywave",
        "name": "Psywave",
        "type": "psychic",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to (user's level) * (X + 50) / 100, where X is a random number from 0 to 100, rounded down, but not less than 1 HP.",
        "shortDescription": "Random damage equal to 0.5x-1.5x user's level.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "punishment": {
        "id": "punishment",
        "name": "Punishment",
        "type": "dark",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 60+(X*20), where X is the target's total stat stage changes that are greater than 0, but not more than 200 power.",
        "shortDescription": "60 power +20 for each of the target's stat boosts.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "pursuit": {
        "id": "pursuit",
        "name": "Pursuit",
        "type": "dark",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If an opposing Pokemon switches out this turn, this move hits that Pokemon before it leaves the field, even if it was not the original target. If the user moves after an opponent using Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch, but not Baton Pass, it will hit that opponent before it leaves the field. Power doubles and no accuracy check is done if the user hits an opponent switching out, and the user's turn is over; if an opponent faints from this, the replacement Pokemon does not become active until the end of the turn.",
        "shortDescription": "If a foe is switching out, hits it at 2x power.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "pyroball": {
        "id": "pyroball",
        "name": "Pyro Ball",
        "type": "fire",
        "category": "physical",
        "power": 120,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to burn the target.",
        "shortDescription": "10% chance to burn the target. Thaws user.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "brn"
            }
        ]
    },
    "quash": {
        "id": "quash",
        "name": "Quash",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to take its turn after all other Pokemon this turn, no matter the priority of its selected move. Fails if the target already moved this turn.",
        "shortDescription": "Forces the target to move last this turn.",
        "flags": [
            "protect",
            "mirror"
        ]
    },
    "quickattack": {
        "id": "quickattack",
        "name": "Quick Attack",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "quickguard": {
        "id": "quickguard",
        "name": "Quick Guard",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 3,
        "target": "allySide",
        "description": "The user and its party members are protected from attacks with original or altered priority greater than 0 made by other Pokemon, including allies, during this turn. This move modifies the same 1/X chance of being successful used by other protection moves, where X starts at 1 and triples each time this move is successfully used, but does not use the chance to check for failure. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn or if this move is already in effect for the user's side.",
        "shortDescription": "Protects allies from priority attacks this turn.",
        "flags": [
            "snatch"
        ],
        "sideCondition": "quickguard"
    },
    "quiverdance": {
        "id": "quiverdance",
        "name": "Quiver Dance",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Attack, Special Defense, and Speed by 1 stage.",
        "shortDescription": "Raises the user's Sp. Atk, Sp. Def, Speed by 1.",
        "flags": [
            "snatch",
            "dance",
            "metronome"
        ],
        "boosts": {
            "spa": 1,
            "spd": 1,
            "spe": 1
        }
    },
    "rage": {
        "id": "rage",
        "name": "Rage",
        "type": "normal",
        "category": "physical",
        "power": 20,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Once this move is successfully used, the user's Attack is raised by 1 stage every time it is hit by another Pokemon's attack as long as this move is chosen for use.",
        "shortDescription": "Raises the user's Attack by 1 if hit during use.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfVolatileStatus": "rage"
    },
    "ragefist": {
        "id": "ragefist",
        "name": "Rage Fist",
        "type": "ghost",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 50+(X*50), where X is the total number of times the user has been hit by a damaging attack during the battle, even if the user did not lose HP from the attack. X cannot be greater than 6 and does not reset upon switching out or fainting. Each hit of a multi-hit attack is counted, but confusion damage is not counted.",
        "shortDescription": "+50 power for each time user was hit. Max 6 hits.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch"
        ]
    },
    "ragepowder": {
        "id": "ragepowder",
        "name": "Rage Powder",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 2,
        "target": "self",
        "description": "Until the end of the turn, all single-target attacks from the opposing side are redirected to the user. Such attacks are redirected to the user before they can be reflected by Magic Coat or the Magic Bounce Ability, or drawn in by the Lightning Rod or Storm Drain Abilities. Fails if it is not a Double Battle or Battle Royal. This effect is ignored while the user is under the effect of Sky Drop.",
        "shortDescription": "The foes' moves target the user on the turn used.",
        "flags": [
            "noassist",
            "failcopycat",
            "powder"
        ],
        "volatileStatus": "ragepowder"
    },
    "ragingbull": {
        "id": "ragingbull",
        "name": "Raging Bull",
        "type": "normal",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this attack does not miss, the effects of Reflect, Light Screen, and Aurora Veil end for the target's side of the field before damage is calculated. If the user's current form is a Paldean Tauros, this move's type changes to match. Fighting type for Combat Breed, Fire type for Blaze Breed, and Water type for Aqua Breed.",
        "shortDescription": "Destroys screens. Type depends on user's form.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ]
    },
    "ragingfury": {
        "id": "ragingfury",
        "name": "Raging Fury",
        "type": "fire",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "randomNormal",
        "description": "The user spends two or three turns locked into this move and becomes confused immediately after its move on the last turn of the effect if it is not already. This move targets an opposing Pokemon at random on each turn. If the user is prevented from moving, is asleep at the beginning of a turn, or the attack is not successful against the target on the first turn of the effect or the second turn of a three-turn effect, the effect ends without causing confusion. If this move is called by Sleep Talk and the user is asleep, the move is used for one turn and does not confuse the user.",
        "shortDescription": "Lasts 2-3 turns. Confuses the user afterwards.",
        "flags": [
            "protect",
            "mirror"
        ],
        "selfVolatileStatus": "lockedmove"
    },
    "raindance": {
        "id": "raindance",
        "name": "Rain Dance",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Rain Dance. The damage of Water-type attacks is multiplied by 1.5 and the damage of Fire-type attacks is multiplied by 0.5 during the effect. Lasts for 8 turns if the user is holding Damp Rock. Fails if the current weather is Rain Dance.",
        "shortDescription": "For 5 turns, heavy rain powers Water moves.",
        "flags": [
            "metronome"
        ],
        "weather": "raindance"
    },
    "rapidspin": {
        "id": "rapidspin",
        "name": "Rapid Spin",
        "type": "normal",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful and the user has not fainted, the effects of Leech Seed and binding moves end for the user, and all hazards are removed from the user's side of the field. Has a 100% chance to raise the user's Speed by 1 stage.",
        "shortDescription": "Free user from hazards/bind/Leech Seed; +1 Spe.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spe": 1
                }
            }
        ]
    },
    "razorleaf": {
        "id": "razorleaf",
        "name": "Razor Leaf",
        "type": "grass",
        "category": "physical",
        "power": 55,
        "accuracy": 95,
        "pp": 25,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio. Hits adjacent foes.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "razorshell": {
        "id": "razorshell",
        "name": "Razor Shell",
        "type": "water",
        "category": "physical",
        "power": 75,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "50% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "razorwind": {
        "id": "razorwind",
        "name": "Razor Wind",
        "type": "normal",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a higher chance for a critical hit. This attack charges on the first turn and executes on the second. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Charges, then hits foe(s) turn 2. High crit ratio.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ],
        "critRatio": 2
    },
    "recover": {
        "id": "recover",
        "name": "Recover",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user by 50% of its max HP.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "heal": [
            1,
            2
        ]
    },
    "recycle": {
        "id": "recycle",
        "name": "Recycle",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user regains the item it last used. Fails if the user is holding an item, if the user has not held an item, if the item was a popped Air Balloon, if the item was picked up by a Pokemon with the Pickup Ability, or if the item was lost to Bug Bite, Corrosive Gas, Covet, Incinerate, Knock Off, Pluck, or Thief. Items thrown with Fling can be regained.",
        "shortDescription": "Restores the item the user last used.",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "reflect": {
        "id": "reflect",
        "name": "Reflect",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members take 0.5x damage from physical attacks, or 0.66x damage if in a Double Battle. Damage is not reduced further with Aurora Veil. Critical hits ignore this effect. It is removed from the user's side if the user or an ally is successfully hit by Brick Break, Psychic Fangs, or Defog. Lasts for 8 turns if the user is holding Light Clay. Fails if the effect is already active on the user's side.",
        "shortDescription": "For 5 turns, physical damage to allies is halved.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "reflect"
    },
    "reflecttype": {
        "id": "reflecttype",
        "name": "Reflect Type",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the user's types to become the same as the current types of the target. If the target's current types include typeless and a non-added type, typeless is ignored. If the target's current types include typeless and an added type from Forest's Curse or Trick-or-Treat, typeless is copied as the Normal type instead. Fails if the user is an Arceus or a Silvally, if the user is Terastallized, or if the target's current type is typeless alone.",
        "shortDescription": "User becomes the same type as the target.",
        "flags": [
            "protect",
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "refresh": {
        "id": "refresh",
        "name": "Refresh",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "The user cures its burn, poison, or paralysis. Fails if the user is not burned, poisoned, or paralyzed.",
        "shortDescription": "User cures its burn, poison, or paralysis.",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "rest": {
        "id": "rest",
        "name": "Rest",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user falls asleep for the next two turns and restores all of its HP, curing itself of any non-volatile status condition in the process. Fails if the user has full HP, is already asleep, or if another effect is preventing sleep.",
        "shortDescription": "User sleeps 2 turns and restores HP and status.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "retaliate": {
        "id": "retaliate",
        "name": "Retaliate",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if one of the user's party members fainted last turn.",
        "shortDescription": "Power doubles if an ally fainted last turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "return": {
        "id": "return",
        "name": "Return",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to the greater of (user's Happiness * 2/5), rounded down, or 1.",
        "shortDescription": "Max 102 power at maximum Happiness.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "revenge": {
        "id": "revenge",
        "name": "Revenge",
        "type": "fighting",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": -4,
        "target": "normal",
        "description": "Power doubles if the user was hit by the target this turn.",
        "shortDescription": "Power doubles if user is damaged by the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "reversal": {
        "id": "reversal",
        "name": "Reversal",
        "type": "fighting",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move is 20 if X is 33 to 48, 40 if X is 17 to 32, 80 if X is 10 to 16, 100 if X is 5 to 9, 150 if X is 2 to 4, and 200 if X is 0 or 1, where X is equal to (user's current HP * 48 / user's maximum HP), rounded down.",
        "shortDescription": "More power the less HP the user has left.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "revivalblessing": {
        "id": "revivalblessing",
        "name": "Revival Blessing",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 1,
        "priority": 0,
        "target": "self",
        "description": "A fainted party member is selected and revived with 1/2 its max HP, rounded down. Fails if there are no fainted party members.",
        "shortDescription": "Revives a fainted Pokemon to 50% HP.",
        "flags": [
            "heal"
        ],
        "selfSwitch": true
    },
    "roar": {
        "id": "roar",
        "name": "Roar",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": -6,
        "target": "normal",
        "description": "The target is forced to switch out and be replaced with a random unfainted ally. Fails if the target is the last unfainted Pokemon in its party, or if the target used Ingrain previously or has the Suction Cups Ability.",
        "shortDescription": "Forces the target to switch to a random ally.",
        "flags": [
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "allyanim",
            "metronome",
            "noassist",
            "failcopycat"
        ],
        "forceSwitch": true
    },
    "roaroftime": {
        "id": "roaroftime",
        "name": "Roar of Time",
        "type": "dragon",
        "category": "special",
        "power": 150,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "recharge",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "rockblast": {
        "id": "rockblast",
        "name": "Rock Blast",
        "type": "rock",
        "category": "physical",
        "power": 25,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "rockclimb": {
        "id": "rockclimb",
        "name": "Rock Climb",
        "type": "normal",
        "category": "physical",
        "power": 90,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to confuse the target.",
        "shortDescription": "20% chance to confuse the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "confusion"
            }
        ]
    },
    "rockpolish": {
        "id": "rockpolish",
        "name": "Rock Polish",
        "type": "rock",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Speed by 2 stages.",
        "shortDescription": "Raises the user's Speed by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spe": 2
        }
    },
    "rockslide": {
        "id": "rockslide",
        "name": "Rock Slide",
        "type": "rock",
        "category": "physical",
        "power": 75,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the foe(s) flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "rocksmash": {
        "id": "rocksmash",
        "name": "Rock Smash",
        "type": "fighting",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Defense by 1 stage.",
        "shortDescription": "50% chance to lower the target's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "def": -1
                }
            }
        ]
    },
    "rockthrow": {
        "id": "rockthrow",
        "name": "Rock Throw",
        "type": "rock",
        "category": "physical",
        "power": 50,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "rocktomb": {
        "id": "rocktomb",
        "name": "Rock Tomb",
        "type": "rock",
        "category": "physical",
        "power": 60,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Speed by 1 stage.",
        "shortDescription": "100% chance to lower the target's Speed by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spe": -1
                }
            }
        ]
    },
    "rockwrecker": {
        "id": "rockwrecker",
        "name": "Rock Wrecker",
        "type": "rock",
        "category": "physical",
        "power": 150,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user must recharge on the following turn and cannot select a move.",
        "shortDescription": "User cannot move next turn.",
        "flags": [
            "recharge",
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "selfVolatileStatus": "mustrecharge"
    },
    "roleplay": {
        "id": "roleplay",
        "name": "Role Play",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user's Ability changes to match the target's Ability. Fails if the user's Ability is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Multitype, Power Construct, RKS System, Schooling, Shields Down, Stance Change, Tera Shift, Zen Mode, Zero to Hero, or already matches the target, or if the target's Ability is As One, Battle Bond, Comatose, Commander, Disguise, Embody Aspect, Flower Gift, Forecast, Hunger Switch, Ice Face, Illusion, Imposter, Multitype, Neutralizing Gas, Poison Puppeteer, Power Construct, Power of Alchemy, Protosynthesis, Quark Drive, Receiver, RKS System, Schooling, Shields Down, Stance Change, Tera Shell, Tera Shift, Teraform Zero, Trace, Wonder Guard, Zen Mode, or Zero to Hero.",
        "shortDescription": "User replaces its Ability with the target's.",
        "flags": [
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "rollingkick": {
        "id": "rollingkick",
        "name": "Rolling Kick",
        "type": "fighting",
        "category": "physical",
        "power": 60,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "rollout": {
        "id": "rollout",
        "name": "Rollout",
        "type": "rock",
        "category": "physical",
        "power": 30,
        "accuracy": 90,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, the user is locked into this move and cannot make another move until it misses, 5 turns have passed, or the attack cannot be used. Power doubles with each successful hit of this move and doubles again if Defense Curl was used previously by the user. If this move is called by Sleep Talk, the move is used for one turn.",
        "shortDescription": "Power doubles with each hit. Repeats for 5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "failinstruct",
            "noparentalbond"
        ]
    },
    "roost": {
        "id": "roost",
        "name": "Roost",
        "type": "flying",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up. If the user is not Terastallized, until the end of the turn Flying-type users lose their Flying type and pure Flying-type users become Normal type. Does nothing if the user's HP is full.",
        "shortDescription": "Heals 50% HP. Flying-type removed 'til turn ends.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "selfVolatileStatus": "roost",
        "heal": [
            1,
            2
        ]
    },
    "rototiller": {
        "id": "rototiller",
        "name": "Rototiller",
        "type": "ground",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "Raises the Attack and Special Attack of all grounded Grass-type Pokemon on the field by 1 stage.",
        "shortDescription": "Raises Atk/Sp. Atk of grounded Grass types by 1.",
        "flags": [
            "distance",
            "nonsky",
            "metronome"
        ]
    },
    "round": {
        "id": "round",
        "name": "Round",
        "type": "normal",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If there are other active Pokemon that chose this move for use this turn, those Pokemon take their turn immediately after the user, in Speed order, and this move's power is 120 for each other user.",
        "shortDescription": "Power doubles if others used Round this turn.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ]
    },
    "sacredfire": {
        "id": "sacredfire",
        "name": "Sacred Fire",
        "type": "fire",
        "category": "physical",
        "power": 100,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to burn the target.",
        "shortDescription": "50% chance to burn the target. Thaws user.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "status": "brn"
            }
        ]
    },
    "sacredsword": {
        "id": "sacredsword",
        "name": "Sacred Sword",
        "type": "fighting",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Ignores the target's stat stage changes, including evasiveness.",
        "shortDescription": "Ignores the target's stat stage changes.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "ignoreEvasion": true
    },
    "safeguard": {
        "id": "safeguard",
        "name": "Safeguard",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 25,
        "priority": 0,
        "target": "allySide",
        "description": "For 5 turns, the user and its party members cannot have non-volatile status conditions or confusion inflicted on them by other Pokemon. Pokemon on the user's side cannot become affected by Yawn but can fall asleep from its effect. It is removed from the user's side if the user or an ally is successfully hit by Defog. Fails if the effect is already active on the user's side.",
        "shortDescription": "For 5 turns, protects user's party from status.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "sideCondition": "safeguard"
    },
    "saltcure": {
        "id": "saltcure",
        "name": "Salt Cure",
        "type": "rock",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes damage to the target equal to 1/8 of its maximum HP (1/4 if the target is Steel or Water type), rounded down, at the end of each turn during effect. This effect ends when the target is no longer active.",
        "shortDescription": "Deals 1/8 max HP each turn; 1/4 on Steel, Water.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "saltcure"
            }
        ]
    },
    "sandattack": {
        "id": "sandattack",
        "name": "Sand Attack",
        "type": "ground",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's accuracy by 1 stage.",
        "shortDescription": "Lowers the target's accuracy by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "accuracy": -1
        }
    },
    "sandsearstorm": {
        "id": "sandsearstorm",
        "name": "Sandsear Storm",
        "type": "ground",
        "category": "special",
        "power": 100,
        "accuracy": 80,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 20% chance to burn the target. If the weather is Primordial Sea or Rain Dance, this move does not check accuracy. If this move is used against a Pokemon holding Utility Umbrella, this move's accuracy remains at 80%.",
        "shortDescription": "20% chance to burn foe(s). Can't miss in rain.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "brn"
            }
        ]
    },
    "sandstorm": {
        "id": "sandstorm",
        "name": "Sandstorm",
        "type": "rock",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Sandstorm. At the end of each turn except the last, all active Pokemon lose 1/16 of their maximum HP, rounded down, unless they are a Ground, Rock, or Steel type, or have the Magic Guard, Overcoat, Sand Force, Sand Rush, or Sand Veil Abilities. During the effect, the Special Defense of Rock-type Pokemon is multiplied by 1.5 when taking damage from a special attack. Lasts for 8 turns if the user is holding Smooth Rock. Fails if the current weather is Sandstorm.",
        "shortDescription": "For 5 turns, a sandstorm rages. Rock: 1.5x SpD.",
        "flags": [
            "metronome",
            "wind"
        ],
        "weather": "sandstorm"
    },
    "sandtomb": {
        "id": "sandtomb",
        "name": "Sand Tomb",
        "type": "ground",
        "category": "physical",
        "power": 35,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "scald": {
        "id": "scald",
        "name": "Scald",
        "type": "water",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to burn the target. The target thaws out if it is frozen.",
        "shortDescription": "30% chance to burn the target. Thaws target.",
        "flags": [
            "protect",
            "mirror",
            "defrost",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "brn"
            }
        ]
    },
    "scaryface": {
        "id": "scaryface",
        "name": "Scary Face",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Speed by 2 stages.",
        "shortDescription": "Lowers the target's Speed by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "spe": -2
        }
    },
    "scratch": {
        "id": "scratch",
        "name": "Scratch",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "screech": {
        "id": "screech",
        "name": "Screech",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 85,
        "pp": 40,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Defense by 2 stages.",
        "shortDescription": "Lowers the target's Defense by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "def": -2
        }
    },
    "searingshot": {
        "id": "searingshot",
        "name": "Searing Shot",
        "type": "fire",
        "category": "special",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Has a 30% chance to burn the target.",
        "shortDescription": "30% chance to burn adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "brn"
            }
        ]
    },
    "secretpower": {
        "id": "secretpower",
        "name": "Secret Power",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to cause a secondary effect on the target based on the battle terrain. Causes paralysis on the regular Wi-Fi terrain, causes paralysis during Electric Terrain, lowers Special Attack by 1 stage during Misty Terrain, causes sleep during Grassy Terrain and lowers Speed by 1 stage during Psychic Terrain.",
        "shortDescription": "Effect varies with terrain. (30% paralysis chance)",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "secretsword": {
        "id": "secretsword",
        "name": "Secret Sword",
        "type": "fighting",
        "category": "special",
        "power": 85,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target based on its Defense instead of Special Defense.",
        "shortDescription": "Damages target based on Defense, not Sp. Def.",
        "flags": [
            "protect",
            "mirror",
            "slicing"
        ]
    },
    "seedbomb": {
        "id": "seedbomb",
        "name": "Seed Bomb",
        "type": "grass",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "seismictoss": {
        "id": "seismictoss",
        "name": "Seismic Toss",
        "type": "fighting",
        "category": "physical",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the user's level.",
        "shortDescription": "Does damage equal to the user's level.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "fixedDamage": "level"
    },
    "selfdestruct": {
        "id": "selfdestruct",
        "name": "Self-Destruct",
        "type": "normal",
        "category": "physical",
        "power": 200,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacent",
        "description": "The user faints after using this move, even if this move fails for having no target. This move is prevented from executing if any active Pokemon has the Damp Ability.",
        "shortDescription": "Hits adjacent Pokemon. The user faints.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "noparentalbond"
        ],
        "selfdestruct": true
    },
    "shadowball": {
        "id": "shadowball",
        "name": "Shadow Ball",
        "type": "ghost",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to lower the target's Special Defense by 1 stage.",
        "shortDescription": "20% chance to lower the target's Sp. Def by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 20,
                "boosts": {
                    "spd": -1
                }
            }
        ]
    },
    "shadowclaw": {
        "id": "shadowclaw",
        "name": "Shadow Claw",
        "type": "ghost",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "shadowforce": {
        "id": "shadowforce",
        "name": "Shadow Force",
        "type": "ghost",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it breaks through the target's Baneful Bunker, Detect, King's Shield, Protect, or Spiky Shield for this turn, allowing other Pokemon to attack the target normally. If the target's side is protected by Crafty Shield, Mat Block, Quick Guard, or Wide Guard, that protection is also broken for this turn and other Pokemon may attack the target's side normally. This attack charges on the first turn and executes on the second. On the first turn, the user avoids all attacks. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Disappears turn 1. Hits turn 2. Breaks protection.",
        "flags": [
            "contact",
            "charge",
            "mirror",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ],
        "breaksProtect": true
    },
    "shadowpunch": {
        "id": "shadowpunch",
        "name": "Shadow Punch",
        "type": "ghost",
        "category": "physical",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ]
    },
    "shadowsneak": {
        "id": "shadowsneak",
        "name": "Shadow Sneak",
        "type": "ghost",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "sharpen": {
        "id": "sharpen",
        "name": "Sharpen",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack by 1 stage.",
        "shortDescription": "Raises the user's Attack by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1
        }
    },
    "shedtail": {
        "id": "shedtail",
        "name": "Shed Tail",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user takes 1/2 of its maximum HP, rounded up, and creates a substitute that has 1/4 of the user's maximum HP, rounded down. The user is replaced with another Pokemon in its party and the selected Pokemon has the substitute transferred to it. Fails if the user would faint, or if there are no unfainted party members.",
        "shortDescription": "User takes 1/2 its max HP to pass a substitute.",
        "volatileStatus": "substitute",
        "selfSwitch": "shedtail"
    },
    "sheercold": {
        "id": "sheercold",
        "name": "Sheer Cold",
        "type": "ice",
        "category": "special",
        "power": 0,
        "accuracy": 30,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to the target's maximum HP. Ignores accuracy and evasiveness modifiers. This attack's accuracy is equal to (user's level - target's level + X)%, where X is 30 if the user is an Ice type and 20 otherwise, and fails if the target is at a higher level. Ice-type Pokemon and Pokemon with the Sturdy Ability are immune.",
        "shortDescription": "OHKOs non-Ice targets. Fails if user's lower level.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "ohko": true
    },
    "shellsmash": {
        "id": "shellsmash",
        "name": "Shell Smash",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "self",
        "description": "Lowers the user's Defense and Special Defense by 1 stage. Raises the user's Attack, Special Attack, and Speed by 2 stages.",
        "shortDescription": "Lowers Def, SpD by 1; raises Atk, SpA, Spe by 2.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": -1,
            "spd": -1,
            "atk": 2,
            "spa": 2,
            "spe": 2
        }
    },
    "shelltrap": {
        "id": "shelltrap",
        "name": "Shell Trap",
        "type": "fire",
        "category": "special",
        "power": 150,
        "accuracy": 100,
        "pp": 5,
        "priority": -3,
        "target": "allAdjacentFoes",
        "description": "Fails unless the user is hit by a physical attack from an opponent this turn before it can execute the move. If the user was hit and has not fainted, it attacks immediately after being hit, and the effect ends. If the opponent's physical attack had a secondary effect removed by the Sheer Force Ability, it does not count for the purposes of this effect.",
        "shortDescription": "User must take physical damage before moving.",
        "flags": [
            "protect",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failinstruct"
        ]
    },
    "shiftgear": {
        "id": "shiftgear",
        "name": "Shift Gear",
        "type": "steel",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Speed by 2 stages and its Attack by 1 stage.",
        "shortDescription": "Raises the user's Speed by 2 and Attack by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spe": 2,
            "atk": 1
        }
    },
    "shockwave": {
        "id": "shockwave",
        "name": "Shock Wave",
        "type": "electric",
        "category": "special",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "shoreup": {
        "id": "shoreup",
        "name": "Shore Up",
        "type": "ground",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half down. If the weather is Sandstorm, the user instead restores 2/3 of its maximum HP, rounded half down.",
        "shortDescription": "User restores 1/2 its max HP; 2/3 in Sandstorm.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "signalbeam": {
        "id": "signalbeam",
        "name": "Signal Beam",
        "type": "bug",
        "category": "special",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to confuse the target.",
        "shortDescription": "10% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "volatileStatus": "confusion"
            }
        ]
    },
    "silktrap": {
        "id": "silktrap",
        "name": "Silk Trap",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn, and Pokemon trying to make contact with the user have their Speed lowered by 1 stage. Non-damaging moves go through this protection. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Protects from damaging attacks. Contact: -1 Spe.",
        "volatileStatus": "silktrap"
    },
    "silverwind": {
        "id": "silverwind",
        "name": "Silver Wind",
        "type": "bug",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to raise the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage.",
        "shortDescription": "10% chance to raise all stats by 1 (not acc/eva).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "selfBoosts": {
                    "atk": 1,
                    "def": 1,
                    "spa": 1,
                    "spd": 1,
                    "spe": 1
                }
            }
        ]
    },
    "simplebeam": {
        "id": "simplebeam",
        "name": "Simple Beam",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's Ability to become Simple. Fails if the target's Ability is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Multitype, Power Construct, RKS System, Schooling, Shields Down, Simple, Stance Change, Tera Shift, Truant, Zen Mode, or Zero to Hero.",
        "shortDescription": "The target's Ability becomes Simple.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "sing": {
        "id": "sing",
        "name": "Sing",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 55,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "status": "slp"
    },
    "sketch": {
        "id": "sketch",
        "name": "Sketch",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 1,
        "priority": 0,
        "target": "normal",
        "description": "This move is permanently replaced by the last move used by the target. The copied move has the maximum PP for that move. Fails if the target has not made a move, if the user has Transformed, or if the move is Chatter, Sketch, Struggle, or any move the user knows.",
        "shortDescription": "Permanently copies the last move target used.",
        "flags": [
            "bypasssub",
            "allyanim",
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "skillswap": {
        "id": "skillswap",
        "name": "Skill Swap",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its Ability with the target's Ability. Fails if either the user or the target's Ability is As One, Battle Bond, Comatose, Commander, Disguise, Embody Aspect, Hunger Switch, Ice Face, Illusion, Multitype, Neutralizing Gas, Poison Puppeteer, Power Construct, Protosynthesis, Quark Drive, RKS System, Schooling, Shields Down, Stance Change, Tera Shell, Tera Shift, Teraform Zero, Wonder Guard, Zen Mode, or Zero to Hero.",
        "shortDescription": "The user and the target trade Abilities.",
        "flags": [
            "protect",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "skittersmack": {
        "id": "skittersmack",
        "name": "Skitter Smack",
        "type": "bug",
        "category": "physical",
        "power": 70,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "100% chance to lower target's Sp. Atk by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "skullbash": {
        "id": "skullbash",
        "name": "Skull Bash",
        "type": "normal",
        "category": "physical",
        "power": 130,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. Raises the user's Defense by 1 stage on the first turn. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Raises user's Defense by 1 on turn 1. Hits turn 2.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ]
    },
    "skyattack": {
        "id": "skyattack",
        "name": "Sky Attack",
        "type": "flying",
        "category": "physical",
        "power": 140,
        "accuracy": 90,
        "pp": 5,
        "priority": 0,
        "target": "any",
        "description": "Has a 30% chance to make the target flinch and a higher chance for a critical hit. This attack charges on the first turn and executes on the second. If the user is holding a Power Herb, the move completes in one turn.",
        "shortDescription": "Charges, then hits turn 2. 30% flinch. High crit.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "distance",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ],
        "critRatio": 2
    },
    "skydrop": {
        "id": "skydrop",
        "name": "Sky Drop",
        "type": "flying",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "any",
        "description": "This attack takes the target into the air with the user on the first turn and executes on the second. Pokemon weighing 200 kg or more cannot be lifted. On the first turn, the user and the target avoid all attacks other than Gust, Hurricane, Sky Uppercut, Smack Down, Thousand Arrows, Thunder, and Twister. The user and the target cannot make a move between turns, but the target can select a move to use. This move cannot damage Flying-type Pokemon. Fails on the first turn if the target is an ally, if the target has a substitute, or if the target is using Bounce, Dig, Dive, Fly, Phantom Force, Shadow Force, or Sky Drop.",
        "shortDescription": "User and foe fly up turn 1. Damages on turn 2.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "gravity",
            "distance",
            "metronome",
            "nosleeptalk",
            "noassist",
            "failinstruct"
        ]
    },
    "skyuppercut": {
        "id": "skyuppercut",
        "name": "Sky Uppercut",
        "type": "fighting",
        "category": "physical",
        "power": 85,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "This move can hit a target using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop.",
        "shortDescription": "Can hit Pokemon using Bounce, Fly, or Sky Drop.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ]
    },
    "slackoff": {
        "id": "slackoff",
        "name": "Slack Off",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user by 50% of its max HP.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "heal": [
            1,
            2
        ]
    },
    "slam": {
        "id": "slam",
        "name": "Slam",
        "type": "normal",
        "category": "physical",
        "power": 80,
        "accuracy": 75,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "slash": {
        "id": "slash",
        "name": "Slash",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ],
        "critRatio": 2
    },
    "sleeppowder": {
        "id": "sleeppowder",
        "name": "Sleep Powder",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 75,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome",
            "powder"
        ],
        "status": "slp"
    },
    "sleeptalk": {
        "id": "sleeptalk",
        "name": "Sleep Talk",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "One of the user's known moves, besides this move, is selected for use at random. Fails if the user is not asleep. The selected move does not have PP deducted from it, and can currently have 0 PP. This move cannot select Assist, Beak Blast, Belch, Bide, Blazing Torque, Celebrate, Chatter, Combat Torque, Copycat, Dynamax Cannon, Focus Punch, Hold Hands, Magical Torque, Me First, Metronome, Mimic, Mirror Move, Nature Power, Noxious Torque, Shell Trap, Sketch, Sleep Talk, Struggle, Uproar, Wicked Torque, or any two-turn move.",
        "shortDescription": "User must be asleep. Uses another known move.",
        "flags": [
            "failencore",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ],
        "sleepUsable": true
    },
    "sludge": {
        "id": "sludge",
        "name": "Sludge",
        "type": "poison",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to poison the target.",
        "shortDescription": "30% chance to poison the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "psn"
            }
        ]
    },
    "sludgebomb": {
        "id": "sludgebomb",
        "name": "Sludge Bomb",
        "type": "poison",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to poison the target.",
        "shortDescription": "30% chance to poison the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "psn"
            }
        ]
    },
    "sludgewave": {
        "id": "sludgewave",
        "name": "Sludge Wave",
        "type": "poison",
        "category": "special",
        "power": 95,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Has a 10% chance to poison the target.",
        "shortDescription": "10% chance to poison adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "psn"
            }
        ]
    },
    "smackdown": {
        "id": "smackdown",
        "name": "Smack Down",
        "type": "rock",
        "category": "physical",
        "power": 50,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "This move can hit a target using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop. If this move hits a target under the effect of Bounce, Fly, Magnet Rise, or Telekinesis, the effect ends. If the target is a Flying type that has not used Roost this turn or a Pokemon with the Levitate Ability, it loses its immunity to Ground-type attacks and the Arena Trap Ability as long as it remains active. During the effect, Magnet Rise fails for the target and Telekinesis fails against the target.",
        "shortDescription": "Removes the target's Ground immunity.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "volatileStatus": "smackdown"
    },
    "smartstrike": {
        "id": "smartstrike",
        "name": "Smart Strike",
        "type": "steel",
        "category": "physical",
        "power": 70,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "smellingsalts": {
        "id": "smellingsalts",
        "name": "Smelling Salts",
        "type": "normal",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target is paralyzed. If the user has not fainted, the target is cured of paralysis.",
        "shortDescription": "Power doubles if target is paralyzed, and cures it.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "smog": {
        "id": "smog",
        "name": "Smog",
        "type": "poison",
        "category": "special",
        "power": 30,
        "accuracy": 70,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 40% chance to poison the target.",
        "shortDescription": "40% chance to poison the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 40,
                "status": "psn"
            }
        ]
    },
    "smokescreen": {
        "id": "smokescreen",
        "name": "Smokescreen",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's accuracy by 1 stage.",
        "shortDescription": "Lowers the target's accuracy by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "accuracy": -1
        }
    },
    "snarl": {
        "id": "snarl",
        "name": "Snarl",
        "type": "dark",
        "category": "special",
        "power": 55,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "snatch": {
        "id": "snatch",
        "name": "Snatch",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "If another Pokemon uses certain non-damaging moves this turn, the user steals that move to use itself. If multiple Pokemon use one of those moves this turn, the applicable moves are all stolen by the first Pokemon in turn order that used this move this turn. This effect is ignored while the user is under the effect of Sky Drop.",
        "shortDescription": "User steals certain support moves to use itself.",
        "flags": [
            "bypasssub",
            "mustpressure",
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "snatch"
    },
    "snipeshot": {
        "id": "snipeshot",
        "name": "Snipe Shot",
        "type": "water",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit. This move cannot be redirected to a different target by any effect.",
        "shortDescription": "High critical hit ratio. Cannot be redirected.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "snore": {
        "id": "snore",
        "name": "Snore",
        "type": "normal",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch. Fails if the user is not asleep.",
        "shortDescription": "User must be asleep. 30% chance to flinch target.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ],
        "sleepUsable": true
    },
    "snowscape": {
        "id": "snowscape",
        "name": "Snowscape",
        "type": "ice",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Snow. During the effect, the Defense of Ice-type Pokemon is multiplied by 1.5 when taking damage from a physical attack. Lasts for 8 turns if the user is holding Icy Rock. Fails if the current weather is Snow.",
        "shortDescription": "For 5 turns, snow falls. Ice: 1.5x Def.",
        "weather": "snow"
    },
    "soak": {
        "id": "soak",
        "name": "Soak",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become a Water type. Fails if the target is an Arceus or a Silvally, if the target is already purely Water type, or if the target is Terastallized.",
        "shortDescription": "Changes the target's type to Water.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "softboiled": {
        "id": "softboiled",
        "name": "Soft-Boiled",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP, rounded half up.",
        "shortDescription": "Heals the user by 50% of its max HP.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ],
        "heal": [
            1,
            2
        ]
    },
    "solarbeam": {
        "id": "solarbeam",
        "name": "Solar Beam",
        "type": "grass",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. Power is halved if the weather is Primordial Sea, Rain Dance, Sandstorm, or Snow and the user is not holding Utility Umbrella. If the user is holding a Power Herb or the weather is Desolate Land or Sunny Day, the move completes in one turn. If the user is holding Utility Umbrella and the weather is Desolate Land or Sunny Day, the move still requires a turn to charge.",
        "shortDescription": "Charges turn 1. Hits turn 2. No charge in sunlight.",
        "flags": [
            "charge",
            "protect",
            "mirror",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ]
    },
    "solarblade": {
        "id": "solarblade",
        "name": "Solar Blade",
        "type": "grass",
        "category": "physical",
        "power": 125,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This attack charges on the first turn and executes on the second. Power is halved if the weather is Hail, Primordial Sea, Rain Dance, or Sandstorm and the user is not holding Utility Umbrella. If the user is holding a Power Herb or the weather is Desolate Land or Sunny Day, the move completes in one turn. If the user is holding Utility Umbrella and the weather is Desolate Land or Sunny Day, the move still requires a turn to charge.",
        "shortDescription": "Charges turn 1. Hits turn 2. No charge in sunlight.",
        "flags": [
            "contact",
            "charge",
            "protect",
            "mirror",
            "metronome",
            "nosleeptalk",
            "failinstruct",
            "slicing"
        ]
    },
    "sonicboom": {
        "id": "sonicboom",
        "name": "Sonic Boom",
        "type": "normal",
        "category": "special",
        "power": 0,
        "accuracy": 90,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Deals 20 HP of damage to the target.",
        "shortDescription": "Always does 20 HP of damage.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "fixedDamage": 20
    },
    "spacialrend": {
        "id": "spacialrend",
        "name": "Spacial Rend",
        "type": "dragon",
        "category": "special",
        "power": 100,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "spark": {
        "id": "spark",
        "name": "Spark",
        "type": "electric",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target.",
        "shortDescription": "30% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "sparklingaria": {
        "id": "sparklingaria",
        "name": "Sparkling Aria",
        "type": "water",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacent",
        "description": "If the user has not fainted, the target is cured of its burn.",
        "shortDescription": "The target is cured of its burn.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "sparklingaria"
            }
        ]
    },
    "speedswap": {
        "id": "speedswap",
        "name": "Speed Swap",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its Speed stat with the target. Stat stage changes are unaffected.",
        "shortDescription": "Swaps Speed stat with target.",
        "flags": [
            "protect",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome"
        ]
    },
    "spicyextract": {
        "id": "spicyextract",
        "name": "Spicy Extract",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Raises the target's Attack by 2 stages and lowers its Defense by 2 stages.",
        "shortDescription": "Raises target's Atk by 2 and lowers its Def by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror"
        ],
        "boosts": {
            "atk": 2,
            "def": -2
        }
    },
    "spiderweb": {
        "id": "spiderweb",
        "name": "Spider Web",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Prevents the target from switching out.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "trapTarget": true
    },
    "spikecannon": {
        "id": "spikecannon",
        "name": "Spike Cannon",
        "type": "normal",
        "category": "physical",
        "power": 20,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "spikes": {
        "id": "spikes",
        "name": "Spikes",
        "type": "ground",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "foeSide",
        "description": "Sets up a hazard on the opposing side of the field, damaging each opposing Pokemon that switches in, unless it is a Flying-type Pokemon or has the Levitate Ability. Can be used up to three times before failing. Opponents lose 1/8 of their maximum HP with one layer, 1/6 of their maximum HP with two layers, and 1/4 of their maximum HP with three layers, all rounded down. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, or is hit by Defog.",
        "shortDescription": "Hurts grounded foes on switch-in. Max 3 layers.",
        "flags": [
            "reflectable",
            "nonsky",
            "metronome",
            "mustpressure"
        ],
        "sideCondition": "spikes"
    },
    "spikyshield": {
        "id": "spikyshield",
        "name": "Spiky Shield",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 4,
        "target": "self",
        "description": "The user is protected from most attacks made by other Pokemon during this turn, and Pokemon making contact with the user lose 1/8 of their maximum HP, rounded down. This move has a 1/X chance of being successful, where X starts at 1 and triples each time this move is successfully used. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn.",
        "shortDescription": "Protects from moves. Contact: loses 1/8 max HP.",
        "flags": [
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "spikyshield"
    },
    "spinout": {
        "id": "spinout",
        "name": "Spin Out",
        "type": "steel",
        "category": "physical",
        "power": 100,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Speed by 2 stages.",
        "shortDescription": "Lowers the user's Speed by 2.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfBoosts": {
            "spe": -2
        }
    },
    "spiritbreak": {
        "id": "spiritbreak",
        "name": "Spirit Break",
        "type": "fairy",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "100% chance to lower the target's Sp. Atk by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "spiritshackle": {
        "id": "spiritshackle",
        "name": "Spirit Shackle",
        "type": "ghost",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching out. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Teleport, U-turn, or Volt Switch. If the target leaves the field using Baton Pass, the replacement will remain trapped. The effect ends if the user leaves the field.",
        "shortDescription": "Prevents the target from switching out.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "spite": {
        "id": "spite",
        "name": "Spite",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's last move used to lose 4 PP. Fails if the target has not made a move, if the move has 0 PP, or if it no longer knows the move.",
        "shortDescription": "Lowers the PP of the target's last move by 4.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ]
    },
    "spitup": {
        "id": "spitup",
        "name": "Spit Up",
        "type": "normal",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 100 times the user's Stockpile count. Fails if the user's Stockpile count is 0. Whether or not this move is successful, the user's Defense and Special Defense decrease by as many stages as Stockpile had increased them, and the user's Stockpile count resets to 0.",
        "shortDescription": "More power with more uses of Stockpile.",
        "flags": [
            "protect",
            "metronome"
        ]
    },
    "splash": {
        "id": "splash",
        "name": "Splash",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "self",
        "description": "No competitive use.",
        "shortDescription": "No competitive use.",
        "flags": [
            "gravity",
            "metronome"
        ]
    },
    "spore": {
        "id": "spore",
        "name": "Spore",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep.",
        "shortDescription": "Causes the target to fall asleep.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome",
            "powder"
        ],
        "status": "slp"
    },
    "spotlight": {
        "id": "spotlight",
        "name": "Spotlight",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 3,
        "target": "normal",
        "description": "Until the end of the turn, all single-target attacks from opponents of the target are redirected to the target. Such attacks are redirected to the target before they can be reflected by Magic Coat or the Magic Bounce Ability, or drawn in by the Lightning Rod or Storm Drain Abilities. Fails if it is not a Double Battle or Battle Royal.",
        "shortDescription": "Target's foes' moves are redirected to it this turn.",
        "flags": [
            "protect",
            "reflectable",
            "allyanim",
            "noassist",
            "failcopycat"
        ],
        "volatileStatus": "spotlight"
    },
    "springtidestorm": {
        "id": "springtidestorm",
        "name": "Springtide Storm",
        "type": "fairy",
        "category": "special",
        "power": 100,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 30% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "30% chance to lower the foe(s) Attack by 1.",
        "flags": [
            "protect",
            "mirror",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 30,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "stealthrock": {
        "id": "stealthrock",
        "name": "Stealth Rock",
        "type": "rock",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "foeSide",
        "description": "Sets up a hazard on the opposing side of the field, damaging each opposing Pokemon that switches in. Fails if the effect is already active on the opposing side. Foes lose 1/32, 1/16, 1/8, 1/4, or 1/2 of their maximum HP, rounded down, based on their weakness to the Rock type; 0.25x, 0.5x, neutral, 2x, or 4x, respectively. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, or is hit by Defog.",
        "shortDescription": "Hurts foes on switch-in. Factors Rock weakness.",
        "flags": [
            "reflectable",
            "metronome",
            "mustpressure"
        ],
        "sideCondition": "stealthrock"
    },
    "steamroller": {
        "id": "steamroller",
        "name": "Steamroller",
        "type": "bug",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "steelwing": {
        "id": "steelwing",
        "name": "Steel Wing",
        "type": "steel",
        "category": "physical",
        "power": 70,
        "accuracy": 90,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to raise the user's Defense by 1 stage.",
        "shortDescription": "10% chance to raise the user's Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "selfBoosts": {
                    "def": 1
                }
            }
        ]
    },
    "stickyweb": {
        "id": "stickyweb",
        "name": "Sticky Web",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "foeSide",
        "description": "Sets up a hazard on the opposing side of the field, lowering the Speed by 1 stage of each opposing Pokemon that switches in, unless it is a Flying-type Pokemon or has the Levitate Ability. Fails if the effect is already active on the opposing side. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, or is hit by Defog.",
        "shortDescription": "Lowers Speed of grounded foes by 1 on switch-in.",
        "flags": [
            "reflectable",
            "metronome"
        ],
        "sideCondition": "stickyweb"
    },
    "stockpile": {
        "id": "stockpile",
        "name": "Stockpile",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense and Special Defense by 1 stage. The user's Stockpile count increases by 1. Fails if the user's Stockpile count is 3. The user's Stockpile count is reset to 0 when it is no longer active.",
        "shortDescription": "Raises user's Defense, Sp. Def by 1. Max 3 uses.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "volatileStatus": "stockpile"
    },
    "stomp": {
        "id": "stomp",
        "name": "Stomp",
        "type": "normal",
        "category": "physical",
        "power": 65,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch. Damage doubles and no accuracy check is done if the target has used Minimize while active.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    },
    "stompingtantrum": {
        "id": "stompingtantrum",
        "name": "Stomping Tantrum",
        "type": "ground",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user's last move on the previous turn, including moves called by other moves or those used through Instruct, Magic Coat, Snatch, or the Dancer or Magic Bounce Abilities, failed to do any of its normal effects, not including damage from an unsuccessful High Jump Kick, Jump Kick, or Mind Blown, or if the user was prevented from moving by any effect other than recharging or Sky Drop. A move that was blocked by Baneful Bunker, Detect, King's Shield, Protect, Spiky Shield, Crafty Shield, Mat Block, Quick Guard, or Wide Guard will not double this move's power, nor will Bounce or Fly ending early due to the effect of Gravity, Smack Down, or Thousand Arrows.",
        "shortDescription": "Power doubles if the user's last move failed.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "stoneaxe": {
        "id": "stoneaxe",
        "name": "Stone Axe",
        "type": "rock",
        "category": "physical",
        "power": 65,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it sets up a hazard on the opposing side of the field, damaging each opposing Pokemon that switches in. Foes lose 1/32, 1/16, 1/8, 1/4, or 1/2 of their maximum HP, rounded down, based on their weakness to the Rock type; 0.25x, 0.5x, neutral, 2x, or 4x, respectively. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, or is hit by Defog.",
        "shortDescription": "Sets Stealth Rock on the target's side.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "stoneedge": {
        "id": "stoneedge",
        "name": "Stone Edge",
        "type": "rock",
        "category": "physical",
        "power": 100,
        "accuracy": 80,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a higher chance for a critical hit.",
        "shortDescription": "High critical hit ratio.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "critRatio": 2
    },
    "storedpower": {
        "id": "storedpower",
        "name": "Stored Power",
        "type": "psychic",
        "category": "special",
        "power": 20,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 20+(X*20), where X is the user's total stat stage changes that are greater than 0.",
        "shortDescription": " + 20 power for each of the user's stat boosts.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "stormthrow": {
        "id": "stormthrow",
        "name": "Storm Throw",
        "type": "fighting",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "This move is always a critical hit unless the target is under the effect of Lucky Chant or has the Battle Armor or Shell Armor Abilities.",
        "shortDescription": "Always results in a critical hit.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "willCrit": true
    },
    "strangesteam": {
        "id": "strangesteam",
        "name": "Strange Steam",
        "type": "fairy",
        "category": "special",
        "power": 90,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to confuse the target.",
        "shortDescription": "20% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "confusion"
            }
        ]
    },
    "strength": {
        "id": "strength",
        "name": "Strength",
        "type": "normal",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "strengthsap": {
        "id": "strengthsap",
        "name": "Strength Sap",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack by 1 stage. The user restores its HP equal to the target's Attack stat calculated with its stat stage before this move was used. If Big Root is held by the user, the HP recovered is 1.3x normal, rounded half down. Fails if the target's Attack stat stage is -6.",
        "shortDescription": "User heals HP=target's Atk stat. Lowers Atk by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "heal",
            "metronome"
        ]
    },
    "stringshot": {
        "id": "stringshot",
        "name": "String Shot",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 95,
        "pp": 40,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Speed by 2 stages.",
        "shortDescription": "Lowers the foe(s) Speed by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "spe": -2
        }
    },
    "struggle": {
        "id": "struggle",
        "name": "Struggle",
        "type": "normal",
        "category": "physical",
        "power": 50,
        "accuracy": 0,
        "pp": 1,
        "priority": 0,
        "target": "randomNormal",
        "description": "Deals typeless damage to a random opposing Pokemon. If this move was successful, the user loses 1/4 of its maximum HP, rounded half up, and the Rock Head Ability does not prevent this. This move is automatically used if none of the user's known moves can be selected.",
        "shortDescription": "User loses 1/4 of its max HP.",
        "flags": [
            "contact",
            "protect",
            "failencore",
            "failmefirst",
            "nosleeptalk",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "strugglebug": {
        "id": "strugglebug",
        "name": "Struggle Bug",
        "type": "bug",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 100% chance to lower the target's Special Attack by 1 stage.",
        "shortDescription": "100% chance to lower the foe(s) Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "spa": -1
                }
            }
        ]
    },
    "stuffcheeks": {
        "id": "stuffcheeks",
        "name": "Stuff Cheeks",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "This move cannot be selected unless the user is holding a Berry. The user eats its Berry and raises its Defense by 2 stages. This effect is not prevented by the Klutz or Unnerve Abilities, or the effects of Embargo or Magic Room. Fails if the user is not holding a Berry.",
        "shortDescription": "Must hold Berry to use. User eats Berry, Def +2.",
        "flags": [
            "snatch",
            "metronome"
        ]
    },
    "stunspore": {
        "id": "stunspore",
        "name": "Stun Spore",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 75,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Paralyzes the target.",
        "shortDescription": "Paralyzes the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome",
            "powder"
        ],
        "status": "par"
    },
    "submission": {
        "id": "submission",
        "name": "Submission",
        "type": "fighting",
        "category": "physical",
        "power": 80,
        "accuracy": 80,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 1/4 the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 1/4 recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            1,
            4
        ]
    },
    "substitute": {
        "id": "substitute",
        "name": "Substitute",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user takes 1/4 of its maximum HP, rounded down, and puts it into a substitute to take its place in battle. The substitute is removed once enough damage is inflicted on it, or if the user switches out or faints. Baton Pass can be used to transfer the substitute to an ally, and the substitute will keep its remaining HP. Until the substitute is broken, it receives damage from all attacks made by other Pokemon and shields the user from status effects and stat stage changes caused by other Pokemon. Sound-based moves and Pokemon with the Infiltrator Ability ignore substitutes. The user still takes normal damage from weather and status effects while behind its substitute. If the substitute breaks during a multi-hit attack, the user will take damage from any remaining hits. If a substitute is created while the user is trapped by a binding move, the binding effect ends immediately. Fails if the user does not have enough HP remaining to create a substitute without fainting, or if it already has a substitute.",
        "shortDescription": "User takes 1/4 its max HP to put in a substitute.",
        "flags": [
            "snatch",
            "nonsky",
            "metronome"
        ],
        "volatileStatus": "substitute"
    },
    "suckerpunch": {
        "id": "suckerpunch",
        "name": "Sucker Punch",
        "type": "dark",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 5,
        "priority": 1,
        "target": "normal",
        "description": "Fails if the target did not select a physical attack, special attack, or Me First for use this turn, or if the target moves before the user.",
        "shortDescription": "Usually goes first. Fails if target is not attacking.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "sunnyday": {
        "id": "sunnyday",
        "name": "Sunny Day",
        "type": "fire",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, the weather becomes Sunny Day. The damage of Fire-type attacks is multiplied by 1.5 and the damage of Water-type attacks is multiplied by 0.5 during the effect. Lasts for 8 turns if the user is holding Heat Rock. Fails if the current weather is Sunny Day.",
        "shortDescription": "For 5 turns, intense sunlight powers Fire moves.",
        "flags": [
            "metronome"
        ],
        "weather": "sunnyday"
    },
    "superfang": {
        "id": "superfang",
        "name": "Super Fang",
        "type": "normal",
        "category": "physical",
        "power": 0,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Deals damage to the target equal to half of its current HP, rounded down, but not less than 1 HP.",
        "shortDescription": "Does damage equal to 1/2 target's current HP.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "superpower": {
        "id": "superpower",
        "name": "Superpower",
        "type": "fighting",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Attack and Defense by 1 stage.",
        "shortDescription": "Lowers the user's Attack and Defense by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfBoosts": {
            "atk": -1,
            "def": -1
        }
    },
    "supersonic": {
        "id": "supersonic",
        "name": "Supersonic",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 55,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become confused.",
        "shortDescription": "Causes the target to become confused.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "confusion"
    },
    "surf": {
        "id": "surf",
        "name": "Surf",
        "type": "water",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Damage doubles if the target is using Dive.",
        "shortDescription": "Hits adjacent Pokemon. Double damage on Dive.",
        "flags": [
            "protect",
            "mirror",
            "nonsky",
            "metronome"
        ]
    },
    "surgingstrikes": {
        "id": "surgingstrikes",
        "name": "Surging Strikes",
        "type": "water",
        "category": "physical",
        "power": 25,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Hits three times. This move is always a critical hit unless the target is under the effect of Lucky Chant or has the Battle Armor or Shell Armor Abilities.",
        "shortDescription": "Always results in a critical hit. Hits 3 times.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch"
        ],
        "multihit": 3,
        "willCrit": true
    },
    "swagger": {
        "id": "swagger",
        "name": "Swagger",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Raises the target's Attack by 2 stages and confuses it.",
        "shortDescription": "Raises the target's Attack by 2 and confuses it.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "atk": 2
        },
        "volatileStatus": "confusion"
    },
    "swallow": {
        "id": "swallow",
        "name": "Swallow",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "The user restores its HP based on its Stockpile count. Restores 1/4 of its maximum HP if it's 1, 1/2 of its maximum HP if it's 2, both rounded half down, and all of its HP if it's 3. Fails if the user's Stockpile count is 0. The user's Defense and Special Defense decrease by as many stages as Stockpile had increased them, and the user's Stockpile count resets to 0.",
        "shortDescription": "Heals the user based on uses of Stockpile.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "sweetkiss": {
        "id": "sweetkiss",
        "name": "Sweet Kiss",
        "type": "fairy",
        "category": "status",
        "power": 0,
        "accuracy": 75,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to become confused.",
        "shortDescription": "Causes the target to become confused.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "confusion"
    },
    "sweetscent": {
        "id": "sweetscent",
        "name": "Sweet Scent",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's evasiveness by 2 stages.",
        "shortDescription": "Lowers the foe(s) evasiveness by 2.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "evasion": -2
        }
    },
    "swift": {
        "id": "swift",
        "name": "Swift",
        "type": "normal",
        "category": "special",
        "power": 60,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy. Hits foes.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "switcheroo": {
        "id": "switcheroo",
        "name": "Switcheroo",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its held item with the target's held item. Fails if either the user or the target is holding a Mail or Z-Crystal, if neither is holding an item, if the user is trying to give or take a Mega Stone to or from the species that can Mega Evolve with it, or if the user is trying to give or take a Blue Orb, a Red Orb, a Griseous Orb, a Plate, a Drive, or a Memory to or from a Kyogre, a Groudon, a Giratina, an Arceus, a Genesect, or a Silvally, respectively. The target is immune to this move if it has the Sticky Hold Ability.",
        "shortDescription": "User switches its held item with the target's.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "noassist",
            "failcopycat"
        ]
    },
    "swordsdance": {
        "id": "swordsdance",
        "name": "Swords Dance",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack by 2 stages.",
        "shortDescription": "Raises the user's Attack by 2.",
        "flags": [
            "snatch",
            "dance",
            "metronome"
        ],
        "boosts": {
            "atk": 2
        }
    },
    "synchronoise": {
        "id": "synchronoise",
        "name": "Synchronoise",
        "type": "psychic",
        "category": "special",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacent",
        "description": "The target is immune if it does not share a type with the user.",
        "shortDescription": "Hits adjacent Pokemon sharing the user's type.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "synthesis": {
        "id": "synthesis",
        "name": "Synthesis",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "self",
        "description": "The user restores 1/2 of its maximum HP if Delta Stream or no weather conditions are in effect or if the user is holding Utility Umbrella, 2/3 of its maximum HP if the weather is Desolate Land or Sunny Day, and 1/4 of its maximum HP if the weather is Primordial Sea, Rain Dance, Sandstorm, or Snow, all rounded half down.",
        "shortDescription": "Heals the user by a weather-dependent amount.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "syrupbomb": {
        "id": "syrupbomb",
        "name": "Syrup Bomb",
        "type": "grass",
        "category": "special",
        "power": 60,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful, it causes the target's Speed to be lowered by 1 stage at the end of each turn for 3 turns.",
        "shortDescription": "Target's Speed is lowered by 1 stage for 3 turns.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 100,
                "volatileStatus": "syrupbomb"
            }
        ]
    },
    "tackle": {
        "id": "tackle",
        "name": "Tackle",
        "type": "normal",
        "category": "physical",
        "power": 40,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "tailglow": {
        "id": "tailglow",
        "name": "Tail Glow",
        "type": "bug",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Special Attack by 3 stages.",
        "shortDescription": "Raises the user's Sp. Atk by 3.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "spa": 3
        }
    },
    "tailslap": {
        "id": "tailslap",
        "name": "Tail Slap",
        "type": "normal",
        "category": "physical",
        "power": 25,
        "accuracy": 85,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times.",
        "shortDescription": "Hits 2-5 times in one turn.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "tailwhip": {
        "id": "tailwhip",
        "name": "Tail Whip",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Defense by 1 stage.",
        "shortDescription": "Lowers the foe(s) Defense by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "def": -1
        }
    },
    "tailwind": {
        "id": "tailwind",
        "name": "Tailwind",
        "type": "flying",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "allySide",
        "description": "For 4 turns, the user and its party members have their Speed doubled. Fails if this move is already in effect for the user's side.",
        "shortDescription": "For 4 turns, allies' Speed is doubled.",
        "flags": [
            "snatch",
            "metronome",
            "wind"
        ],
        "sideCondition": "tailwind"
    },
    "takedown": {
        "id": "takedown",
        "name": "Take Down",
        "type": "normal",
        "category": "physical",
        "power": 90,
        "accuracy": 85,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 1/4 the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 1/4 recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            1,
            4
        ]
    },
    "tarshot": {
        "id": "tarshot",
        "name": "Tar Shot",
        "type": "rock",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Speed by 1 stage. Until the target switches out, the effectiveness of Fire-type moves is doubled against it.",
        "shortDescription": "Target gets -1 Spe and becomes weaker to Fire.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "spe": -1
        },
        "volatileStatus": "tarshot"
    },
    "taunt": {
        "id": "taunt",
        "name": "Taunt",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from using non-damaging moves for its next three turns. Pokemon with the Oblivious Ability or protected by the Aroma Veil Ability are immune.",
        "shortDescription": "Target can't use status moves its next 3 turns.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "taunt"
    },
    "tearfullook": {
        "id": "tearfullook",
        "name": "Tearful Look",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack and Special Attack by 1 stage.",
        "shortDescription": "Lowers the target's Attack and Sp. Atk by 1.",
        "flags": [
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "atk": -1,
            "spa": -1
        }
    },
    "teatime": {
        "id": "teatime",
        "name": "Teatime",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "All active Pokemon consume their held Berries. This effect is not prevented by substitutes, the Klutz or Unnerve Abilities, or the effects of Embargo or Magic Room. Fails if no active Pokemon is holding a Berry.",
        "shortDescription": "All active Pokemon consume held Berries.",
        "flags": [
            "bypasssub",
            "metronome"
        ]
    },
    "teeterdance": {
        "id": "teeterdance",
        "name": "Teeter Dance",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacent",
        "description": "Causes the target to become confused.",
        "shortDescription": "Confuses adjacent Pokemon.",
        "flags": [
            "protect",
            "mirror",
            "dance",
            "metronome"
        ],
        "volatileStatus": "confusion"
    },
    "teleport": {
        "id": "teleport",
        "name": "Teleport",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": -6,
        "target": "self",
        "description": "If this move is successful and the user has not fainted, the user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if there are no unfainted party members.",
        "shortDescription": "User switches out.",
        "flags": [
            "metronome"
        ],
        "selfSwitch": true
    },
    "terrainpulse": {
        "id": "terrainpulse",
        "name": "Terrain Pulse",
        "type": "normal",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the user is grounded and a terrain is active, and this move's type changes to match. Electric type during Electric Terrain, Grass type during Grassy Terrain, Fairy type during Misty Terrain, and Psychic type during Psychic Terrain.",
        "shortDescription": "User on terrain: power doubles, type varies.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "pulse"
        ]
    },
    "thief": {
        "id": "thief",
        "name": "Thief",
        "type": "dark",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "If this attack was successful and the user has not fainted, it steals the target's held item if the user is not holding one. The target's item is not stolen if it is a Mail or Z-Crystal, or if the target is a Kyogre holding a Blue Orb, a Groudon holding a Red Orb, a Giratina holding a Griseous Orb, an Arceus holding a Plate, a Genesect holding a Drive, a Silvally holding a Memory, or a Pokemon that can Mega Evolve holding the Mega Stone for its species. Items lost to this move cannot be regained with Recycle or the Harvest Ability.",
        "shortDescription": "If the user has no item, it steals the target's.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "failmefirst",
            "noassist",
            "failcopycat"
        ]
    },
    "thrash": {
        "id": "thrash",
        "name": "Thrash",
        "type": "normal",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "randomNormal",
        "description": "The user spends two or three turns locked into this move and becomes confused immediately after its move on the last turn of the effect if it is not already. This move targets an opposing Pokemon at random on each turn. If the user is prevented from moving, is asleep at the beginning of a turn, or the attack is not successful against the target on the first turn of the effect or the second turn of a three-turn effect, the effect ends without causing confusion. If this move is called by Sleep Talk and the user is asleep, the move is used for one turn and does not confuse the user.",
        "shortDescription": "Lasts 2-3 turns. Confuses the user afterwards.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "failinstruct"
        ],
        "selfVolatileStatus": "lockedmove"
    },
    "throatchop": {
        "id": "throatchop",
        "name": "Throat Chop",
        "type": "dark",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "For 2 turns, the target cannot use sound-based moves.",
        "shortDescription": "For 2 turns, the target cannot use sound moves.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "thunder": {
        "id": "thunder",
        "name": "Thunder",
        "type": "electric",
        "category": "special",
        "power": 110,
        "accuracy": 70,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to paralyze the target. This move can hit a target using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop. If the weather is Primordial Sea or Rain Dance, this move does not check accuracy. If the weather is Desolate Land or Sunny Day, this move's accuracy is 50%. If this move is used against a Pokemon holding Utility Umbrella, this move's accuracy remains at 70%.",
        "shortDescription": "30% chance to paralyze. Can't miss in rain.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "status": "par"
            }
        ]
    },
    "thunderbolt": {
        "id": "thunderbolt",
        "name": "Thunderbolt",
        "type": "electric",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to paralyze the target.",
        "shortDescription": "10% chance to paralyze the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "par"
            }
        ]
    },
    "thundercage": {
        "id": "thundercage",
        "name": "Thunder Cage",
        "type": "electric",
        "category": "special",
        "power": 80,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "protect",
            "mirror"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "thunderfang": {
        "id": "thunderfang",
        "name": "Thunder Fang",
        "type": "electric",
        "category": "physical",
        "power": 65,
        "accuracy": 95,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to paralyze the target and a 10% chance to make it flinch.",
        "shortDescription": "10% chance to paralyze. 10% chance to flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "bite"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "par"
            },
            {
                "chance": 10,
                "volatileStatus": "flinch"
            }
        ]
    },
    "thunderpunch": {
        "id": "thunderpunch",
        "name": "Thunder Punch",
        "type": "electric",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to paralyze the target.",
        "shortDescription": "10% chance to paralyze the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "par"
            }
        ]
    },
    "thundershock": {
        "id": "thundershock",
        "name": "Thunder Shock",
        "type": "electric",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "Has a 10% chance to paralyze the target.",
        "shortDescription": "10% chance to paralyze the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 10,
                "status": "par"
            }
        ]
    },
    "thunderwave": {
        "id": "thunderwave",
        "name": "Thunder Wave",
        "type": "electric",
        "category": "status",
        "power": 0,
        "accuracy": 90,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Paralyzes the target. This move does not ignore type immunity.",
        "shortDescription": "Paralyzes the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "par",
        "ignoreImmunity": false
    },
    "tickle": {
        "id": "tickle",
        "name": "Tickle",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Attack and Defense by 1 stage.",
        "shortDescription": "Lowers the target's Attack and Defense by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ],
        "boosts": {
            "atk": -1,
            "def": -1
        }
    },
    "tidyup": {
        "id": "tidyup",
        "name": "Tidy Up",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and Speed by 1 stage. Removes subtitutes from all active Pokemon and ends the effects of Spikes, Stealth Rock, Sticky Web, and Toxic Spikes for both sides.",
        "shortDescription": "User +1 Atk, Spe. Clears all substitutes/hazards."
    },
    "topsyturvy": {
        "id": "topsyturvy",
        "name": "Topsy-Turvy",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "The target's positive stat stages become negative and vice versa. Fails if all of the target's stat stages are 0.",
        "shortDescription": "Inverts the target's stat stages.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "torchsong": {
        "id": "torchsong",
        "name": "Torch Song",
        "type": "fire",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to raise the user's Special Attack by 1 stage.",
        "shortDescription": "100% chance to raise the user's Sp. Atk by 1.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "selfBoosts": {
                    "spa": 1
                }
            }
        ]
    },
    "torment": {
        "id": "torment",
        "name": "Torment",
        "type": "dark",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from selecting the same move for use two turns in a row. This effect ends when the target is no longer active.",
        "shortDescription": "Target can't select the same move twice in a row.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "bypasssub",
            "metronome"
        ],
        "volatileStatus": "torment"
    },
    "toxic": {
        "id": "toxic",
        "name": "Toxic",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Badly poisons the target. If a Poison-type Pokemon uses this move, the target cannot avoid the attack, even if the target is in the middle of a two-turn move.",
        "shortDescription": "Badly poisons the target. Poison types can't miss.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "tox"
    },
    "toxicspikes": {
        "id": "toxicspikes",
        "name": "Toxic Spikes",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": 0,
        "target": "foeSide",
        "description": "Sets up a hazard on the opposing side of the field, poisoning each opposing Pokemon that switches in, unless it is a Flying-type Pokemon or has the Levitate Ability. Can be used up to two times before failing. Opposing Pokemon become poisoned with one layer and badly poisoned with two layers. Can be removed from the opposing side if any opposing Pokemon uses Mortal Spin, Rapid Spin, or Defog successfully, is hit by Defog, or a grounded Poison-type Pokemon switches in. Safeguard prevents the opposing party from being poisoned on switch-in, but a substitute does not.",
        "shortDescription": "Poisons grounded foes on switch-in. Max 2 layers.",
        "flags": [
            "reflectable",
            "nonsky",
            "metronome",
            "mustpressure"
        ],
        "sideCondition": "toxicspikes"
    },
    "toxicthread": {
        "id": "toxicthread",
        "name": "Toxic Thread",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the target's Speed by 1 stage and poisons it.",
        "shortDescription": "Lowers the target's Speed by 1 and poisons it.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "boosts": {
            "spe": -1
        },
        "status": "psn"
    },
    "transform": {
        "id": "transform",
        "name": "Transform",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user transforms into the target. The target's current stats, stat stages, types, moves, Ability, weight, gender, and sprite are copied. The user's level and HP remain the same and each copied move receives only 5 PP, with a maximum of 5 PP each. The user can no longer change formes if it would have the ability to do so. This move fails if it hits a substitute, if either the user or the target is already transformed, or if either is behind an Illusion.",
        "shortDescription": "Copies target's stats, moves, types, and Ability.",
        "flags": [
            "allyanim",
            "failencore",
            "noassist",
            "failcopycat",
            "failmimic",
            "failinstruct"
        ]
    },
    "triattack": {
        "id": "triattack",
        "name": "Tri Attack",
        "type": "normal",
        "category": "special",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to either burn, freeze, or paralyze the target.",
        "shortDescription": "20% chance to paralyze or burn or freeze target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "trick": {
        "id": "trick",
        "name": "Trick",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "The user swaps its held item with the target's held item. Fails if either the user or the target is holding a Mail or Z-Crystal, if neither is holding an item, if the user is trying to give or take a Mega Stone to or from the species that can Mega Evolve with it, or if the user is trying to give or take a Blue Orb, a Red Orb, a Griseous Orb, a Plate, a Drive, or a Memory to or from a Kyogre, a Groudon, a Giratina, an Arceus, a Genesect, or a Silvally, respectively. The target is immune to this move if it has the Sticky Hold Ability.",
        "shortDescription": "User switches its held item with the target's.",
        "flags": [
            "protect",
            "mirror",
            "allyanim",
            "noassist",
            "failcopycat"
        ]
    },
    "trickortreat": {
        "id": "trickortreat",
        "name": "Trick-or-Treat",
        "type": "ghost",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Causes the Ghost type to be added to the target, effectively making it have two or three types. Fails if the target is already a Ghost type. If Forest's Curse adds a type to the target, it replaces the type added by this move and vice versa.",
        "shortDescription": "Adds Ghost to the target's type(s).",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "trickroom": {
        "id": "trickroom",
        "name": "Trick Room",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": -7,
        "target": "all",
        "description": "For 5 turns, the Speed of every Pokemon is recalculated for the purposes of determining turn order. During the effect, each Pokemon's Speed is considered to be (10000 - its normal Speed), and if this value is greater than 8191, 8192 is subtracted from it. If this move is used during the effect, the effect ends.",
        "shortDescription": "Goes last. For 5 turns, turn order is reversed.",
        "flags": [
            "mirror",
            "metronome"
        ],
        "pseudoWeather": "trickroom"
    },
    "triplearrows": {
        "id": "triplearrows",
        "name": "Triple Arrows",
        "type": "fighting",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 50% chance to lower the target's Defense by 1 stage, a 30% chance to make it flinch, and a higher chance for a critical hit.",
        "shortDescription": "High crit. Target: 50% -1 Defense, 30% flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 50,
                "boosts": {
                    "def": -1
                }
            },
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ],
        "critRatio": 2
    },
    "tripledive": {
        "id": "tripledive",
        "name": "Triple Dive",
        "type": "water",
        "category": "physical",
        "power": 30,
        "accuracy": 95,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits three times.",
        "shortDescription": "Hits 3 times.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 3
    },
    "triplekick": {
        "id": "triplekick",
        "name": "Triple Kick",
        "type": "fighting",
        "category": "physical",
        "power": 10,
        "accuracy": 90,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits three times. Power increases to 20 for the second hit and 30 for the third. This move checks accuracy for each hit, and the attack ends if the target avoids a hit. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit three times.",
        "shortDescription": "Hits 3 times. Each hit can miss, but power rises.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": 3
    },
    "tropkick": {
        "id": "tropkick",
        "name": "Trop Kick",
        "type": "grass",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to lower the target's Attack by 1 stage.",
        "shortDescription": "100% chance to lower the target's Attack by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 100,
                "boosts": {
                    "atk": -1
                }
            }
        ]
    },
    "trumpcard": {
        "id": "trumpcard",
        "name": "Trump Card",
        "type": "normal",
        "category": "special",
        "power": 0,
        "accuracy": 0,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "The power of this move is based on the amount of PP remaining after normal PP reduction and the Pressure Ability resolve. 200 power for 0 PP, 80 power for 1 PP, 60 power for 2 PP, 50 power for 3 PP, and 40 power for 4 or more PP.",
        "shortDescription": "More power the fewer PP this move has left.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "twinbeam": {
        "id": "twinbeam",
        "name": "Twin Beam",
        "type": "psychic",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times in one turn.",
        "flags": [
            "protect",
            "mirror"
        ],
        "multihit": 2
    },
    "twineedle": {
        "id": "twineedle",
        "name": "Twineedle",
        "type": "bug",
        "category": "physical",
        "power": 25,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Hits twice, with each hit having a 20% chance to poison the target. If the first hit breaks the target's substitute, it will take damage for the second hit.",
        "shortDescription": "Hits 2 times. Each hit has 20% chance to poison.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "psn"
            }
        ],
        "multihit": 2
    },
    "twister": {
        "id": "twister",
        "name": "Twister",
        "type": "dragon",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 20% chance to make the target flinch. Power doubles if the target is using Bounce, Fly, or Sky Drop, or is under the effect of Sky Drop.",
        "shortDescription": "20% chance to make the foe(s) flinch.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "flinch"
            }
        ]
    },
    "uproar": {
        "id": "uproar",
        "name": "Uproar",
        "type": "normal",
        "category": "special",
        "power": 90,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "randomNormal",
        "description": "The user spends three turns locked into this move. This move targets an opponent at random on each turn. On the first of the three turns, all sleeping active Pokemon wake up. During the three turns, no active Pokemon can fall asleep by any means, and Pokemon switched in during the effect do not wake up. If the user is prevented from moving or the attack is not successful against the target during one of the turns, the effect ends.",
        "shortDescription": "Lasts 3 turns. Active Pokemon cannot fall asleep.",
        "flags": [
            "protect",
            "mirror",
            "sound",
            "bypasssub",
            "metronome",
            "nosleeptalk",
            "failinstruct"
        ],
        "selfVolatileStatus": "uproar"
    },
    "uturn": {
        "id": "uturn",
        "name": "U-turn",
        "type": "bug",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful and the user has not fainted, the user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if there are no unfainted party members, or if the target switched out using an Eject Button or through the effect of the Emergency Exit or Wimp Out Abilities.",
        "shortDescription": "User switches out after damaging the target.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "selfSwitch": true
    },
    "vacuumwave": {
        "id": "vacuumwave",
        "name": "Vacuum Wave",
        "type": "fighting",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 30,
        "priority": 1,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "Usually goes first.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "vcreate": {
        "id": "vcreate",
        "name": "V-create",
        "type": "fire",
        "category": "physical",
        "power": 180,
        "accuracy": 95,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Lowers the user's Speed, Defense, and Special Defense by 1 stage.",
        "shortDescription": "Lowers the user's Defense, Sp. Def, Speed by 1.",
        "flags": [
            "contact",
            "protect",
            "mirror"
        ],
        "selfBoosts": {
            "spe": -1,
            "def": -1,
            "spd": -1
        }
    },
    "venomdrench": {
        "id": "venomdrench",
        "name": "Venom Drench",
        "type": "poison",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Lowers the target's Attack, Special Attack, and Speed by 1 stage if the target is poisoned. Fails if the target is not poisoned.",
        "shortDescription": "Lowers Atk/Sp. Atk/Speed of poisoned foes by 1.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ]
    },
    "venoshock": {
        "id": "venoshock",
        "name": "Venoshock",
        "type": "poison",
        "category": "special",
        "power": 65,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target is poisoned.",
        "shortDescription": "Power doubles if the target is poisoned.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "victorydance": {
        "id": "victorydance",
        "name": "Victory Dance",
        "type": "fighting",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack, Defense, and Speed by 1 stage.",
        "shortDescription": "Raises the user's Attack, Defense, Speed by 1.",
        "flags": [
            "snatch",
            "dance",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "def": 1,
            "spe": 1
        }
    },
    "vinewhip": {
        "id": "vinewhip",
        "name": "Vine Whip",
        "type": "grass",
        "category": "physical",
        "power": 45,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "visegrip": {
        "id": "visegrip",
        "name": "Vise Grip",
        "type": "normal",
        "category": "physical",
        "power": 55,
        "accuracy": 100,
        "pp": 30,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "vitalthrow": {
        "id": "vitalthrow",
        "name": "Vital Throw",
        "type": "fighting",
        "category": "physical",
        "power": 70,
        "accuracy": 0,
        "pp": 10,
        "priority": -1,
        "target": "normal",
        "description": "This move does not check accuracy.",
        "shortDescription": "This move does not check accuracy. Goes last.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "voltswitch": {
        "id": "voltswitch",
        "name": "Volt Switch",
        "type": "electric",
        "category": "special",
        "power": 70,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "If this move is successful and the user has not fainted, the user switches out even if it is trapped and is replaced immediately by a selected party member. The user does not switch out if there are no unfainted party members, or if the target switched out using an Eject Button or through the effect of the Emergency Exit or Wimp Out Abilities.",
        "shortDescription": "User switches out after damaging the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "selfSwitch": true
    },
    "wakeupslap": {
        "id": "wakeupslap",
        "name": "Wake-Up Slap",
        "type": "fighting",
        "category": "physical",
        "power": 70,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if the target is asleep. If the user has not fainted, the target wakes up.",
        "shortDescription": "Power doubles if target is asleep, and wakes it.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "waterfall": {
        "id": "waterfall",
        "name": "Waterfall",
        "type": "water",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to make the target flinch.",
        "shortDescription": "20% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "flinch"
            }
        ]
    },
    "watergun": {
        "id": "watergun",
        "name": "Water Gun",
        "type": "water",
        "category": "special",
        "power": 40,
        "accuracy": 100,
        "pp": 25,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "waterpulse": {
        "id": "waterpulse",
        "name": "Water Pulse",
        "type": "water",
        "category": "special",
        "power": 60,
        "accuracy": 100,
        "pp": 20,
        "priority": 0,
        "target": "any",
        "description": "Has a 20% chance to confuse the target.",
        "shortDescription": "20% chance to confuse the target.",
        "flags": [
            "protect",
            "mirror",
            "distance",
            "metronome",
            "pulse"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "confusion"
            }
        ]
    },
    "watershuriken": {
        "id": "watershuriken",
        "name": "Water Shuriken",
        "type": "water",
        "category": "special",
        "power": 15,
        "accuracy": 100,
        "pp": 20,
        "priority": 1,
        "target": "normal",
        "description": "Hits two to five times. Has a 35% chance to hit two or three times and a 15% chance to hit four or five times. If one of the hits breaks the target's substitute, it will take damage for the remaining hits. If the user has the Skill Link Ability, this move will always hit five times. If the user is an Ash-Greninja with the Battle Bond Ability, this move has a power of 20 and always hits three times.",
        "shortDescription": "Usually goes first. Hits 2-5 times in one turn.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "multihit": [
            2,
            5
        ]
    },
    "watersport": {
        "id": "watersport",
        "name": "Water Sport",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 15,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, all Fire-type attacks used by any active Pokemon have their power multiplied by 0.33. Fails if this effect is already active.",
        "shortDescription": "For 5 turns, Fire-type attacks have 1/3 power.",
        "flags": [
            "nonsky",
            "metronome"
        ],
        "pseudoWeather": "watersport"
    },
    "waterspout": {
        "id": "waterspout",
        "name": "Water Spout",
        "type": "water",
        "category": "special",
        "power": 150,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Power is equal to (user's current HP * 150 / user's maximum HP), rounded down, but not less than 1.",
        "shortDescription": "Less power as user's HP decreases. Hits foe(s).",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "wavecrash": {
        "id": "wavecrash",
        "name": "Wave Crash",
        "type": "water",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 33% the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 33% recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            33,
            100
        ]
    },
    "weatherball": {
        "id": "weatherball",
        "name": "Weather Ball",
        "type": "normal",
        "category": "special",
        "power": 50,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Power doubles if a weather condition other than Delta Stream is active, and this move's type changes to match. Ice type during Snow, Water type during Primordial Sea or Rain Dance, Rock type during Sandstorm, and Fire type during Desolate Land or Sunny Day. If the user is holding Utility Umbrella and uses Weather Ball during Primordial Sea, Rain Dance, Desolate Land, or Sunny Day, this move remains Normal type and does not double in power.",
        "shortDescription": "Power doubles and type varies in each weather.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ]
    },
    "whirlpool": {
        "id": "whirlpool",
        "name": "Whirlpool",
        "type": "water",
        "category": "special",
        "power": 35,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "whirlwind": {
        "id": "whirlwind",
        "name": "Whirlwind",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 20,
        "priority": -6,
        "target": "normal",
        "description": "The target is forced to switch out and be replaced with a random unfainted ally. Fails if the target is the last unfainted Pokemon in its party, or if the target used Ingrain previously or has the Suction Cups Ability.",
        "shortDescription": "Forces the target to switch to a random ally.",
        "flags": [
            "reflectable",
            "mirror",
            "bypasssub",
            "allyanim",
            "metronome",
            "noassist",
            "failcopycat",
            "wind"
        ],
        "forceSwitch": true
    },
    "wickedblow": {
        "id": "wickedblow",
        "name": "Wicked Blow",
        "type": "dark",
        "category": "physical",
        "power": 75,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "This move is always a critical hit unless the target is under the effect of Lucky Chant or has the Battle Armor or Shell Armor Abilities.",
        "shortDescription": "Always results in a critical hit.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "punch"
        ],
        "willCrit": true
    },
    "wideguard": {
        "id": "wideguard",
        "name": "Wide Guard",
        "type": "rock",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 3,
        "target": "allySide",
        "description": "The user and its party members are protected from moves made by other Pokemon, including allies, during this turn that target all adjacent foes or all adjacent Pokemon. This move modifies the same 1/X chance of being successful used by other protection moves, where X starts at 1 and triples each time this move is successfully used, but does not use the chance to check for failure. X resets to 1 if this move fails, if the user's last move used is not Baneful Bunker, Burning Bulwark, Detect, Endure, King's Shield, Max Guard, Obstruct, Protect, Quick Guard, Silk Trap, Spiky Shield, or Wide Guard, or if it was one of those moves and the user's protection was broken. Fails if the user moves last this turn or if this move is already in effect for the user's side.",
        "shortDescription": "Protects allies from multi-target moves this turn.",
        "flags": [
            "snatch"
        ],
        "sideCondition": "wideguard"
    },
    "wildboltstorm": {
        "id": "wildboltstorm",
        "name": "Wildbolt Storm",
        "type": "electric",
        "category": "special",
        "power": 100,
        "accuracy": 80,
        "pp": 10,
        "priority": 0,
        "target": "allAdjacentFoes",
        "description": "Has a 20% chance to paralyze the target. If the weather is Primordial Sea or Rain Dance, this move does not check accuracy. If this move is used against a Pokemon holding Utility Umbrella, this move's accuracy remains at 80%.",
        "shortDescription": "20% chance to paralyze foe(s). Rain: can't miss.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "wind"
        ],
        "secondaries": [
            {
                "chance": 20,
                "status": "par"
            }
        ]
    },
    "wildcharge": {
        "id": "wildcharge",
        "name": "Wild Charge",
        "type": "electric",
        "category": "physical",
        "power": 90,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 1/4 the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 1/4 recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            1,
            4
        ]
    },
    "willowisp": {
        "id": "willowisp",
        "name": "Will-O-Wisp",
        "type": "fire",
        "category": "status",
        "power": 0,
        "accuracy": 85,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Burns the target.",
        "shortDescription": "Burns the target.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "status": "brn"
    },
    "wingattack": {
        "id": "wingattack",
        "name": "Wing Attack",
        "type": "flying",
        "category": "physical",
        "power": 60,
        "accuracy": 100,
        "pp": 35,
        "priority": 0,
        "target": "any",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "distance",
            "metronome"
        ]
    },
    "wish": {
        "id": "wish",
        "name": "Wish",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "self",
        "description": "At the end of the next turn, the Pokemon at the user's position has 1/2 of the user's maximum HP restored to it, rounded down. Fails if this move is already in effect for the user's position.",
        "shortDescription": "Next turn, 50% of the user's max HP is restored.",
        "flags": [
            "snatch",
            "heal",
            "metronome"
        ]
    },
    "withdraw": {
        "id": "withdraw",
        "name": "Withdraw",
        "type": "water",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 40,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Defense by 1 stage.",
        "shortDescription": "Raises the user's Defense by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "def": 1
        }
    },
    "wonderroom": {
        "id": "wonderroom",
        "name": "Wonder Room",
        "type": "psychic",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "all",
        "description": "For 5 turns, all active Pokemon have their Defense and Special Defense stats swapped. Stat stage changes are unaffected. If this move is used during the effect, the effect ends.",
        "shortDescription": "For 5 turns, all Defense and Sp. Def stats switch.",
        "flags": [
            "mirror",
            "metronome"
        ],
        "pseudoWeather": "wonderroom"
    },
    "woodhammer": {
        "id": "woodhammer",
        "name": "Wood Hammer",
        "type": "grass",
        "category": "physical",
        "power": 120,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "If the target lost HP, the user takes recoil damage equal to 33% the HP lost by the target, rounded half up, but not less than 1 HP.",
        "shortDescription": "Has 33% recoil.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "recoil": [
            33,
            100
        ]
    },
    "workup": {
        "id": "workup",
        "name": "Work Up",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 30,
        "priority": 0,
        "target": "self",
        "description": "Raises the user's Attack and Special Attack by 1 stage.",
        "shortDescription": "Raises the user's Attack and Sp. Atk by 1.",
        "flags": [
            "snatch",
            "metronome"
        ],
        "boosts": {
            "atk": 1,
            "spa": 1
        }
    },
    "worryseed": {
        "id": "worryseed",
        "name": "Worry Seed",
        "type": "grass",
        "category": "status",
        "power": 0,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target's Ability to become Insomnia. Fails if the target's Ability is As One, Battle Bond, Comatose, Disguise, Gulp Missile, Ice Face, Insomnia, Multitype, Power Construct, RKS System, Schooling, Shields Down, Stance Change, Tera Shift, Truant, Zen Mode, or Zero to Hero.",
        "shortDescription": "The target's Ability becomes Insomnia.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "allyanim",
            "metronome"
        ]
    },
    "wrap": {
        "id": "wrap",
        "name": "Wrap",
        "type": "normal",
        "category": "physical",
        "power": 15,
        "accuracy": 90,
        "pp": 20,
        "priority": 0,
        "target": "normal",
        "description": "Prevents the target from switching for four or five turns (seven turns if the user is holding Grip Claw). Causes damage to the target equal to 1/8 of its maximum HP (1/6 if the user is holding Binding Band), rounded down, at the end of each turn during effect. The target can still switch out if it is holding Shed Shell or uses Baton Pass, Flip Turn, Parting Shot, Shed Tail, Teleport, U-turn, or Volt Switch. The effect ends if either the user or the target leaves the field, or if the target uses Mortal Spin, Rapid Spin, or Substitute successfully. This effect is not stackable or reset by using this or another binding move.",
        "shortDescription": "Traps and damages the target for 4-5 turns.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "partiallytrapped"
    },
    "wringout": {
        "id": "wringout",
        "name": "Wring Out",
        "type": "normal",
        "category": "special",
        "power": 0,
        "accuracy": 100,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Power is equal to 120 * (target's current HP / target's maximum HP), rounded half down, but not less than 1.",
        "shortDescription": "More power the more HP the target has left.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ]
    },
    "xscissor": {
        "id": "xscissor",
        "name": "X-Scissor",
        "type": "bug",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "No additional effect.",
        "shortDescription": "No additional effect.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome",
            "slicing"
        ]
    },
    "yawn": {
        "id": "yawn",
        "name": "Yawn",
        "type": "normal",
        "category": "status",
        "power": 0,
        "accuracy": 0,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Causes the target to fall asleep at the end of the next turn. Fails when used if the target cannot fall asleep or if it already has a non-volatile status condition. At the end of the next turn, if the target is still active, does not have a non-volatile status condition, and can fall asleep, it falls asleep. If the target becomes affected, this effect cannot be prevented by Safeguard or a substitute, or by falling asleep and waking up during the effect.",
        "shortDescription": "Puts the target to sleep after 1 turn.",
        "flags": [
            "protect",
            "reflectable",
            "mirror",
            "metronome"
        ],
        "volatileStatus": "yawn"
    },
    "zapcannon": {
        "id": "zapcannon",
        "name": "Zap Cannon",
        "type": "electric",
        "category": "special",
        "power": 120,
        "accuracy": 50,
        "pp": 5,
        "priority": 0,
        "target": "normal",
        "description": "Has a 100% chance to paralyze the target.",
        "shortDescription": "100% chance to paralyze the target.",
        "flags": [
            "protect",
            "mirror",
            "metronome",
            "bullet"
        ],
        "secondaries": [
            {
                "chance": 100,
                "status": "par"
            }
        ]
    },
    "zenheadbutt": {
        "id": "zenheadbutt",
        "name": "Zen Headbutt",
        "type": "psychic",
        "category": "physical",
        "power": 80,
        "accuracy": 90,
        "pp": 15,
        "priority": 0,
        "target": "normal",
        "description": "Has a 20% chance to make the target flinch.",
        "shortDescription": "20% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 20,
                "volatileStatus": "flinch"
            }
        ]
    },
    "zingzap": {
        "id": "zingzap",
        "name": "Zing Zap",
        "type": "electric",
        "category": "physical",
        "power": 80,
        "accuracy": 100,
        "pp": 10,
        "priority": 0,
        "target": "normal",
        "description": "Has a 30% chance to make the target flinch.",
        "shortDescription": "30% chance to make the target flinch.",
        "flags": [
            "contact",
            "protect",
            "mirror",
            "metronome"
        ],
        "secondaries": [
            {
                "chance": 30,
                "volatileStatus": "flinch"
            }
        ]
    }
});

export function normalizeMoveId(moveId) {
    return String(moveId || "").replace(/^cobblemon:/, "").toLowerCase();
}

export function moveData(moveId) {
    return MOVE_DATA[normalizeMoveId(moveId)] || MOVE_DATA.struggle;
}

export function moveEffectChance(moveId) {
    const move = moveData(moveId);
    const chances = Array.isArray(move.secondaries)
        ? move.secondaries.map(effect => Number(effect.chance) || 0)
        : [];
    return chances.length ? Math.max(...chances) : 0;
}
