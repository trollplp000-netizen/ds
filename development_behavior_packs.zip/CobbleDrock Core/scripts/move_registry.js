import { ScriptEventSource, system } from "@minecraft/server";
import { MOVE_DATA as CORE_MOVE_DATA, normalizeMoveId } from "./battle_moves.js";

export { normalizeMoveId };
export const MOVE_DATA = { ...CORE_MOVE_DATA };
export const MOVE_REGISTER_REQUEST_EVENT = "lota:server_move_register_v1";
export const MOVE_REGISTER_RESULT_EVENT = "lota:server_move_register_result_v1";

const providers = new Map();
const chunks = new Map();
const MAX_EXTERNAL_MOVES = 512;
const TYPES = new Set(["normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison", "ground",
    "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy", "typeless"]);

function validKey(value) {
    return typeof value === "string" && value.length <= 64 && /^[a-z0-9][a-z0-9_.-]*$/.test(value)
        && !["__proto__", "constructor", "prototype"].includes(value);
}

function freezeJson(value, depth = 0) {
    if (depth > 6) throw new Error("move_data_depth");
    if (value === null || typeof value !== "object") return value;
    for (const key of Object.keys(value)) {
        if (["__proto__", "constructor", "prototype"].includes(key)) throw new Error("move_data_key");
        freezeJson(value[key], depth + 1);
    }
    return Object.freeze(value);
}

export function registerExternalMove(request) {
    if (Number(request?.version) !== 1) return { outcome: "rejected", reason: "unsupported_version" };
    const { addonId, move, data } = request;
    if (!validKey(addonId) || !validKey(move)) return { outcome: "rejected", reason: "invalid_identity" };
    if (Object.prototype.hasOwnProperty.call(CORE_MOVE_DATA, move)) return { outcome: "rejected", reason: "core_move" };
    const existing = providers.get(move);
    if (existing && existing !== addonId) return { outcome: "rejected", reason: "move_conflict" };
    if (!existing && providers.size >= MAX_EXTERNAL_MOVES) return { outcome: "rejected", reason: "registry_full" };
    if (!data || typeof data !== "object" || Array.isArray(data) || data.id !== move || !TYPES.has(data.type)
        || !["physical", "special", "status"].includes(data.category) || typeof data.name !== "string"
        || data.name.length > 80 || !Number.isFinite(data.power) || data.power < 0 || data.power > 1000
        || !Number.isFinite(data.accuracy) || data.accuracy < 0 || data.accuracy > 100
        || !Number.isInteger(data.pp) || data.pp < 1 || data.pp > 64
        || !Number.isInteger(data.priority) || data.priority < -7 || data.priority > 7) {
        return { outcome: "rejected", reason: "invalid_move_data" };
    }
    let validated;
    try {
        const serialized = JSON.stringify(data);
        if (serialized.length > 16000) return { outcome: "rejected", reason: "move_data_size" };
        validated = freezeJson(JSON.parse(serialized));
    } catch (error) {
        return { outcome: "rejected", reason: "invalid_move_data" };
    }
    MOVE_DATA[move] = validated;
    providers.set(move, addonId);
    return { outcome: "registered", reason: "", move };
}

export function moveData(moveId) {
    return MOVE_DATA[normalizeMoveId(moveId)] || MOVE_DATA.struggle;
}

export function moveEffectChance(moveId) {
    const move = moveData(moveId);
    const chances = Array.isArray(move.secondaries) ? move.secondaries.map(effect => Number(effect.chance) || 0) : [];
    return chances.length ? Math.max(...chances) : 0;
}

function handleRequest(request) {
    const result = registerExternalMove(request);
    try {
        system.sendScriptEvent(MOVE_REGISTER_RESULT_EVENT, JSON.stringify({
            version: 1, addonId: String(request?.addonId || "").slice(0, 64),
            move: String(request?.move || "").slice(0, 64), ...result
        }));
    } catch (error) {
        console.warn(`[MoveRegistry] Registration result failed: ${error}`);
    }
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== MOVE_REGISTER_REQUEST_EVENT || event.sourceType !== ScriptEventSource.Server) return;
    let request;
    try { request = JSON.parse(String(event.message || "")); } catch (error) { return; }
    if (request?.transport !== "chunk") {
        system.run(() => handleRequest(request));
        return;
    }
    for (const [key, pending] of chunks) {
        if (system.currentTick - pending.tick > 200) chunks.delete(key);
    }
    if (!validKey(request.addonId) || !validKey(request.move) || !Number.isInteger(request.total)
        || request.total < 1 || request.total > 32 || !Number.isInteger(request.index)
        || request.index < 0 || request.index >= request.total || typeof request.chunk !== "string"
        || request.chunk.length > 600) return;
    const key = `${request.addonId}:${request.move}`;
    if (!chunks.has(key) && chunks.size >= 64) return;
    const pending = chunks.get(key) || { tick: system.currentTick, total: request.total, parts: new Map() };
    if (pending.total !== request.total) { chunks.delete(key); return; }
    pending.parts.set(request.index, request.chunk);
    chunks.set(key, pending);
    if (pending.parts.size !== pending.total) return;
    chunks.delete(key);
    let assembled;
    try {
        assembled = JSON.parse(Array.from({ length: pending.total }, (_, index) => pending.parts.get(index)).join(""));
    } catch (error) { return; }
    if (assembled.addonId !== request.addonId || assembled.move !== request.move) return;
    system.run(() => handleRequest(assembled));
});
