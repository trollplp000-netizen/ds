export const TICKS_PER_MINUTE = 1200;

export const BERRY_MAX_STAGE = 5;
export const MINT_MAX_STAGE = 7;
export const HARVEST_RESET_STAGE = 3;
export const MINT_LIGHT_THRESHOLD = 9;
export const MINT_GROWTH_CHANCE = 1 / 8;
export const BASE_MUTATION_CHANCE = 125 / 1000;
export const SURPRISE_MUTATION_CHANCE = BASE_MUTATION_CHANCE * 4;

export const GROWTH_TIME_MULTIPLIER = 1.4;

export const HORIZONTAL_OFFSETS = [
  { x: 0, z: -1 },
  { x: 0, z: 1 },
  { x: -1, z: 0 },
  { x: 1, z: 0 }
];

export const BERRY_PLANT_SOIL = ['minecraft:farmland'];
export const BERRY_WILD_SOIL = [
  'minecraft:dirt', 'minecraft:grass_block', 'minecraft:podzol', 'minecraft:coarse_dirt',
  'minecraft:dirt_with_roots', 'minecraft:mycelium', 'minecraft:moss_block', 'minecraft:mud',
  'minecraft:muddy_mangrove_roots', 'minecraft:grass_path',
  'minecraft:sand', 'minecraft:red_sand', 'minecraft:hardened_clay', 'minecraft:snow'
];

export const MINT_WILD_SOIL = BERRY_WILD_SOIL.filter(b => !b.endsWith('sand') && b !== 'minecraft:hardened_clay' && b !== 'minecraft:snow');
export const MINT_PLANT_SOIL = ['minecraft:farmland'];

export function canBeMulched(stage, currentMulch) {
  return currentMulch === 'none' && stage < 4;
}

function randomIntInRange(min, max, rng) {
  const lo = Math.floor(Math.min(min, max));
  const hi = Math.floor(Math.max(min, max));
  return lo + Math.floor(rng() * (hi - lo + 1));
}

function jittered(value, rng) {
  return Math.max(1, Math.round(value * (0.8 + rng() * 0.2)));
}

function phaseRange(berry, stage) {
  return stage < HARVEST_RESET_STAGE
    ? [berry.growthMinutesMin, berry.growthMinutesMax]
    : [berry.refreshMinutesMin, berry.refreshMinutesMax];
}

export function stagesLeftInPhase(stage) {
  return stage < HARVEST_RESET_STAGE ? HARVEST_RESET_STAGE - stage : BERRY_MAX_STAGE - stage;
}

export function createGrowthPool(berry, stage, mulchType, rng = Math.random) {
  const [min, max] = phaseRange(berry, stage);
  const stagesLeft = stagesLeftInPhase(stage);
  if (stagesLeft <= 0) {
    return { pool: 0, stagesLeft: 0, stageTimer: 0, mulchDurationDelta: 0 };
  }
  let pool = randomIntInRange(min, max, rng) * GROWTH_TIME_MULTIPLIER;
  let mulchDurationDelta = 0;
  if (mulchType === 'growth') {
    pool *= 0.5;
    mulchDurationDelta = -1;
  }
  const stageTimer = jittered(pool / stagesLeft, rng);
  return {
    pool: Math.max(0, pool - stageTimer),
    stagesLeft,
    stageTimer,
    mulchDurationDelta
  };
}

export function nextStageTimerFromPool(pool, stagesLeft, rng = Math.random) {
  if (stagesLeft <= 0 || pool <= 0) return 1;
  return jittered(pool / stagesLeft, rng);
}

export function refreshTimersWithGrowthMulch(cropData) {
  return {
    ...cropData,
    pool: cropData.pool * 0.5,
    stageTimer: Math.max(1, Math.round(cropData.stageTimer * 0.5))
  };
}

export function growthFactorBonus(berry, mulchType, biomeMatches, rng = Math.random) {
  const favoriteMulch = (berry.favoriteMulches || []).includes(String(mulchType || 'none'));
  if (!favoriteMulch && !biomeMatches) return 0;
  let bonus = 0;
  for (const factor of berry.growthFactors || []) {
    if (factor?.variant !== 'cobblemon:preferred_biome') continue;
    const min = Number(factor?.bonusYield?.min) || 0;
    const max = Math.max(min, Number(factor?.bonusYield?.max) || 0);
    bonus += randomIntInRange(min, max, rng);
  }
  return bonus;
}

export function calculateYield(berry, mulchType, biomeMatches, rng = Math.random) {
  let yieldCount = randomIntInRange(berry.baseYieldMin, berry.baseYieldMax, rng);
  yieldCount += growthFactorBonus(berry, mulchType, biomeMatches, rng);
  let mulchDurationDelta = 0;
  if (mulchType === 'rich') {
    yieldCount += randomIntInRange(1, 2, rng);
    mulchDurationDelta = -1;
  }
  return {
    yieldCount: Math.max(1, Math.min(berry.growthPointCount, yieldCount)),
    mulchDurationDelta
  };
}

export function findNeighborMutations(berry, neighborBerryItems) {
  const offered = [];
  for (const neighborItem of neighborBerryItems) {
    const result = berry.mutations?.[neighborItem];
    if (result) offered.push(result);
  }
  return offered;
}

export function rollMutation(offeredMutations, mulchType, rng = Math.random) {
  if (!offeredMutations.length) return { result: undefined, mulchDurationDelta: 0 };
  const isSurprise = mulchType === 'surprise';
  const chance = isSurprise ? SURPRISE_MUTATION_CHANCE : BASE_MUTATION_CHANCE;
  const result = rng() * 1000 < chance * 1000
    ? offeredMutations[Math.floor(rng() * offeredMutations.length)]
    : undefined;
  return { result, mulchDurationDelta: result && isSurprise ? -1 : 0 };
}

export function chooseMutationSlot(yieldCount, rng = Math.random) {
  return Math.floor(rng() * Math.max(1, yieldCount));
}

export function buildHarvestDrops(berry, yieldCount, mutationResult, mutationSlot = undefined, rng = Math.random) {
  const drops = [];
  for (let i = 0; i < Math.max(1, yieldCount); i++) drops.push(berry.itemId);
  if (mutationResult && drops.length > 0) {
    const slot = Number.isInteger(mutationSlot) && mutationSlot >= 0 && mutationSlot < drops.length
      ? mutationSlot
      : Math.floor(rng() * drops.length);
    drops[slot] = mutationResult;
  }
  return drops;
}

export function berryBreakDrops(stage, berry, cropData) {
  if (stage === 0) return [berry.itemId];
  return [];
}

export function berryHarvestDrops(berry, cropData, biomeMatches, mulchType, rng = Math.random) {
  if (cropData?.drops?.length) return [...cropData.drops];
  const { yieldCount } = calculateYield(berry, mulchType || 'none', biomeMatches, rng);
  return buildHarvestDrops(berry, yieldCount, undefined);
}

export function mintLoot(stage, crop, fortuneLevel = 0, rng = Math.random) {
  if (stage < MINT_MAX_STAGE) {
    return [{ item: crop.seedId, count: 1 }];
  }
  let seedCount = 1;
  if (rng() < 0.125) seedCount += 1;
  if (fortuneLevel >= 1 && rng() < 0.25) seedCount += 1;
  if (fortuneLevel >= 2 && rng() < 0.5) seedCount += 1;
  let leafCount = 1;
  if (rng() < 0.5) leafCount += 2;
  return [
    { item: crop.seedId, count: seedCount },
    { item: crop.leafId, count: leafCount }
  ];
}

export function berrySoilValid(belowTypeId, rooted) {
  if (rooted) return true;
  return BERRY_PLANT_SOIL.includes(belowTypeId) || BERRY_WILD_SOIL.includes(belowTypeId);
}

export function mintSoilValid(belowTypeId, isWild, rooted) {
  if (rooted) return true;
  return isWild ? MINT_WILD_SOIL.includes(belowTypeId) : MINT_PLANT_SOIL.includes(belowTypeId);
}

export function mintLightSufficient(lightLevel) {
  return Number(lightLevel) >= MINT_LIGHT_THRESHOLD;
}
