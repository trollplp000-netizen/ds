export const SPAWN_LEVELS = {
    "bulbasaur": {
        "min": 5,
        "max": 32
    },
    "ivysaur": {
        "min": 16,
        "max": 40
    },
    "venusaur": {
        "min": 32,
        "max": 52
    },
    "charmander": {
        "min": 5,
        "max": 31
    },
    "charmeleon": {
        "min": 16,
        "max": 40
    },
    "charizard": {
        "min": 36,
        "max": 53
    },
    "squirtle": {
        "min": 5,
        "max": 31
    },
    "wartortle": {
        "min": 16,
        "max": 40
    },
    "blastoise": {
        "min": 36,
        "max": 53
    },
    "caterpie": {
        "min": 1,
        "max": 20
    },
    "metapod": {
        "min": 7,
        "max": 21
    },
    "butterfree": {
        "min": 10,
        "max": 40
    },
    "weedle": {
        "min": 1,
        "max": 20
    },
    "kakuna": {
        "min": 7,
        "max": 21
    },
    "beedrill": {
        "min": 10,
        "max": 40
    },
    "pidgey": {
        "min": 1,
        "max": 25
    },
    "pidgeotto": {
        "min": 18,
        "max": 35
    },
    "pidgeot": {
        "min": 36,
        "max": 48
    },
    "rattata": {
        "min": 1,
        "max": 25
    },
    "raticate": {
        "min": 20,
        "max": 41
    },
    "spearow": {
        "min": 1,
        "max": 26
    },
    "fearow": {
        "min": 20,
        "max": 44
    },
    "ekans": {
        "min": 4,
        "max": 29
    },
    "arbok": {
        "min": 22,
        "max": 45
    },
    "pikachu": {
        "min": 16,
        "max": 32
    },
    "raichu": {
        "min": 27,
        "max": 49
    },
    "sandshrew": {
        "min": 5,
        "max": 30
    },
    "sandslash": {
        "min": 22,
        "max": 45
    },
    "nidoranf": {
        "min": 3,
        "max": 28
    },
    "nidorina": {
        "min": 16,
        "max": 37
    },
    "nidoqueen": {
        "min": 37,
        "max": 51
    },
    "nidoranm": {
        "min": 3,
        "max": 28
    },
    "nidorino": {
        "min": 16,
        "max": 37
    },
    "nidoking": {
        "min": 37,
        "max": 51
    },
    "clefairy": {
        "min": 17,
        "max": 32
    },
    "clefable": {
        "min": 27,
        "max": 48
    },
    "vulpix": {
        "min": 5,
        "max": 30
    },
    "ninetales": {
        "min": 25,
        "max": 51
    },
    "jigglypuff": {
        "min": 16,
        "max": 27
    },
    "wigglytuff": {
        "min": 22,
        "max": 44
    },
    "zubat": {
        "min": 1,
        "max": 25
    },
    "golbat": {
        "min": 22,
        "max": 46
    },
    "oddish": {
        "min": 7,
        "max": 32
    },
    "gloom": {
        "min": 21,
        "max": 40
    },
    "vileplume": {
        "min": 35,
        "max": 49
    },
    "paras": {
        "min": 4,
        "max": 29
    },
    "parasect": {
        "min": 24,
        "max": 41
    },
    "venonat": {
        "min": 6,
        "max": 31
    },
    "venomoth": {
        "min": 31,
        "max": 45
    },
    "diglett": {
        "min": 2,
        "max": 27
    },
    "dugtrio": {
        "min": 26,
        "max": 43
    },
    "meowth": {
        "min": 4,
        "max": 29
    },
    "persian": {
        "min": 28,
        "max": 44
    },
    "psyduck": {
        "min": 7,
        "max": 32
    },
    "golduck": {
        "min": 33,
        "max": 50
    },
    "mankey": {
        "min": 6,
        "max": 31
    },
    "primeape": {
        "min": 28,
        "max": 46
    },
    "growlithe": {
        "min": 10,
        "max": 35
    },
    "arcanine": {
        "min": 30,
        "max": 56
    },
    "poliwag": {
        "min": 5,
        "max": 30
    },
    "poliwhirl": {
        "min": 25,
        "max": 39
    },
    "poliwrath": {
        "min": 34,
        "max": 51
    },
    "abra": {
        "min": 6,
        "max": 31
    },
    "kadabra": {
        "min": 16,
        "max": 40
    },
    "alakazam": {
        "min": 35,
        "max": 50
    },
    "machop": {
        "min": 6,
        "max": 31
    },
    "machoke": {
        "min": 28,
        "max": 41
    },
    "machamp": {
        "min": 36,
        "max": 51
    },
    "bellsprout": {
        "min": 5,
        "max": 30
    },
    "weepinbell": {
        "min": 21,
        "max": 39
    },
    "victreebel": {
        "min": 34,
        "max": 49
    },
    "tentacool": {
        "min": 9,
        "max": 34
    },
    "tentacruel": {
        "min": 30,
        "max": 52
    },
    "geodude": {
        "min": 5,
        "max": 30
    },
    "graveler": {
        "min": 25,
        "max": 39
    },
    "golem": {
        "min": 34,
        "max": 50
    },
    "ponyta": {
        "min": 16,
        "max": 41
    },
    "rapidash": {
        "min": 40,
        "max": 50
    },
    "slowpoke": {
        "min": 7,
        "max": 32
    },
    "slowbro": {
        "min": 37,
        "max": 49
    },
    "magnemite": {
        "min": 8,
        "max": 33
    },
    "magneton": {
        "min": 30,
        "max": 47
    },
    "farfetchd": {
        "min": 13,
        "max": 38
    },
    "doduo": {
        "min": 6,
        "max": 31
    },
    "dodrio": {
        "min": 31,
        "max": 47
    },
    "seel": {
        "min": 8,
        "max": 33
    },
    "dewgong": {
        "min": 34,
        "max": 48
    },
    "grimer": {
        "min": 8,
        "max": 33
    },
    "muk": {
        "min": 38,
        "max": 50
    },
    "shellder": {
        "min": 6,
        "max": 31
    },
    "cloyster": {
        "min": 26,
        "max": 53
    },
    "gastly": {
        "min": 6,
        "max": 31
    },
    "haunter": {
        "min": 25,
        "max": 41
    },
    "gengar": {
        "min": 36,
        "max": 50
    },
    "onix": {
        "min": 14,
        "max": 39
    },
    "drowzee": {
        "min": 8,
        "max": 33
    },
    "hypno": {
        "min": 26,
        "max": 48
    },
    "krabby": {
        "min": 8,
        "max": 33
    },
    "kingler": {
        "min": 28,
        "max": 48
    },
    "voltorb": {
        "min": 8,
        "max": 33
    },
    "electrode": {
        "min": 30,
        "max": 49
    },
    "exeggcute": {
        "min": 8,
        "max": 33
    },
    "exeggutor": {
        "min": 28,
        "max": 53
    },
    "cubone": {
        "min": 7,
        "max": 32
    },
    "marowak": {
        "min": 28,
        "max": 43
    },
    "hitmonlee": {
        "min": 20,
        "max": 46
    },
    "hitmonchan": {
        "min": 20,
        "max": 46
    },
    "lickitung": {
        "min": 14,
        "max": 39
    },
    "koffing": {
        "min": 9,
        "max": 34
    },
    "weezing": {
        "min": 35,
        "max": 49
    },
    "rhyhorn": {
        "min": 10,
        "max": 35
    },
    "rhydon": {
        "min": 42,
        "max": 49
    },
    "chansey": {
        "min": 17,
        "max": 45
    },
    "tangela": {
        "min": 19,
        "max": 44
    },
    "kangaskhan": {
        "min": 24,
        "max": 49
    },
    "horsea": {
        "min": 5,
        "max": 30
    },
    "seadra": {
        "min": 32,
        "max": 44
    },
    "goldeen": {
        "min": 7,
        "max": 32
    },
    "seaking": {
        "min": 33,
        "max": 45
    },
    "staryu": {
        "min": 9,
        "max": 34
    },
    "starmie": {
        "min": 29,
        "max": 52
    },
    "mrmime": {
        "min": 26,
        "max": 46
    },
    "scyther": {
        "min": 25,
        "max": 50
    },
    "jynx": {
        "min": 30,
        "max": 46
    },
    "electabuzz": {
        "min": 30,
        "max": 50
    },
    "magmar": {
        "min": 30,
        "max": 50
    },
    "pinsir": {
        "min": 25,
        "max": 50
    },
    "tauros": {
        "min": 24,
        "max": 49
    },
    "magikarp": {
        "min": 1,
        "max": 20
    },
    "gyarados": {
        "min": 20,
        "max": 54
    },
    "lapras": {
        "min": 29,
        "max": 54
    },
    "ditto": {
        "min": 4,
        "max": 29
    },
    "eevee": {
        "min": 5,
        "max": 33
    },
    "vaporeon": {
        "min": 28,
        "max": 53
    },
    "jolteon": {
        "min": 28,
        "max": 53
    },
    "flareon": {
        "min": 28,
        "max": 53
    },
    "porygon": {
        "min": 15,
        "max": 40
    },
    "omanyte": {
        "min": 11,
        "max": 36
    },
    "omastar": {
        "min": 40,
        "max": 50
    },
    "kabuto": {
        "min": 11,
        "max": 36
    },
    "kabutops": {
        "min": 40,
        "max": 50
    },
    "aerodactyl": {
        "min": 27,
        "max": 52
    },
    "snorlax": {
        "min": 34,
        "max": 54
    },
    "dratini": {
        "min": 5,
        "max": 30
    },
    "dragonair": {
        "min": 30,
        "max": 42
    },
    "dragonite": {
        "min": 55,
        "max": 60
    },
    "chikorita": {
        "min": 5,
        "max": 32
    },
    "bayleef": {
        "min": 16,
        "max": 41
    },
    "meganium": {
        "min": 32,
        "max": 53
    },
    "cyndaquil": {
        "min": 5,
        "max": 31
    },
    "quilava": {
        "min": 17,
        "max": 41
    },
    "typhlosion": {
        "min": 36,
        "max": 53
    },
    "totodile": {
        "min": 5,
        "max": 31
    },
    "croconaw": {
        "min": 18,
        "max": 41
    },
    "feraligatr": {
        "min": 30,
        "max": 53
    },
    "sentret": {
        "min": 1,
        "max": 22
    },
    "furret": {
        "min": 15,
        "max": 42
    },
    "hoothoot": {
        "min": 1,
        "max": 26
    },
    "noctowl": {
        "min": 20,
        "max": 45
    },
    "ledyba": {
        "min": 2,
        "max": 27
    },
    "ledian": {
        "min": 18,
        "max": 39
    },
    "spinarak": {
        "min": 1,
        "max": 25
    },
    "ariados": {
        "min": 22,
        "max": 40
    },
    "crobat": {
        "min": 41,
        "max": 54
    },
    "chinchou": {
        "min": 8,
        "max": 33
    },
    "lanturn": {
        "min": 27,
        "max": 46
    },
    "pichu": {
        "min": 1,
        "max": 32
    },
    "cleffa": {
        "min": 1,
        "max": 22
    },
    "igglybuff": {
        "min": 1,
        "max": 21
    },
    "togepi": {
        "min": 1,
        "max": 25
    },
    "togetic": {
        "min": 20,
        "max": 41
    },
    "natu": {
        "min": 7,
        "max": 32
    },
    "xatu": {
        "min": 25,
        "max": 47
    },
    "mareep": {
        "min": 3,
        "max": 28
    },
    "flaaffy": {
        "min": 15,
        "max": 37
    },
    "ampharos": {
        "min": 30,
        "max": 51
    },
    "bellossom": {
        "min": 35,
        "max": 49
    },
    "marill": {
        "min": 14,
        "max": 25
    },
    "azumarill": {
        "min": 18,
        "max": 42
    },
    "sudowoodo": {
        "min": 16,
        "max": 41
    },
    "politoed": {
        "min": 34,
        "max": 50
    },
    "hoppip": {
        "min": 1,
        "max": 25
    },
    "skiploom": {
        "min": 18,
        "max": 34
    },
    "jumpluff": {
        "min": 27,
        "max": 46
    },
    "aipom": {
        "min": 11,
        "max": 36
    },
    "sunkern": {
        "min": 1,
        "max": 18
    },
    "sunflora": {
        "min": 13,
        "max": 43
    },
    "yanma": {
        "min": 14,
        "max": 39
    },
    "wooper": {
        "min": 1,
        "max": 21
    },
    "quagsire": {
        "min": 20,
        "max": 43
    },
    "espeon": {
        "min": 28,
        "max": 53
    },
    "umbreon": {
        "min": 28,
        "max": 53
    },
    "murkrow": {
        "min": 16,
        "max": 41
    },
    "slowking": {
        "min": 37,
        "max": 49
    },
    "misdreavus": {
        "min": 19,
        "max": 44
    },
    "unown": {
        "min": 1,
        "max": 100
    },
    "wobbuffet": {
        "min": 15,
        "max": 41
    },
    "girafarig": {
        "min": 21,
        "max": 46
    },
    "pineco": {
        "min": 4,
        "max": 29
    },
    "forretress": {
        "min": 31,
        "max": 47
    },
    "dunsparce": {
        "min": 17,
        "max": 42
    },
    "gligar": {
        "min": 18,
        "max": 43
    },
    "steelix": {
        "min": 34,
        "max": 51
    },
    "snubbull": {
        "min": 5,
        "max": 30
    },
    "granbull": {
        "min": 23,
        "max": 45
    },
    "qwilfish": {
        "min": 19,
        "max": 44
    },
    "scizor": {
        "min": 45,
        "max": 50
    },
    "shuckle": {
        "min": 16,
        "max": 51
    },
    "heracross": {
        "min": 25,
        "max": 50
    },
    "sneasel": {
        "min": 18,
        "max": 43
    },
    "teddiursa": {
        "min": 8,
        "max": 33
    },
    "ursaring": {
        "min": 30,
        "max": 50
    },
    "slugma": {
        "min": 1,
        "max": 25
    },
    "magcargo": {
        "min": 38,
        "max": 43
    },
    "swinub": {
        "min": 1,
        "max": 25
    },
    "piloswine": {
        "min": 33,
        "max": 45
    },
    "corsola": {
        "min": 16,
        "max": 41
    },
    "remoraid": {
        "min": 5,
        "max": 30
    },
    "octillery": {
        "min": 25,
        "max": 48
    },
    "delibird": {
        "min": 8,
        "max": 33
    },
    "mantine": {
        "min": 30,
        "max": 49
    },
    "skarmory": {
        "min": 22,
        "max": 47
    },
    "houndour": {
        "min": 8,
        "max": 33
    },
    "houndoom": {
        "min": 24,
        "max": 50
    },
    "kingdra": {
        "min": 39,
        "max": 54
    },
    "phanpy": {
        "min": 8,
        "max": 33
    },
    "donphan": {
        "min": 25,
        "max": 50
    },
    "porygon2": {
        "min": 35,
        "max": 52
    },
    "stantler": {
        "min": 22,
        "max": 47
    },
    "smeargle": {
        "min": 1,
        "max": 25
    },
    "tyrogue": {
        "min": 1,
        "max": 21
    },
    "hitmontop": {
        "min": 20,
        "max": 46
    },
    "smoochum": {
        "min": 6,
        "max": 31
    },
    "elekid": {
        "min": 11,
        "max": 36
    },
    "magby": {
        "min": 11,
        "max": 36
    },
    "miltank": {
        "min": 24,
        "max": 49
    },
    "blissey": {
        "min": 40,
        "max": 54
    },
    "larvitar": {
        "min": 5,
        "max": 30
    },
    "pupitar": {
        "min": 30,
        "max": 54
    },
    "tyranitar": {
        "min": 55,
        "max": 60
    },
    "treecko": {
        "min": 5,
        "max": 31
    },
    "grovyle": {
        "min": 16,
        "max": 41
    },
    "sceptile": {
        "min": 36,
        "max": 53
    },
    "torchic": {
        "min": 5,
        "max": 31
    },
    "combusken": {
        "min": 16,
        "max": 41
    },
    "blaziken": {
        "min": 36,
        "max": 53
    },
    "mudkip": {
        "min": 5,
        "max": 31
    },
    "marshtomp": {
        "min": 16,
        "max": 41
    },
    "swampert": {
        "min": 36,
        "max": 53
    },
    "poochyena": {
        "min": 1,
        "max": 22
    },
    "mightyena": {
        "min": 18,
        "max": 42
    },
    "zigzagoon": {
        "min": 1,
        "max": 24
    },
    "linoone": {
        "min": 20,
        "max": 42
    },
    "lotad": {
        "min": 1,
        "max": 22
    },
    "lombre": {
        "min": 14,
        "max": 34
    },
    "ludicolo": {
        "min": 29,
        "max": 48
    },
    "seedot": {
        "min": 1,
        "max": 22
    },
    "nuzleaf": {
        "min": 14,
        "max": 34
    },
    "shiftry": {
        "min": 29,
        "max": 48
    },
    "taillow": {
        "min": 2,
        "max": 27
    },
    "swellow": {
        "min": 22,
        "max": 46
    },
    "wingull": {
        "min": 2,
        "max": 27
    },
    "pelipper": {
        "min": 25,
        "max": 44
    },
    "ralts": {
        "min": 1,
        "max": 20
    },
    "kirlia": {
        "min": 20,
        "max": 29
    },
    "gardevoir": {
        "min": 30,
        "max": 52
    },
    "surskit": {
        "min": 2,
        "max": 27
    },
    "masquerain": {
        "min": 22,
        "max": 45
    },
    "shroomish": {
        "min": 5,
        "max": 30
    },
    "breloom": {
        "min": 23,
        "max": 46
    },
    "slakoth": {
        "min": 3,
        "max": 28
    },
    "vigoroth": {
        "min": 18,
        "max": 44
    },
    "slaking": {
        "min": 36,
        "max": 67
    },
    "nincada": {
        "min": 2,
        "max": 27
    },
    "ninjask": {
        "min": 20,
        "max": 46
    },
    "shedinja": {
        "min": 20,
        "max": 24
    },
    "whismur": {
        "min": 1,
        "max": 24
    },
    "loudred": {
        "min": 20,
        "max": 39
    },
    "exploud": {
        "min": 40,
        "max": 49
    },
    "makuhita": {
        "min": 1,
        "max": 24
    },
    "hariyama": {
        "min": 24,
        "max": 47
    },
    "azurill": {
        "min": 1,
        "max": 19
    },
    "nosepass": {
        "min": 13,
        "max": 38
    },
    "sableye": {
        "min": 13,
        "max": 38
    },
    "mawile": {
        "min": 13,
        "max": 38
    },
    "aron": {
        "min": 8,
        "max": 33
    },
    "lairon": {
        "min": 32,
        "max": 43
    },
    "aggron": {
        "min": 42,
        "max": 53
    },
    "meditite": {
        "min": 3,
        "max": 28
    },
    "medicham": {
        "min": 37,
        "max": 41
    },
    "electrike": {
        "min": 5,
        "max": 30
    },
    "manectric": {
        "min": 26,
        "max": 48
    },
    "plusle": {
        "min": 16,
        "max": 41
    },
    "minun": {
        "min": 16,
        "max": 41
    },
    "volbeat": {
        "min": 18,
        "max": 43
    },
    "illumise": {
        "min": 18,
        "max": 43
    },
    "roselia": {
        "min": 23,
        "max": 40
    },
    "carvanha": {
        "min": 6,
        "max": 31
    },
    "sharpedo": {
        "min": 30,
        "max": 46
    },
    "wailmer": {
        "min": 15,
        "max": 40
    },
    "wailord": {
        "min": 40,
        "max": 50
    },
    "numel": {
        "min": 6,
        "max": 31
    },
    "camerupt": {
        "min": 33,
        "max": 46
    },
    "torkoal": {
        "min": 22,
        "max": 47
    },
    "spoink": {
        "min": 8,
        "max": 33
    },
    "grumpig": {
        "min": 32,
        "max": 47
    },
    "spinda": {
        "min": 11,
        "max": 36
    },
    "trapinch": {
        "min": 4,
        "max": 29
    },
    "vibrava": {
        "min": 35,
        "max": 40
    },
    "flygon": {
        "min": 45,
        "max": 52
    },
    "cacnea": {
        "min": 9,
        "max": 34
    },
    "cacturne": {
        "min": 32,
        "max": 48
    },
    "swablu": {
        "min": 6,
        "max": 31
    },
    "altaria": {
        "min": 35,
        "max": 49
    },
    "lunatone": {
        "min": 21,
        "max": 46
    },
    "solrock": {
        "min": 21,
        "max": 46
    },
    "barboach": {
        "min": 4,
        "max": 29
    },
    "whiscash": {
        "min": 30,
        "max": 47
    },
    "corphish": {
        "min": 6,
        "max": 31
    },
    "crawdaunt": {
        "min": 30,
        "max": 47
    },
    "baltoy": {
        "min": 5,
        "max": 30
    },
    "claydol": {
        "min": 36,
        "max": 50
    },
    "lileep": {
        "min": 11,
        "max": 36
    },
    "cradily": {
        "min": 40,
        "max": 50
    },
    "anorith": {
        "min": 11,
        "max": 36
    },
    "armaldo": {
        "min": 40,
        "max": 50
    },
    "feebas": {
        "min": 1,
        "max": 20
    },
    "milotic": {
        "min": 15,
        "max": 54
    },
    "kecleon": {
        "min": 19,
        "max": 44
    },
    "shuppet": {
        "min": 5,
        "max": 30
    },
    "banette": {
        "min": 37,
        "max": 46
    },
    "duskull": {
        "min": 5,
        "max": 30
    },
    "dusclops": {
        "min": 37,
        "max": 46
    },
    "tropius": {
        "min": 21,
        "max": 46
    },
    "chimecho": {
        "min": 24,
        "max": 46
    },
    "absol": {
        "min": 22,
        "max": 47
    },
    "wynaut": {
        "min": 1,
        "max": 26
    },
    "snorunt": {
        "min": 5,
        "max": 30
    },
    "glalie": {
        "min": 42,
        "max": 48
    },
    "spheal": {
        "min": 4,
        "max": 29
    },
    "sealeo": {
        "min": 32,
        "max": 41
    },
    "walrein": {
        "min": 44,
        "max": 53
    },
    "clamperl": {
        "min": 10,
        "max": 35
    },
    "huntail": {
        "min": 30,
        "max": 49
    },
    "gorebyss": {
        "min": 30,
        "max": 49
    },
    "relicanth": {
        "min": 24,
        "max": 49
    },
    "luvdisc": {
        "min": 8,
        "max": 33
    },
    "bagon": {
        "min": 5,
        "max": 30
    },
    "shelgon": {
        "min": 30,
        "max": 42
    },
    "salamence": {
        "min": 50,
        "max": 60
    },
    "beldum": {
        "min": 5,
        "max": 30
    },
    "metang": {
        "min": 20,
        "max": 44
    },
    "metagross": {
        "min": 45,
        "max": 60
    },
    "turtwig": {
        "min": 5,
        "max": 32
    },
    "grotle": {
        "min": 18,
        "max": 41
    },
    "torterra": {
        "min": 32,
        "max": 53
    },
    "chimchar": {
        "min": 5,
        "max": 31
    },
    "monferno": {
        "min": 14,
        "max": 41
    },
    "infernape": {
        "min": 36,
        "max": 53
    },
    "piplup": {
        "min": 5,
        "max": 31
    },
    "prinplup": {
        "min": 16,
        "max": 41
    },
    "empoleon": {
        "min": 36,
        "max": 53
    },
    "starly": {
        "min": 1,
        "max": 25
    },
    "staravia": {
        "min": 14,
        "max": 34
    },
    "staraptor": {
        "min": 34,
        "max": 49
    },
    "bidoof": {
        "min": 1,
        "max": 25
    },
    "bibarel": {
        "min": 15,
        "max": 41
    },
    "kricketot": {
        "min": 1,
        "max": 19
    },
    "kricketune": {
        "min": 10,
        "max": 38
    },
    "shinx": {
        "min": 1,
        "max": 26
    },
    "luxio": {
        "min": 15,
        "max": 36
    },
    "luxray": {
        "min": 30,
        "max": 52
    },
    "budew": {
        "min": 3,
        "max": 28
    },
    "roserade": {
        "min": 35,
        "max": 52
    },
    "cranidos": {
        "min": 10,
        "max": 35
    },
    "rampardos": {
        "min": 30,
        "max": 50
    },
    "shieldon": {
        "min": 10,
        "max": 35
    },
    "bastiodon": {
        "min": 30,
        "max": 50
    },
    "combee": {
        "min": 1,
        "max": 24
    },
    "vespiquen": {
        "min": 21,
        "max": 47
    },
    "pachirisu": {
        "min": 16,
        "max": 41
    },
    "buizel": {
        "min": 8,
        "max": 33
    },
    "floatzel": {
        "min": 26,
        "max": 50
    },
    "shellos": {
        "min": 8,
        "max": 33
    },
    "gastrodon": {
        "min": 30,
        "max": 48
    },
    "ambipom": {
        "min": 32,
        "max": 48
    },
    "drifloon": {
        "min": 10,
        "max": 35
    },
    "drifblim": {
        "min": 28,
        "max": 50
    },
    "buneary": {
        "min": 10,
        "max": 35
    },
    "lopunny": {
        "min": 30,
        "max": 48
    },
    "mismagius": {
        "min": 39,
        "max": 50
    },
    "honchkrow": {
        "min": 36,
        "max": 51
    },
    "glameow": {
        "min": 6,
        "max": 31
    },
    "purugly": {
        "min": 38,
        "max": 45
    },
    "chingling": {
        "min": 4,
        "max": 29
    },
    "bronzor": {
        "min": 5,
        "max": 30
    },
    "bronzong": {
        "min": 33,
        "max": 50
    },
    "bonsly": {
        "min": 4,
        "max": 29
    },
    "mimejr": {
        "min": 6,
        "max": 31
    },
    "happiny": {
        "min": 1,
        "max": 22
    },
    "chatot": {
        "min": 16,
        "max": 41
    },
    "spiritomb": {
        "min": 24,
        "max": 49
    },
    "gible": {
        "min": 5,
        "max": 30
    },
    "gabite": {
        "min": 24,
        "max": 47
    },
    "garchomp": {
        "min": 48,
        "max": 60
    },
    "munchlax": {
        "min": 24,
        "max": 39
    },
    "riolu": {
        "min": 4,
        "max": 29
    },
    "lucario": {
        "min": 24,
        "max": 53
    },
    "hippopotas": {
        "min": 8,
        "max": 33
    },
    "hippowdon": {
        "min": 34,
        "max": 53
    },
    "skorupi": {
        "min": 8,
        "max": 33
    },
    "drapion": {
        "min": 40,
        "max": 50
    },
    "croagunk": {
        "min": 5,
        "max": 30
    },
    "toxicroak": {
        "min": 37,
        "max": 49
    },
    "carnivine": {
        "min": 20,
        "max": 45
    },
    "finneon": {
        "min": 8,
        "max": 33
    },
    "lumineon": {
        "min": 31,
        "max": 46
    },
    "mantyke": {
        "min": 10,
        "max": 35
    },
    "weavile": {
        "min": 38,
        "max": 51
    },
    "magnezone": {
        "min": 42,
        "max": 54
    },
    "lickilicky": {
        "min": 34,
        "max": 52
    },
    "rhyperior": {
        "min": 44,
        "max": 54
    },
    "tangrowth": {
        "min": 24,
        "max": 54
    },
    "electivire": {
        "min": 45,
        "max": 54
    },
    "magmortar": {
        "min": 45,
        "max": 54
    },
    "togekiss": {
        "min": 36,
        "max": 55
    },
    "yanmega": {
        "min": 33,
        "max": 52
    },
    "leafeon": {
        "min": 28,
        "max": 53
    },
    "glaceon": {
        "min": 28,
        "max": 53
    },
    "gliscor": {
        "min": 38,
        "max": 51
    },
    "mamoswine": {
        "min": 40,
        "max": 53
    },
    "porygonz": {
        "min": 47,
        "max": 54
    },
    "gallade": {
        "min": 30,
        "max": 52
    },
    "probopass": {
        "min": 33,
        "max": 53
    },
    "dusknoir": {
        "min": 41,
        "max": 53
    },
    "froslass": {
        "min": 42,
        "max": 48
    },
    "snivy": {
        "min": 5,
        "max": 31
    },
    "servine": {
        "min": 17,
        "max": 41
    },
    "serperior": {
        "min": 36,
        "max": 53
    },
    "tepig": {
        "min": 5,
        "max": 31
    },
    "pignite": {
        "min": 17,
        "max": 42
    },
    "emboar": {
        "min": 36,
        "max": 53
    },
    "oshawott": {
        "min": 5,
        "max": 31
    },
    "dewott": {
        "min": 17,
        "max": 41
    },
    "samurott": {
        "min": 36,
        "max": 53
    },
    "patrat": {
        "min": 1,
        "max": 26
    },
    "watchog": {
        "min": 20,
        "max": 42
    },
    "lillipup": {
        "min": 3,
        "max": 28
    },
    "herdier": {
        "min": 16,
        "max": 37
    },
    "stoutland": {
        "min": 32,
        "max": 50
    },
    "purrloin": {
        "min": 3,
        "max": 28
    },
    "liepard": {
        "min": 20,
        "max": 45
    },
    "pansage": {
        "min": 7,
        "max": 32
    },
    "simisage": {
        "min": 27,
        "max": 50
    },
    "pansear": {
        "min": 7,
        "max": 32
    },
    "simisear": {
        "min": 27,
        "max": 50
    },
    "panpour": {
        "min": 7,
        "max": 32
    },
    "simipour": {
        "min": 27,
        "max": 50
    },
    "munna": {
        "min": 4,
        "max": 29
    },
    "musharna": {
        "min": 24,
        "max": 49
    },
    "pidove": {
        "min": 1,
        "max": 26
    },
    "tranquill": {
        "min": 21,
        "max": 36
    },
    "unfezant": {
        "min": 32,
        "max": 49
    },
    "blitzle": {
        "min": 5,
        "max": 30
    },
    "zebstrika": {
        "min": 27,
        "max": 50
    },
    "roggenrola": {
        "min": 3,
        "max": 28
    },
    "boldore": {
        "min": 25,
        "max": 39
    },
    "gigalith": {
        "min": 34,
        "max": 52
    },
    "woobat": {
        "min": 7,
        "max": 32
    },
    "swoobat": {
        "min": 27,
        "max": 43
    },
    "drilbur": {
        "min": 8,
        "max": 33
    },
    "excadrill": {
        "min": 31,
        "max": 51
    },
    "timburr": {
        "min": 6,
        "max": 31
    },
    "gurdurr": {
        "min": 25,
        "max": 41
    },
    "conkeldurr": {
        "min": 36,
        "max": 51
    },
    "throh": {
        "min": 12,
        "max": 47
    },
    "sawk": {
        "min": 12,
        "max": 47
    },
    "sewaddle": {
        "min": 6,
        "max": 31
    },
    "swadloon": {
        "min": 20,
        "max": 38
    },
    "leavanny": {
        "min": 33,
        "max": 50
    },
    "venipede": {
        "min": 1,
        "max": 26
    },
    "whirlipede": {
        "min": 22,
        "max": 36
    },
    "scolipede": {
        "min": 30,
        "max": 49
    },
    "cottonee": {
        "min": 3,
        "max": 28
    },
    "whimsicott": {
        "min": 23,
        "max": 48
    },
    "petilil": {
        "min": 3,
        "max": 28
    },
    "lilligant": {
        "min": 23,
        "max": 48
    },
    "basculin": {
        "min": 21,
        "max": 46
    },
    "sandile": {
        "min": 4,
        "max": 29
    },
    "krokorok": {
        "min": 29,
        "max": 35
    },
    "krookodile": {
        "min": 40,
        "max": 52
    },
    "darumaka": {
        "min": 7,
        "max": 32
    },
    "darmanitan": {
        "min": 35,
        "max": 54
    },
    "maractus": {
        "min": 21,
        "max": 46
    },
    "dwebble": {
        "min": 8,
        "max": 33
    },
    "crustle": {
        "min": 34,
        "max": 49
    },
    "scraggy": {
        "min": 10,
        "max": 35
    },
    "scrafty": {
        "min": 39,
        "max": 49
    },
    "sigilyph": {
        "min": 24,
        "max": 49
    },
    "yamask": {
        "min": 5,
        "max": 30
    },
    "cofagrigus": {
        "min": 34,
        "max": 48
    },
    "tirtouga": {
        "min": 15,
        "max": 40
    },
    "carracosta": {
        "min": 37,
        "max": 57
    },
    "archen": {
        "min": 15,
        "max": 40
    },
    "archeops": {
        "min": 37,
        "max": 57
    },
    "trubbish": {
        "min": 8,
        "max": 33
    },
    "garbodor": {
        "min": 36,
        "max": 47
    },
    "zorua": {
        "min": 8,
        "max": 33
    },
    "zoroark": {
        "min": 30,
        "max": 51
    },
    "minccino": {
        "min": 5,
        "max": 30
    },
    "cinccino": {
        "min": 25,
        "max": 47
    },
    "gothita": {
        "min": 4,
        "max": 29
    },
    "gothorita": {
        "min": 32,
        "max": 39
    },
    "gothitelle": {
        "min": 41,
        "max": 49
    },
    "solosis": {
        "min": 4,
        "max": 29
    },
    "duosion": {
        "min": 32,
        "max": 37
    },
    "reuniclus": {
        "min": 41,
        "max": 49
    },
    "ducklett": {
        "min": 6,
        "max": 31
    },
    "swanna": {
        "min": 35,
        "max": 47
    },
    "vanillite": {
        "min": 6,
        "max": 31
    },
    "vanillish": {
        "min": 35,
        "max": 40
    },
    "vanilluxe": {
        "min": 47,
        "max": 54
    },
    "deerling": {
        "min": 9,
        "max": 34
    },
    "sawsbuck": {
        "min": 34,
        "max": 48
    },
    "emolga": {
        "min": 18,
        "max": 43
    },
    "karrablast": {
        "min": 7,
        "max": 32
    },
    "escavalier": {
        "min": 27,
        "max": 50
    },
    "foongus": {
        "min": 4,
        "max": 29
    },
    "amoonguss": {
        "min": 39,
        "max": 46
    },
    "frillish": {
        "min": 9,
        "max": 34
    },
    "jellicent": {
        "min": 40,
        "max": 48
    },
    "alomomola": {
        "min": 22,
        "max": 47
    },
    "joltik": {
        "min": 7,
        "max": 32
    },
    "galvantula": {
        "min": 36,
        "max": 47
    },
    "ferroseed": {
        "min": 6,
        "max": 31
    },
    "ferrothorn": {
        "min": 40,
        "max": 49
    },
    "klink": {
        "min": 5,
        "max": 30
    },
    "klang": {
        "min": 38,
        "max": 44
    },
    "klinklang": {
        "min": 49,
        "max": 52
    },
    "tynamo": {
        "min": 3,
        "max": 28
    },
    "eelektrik": {
        "min": 39,
        "max": 41
    },
    "eelektross": {
        "min": 36,
        "max": 52
    },
    "elgyem": {
        "min": 9,
        "max": 34
    },
    "beheeyem": {
        "min": 42,
        "max": 49
    },
    "litwick": {
        "min": 3,
        "max": 28
    },
    "lampent": {
        "min": 41,
        "max": 46
    },
    "chandelure": {
        "min": 41,
        "max": 52
    },
    "axew": {
        "min": 7,
        "max": 32
    },
    "fraxure": {
        "min": 38,
        "max": 41
    },
    "haxorus": {
        "min": 48,
        "max": 54
    },
    "cubchoo": {
        "min": 6,
        "max": 31
    },
    "beartic": {
        "min": 37,
        "max": 51
    },
    "cryogonal": {
        "min": 27,
        "max": 52
    },
    "shelmet": {
        "min": 6,
        "max": 31
    },
    "accelgor": {
        "min": 26,
        "max": 50
    },
    "stunfisk": {
        "min": 22,
        "max": 47
    },
    "mienfoo": {
        "min": 10,
        "max": 35
    },
    "mienshao": {
        "min": 50,
        "max": 51
    },
    "druddigon": {
        "min": 24,
        "max": 49
    },
    "golett": {
        "min": 5,
        "max": 30
    },
    "golurk": {
        "min": 43,
        "max": 48
    },
    "bouffalant": {
        "min": 24,
        "max": 49
    },
    "rufflet": {
        "min": 10,
        "max": 35
    },
    "braviary": {
        "min": 54,
        "max": 59
    },
    "heatmor": {
        "min": 23,
        "max": 48
    },
    "durant": {
        "min": 23,
        "max": 48
    },
    "deino": {
        "min": 5,
        "max": 30
    },
    "zweilous": {
        "min": 50,
        "max": 55
    },
    "hydreigon": {
        "min": 64,
        "max": 69
    },
    "larvesta": {
        "min": 11,
        "max": 36
    },
    "volcarona": {
        "min": 59,
        "max": 64
    },
    "chespin": {
        "min": 5,
        "max": 31
    },
    "quilladin": {
        "min": 16,
        "max": 41
    },
    "chesnaught": {
        "min": 36,
        "max": 53
    },
    "fennekin": {
        "min": 5,
        "max": 31
    },
    "braixen": {
        "min": 16,
        "max": 41
    },
    "delphox": {
        "min": 36,
        "max": 53
    },
    "froakie": {
        "min": 5,
        "max": 31
    },
    "frogadier": {
        "min": 16,
        "max": 41
    },
    "greninja": {
        "min": 36,
        "max": 53
    },
    "bunnelby": {
        "min": 1,
        "max": 24
    },
    "diggersby": {
        "min": 20,
        "max": 42
    },
    "fletchling": {
        "min": 3,
        "max": 28
    },
    "fletchinder": {
        "min": 17,
        "max": 38
    },
    "talonflame": {
        "min": 35,
        "max": 50
    },
    "scatterbug": {
        "min": 1,
        "max": 20
    },
    "spewpa": {
        "min": 9,
        "max": 21
    },
    "vivillon": {
        "min": 12,
        "max": 41
    },
    "litleo": {
        "min": 12,
        "max": 37
    },
    "pyroar": {
        "min": 35,
        "max": 51
    },
    "flabebe": {
        "min": 5,
        "max": 30
    },
    "floette": {
        "min": 19,
        "max": 37
    },
    "florges": {
        "min": 32,
        "max": 55
    },
    "skiddo": {
        "min": 10,
        "max": 35
    },
    "gogoat": {
        "min": 32,
        "max": 53
    },
    "furfrou": {
        "min": 22,
        "max": 47
    },
    "espurr": {
        "min": 11,
        "max": 36
    },
    "meowstic": {
        "min": 25,
        "max": 47
    },
    "honedge": {
        "min": 8,
        "max": 33
    },
    "doublade": {
        "min": 35,
        "max": 45
    },
    "aegislash": {
        "min": 40,
        "max": 50
    },
    "spritzee": {
        "min": 9,
        "max": 34
    },
    "aromatisse": {
        "min": 29,
        "max": 46
    },
    "swirlix": {
        "min": 9,
        "max": 34
    },
    "slurpuff": {
        "min": 29,
        "max": 48
    },
    "inkay": {
        "min": 4,
        "max": 29
    },
    "malamar": {
        "min": 30,
        "max": 48
    },
    "binacle": {
        "min": 6,
        "max": 31
    },
    "barbaracle": {
        "min": 39,
        "max": 50
    },
    "skrelp": {
        "min": 7,
        "max": 32
    },
    "dragalge": {
        "min": 48,
        "max": 49
    },
    "clauncher": {
        "min": 8,
        "max": 33
    },
    "clawitzer": {
        "min": 37,
        "max": 50
    },
    "tyrunt": {
        "min": 11,
        "max": 36
    },
    "tyrantrum": {
        "min": 39,
        "max": 52
    },
    "amaura": {
        "min": 11,
        "max": 36
    },
    "aurorus": {
        "min": 39,
        "max": 52
    },
    "sylveon": {
        "min": 28,
        "max": 53
    },
    "hawlucha": {
        "min": 25,
        "max": 50
    },
    "dedenne": {
        "min": 18,
        "max": 43
    },
    "carbink": {
        "min": 25,
        "max": 50
    },
    "goomy": {
        "min": 5,
        "max": 30
    },
    "sliggoo": {
        "min": 40,
        "max": 45
    },
    "goodra": {
        "min": 50,
        "max": 60
    },
    "klefki": {
        "min": 22,
        "max": 47
    },
    "phantump": {
        "min": 6,
        "max": 31
    },
    "trevenant": {
        "min": 26,
        "max": 47
    },
    "pumpkaboo": {
        "min": 9,
        "max": 34
    },
    "gourgeist": {
        "min": 29,
        "max": 49
    },
    "bergmite": {
        "min": 5,
        "max": 30
    },
    "avalugg": {
        "min": 37,
        "max": 51
    },
    "noibat": {
        "min": 1,
        "max": 25
    },
    "noivern": {
        "min": 48,
        "max": 54
    },
    "rowlet": {
        "min": 5,
        "max": 32
    },
    "dartrix": {
        "min": 17,
        "max": 42
    },
    "decidueye": {
        "min": 34,
        "max": 53
    },
    "litten": {
        "min": 5,
        "max": 32
    },
    "torracat": {
        "min": 17,
        "max": 42
    },
    "incineroar": {
        "min": 34,
        "max": 53
    },
    "popplio": {
        "min": 5,
        "max": 32
    },
    "brionne": {
        "min": 17,
        "max": 42
    },
    "primarina": {
        "min": 34,
        "max": 53
    },
    "pikipek": {
        "min": 2,
        "max": 27
    },
    "trumbeak": {
        "min": 14,
        "max": 36
    },
    "toucannon": {
        "min": 28,
        "max": 49
    },
    "yungoos": {
        "min": 1,
        "max": 25
    },
    "gumshoos": {
        "min": 20,
        "max": 42
    },
    "crabrawler": {
        "min": 9,
        "max": 34
    },
    "crabominable": {
        "min": 29,
        "max": 48
    },
    "cutiefly": {
        "min": 5,
        "max": 30
    },
    "ribombee": {
        "min": 25,
        "max": 46
    },
    "wishiwashi": {
        "min": 1,
        "max": 18
    },
    "mareanie": {
        "min": 6,
        "max": 31
    },
    "toxapex": {
        "min": 38,
        "max": 50
    },
    "mudbray": {
        "min": 14,
        "max": 39
    },
    "mudsdale": {
        "min": 30,
        "max": 50
    },
    "dewpider": {
        "min": 2,
        "max": 27
    },
    "araquanid": {
        "min": 22,
        "max": 45
    },
    "fomantis": {
        "min": 1,
        "max": 25
    },
    "lurantis": {
        "min": 34,
        "max": 48
    },
    "morelull": {
        "min": 4,
        "max": 29
    },
    "shiinotic": {
        "min": 24,
        "max": 41
    },
    "salandit": {
        "min": 7,
        "max": 32
    },
    "salazzle": {
        "min": 33,
        "max": 48
    },
    "stufful": {
        "min": 9,
        "max": 34
    },
    "bewear": {
        "min": 27,
        "max": 50
    },
    "bounsweet": {
        "min": 1,
        "max": 21
    },
    "steenee": {
        "min": 18,
        "max": 29
    },
    "tsareena": {
        "min": 28,
        "max": 51
    },
    "comfey": {
        "min": 24,
        "max": 49
    },
    "wimpod": {
        "min": 1,
        "max": 23
    },
    "golisopod": {
        "min": 30,
        "max": 53
    },
    "sandygast": {
        "min": 7,
        "max": 32
    },
    "palossand": {
        "min": 42,
        "max": 48
    },
    "pyukumuku": {
        "min": 16,
        "max": 41
    },
    "komala": {
        "min": 23,
        "max": 48
    },
    "turtonator": {
        "min": 24,
        "max": 49
    },
    "togedemaru": {
        "min": 19,
        "max": 44
    },
    "mimikyu": {
        "min": 23,
        "max": 48
    },
    "bruxish": {
        "min": 23,
        "max": 48
    },
    "drampa": {
        "min": 24,
        "max": 49
    },
    "dhelmise": {
        "min": 27,
        "max": 52
    },
    "jangmoo": {
        "min": 5,
        "max": 30
    },
    "hakamoo": {
        "min": 35,
        "max": 42
    },
    "kommoo": {
        "min": 45,
        "max": 60
    },
    "grookey": {
        "min": 5,
        "max": 31
    },
    "thwackey": {
        "min": 16,
        "max": 42
    },
    "rillaboom": {
        "min": 35,
        "max": 53
    },
    "scorbunny": {
        "min": 5,
        "max": 31
    },
    "raboot": {
        "min": 16,
        "max": 42
    },
    "cinderace": {
        "min": 35,
        "max": 53
    },
    "sobble": {
        "min": 5,
        "max": 31
    },
    "drizzile": {
        "min": 16,
        "max": 42
    },
    "inteleon": {
        "min": 35,
        "max": 53
    },
    "skwovet": {
        "min": 3,
        "max": 28
    },
    "greedent": {
        "min": 24,
        "max": 46
    },
    "rookidee": {
        "min": 1,
        "max": 25
    },
    "corvisquire": {
        "min": 18,
        "max": 37
    },
    "corviknight": {
        "min": 38,
        "max": 50
    },
    "nickit": {
        "min": 1,
        "max": 25
    },
    "thievul": {
        "min": 18,
        "max": 46
    },
    "gossifleur": {
        "min": 1,
        "max": 25
    },
    "eldegoss": {
        "min": 20,
        "max": 46
    },
    "wooloo": {
        "min": 2,
        "max": 27
    },
    "dubwool": {
        "min": 24,
        "max": 49
    },
    "chewtle": {
        "min": 3,
        "max": 28
    },
    "drednaw": {
        "min": 22,
        "max": 49
    },
    "yamper": {
        "min": 2,
        "max": 27
    },
    "boltund": {
        "min": 25,
        "max": 49
    },
    "silicobra": {
        "min": 7,
        "max": 32
    },
    "sandaconda": {
        "min": 36,
        "max": 51
    },
    "cramorant": {
        "min": 23,
        "max": 48
    },
    "arrokuda": {
        "min": 3,
        "max": 28
    },
    "barraskewda": {
        "min": 26,
        "max": 49
    },
    "toxel": {
        "min": 1,
        "max": 24
    },
    "toxtricity": {
        "min": 30,
        "max": 50
    },
    "sizzlipede": {
        "min": 6,
        "max": 31
    },
    "centiskorch": {
        "min": 28,
        "max": 53
    },
    "clobbopus": {
        "min": 6,
        "max": 31
    },
    "grapploct": {
        "min": 35,
        "max": 48
    },
    "sinistea": {
        "min": 6,
        "max": 31
    },
    "polteageist": {
        "min": 26,
        "max": 51
    },
    "hatenna": {
        "min": 2,
        "max": 27
    },
    "hattrem": {
        "min": 32,
        "max": 37
    },
    "hatterene": {
        "min": 42,
        "max": 51
    },
    "impidimp": {
        "min": 2,
        "max": 27
    },
    "morgrem": {
        "min": 32,
        "max": 37
    },
    "grimmsnarl": {
        "min": 42,
        "max": 51
    },
    "obstagoon": {
        "min": 35,
        "max": 52
    },
    "perrserker": {
        "min": 28,
        "max": 44
    },
    "cursola": {
        "min": 38,
        "max": 51
    },
    "sirfetchd": {
        "min": 33,
        "max": 51
    },
    "mrrime": {
        "min": 42,
        "max": 52
    },
    "milcery": {
        "min": 2,
        "max": 27
    },
    "alcremie": {
        "min": 22,
        "max": 50
    },
    "falinks": {
        "min": 22,
        "max": 47
    },
    "pincurchin": {
        "min": 19,
        "max": 44
    },
    "stonjourner": {
        "min": 22,
        "max": 47
    },
    "eiscue": {
        "min": 22,
        "max": 47
    },
    "morpeko": {
        "min": 19,
        "max": 44
    },
    "cufant": {
        "min": 8,
        "max": 33
    },
    "copperajah": {
        "min": 34,
        "max": 50
    },
    "dreepy": {
        "min": 2,
        "max": 27
    },
    "drakloak": {
        "min": 50,
        "max": 55
    },
    "dragapult": {
        "min": 60,
        "max": 65
    },
    "wyrdeer": {
        "min": 42,
        "max": 53
    },
    "kleavor": {
        "min": 45,
        "max": 50
    },
    "ursaluna": {
        "min": 45,
        "max": 55
    },
    "basculegion": {
        "min": 41,
        "max": 53
    },
    "sneasler": {
        "min": 38,
        "max": 51
    },
    "overqwil": {
        "min": 39,
        "max": 51
    },
    "sprigatito": {
        "min": 5,
        "max": 31
    },
    "floragato": {
        "min": 16,
        "max": 41
    },
    "meowscarada": {
        "min": 36,
        "max": 53
    },
    "fuecoco": {
        "min": 5,
        "max": 31
    },
    "crocalor": {
        "min": 16,
        "max": 41
    },
    "skeledirge": {
        "min": 36,
        "max": 53
    },
    "quaxly": {
        "min": 5,
        "max": 31
    },
    "quaxwell": {
        "min": 16,
        "max": 41
    },
    "quaquaval": {
        "min": 36,
        "max": 53
    },
    "lechonk": {
        "min": 1,
        "max": 25
    },
    "oinkologne": {
        "min": 18,
        "max": 49
    },
    "tarountula": {
        "min": 1,
        "max": 21
    },
    "spidops": {
        "min": 15,
        "max": 40
    },
    "tandemaus": {
        "min": 6,
        "max": 31
    },
    "maushold": {
        "min": 25,
        "max": 47
    },
    "fidough": {
        "min": 6,
        "max": 31
    },
    "dachsbun": {
        "min": 26,
        "max": 48
    },
    "smoliv": {
        "min": 1,
        "max": 26
    },
    "dolliv": {
        "min": 25,
        "max": 35
    },
    "arboliva": {
        "min": 35,
        "max": 51
    },
    "squawkabilly": {
        "min": 17,
        "max": 42
    },
    "nacli": {
        "min": 3,
        "max": 28
    },
    "naclstack": {
        "min": 24,
        "max": 36
    },
    "garganacl": {
        "min": 38,
        "max": 50
    },
    "charcadet": {
        "min": 1,
        "max": 26
    },
    "armarouge": {
        "min": 21,
        "max": 53
    },
    "ceruledge": {
        "min": 21,
        "max": 53
    },
    "tadbulb": {
        "min": 2,
        "max": 27
    },
    "bellibolt": {
        "min": 22,
        "max": 50
    },
    "wattrel": {
        "min": 3,
        "max": 28
    },
    "kilowattrel": {
        "min": 25,
        "max": 49
    },
    "maschiff": {
        "min": 9,
        "max": 34
    },
    "mabosstiff": {
        "min": 30,
        "max": 51
    },
    "shroodle": {
        "min": 4,
        "max": 29
    },
    "grafaiai": {
        "min": 28,
        "max": 49
    },
    "bramblin": {
        "min": 3,
        "max": 28
    },
    "brambleghast": {
        "min": 23,
        "max": 48
    },
    "toedscool": {
        "min": 9,
        "max": 34
    },
    "toedscruel": {
        "min": 30,
        "max": 52
    },
    "klawf": {
        "min": 20,
        "max": 45
    },
    "capsakid": {
        "min": 5,
        "max": 30
    },
    "scovillain": {
        "min": 25,
        "max": 49
    },
    "rellor": {
        "min": 2,
        "max": 27
    },
    "rabsca": {
        "min": 22,
        "max": 47
    },
    "flittle": {
        "min": 1,
        "max": 26
    },
    "espathra": {
        "min": 35,
        "max": 48
    },
    "tinkatink": {
        "min": 5,
        "max": 30
    },
    "tinkatuff": {
        "min": 24,
        "max": 38
    },
    "tinkaton": {
        "min": 38,
        "max": 51
    },
    "wiglett": {
        "min": 1,
        "max": 25
    },
    "wugtrio": {
        "min": 26,
        "max": 43
    },
    "finizen": {
        "min": 7,
        "max": 32
    },
    "palafin": {
        "min": 38,
        "max": 46
    },
    "varoom": {
        "min": 5,
        "max": 30
    },
    "revavroom": {
        "min": 40,
        "max": 50
    },
    "cyclizar": {
        "min": 25,
        "max": 50
    },
    "orthworm": {
        "min": 23,
        "max": 48
    },
    "glimmet": {
        "min": 10,
        "max": 35
    },
    "glimmora": {
        "min": 35,
        "max": 53
    },
    "flamigo": {
        "min": 25,
        "max": 50
    },
    "cetoddle": {
        "min": 8,
        "max": 33
    },
    "cetitan": {
        "min": 28,
        "max": 52
    },
    "veluza": {
        "min": 23,
        "max": 48
    },
    "dondozo": {
        "min": 28,
        "max": 53
    },
    "tatsugiri": {
        "min": 23,
        "max": 48
    },
    "annihilape": {
        "min": 35,
        "max": 54
    },
    "clodsire": {
        "min": 20,
        "max": 43
    },
    "farigiraf": {
        "min": 32,
        "max": 45
    },
    "dudunsparce": {
        "min": 32,
        "max": 52
    },
    "gimmighoul": {
        "min": 5,
        "max": 30
    },
    "poltchageist": {
        "min": 6,
        "max": 31
    },
    "sinistcha": {
        "min": 26,
        "max": 51
    },
    "decidueye_hisui": {
        "min": 34,
        "max": 53
    },
    "zigzagoon_galar": {
        "min": 1,
        "max": 24
    },
    "linoone_galar": {
        "min": 20,
        "max": 42
    },
    "avalugg_hisui": {
        "min": 37,
        "max": 51
    },
    "goodra_hisui": {
        "min": 50,
        "max": 60
    },
    "sliggoo_hisui": {
        "min": 40,
        "max": 45
    },
    "samurott_hisui": {
        "min": 36,
        "max": 53
    },
    "zoroark_hisui": {
        "min": 30,
        "max": 51
    },
    "lilligant_hisui": {
        "min": 23,
        "max": 48
    },
    "braviary_hisui": {
        "min": 54,
        "max": 59
    },
    "zorua_hisui": {
        "min": 8,
        "max": 33
    },
    "yamask_galar": {
        "min": 5,
        "max": 30
    },
    "stunfisk_galar": {
        "min": 22,
        "max": 47
    },
    "wooper_paldea": {
        "min": 1,
        "max": 21
    },
    "corsola_galar": {
        "min": 16,
        "max": 41
    },
    "slowking_galar": {
        "min": 37,
        "max": 49
    },
    "qwilfish_hisui": {
        "min": 19,
        "max": 44
    },
    "sneasel_hisui": {
        "min": 18,
        "max": 43
    },
    "typhlosion_hisui": {
        "min": 36,
        "max": 53
    },
    "muk_alola": {
        "min": 38,
        "max": 50
    },
    "raichu_alola": {
        "min": 27,
        "max": 49
    },
    "slowpoke_galar": {
        "min": 7,
        "max": 32
    },
    "voltorb_hisui": {
        "min": 8,
        "max": 33
    },
    "raticate_alola": {
        "min": 20,
        "max": 41
    },
    "rapidash_galar": {
        "min": 40,
        "max": 50
    },
    "meowth_alola": {
        "min": 4,
        "max": 29
    },
    "meowth_galar": {
        "min": 4,
        "max": 29
    },
    "sandshrew_alola": {
        "min": 5,
        "max": 30
    },
    "vulpix_alola": {
        "min": 5,
        "max": 30
    },
    "grimer_alola": {
        "min": 8,
        "max": 33
    },
    "graveler_alola": {
        "min": 25,
        "max": 39
    },
    "exeggutor_alola": {
        "min": 28,
        "max": 53
    },
    "electrode_hisui": {
        "min": 30,
        "max": 49
    },
    "ninetales_alola": {
        "min": 25,
        "max": 51
    },
    "weezing_galar": {
        "min": 35,
        "max": 49
    },
    "golem_alola": {
        "min": 34,
        "max": 50
    },
    "farfetchd_galar": {
        "min": 13,
        "max": 38
    },
    "sandslash_alola": {
        "min": 22,
        "max": 45
    },
    "geodude_alola": {
        "min": 5,
        "max": 30
    },
    "dugtrio_alola": {
        "min": 26,
        "max": 43
    },
    "mrmime_galar": {
        "min": 26,
        "max": 46
    },
    "slowbro_galar": {
        "min": 37,
        "max": 49
    },
    "marowak_alola": {
        "min": 28,
        "max": 43
    },
    "diglett_alola": {
        "min": 2,
        "max": 27
    },
    "ponyta_galar": {
        "min": 16,
        "max": 41
    },
    "rattata_alola": {
        "min": 1,
        "max": 25
    },
    "persian_alola": {
        "min": 28,
        "max": 44
    },
    "tauros_paldea_combat": {
        "min": 24,
        "max": 49
    },
    "tauros_paldea_blaze": {
        "min": 24,
        "max": 49
    },
    "tauros_paldea_aqua": {
        "min": 24,
        "max": 49
    },
    "runerigus": {
        "min": 34,
        "max": 48
    }
};
