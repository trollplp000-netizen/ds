export const COBBLEMON_OWNER_FOLLOW = Object.freeze({
    speed: 0.4,
    startDistance: 5,
    stopDistance: 4,
    teleportDistance: 32
});

const ORIGINAL_FLYING_TYPES = new Set([
    "lota:abra",
    "lota:aegislash",
    "lota:aerodactyl",
    "lota:altaria",
    "lota:archeops",
    "lota:articuno",
    "lota:baltoy",
    "lota:banette",
    "lota:beautifly",
    "lota:beedrill",
    "lota:beheeyem",
    "lota:beldum",
    "lota:braviary",
    "lota:bronzong",
    "lota:bronzor",
    "lota:butterfree",
    "lota:carbink",
    "lota:carnivine",
    "lota:castform",
    "lota:chandelure",
    "lota:charizard",
    "lota:chatot",
    "lota:chimecho",
    "lota:chingling",
    "lota:claydol",
    "lota:clefable",
    "lota:clefairy",
    "lota:cofagrigus",
    "lota:combee",
    "lota:comfey",
    "lota:corviknight",
    "lota:corvisquire",
    "lota:cottonee",
    "lota:cramorant",
    "lota:crobat",
    "lota:cryogonal",
    "lota:cutiefly",
    "lota:dartrix",
    "lota:decidueye",
    "lota:delibird",
    "lota:dhelmise",
    "lota:diancie",
    "lota:doublade",
    "lota:dragapult",
    "lota:dragonair",
    "lota:dragonite",
    "lota:drakloak",
    "lota:drampa",
    "lota:dreepy",
    "lota:drifblim",
    "lota:drifloon",
    "lota:ducklett",
    "lota:duosion",
    "lota:dusclops",
    "lota:dusknoir",
    "lota:duskull",
    "lota:dustox",
    "lota:eelektrik",
    "lota:eelektross",
    "lota:eldegoss",
    "lota:elgyem",
    "lota:emolga",
    "lota:escavalier",
    "lota:farfetchd",
    "lota:fearow",
    "lota:flabebe",
    "lota:flamigo",
    "lota:flapple",
    "lota:fletchinder",
    "lota:fletchling",
    "lota:flittle",
    "lota:floette",
    "lota:florges",
    "lota:flygon",
    "lota:forretress",
    "lota:frillish",
    "lota:froslass",
    "lota:frosmoth",
    "lota:garchomp",
    "lota:gastly",
    "lota:gengar",
    "lota:gholdengo",
    "lota:glalie",
    "lota:gligar",
    "lota:glimmet",
    "lota:glimmora",
    "lota:gliscor",
    "lota:golbat",
    "lota:golurk",
    "lota:gossifleur",
    "lota:gourgeist",
    "lota:haunter",
    "lota:heracross",
    "lota:honchkrow",
    "lota:honedge",
    "lota:hooh",
    "lota:hoothoot",
    "lota:hoppip",
    "lota:hydreigon",
    "lota:igglybuff",
    "lota:illumise",
    "lota:inkay",
    "lota:jellicent",
    "lota:jigglypuff",
    "lota:jumpluff",
    "lota:kilowattrel",
    "lota:klang",
    "lota:klefki",
    "lota:klink",
    "lota:klinklang",
    "lota:koffing",
    "lota:kricketune",
    "lota:lampent",
    "lota:latias",
    "lota:latios",
    "lota:ledian",
    "lota:ledyba",
    "lota:lugia",
    "lota:lunatone",
    "lota:magnemite",
    "lota:magneton",
    "lota:magnezone",
    "lota:malamar",
    "lota:masquerain",
    "lota:metagross",
    "lota:metang",
    "lota:mew",
    "lota:mewtwo",
    "lota:milcery",
    "lota:misdreavus",
    "lota:mismagius",
    "lota:moltres",
    "lota:munna",
    "lota:murkrow",
    "lota:musharna",
    "lota:naganadel",
    "lota:ninjask",
    "lota:noctowl",
    "lota:noibat",
    "lota:noivern",
    "lota:pelipper",
    "lota:phantump",
    "lota:pidgeot",
    "lota:pidgeotto",
    "lota:pidgey",
    "lota:pidove",
    "lota:pikipek",
    "lota:poipole",
    "lota:poltchageist",
    "lota:polteageist",
    "lota:porygon",
    "lota:porygon2",
    "lota:porygonz",
    "lota:probopass",
    "lota:pumpkaboo",
    "lota:rabsca",
    "lota:rayquaza",
    "lota:regidrago",
    "lota:regieleki",
    "lota:reuniclus",
    "lota:revavroom",
    "lota:ribombee",
    "lota:rookidee",
    "lota:rotom",
    "lota:rowlet",
    "lota:rufflet",
    "lota:runerigus",
    "lota:salamence",
    "lota:scizor",
    "lota:scyther",
    "lota:shedinja",
    "lota:shuppet",
    "lota:sigilyph",
    "lota:sinistcha",
    "lota:sinistea",
    "lota:skarmory",
    "lota:skiploom",
    "lota:solosis",
    "lota:solrock",
    "lota:spearow",
    "lota:spritzee",
    "lota:squawkabilly",
    "lota:staraptor",
    "lota:staravia",
    "lota:starly",
    "lota:swablu",
    "lota:swanna",
    "lota:swellow",
    "lota:swirlix",
    "lota:swoobat",
    "lota:tadbulb",
    "lota:taillow",
    "lota:talonflame",
    "lota:togekiss",
    "lota:togetic",
    "lota:toucannon",
    "lota:tranquill",
    "lota:tropius",
    "lota:trumbeak",
    "lota:tynamo",
    "lota:unfezant",
    "lota:unown",
    "lota:vanillish",
    "lota:vanillite",
    "lota:vanilluxe",
    "lota:varoom",
    "lota:venomoth",
    "lota:vespiquen",
    "lota:vibrava",
    "lota:vivillon",
    "lota:volbeat",
    "lota:volcarona",
    "lota:wattrel",
    "lota:weezing",
    "lota:whimsicott",
    "lota:wigglytuff",
    "lota:wingull",
    "lota:woobat",
    "lota:xatu",
    "lota:yamask",
    "lota:yanma",
    "lota:yanmega",
    "lota:zapdos",
    "lota:zubat"
]);

export function isOriginalFlyingType(typeId) {
    return ORIGINAL_FLYING_TYPES.has(typeId);
}

export function distanceBetween(first, second) {
    return Math.hypot(
        Number(second?.x || 0) - Number(first?.x || 0),
        Number(second?.y || 0) - Number(first?.y || 0),
        Number(second?.z || 0) - Number(first?.z || 0)
    );
}

export function airFollowMode(ownerDistance, wasFollowing, sameDimension = true) {
    if (!sameDimension || ownerDistance > COBBLEMON_OWNER_FOLLOW.teleportDistance) return "teleport";
    if (wasFollowing) {
        return ownerDistance <= COBBLEMON_OWNER_FOLLOW.stopDistance ? "hold" : "follow";
    }
    return ownerDistance > COBBLEMON_OWNER_FOLLOW.startDistance ? "follow" : "hold";
}

export function ownerAirTarget(ownerLocation, ownerHeadLocation) {
    const feetY = Number(ownerLocation?.y || 0);
    const headY = Number(ownerHeadLocation?.y || feetY + 1.62);
    return {
        x: Number(ownerLocation?.x || 0),
        y: Math.max(feetY + 2.25, headY + 0.65),
        z: Number(ownerLocation?.z || 0)
    };
}

export function directAirVelocity(origin, target, maxSpeed = COBBLEMON_OWNER_FOLLOW.speed) {
    const dx = Number(target?.x || 0) - Number(origin?.x || 0);
    const dy = Number(target?.y || 0) - Number(origin?.y || 0);
    const dz = Number(target?.z || 0) - Number(origin?.z || 0);
    const distance = Math.hypot(dx, dy, dz);
    if (distance <= 0.001) return { x: 0, y: 0, z: 0 };

    const speed = Math.min(maxSpeed, Math.max(0.12, distance * 0.08));
    return {
        x: dx / distance * speed,
        y: dy / distance * speed,
        z: dz / distance * speed
    };
}

export function velocityCorrection(current, desired, epsilon = 0.003) {
    const correction = {
        x: Number(desired?.x || 0) - Number(current?.x || 0),
        y: Number(desired?.y || 0) - Number(current?.y || 0),
        z: Number(desired?.z || 0) - Number(current?.z || 0)
    };
    return Math.hypot(correction.x, correction.y, correction.z) > epsilon ? correction : undefined;
}

export function yawForVelocity(velocity) {
    const x = Number(velocity?.x || 0);
    const z = Number(velocity?.z || 0);
    if (Math.hypot(x, z) <= 0.001) return undefined;
    return Math.atan2(-x, z) * 180 / Math.PI;
}

export function shortestYawDifference(first, second) {
    return ((Number(second || 0) - Number(first || 0) + 540) % 360) - 180;
}
