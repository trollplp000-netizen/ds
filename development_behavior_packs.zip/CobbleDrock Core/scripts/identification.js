import { system, world } from "@minecraft/server";
import {
    captureSpeciesKey,
    encounteredSpecies,
    hasCapturedSpecies,
    markCaptureEncounter
} from "./capture_rate.js";
import { speciesData } from "./battle_math.js";
import { loadPartyFromPlayer, subscribePartySaved } from "./storage.js";

const IDENTIFIED_CACHE_STALE_TICKS = 20;
const PARTY_CACHE_STALE_TICKS = 40;

const identifiedCache = new Map();
const partyCache = new Map();

function cachedKeys(player, cache, staleTicks, read) {
    const tick = Number(system.currentTick) || 0;
    const cached = cache.get(player.id);
    if (cached && tick - cached.tick < staleTicks) return cached.keys;
    const keys = read(player);
    cache.set(player.id, { tick, keys });
    return keys;
}

function identifiedKeys(player) {
    return cachedKeys(player, identifiedCache, IDENTIFIED_CACHE_STALE_TICKS, candidate =>
        encounteredSpecies(candidate)
    );
}

function partySpeciesKeys(player) {
    return cachedKeys(player, partyCache, PARTY_CACHE_STALE_TICKS, candidate => {
        const keys = new Set();
        for (const pokemon of loadPartyFromPlayer(candidate)) {
            const key = captureSpeciesKey(pokemon);
            if (key) keys.add(key);
        }
        return keys;
    });
}

export function identificationSpeciesKey(value) {
    let key = "";
    if (typeof value === "string") key = captureSpeciesKey(value);
    else if (value?.species) key = captureSpeciesKey(value);
    else {
        try { key = captureSpeciesKey(String(value?.typeId || "")); } catch (error) {}
    }
    if (!key) return "";
    const baseSpecies = String(speciesData(key)?.baseSpecies || "");
    return baseSpecies ? captureSpeciesKey(baseSpecies) : key;
}

export function identify(player, pokemonOrSpeciesOrEntity) {
    const key = identificationSpeciesKey(pokemonOrSpeciesOrEntity);
    if (!player?.isValid || !key) return false;
    const wasIdentified = identifiedKeys(player).has(key);
    markCaptureEncounter(player, key);
    identifiedCache.delete(player.id);
    return !wasIdentified;
}

export function isIdentified(player, pokemonOrSpeciesOrEntity) {
    const key = identificationSpeciesKey(pokemonOrSpeciesOrEntity);
    if (!player?.isValid || !key) return false;
    if (partySpeciesKeys(player).has(key)) return true;
    return identifiedKeys(player).has(key);
}

export function anyUnidentifiedViewerNear(dimension, location, pokemonOrSpeciesOrEntity, maxDistance) {
    try {
        for (const player of world.getPlayers({ location, maxDistance, dimension })) {
            if (!isIdentified(player, pokemonOrSpeciesOrEntity)) return true;
        }
    } catch (error) {}
    return false;
}

export function hasCaughtSpecies(player, pokemonOrSpeciesOrEntity) {
    const key = identificationSpeciesKey(pokemonOrSpeciesOrEntity);
    if (!player?.isValid || !key) return false;
    if (partySpeciesKeys(player).has(key)) return true;
    try { return hasCapturedSpecies(player, key); }
    catch (error) { return false; }
}

export function anyUncaughtViewerNear(dimension, location, pokemonOrSpeciesOrEntity, maxDistance) {
    try {
        for (const player of world.getPlayers({ location, maxDistance, dimension })) {
            if (!hasCaughtSpecies(player, pokemonOrSpeciesOrEntity)) return true;
        }
    } catch (error) {}
    return false;
}

world.afterEvents.playerLeave.subscribe(event => {
    identifiedCache.delete(event.playerId);
    partyCache.delete(event.playerId);
});

subscribePartySaved(player => {
    if (player?.isValid) partyCache.delete(player.id);
});
