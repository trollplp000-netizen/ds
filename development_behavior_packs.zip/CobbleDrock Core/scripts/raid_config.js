const COMMON = Object.freeze({
    maxCheers: 3,
    raidPartySize: 1,
    multiplayerHealthMultiplier: 1.5,
    hiddenAbilityRate: 0.2,
    lives: 1,
    playersShareLives: false,
    catchRate: 1
});

function tier(values) {
    return Object.freeze({ ...COMMON, ...values });
}

export const RAID_TIERS = Object.freeze({
    1: tier({
        maxPlayers: 1,
        healthMultiplier: 5,
        bossLevel: 12,
        rewardLevel: 12,
        perfectIvs: 0,
        currency: 500,
        energy: 1,
        requiredDamage: 0.20,
        ai: "random",
        scripts: []
    }),
    2: tier({
        maxPlayers: 2,
        healthMultiplier: 7,
        bossLevel: 20,
        rewardLevel: 20,
        perfectIvs: 1,
        currency: 1500,
        energy: 2,
        requiredDamage: 0.18,
        ai: "random",
        scripts: []
    }),
    3: tier({
        maxPlayers: 3,
        healthMultiplier: 10,
        bossLevel: 35,
        rewardLevel: 35,
        perfectIvs: 2,
        currency: 3000,
        energy: 3,
        requiredDamage: 0.16,
        ai: "random",
        scripts: []
    }),
    4: tier({
        maxPlayers: 4,
        healthMultiplier: 15,
        bossLevel: 45,
        rewardLevel: 45,
        perfectIvs: 3,
        currency: 5000,
        energy: 5,
        requiredDamage: 0.16,
        ai: "random",
        scripts: [
            { hp: 0.4, actions: ["SHIELD_UP", "RESET_BOSS"] },
            { hp: 0.2, actions: ["SHIELD_DOWN"] }
        ]
    }),
    5: tier({
        maxPlayers: 4,
        healthMultiplier: 20,
        bossLevel: 75,
        rewardLevel: 75,
        perfectIvs: 4,
        currency: 10000,
        energy: 10,
        requiredDamage: 0.16,
        ai: "random",
        scripts: [
            { hp: 0.5, actions: ["SHIELD_UP", "RESET_BOSS"] },
            { hp: 0.3, actions: ["RESET_PLAYER"] },
            { hp: 0.2, actions: ["SHIELD_DOWN"] }
        ]
    }),
    6: tier({
        maxPlayers: 4,
        healthMultiplier: 25,
        bossLevel: 90,
        rewardLevel: 90,
        perfectIvs: 5,
        currency: 25000,
        energy: 15,
        requiredDamage: 0.16,
        ai: "strong",
        scripts: [
            { turn: 1, actions: ["BOSS_STAT_DEF_1"] },
            { hp: 0.6, actions: ["SHIELD_UP", "RESET_BOSS"] },
            { hp: 0.3, actions: ["RESET_PLAYER"] },
            { hp: 0.2, actions: ["SHIELD_DOWN"] }
        ]
    }),
    7: tier({
        maxPlayers: 4,
        healthMultiplier: 30,
        bossLevel: 100,
        rewardLevel: 100,
        perfectIvs: 6,
        currency: 50000,
        energy: 20,
        requiredDamage: 0.16,
        ai: "strong",
        scripts: [
            { turn: 1, actions: ["BOSS_STAT_DEF_1"] },
            { hp: 0.8, actions: ["RESET_PLAYER"] },
            { hp: 0.7, actions: ["SHIELD_UP", "RESET_BOSS"] },
            { hp: 0.3, actions: ["RESET_PLAYER"] },
            { hp: 0.2, actions: ["SHIELD_DOWN"] }
        ]
    })
});

export const RAID_MOVE_BLACKLIST = Object.freeze(new Set([
    "bestow", "circlethrow", "destinybond", "disable", "encore", "endeavor",
    "entrainment", "fissure", "guardsplit", "guillotine", "horndrill", "imprison",
    "instruct", "naturesmadness", "painsplit", "perishsong", "powersplit", "roar",
    "ruination", "sheercold", "simplebeam", "skillswap", "skydrop", "superfang",
    "taunt", "torment", "trick", "whirlwind", "worryseed"
]));

export const RAID_ABILITY_BLACKLIST = Object.freeze(new Set([
    "wonderguard", "perishbody"
]));

export function raidTierConfig(value) {
    const tierNumber = Math.floor(Number(value));
    return RAID_TIERS[tierNumber];
}

export function raidSharedMaxHealth(baseHp, tierConfig, playerCount) {
    const base = Math.max(1, Number(baseHp) || 1);
    const healthMultiplier = Math.max(1, Number(tierConfig?.healthMultiplier) || 1);
    const multiplayerMultiplier = Math.max(1, Number(tierConfig?.multiplayerHealthMultiplier) || 1);
    const players = Math.max(1, Math.floor(Number(playerCount) || 1));
    return Math.max(1, Math.floor(base * healthMultiplier * (1 + (multiplayerMultiplier - 1) * (players - 1))));
}

export function raidContributionEligible(damage, sharedMaxHp, tierConfig) {
    const maximum = Math.max(1, Number(sharedMaxHp) || 1);
    const contribution = Math.max(0, Number(damage) || 0) / maximum;
    return contribution >= Math.max(0, Number(tierConfig?.requiredDamage) || 0);
}
