import { world, system, InputButton, ButtonState } from "@minecraft/server";
import { FLIGHT_PROFILES } from "./flight_profiles.js";
import { flightParameters, jumpTransition, newFlightState, stepFlight } from "./flight_physics.js";
import { flightBank } from "./flight_view.js";
import { hasProperty, setRidingProperty, resetRidingProperty } from "./riding_properties.js";

const mounts = new Map();
const jumpPresses = new Map();
const flightHintShown = new Set();

function controlsMount(player,mount) {
    const rideable=mount.getComponent?.('minecraft:rideable');
    const riders=rideable?.getRiders?.();
    return !riders?.length || riders[rideable.controllingSeat ?? 0]?.id === player.id;
}

function clearFlightView(ride, mount) {
    if (ride?.cameraActive) {
        try {
            if (!ride.player.hasTag?.('lota:battle_player')) ride.player.camera?.clear();
            ride.player.setDynamicProperty?.('lota:flight_camera_active',undefined);
        } catch {}
        ride.cameraActive=false;
    }
    if (mount?.isValid && FLIGHT_PROFILES[mount.typeId]) {
        resetRidingProperty(mount,'lota:flight_pitch');
        resetRidingProperty(mount,'lota:flight_roll');
    }
}

world.afterEvents.playerSpawn?.subscribe(event => {
    if (event.player.getDynamicProperty('lota:flight_camera_active') === true) {
        event.player.camera.clear();
        event.player.setDynamicProperty('lota:flight_camera_active',undefined);
    }
});
world.afterEvents.playerButtonInput.subscribe(event => {
    if (event.button !== InputButton.Jump || event.newButtonState !== ButtonState.Pressed) return;
    const mount = event.player.getComponent('minecraft:riding')?.entityRidingOn;
    if (!mount || !FLIGHT_PROFILES[mount.typeId]) return;
    if (!controlsMount(event.player,mount)) return;
    const previous = jumpPresses.get(event.player.id);
    const next = jumpTransition(previous?.mountId === mount.id ? previous : {},system.currentTick,true,mount.isInWater);
    jumpPresses.set(event.player.id,{...next,mountId:mount.id});
});
world.afterEvents.playerLeave.subscribe(event => {
    jumpPresses.delete(event.playerId);
    flightHintShown.delete(event.playerId);
});

export function forgetMountFlight(mount) {
    const state = mounts.get(mount.id);
    try {
        clearFlightView(state,mount);
        if (state && mount.isValid) mount.setDynamicProperty('lota:flight_stamina',state.physics.stamina);
    } finally {
        if (state) jumpPresses.delete(state.playerId);
        mounts.delete(mount.id);
    }
}

export function updateMountFlight(player, mount) {
    if (!hasProperty(mount,'lota:ride_flying')) return;
    if (!controlsMount(player,mount)) return;
    const profile = FLIGHT_PROFILES[mount.typeId];
    if (!profile) {
        if (mount.getProperty('lota:ride_flying') === true) mount.triggerEvent('lota:stop_riding_air');
        return;
    }
    if (!mount.getComponent?.('minecraft:rideable')) return;
    let ride = mounts.get(mount.id);
    if (!ride || ride.playerId !== player.id) {
        if (ride) {
            clearFlightView(ride,mount);
            if (ride.playerId !== player.id) jumpPresses.delete(ride.playerId);
        }
        const runtimeStamina = Number(ride?.physics?.stamina);
        let stamina;
        if (Number.isFinite(runtimeStamina)) {
            stamina = Math.max(0,Math.min(1,runtimeStamina));
        } else {
            const stored = Number(mount.getDynamicProperty('lota:flight_stamina'));
            stamina = Number.isFinite(stored) ? Math.max(0,Math.min(1,stored)) : 1;
        }
        ride = {player,playerId:player.id,roll:0,params:flightParameters(profile),physics:newFlightState(mount.getRotation().y,stamina),
            air:mount.getProperty('lota:ride_flying') === true,lastTransition:system.currentTick,groundTicks:0};
        mounts.set(mount.id,ride);
        if (player.getDynamicProperty?.('lota:flight_camera_active') === true
            && !player.hasTag?.('lota:battle_player')) {
            player.camera?.clear();
            player.setDynamicProperty('lota:flight_camera_active',undefined);
        }
        if (mount.getProperty('lota:ride_active') !== true)
            mount.triggerEvent(ride.air ? 'lota:start_riding_air' : 'lota:party_rider_enter');
        if (!flightHintShown.has(player.id)) {
            player.onScreenDisplay?.setActionBar('§7Space ×2: cất cánh • Giữ Space: nâng độ cao • Ngồi/Shift: xuống Pokémon');
            flightHintShown.add(player.id);
        }
    }
    const jump = jumpPresses.get(player.id);
    if (!ride.air && jump?.takeoff && jump.mountId === mount.id && !mount.isInWater && ride.physics.stamina > 0) {
        mount.triggerEvent('lota:start_riding_air');
        ride.air = true;
        ride.lastTransition = system.currentTick;
        ride.groundTicks = 0;
        ride.physics = newFlightState(mount.getRotation().y,ride.physics.stamina);
        ride.physics.vertical = Math.min(.22,ride.params.vertical);
        jumpPresses.delete(player.id);
    }
    if (!ride.air) {
        ride.physics.stamina = Math.min(1,ride.physics.stamina+1/(20*15));
        if (system.currentTick%20 === 0) mount.setDynamicProperty('lota:flight_stamina',ride.physics.stamina);
        return;
    }
    if (mount.getProperty('lota:ride_flying') !== true) mount.triggerEvent('lota:start_riding_air');
    const movement = player.inputInfo.getMovementVector();
    const rotation = player.getRotation();
    const input = {forward:movement.y,yaw:rotation.y,pitch:rotation.x,
        strafe:movement.x,
        jump:player.inputInfo.getButtonState(InputButton.Jump) === ButtonState.Pressed,
        boost:player.isSprinting === true};
    if (ride.params.style === 'hover') {
        input.tooHigh=!mount.dimension.getBlockFromRay(mount.location,{x:0,y:-1,z:0},
            {maxDistance:ride.params.hoverHeight,includePassableBlocks:false,includeLiquidBlocks:true});
    }
    const result = stepFlight(ride.physics,input,ride.params);
    const actual = mount.getVelocity();
    const stalled = Math.hypot(actual.x,actual.z)<.02 && Math.abs(ride.physics.forward)>.1 && !mount.isOnGround;
    ride.stalledTicks = stalled ? (ride.stalledTicks || 0)+1 : 0;
    if (ride.stalledTicks >= 3) {
        result.state.forward = Math.min(result.state.forward,.1);
        result.velocity.x = 0; result.velocity.z = 0;
    }
    ride.roll = flightBank(ride.roll,result.state.yaw-ride.physics.yaw,result.state.forward,ride.params.speed);
    ride.physics = result.state;
    mount.applyImpulse({x:result.velocity.x-actual.x,y:result.velocity.y-actual.y,z:result.velocity.z-actual.z});
    mount.setRotation({x:0,y:ride.physics.yaw});
    setRidingProperty(mount,'lota:flight_pitch',ride.physics.pitch);
    setRidingProperty(mount,'lota:flight_roll',ride.roll);
    ride.groundTicks = mount.isOnGround && result.velocity.y<=0 ? ride.groundTicks+1 : 0;
    if ((system.currentTick-ride.lastTransition>=10 && ride.groundTicks>=3) || mount.isInWater) {
        mount.triggerEvent('lota:stop_riding_air');
        mount.clearVelocity();
        ride.air = false;
        clearFlightView(ride,mount);
        ride.lastTransition = system.currentTick;
        jumpPresses.delete(player.id);
    }
    if (system.currentTick%20 === 0) mount.setDynamicProperty('lota:flight_stamina',ride.physics.stamina);
}

