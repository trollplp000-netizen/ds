export const PASTURE = Object.freeze({ limit: 16, ticks: 40, radius: 36, perChunk: 4, viewDistance: 8 });
export const PASTURE_PREFIX = "lota:pasture_v1:";
export const PASTURE_TAG = "lota:pastured_pokemon";

export function pastureKey(dimensionId, location) {
    return `${PASTURE_PREFIX}${dimensionId}:${location.x},${location.y},${location.z}`;
}

export function inPastureBounds(position, anchor, radius = PASTURE.radius) {
    return ["x", "y", "z"].every(axis => position[axis] >= anchor[axis] - radius
        && position[axis] < anchor[axis] + radius);
}

export function canViewPasture(player, record) {
    return !!player?.isValid && !player.hasTag("lota:battle_player")
        && player.dimension.id === record.dimensionId
        && Math.hypot(...["x", "y", "z"].map(axis => player.location[axis] - record.location[axis] - 0.5)) <= PASTURE.viewDistance;
}

export function pastureAppearance(pokemon) {
    const result = {};
    for (const key of ["uuid", "species", "form", "aspects", "nickname", "level", "gender", "isShiny",
        "caughtBall", "cosmeticSkin", "spawnProperties", "evolutionProperties", "currentHp", "maxHp"]) {
        if (pokemon[key] !== undefined) result[key] = JSON.parse(JSON.stringify(pokemon[key]));
    }
    return result;
}

export function pastureBreedingSnapshot(pokemon) {
    const result = {};
    for (const key of ["uuid", "species", "form", "aspects", "level", "gender", "isShiny", "caughtBall", "ability",
        "nature", "mintedNature", "heldItem", "heldItemData", "ivs", "moves", "benchedMoves", "relearnableMoves", "originalTrainer", "neutered"]) {
        if (pokemon[key] !== undefined) result[key] = JSON.parse(JSON.stringify(pokemon[key]));
    }
    return result;
}

function pastureMoveId(move) {
    return String(typeof move === "string" ? move : move?.id || "")
        .replace(/^.*:/, "").toLowerCase();
}

export function mergePasturePendingMoves(pokemon, pendingMoves) {
    if (!pokemon || typeof pokemon !== "object") return { pokemon, changed: false };
    const result = JSON.parse(JSON.stringify(pokemon));
    const known = new Set();
    for (const move of [...(result.moves || []), ...(result.benchedMoves || []), ...(result.relearnableMoves || [])]) {
        const id = pastureMoveId(move);
        if (id) known.add(id);
    }
    if (!Array.isArray(result.benchedMoves)) result.benchedMoves = [];
    let changed = false;
    for (const move of pendingMoves || []) {
        const id = pastureMoveId(move);
        if (!id || known.has(id)) continue;
        result.benchedMoves.push(id);
        known.add(id);
        changed = true;
    }
    return { pokemon: result, changed };
}

export function validPastureRecord(record, key) {
    return record?.version === 1 && typeof record.id === "string" && record.id.length > 0
        && typeof record.dimensionId === "string" && record.location
        && ["x", "y", "z"].every(axis => Number.isInteger(record.location[axis]))
        && pastureKey(record.dimensionId, record.location) === key
        && Array.isArray(record.members) && record.members.length <= PASTURE.limit
        && record.members.every(member => typeof member.ownerId === "string" && member.ownerId.length > 0
            && typeof member.uuid === "string" && member.uuid.length > 0
            && typeof member.lease === "string" && member.lease.length > 0
            && member.appearance?.uuid === member.uuid && typeof member.appearance.species === "string"
            && (member.breeding === undefined || (member.breeding?.uuid === member.uuid && typeof member.breeding.species === "string"))
            && (member.pendingMirrorMoves === undefined || (Array.isArray(member.pendingMirrorMoves)
                && member.pendingMirrorMoves.length <= 256
                && member.pendingMirrorMoves.every(move => typeof move === "string" && move.length > 0 && move.length <= 128))))
        && new Set(record.members.map(member => `${member.ownerId}/${member.uuid}`)).size === record.members.length
        && new Set(record.members.map(member => member.lease)).size === record.members.length;
}

export function writePastureRecord(properties, key, record) {
    if (record !== undefined && !validPastureRecord(record, key)) return false;
    let previous;
    let readPrevious = false;
    try {
        previous = properties.getDynamicProperty(key);
        readPrevious = true;
        const serialized = record === undefined ? undefined : JSON.stringify(record);
        properties.setDynamicProperty(key, serialized);
        if (properties.getDynamicProperty(key) === serialized) return true;
    } catch (error) { }
    if (readPrevious) { try { properties.setDynamicProperty(key, previous); } catch (error) {} }
    return false;
}

export function resolvePastureMember(record, entityLink) {
    if (!record || record.id !== entityLink?.pastureId) return undefined;
    return record.members.find(member => member.ownerId === entityLink.ownerId
        && member.uuid === entityLink.uuid && member.lease === entityLink.lease);
}

export function pasturablePokemon(pokemon, partyIds, alreadyTethered) {
    return !!pokemon?.uuid && !!pokemon.species && Number(pokemon.currentHp) > 0
        && !partyIds.has(pokemon.uuid) && !alreadyTethered;
}

const PASSABLE_BLOCK_NAMES = new Set([
    "short_grass", "tallgrass", "fern", "large_fern", "deadbush", "dead_bush", "snow_layer", "tripwire",
    "reeds", "sugar_cane", "bamboo_sapling", "small_dripleaf", "big_dripleaf", "nether_sprouts",
    "crimson_fungus", "warped_fungus", "weeping_vines", "twisting_vines", "vine", "glow_lichen"
]);
const PASSABLE_BLOCK_SUFFIXES = ["_flower", "_sapling", "_torch", "_carpet", "_button", "_pressure_plate",
    "_rail", "_mushroom", "_roots", "_azalea"];
function blockType(block) {
    try { return String(block?.typeId || "").toLowerCase(); } catch { return ""; }
}
function blockFlag(block, name) {
    try { return typeof block?.[name] === "boolean" ? block[name] : undefined; } catch { return undefined; }
}
function isWater(block, type = blockType(block)) {
    if (["minecraft:water", "minecraft:flowing_water"].includes(type)) return true;
    return blockFlag(block, "isLiquid") === true && !type.includes("lava");
}
function isPassableSpace(block, type = blockType(block)) {
    if (!block) return false;
    if (blockFlag(block, "isAir") === true || type.endsWith(":air")) return true;
    const name = type.split(":").pop();
    return PASSABLE_BLOCK_NAMES.has(name) || PASSABLE_BLOCK_SUFFIXES.some(suffix => name.endsWith(suffix));
}
function isSolidSupport(block, type = blockType(block)) {
    const solid = blockFlag(block, "isSolid");
    if (solid === true) return true;
    return solid === undefined && !!type && !isPassableSpace(block, type)
        && blockFlag(block, "isLiquid") !== true && !type.includes("lava");
}

export function findPasturePosition(record, profile, getBlock, occupied = []) {
    const directions = { north: [0, -1], south: [0, 1], east: [1, 0], west: [-1, 0] };
    const [dx, dz] = directions[record.facing] || directions.north;
    const width = Math.max(0.1, profile.width), height = Math.max(0.1, profile.height);
    const half = width / 2;
    const dangerous = new Set(["minecraft:lava", "minecraft:flowing_lava", "minecraft:fire", "minecraft:soul_fire",
        "minecraft:magma", "minecraft:magma_block", "minecraft:cactus", "minecraft:campfire", "minecraft:soul_campfire", "minecraft:powder_snow"]);
    for (let step = 0; step < 6; step++) {
        const distance = Math.ceil(width) + 2 + step;
        const x = record.location.x + 0.5 + dx * distance;
        const z = record.location.z + 0.5 + dz * distance;
        for (const dy of [0, ...Array.from({ length: 15 }, (_, i) => i + 1), ...Array.from({ length: 15 }, (_, i) => -i - 1)]) {
            const y = record.location.y + dy;
            if (!inPastureBounds({ x, y, z }, record.location)) continue;
            if (occupied.some(other => Math.abs(x - other.x) < half + other.width / 2
                && Math.abs(z - other.z) < half + other.width / 2 && y < other.y + other.height && y + height > other.y)) continue;
            let safe = true;
            for (let bx = Math.floor(x - half + 0.001); safe && bx <= Math.floor(x + half - 0.001); bx++) {
                for (let bz = Math.floor(z - half + 0.001); safe && bz <= Math.floor(z + half - 0.001); bz++) {
                    const floor = getBlock({ x: bx, y: y - 1, z: bz });
                    const feet = getBlock({ x: bx, y, z: bz });
                    const floorType = blockType(floor), feetType = blockType(feet);
                    if (!floor || !feet || dangerous.has(floorType)
                        || (profile.waterOnly ? !isWater(feet, feetType) : !(isSolidSupport(floor, floorType) || (profile.swims && isWater(floor, floorType))))) { safe = false; break; }
                    for (let by = y; by < Math.ceil(y + height); by++) {
                        const block = getBlock({ x: bx, y: by, z: bz });
                        const type = blockType(block);
                        if (!block || dangerous.has(type) || (!isPassableSpace(block, type) && !(profile.swims && isWater(block, type)))) { safe = false; break; }
                    }
                }
            }
            if (safe) return { x, y, z };
        }
    }
    return undefined;
}
