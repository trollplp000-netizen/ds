import { system, world } from "@minecraft/server";
import {
    POKE_BALL_IDS,
    POKE_BALL_ID_SET,
    withPokeBallTooltip
} from "./poke_ball_tooltip_data.js";

function scheduleChangedStackDecoration(event) {
    const expected = event.itemStack;
    if (!expected || !POKE_BALL_ID_SET.has(expected.typeId)) return;
    system.run(() => {
        const player = event.player;
        if (!player?.isValid) return;
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) return;

        const candidates = [event.slot];
        if (event.inventoryType === "Inventory" && event.slot + 9 < container.size) {
            candidates.push(event.slot + 9);
        }

        const matchingSlots = [...new Set(candidates)].filter(slot => {
            const stack = container.getItem(slot);
            return stack?.typeId === expected.typeId && stack.amount === expected.amount;
        });
        if (matchingSlots.length !== 1) return;

        const slot = matchingSlots[0];
        const stack = container.getItem(slot);
        try {
            const updatedLore = withPokeBallTooltip(stack.typeId, stack.getRawLore());
            if (!updatedLore) return;
            stack.setLore(updatedLore);
            container.setItem(slot, stack);
        } catch (error) {
            console.warn(`Poke Ball tooltip failed for ${stack.typeId}: ${error}`);
        }
    });
}

const inventoryChange = world.afterEvents.playerInventoryItemChange;
if (inventoryChange?.subscribe) {
    inventoryChange.subscribe(scheduleChangedStackDecoration, {
        includeItems: POKE_BALL_IDS
    });
}
