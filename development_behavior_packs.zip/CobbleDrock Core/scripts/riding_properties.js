export function hasProperty(entity, name) {
    try { return !!entity?.isValid && entity.getProperty(name) !== undefined; }
    catch { return false; }
}

export function setRidingProperty(entity, name, value) {
    if (!hasProperty(entity,name)) return false;
    try { entity.setProperty(name,value); return true; }
    catch (error) {
        if (!hasProperty(entity,name)) return false;
        throw error;
    }
}

export function resetRidingProperty(entity, name) {
    if (!hasProperty(entity,name)) return false;
    try { entity.resetProperty(name); return true; }
    catch (error) {
        if (!hasProperty(entity,name)) return false;
        throw error;
    }
}

export function createRidingWarningReporter(warn = message => console.warn(message)) {
    const previous = new Map();
    return {
        report(key, message) {
            if (previous.get(key) === message) return;
            previous.set(key,message);
            warn(message);
        },
        clear(key) { previous.delete(key); }
    };
}

