import { ScriptEventSource, system } from "@minecraft/server";
import { SPECIES_DATA as CORE_SPECIES_DATA } from "./battle_species.js";

export const SPECIES_REGISTER_REQUEST_EVENT = "lota:server_species_register_v1";
export const SPECIES_REGISTER_RESULT_EVENT = "lota:server_species_register_result_v1";
export const SPECIES_DATA = { ...CORE_SPECIES_DATA };

const externalProviders = new Map();
const portraitGlyphs = new Map();
const glyphProviders = new Map();
const registryChangedListeners = new Set();

export const REGIONAL_FORM_PORTRAIT_GLYPHS = Object.freeze(Object.fromEntries([
    "rattata_alola", "raticate_alola", "raichu_alola", "sandshrew_alola", "sandslash_alola",
    "vulpix_alola", "ninetales_alola", "diglett_alola", "dugtrio_alola", "meowth_alola",
    "persian_alola", "geodude_alola", "graveler_alola", "golem_alola", "grimer_alola",
    "muk_alola", "exeggutor_alola", "marowak_alola",
    "corsola_galar", "farfetchd_galar", "linoone_galar", "meowth_galar", "mrmime_galar",
    "ponyta_galar", "rapidash_galar", "slowbro_galar", "slowking_galar", "slowpoke_galar",
    "stunfisk_galar", "weezing_galar", "yamask_galar", "zigzagoon_galar",
    "avalugg_hisui", "braviary_hisui", "decidueye_hisui", "electrode_hisui", "goodra_hisui",
    "lilligant_hisui", "qwilfish_hisui", "samurott_hisui", "sliggoo_hisui", "sneasel_hisui",
    "typhlosion_hisui", "voltorb_hisui", "zoroark_hisui", "zorua_hisui",
    "tauros_paldea_aqua", "tauros_paldea_blaze", "tauros_paldea_combat", "wooper_paldea"
].map((species, index) => [species, 0xF800 + index])));
for (const [species, codepoint] of Object.entries(REGIONAL_FORM_PORTRAIT_GLYPHS)) {
    glyphProviders.set(codepoint, species);
}
const MAX_EXTERNAL_SPECIES = 256;
const STAT_KEYS = ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"];
const TYPES = new Set([
    "normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison", "ground",
    "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy"
]);

function cleanKey(value, maxLength = 64) {
    const key = String(value || "").trim().toLowerCase();
    return key.length <= maxLength && !["__proto__", "prototype", "constructor"].includes(key)
        && /^[a-z0-9][a-z0-9_.-]*$/.test(key) ? key : "";
}

function finiteInteger(value, minimum, maximum) {
    const number = Number(value);
    return Number.isInteger(number) && number >= minimum && number <= maximum ? number : undefined;
}

function finiteNumber(value, minimum, maximum) {
    const number = Number(value);
    return Number.isFinite(number) && number >= minimum && number <= maximum ? number : undefined;
}

function validatedSpeciesData(source) {
    if (!source || typeof source !== "object" || Array.isArray(source)) return undefined;
    const pokedex = finiteInteger(source.pokedex, 1, 1025);
    const name = String(source.name || "").trim();
    const types = Array.isArray(source.types) ? source.types : [];
    const stats = source.baseStats;
    if (!pokedex || !name || name.length > 80 || types.length < 1 || types.length > 2
        || types.some(type => !TYPES.has(type)) || !stats || typeof stats !== "object") return undefined;
    const baseStats = {};
    for (const key of STAT_KEYS) {
        baseStats[key] = finiteInteger(stats[key], 1, 255);
        if (baseStats[key] === undefined) return undefined;
    }
    const catchRate = finiteInteger(source.catchRate, 1, 255);
    const baseExperienceYield = finiteInteger(source.baseExperienceYield, 1, 1000);
    const experienceGroup = cleanKey(source.experienceGroup, 32);
    if (catchRate === undefined || baseExperienceYield === undefined || !experienceGroup) return undefined;
    if (!Array.isArray(source.levelMoves) || source.levelMoves.length > 128) return undefined;
    const levelMoves = [];
    for (const move of source.levelMoves) {
        const level = finiteInteger(move?.level, 1, 100);
        const id = cleanKey(move?.id, 48);
        if (!level || !id) return undefined;
        levelMoves.push(Object.freeze({ level, id }));
    }
    const result = { pokedex, name, types: Object.freeze([...types]), baseStats: Object.freeze(baseStats),
        catchRate, baseExperienceYield, experienceGroup, levelMoves: Object.freeze(levelMoves) };
    if (source.portraitGlyph !== undefined) {
        const codepoint = finiteInteger(source.portraitGlyph, 0xF000, 0xF8FF);
        if (codepoint === undefined) return undefined;
        result.portraitGlyph = codepoint;
    }
    for (const key of ["maleRatio", "baseFriendship", "height", "weight", "baseScale"]) {
        if (source[key] === undefined) continue;
        const value = finiteNumber(source[key], key === "maleRatio" ? -1 : 0, 100000);
        if (value === undefined) return undefined;
        result[key] = value;
    }
    if (Array.isArray(source.abilities)) {
        if (source.abilities.length > 8) return undefined;
        const abilities = source.abilities.map(value => String(value || "").trim().toLowerCase());
        if (abilities.some(value => !/^(h:)?[a-z0-9_]{1,48}$/.test(value))) return undefined;
        result.abilities = Object.freeze(abilities);
    }
    if (source.hitbox && typeof source.hitbox === "object" && !Array.isArray(source.hitbox)) {
        const width = finiteNumber(source.hitbox.width, 0.1, 64);
        const height = finiteNumber(source.hitbox.height, 0.1, 64);
        if (width === undefined || height === undefined) return undefined;
        result.hitbox = Object.freeze({ width, height, fixed: !!source.hitbox.fixed });
    }
    return Object.freeze(result);
}

export function registerExternalSpecies(request) {
    if (Number(request?.version) !== 1) return { outcome: "rejected", reason: "unsupported_version" };
    const addonId = cleanKey(request.addonId);
    const species = cleanKey(request.species);
    if (!addonId || !species) return { outcome: "rejected", reason: "invalid_identity" };
    if (Object.prototype.hasOwnProperty.call(CORE_SPECIES_DATA, species)) {
        return { outcome: "rejected", reason: "core_species" };
    }
    const existing = externalProviders.get(species);
    if (existing && existing !== addonId) return { outcome: "rejected", reason: "species_conflict" };
    if (!existing && externalProviders.size >= MAX_EXTERNAL_SPECIES) return { outcome: "rejected", reason: "registry_full" };
    const data = validatedSpeciesData(request.data);
    if (!data) return { outcome: "rejected", reason: "invalid_species_data" };
    const glyphOwner = glyphProviders.get(data.portraitGlyph);
    if (data.portraitGlyph && glyphOwner && glyphOwner !== species) {
        return { outcome: "rejected", reason: "portrait_glyph_conflict" };
    }
    SPECIES_DATA[species] = data;
    externalProviders.set(species, addonId);
    if (data.portraitGlyph) {
        glyphProviders.set(data.portraitGlyph, species);
        if (!Object.values(CORE_SPECIES_DATA).some(record => Number(record.pokedex) === data.pokedex)) {
            portraitGlyphs.set(data.pokedex, data.portraitGlyph);
        }
    }
    for (const listener of registryChangedListeners) {
        try { listener(species, data); } catch (error) {
            console.warn(`[SpeciesRegistry] Registry listener failed: ${error}`);
        }
    }
    return { outcome: "registered", reason: "", species };
}

export function subscribeSpeciesRegistryChanged(listener) {
    if (typeof listener !== "function") return () => {};
    registryChangedListeners.add(listener);
    return () => registryChangedListeners.delete(listener);
}

export function speciesPortraitGlyph(species) {
    const key = String(species || "").replace(/^.*:/, "").toLowerCase();
    return Object.prototype.hasOwnProperty.call(REGIONAL_FORM_PORTRAIT_GLYPHS, key)
        ? REGIONAL_FORM_PORTRAIT_GLYPHS[key]
        : 0;
}

export function pokemonPortraitGlyph(dex) {
    const number = Math.max(0, Math.min(1025, Math.floor(Number(dex) || 0)));
    return portraitGlyphs.get(number) || (0xE200 + number);
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== SPECIES_REGISTER_REQUEST_EVENT || event.sourceType !== ScriptEventSource.Server) return;
    let request;
    try {
        request = JSON.parse(String(event.message || ""));
    } catch (error) {
        return;
    }
    system.run(() => {
        const result = registerExternalSpecies(request);
        try {
            system.sendScriptEvent(SPECIES_REGISTER_RESULT_EVENT, JSON.stringify({
                version: 1,
                requestId: String(request?.requestId || "").slice(0, 80),
                addonId: String(request?.addonId || "").slice(0, 64),
                species: String(request?.species || "").slice(0, 64),
                ...result
            }));
        } catch (error) {
            console.warn(`[SpeciesRegistry] Registration result failed: ${error}`);
        }
    });
});
