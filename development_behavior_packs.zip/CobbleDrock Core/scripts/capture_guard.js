const activeWildCaptureIds = new Set();

function captureTargetId(target) {
    if (typeof target === "string") return target;
    return String(target?.id || "");
}

export function wildCaptureInProgress(target) {
    const targetId = captureTargetId(target);
    return !!targetId && activeWildCaptureIds.has(targetId);
}

export function tryLockWildCapture(target) {
    const targetId = captureTargetId(target);
    if (!targetId || activeWildCaptureIds.has(targetId)) return false;
    activeWildCaptureIds.add(targetId);
    return true;
}

export function unlockWildCapture(target) {
    const targetId = captureTargetId(target);
    return !!targetId && activeWildCaptureIds.delete(targetId);
}
