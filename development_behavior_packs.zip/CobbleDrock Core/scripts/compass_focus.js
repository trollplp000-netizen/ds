import { world, system, EquipmentSlot } from "@minecraft/server";

const COMPASS_ITEM = "lota:pokemon_compass";
const FOCUS_ENTITY = "lota:compass_focus";
const FOCUS_TAG = "lota:compass_focus";
const FOCUS_DISTANCE = 1.6;
const MIN_FOCUS_DISTANCE = 0.35;
const WALL_CLEARANCE = 0.25;
const EFFECT_REFRESH_INTERVAL = 200;
const ORPHAN_SWEEP_INTERVAL = 60;

const KNOWN_DIMENSION_IDS = [
    "minecraft:overworld", "minecraft:nether", "minecraft:the_end",
    "overworld", "nether", "the_end"
];

const focusEntities = new Map();

function isHoldingCompass(player) {
    try {
        const equippable = player.getComponent("minecraft:equippable");
        return equippable?.getEquipment(EquipmentSlot.Mainhand)?.typeId === COMPASS_ITEM;
    } catch (error) {
        return false;
    }
}

function isEmptyHanded(player) {
    try {
        const equippable = player.getComponent("minecraft:equippable");
        return !equippable?.getEquipment(EquipmentSlot.Mainhand);
    } catch (error) {
        return false;
    }
}

export function wantsThrowFocus(player) {
    try {
        return !!player.isSneaking && isEmptyHanded(player);
    } catch (error) {
        return false;
    }
}

function distanceBetween(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function focusLocationFor(player) {
    const eye = player.getHeadLocation();
    const view = player.getViewDirection();
    let distance = FOCUS_DISTANCE;

    try {
        const hit = player.dimension.getBlockFromRay(eye, view, { maxDistance: FOCUS_DISTANCE });
        if (hit?.block) {
            const hitDistance = distanceBetween(eye, hit.faceLocation);
            distance = Math.max(MIN_FOCUS_DISTANCE, hitDistance - WALL_CLEARANCE);
        }
    } catch (error) {}

    return {
        x: eye.x + view.x * distance,
        y: eye.y + view.y * distance,
        z: eye.z + view.z * distance
    };
}

function despawnFocus(playerId) {
    if (!playerId) return;
    const entity = focusEntities.get(playerId);
    focusEntities.delete(playerId);
    if (entity?.isValid) {
        try { entity.remove(); } catch (error) {}
    }
}

function spawnFocus(player) {
    try {
        const entity = player.dimension.spawnEntity(FOCUS_ENTITY, focusLocationFor(player));
        entity.addTag(FOCUS_TAG);
        try { entity.addEffect("invisibility", 400, { amplifier: 1, showParticles: false }); } catch (error) {}
        focusEntities.set(player.id, entity);
    } catch (error) {}
}

function updateFocusForPlayer(player) {
    let holding = false;
    try {
        if (!player.hasTag("lota:battle_player")) {
            holding = isHoldingCompass(player) || wantsThrowFocus(player);
        }
    } catch (error) { holding = false; }

    const existing = focusEntities.get(player.id);

    if (!holding) {
        if (existing) despawnFocus(player.id);
        return;
    }

    const location = focusLocationFor(player);
    const rotation = player.getRotation();

    if (existing?.isValid && existing.dimension.id === player.dimension.id) {
        try { existing.teleport(location, { rotation }); }
        catch (error) {}
        return;
    }

    if (existing) despawnFocus(player.id);
    spawnFocus(player);
}

function sweepOrphanedFocusEntities() {
    const trackedIds = new Set();
    for (const entity of focusEntities.values()) {
        if (entity?.isValid) trackedIds.add(entity.id);
    }
    for (const dimensionId of KNOWN_DIMENSION_IDS) {
        let dimension;
        try { dimension = world.getDimension(dimensionId); } catch (error) { continue; }
        let found;
        try { found = dimension.getEntities({ type: FOCUS_ENTITY }); } catch (error) { continue; }
        for (const entity of found) {
            if (trackedIds.has(entity.id)) continue;
            try { entity.remove(); } catch (error) {}
        }
    }
}

let nextEffectRefresh = 0;
let nextOrphanSweep = 0;

system.runInterval(() => {
    const activeIds = new Set();
    for (const player of world.getPlayers()) {
        if (!player.isValid) continue;
        activeIds.add(player.id);
        updateFocusForPlayer(player);
    }
    for (const playerId of [...focusEntities.keys()]) {
        if (!activeIds.has(playerId)) despawnFocus(playerId);
    }

    if (system.currentTick >= nextEffectRefresh) {
        nextEffectRefresh = system.currentTick + EFFECT_REFRESH_INTERVAL;
        for (const entity of focusEntities.values()) {
            if (!entity?.isValid) continue;
            try { entity.addEffect("invisibility", 400, { amplifier: 1, showParticles: false }); }
            catch (error) {}
        }
    }

    if (system.currentTick >= nextOrphanSweep) {
        nextOrphanSweep = system.currentTick + ORPHAN_SWEEP_INTERVAL;
        sweepOrphanedFocusEntities();
    }
}, 1);

system.runTimeout(() => sweepOrphanedFocusEntities(), 20);

world.afterEvents.playerLeave.subscribe(event => despawnFocus(event.playerId));
world.afterEvents.entityDie.subscribe(event => {
    const entity = event.deadEntity;
    if (entity?.typeId === FOCUS_ENTITY) {
        for (const [playerId, tracked] of focusEntities) {
            if (tracked?.id === entity.id) {
                focusEntities.delete(playerId);
                break;
            }
        }
    }
});
