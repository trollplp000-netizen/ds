import { ScriptEventSource, world, system, ItemStack } from "@minecraft/server";
import {
    battleCaptureContext,
    isBattleCaptureInProgress,
    subscribeBattleHudCleared,
    tryCaptureBattlePokemon
} from "./battle_system.js";
import "./apricorn_system.js";
import "./berry_mint_system.js";
import "./berry_mint_item_system.js";
import "./battle_item_tooltips.js";
import "./poke_ball_tooltips.js";
import "./experience_item_system.js";
import "./evolution_stone_ore_system.js";
import "./healing_machine.js";
import "./pc_system.js";
import "./tm_machine_system.js";
import "./pasture_system.js";
import { subscribeSelectedPartySlotChanged } from "./pokemon_compass.js";
import "./compass_focus.js";
import "./pokemon_interaction.js";
import "./flight_riding.js";
import "./shoulder_mount.js";
import "./evolution_world_progress.js";
import "./pokedex_system.js";
import "./badge_case_screen.js";
import "./starter_selection.js";
import "./storage_maintenance.js";
import "./entity_property_repair.js";
import "./core_menu.js";
import "./party_slot_arrows.js";
import "./natural_spawning.js";
import "./server_content_api.js";
import "./raid_system.js";
import "./pokemon_trade.js";
import "./pokemon_skin_api.js";
import "./addon_api.js";
import "./alpha_system.js";
import { SPAWN_LEVELS } from "./spawn_levels.js";
import {
    CAPTURE_BALLS,
    applyCaptureBallEffects,
    calculateCaptureRate,
    captureBallCode,
    captureBallForItem,
    captureBallForProjectile,
    captureRateStateToken,
    captureSpeciesKey,
    formatCapturePercentage,
    hasCaptureEncounter,
    markCaptureEncounter,
    markSpeciesCaptured,
    rollCaptureOutcome
} from "./capture_rate.js";
import { speciesData } from "./battle_math.js";
import { speciesPortraitGlyph, subscribeSpeciesRegistryChanged } from "./species_registry.js";
import {
    addPokemonExperience,
    experienceProgress,
    normalizePokemonExperience
} from "./experience.js";
import {
    generateRandomPokemon,
    savePokemonToEntity,
    loadPokemonFromEntity,
    addPokemonToPlayerParty,
    loadPartyFromPlayer,
    savePartyToPlayer,
    subscribePartySaved
} from "./storage.js";
import { forgetHudTitlePlayer, setHudTitleBase } from "./hud_title_bridge.js";
import { getEffectiveLevelCap } from "./level_cap.js";
import { heldItemPartyHudCode } from "./held_items.js";
import { playCaptureMotion } from "./capture_animation.js";
import { tryLockWildCapture, unlockWildCapture } from "./capture_guard.js";
import { applyWildPokemonNameTags } from "./pokemon_nametag_display.js";
import {
    partyActiveMarker,
    partyActivityMarkers,
    partyGenderMarkers,
    partyStatusCode
} from "./party_hud_presentation.js";
import { partyEffectsFor, dropPartyEffects } from "./party_hud_effects.js";

const BALL_PROJECTILES = new Set(Object.values(CAPTURE_BALLS).map(ball => ball.projectileId));
const BATTLE_TAG = "lota:in_battle";

const PARTY_HUD_STAY_TICKS = 20 * 60 * 60 * 24;
const PARTY_HUD_REFRESH_EVENT = "lota:server_party_hud_refresh_v1";
const PARTY_DIMENSION_IDS = Object.freeze([
    "minecraft:overworld", "minecraft:nether", "minecraft:the_end",
    "overworld", "nether", "the_end", "lota:wild_world", "lota:island_world"
]);

function isPokemonEntity(entity) {
    if (!entity || !entity.isValid) return false;
    const typeId = entity.typeId;
    return typeId.startsWith("lota:")
        && !typeId.endsWith("_projectile")
        && typeId !== "lota:poke_ball_capture"
        && !!speciesData(typeId);
}

function pokemonDisplayName(pokemon) {
    const species = String(pokemon?.species || "").replace("lota:", "").toLowerCase();
    return pokemon?.nickname || speciesData(species)?.name || species || "Unknown";
}

function retireBallProjectile(projectile, delayTicks = 4) {
    if (!projectile) return;
    try { projectile.addTag("lota:hit_processed"); } catch (error) {}
    try { projectile.clearVelocity(); } catch (error) {}
    system.runTimeout(() => {
        try { if (projectile.isValid) projectile.remove(); } catch (error) {}
    }, delayTicks);
}

function projectileThrower(projectile, source) {
    if (source?.typeId === "minecraft:player") return source;
    try {
        const owner = projectile?.getComponent("minecraft:projectile")?.owner;
        return owner?.typeId === "minecraft:player" ? owner : undefined;
    } catch (error) {
        return undefined;
    }
}

function isCreativePlayer(player) {
    try { return String(player?.getGameMode?.() || "").toLowerCase().includes("creative"); }
    catch (error) { return false; }
}

function throwerFromProjectile(projectile) {
    try {
        const owner = projectile?.getComponent("minecraft:projectile")?.owner;
        return owner?.typeId === "minecraft:player" ? owner : undefined;
    } catch (error) {
        return undefined;
    }
}

function returnBallToThrower(thrower, ball) {
    if (!thrower?.isValid || !ball?.itemId || isCreativePlayer(thrower)) return false;
    try {
        const container = thrower.getComponent("minecraft:inventory")?.container;
        if (!container) return false;
        const remainder = container.addItem(new ItemStack(ball.itemId, 1));
        if (!remainder) return true;
        try { thrower.dimension.spawnItem(remainder, thrower.location); } catch (error) {}
        return true;
    } catch (error) {
        return false;
    }
}

function dropBallItem(projectile, ball) {
    if (!projectile || !ball?.itemId) return;
    const dimension = projectile.dimension;
    const location = projectile.location;
    const dropLocation = { x: location.x, y: location.y + 0.5, z: location.z };
    try { projectile.addTag("lota:hit_processed"); } catch (error) {}
    try { projectile.clearVelocity(); } catch (error) {}
    system.runTimeout(() => {
        try {
            dimension.spawnItem(new ItemStack(ball.itemId, 1), dropLocation);
            if (projectile.isValid) projectile.remove();
        } catch (error) {
            console.warn(`Poké Ball drop failed: ${error}`);
        }
    }, 3);
}

function pokemonOwnerId(entity) {
    try {
        return String(entity?.getDynamicProperty("lota:party_owner_id") || "");
    } catch (error) {
        return "";
    }
}

function restoreWildPokemon(dimension, pokemonId, location, pokemonData, capturer, renderScale) {
    try {
        const restored = dimension.spawnEntity(pokemonId, location);
        savePokemonToEntity(restored, pokemonData);
        try {
            const preservedScale = Number(renderScale);
            restored.setProperty(
                "lota:scale_factor",
                Number.isFinite(preservedScale) ? Math.max(0.8, Math.min(1.2, preservedScale)) : Math.random() * 0.4 + 0.8
            );
        } catch (error) {}
        try { restored.setProperty("lota:is_shiny", pokemonData.isShiny ? 1.0 : 0.0); } catch (error) {}
        applyWildPokemonNameTags(restored, pokemonData);
        return restored;
    } catch (error) {
        console.warn(`Wild Pokemon restore failed: ${error}`);
        return null;
    }
}

function captureBlockReason(entity, pokemonData, thrower) {
    if (thrower?.typeId !== "minecraft:player") return "The ball has no valid thrower.";
    if (pokemonOwnerId(entity)) return "Owned Pokemon cannot be captured.";
    if (entity.hasTag("lota:uncatchable") || entity.hasTag("lota:battle_clone")
        || pokemonData?.uncatchable === true || pokemonData?.isBattleClone === true) {
        return "This Pokemon cannot be captured.";
    }
    try {
        if ((entity.getComponent("minecraft:health")?.currentValue || 0) <= 0) {
            return "Fainted Pokemon cannot be captured.";
        }
    } catch (error) {}
    return "";
}






function beginCapture(projectile, hitPokemon, source) {
    let lockedCaptureTarget;
    try {
        if (!projectile || !projectile.isValid) return;
        if (projectile.hasTag("lota:party_summon_ball")) return;
        if (!BALL_PROJECTILES.has(projectile.typeId)) return;
        if (projectile.hasTag("lota:hit_processed")) return;
        if (!isPokemonEntity(hitPokemon)) return;
        const ball = captureBallForProjectile(projectile.typeId);
        if (!ball) return;
        const thrower = projectileThrower(projectile, source);
        if (hitPokemon.hasTag(BATTLE_TAG)) {
            if (isBattleCaptureInProgress(hitPokemon)) {
                dropBallItem(projectile, ball);
                return;
            }
            if (!tryCaptureBattlePokemon(projectile, hitPokemon, source)) {
                retireBallProjectile(projectile);
            }
            return;
        }
        const dimension = projectile.dimension;

                    projectile.addTag("lota:hit_processed");

                    const pokemonId = hitPokemon.typeId;

                    const pokemonData = loadPokemonFromEntity(hitPokemon) || generateRandomPokemon(pokemonId, 15);

                    const projectileOwner = thrower;
                    const blockReason = captureBlockReason(hitPokemon, pokemonData, projectileOwner);
                    if (blockReason) {
                        try { projectileOwner?.sendMessage(`§c${blockReason}`); } catch (error) {}
                        try {
                            const creative = String(projectileOwner?.getGameMode?.() || "").toLowerCase().includes("creative");
                            if (!creative) {
                                dimension.spawnItem(new ItemStack(ball.itemId, 1), {
                                    x: projectile.location.x,
                                    y: projectile.location.y + 0.25,
                                    z: projectile.location.z
                                });
                            }
                        } catch (error) {}
                        retireBallProjectile(projectile);
                        return;
                    }
                    if (!tryLockWildCapture(hitPokemon)) {
                        dropBallItem(projectile, ball);
                        return;
                    }
                    lockedCaptureTarget = hitPokemon;
                    const ownerParty = projectileOwner?.typeId === "minecraft:player"
                        ? loadPartyFromPlayer(projectileOwner)
                        : [];
                    const leadPokemon = ownerParty[projectileOwner?.typeId === "minecraft:player" ? currentActiveSlot(projectileOwner) : 0]
                        || ownerParty.find(member => Number(member?.currentHp) > 0);
                    const outcome = rollCaptureOutcome(calculateCaptureRate(
                        pokemonData,
                        ball,
                        false,
                        {
                            player: projectileOwner,
                            party: ownerParty,
                            leadPokemon,
                            leadPokemonLevel: leadPokemon?.level,
                            targetEntity: hitPokemon,
                            timeOfDay: world.getTimeOfDay(),
                            moonPhase: world.getMoonPhase?.()
                        }
                    ));
                    const ballTypeInt = ball.type;

                    let renderScale;
                    try { renderScale = Number(hitPokemon.getProperty("lota:scale_factor")); } catch (error) {}

                    const captureMotion = playCaptureMotion({
                        projectile,
                        target: hitPokemon,
                        thrower: projectileOwner,
                        dimension,
                        ballType: ballTypeInt,
                        outcome,
                        ballRefund: { ball },
                        onAbsorbed: (absorbedPokemon) => {
                            unlockWildCapture(lockedCaptureTarget || absorbedPokemon);
                            lockedCaptureTarget = undefined;
                            try { if (absorbedPokemon?.isValid) absorbedPokemon.remove(); } catch (error) {}
                        },
                        onCaught: (endLoc) => {
                            try {
                                let owner = projectileOwner;
                                if (!owner) {
                                    let nearestDist = Number.POSITIVE_INFINITY;
                                    for (const candidate of dimension.getPlayers()) {
                                        const candidateLoc = candidate.location;
                                        const distance = Math.hypot(
                                            candidateLoc.x - endLoc.x,
                                            candidateLoc.y - endLoc.y,
                                            candidateLoc.z - endLoc.z
                                        );
                                        if (distance < nearestDist) {
                                            nearestDist = distance;
                                            owner = candidate;
                                        }
                                    }
                                }
                                if (!owner) {
                                    restoreWildPokemon(dimension, pokemonId, endLoc, pokemonData, undefined, renderScale);
                                    return;
                                }

                                const previousCaptureState = {
                                    caughtBall: pokemonData.caughtBall,
                                    friendship: pokemonData.friendship,
                                    currentHp: pokemonData.currentHp,
                                    statusCondition: pokemonData.statusCondition,
                                    moves: (pokemonData.moves || []).map(move => ({ ...move }))
                                };
                                pokemonData.caughtBall = ball.caughtBall;
                                applyCaptureBallEffects(pokemonData, ball);
                                const rawSpeciesForNick = pokemonData.species.replace("lota:", "").toLowerCase();
                                pokemonData.nickname = pokemonData.nickname || speciesData(rawSpeciesForNick)?.name || rawSpeciesForNick;

                                const result = addPokemonToPlayerParty(owner, pokemonData);
                                if (!result.success) {
                                    pokemonData.caughtBall = previousCaptureState.caughtBall;
                                    pokemonData.friendship = previousCaptureState.friendship;
                                    pokemonData.currentHp = previousCaptureState.currentHp;
                                    pokemonData.statusCondition = previousCaptureState.statusCondition;
                                    pokemonData.moves = previousCaptureState.moves;
                                    owner.sendMessage(`§c[Error] Failed to save Pokemon data.`);
                                    restoreWildPokemon(dimension, pokemonId, endLoc, pokemonData, owner, renderScale);
                                    return;
                                }

                                markCaptureEncounter(owner, pokemonData);
                                markSpeciesCaptured(owner, pokemonData);
                                updatePlayerPartyProperties(owner);

                                const speciesName = speciesData(rawSpeciesForNick)?.name || rawSpeciesForNick;
                                const caughtName = pokemonData.nickname
                                    && pokemonData.nickname !== speciesName
                                    && pokemonData.nickname !== rawSpeciesForNick
                                    ? { text: pokemonData.nickname }
                                    : { translate: `cobblemon.species.${rawSpeciesForNick}.name` };
                                owner.sendMessage({
                                    rawtext: [{
                                        translate: "cobblemon.capture.succeeded",
                                        with: { rawtext: [caughtName] }
                                    }]
                                });
                            } catch (captureError) {
                                console.warn(`Capture storage failed: ${captureError}`);
                                restoreWildPokemon(dimension, pokemonId, endLoc, pokemonData, projectileOwner, renderScale);
                            }
                        },
                        onBreakFree: (endLoc) => restoreWildPokemon(
                            dimension,
                            pokemonId,
                            endLoc,
                            pokemonData,
                            projectileOwner,
                            renderScale
                        )
                    });

                    if (!captureMotion) {
                        unlockWildCapture(lockedCaptureTarget);
                        lockedCaptureTarget = undefined;
                        dropBallItem(projectile, ball);
                    }

    } catch (e) {
        if (lockedCaptureTarget) unlockWildCapture(lockedCaptureTarget);
        console.error(`Capture collision error: ${e}\n${e.stack}`);
    }
}

world.afterEvents.projectileHitEntity.subscribe((event) => {
    beginCapture(event.projectile, event.getEntityHit()?.entity, event.source);
});

const activeBallProjectiles = new Map();

world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity && entity.isValid && BALL_PROJECTILES.has(entity.typeId)) {
        activeBallProjectiles.set(entity.id, entity);
    }
});

system.runInterval(() => {
    if (activeBallProjectiles.size === 0) return;

    for (const [id, projectile] of activeBallProjectiles) {
        if (!projectile || !projectile.isValid || projectile.hasTag("lota:hit_processed") || projectile.hasTag("lota:party_summon_ball")) {
            activeBallProjectiles.delete(id);
            continue;
        }

        try {
            const hitPokemon = projectile.dimension.getEntities({
                location: projectile.location,
                maxDistance: 0.8,
                families: ["pokemon"],
                closest: 1
            })[0];

            if (hitPokemon) {
                let owner = null;
                try {
                    owner = projectile.getComponent("minecraft:projectile")?.owner;
                } catch (e) {}
                beginCapture(projectile, hitPokemon, owner);
                activeBallProjectiles.delete(id);
            }
        } catch (error) {
            activeBallProjectiles.delete(id);
            console.warn(`Ball proximity check failed: ${error}`);
        }
    }
}, 1);

world.afterEvents.projectileHitBlock.subscribe((event) => {
    try {
        const projectile = event.projectile;
        if (!projectile || !projectile.isValid) return;
        if (projectile.hasTag("lota:party_summon_ball") || projectile.hasTag("lota:hit_processed")) return;
        const ball = captureBallForProjectile(projectile.typeId);
        if (!ball) return;
        const dimension = projectile.dimension;
        const loc = projectile.location;
        let owner;
        try { owner = projectile.getComponent("minecraft:projectile")?.owner; } catch (error) {}
        const isBattleThrow = owner?.typeId === "minecraft:player" && !!battleCaptureContext(owner);
        projectile.addTag("lota:hit_processed");
        try { projectile.clearVelocity(); } catch (error) {}
        const dropLoc = { x: loc.x, y: loc.y + 0.5, z: loc.z };
        system.runTimeout(() => {
            try {
                if (!isBattleThrow) dimension.spawnItem(new ItemStack(ball.itemId, 1), dropLoc);
                if (projectile?.isValid) projectile.remove();
            } catch (error) {
                console.warn(`Ball block-hit cleanup failed: ${error}`);
            }
        }, 3);
    } catch (error) {
        console.error(`Projectile block-hit error: ${error}`);
    }
});

world.afterEvents.entitySpawn.subscribe((event) => {
    const spawnedEntity = event.entity;
    system.run(() => {
      try {
        const entity = spawnedEntity;
        if (!entity || !entity.isValid) return;

        const typeId = entity.typeId;
        if (isPokemonEntity(entity)) {
            let pokemonData = loadPokemonFromEntity(entity);
            const speciesName = typeId.replace("lota:", "").toLowerCase();
            if (!pokemonData) {
                let minLvl = 5;
                let maxLvl = 15;
                if (SPAWN_LEVELS[speciesName]) {
                    minLvl = SPAWN_LEVELS[speciesName].min;
                    maxLvl = SPAWN_LEVELS[speciesName].max;
                }
                const spawnLevel = Math.floor(Math.random() * (maxLvl - minLvl + 1)) + minLvl;
                pokemonData = generateRandomPokemon(typeId, spawnLevel);
                savePokemonToEntity(entity, pokemonData);
                try {
                    entity.setProperty("lota:scale_factor", Math.random() * 0.4 + 0.8);
                } catch (err) {}
            }

            try {
                entity.setProperty("lota:is_shiny", pokemonData.isShiny ? 1.0 : 0.0);
            } catch (err) {}

            applyWildPokemonNameTags(entity, pokemonData);
        }
      } catch (e) {
        console.error(`Error in entitySpawn handler: ${e}`);
      }
    });
});

const activeCaptureRateHud = new Set();
const captureRatePlayers = new Map();
let captureRateRunId;

function lookedAtWildPokemon(player) {
    try {
        const hits = player.getEntitiesFromViewDirection({ maxDistance: 8 });
        for (const hit of hits) {
            const entity = hit?.entity;
            if (!isPokemonEntity(entity) || entity.hasTag("lota:party_pokemon")) continue;
            if (!entity.getDynamicProperty("lota:pokemon_data")) continue;
            return entity;
        }
    } catch (error) {}
    return undefined;
}

function chanceColor(percentage) {
    if (percentage >= 75) return "§a";
    if (percentage >= 50) return "§e";
    if (percentage >= 25) return "§6";
    return "§c";
}

function hpMultiplierColor(multiplier) {
    if (multiplier >= 0.9) return "§a";
    if (multiplier >= 0.67) return "§e";
    if (multiplier >= 0.5) return "§6";
    return "§c";
}

function ballMultiplierColor(multiplier) {
    if (multiplier >= 3) return "§a";
    if (multiplier >= 2) return "§b";
    if (multiplier >= 1.5) return "§e";
    if (multiplier < 1) return "§c";
    return "§7";
}

function captureRateHudText(player, pokemon, ball, inBattle, context = {}) {
    const party = loadPartyFromPlayer(player);
    const leadPokemon = context.leadPokemon
        || party[currentActiveSlot(player)]
        || party.find(member => Number(member?.currentHp) > 0);
    const calculation = calculateCaptureRate(pokemon, ball, inBattle, {
        ...context,
        player,
        party,
        leadPokemon,
        leadPokemonLevel: leadPokemon?.level,
        timeOfDay: world.getTimeOfDay(),
        moonPhase: world.getMoonPhase?.()
    });
    const stateToken = captureRateStateToken(calculation.percentage);
    const encountered = inBattle || hasCaptureEncounter(player, pokemon, party);

    if (!encountered) {
        return `${captureRateStateToken(0)}§8??? Lv?${inBattle ? "" : " §cWild"}\n\n§8???\n§6Not encountered yet`;
    }

    const species = captureSpeciesKey(pokemon);
    const displayName = pokemonDisplayName(pokemon);
    const percentText = calculation.guaranteed
        ? "§a✓ Guaranteed"
        : `${chanceColor(calculation.percentage)}${formatCapturePercentage(calculation)}%`;
    const lines = [
        `${stateToken}§f${displayName} Lv${Math.max(1, Math.floor(Number(pokemon?.level) || 1))}${inBattle ? "" : " §cWild"}`,
        "",
        percentText,
        `${hpMultiplierColor(calculation.hpMultiplier)}HP ${calculation.hpMultiplier.toFixed(2)}x`
    ];
    if (calculation.status.multiplier > 1) {
        lines.push(`§d${calculation.status.icon} ${calculation.status.label} ${calculation.status.multiplier.toFixed(1)}x`);
    }
    const condition = calculation.ballCondition ? ` §8(${calculation.ballCondition})` : "";
    lines.push(`${ballMultiplierColor(calculation.ballMultiplier)}● ${ball.name} ${calculation.ballMultiplier.toFixed(1)}x${condition}`);
    if (!inBattle) lines.push("§6⚠ Out of battle: 0.5x");
    return lines.join("\n");
}

function updateCaptureRateHud(player, ball) {
    const battleContext = battleCaptureContext(player);
    let pokemon = battleContext?.pokemon;
    let targetEntity = battleContext?.target;
    let inBattle = !!battleContext;
    if (!pokemon) {
        const target = lookedAtWildPokemon(player);
        if (target) {
            targetEntity = target;
            pokemon = loadPokemonFromEntity(target);
            if (!pokemon) {
                pokemon = generateRandomPokemon(target.typeId, 15);
                savePokemonToEntity(target, pokemon);
            }
        }
    }

    if (!pokemon) {
        if (activeCaptureRateHud.delete(player.id)) player.onScreenDisplay.setActionBar("");
        return;
    }

    player.onScreenDisplay.setActionBar(captureRateHudText(player, pokemon, ball, inBattle, {
        targetEntity,
        battleTurn: battleContext?.turn
    }));
    activeCaptureRateHud.add(player.id);
}

function stopCaptureRateLoopIfIdle() {
    if (captureRatePlayers.size !== 0 || captureRateRunId === undefined) return;
    system.clearRun(captureRateRunId);
    captureRateRunId = undefined;
}

function removeCaptureRatePlayer(playerId, player) {
    captureRatePlayers.delete(playerId);
    if (activeCaptureRateHud.delete(playerId) && player?.isValid) {
        try { player.onScreenDisplay.setActionBar(""); } catch (error) {}
    }
    stopCaptureRateLoopIfIdle();
}

function ensureCaptureRateLoop() {
    if (captureRateRunId !== undefined || captureRatePlayers.size === 0) return;
    captureRateRunId = system.runInterval(() => {
        for (const [playerId, state] of captureRatePlayers) {
            const player = state.player;
            if (!player?.isValid) {
                captureRatePlayers.delete(playerId);
                activeCaptureRateHud.delete(playerId);
                continue;
            }
            try {
                updateCaptureRateHud(player, state.ball);
            } catch (error) {
                console.warn(`Capture rate HUD update failed: ${error}`);
            }
        }
        stopCaptureRateLoopIfIdle();
    }, 3);
}

function updateCaptureRatePlayer(player, selectedItem) {
    if (!player?.isValid) return;
    const ball = captureBallForItem(selectedItem?.typeId);
    if (!ball) {
        removeCaptureRatePlayer(player.id, player);
        return;
    }
    captureRatePlayers.set(player.id, { player, ball });
    ensureCaptureRateLoop();
}

function refreshCaptureRatePlayer(player) {
    let selectedItem;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        selectedItem = container?.getItem(player.selectedSlotIndex);
    } catch (error) {}
    updateCaptureRatePlayer(player, selectedItem);
}

world.afterEvents.playerHotbarSelectedSlotChange.subscribe((event) => {
    updateCaptureRatePlayer(event.player, event.itemStack);
});

world.afterEvents.playerInventoryItemChange.subscribe((event) => {
    if (event.slot !== event.player.selectedSlotIndex) return;
    updateCaptureRatePlayer(event.player, event.itemStack);
});

world.afterEvents.playerSpawn.subscribe((event) => {
    system.run(() => refreshCaptureRatePlayer(event.player));
});

world.afterEvents.playerLeave.subscribe((event) => {
    removeCaptureRatePlayer(event.playerId);
});

system.run(() => {
    for (const player of world.getAllPlayers()) {
        try {
            refreshCaptureRatePlayer(player);
        } catch (error) {
            console.warn(`Capture rate HUD initialization failed: ${error}`);
        }
    }
});

const partyDataVersionCache = new Map();
const partyHudActivityCache = new Map();

function partyDimensions() {
    const found = new Map();
    for (const id of PARTY_DIMENSION_IDS) {
        try {
            const dimension = world.getDimension(id);
            found.set(String(dimension.id), dimension);
        } catch (error) {}
    }
    return [...found.values()];
}

function partyEntities() {
    const entities = [];
    for (const dimension of partyDimensions()) {
        try { entities.push(...dimension.getEntities({ tags: ["lota:party_pokemon"] })); }
        catch (error) {}
    }
    return entities;
}

function partyHudActivities(player, party, entities = partyEntities()) {
    const slots = (Array.isArray(party) ? party : []).slice(0, 6);
    const uuids = slots.map(pokemon => String(pokemon?.uuid || ""));
    const activities = new Map(uuids.filter(Boolean).map(uuid => [uuid, ""]));
    if (!Array.isArray(entities) || activities.size === 0) return slots.map(() => "");
    const ownerId = player?.id;
    let remainingUnmounted = activities.size;
    for (const entity of entities) {
        try {
            if (!entity?.isValid || !entity.hasTag?.("lota:party_pokemon")) continue;
            if (ownerId) {
                let owner = "";
                try { owner = String(entity?.getDynamicProperty?.("lota:party_owner_id") || ""); }
                catch (error) {}
                if (owner !== String(ownerId)) continue;
            }
            let uuid = "";
            try {
                const raw = entity?.getDynamicProperty?.("lota:pokemon_data");
                uuid = raw ? JSON.parse(String(raw)).uuid : "";
            } catch (error) {}
            if (!activities.has(uuid) || activities.get(uuid) === "mounted") continue;
            let mounted = false;
            try { mounted = (entity?.getComponent?.("minecraft:rideable")?.getRiders?.() || []).length > 0; }
            catch (error) {}
            if (mounted) {
                activities.set(uuid, "mounted");
                if (--remainingUnmounted === 0) break;
                continue;
            }
            let shoulder = "";
            try {
                if (entity?.hasTag?.("lota:shoulder_mounted")) {
                    const shoulderOwner = String(entity?.getDynamicProperty?.("lota:shoulder_owner") || "");
                    const side = Number(entity?.getDynamicProperty?.("lota:shoulder_side"));
                    if (!ownerId || shoulderOwner === String(ownerId)) {
                        shoulder = side === 1 ? "shoulder_right" : (side === -1 ? "shoulder_left" : "");
                    }
                }
            } catch (error) {}
            if (shoulder) {
                activities.set(uuid, shoulder);
                continue;
            }
            if (!activities.get(uuid)) activities.set(uuid, "released");
        } catch (error) {}
    }
    return uuids.map(uuid => activities.get(uuid) || "");
}

function isBattleHudActive(player) {
    try {
        return player.hasTag("lota:party_selecting") || player.hasTag("lota:battle_player");
    } catch (error) {
        return false;
    }
}

export function updatePlayerPartyProperties(player) {
    try {
        if (!player || !player.isValid) return;

        const party = loadPartyFromPlayer(player);
        let experienceChanged = false;
        for (const pokemon of party) {
            if (normalizePokemonExperience(pokemon)) experienceChanged = true;
        }
        if (experienceChanged) savePartyToPlayer(player, party);
        partyDataVersionCache.set(
            player.id,
            String(player.getDynamicProperty("lota:party_data") || "[]")
        );

        updatePlayerPartyHud(player, party, partyHudActivities(player, party));
    } catch (err) {
        console.error(`Error updating player party properties: ${err}`);
    }
}

const partyHudCache = new Map();

const partyHudDelivered = new Set();

const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";

function currentActiveSlot(player) {
    const stored = Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY));
    return Number.isInteger(stored) && stored >= 0 && stored < 6 ? stored : 0;
}

function updatePlayerPartyHud(player, party, activities) {
    try {
        let payload = partyHudCache.get(player.id);

        if (party) {
            const names = [];
            const levels = [];
            const speciesIds = [];
            const portraitGlyphIds = [];
            const hpBuckets = [];
            const experienceBuckets = [];
            const ballTypes = [];
            const heldItemCodes = [];
            const statusCodes = [];
            for (let i = 0; i < 6; i++) {
                const pokemon = party[i];
                if (!pokemon) {
                    names.push(" ");
                    levels.push(" ");
                    speciesIds.push(0);
                    portraitGlyphIds.push(0);
                    hpBuckets.push(0);
                    experienceBuckets.push(0);
                    ballTypes.push("");
                    heldItemCodes.push("");
                    statusCodes.push("");
                    continue;
                }

                const rawSpecies = pokemon.species.replace("lota:", "").toLowerCase();
                names.push(pokemonDisplayName(pokemon));
                levels.push(`${Math.max(1, Math.floor(Number(pokemon.level) || 1))}`);
                speciesIds.push(Number(speciesData(rawSpecies)?.pokedex) || 0);
                portraitGlyphIds.push(speciesPortraitGlyph(rawSpecies));
                const maxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1));
                const hasCurrentHp = pokemon.currentHp !== undefined && pokemon.currentHp !== null && pokemon.currentHp !== "";
                const rawCurrentHp = Number(pokemon.currentHp);
                const currentHp = Math.max(0, Math.min(maxHp, Math.floor(hasCurrentHp && Number.isFinite(rawCurrentHp) ? rawCurrentHp : maxHp)));
                const hpRatio = Math.max(0, Math.min(100, Math.round((currentHp / maxHp) * 100) || 0));
                hpBuckets.push(hpRatio <= 0 ? 0 : Math.max(1, Math.min(10, Math.ceil(hpRatio / 10))));
                const progress = experienceProgress(pokemon);
                experienceBuckets.push(progress <= 0 ? 0 : Math.max(1, Math.min(10, Math.ceil(progress * 10))));
                ballTypes.push(captureBallCode(pokemon.caughtBall));
                heldItemCodes.push(heldItemPartyHudCode(pokemon.heldItem));
                statusCodes.push(partyStatusCode(pokemon));
            }

            const speciesMarkers = speciesIds.map((id, slot) => id > 0
                ? `|${slot}:${String(id).padStart(3, "0")}|`
                : ""
            ).join("");
            const portraitGlyphMarkers = portraitGlyphIds.map((code, slot) => code > 0 && speciesIds[slot] > 0
                ? `|G${slot}:${code.toString(16).toUpperCase().padStart(4, "0")}|`
                : ""
            ).join("");
            const ballMarkers = ballTypes.map((ball, slot) => ball ? `|B${slot}:${ball}|` : "").join("");
            const heldItemMarkers = heldItemCodes.map((code, slot) => code ? `|I${slot}:${code}|` : "").join("");
            const hpMarkers = hpBuckets.map((bucket, slot) => bucket > 0 ? `|H${slot}:${String(bucket).padStart(2, "0")}|` : "").join("");
            const experienceMarkers = experienceBuckets.map((bucket, slot) => bucket > 0 ? `|E${slot}:${String(bucket).padStart(2, "0")}|` : "").join("");
            const faintMarkers = hpBuckets.map((bucket, slot) => bucket <= 0 && speciesIds[slot] > 0 ? `|F${slot}|` : "").join("");
            const statusMarkers = statusCodes.map((status, slot) => status ? `|ST${slot}:${status}|` : "").join("");
            const activityMarkers = partyActivityMarkers(party, activities);
            const genderMarkers = partyGenderMarkers(party);

            const effects = partyEffectsFor(player.id);
            let transient = false;
            const animMarkers = [];
            const levelOverrides = new Array(6).fill(null);
            for (let slot = 0; slot < 6; slot++) {
                const uuid = party[slot]?.uuid;
                if (!uuid || !effects) continue;
                const state = effects.markersFor(uuid, experienceBuckets[slot] / 10);
                if (state.levelScrollFrame !== null) {
                    animMarkers.push(`|X${slot}:${String(state.levelScrollFrame).padStart(2, "0")}|`);
                    transient = true;
                }
                if (state.expPopup) {
                    animMarkers.push(`|XP${slot}|`);
                    transient = true;
                }
                if (state.movePopup) {
                    animMarkers.push(`|PM${slot}|`);
                    transient = true;
                }
                if (state.evoPopup) {
                    animMarkers.push(`|PE${slot}|`);
                    transient = true;
                }
                if (state.levelOverride != null) {
                    levelOverrides[slot] = Math.max(1, Math.min(100, Math.floor(Number(state.levelOverride) || 1)));
                    transient = true;
                }
            }
            if (effects && effects.records.size > 0) transient = true;
            const animationMarkers = animMarkers.join("");

            const levelMarkers = levels.map((level, slot) => {
                if (!(speciesIds[slot] > 0)) return "";
                const shown = levelOverrides[slot] ?? Math.max(1, Math.min(100, Math.floor(Number(level) || 1)));
                return `|L${slot}:${String(shown).padStart(3, "0")}|`;
            }).join("");

            const frameMarkers = Array.from({ length: 6 }, (_, slot) => {
                const pokemon = party[slot];
                if (!pokemon || !speciesIds[slot]) return `|S${slot}:00|`;
                return `|S${slot}:${hpBuckets[slot] <= 0 ? "02" : "01"}|`;
            }).join("");
            const activeSlot = currentActiveSlot(player);
            const activeMarker = speciesIds[activeSlot] > 0 ? partyActiveMarker(activeSlot) : "";
            payload = {
                title: `|PARTY_HUD_READY|${experienceMarkers}${speciesMarkers}${portraitGlyphMarkers}${ballMarkers}${heldItemMarkers}${levelMarkers}${hpMarkers}${faintMarkers}${statusMarkers}${genderMarkers}${activityMarkers}${frameMarkers}${activeMarker}${animationMarkers}`,
                subtitle: names.join("\n"),
                transient
            };
            partyHudCache.set(player.id, payload);
        } else if (!payload) {
            return updatePlayerPartyHud(player, loadPartyFromPlayer(player));
        }

        if (isBattleHudActive(player)) {
            partyHudDelivered.delete(player.id);
            return;
        }

        setHudTitleBase(player, payload.title, payload.subtitle, PARTY_HUD_STAY_TICKS);
        partyHudDelivered.add(player.id);
    } catch (err) {
        console.error(`Error updating player party HUD: ${err}`);
    }
}

function refreshPartyHudActivity(player, entities) {
    if (!player?.isValid) return;
    const party = loadPartyFromPlayer(player);
    const activities = partyHudActivities(player, party, entities);
    const signature = activities.join(",");
    if (partyEffectsFor(player.id)?.records.size) return;
    if (partyHudActivityCache.get(player.id) === signature
        && partyHudCache.has(player.id)
        && partyHudDelivered.has(player.id)) return;
    partyHudActivityCache.set(player.id, signature);
    partyHudCache.delete(player.id);
    updatePlayerPartyHud(player, party, activities);
}

system.runInterval(() => {
    const players = world.getAllPlayers();
    if (players.length === 0) return;
    const entities = partyEntities();
    for (const player of players) {
        try { refreshPartyHudActivity(player, entities); } catch (error) {}
    }
}, 10);

function playPartyEffectSound(player, cue) {
    if (!player?.isValid || !cue) return;
    try {
        if (cue === "evo") {
            try {
                player.playSound("lota.evolution.notification", { volume: 1, pitch: 1 });
                return;
            } catch (error) {}
            player.playSound("random.levelup", { volume: 0.8, pitch: 1 });
        } else if (cue === "levelup") {
            player.playSound("random.levelup", { volume: 0.8, pitch: 1 });
        } else if (cue === "start") {
            player.playSound("random.orb", { volume: 0.6, pitch: 1 });
        }
    } catch (error) {}
}

function drainPartyEffectSounds(player, effects, party) {
    if (!player?.isValid || !effects) return;
    for (const pokemon of party) {
        const uuid = pokemon?.uuid;
        if (!uuid) continue;
        for (const cue of effects.drainSounds(uuid)) playPartyEffectSound(player, cue);
    }
}

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const effects = partyEffectsFor(player.id);
        if (!effects || effects.records.size === 0) continue;
        const party = loadPartyFromPlayer(player);
        const paused = isBattleHudActive(player);
        effects.tick(party.map(pokemon => pokemon?.uuid).filter(Boolean), paused);
        drainPartyEffectSounds(player, effects, party);
        const cached = partyHudCache.get(player.id);
        if (cached?.transient || effects.records.size > 0) {
            partyHudCache.delete(player.id);
            updatePlayerPartyHud(player, party, partyHudActivities(player, party));
        }
    }
}, 1);

const pendingPartyHudSync = new Set();
let registryHudSyncQueued = false;
subscribeSpeciesRegistryChanged(() => {
    if (registryHudSyncQueued) return;
    registryHudSyncQueued = true;
    system.run(() => {
        registryHudSyncQueued = false;
        for (const player of world.getAllPlayers()) {
            if (!player?.isValid) continue;
            partyHudCache.delete(player.id);
            partyDataVersionCache.delete(player.id);
            updatePlayerPartyProperties(player);
        }
    });
});

subscribePartySaved(player => {
    if (!player?.isValid || pendingPartyHudSync.has(player.id)) return;
    pendingPartyHudSync.add(player.id);
    system.run(() => {
        pendingPartyHudSync.delete(player.id);
        if (player?.isValid) updatePlayerPartyProperties(player);
    });
});

subscribeSelectedPartySlotChanged(player => {
    if (player?.isValid) updatePlayerPartyProperties(player);
});

subscribeBattleHudCleared(player => {
    if (!player?.isValid) return;
    system.run(() => {
        if (!player?.isValid) return;
        partyHudCache.delete(player.id);
        partyDataVersionCache.delete(player.id);
        updatePlayerPartyProperties(player);
    });
});

world.afterEvents.playerDimensionChange?.subscribe(event => {
    const refreshPartyHud = () => {
        const player = event.player;
        if (!player?.isValid || isBattleHudActive(player)) return;
        partyHudCache.delete(player.id);
        partyDataVersionCache.delete(player.id);
        updatePlayerPartyProperties(player);
    };
    system.run(refreshPartyHud);
    system.runTimeout(refreshPartyHud, 10);
});

function queuePartyHudTransitionRefresh(player) {
    const refresh = () => {
        if (!player?.isValid || isBattleHudActive(player)) return;
        partyHudCache.delete(player.id);
        partyDataVersionCache.delete(player.id);
        updatePlayerPartyProperties(player);
    };
    system.run(refresh);
    for (const delay of [2, 10, 20, 40]) system.runTimeout(refresh, delay);
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== PARTY_HUD_REFRESH_EVENT || event.sourceType !== ScriptEventSource.Server) return;
    let request;
    try { request = JSON.parse(String(event.message || "{}")); }
    catch (error) { return; }
    if (Number(request?.version) !== 1) return;
    const playerId = String(request?.playerId || "");
    const player = playerId ? world.getAllPlayers().find(value => String(value.id) === playerId) : undefined;
    if (player?.isValid) queuePartyHudTransitionRefresh(player);
});

system.run(() => {
    for (const player of world.getAllPlayers()) {
        if (!player?.isValid) continue;
        partyHudCache.delete(player.id);
        partyDataVersionCache.delete(player.id);
        updatePlayerPartyProperties(player);
    }
});

world.afterEvents.playerLeave.subscribe((event) => {
    partyHudCache.delete(event.playerId);
    partyHudDelivered.delete(event.playerId);
    partyDataVersionCache.delete(event.playerId);
    partyHudActivityCache.delete(event.playerId);
    pendingPartyHudSync.delete(event.playerId);
    dropPartyEffects(event.playerId);
    forgetHudTitlePlayer(event.playerId);
});

world.afterEvents.playerSpawn.subscribe((event) => {
    try {
        const player = event.player;
        if (player && player.isValid) {
            updatePlayerPartyProperties(player);
            const syncAfterHudLoad = () => {
                if (player.isValid) updatePlayerPartyProperties(player);
            };
            system.run(syncAfterHudLoad);
            system.runTimeout(syncAfterHudLoad, 10);
        }
    } catch (e) {
        console.error(`Error in playerSpawn party sync: ${e}`);
    }
});

function healPokemonForTesting(pokemon) {
    if (!pokemon) return false;

    const currentMaxHp = Number(pokemon.maxHp);
    const fallbackHp = Number(pokemon.currentHp);
    const maxHp = Math.max(1, Math.floor(currentMaxHp || fallbackHp || 1));
    pokemon.maxHp = maxHp;
    pokemon.currentHp = maxHp;
    pokemon.statusCondition = "NONE";

    if (Array.isArray(pokemon.moves)) {
        for (const move of pokemon.moves) {
            if (!move) continue;
            const currentMaxPp = Number(move.maxPp);
            const fallbackPp = Number(move.pp);
            const maxPp = Math.max(0, Math.floor(currentMaxPp || fallbackPp || 0));
            move.maxPp = maxPp;
            move.pp = maxPp;
        }
    }

    return true;
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
    const id = event.id;
    const sourceEntity = event.sourceEntity;
    if (!sourceEntity) return;

    if (id === "lota:testparty") {
        try {
            const dummyParty = [
                generateRandomPokemon("lota:bulbasaur", 5),
                generateRandomPokemon("lota:charizard", 36),
                generateRandomPokemon("lota:pikachu", 25)
            ];

            dummyParty[0].caughtBall = "poke_ball";
            dummyParty[1].caughtBall = "ultra_ball";
            dummyParty[2].caughtBall = "great_ball";

            dummyParty[0].currentHp = 10;
            dummyParty[0].maxHp = 20;
            dummyParty[1].currentHp = 0;
            dummyParty[1].maxHp = 80;
            dummyParty[2].currentHp = 35;
            dummyParty[2].maxHp = 35;

            savePartyToPlayer(sourceEntity, dummyParty);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage("§a[Debug] Test party populated!");
        } catch (err) {
            sourceEntity.sendMessage(`§c[Debug] Error: ${err}`);
        }
    } else if (id === "lota:healparty") {
        try {
            const party = loadPartyFromPlayer(sourceEntity);
            let healedCount = 0;

            for (const pokemon of party) {
                if (healPokemonForTesting(pokemon)) healedCount++;
            }

            savePartyToPlayer(sourceEntity, party);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage(healedCount > 0
                ? `[Debug] Healed ${healedCount} Pokemon.`
                : "[Debug] No Pokemon to heal.");
        } catch (err) {
            sourceEntity.sendMessage(`[Debug] Heal error: ${err}`);
        }
    } else if (id === "lota:damageparty") {
        try {
            const args = String(event.message || "").trim().split(/\s+/).filter(Boolean);
            const amountPercent = Math.max(1, Math.min(100, Math.floor(Number(args[0]) || 25)));
            const slotIndex = args.length > 1 ? Math.floor(Number(args[1])) : -1;
            const party = loadPartyFromPlayer(sourceEntity);
            let damagedCount = 0;
            const debugRatios = [];

            for (let i = 0; i < party.length; i++) {
                if (slotIndex >= 0 && i !== slotIndex) continue;
                const pokemon = party[i];
                if (!pokemon) continue;

                const maxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || Number(pokemon.currentHp) || 1));
                const damage = Math.max(1, Math.ceil(maxHp * (amountPercent / 100)));
                pokemon.maxHp = maxHp;
                pokemon.currentHp = Math.max(0, Math.floor(Number(pokemon.currentHp) || 0) - damage);
                debugRatios.push(`${i}:${pokemon.currentHp}/${pokemon.maxHp}`);
                damagedCount++;
            }

            savePartyToPlayer(sourceEntity, party);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage(damagedCount > 0
                ? `[Debug] Damaged ${damagedCount} Pokemon by ${amountPercent}%. ${debugRatios.join(" ")}`
                : "[Debug] No Pokemon matched.");
        } catch (err) {
            sourceEntity.sendMessage(`[Debug] Damage error: ${err}`);
        }
    } else if (id === "lota:statusparty") {
        try {
            const args = String(event.message || "").trim().split(/\s+/).filter(Boolean);
            const code = String(args[0] || "brn").toUpperCase();
            const slotIndex = args.length > 1 ? Math.floor(Number(args[1])) : -1;
            const party = loadPartyFromPlayer(sourceEntity);
            let statusCount = 0;
            for (let i = 0; i < party.length; i++) {
                if (slotIndex >= 0 && i !== slotIndex) continue;
                const pokemon = party[i];
                if (!pokemon) continue;
                if (code === "NONE" || code === "CLEAR" || code === "CURE") {
                    pokemon.statusCondition = "NONE";
                } else {
                    pokemon.statusCondition = code;
                }
                statusCount++;
            }
            savePartyToPlayer(sourceEntity, party);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage(statusCount > 0
                ? `[Debug] Set status ${code} on ${statusCount} Pokemon.`
                : "[Debug] No Pokemon matched.");
        } catch (err) {
            sourceEntity.sendMessage(`[Debug] Status error: ${err}`);
        }
    } else if (id === "lota:giveexp") {
        try {
            const args = String(event.message || "").trim().split(/\s+/).filter(Boolean);
            const amount = Math.max(1, Math.floor(Number(args[0]) || 100));
            const slotIndex = Math.max(0, Math.min(5, Math.floor(Number(args[1]) || 0)));
            const party = loadPartyFromPlayer(sourceEntity);
            const pokemon = party[slotIndex];
            if (!pokemon) {
                sourceEntity.sendMessage(`[Debug] No Pokemon in slot ${slotIndex}.`);
                return;
            }
            const result = addPokemonExperience(pokemon, amount, getEffectiveLevelCap(sourceEntity));
            partyEffectsFor(sourceEntity.id)?.expGained(pokemon.uuid, result);
            savePartyToPlayer(sourceEntity, party);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage(`[Debug] ${pokemon.nickname || pokemon.species} gained ${result.amount} Exp. Lv.${result.oldLevel} -> Lv.${result.newLevel}`);
            if (result.queuedEvolutions?.length) {
                sourceEntity.sendMessage(`§a${pokemon.nickname || pokemon.species} is ready to evolve! Open the party menu and press Evolve.`);
            }
        } catch (err) {
            sourceEntity.sendMessage(`[Debug] Experience error: ${err}`);
        }
    } else if (id === "lota:clearparty") {
        try {
            savePartyToPlayer(sourceEntity, []);
            updatePlayerPartyProperties(sourceEntity);
            sourceEntity.sendMessage("§a[Debug] Party reset complete!");
        } catch (err) {
            sourceEntity.sendMessage(`§c[Debug] Error: ${err}`);
        }
    }
});
