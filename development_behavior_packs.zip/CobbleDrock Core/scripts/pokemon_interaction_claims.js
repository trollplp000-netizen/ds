import { system } from "@minecraft/server";

const interactionClaims = new Map();

function interactionKey(player, target) {
    const playerId = String(player?.id || "");
    const targetId = String(target?.id || "");
    return playerId && targetId ? `${playerId}:${targetId}` : "";
}

export function claimPokemonInteraction(player, target) {
    const key = interactionKey(player, target);
    if (!key || interactionClaims.has(key)) return false;
    const claim = {};
    interactionClaims.set(key, claim);
    system.runTimeout(() => {
        if (interactionClaims.get(key) === claim) interactionClaims.delete(key);
    }, 2);
    return true;
}

export function consumePokemonInteractionClaim(player, target) {
    const key = interactionKey(player, target);
    if (!key || !interactionClaims.has(key)) return false;
    interactionClaims.delete(key);
    return true;
}
