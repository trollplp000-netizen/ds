export function createSpawnZoneBounds(targetX, targetZ, playerY, config) {
    const length = Math.max(1, Math.floor(Number(config.spawningZoneDiameter) || 1));
    const height = Math.max(1, Math.floor(Number(config.spawningZoneHeight) || 1));
    return {
        minX: Math.ceil(targetX - length / 2),
        minY: Math.ceil(playerY - height / 2),
        minZ: Math.ceil(targetZ - length / 2),
        length,
        height,
        width: length
    };
}

export function createEntityLimitQuery(center, heightRange, config) {
    const bounds = createEntityLimitHorizontalBounds(center, config);
    const minimumY = Number(heightRange?.min);
    const maximumY = Number(heightRange?.max);
    const safeMinimumY = Number.isFinite(minimumY) ? minimumY : -64;
    const safeMaximumY = Number.isFinite(maximumY) ? maximumY : 320;
    return {
        location: {
            x: bounds.minX,
            y: safeMinimumY,
            z: bounds.minZ
        },
        volume: {
            x: bounds.horizontalSize,
            y: Math.max(1, safeMaximumY - safeMinimumY),
            z: bounds.horizontalSize
        },
        families: ["pokemon"],
        excludeTags: ["lota:spawn_cap_exempt"]
    };
}

export function createEntityLimitHorizontalBounds(center, config) {
    const chunkRange = Math.max(1, Math.floor(Number(config.entityLimitChunkRange) || 1));
    const horizontalSize = chunkRange * 16 * 2;
    return {
        minX: Number(center.x) - horizontalSize / 2,
        maxX: Number(center.x) + horizontalSize / 2,
        minZ: Number(center.z) - horizontalSize / 2,
        maxZ: Number(center.z) + horizontalSize / 2,
        horizontalSize
    };
}

export function createEntityLimitChunkLocations(center, config) {
    const bounds = createEntityLimitHorizontalBounds(center, config);
    const minChunkX = Math.floor(bounds.minX / 16);
    const maxChunkX = Math.floor(bounds.maxX / 16);
    const minChunkZ = Math.floor(bounds.minZ / 16);
    const maxChunkZ = Math.floor(bounds.maxZ / 16);
    const y = Math.floor(Number(center.y) || 0);
    const locations = [];
    for (let chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
        for (let chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
            locations.push({ x: chunkX * 16, y, z: chunkZ * 16 });
        }
    }
    return locations;
}

export function isEntityLimitCountReached(count, config) {
    const chunkRange = Math.max(1, Math.floor(Number(config.entityLimitChunkRange) || 1));
    const chunksCovered = chunkRange * chunkRange;
    return Math.max(0, Number(count) || 0) / chunksCovered >= Math.max(0, Number(config.pokemonPerChunk) || 0);
}

export function createStaggeredInitialAttemptTick(currentTick, initialDelay, interval, playerOrdinal) {
    const phaseCount = Math.max(1, Math.floor(Number(interval) || 1));
    const phase = Math.max(0, Math.floor(Number(playerOrdinal) || 0)) % phaseCount;
    return Math.floor(Number(currentTick) || 0) + Math.max(0, Math.floor(Number(initialDelay) || 0)) + phase;
}

export function minimumNaturalSpawnDistanceFromCause(config) {
    const zoneDiameter = Math.max(1, Math.floor(Number(config.spawningZoneDiameter) || 1));
    const maximumRoundedZoneOffset = Math.SQRT2 * (zoneDiameter / 2 + 0.5);
    return Math.max(0,
        (Number(config.minimumSpawningZoneDistanceFromPlayer) || 0) - maximumRoundedZoneOffset
    );
}

export function isNaturalSpawnFarEnoughFromPlayers(location, causePlayerId, players, config) {
    const causeMinimum = minimumNaturalSpawnDistanceFromCause(config);
    const otherMinimum = Math.max(0, Number(config.minimumDistanceBetweenEntities) || 0);
    for (const player of players || []) {
        const playerLocation = player?.location || player;
        if (!playerLocation) continue;
        const dx = Number(location?.x) - Number(playerLocation.x);
        const dz = Number(location?.z) - Number(playerLocation.z);
        if (player?.id === causePlayerId) {
            if (dx * dx + dz * dz < causeMinimum * causeMinimum) return false;
            continue;
        }
        const dy = Number(location?.y) - Number(playerLocation.y);
        if (dx * dx + dy * dy + dz * dz < otherMinimum * otherMinimum) return false;
    }
    return true;
}

export const NATURAL_LEVEL_VARIATION = 5;
export const NATURAL_NO_PARTY_LEVEL_MAX = 5;

export function highestNaturalSpawnPartyLevel(party) {
    let highest;
    for (const pokemon of party || []) {
        const level = Number(pokemon?.level);
        if (!Number.isFinite(level) || level <= 0) continue;
        highest = Math.max(highest ?? 1, Math.floor(level));
    }
    return highest;
}

export function influencedLevelRange(highestPartyLevel, speciesMinimum, speciesMaximum) {
    const numericHighest = Number(highestPartyLevel);
    const hasPartyPokemon = Number.isFinite(numericHighest) && numericHighest > 0;
    const highest = hasPartyPokemon
        ? Math.min(100, Math.max(1, Math.floor(numericHighest)))
        : undefined;
    const numericMinimum = Number(speciesMinimum);
    const numericMaximum = Number(speciesMaximum);
    const minimum = Number.isFinite(numericMinimum)
        ? Math.min(100, Math.max(1, Math.floor(numericMinimum)))
        : 1;
    const maximum = Number.isFinite(numericMaximum)
        ? Math.min(100, Math.max(minimum, Math.floor(numericMaximum)))
        : 100;
    const influenceMinimum = hasPartyPokemon ? Math.max(1, highest - NATURAL_LEVEL_VARIATION) : 1;
    const influenceMaximum = hasPartyPokemon
        ? Math.min(100, Math.max(highest + NATURAL_LEVEL_VARIATION, NATURAL_NO_PARTY_LEVEL_MAX))
        : NATURAL_NO_PARTY_LEVEL_MAX;

    const intersectionMinimum = Math.max(influenceMinimum, minimum);
    const intersectionMaximum = Math.min(influenceMaximum, maximum);
    if (intersectionMinimum <= intersectionMaximum) {
        return { minimum: intersectionMinimum, maximum: intersectionMaximum };
    }

    const width = maximum - minimum;
    if (minimum > influenceMaximum) {
        return { minimum, maximum: minimum + Math.floor(width / 4) };
    }
    return { minimum: minimum + Math.floor(3 * width / 4), maximum };
}

export function chooseNaturalSpawnLevel(
    highestPartyLevel,
    speciesMinimum,
    speciesMaximum,
    random = Math.random
) {
    const range = influencedLevelRange(highestPartyLevel, speciesMinimum, speciesMaximum);
    const numericRoll = Number(random());
    const roll = Number.isFinite(numericRoll)
        ? Math.min(1 - Number.EPSILON, Math.max(0, numericRoll))
        : 0;
    return range.minimum + Math.floor(roll * (range.maximum - range.minimum + 1));
}

export function createNaturalSpawnLocation(positionType, x, y, z) {
    return {
        x: x + 0.5,
        y: y + (positionType === "surface" ? 0.5 : 1),
        z: z + 0.5
    };
}

export function createFluidConditionLocation(positionType, x, y, z) {
    return {
        x,
        y: y + (positionType === "seafloor" ? 1 : 0),
        z
    };
}

export function filterPositionsOutsideMinimumDistance(positions, selectedPosition, minimumDistance) {
    const selected = selectedPosition?.blockLocation || selectedPosition;
    const minimumSquared = Math.max(0, Number(minimumDistance) || 0) ** 2;
    return positions.filter(candidate => {
        const location = candidate?.position?.blockLocation || candidate?.blockLocation || candidate;
        const dx = Number(location?.x) - Number(selected?.x);
        const dy = Number(location?.y) - Number(selected?.y);
        const dz = Number(location?.z) - Number(selected?.z);
        return dx * dx + dy * dy + dz * dz >= minimumSquared;
    });
}

export function advanceLoadedNaturalAge(currentAge, elapsedLoadedTicks = 20) {
    return Math.max(0, Number(currentAge) || 0) + Math.max(0, Number(elapsedLoadedTicks) || 0);
}

export function nearestEntityDistance(origin, entities) {
    let nearestSquared = Number.POSITIVE_INFINITY;
    for (const entity of entities || []) {
        const location = entity?.location || entity;
        if (!location) continue;
        const dx = Number(origin?.x) - Number(location.x);
        const dy = Number(origin?.y) - Number(location.y);
        const dz = Number(origin?.z) - Number(location.z);
        const distanceSquared = dx * dx + dy * dy + dz * dz;
        if (Number.isFinite(distanceSquared)) nearestSquared = Math.min(nearestSquared, distanceSquared);
    }
    return Math.sqrt(nearestSquared);
}

function spatialCellKey(x, z) {
    return `${x}|${z}`;
}

export function createEntitySpatialIndex(entities, cellSize) {
    const safeCellSize = Math.max(1, Number(cellSize) || 1);
    const cells = new Map();
    for (const entity of entities || []) {
        const location = entity?.location || entity;
        if (!location) continue;
        const cellX = Math.floor(Number(location.x) / safeCellSize);
        const cellZ = Math.floor(Number(location.z) / safeCellSize);
        const key = spatialCellKey(cellX, cellZ);
        if (!cells.has(key)) cells.set(key, []);
        cells.get(key).push(entity);
    }
    return { cellSize: safeCellSize, cells };
}

export function nearestIndexedEntityDistance(origin, index, maximumRelevantDistance) {
    const cellSize = Math.max(1, Number(index?.cellSize) || 1);
    const maximumDistance = Math.max(0, Number(maximumRelevantDistance) || 0);
    const cellRadius = Math.ceil(maximumDistance / cellSize);
    const centerX = Math.floor(Number(origin?.x) / cellSize);
    const centerZ = Math.floor(Number(origin?.z) / cellSize);
    const candidates = [];
    for (let cellX = centerX - cellRadius; cellX <= centerX + cellRadius; cellX++) {
        for (let cellZ = centerZ - cellRadius; cellZ <= centerZ + cellRadius; cellZ++) {
            const cell = index?.cells?.get(spatialCellKey(cellX, cellZ));
            if (cell) candidates.push(...cell);
        }
    }
    const nearest = nearestEntityDistance(origin, candidates);
    return nearest <= maximumDistance ? nearest : Number.POSITIVE_INFINITY;
}

export function spawnRuleSignature(entry) {
    return JSON.stringify([
        entry?.conditions || [],
        entry?.anticonditions || [],
        entry?.weightMultipliers || []
    ]);
}

export function compileSpawnEntryGroups(entries) {
    const groupsByBucketAndPosition = new Map();
    const groupsBySignature = new Map();

    for (const entry of entries || []) {
        const key = `${entry?.bucket}|${entry?.positionType}`;
        if (!groupsByBucketAndPosition.has(key)) {
            groupsByBucketAndPosition.set(key, { ruleGroups: [], orderedEntries: [] });
            groupsBySignature.set(key, new Map());
        }

        const compiled = groupsByBucketAndPosition.get(key);
        const signature = spawnRuleSignature(entry);
        const signatureGroups = groupsBySignature.get(key);
        let ruleGroup = signatureGroups.get(signature);
        if (!ruleGroup) {
            ruleGroup = { representative: entry };
            signatureGroups.set(signature, ruleGroup);
            compiled.ruleGroups.push(ruleGroup);
        }
        compiled.orderedEntries.push({ entry, ruleGroup });
    }

    return groupsByBucketAndPosition;
}

export function shouldNaturallyDespawn(age, distance, config) {
    const entityAge = Math.max(0, Number(age) || 0);
    const nearestDistance = Number(distance);
    const minimumAge = Number(config.despawnerMinAgeTicks) || 0;
    const maximumAge = Number(config.despawnerMaxAgeTicks) || minimumAge;
    const nearDistance = Number(config.despawnerNearDistance) || 0;
    const farDistance = Number(config.despawnerFarDistance) || nearDistance;
    if (entityAge < minimumAge || nearestDistance < nearDistance) return false;
    if (nearestDistance > farDistance || entityAge > maximumAge) return true;

    const distanceRatio = Math.min(1, Math.max(0,
        (nearestDistance - nearDistance) / Math.max(1, farDistance - nearDistance)
    ));
    const distanceAdjustedMaximumAge = (1 - distanceRatio) * (maximumAge - minimumAge);
    return entityAge > distanceAdjustedMaximumAge;
}
