export const BERRY_DATA = Object.freeze({
  "aguav_berry": {
    "id": "aguav_berry",
    "name": "Aguav Berry",
    "itemId": "lota:aguav_berry",
    "blockId": "lota:aguav_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.48,
    "weight": 1,
    "colour": "LIME",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:lum_berry": "lota:sitrus_berry",
      "lota:wepear_berry": "lota:rabuta_berry",
      "lota:leppa_berry": "lota:eggant_berry"
    },
    "sproutShape": "stand-sprout",
    "matureShape": "stand-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:aguav_berry.geo",
    "fruitTexture": "cobblemon:aguav",
    "flavours": {
      "BITTER": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 19.25,
          "z": 8
        },
        "rotation": {
          "x": 60,
          "y": 80,
          "z": -85
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 20,
          "z": 8.25
        },
        "rotation": {
          "x": 132.5,
          "y": -45,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 19.75,
          "z": 8
        },
        "rotation": {
          "x": -145,
          "y": 7.5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 22,
          "z": 8
        },
        "rotation": {
          "x": 145,
          "y": 12.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 22.5,
          "z": 7.5
        },
        "rotation": {
          "x": -25,
          "y": 70,
          "z": 120
        }
      },
      {
        "position": {
          "x": 8,
          "y": 22.25,
          "z": 8
        },
        "rotation": {
          "x": -157.5,
          "y": 17.5,
          "z": 27.5
        }
      }
    ],
    "effectGroup": "nature_recovery",
    "showdownEffect": null
  },
  "apicot_berry": {
    "id": "apicot_berry",
    "name": "Apicot Berry",
    "itemId": "lota:apicot_berry",
    "blockId": "lota:apicot_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "BLUE",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:apicot_berry.geo",
    "fruitTexture": "cobblemon:apicot",
    "flavours": {
      "SPICY": 10,
      "DRY": 30,
      "SOUR": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 6.5,
          "y": 25,
          "z": 2
        },
        "rotation": {
          "x": 32.5,
          "y": 25,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 23.25,
          "z": 10.5
        },
        "rotation": {
          "x": -5,
          "y": -70,
          "z": -25
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 24.25,
          "z": 12
        },
        "rotation": {
          "x": -145,
          "y": 0,
          "z": -165
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 15.75,
          "z": 5.5
        },
        "rotation": {
          "x": 15,
          "y": 65,
          "z": 0
        }
      },
      {
        "position": {
          "x": 13.75,
          "y": 21.75,
          "z": 5.75
        },
        "rotation": {
          "x": 120,
          "y": 55,
          "z": 137.5
        }
      },
      {
        "position": {
          "x": 14,
          "y": 16,
          "z": 10.5
        },
        "rotation": {
          "x": 40,
          "y": -80,
          "z": -25
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 16.25,
          "z": 13.5
        },
        "rotation": {
          "x": -25,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9,
          "y": 15.5,
          "z": 2
        },
        "rotation": {
          "x": 167.5,
          "y": -5,
          "z": -170
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "aspear_berry": {
    "id": "aspear_berry",
    "name": "Aspear Berry",
    "itemId": "lota:aspear_berry",
    "blockId": "lota:aspear_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "YELLOW",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:lum_berry",
      "lota:persim_berry": "lota:iapapa_berry"
    },
    "sproutShape": "standard-sprout",
    "matureShape": "standard-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:aspear_berry.geo",
    "fruitTexture": "cobblemon:aspear",
    "flavours": {
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.5,
          "y": 14,
          "z": 1
        },
        "rotation": {
          "x": 165,
          "y": -2.5,
          "z": -180
        }
      },
      {
        "position": {
          "x": 11,
          "y": 19,
          "z": 3
        },
        "rotation": {
          "x": 27.5,
          "y": -10,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 11,
          "z": 6
        },
        "rotation": {
          "x": 45,
          "y": 82.5,
          "z": 32.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 17.5,
          "z": 11
        },
        "rotation": {
          "x": -35,
          "y": -80,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 12,
          "z": 15
        },
        "rotation": {
          "x": -15,
          "y": -5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9,
          "y": 20,
          "z": 13
        },
        "rotation": {
          "x": -160,
          "y": -7.5,
          "z": -172.5
        }
      },
      {
        "position": {
          "x": 15,
          "y": 11.25,
          "z": 4.5
        },
        "rotation": {
          "x": 70,
          "y": -75,
          "z": -55
        }
      },
      {
        "position": {
          "x": 15,
          "y": 14,
          "z": 11
        },
        "rotation": {
          "x": -52.5,
          "y": 80,
          "z": -32.5
        }
      },
      {
        "position": {
          "x": 11,
          "y": 23,
          "z": 8
        },
        "rotation": {
          "x": -65,
          "y": 72.5,
          "z": -20
        }
      },
      {
        "position": {
          "x": 5,
          "y": 22.5,
          "z": 5.5
        },
        "rotation": {
          "x": 52.5,
          "y": 80,
          "z": 7.5
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "babiri_berry": {
    "id": "babiri_berry",
    "name": "Babiri Berry",
    "itemId": "lota:babiri_berry",
    "blockId": "lota:babiri_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "LIME",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_bamboo",
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:rabuta_berry": "lota:durin_berry"
    },
    "sproutShape": "tail-sprout",
    "matureShape": "tail-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:babiri_berry.geo",
    "fruitTexture": "cobblemon:babiri",
    "flavours": {
      "SPICY": 25,
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 11.25,
          "y": -0.75,
          "z": 11
        },
        "rotation": {
          "x": 50,
          "y": 62.5,
          "z": -132.5
        }
      },
      {
        "position": {
          "x": 11,
          "y": -0.75,
          "z": 5.25
        },
        "rotation": {
          "x": 2.5,
          "y": -35,
          "z": -160
        }
      },
      {
        "position": {
          "x": 5,
          "y": -0.75,
          "z": 10.5
        },
        "rotation": {
          "x": 0,
          "y": 15,
          "z": 160
        }
      },
      {
        "position": {
          "x": 5,
          "y": -0.75,
          "z": 5
        },
        "rotation": {
          "x": -50,
          "y": 62.5,
          "z": 132.5
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 8.75,
          "z": 7
        },
        "rotation": {
          "x": -90,
          "y": 0,
          "z": 127.5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 6,
          "z": 14.25
        },
        "rotation": {
          "x": 0,
          "y": -5,
          "z": 90
        }
      },
      {
        "position": {
          "x": 11.5,
          "y": 7.5,
          "z": 9
        },
        "rotation": {
          "x": 90,
          "y": 0,
          "z": 155
        }
      },
      {
        "position": {
          "x": 9,
          "y": 4.75,
          "z": 2
        },
        "rotation": {
          "x": 0,
          "y": -5,
          "z": -90
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "belue_berry": {
    "id": "belue_berry",
    "name": "Belue Berry",
    "itemId": "lota:belue_berry",
    "blockId": "lota:belue_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "PURPLE",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:grepa_berry": "lota:apicot_berry",
      "lota:coba_berry": "lota:rowap_berry"
    },
    "sproutShape": "platform-sprout",
    "matureShape": "platform-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:belue_berry.geo",
    "fruitTexture": "cobblemon:belue",
    "flavours": {
      "SPICY": 10,
      "SOUR": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 11.35,
          "z": 5.25
        },
        "rotation": {
          "x": 35,
          "y": -65,
          "z": -32.5
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 21.85,
          "z": 10.75
        },
        "rotation": {
          "x": -17.5,
          "y": -45,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 10.75,
          "y": 7.35,
          "z": 10.25
        },
        "rotation": {
          "x": -7.5,
          "y": 7.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 5.25,
          "y": 15.35,
          "z": 9.25
        },
        "rotation": {
          "x": -2.5,
          "y": -7.5,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 21.85,
          "z": 6.5
        },
        "rotation": {
          "x": 7.5,
          "y": 42.5,
          "z": 17.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "bluk_berry": {
    "id": "bluk_berry",
    "name": "Bluk Berry",
    "itemId": "lota:bluk_berry",
    "blockId": "lota:bluk_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 15,
    "colour": "PURPLE",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:leppa_berry",
      "lota:wiki_berry": "lota:cornn_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:bluk_berry.geo",
    "fruitTexture": "cobblemon:bluk",
    "flavours": {
      "DRY": 10,
      "SWEET": 5
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7,
          "y": 25.5,
          "z": 6
        },
        "rotation": {
          "x": 27.5,
          "y": 42.5,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 25,
          "z": 10
        },
        "rotation": {
          "x": -10,
          "y": -22.5,
          "z": -17.5
        }
      },
      {
        "position": {
          "x": 10,
          "y": 25,
          "z": 8.25
        },
        "rotation": {
          "x": 15,
          "y": 77.5,
          "z": 40
        }
      },
      {
        "position": {
          "x": 6,
          "y": 19.5,
          "z": 7
        },
        "rotation": {
          "x": 10,
          "y": 20,
          "z": -15
        }
      },
      {
        "position": {
          "x": 7,
          "y": 19.5,
          "z": 10.25
        },
        "rotation": {
          "x": -32.5,
          "y": -50,
          "z": 15
        }
      },
      {
        "position": {
          "x": 10,
          "y": 19.5,
          "z": 9
        },
        "rotation": {
          "x": -12.5,
          "y": 40,
          "z": 15
        }
      },
      {
        "position": {
          "x": 9,
          "y": 19.5,
          "z": 5.5
        },
        "rotation": {
          "x": 20,
          "y": -37.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 13.5,
          "z": 5.5
        },
        "rotation": {
          "x": 10,
          "y": 32.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 13.25,
          "z": 9.75
        },
        "rotation": {
          "x": -15,
          "y": -12.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 12.75,
          "z": 8.25
        },
        "rotation": {
          "x": -17.5,
          "y": 12.5,
          "z": 2.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "charti_berry": {
    "id": "charti_berry",
    "name": "Charti Berry",
    "itemId": "lota:charti_berry",
    "blockId": "lota:charti_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "BROWN",
    "favoriteMulches": [
      "coarse",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_dripstone",
      "cobblemon:is_mountain",
      "cobblemon:is_sandy",
      "cobblemon:is_volcanic"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:durin_berry": "lota:jaboca_berry"
    },
    "sproutShape": "squat-sprout",
    "matureShape": "squat-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:charti_berry.geo",
    "fruitTexture": "cobblemon:charti",
    "flavours": {
      "SPICY": 10,
      "DRY": 20
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.25,
          "y": 9.5,
          "z": 1.75
        },
        "rotation": {
          "x": 125,
          "y": 67.5,
          "z": 142.5
        }
      },
      {
        "position": {
          "x": 1.75,
          "y": 9,
          "z": 9.75
        },
        "rotation": {
          "x": -22.5,
          "y": 35,
          "z": -27.5
        }
      },
      {
        "position": {
          "x": 3.25,
          "y": 16,
          "z": 6
        },
        "rotation": {
          "x": 20,
          "y": 75,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 16,
          "z": 3.25
        },
        "rotation": {
          "x": 25,
          "y": -25,
          "z": -15
        }
      },
      {
        "position": {
          "x": 14.25,
          "y": 9,
          "z": 6.5
        },
        "rotation": {
          "x": 142.5,
          "y": -62.5,
          "z": -125
        }
      },
      {
        "position": {
          "x": 11,
          "y": 8.5,
          "z": 14.25
        },
        "rotation": {
          "x": -160,
          "y": -12.5,
          "z": 172.5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 16.25,
          "z": 12.75
        },
        "rotation": {
          "x": -150,
          "y": 40,
          "z": -167.5
        }
      },
      {
        "position": {
          "x": 12.75,
          "y": 16.5,
          "z": 10
        },
        "rotation": {
          "x": -172.5,
          "y": -30,
          "z": -165
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "cheri_berry": {
    "id": "cheri_berry",
    "name": "Cheri Berry",
    "itemId": "lota:cheri_berry",
    "blockId": "lota:cheri_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "RED",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:lum_berry",
      "lota:persim_berry": "lota:figy_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:cheri_berry.geo",
    "fruitTexture": "cobblemon:cheri",
    "flavours": {
      "SPICY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.2,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 12.5,
          "y": 24,
          "z": 8.5
        },
        "rotation": {
          "x": 10,
          "y": -110,
          "z": 0
        }
      },
      {
        "position": {
          "x": 13.5,
          "y": 16.75,
          "z": 6.5
        },
        "rotation": {
          "x": 157.5,
          "y": 82.5,
          "z": 162.5
        }
      },
      {
        "position": {
          "x": 6,
          "y": 16.75,
          "z": 2.5
        },
        "rotation": {
          "x": 5,
          "y": 12.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 2.5,
          "y": 16.75,
          "z": 9.25
        },
        "rotation": {
          "x": -22.5,
          "y": -95,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 23.75,
          "z": 13
        },
        "rotation": {
          "x": 7.5,
          "y": 160,
          "z": -5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 23.75,
          "z": 2.75
        },
        "rotation": {
          "x": -7.5,
          "y": 170,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3.5,
          "y": 24,
          "z": 6.5
        },
        "rotation": {
          "x": 0,
          "y": 75,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 16.75,
          "z": 13.25
        },
        "rotation": {
          "x": 5,
          "y": 167.5,
          "z": 5
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "chesto_berry": {
    "id": "chesto_berry",
    "name": "Chesto Berry",
    "itemId": "lota:chesto_berry",
    "blockId": "lota:chesto_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "BLUE",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:lum_berry",
      "lota:persim_berry": "lota:wiki_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:chesto_berry.geo",
    "fruitTexture": "cobblemon:chesto",
    "flavours": {
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 17,
          "z": 15
        },
        "rotation": {
          "x": -17.5,
          "y": 27.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12.25,
          "y": 21,
          "z": 13
        },
        "rotation": {
          "x": -12.5,
          "y": 5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3,
          "y": 13,
          "z": 13
        },
        "rotation": {
          "x": 5,
          "y": 40,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 17,
          "z": 7.5
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": -25
        }
      },
      {
        "position": {
          "x": 4,
          "y": 23,
          "z": 14
        },
        "rotation": {
          "x": -17.5,
          "y": -60,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 17,
          "z": 0.75
        },
        "rotation": {
          "x": 12.5,
          "y": 25,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3,
          "y": 21,
          "z": 3
        },
        "rotation": {
          "x": 12.5,
          "y": 35,
          "z": 0
        }
      },
      {
        "position": {
          "x": 15.5,
          "y": 17,
          "z": 7.75
        },
        "rotation": {
          "x": 7.5,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12.25,
          "y": 24,
          "z": 2.5
        },
        "rotation": {
          "x": 17.5,
          "y": -60,
          "z": 0
        }
      },
      {
        "position": {
          "x": 13.75,
          "y": 13,
          "z": 3
        },
        "rotation": {
          "x": 7.5,
          "y": -17.5,
          "z": 0
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "chilan_berry": {
    "id": "chilan_berry",
    "name": "Chilan Berry",
    "itemId": "lota:chilan_berry",
    "blockId": "lota:chilan_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "YELLOW",
    "favoriteMulches": [
      "loamy",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_temperate",
      "cobblemon:is_grassland"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:watmel_berry": "lota:custap_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:chilan_berry.geo",
    "fruitTexture": "cobblemon:chilan",
    "flavours": {
      "DRY": 25,
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 9.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 12.25,
          "y": 20,
          "z": 7.25
        },
        "rotation": {
          "x": 157.5,
          "y": 32.5,
          "z": -172.5
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 16.25,
          "z": 2.25
        },
        "rotation": {
          "x": -157.5,
          "y": 22.5,
          "z": 177.5
        }
      },
      {
        "position": {
          "x": 3.25,
          "y": 21.5,
          "z": 3.5
        },
        "rotation": {
          "x": 170,
          "y": -40,
          "z": 177.5
        }
      },
      {
        "position": {
          "x": 4,
          "y": 27,
          "z": 9
        },
        "rotation": {
          "x": 52.5,
          "y": -75,
          "z": -67.5
        }
      },
      {
        "position": {
          "x": 2.5,
          "y": 19.75,
          "z": 10
        },
        "rotation": {
          "x": -10,
          "y": -35,
          "z": 10
        }
      },
      {
        "position": {
          "x": 8,
          "y": 16.25,
          "z": 13.5
        },
        "rotation": {
          "x": 15,
          "y": -60,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9,
          "y": 24.75,
          "z": 12.25
        },
        "rotation": {
          "x": -27.5,
          "y": 62.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 10,
          "y": 27.5,
          "z": 5
        },
        "rotation": {
          "x": 167.5,
          "y": -5,
          "z": -162.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "chople_berry": {
    "id": "chople_berry",
    "name": "Chople Berry",
    "itemId": "lota:chople_berry",
    "blockId": "lota:chople_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "RED",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_bamboo",
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:spelon_berry": "lota:lansat_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:chople_berry.geo",
    "fruitTexture": "cobblemon:chople",
    "flavours": {
      "SPICY": 15,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 2.75,
          "y": 20,
          "z": 4
        },
        "rotation": {
          "x": 5,
          "y": -60,
          "z": -27.5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 23.75,
          "z": 2
        },
        "rotation": {
          "x": 7.5,
          "y": 22.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 13.75,
          "y": 23.25,
          "z": 4.75
        },
        "rotation": {
          "x": -2.5,
          "y": -10,
          "z": 25
        }
      },
      {
        "position": {
          "x": 12.5,
          "y": 16.75,
          "z": 3.25
        },
        "rotation": {
          "x": 22.5,
          "y": -27.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 13.25,
          "y": 20,
          "z": 12
        },
        "rotation": {
          "x": -5,
          "y": -60,
          "z": 27.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 23.75,
          "z": 14
        },
        "rotation": {
          "x": -7.5,
          "y": 22.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 2.25,
          "y": 23.25,
          "z": 11.25
        },
        "rotation": {
          "x": 2.5,
          "y": -10,
          "z": -25
        }
      },
      {
        "position": {
          "x": 4,
          "y": 16.75,
          "z": 12.75
        },
        "rotation": {
          "x": -22.5,
          "y": -27.5,
          "z": 7.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "coba_berry": {
    "id": "coba_berry",
    "name": "Coba Berry",
    "itemId": "lota:coba_berry",
    "blockId": "lota:coba_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "LIGHT_BLUE",
    "favoriteMulches": [
      "loamy",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_peak",
      "cobblemon:is_temperate",
      "cobblemon:is_sky"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:belue_berry": "lota:rowap_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:coba_berry.geo",
    "fruitTexture": "cobblemon:coba",
    "flavours": {
      "DRY": 10,
      "BITTER": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7,
          "y": 1.25,
          "z": 7
        },
        "rotation": {
          "x": 25,
          "y": -2.5,
          "z": -137.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 1.25,
          "z": 9
        },
        "rotation": {
          "x": -27.5,
          "y": -5,
          "z": 135
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 0.5,
          "z": 5.75
        },
        "rotation": {
          "x": 70,
          "y": -30,
          "z": 70
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 0.25,
          "z": 10
        },
        "rotation": {
          "x": -110,
          "y": 30,
          "z": 110
        }
      },
      {
        "position": {
          "x": 9.75,
          "y": 1.5,
          "z": 6.75
        },
        "rotation": {
          "x": 117.5,
          "y": -62.5,
          "z": 52.5
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 1.5,
          "z": 9.5
        },
        "rotation": {
          "x": -50,
          "y": 70,
          "z": 137.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "colbur_berry": {
    "id": "colbur_berry",
    "name": "Colbur Berry",
    "itemId": "lota:colbur_berry",
    "blockId": "lota:colbur_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "MAGENTA",
    "favoriteMulches": [
      "coarse",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_badlands",
      "cobblemon:is_spooky",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:touga_berry": "lota:spelon_berry"
    },
    "sproutShape": "pyramid-sprout",
    "matureShape": "pyramid-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:colbur_berry.geo",
    "fruitTexture": "cobblemon:colbur",
    "flavours": {
      "BITTER": 10,
      "SOUR": 20
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8.5,
          "y": 11.75,
          "z": 3
        },
        "rotation": {
          "x": 12.5,
          "y": -2.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 3,
          "y": 12.25,
          "z": 7.5
        },
        "rotation": {
          "x": -140,
          "y": 65,
          "z": -150
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 13,
          "z": 13
        },
        "rotation": {
          "x": -172.5,
          "y": 22.5,
          "z": 170
        }
      },
      {
        "position": {
          "x": 13,
          "y": 12.5,
          "z": 8.5
        },
        "rotation": {
          "x": 170,
          "y": -62.5,
          "z": -165
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 20,
          "z": 11
        },
        "rotation": {
          "x": -170,
          "y": -22.5,
          "z": -172.5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 19.25,
          "z": 5
        },
        "rotation": {
          "x": 15,
          "y": -10,
          "z": -22.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "cornn_berry": {
    "id": "cornn_berry",
    "name": "Cornn Berry",
    "itemId": "lota:cornn_berry",
    "blockId": "lota:cornn_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "PURPLE",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:rindo_berry": "lota:kelpsy_berry",
      "lota:passho_berry": "lota:pamtre_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:cornn_berry.geo",
    "fruitTexture": "cobblemon:cornn",
    "flavours": {
      "DRY": 20,
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 10,
          "z": 5
        },
        "rotation": {
          "x": 15,
          "y": 5,
          "z": -177.5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 10,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -87.5,
          "z": -160
        }
      },
      {
        "position": {
          "x": 11,
          "y": 10,
          "z": 8
        },
        "rotation": {
          "x": 2.5,
          "y": 82.5,
          "z": 165
        }
      },
      {
        "position": {
          "x": 8,
          "y": 10,
          "z": 11
        },
        "rotation": {
          "x": -15,
          "y": -5,
          "z": -177.5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 6.25,
          "z": 5
        },
        "rotation": {
          "x": 140,
          "y": 45,
          "z": -5
        }
      },
      {
        "position": {
          "x": 11,
          "y": 5.75,
          "z": 5
        },
        "rotation": {
          "x": 140,
          "y": -35,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 6,
          "z": 11
        },
        "rotation": {
          "x": -140,
          "y": -45,
          "z": -5
        }
      },
      {
        "position": {
          "x": 11,
          "y": 6.25,
          "z": 11
        },
        "rotation": {
          "x": -40,
          "y": -50,
          "z": -175
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "custap_berry": {
    "id": "custap_berry",
    "name": "Custap Berry",
    "itemId": "lota:custap_berry",
    "blockId": "lota:custap_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "ORANGE",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "tail-sprout",
    "matureShape": "tail-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:custap_berry.geo",
    "fruitTexture": "cobblemon:custap",
    "flavours": {
      "SWEET": 40,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 9.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 4.75,
          "y": 10.75,
          "z": 7.5
        },
        "rotation": {
          "x": 5,
          "y": 0,
          "z": -10
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 19.75,
          "z": 8.5
        },
        "rotation": {
          "x": 5,
          "y": -180,
          "z": 5
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 6.25,
          "z": 3.75
        },
        "rotation": {
          "x": 97.5,
          "y": -95,
          "z": -90
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 8.5,
          "z": 12.75
        },
        "rotation": {
          "x": -90,
          "y": 95,
          "z": -95
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "durin_berry": {
    "id": "durin_berry",
    "name": "Durin Berry",
    "itemId": "lota:durin_berry",
    "blockId": "lota:durin_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "LIME",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hondew_berry": "lota:petaya_berry",
      "lota:charti_berry": "lota:jaboca_berry"
    },
    "sproutShape": "cone-sprout",
    "matureShape": "cone-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:durin_berry.geo",
    "fruitTexture": "cobblemon:durin",
    "flavours": {
      "BITTER": 30,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 12,
          "y": 13,
          "z": 4
        },
        "rotation": {
          "x": 32.5,
          "y": -57.5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 4,
          "y": 12.25,
          "z": 4
        },
        "rotation": {
          "x": 20,
          "y": 50,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 4,
          "y": 12.75,
          "z": 12
        },
        "rotation": {
          "x": -12.5,
          "y": -35,
          "z": -10
        }
      },
      {
        "position": {
          "x": 12,
          "y": 12.5,
          "z": 12
        },
        "rotation": {
          "x": -20,
          "y": 42.5,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 13,
          "y": 19.25,
          "z": 7.75
        },
        "rotation": {
          "x": -15,
          "y": -77.5,
          "z": 25
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 19,
          "z": 3
        },
        "rotation": {
          "x": 12.5,
          "y": -12.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 3,
          "y": 18.75,
          "z": 7.75
        },
        "rotation": {
          "x": -30,
          "y": -75,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 19,
          "z": 13
        },
        "rotation": {
          "x": -12.5,
          "y": -10,
          "z": 5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "eggant_berry": {
    "id": "eggant_berry",
    "name": "Eggant Berry",
    "itemId": "lota:eggant_berry",
    "blockId": "lota:eggant_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 2,
    "colour": "BLUE",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 7,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:eggant_berry.geo",
    "fruitTexture": "cobblemon:eggant",
    "flavours": {
      "SPICY": 5,
      "DRY": 5,
      "SWEET": 5,
      "BITTER": 5,
      "SOUR": 5
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 5.25,
          "z": 7.75
        },
        "rotation": {
          "x": 30,
          "y": 27.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 5,
          "z": 8
        },
        "rotation": {
          "x": -112.5,
          "y": -80,
          "z": 145
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 5,
          "z": 8.25
        },
        "rotation": {
          "x": -147.5,
          "y": 52.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 7.5,
          "z": 7.75
        },
        "rotation": {
          "x": 27.5,
          "y": -30,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 7.5,
          "z": 8.25
        },
        "rotation": {
          "x": -150,
          "y": 7.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 8,
          "z": 7.75
        },
        "rotation": {
          "x": 17.5,
          "y": 75,
          "z": -15
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 8.75,
          "z": 8.25
        },
        "rotation": {
          "x": -167.5,
          "y": -47.5,
          "z": -157.5
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "enigma_berry": {
    "id": "enigma_berry",
    "name": "Enigma Berry",
    "itemId": "lota:enigma_berry",
    "blockId": "lota:enigma_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "WHITE",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:kasib_berry": "lota:kee_berry",
      "lota:wacan_berry": "lota:maranga_berry"
    },
    "sproutShape": "cone-sprout",
    "matureShape": "cone-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:enigma_berry.geo",
    "fruitTexture": "cobblemon:enigma",
    "flavours": {
      "SPICY": 40,
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9.5,
          "y": 10.25,
          "z": 1.5
        },
        "rotation": {
          "x": 10,
          "y": 15,
          "z": 175
        }
      },
      {
        "position": {
          "x": 4.75,
          "y": 14,
          "z": 4.5
        },
        "rotation": {
          "x": 165,
          "y": 30,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 10.25,
          "z": 10
        },
        "rotation": {
          "x": -165,
          "y": -65,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 14.75,
          "z": 14
        },
        "rotation": {
          "x": -7.5,
          "y": 17.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 11.5,
          "y": 11.5,
          "z": 12
        },
        "rotation": {
          "x": -157.5,
          "y": 52.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 14,
          "y": 14.75,
          "z": 7
        },
        "rotation": {
          "x": 42.5,
          "y": 77.5,
          "z": -147.5
        }
      }
    ],
    "effectGroup": "mutation_result",
    "showdownEffect": null
  },
  "figy_berry": {
    "id": "figy_berry",
    "name": "Figy Berry",
    "itemId": "lota:figy_berry",
    "blockId": "lota:figy_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.48,
    "weight": 1,
    "colour": "ORANGE",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:lum_berry": "lota:sitrus_berry",
      "lota:razz_berry": "lota:touga_berry",
      "lota:leppa_berry": "lota:eggant_berry"
    },
    "sproutShape": "nest-sprout",
    "matureShape": "nest-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:figy_berry.geo",
    "fruitTexture": "cobblemon:figy",
    "flavours": {
      "SPICY": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 4,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8.75,
          "y": 18.25,
          "z": 8
        },
        "rotation": {
          "x": 130,
          "y": -47.5,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 18,
          "z": 8.75
        },
        "rotation": {
          "x": -160,
          "y": -5,
          "z": -40
        }
      },
      {
        "position": {
          "x": 7,
          "y": 18,
          "z": 8.25
        },
        "rotation": {
          "x": 115,
          "y": 75,
          "z": -20
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 18.25,
          "z": 9.25
        },
        "rotation": {
          "x": -127.5,
          "y": 15,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 18,
          "z": 7.5
        },
        "rotation": {
          "x": 132.5,
          "y": 22.5,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 18,
          "z": 9.25
        },
        "rotation": {
          "x": -137.5,
          "y": 45,
          "z": 77.5
        }
      }
    ],
    "effectGroup": "nature_recovery",
    "showdownEffect": null
  },
  "ganlon_berry": {
    "id": "ganlon_berry",
    "name": "Ganlon Berry",
    "itemId": "lota:ganlon_berry",
    "blockId": "lota:ganlon_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "BLUE",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "platform-sprout",
    "matureShape": "platform-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:ganlon_berry.geo",
    "fruitTexture": "cobblemon:ganlon",
    "flavours": {
      "DRY": 30,
      "SWEET": 10,
      "BITTER": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9.5,
          "y": 21.75,
          "z": 5.5
        },
        "rotation": {
          "x": 5,
          "y": -37.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 21.75,
          "z": 11.25
        },
        "rotation": {
          "x": -177.5,
          "y": -5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 4.5,
          "y": 15.25,
          "z": 9
        },
        "rotation": {
          "x": -170,
          "y": 65,
          "z": -175
        }
      },
      {
        "position": {
          "x": 8,
          "y": 11.25,
          "z": 4.5
        },
        "rotation": {
          "x": 20,
          "y": -80,
          "z": -15
        }
      },
      {
        "position": {
          "x": 11.75,
          "y": 7.25,
          "z": 9.75
        },
        "rotation": {
          "x": -172.5,
          "y": 27.5,
          "z": -175
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "grepa_berry": {
    "id": "grepa_berry",
    "name": "Grepa Berry",
    "itemId": "lota:grepa_berry",
    "blockId": "lota:grepa_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:belue_berry": "lota:apicot_berry",
      "lota:pomeg_berry": "lota:starf_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:grepa_berry.geo",
    "fruitTexture": "cobblemon:grepa",
    "flavours": {
      "DRY": 10,
      "SWEET": 15,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 3.5,
          "y": 21.5,
          "z": 3
        },
        "rotation": {
          "x": 10,
          "y": 32.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 27.5,
          "z": 5
        },
        "rotation": {
          "x": 27.5,
          "y": -27.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 12.5,
          "y": 20.75,
          "z": 6.5
        },
        "rotation": {
          "x": 162.5,
          "y": 2.5,
          "z": -162.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 26,
          "z": 7
        },
        "rotation": {
          "x": -70,
          "y": 77.5,
          "z": -95
        }
      },
      {
        "position": {
          "x": 11,
          "y": 26.75,
          "z": 12
        },
        "rotation": {
          "x": -27.5,
          "y": 42.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 19.25,
          "z": 14.25
        },
        "rotation": {
          "x": -167.5,
          "y": 17.5,
          "z": 167.5
        }
      },
      {
        "position": {
          "x": 13.5,
          "y": 16.5,
          "z": 11.25
        },
        "rotation": {
          "x": 172.5,
          "y": -70,
          "z": -167.5
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 17,
          "z": 1
        },
        "rotation": {
          "x": -180,
          "y": -17.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 2,
          "y": 16.25,
          "z": 10
        },
        "rotation": {
          "x": -12.5,
          "y": 30,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 23.5,
          "z": 14.25
        },
        "rotation": {
          "x": 2.5,
          "y": -77.5,
          "z": -15
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "haban_berry": {
    "id": "haban_berry",
    "name": "Haban Berry",
    "itemId": "lota:haban_berry",
    "blockId": "lota:haban_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "RED",
    "favoriteMulches": [
      "coarse",
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_magical",
      "cobblemon:is_mountain",
      "cobblemon:is_sky",
      "cobblemon:is_volcanic"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:sitrus_berry": "lota:pomeg_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:haban_berry.geo",
    "fruitTexture": "cobblemon:haban",
    "flavours": {
      "SWEET": 10,
      "BITTER": 20
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 12.75,
          "z": 1.25
        },
        "rotation": {
          "x": 10,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 1.25,
          "y": 12.75,
          "z": 8
        },
        "rotation": {
          "x": 10,
          "y": 90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 12.75,
          "z": 14.75
        },
        "rotation": {
          "x": 10,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14.75,
          "y": 12.75,
          "z": 8
        },
        "rotation": {
          "x": 10,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 4,
          "y": 10.75,
          "z": 4
        },
        "rotation": {
          "x": 20,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 4,
          "y": 10.75,
          "z": 12
        },
        "rotation": {
          "x": 20,
          "y": 135,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12,
          "y": 10.75,
          "z": 12
        },
        "rotation": {
          "x": 20,
          "y": -135,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12,
          "y": 11,
          "z": 4
        },
        "rotation": {
          "x": 20,
          "y": -45,
          "z": 0
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "hondew_berry": {
    "id": "hondew_berry",
    "name": "Hondew Berry",
    "itemId": "lota:hondew_berry",
    "blockId": "lota:hondew_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "LIME",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:durin_berry": "lota:petaya_berry",
      "lota:pomeg_berry": "lota:starf_berry"
    },
    "sproutShape": "platform-sprout",
    "matureShape": "platform-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:hondew_berry.geo",
    "fruitTexture": "cobblemon:hondew",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 11.5,
          "z": 6
        },
        "rotation": {
          "x": 60,
          "y": -65,
          "z": -67.5
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 22,
          "z": 10
        },
        "rotation": {
          "x": -80,
          "y": -70,
          "z": 82.5
        }
      },
      {
        "position": {
          "x": 11,
          "y": 7.5,
          "z": 9.25
        },
        "rotation": {
          "x": -10,
          "y": -25,
          "z": 20
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 15.5,
          "z": 8.75
        },
        "rotation": {
          "x": -17.5,
          "y": 30,
          "z": -30
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 22,
          "z": 6.5
        },
        "rotation": {
          "x": 12.5,
          "y": 30,
          "z": 25
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "hopo_berry": {
    "id": "hopo_berry",
    "name": "Hopo Berry",
    "itemId": "lota:hopo_berry",
    "blockId": "lota:hopo_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:occa_berry": "lota:enigma_berry",
      "lota:passho_berry": "lota:enigma_berry",
      "lota:wacan_berry": "lota:enigma_berry",
      "lota:rindo_berry": "lota:enigma_berry",
      "lota:yache_berry": "lota:enigma_berry",
      "lota:chople_berry": "lota:enigma_berry",
      "lota:kebia_berry": "lota:enigma_berry",
      "lota:shuca_berry": "lota:enigma_berry",
      "lota:coba_berry": "lota:enigma_berry",
      "lota:payapa_berry": "lota:enigma_berry",
      "lota:tanga_berry": "lota:enigma_berry",
      "lota:charti_berry": "lota:enigma_berry",
      "lota:kasib_berry": "lota:enigma_berry",
      "lota:haban_berry": "lota:enigma_berry",
      "lota:colbur_berry": "lota:enigma_berry",
      "lota:babiri_berry": "lota:enigma_berry",
      "lota:chilan_berry": "lota:enigma_berry",
      "lota:roseli_berry": "lota:enigma_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:hopo_berry.geo",
    "fruitTexture": "cobblemon:hopo",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "SWEET": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10,
          "y": 12,
          "z": 0.5
        },
        "rotation": {
          "x": 7.5,
          "y": -15,
          "z": -10
        }
      },
      {
        "position": {
          "x": 5,
          "y": 18.75,
          "z": 1.75
        },
        "rotation": {
          "x": -2.5,
          "y": 30,
          "z": -10
        }
      },
      {
        "position": {
          "x": 0.5,
          "y": 12,
          "z": 6
        },
        "rotation": {
          "x": 142.5,
          "y": 77.5,
          "z": 140
        }
      },
      {
        "position": {
          "x": 2,
          "y": 18.25,
          "z": 11
        },
        "rotation": {
          "x": -37.5,
          "y": 77.5,
          "z": -45
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 12,
          "z": 15.5
        },
        "rotation": {
          "x": -170,
          "y": -12.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 12,
          "y": 18.75,
          "z": 14.25
        },
        "rotation": {
          "x": 177.5,
          "y": 20,
          "z": 167.5
        }
      },
      {
        "position": {
          "x": 15.5,
          "y": 12,
          "z": 10.5
        },
        "rotation": {
          "x": -165,
          "y": -77.5,
          "z": 175
        }
      },
      {
        "position": {
          "x": 14,
          "y": 18.25,
          "z": 5
        },
        "rotation": {
          "x": 22.5,
          "y": -75,
          "z": -12.5
        }
      }
    ],
    "effectGroup": "pp_recovery",
    "showdownEffect": null
  },
  "iapapa_berry": {
    "id": "iapapa_berry",
    "name": "Iapapa Berry",
    "itemId": "lota:iapapa_berry",
    "blockId": "lota:iapapa_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.48,
    "weight": 1,
    "colour": "ORANGE",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": false,
    "mutations": {
      "lota:lum_berry": "lota:sitrus_berry",
      "lota:pinap_berry": "lota:nomel_berry",
      "lota:leppa_berry": "lota:eggant_berry"
    },
    "sproutShape": "sword-sprout",
    "matureShape": "sword-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:iapapa_berry.geo",
    "fruitTexture": "cobblemon:iapapa",
    "flavours": {
      "SOUR": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 11.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 14,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 16.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 19,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 21.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 24,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 26.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 29,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 31.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 34,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      }
    ],
    "effectGroup": "nature_recovery",
    "showdownEffect": null
  },
  "jaboca_berry": {
    "id": "jaboca_berry",
    "name": "Jaboca Berry",
    "itemId": "lota:jaboca_berry",
    "blockId": "lota:jaboca_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:jaboca_berry.geo",
    "fruitTexture": "cobblemon:jaboca",
    "flavours": {
      "BITTER": 40,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.75,
        "z": 7.85
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 10.75,
          "z": 3.75
        },
        "rotation": {
          "x": 57.5,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5,
          "y": 9.5,
          "z": 5
        },
        "rotation": {
          "x": 57.5,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3.75,
          "y": 10.75,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": -57.5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 9.5,
          "z": 11
        },
        "rotation": {
          "x": -125,
          "y": 45,
          "z": 180
        }
      },
      {
        "position": {
          "x": 8,
          "y": 10.75,
          "z": 12.25
        },
        "rotation": {
          "x": -122.5,
          "y": 0,
          "z": 180
        }
      },
      {
        "position": {
          "x": 11,
          "y": 9.5,
          "z": 11
        },
        "rotation": {
          "x": -122.5,
          "y": -45,
          "z": 180
        }
      },
      {
        "position": {
          "x": 12.25,
          "y": 10.75,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 57.5
        }
      },
      {
        "position": {
          "x": 11,
          "y": 9.5,
          "z": 5
        },
        "rotation": {
          "x": 57.5,
          "y": -45,
          "z": 0
        }
      }
    ],
    "effectGroup": "mutation_result",
    "showdownEffect": null
  },
  "kasib_berry": {
    "id": "kasib_berry",
    "name": "Kasib Berry",
    "itemId": "lota:kasib_berry",
    "blockId": "lota:kasib_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "PURPLE",
    "favoriteMulches": [
      "coarse",
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_dripstone",
      "cobblemon:is_lush",
      "cobblemon:is_spooky",
      "cobblemon:is_swamp",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:enigma_berry": "lota:kee_berry"
    },
    "sproutShape": "platform-sprout",
    "matureShape": "platform-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:kasib_berry.geo",
    "fruitTexture": "cobblemon:kasib",
    "flavours": {
      "DRY": 10,
      "SWEET": 20
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 22,
          "z": 10
        },
        "rotation": {
          "x": -147.5,
          "y": -10,
          "z": 180
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 22,
          "z": 7.25
        },
        "rotation": {
          "x": 35,
          "y": -35,
          "z": 0
        }
      },
      {
        "position": {
          "x": 10.75,
          "y": 7.5,
          "z": 9.25
        },
        "rotation": {
          "x": -150,
          "y": -55,
          "z": -180
        }
      },
      {
        "position": {
          "x": 6,
          "y": 15.5,
          "z": 8.5
        },
        "rotation": {
          "x": -150,
          "y": 87.5,
          "z": -180
        }
      },
      {
        "position": {
          "x": 8,
          "y": 11.5,
          "z": 6
        },
        "rotation": {
          "x": 32.5,
          "y": 0,
          "z": 0
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "kebia_berry": {
    "id": "kebia_berry",
    "name": "Kebia Berry",
    "itemId": "lota:kebia_berry",
    "blockId": "lota:kebia_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "GREEN",
    "favoriteMulches": [
      "humid",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest",
      "cobblemon:is_mushroom",
      "cobblemon:is_spooky",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 7,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:pamtre_berry": "lota:micle_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:kebia_berry.geo",
    "fruitTexture": "cobblemon:kebia",
    "flavours": {
      "DRY": 15,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9,
          "y": 17,
          "z": 0.5
        },
        "rotation": {
          "x": -45,
          "y": -45,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 14,
          "y": 20.75,
          "z": 6.5
        },
        "rotation": {
          "x": 115,
          "y": -65,
          "z": -122.5
        }
      },
      {
        "position": {
          "x": 2.5,
          "y": 22.25,
          "z": 4.25
        },
        "rotation": {
          "x": 15,
          "y": 10,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 12,
          "y": 26.5,
          "z": 11.25
        },
        "rotation": {
          "x": -165,
          "y": 15,
          "z": -165
        }
      },
      {
        "position": {
          "x": 3,
          "y": 25.5,
          "z": 9.75
        },
        "rotation": {
          "x": -17.5,
          "y": 52.5,
          "z": -30
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 19.25,
          "z": 14.75
        },
        "rotation": {
          "x": 160,
          "y": 52.5,
          "z": 172.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 27.5,
          "z": 5
        },
        "rotation": {
          "x": 72.5,
          "y": -57.5,
          "z": -37.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "kee_berry": {
    "id": "kee_berry",
    "name": "Kee Berry",
    "itemId": "lota:kee_berry",
    "blockId": "lota:kee_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "PINK",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:kee_berry.geo",
    "fruitTexture": "cobblemon:kee",
    "flavours": {
      "SPICY": 30,
      "DRY": 30,
      "SWEET": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.5,
          "y": 11.5,
          "z": 0.75
        },
        "rotation": {
          "x": 5,
          "y": -2.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 0.5,
          "y": 12,
          "z": 10.5
        },
        "rotation": {
          "x": -42.5,
          "y": 80,
          "z": -47.5
        }
      },
      {
        "position": {
          "x": 15.5,
          "y": 12,
          "z": 5.5
        },
        "rotation": {
          "x": 15,
          "y": -77.5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 11.5,
          "z": 15.5
        },
        "rotation": {
          "x": -175,
          "y": -17.5,
          "z": 170
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 19.5,
          "z": 5.5
        },
        "rotation": {
          "x": 125,
          "y": 75,
          "z": 120
        }
      },
      {
        "position": {
          "x": 14.5,
          "y": 19.5,
          "z": 10.5
        },
        "rotation": {
          "x": -157.5,
          "y": -75,
          "z": 162.5
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 19,
          "z": 1.75
        },
        "rotation": {
          "x": 7.5,
          "y": -20,
          "z": -10
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 19,
          "z": 14.25
        },
        "rotation": {
          "x": -172.5,
          "y": -2.5,
          "z": -177.5
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "kelpsy_berry": {
    "id": "kelpsy_berry",
    "name": "Kelpsy Berry",
    "itemId": "lota:kelpsy_berry",
    "blockId": "lota:kelpsy_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "LIGHT_BLUE",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:pamtre_berry": "lota:liechi_berry",
      "lota:pomeg_berry": "lota:starf_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:kelpsy_berry.geo",
    "fruitTexture": "cobblemon:kelpsy",
    "flavours": {
      "DRY": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.75,
          "y": 0.25,
          "z": 8
        },
        "rotation": {
          "x": 110,
          "y": 22.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.75,
          "z": 8
        },
        "rotation": {
          "x": 150,
          "y": 12.5,
          "z": 52.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.5,
          "z": 7.75
        },
        "rotation": {
          "x": 20,
          "y": 17.5,
          "z": 145
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.25,
          "z": 8.25
        },
        "rotation": {
          "x": -27.5,
          "y": 40,
          "z": -152.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 0.5,
          "z": 8.75
        },
        "rotation": {
          "x": -107.5,
          "y": -7.5,
          "z": 40
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.25,
          "z": 8.25
        },
        "rotation": {
          "x": -52.5,
          "y": -62.5,
          "z": 170
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 0.75,
          "z": 9
        },
        "rotation": {
          "x": -127.5,
          "y": -52.5,
          "z": 45
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.5,
          "z": 7.75
        },
        "rotation": {
          "x": 75,
          "y": -20,
          "z": 62.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 0.5,
          "z": 7.25
        },
        "rotation": {
          "x": 122.5,
          "y": -40,
          "z": -40
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.5,
          "z": 8.25
        },
        "rotation": {
          "x": -122.5,
          "y": 10,
          "z": -35
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "lansat_berry": {
    "id": "lansat_berry",
    "name": "Lansat Berry",
    "itemId": "lota:lansat_berry",
    "blockId": "lota:lansat_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "squat-sprout",
    "matureShape": "squat-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:lansat_berry.geo",
    "fruitTexture": "cobblemon:lansat",
    "flavours": {
      "SPICY": 30,
      "DRY": 10,
      "SWEET": 30,
      "BITTER": 10,
      "SOUR": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 3,
          "y": 10,
          "z": 1.75
        },
        "rotation": {
          "x": 10,
          "y": 37.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 9.5,
          "z": 10.5
        },
        "rotation": {
          "x": 70,
          "y": 75,
          "z": 57.5
        }
      },
      {
        "position": {
          "x": 10,
          "y": 8.5,
          "z": 1.5
        },
        "rotation": {
          "x": 12.5,
          "y": -7.5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 16.5,
          "z": 6.5
        },
        "rotation": {
          "x": -117.5,
          "y": 77.5,
          "z": -130
        }
      },
      {
        "position": {
          "x": 7,
          "y": 16.25,
          "z": 13
        },
        "rotation": {
          "x": -167.5,
          "y": -7.5,
          "z": -172.5
        }
      },
      {
        "position": {
          "x": 14.5,
          "y": 9.25,
          "z": 7
        },
        "rotation": {
          "x": 82.5,
          "y": -67.5,
          "z": -67.5
        }
      },
      {
        "position": {
          "x": 13.5,
          "y": 9.75,
          "z": 14.25
        },
        "rotation": {
          "x": -170,
          "y": -40,
          "z": -175
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 8.5,
          "z": 14.5
        },
        "rotation": {
          "x": -167.5,
          "y": 10,
          "z": 162.5
        }
      },
      {
        "position": {
          "x": 13,
          "y": 16.25,
          "z": 8.25
        },
        "rotation": {
          "x": -52.5,
          "y": -70,
          "z": 62.5
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 16.25,
          "z": 3
        },
        "rotation": {
          "x": 12.5,
          "y": 7.5,
          "z": -2.5
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "leppa_berry": {
    "id": "leppa_berry",
    "name": "Leppa Berry",
    "itemId": "lota:leppa_berry",
    "blockId": "lota:leppa_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:lum_berry": "lota:hopo_berry",
      "lota:figy_berry": "lota:eggant_berry",
      "lota:wiki_berry": "lota:eggant_berry",
      "lota:mago_berry": "lota:eggant_berry",
      "lota:aguav_berry": "lota:eggant_berry",
      "lota:iapapa_berry": "lota:eggant_berry"
    },
    "sproutShape": "volcano-sprout",
    "matureShape": "volcano-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:leppa_berry.geo",
    "fruitTexture": "cobblemon:leppa",
    "flavours": {
      "SPICY": 10,
      "SWEET": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.2,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7,
          "y": 13.5,
          "z": 7
        },
        "rotation": {
          "x": 17.5,
          "y": -45,
          "z": -180
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 13.5,
          "z": 9.25
        },
        "rotation": {
          "x": -167.5,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 13.5,
          "z": 9.25
        },
        "rotation": {
          "x": -167.5,
          "y": -45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 13.5,
          "z": 6.75
        },
        "rotation": {
          "x": 10,
          "y": 45,
          "z": -180
        }
      }
    ],
    "effectGroup": "pp_recovery",
    "showdownEffect": null
  },
  "liechi_berry": {
    "id": "liechi_berry",
    "name": "Liechi Berry",
    "itemId": "lota:liechi_berry",
    "blockId": "lota:liechi_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 200,
    "colour": "ORANGE",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:specific_biome",
        "biome": "cobblemon:is_mirage_island",
        "minGroveSize": 1,
        "maxGroveSize": 1
      }
    ],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "tail-sprout",
    "matureShape": "tail-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:liechi_berry.geo",
    "fruitTexture": "cobblemon:liechi",
    "flavours": {
      "SPICY": 30,
      "DRY": 10,
      "SWEET": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.5,
          "y": 3.25,
          "z": 7.75
        },
        "rotation": {
          "x": 90,
          "y": 7.5,
          "z": 15
        }
      },
      {
        "position": {
          "x": 10.75,
          "y": 3.25,
          "z": 8.25
        },
        "rotation": {
          "x": -87.5,
          "y": 5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 3.25,
          "z": 11.25
        },
        "rotation": {
          "x": -5,
          "y": -20,
          "z": -90
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 3.25,
          "z": 4.5
        },
        "rotation": {
          "x": 5,
          "y": -10,
          "z": 87.5
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "lum_berry": {
    "id": "lum_berry",
    "name": "Lum Berry",
    "itemId": "lota:lum_berry",
    "blockId": "lota:lum_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "GREEN",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:figy_berry": "lota:sitrus_berry",
      "lota:wiki_berry": "lota:sitrus_berry",
      "lota:mago_berry": "lota:sitrus_berry",
      "lota:aguav_berry": "lota:sitrus_berry",
      "lota:iapapa_berry": "lota:sitrus_berry",
      "lota:leppa_berry": "lota:hopo_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:lum_berry.geo",
    "fruitTexture": "cobblemon:lum",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "SWEET": 10,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 2.25,
          "y": 13.75,
          "z": 8
        },
        "rotation": {
          "x": 22.5,
          "y": -17.5,
          "z": -52.5
        }
      },
      {
        "position": {
          "x": 6,
          "y": 12,
          "z": 8.25
        },
        "rotation": {
          "x": -42.5,
          "y": -20,
          "z": 25
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 20.75,
          "z": 7.25
        },
        "rotation": {
          "x": 100,
          "y": 42.5,
          "z": 95
        }
      },
      {
        "position": {
          "x": 10,
          "y": 19.75,
          "z": 8
        },
        "rotation": {
          "x": -65,
          "y": -7.5,
          "z": 15
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "mago_berry": {
    "id": "mago_berry",
    "name": "Mago Berry",
    "itemId": "lota:mago_berry",
    "blockId": "lota:mago_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.48,
    "weight": 1,
    "colour": "PINK",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 9,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:lum_berry": "lota:sitrus_berry",
      "lota:nanab_berry": "lota:magost_berry",
      "lota:leppa_berry": "lota:eggant_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:mago_berry.geo",
    "fruitTexture": "cobblemon:mago",
    "flavours": {
      "SWEET": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 3.75,
          "y": 19.25,
          "z": 3.25
        },
        "rotation": {
          "x": 45,
          "y": 32.5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 11.25,
          "y": 16.75,
          "z": 3
        },
        "rotation": {
          "x": 22.5,
          "y": -32.5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 23.5,
          "z": 3.25
        },
        "rotation": {
          "x": 40,
          "y": -2.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3,
          "y": 24.25,
          "z": 7.25
        },
        "rotation": {
          "x": 67.5,
          "y": 77.5,
          "z": 30
        }
      },
      {
        "position": {
          "x": 5.25,
          "y": 21.5,
          "z": 13
        },
        "rotation": {
          "x": -135,
          "y": 17.5,
          "z": 177.5
        }
      },
      {
        "position": {
          "x": 10.75,
          "y": 23.25,
          "z": 12.75
        },
        "rotation": {
          "x": -137.5,
          "y": -17.5,
          "z": -180
        }
      },
      {
        "position": {
          "x": 3,
          "y": 15.75,
          "z": 9.25
        },
        "rotation": {
          "x": -152.5,
          "y": 60,
          "z": -180
        }
      },
      {
        "position": {
          "x": 13,
          "y": 17,
          "z": 11.5
        },
        "rotation": {
          "x": -162.5,
          "y": -62.5,
          "z": -170
        }
      },
      {
        "position": {
          "x": 13,
          "y": 24.5,
          "z": 7.25
        },
        "rotation": {
          "x": 85,
          "y": -82.5,
          "z": -50
        }
      }
    ],
    "effectGroup": "nature_recovery",
    "showdownEffect": null
  },
  "magost_berry": {
    "id": "magost_berry",
    "name": "Magost Berry",
    "itemId": "lota:magost_berry",
    "blockId": "lota:magost_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "PINK",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 7,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:roseli_berry": "lota:qualot_berry",
      "lota:tanga_berry": "lota:watmel_berry"
    },
    "sproutShape": "frill-sprout",
    "matureShape": "frill-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:magost_berry.geo",
    "fruitTexture": "cobblemon:magost",
    "flavours": {
      "SWEET": 20,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 12.5,
          "z": 8
        },
        "rotation": {
          "x": -180,
          "y": 10,
          "z": 0
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 12,
          "z": 7
        },
        "rotation": {
          "x": 152.5,
          "y": 25,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 12,
          "z": 8.5
        },
        "rotation": {
          "x": -175,
          "y": -7.5,
          "z": 25
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 12,
          "z": 9.5
        },
        "rotation": {
          "x": -62.5,
          "y": 52.5,
          "z": 130
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 12,
          "z": 9
        },
        "rotation": {
          "x": -35,
          "y": -45,
          "z": -170
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 12,
          "z": 7.5
        },
        "rotation": {
          "x": 175,
          "y": -22.5,
          "z": -30
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 12,
          "z": 6.5
        },
        "rotation": {
          "x": 132.5,
          "y": 47.5,
          "z": -50
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "maranga_berry": {
    "id": "maranga_berry",
    "name": "Maranga Berry",
    "itemId": "lota:maranga_berry",
    "blockId": "lota:maranga_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:maranga_berry.geo",
    "fruitTexture": "cobblemon:maranga",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "SWEET": 30,
      "BITTER": 30,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9.25,
          "y": 13.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 70,
          "z": 147.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 13.5,
          "z": 9.25
        },
        "rotation": {
          "x": -145,
          "y": 17.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 8,
          "y": 13.5,
          "z": 6.75
        },
        "rotation": {
          "x": 35,
          "y": -17.5,
          "z": 170
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 13.5,
          "z": 8
        },
        "rotation": {
          "x": 180,
          "y": -70,
          "z": 32.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 14,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 12.5,
          "z": -180
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "micle_berry": {
    "id": "micle_berry",
    "name": "Micle Berry",
    "itemId": "lota:micle_berry",
    "blockId": "lota:micle_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "LIME",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 9,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "pyramid-sprout",
    "matureShape": "pyramid-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:micle_berry.geo",
    "fruitTexture": "cobblemon:micle",
    "flavours": {
      "DRY": 40,
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.2,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 6.5,
          "y": 19.25,
          "z": 5
        },
        "rotation": {
          "x": 12.5,
          "y": 22.5,
          "z": 25
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 9.5,
          "z": 3
        },
        "rotation": {
          "x": 7.5,
          "y": -37.5,
          "z": -17.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 13.75,
          "z": 6.5
        },
        "rotation": {
          "x": 167.5,
          "y": 65,
          "z": 157.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 9.5,
          "z": 12
        },
        "rotation": {
          "x": 45,
          "y": 62.5,
          "z": 30
        }
      },
      {
        "position": {
          "x": 13,
          "y": 9.25,
          "z": 9.5
        },
        "rotation": {
          "x": -140,
          "y": -62.5,
          "z": 155
        }
      },
      {
        "position": {
          "x": 11,
          "y": 19.75,
          "z": 9
        },
        "rotation": {
          "x": -162.5,
          "y": 67.5,
          "z": -152.5
        }
      },
      {
        "position": {
          "x": 5.25,
          "y": 18.75,
          "z": 10.75
        },
        "rotation": {
          "x": -167.5,
          "y": -2.5,
          "z": -172.5
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 12.75,
          "z": 13
        },
        "rotation": {
          "x": -10,
          "y": -30,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 13,
          "y": 13.75,
          "z": 5
        },
        "rotation": {
          "x": 57.5,
          "y": -75,
          "z": -40
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "nanab_berry": {
    "id": "nanab_berry",
    "name": "Nanab Berry",
    "itemId": "lota:nanab_berry",
    "blockId": "lota:nanab_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 15,
    "colour": "PINK",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:leppa_berry",
      "lota:mago_berry": "lota:magost_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:nanab_berry.geo",
    "fruitTexture": "cobblemon:nanab",
    "flavours": {
      "SWEET": 10,
      "BITTER": 5
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.5,
          "y": 24,
          "z": 1.75
        },
        "rotation": {
          "x": -7.5,
          "y": 10,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14,
          "y": 15.75,
          "z": 9.25
        },
        "rotation": {
          "x": -15,
          "y": -117.5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 2.75,
          "y": 22.75,
          "z": 13.5
        },
        "rotation": {
          "x": 165,
          "y": 45,
          "z": 165
        }
      },
      {
        "position": {
          "x": 2,
          "y": 15.75,
          "z": 9.75
        },
        "rotation": {
          "x": -12.5,
          "y": 100,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3.5,
          "y": 16.5,
          "z": 2.5
        },
        "rotation": {
          "x": -12.5,
          "y": 30,
          "z": -5
        }
      },
      {
        "position": {
          "x": 14.25,
          "y": 23.25,
          "z": 5
        },
        "rotation": {
          "x": -32.5,
          "y": -72.5,
          "z": 27.5
        }
      },
      {
        "position": {
          "x": 13,
          "y": 22.5,
          "z": 14
        },
        "rotation": {
          "x": 177.5,
          "y": -27.5,
          "z": 175
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 17.25,
          "z": 14
        },
        "rotation": {
          "x": -5,
          "y": 170,
          "z": 5
        }
      },
      {
        "position": {
          "x": 11.25,
          "y": 17,
          "z": 2
        },
        "rotation": {
          "x": -2.5,
          "y": -32.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 2,
          "y": 23.5,
          "z": 5.25
        },
        "rotation": {
          "x": -32.5,
          "y": 75,
          "z": -30
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "nomel_berry": {
    "id": "nomel_berry",
    "name": "Nomel Berry",
    "itemId": "lota:nomel_berry",
    "blockId": "lota:nomel_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:yache_berry": "lota:grepa_berry",
      "lota:payapa_berry": "lota:belue_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:nomel_berry.geo",
    "fruitTexture": "cobblemon:nomel",
    "flavours": {
      "SPICY": 10,
      "SOUR": 20
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 6.75,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -50,
          "z": -37.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 8.25,
          "z": 7.75
        },
        "rotation": {
          "x": 107.5,
          "y": -52.5,
          "z": -152.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 6.5,
          "z": 8.25
        },
        "rotation": {
          "x": -122.5,
          "y": -57.5,
          "z": 152.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 7.75,
          "z": 8.25
        },
        "rotation": {
          "x": -42.5,
          "y": 0,
          "z": -30
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5.75,
          "z": 8
        },
        "rotation": {
          "x": 45,
          "y": 2.5,
          "z": 22.5
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 8.5,
          "z": 8
        },
        "rotation": {
          "x": 7.5,
          "y": -30,
          "z": 42.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "occa_berry": {
    "id": "occa_berry",
    "name": "Occa Berry",
    "itemId": "lota:occa_berry",
    "blockId": "lota:occa_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "ORANGE",
    "favoriteMulches": [
      "humid",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_sandy",
      "cobblemon:is_thermal",
      "cobblemon:is_volcanic"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:touga_berry": "lota:tamato_berry"
    },
    "sproutShape": "lantern-sprout",
    "matureShape": "lantern-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:occa_berry.geo",
    "fruitTexture": "cobblemon:occa",
    "flavours": {
      "SPICY": 15,
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10,
          "y": 27.75,
          "z": 4
        },
        "rotation": {
          "x": 117.5,
          "y": -60,
          "z": -120
        }
      },
      {
        "position": {
          "x": 6,
          "y": 27.75,
          "z": 4
        },
        "rotation": {
          "x": 115,
          "y": 60,
          "z": 112.5
        }
      },
      {
        "position": {
          "x": 4,
          "y": 27.75,
          "z": 6
        },
        "rotation": {
          "x": 5,
          "y": -17.5,
          "z": -27.5
        }
      },
      {
        "position": {
          "x": 4,
          "y": 27.75,
          "z": 10
        },
        "rotation": {
          "x": -177.5,
          "y": -5,
          "z": 152.5
        }
      },
      {
        "position": {
          "x": 6,
          "y": 27.75,
          "z": 12
        },
        "rotation": {
          "x": -70,
          "y": 60,
          "z": -75
        }
      },
      {
        "position": {
          "x": 10,
          "y": 27.75,
          "z": 12
        },
        "rotation": {
          "x": -65,
          "y": -55,
          "z": 62.5
        }
      },
      {
        "position": {
          "x": 12,
          "y": 27.75,
          "z": 10
        },
        "rotation": {
          "x": -175,
          "y": 7.5,
          "z": -155
        }
      },
      {
        "position": {
          "x": 12,
          "y": 27.75,
          "z": 6
        },
        "rotation": {
          "x": 117.5,
          "y": 82.5,
          "z": 145
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "oran_berry": {
    "id": "oran_berry",
    "name": "Oran Berry",
    "itemId": "lota:oran_berry",
    "blockId": "lota:oran_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 25,
    "colour": "LIGHT_BLUE",
    "favoriteMulches": [
      "peat",
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_temperate"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:all_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:cheri_berry": "lota:lum_berry",
      "lota:chesto_berry": "lota:lum_berry",
      "lota:pecha_berry": "lota:lum_berry",
      "lota:rawst_berry": "lota:lum_berry",
      "lota:aspear_berry": "lota:lum_berry",
      "lota:razz_berry": "lota:leppa_berry",
      "lota:bluk_berry": "lota:leppa_berry",
      "lota:nanab_berry": "lota:leppa_berry",
      "lota:wepear_berry": "lota:leppa_berry",
      "lota:pinap_berry": "lota:leppa_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:oran_berry.geo",
    "fruitTexture": "cobblemon:oran",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 12,
          "y": 21,
          "z": 7.5
        },
        "rotation": {
          "x": -12.5,
          "y": -12.5,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 2,
          "y": 14.75,
          "z": 10.5
        },
        "rotation": {
          "x": -7.5,
          "y": -5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 15,
          "y": 9,
          "z": 8
        },
        "rotation": {
          "x": 7.5,
          "y": 0,
          "z": 15
        }
      },
      {
        "position": {
          "x": 13,
          "y": 14.75,
          "z": 14
        },
        "rotation": {
          "x": -20,
          "y": 5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 6,
          "y": 21,
          "z": 12
        },
        "rotation": {
          "x": -15,
          "y": -10,
          "z": 5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 9,
          "z": 15
        },
        "rotation": {
          "x": -12.5,
          "y": -2.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 12,
          "y": 15,
          "z": 2
        },
        "rotation": {
          "x": 15,
          "y": 12.5,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 8.75,
          "z": 1
        },
        "rotation": {
          "x": 22.5,
          "y": -15,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 5.25,
          "y": 21,
          "z": 4
        },
        "rotation": {
          "x": 7.5,
          "y": -42.5,
          "z": -22.5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 8.5,
          "z": 6.5
        },
        "rotation": {
          "x": 10,
          "y": 0,
          "z": -20
        }
      }
    ],
    "effectGroup": "hp_recovery",
    "showdownEffect": null
  },
  "pamtre_berry": {
    "id": "pamtre_berry",
    "name": "Pamtre Berry",
    "itemId": "lota:pamtre_berry",
    "blockId": "lota:pamtre_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "PURPLE",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:kelpsy_berry": "lota:liechi_berry",
      "lota:kebia_berry": "lota:micle_berry"
    },
    "sproutShape": "lantern-sprout",
    "matureShape": "lantern-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:pamtre_berry.geo",
    "fruitTexture": "cobblemon:pamtre",
    "flavours": {
      "DRY": 30,
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10.5,
          "y": 28,
          "z": 1.5
        },
        "rotation": {
          "x": -2.5,
          "y": -10,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 28,
          "z": 1.5
        },
        "rotation": {
          "x": 2.5,
          "y": 70,
          "z": 0
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 28,
          "z": 5.5
        },
        "rotation": {
          "x": 2.5,
          "y": 30,
          "z": 0
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 28,
          "z": 10.5
        },
        "rotation": {
          "x": -2.5,
          "y": 82.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 28,
          "z": 14.5
        },
        "rotation": {
          "x": 5,
          "y": 55,
          "z": 0
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 28,
          "z": 14.5
        },
        "rotation": {
          "x": -2.5,
          "y": 155,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14.5,
          "y": 28,
          "z": 10.5
        },
        "rotation": {
          "x": 2.5,
          "y": 65,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14.5,
          "y": 28,
          "z": 5.5
        },
        "rotation": {
          "x": 5,
          "y": 25,
          "z": 0
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "passho_berry": {
    "id": "passho_berry",
    "name": "Passho Berry",
    "itemId": "lota:passho_berry",
    "blockId": "lota:passho_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "BLUE",
    "favoriteMulches": [
      "humid",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_coast",
      "cobblemon:is_freshwater",
      "cobblemon:is_island",
      "cobblemon:is_ocean"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:cornn_berry": "lota:pamtre_berry"
    },
    "sproutShape": "nest-sprout",
    "matureShape": "nest-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:passho_berry.geo",
    "fruitTexture": "cobblemon:passho",
    "flavours": {
      "DRY": 15,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 18.25,
          "z": 4.25
        },
        "rotation": {
          "x": -165,
          "y": -10,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 11.75,
          "y": 18.25,
          "z": 7
        },
        "rotation": {
          "x": -180,
          "y": 12.5,
          "z": 15
        }
      },
      {
        "position": {
          "x": 4.25,
          "y": 18.25,
          "z": 7
        },
        "rotation": {
          "x": -7.5,
          "y": 35,
          "z": 157.5
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 18.25,
          "z": 10.75
        },
        "rotation": {
          "x": 177.5,
          "y": -57.5,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 18.25,
          "z": 10.75
        },
        "rotation": {
          "x": 177.5,
          "y": -52.5,
          "z": -7.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "payapa_berry": {
    "id": "payapa_berry",
    "name": "Payapa Berry",
    "itemId": "lota:payapa_berry",
    "blockId": "lota:payapa_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "MAGENTA",
    "favoriteMulches": [
      "loamy",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_desert",
      "cobblemon:is_floral",
      "cobblemon:is_magical",
      "cobblemon:is_savanna",
      "cobblemon:is_spooky"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 5,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:nomel_berry": "lota:belue_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:payapa_berry.geo",
    "fruitTexture": "cobblemon:payapa",
    "flavours": {
      "SWEET": 10,
      "SOUR": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 5.25,
          "z": 8
        },
        "rotation": {
          "x": 52.5,
          "y": -2.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5,
          "z": 8
        },
        "rotation": {
          "x": 37.5,
          "y": 67.5,
          "z": -20
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5.25,
          "z": 8
        },
        "rotation": {
          "x": -132.5,
          "y": 30,
          "z": 170
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5,
          "z": 8
        },
        "rotation": {
          "x": -130,
          "y": -32.5,
          "z": -167.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 4.75,
          "z": 8
        },
        "rotation": {
          "x": 47.5,
          "y": -65,
          "z": 12.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "pecha_berry": {
    "id": "pecha_berry",
    "name": "Pecha Berry",
    "itemId": "lota:pecha_berry",
    "blockId": "lota:pecha_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "PINK",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:lum_berry",
      "lota:persim_berry": "lota:mago_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:pecha_berry.geo",
    "fruitTexture": "cobblemon:pecha",
    "flavours": {
      "SWEET": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 11,
          "y": 16.75,
          "z": 6
        },
        "rotation": {
          "x": 2.5,
          "y": 10,
          "z": -22.5
        }
      },
      {
        "position": {
          "x": 3.75,
          "y": 12.25,
          "z": 5.25
        },
        "rotation": {
          "x": -45,
          "y": -57.5,
          "z": 40
        }
      },
      {
        "position": {
          "x": 4.5,
          "y": 16.5,
          "z": 11.5
        },
        "rotation": {
          "x": 5,
          "y": -17.5,
          "z": 20
        }
      },
      {
        "position": {
          "x": 5,
          "y": 21,
          "z": 4.75
        },
        "rotation": {
          "x": 140,
          "y": -70,
          "z": -160
        }
      },
      {
        "position": {
          "x": 10.75,
          "y": 21,
          "z": 11.5
        },
        "rotation": {
          "x": -7.5,
          "y": -60,
          "z": 27.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 10.25,
          "z": 12.25
        },
        "rotation": {
          "x": -17.5,
          "y": 50,
          "z": -17.5
        }
      },
      {
        "position": {
          "x": 10,
          "y": 22.75,
          "z": 5.25
        },
        "rotation": {
          "x": 10,
          "y": 30,
          "z": 45
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 22.5,
          "z": 10.5
        },
        "rotation": {
          "x": -10,
          "y": 20,
          "z": -40
        }
      },
      {
        "position": {
          "x": 12,
          "y": 12.25,
          "z": 10.5
        },
        "rotation": {
          "x": 20,
          "y": -12.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 10.25,
          "z": 3.75
        },
        "rotation": {
          "x": 7.5,
          "y": 32.5,
          "z": 17.5
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "persim_berry": {
    "id": "persim_berry",
    "name": "Persim Berry",
    "itemId": "lota:persim_berry",
    "blockId": "lota:persim_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "PINK",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:all_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:cheri_berry": "lota:figy_berry",
      "lota:chesto_berry": "lota:wiki_berry",
      "lota:pecha_berry": "lota:mago_berry",
      "lota:rawst_berry": "lota:aguav_berry",
      "lota:aspear_berry": "lota:iapapa_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:persim_berry.geo",
    "fruitTexture": "cobblemon:persim",
    "flavours": {
      "SPICY": 10,
      "DRY": 10,
      "SWEET": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 1.5,
          "y": 12.25,
          "z": 6
        },
        "rotation": {
          "x": 5,
          "y": -15,
          "z": -5
        }
      },
      {
        "position": {
          "x": 2,
          "y": 11.25,
          "z": 11
        },
        "rotation": {
          "x": 0,
          "y": 17.5,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 12.5,
          "z": 14.75
        },
        "rotation": {
          "x": -2.5,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 11.5,
          "y": 11.5,
          "z": 14.25
        },
        "rotation": {
          "x": 2.5,
          "y": 17.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14.75,
          "y": 12.5,
          "z": 10
        },
        "rotation": {
          "x": -2.5,
          "y": -22.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 14.25,
          "y": 12,
          "z": 5
        },
        "rotation": {
          "x": -2.5,
          "y": 12.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 12.5,
          "z": 1.75
        },
        "rotation": {
          "x": 10,
          "y": 30,
          "z": 0
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 11.5,
          "z": 1.75
        },
        "rotation": {
          "x": 2.5,
          "y": -7.5,
          "z": 0
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "petaya_berry": {
    "id": "petaya_berry",
    "name": "Petaya Berry",
    "itemId": "lota:petaya_berry",
    "blockId": "lota:petaya_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "ORANGE",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "frill-sprout",
    "matureShape": "frill-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:petaya_berry.geo",
    "fruitTexture": "cobblemon:petaya",
    "flavours": {
      "SPICY": 30,
      "BITTER": 30,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 8.75,
          "z": 6.5
        },
        "rotation": {
          "x": 130,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 8.75,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": -130
        }
      },
      {
        "position": {
          "x": 8,
          "y": 8.75,
          "z": 9.5
        },
        "rotation": {
          "x": -50,
          "y": 0,
          "z": 180
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 8.75,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 130
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 11.75,
          "z": 7.25
        },
        "rotation": {
          "x": 147.5,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 11.75,
          "z": 8.75
        },
        "rotation": {
          "x": -32.5,
          "y": 45,
          "z": 180
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 11.75,
          "z": 8.75
        },
        "rotation": {
          "x": -32.5,
          "y": -45,
          "z": 180
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 11.75,
          "z": 7.25
        },
        "rotation": {
          "x": 147.5,
          "y": -45,
          "z": 0
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "pinap_berry": {
    "id": "pinap_berry",
    "name": "Pinap Berry",
    "itemId": "lota:pinap_berry",
    "blockId": "lota:pinap_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 15,
    "colour": "YELLOW",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": false,
    "mutations": {
      "lota:oran_berry": "lota:leppa_berry",
      "lota:iapapa_berry": "lota:nomel_berry"
    },
    "sproutShape": "sword-sprout",
    "matureShape": "sword-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:pinap_berry.geo",
    "fruitTexture": "cobblemon:pinap",
    "flavours": {
      "SPICY": 5,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 12,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 16,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 20,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 24,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 28,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 32,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 36,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 40,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 44,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 48,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "pomeg_berry": {
    "id": "pomeg_berry",
    "name": "Pomeg Berry",
    "itemId": "lota:pomeg_berry",
    "blockId": "lota:pomeg_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:kelpsy_berry": "lota:starf_berry",
      "lota:qualot_berry": "lota:starf_berry",
      "lota:hondew_berry": "lota:starf_berry",
      "lota:grepa_berry": "lota:starf_berry",
      "lota:tamato_berry": "lota:starf_berry"
    },
    "sproutShape": "frill-sprout",
    "matureShape": "frill-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:pomeg_berry.geo",
    "fruitTexture": "cobblemon:pomeg",
    "flavours": {
      "SPICY": 10,
      "SWEET": 10,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7,
          "y": 12.5,
          "z": 6.5
        },
        "rotation": {
          "x": 52.5,
          "y": -27.5,
          "z": -70
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 12.5,
          "z": 8
        },
        "rotation": {
          "x": 7.5,
          "y": -5,
          "z": 60
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 12.5,
          "z": 9.5
        },
        "rotation": {
          "x": -62.5,
          "y": 35,
          "z": -80
        }
      },
      {
        "position": {
          "x": 9,
          "y": 12,
          "z": 6.5
        },
        "rotation": {
          "x": 67.5,
          "y": 27.5,
          "z": 82.5
        }
      },
      {
        "position": {
          "x": 6.6,
          "y": 12.5,
          "z": 8
        },
        "rotation": {
          "x": -2.5,
          "y": 12.5,
          "z": -65
        }
      },
      {
        "position": {
          "x": 9,
          "y": 12,
          "z": 9.5
        },
        "rotation": {
          "x": -55,
          "y": -27.5,
          "z": 77.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "qualot_berry": {
    "id": "qualot_berry",
    "name": "Qualot Berry",
    "itemId": "lota:qualot_berry",
    "blockId": "lota:qualot_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "PINK",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:watmel_berry": "lota:ganlon_berry",
      "lota:pomeg_berry": "lota:starf_berry"
    },
    "sproutShape": "pyramid-sprout",
    "matureShape": "pyramid-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:qualot_berry.geo",
    "fruitTexture": "cobblemon:qualot",
    "flavours": {
      "SPICY": 10,
      "SWEET": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5,
          "y": 20.75,
          "z": 5.75
        },
        "rotation": {
          "x": 30,
          "y": 75,
          "z": 20
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 16.5,
          "z": 5
        },
        "rotation": {
          "x": 30,
          "y": 10,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 3.5,
          "y": 12.5,
          "z": 3
        },
        "rotation": {
          "x": 7.5,
          "y": 27.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 16,
          "z": 9.5
        },
        "rotation": {
          "x": 17.5,
          "y": -75,
          "z": -45
        }
      },
      {
        "position": {
          "x": 11,
          "y": 18,
          "z": 10
        },
        "rotation": {
          "x": -130,
          "y": 62.5,
          "z": 155
        }
      },
      {
        "position": {
          "x": 12.5,
          "y": 11.75,
          "z": 13
        },
        "rotation": {
          "x": -10,
          "y": 10,
          "z": -5
        }
      },
      {
        "position": {
          "x": 5,
          "y": 11,
          "z": 13
        },
        "rotation": {
          "x": -12.5,
          "y": -30,
          "z": 10
        }
      },
      {
        "position": {
          "x": 11,
          "y": 20.75,
          "z": 7.5
        },
        "rotation": {
          "x": 10,
          "y": -25,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 20,
          "z": 11
        },
        "rotation": {
          "x": -15,
          "y": -17.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 13,
          "y": 12.25,
          "z": 5.5
        },
        "rotation": {
          "x": -2.5,
          "y": -75,
          "z": 17.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "rabuta_berry": {
    "id": "rabuta_berry",
    "name": "Rabuta Berry",
    "itemId": "lota:rabuta_berry",
    "blockId": "lota:rabuta_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "GREEN",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:shuca_berry": "lota:hondew_berry",
      "lota:babiri_berry": "lota:durin_berry"
    },
    "sproutShape": "lilypad-sprout",
    "matureShape": "lilypad-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:rabuta_berry.geo",
    "fruitTexture": "cobblemon:rabuta",
    "flavours": {
      "BITTER": 20,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10,
          "y": 1,
          "z": 5.75
        },
        "rotation": {
          "x": 65,
          "y": -50,
          "z": 30
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 2,
          "z": 6
        },
        "rotation": {
          "x": 72.5,
          "y": 0,
          "z": 22.5
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 1,
          "z": 5.75
        },
        "rotation": {
          "x": 75,
          "y": 40,
          "z": -20
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 1.25,
          "z": 7.5
        },
        "rotation": {
          "x": -65,
          "y": -35,
          "z": -35
        }
      },
      {
        "position": {
          "x": 9.75,
          "y": 1.25,
          "z": 7.5
        },
        "rotation": {
          "x": -72.5,
          "y": 35,
          "z": 10
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 1.75,
          "z": 7.5
        },
        "rotation": {
          "x": -97.5,
          "y": -12.5,
          "z": 107.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "rawst_berry": {
    "id": "rawst_berry",
    "name": "Rawst Berry",
    "itemId": "lota:rawst_berry",
    "blockId": "lota:rawst_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 20,
    "colour": "CYAN",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 9,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:lum_berry",
      "lota:persim_berry": "lota:aguav_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:rawst_berry.geo",
    "fruitTexture": "cobblemon:rawst",
    "flavours": {
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9,
          "y": 1.25,
          "z": 6
        },
        "rotation": {
          "x": 155,
          "y": -17.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 1.5,
          "z": 8
        },
        "rotation": {
          "x": -180,
          "y": 50,
          "z": 30
        }
      },
      {
        "position": {
          "x": 9,
          "y": 1.5,
          "z": 9.75
        },
        "rotation": {
          "x": -152.5,
          "y": 27.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 7,
          "y": 1.25,
          "z": 6
        },
        "rotation": {
          "x": 120,
          "y": -62.5,
          "z": 75
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 1.25,
          "z": 8
        },
        "rotation": {
          "x": -180,
          "y": -35,
          "z": -25
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 1.5,
          "z": 9.5
        },
        "rotation": {
          "x": -147.5,
          "y": -12.5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 3,
          "z": 8.5
        },
        "rotation": {
          "x": -172.5,
          "y": -55,
          "z": -15
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 3,
          "z": 6.75
        },
        "rotation": {
          "x": 165,
          "y": -32.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 7,
          "y": 3,
          "z": 8.5
        },
        "rotation": {
          "x": -155,
          "y": -62.5,
          "z": -10
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "razz_berry": {
    "id": "razz_berry",
    "name": "Razz Berry",
    "itemId": "lota:razz_berry",
    "blockId": "lota:razz_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 15,
    "colour": "RED",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:leppa_berry",
      "lota:figy_berry": "lota:touga_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:razz_berry.geo",
    "fruitTexture": "cobblemon:razz",
    "flavours": {
      "SPICY": 10,
      "DRY": 5
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.5,
          "y": 18.75,
          "z": 11.25
        },
        "rotation": {
          "x": -10,
          "y": -10,
          "z": 0
        }
      },
      {
        "position": {
          "x": 11.5,
          "y": 19,
          "z": 10
        },
        "rotation": {
          "x": 160,
          "y": -67.5,
          "z": -165
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 18.75,
          "z": 5.5
        },
        "rotation": {
          "x": -5,
          "y": 40,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 4.75,
          "y": 25.25,
          "z": 9.5
        },
        "rotation": {
          "x": 7.5,
          "y": -45,
          "z": -15
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 25.25,
          "z": 10.25
        },
        "rotation": {
          "x": -17.5,
          "y": 2.5,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 24.75,
          "z": 5.5
        },
        "rotation": {
          "x": 12.5,
          "y": 35,
          "z": 12.5
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 12.75,
          "z": 9.25
        },
        "rotation": {
          "x": -10,
          "y": 12.5,
          "z": 5
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 13.25,
          "z": 5.75
        },
        "rotation": {
          "x": 15,
          "y": 5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 13,
          "z": 10
        },
        "rotation": {
          "x": -2.5,
          "y": 62.5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 10.5,
          "y": 18.75,
          "z": 3.75
        },
        "rotation": {
          "x": -12.5,
          "y": -50,
          "z": 20
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "rindo_berry": {
    "id": "rindo_berry",
    "name": "Rindo Berry",
    "itemId": "lota:rindo_berry",
    "blockId": "lota:rindo_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "LIME",
    "favoriteMulches": [
      "humid",
      "loamy",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_temperate",
      "cobblemon:is_lush"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:cornn_berry": "lota:kelpsy_berry"
    },
    "sproutShape": "box-sprout",
    "matureShape": "box-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:rindo_berry.geo",
    "fruitTexture": "cobblemon:rindo",
    "flavours": {
      "SPICY": 10,
      "BITTER": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9.5,
          "y": 24,
          "z": 1
        },
        "rotation": {
          "x": 12.5,
          "y": 67.5,
          "z": 40
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 28,
          "z": 1
        },
        "rotation": {
          "x": 20,
          "y": -72.5,
          "z": -27.5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 23.25,
          "z": 3.5
        },
        "rotation": {
          "x": -35,
          "y": 12.5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 1,
          "y": 27.5,
          "z": 12.75
        },
        "rotation": {
          "x": 30,
          "y": -7.5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 24,
          "z": 15
        },
        "rotation": {
          "x": -160,
          "y": -72.5,
          "z": 150
        }
      },
      {
        "position": {
          "x": 8.25,
          "y": 28,
          "z": 15
        },
        "rotation": {
          "x": -165,
          "y": 70,
          "z": -125
        }
      },
      {
        "position": {
          "x": 15,
          "y": 23.25,
          "z": 12.25
        },
        "rotation": {
          "x": 160,
          "y": 12.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 15,
          "y": 27.5,
          "z": 7.25
        },
        "rotation": {
          "x": 22.5,
          "y": -20,
          "z": -2.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "roseli_berry": {
    "id": "roseli_berry",
    "name": "Roseli Berry",
    "itemId": "lota:roseli_berry",
    "blockId": "lota:roseli_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "loamy",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_floral",
      "cobblemon:is_island",
      "cobblemon:is_magical",
      "cobblemon:is_mushroom"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:magost_berry": "lota:qualot_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:roseli_berry.geo",
    "fruitTexture": "cobblemon:roseli",
    "flavours": {
      "SWEET": 25,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.25,
          "y": 1.75,
          "z": 7.25
        },
        "rotation": {
          "x": 137.5,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 1.75,
          "z": 8.75
        },
        "rotation": {
          "x": -42.5,
          "y": -45,
          "z": 180
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 2.75,
          "z": 7.25
        },
        "rotation": {
          "x": 150,
          "y": -7.5,
          "z": -30
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 2.75,
          "z": 8.75
        },
        "rotation": {
          "x": -30,
          "y": 7.5,
          "z": -150
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 4.75,
          "z": 7.25
        },
        "rotation": {
          "x": 82.5,
          "y": 72.5,
          "z": -80
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 4.75,
          "z": 8.75
        },
        "rotation": {
          "x": -97.5,
          "y": -72.5,
          "z": -100
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 5.75,
          "z": 7.25
        },
        "rotation": {
          "x": 157.5,
          "y": -45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 5.75,
          "z": 8.75
        },
        "rotation": {
          "x": -22.5,
          "y": 45,
          "z": 180
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "rowap_berry": {
    "id": "rowap_berry",
    "name": "Rowap Berry",
    "itemId": "lota:rowap_berry",
    "blockId": "lota:rowap_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "CYAN",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "volcano-sprout",
    "matureShape": "volcano-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:rowap_berry.geo",
    "fruitTexture": "cobblemon:rowap",
    "flavours": {
      "SPICY": 10,
      "SOUR": 40
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.25,
          "y": 13,
          "z": 7.25
        },
        "rotation": {
          "x": 12.5,
          "y": -17.5,
          "z": -170
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 13,
          "z": 8.75
        },
        "rotation": {
          "x": -157.5,
          "y": -57.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 13,
          "z": 8.75
        },
        "rotation": {
          "x": -167.5,
          "y": 20,
          "z": -10
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 13,
          "z": 7.25
        },
        "rotation": {
          "x": 25,
          "y": 60,
          "z": -170
        }
      }
    ],
    "effectGroup": "mutation_result",
    "showdownEffect": null
  },
  "salac_berry": {
    "id": "salac_berry",
    "name": "Salac Berry",
    "itemId": "lota:salac_berry",
    "blockId": "lota:salac_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "GREEN",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:salac_berry.geo",
    "fruitTexture": "cobblemon:salac",
    "flavours": {
      "SWEET": 30,
      "BITTER": 10,
      "SOUR": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.25,
          "y": 20.75,
          "z": 7.25
        },
        "rotation": {
          "x": 85,
          "y": -72.5,
          "z": 140
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 20.75,
          "z": 8.75
        },
        "rotation": {
          "x": -80,
          "y": 75,
          "z": 55
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 21.75,
          "z": 7.25
        },
        "rotation": {
          "x": 55,
          "y": 37.5,
          "z": -170
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 21.75,
          "z": 8.75
        },
        "rotation": {
          "x": -125,
          "y": -37.5,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 23.75,
          "z": 7.5
        },
        "rotation": {
          "x": 17.5,
          "y": -10,
          "z": -170
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 23.75,
          "z": 8.5
        },
        "rotation": {
          "x": -160,
          "y": 12.5,
          "z": -10
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "shuca_berry": {
    "id": "shuca_berry",
    "name": "Shuca Berry",
    "itemId": "lota:shuca_berry",
    "blockId": "lota:shuca_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "BROWN",
    "favoriteMulches": [
      "loamy",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid",
      "cobblemon:is_grassland"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:rabuta_berry": "lota:hondew_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:shuca_berry.geo",
    "fruitTexture": "cobblemon:shuca",
    "flavours": {
      "SPICY": 10,
      "SWEET": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 1.5,
          "y": 12,
          "z": 8
        },
        "rotation": {
          "x": -15,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 12,
          "z": 1.5
        },
        "rotation": {
          "x": 15,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 14.5,
          "y": 12,
          "z": 8
        },
        "rotation": {
          "x": 15,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 12,
          "z": 14.5
        },
        "rotation": {
          "x": -165,
          "y": 0,
          "z": -180
        }
      },
      {
        "position": {
          "x": 3.75,
          "y": 10,
          "z": 3.75
        },
        "rotation": {
          "x": 15,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12.25,
          "y": 10,
          "z": 3.75
        },
        "rotation": {
          "x": 15,
          "y": -45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 12.25,
          "y": 10,
          "z": 12.25
        },
        "rotation": {
          "x": 15,
          "y": -135,
          "z": 0
        }
      },
      {
        "position": {
          "x": 3.75,
          "y": 10,
          "z": 12.25
        },
        "rotation": {
          "x": 15,
          "y": 135,
          "z": 0
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "sitrus_berry": {
    "id": "sitrus_berry",
    "name": "Sitrus Berry",
    "itemId": "lota:sitrus_berry",
    "blockId": "lota:sitrus_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "YELLOW",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_mountain",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:haban_berry": "lota:pomeg_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:sitrus_berry.geo",
    "fruitTexture": "cobblemon:sitrus",
    "flavours": {
      "DRY": 10,
      "SWEET": 10,
      "BITTER": 10,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 3.5,
          "y": 22.5,
          "z": 3.75
        },
        "rotation": {
          "x": 17.5,
          "y": -10,
          "z": -5
        }
      },
      {
        "position": {
          "x": 3.5,
          "y": 20.75,
          "z": 9
        },
        "rotation": {
          "x": -15,
          "y": -22.5,
          "z": -20
        }
      },
      {
        "position": {
          "x": 6.5,
          "y": 17,
          "z": 2
        },
        "rotation": {
          "x": 12.5,
          "y": 15,
          "z": 2.5
        }
      },
      {
        "position": {
          "x": 14,
          "y": 16.25,
          "z": 6
        },
        "rotation": {
          "x": 7.5,
          "y": 10,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 12.5,
          "y": 17.5,
          "z": 14
        },
        "rotation": {
          "x": -10,
          "y": -30,
          "z": 10
        }
      },
      {
        "position": {
          "x": 12.5,
          "y": 21.25,
          "z": 8.75
        },
        "rotation": {
          "x": -7.5,
          "y": -7.5,
          "z": 27.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 21.5,
          "z": 12.5
        },
        "rotation": {
          "x": -22.5,
          "y": 0,
          "z": -10
        }
      },
      {
        "position": {
          "x": 4.75,
          "y": 16,
          "z": 14
        },
        "rotation": {
          "x": -22.5,
          "y": -7.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 2,
          "y": 15.75,
          "z": 6
        },
        "rotation": {
          "x": 2.5,
          "y": 12.5,
          "z": -17.5
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 21.5,
          "z": 3.5
        },
        "rotation": {
          "x": 22.5,
          "y": -10,
          "z": 7.5
        }
      }
    ],
    "effectGroup": "mutation_result",
    "showdownEffect": null
  },
  "spelon_berry": {
    "id": "spelon_berry",
    "name": "Spelon Berry",
    "itemId": "lota:spelon_berry",
    "blockId": "lota:spelon_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:tamato_berry": "lota:salac_berry",
      "lota:chople_berry": "lota:lansat_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:spelon_berry.geo",
    "fruitTexture": "cobblemon:spelon",
    "flavours": {
      "SPICY": 30,
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.5,
          "y": 4.5,
          "z": 8.5
        },
        "rotation": {
          "x": -140,
          "y": -45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 4.5,
          "z": 7.25
        },
        "rotation": {
          "x": 145,
          "y": -47.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 4.25,
          "z": 7.5
        },
        "rotation": {
          "x": 140,
          "y": 45,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 4.25,
          "z": 8.75
        },
        "rotation": {
          "x": -145,
          "y": 45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5.5,
          "z": 9
        },
        "rotation": {
          "x": -20,
          "y": -42.5,
          "z": -165
        }
      },
      {
        "position": {
          "x": 7,
          "y": 6,
          "z": 8
        },
        "rotation": {
          "x": -2.5,
          "y": 47.5,
          "z": -167.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 5.25,
          "z": 7
        },
        "rotation": {
          "x": 17.5,
          "y": -42.5,
          "z": 170
        }
      },
      {
        "position": {
          "x": 9,
          "y": 5.75,
          "z": 8
        },
        "rotation": {
          "x": -177.5,
          "y": -45,
          "z": -15
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "starf_berry": {
    "id": "starf_berry",
    "name": "Starf Berry",
    "itemId": "lota:starf_berry",
    "blockId": "lota:starf_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 1,
    "growthMinutesMin": 54,
    "growthMinutesMax": 66,
    "refreshMinutesMin": 27,
    "refreshMinutesMax": 33,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.24,
    "weight": 1,
    "colour": "GREEN",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {},
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:starf_berry.geo",
    "fruitTexture": "cobblemon:starf",
    "flavours": {
      "SPICY": 30,
      "DRY": 10,
      "SWEET": 30,
      "BITTER": 10,
      "SOUR": 30
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8.75,
          "y": 6.5,
          "z": 6
        },
        "rotation": {
          "x": 77.5,
          "y": 22.5,
          "z": -170
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 6.5,
          "z": 8.25
        },
        "rotation": {
          "x": -15,
          "y": 45,
          "z": -120
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 6.5,
          "z": 9.5
        },
        "rotation": {
          "x": -55,
          "y": -30,
          "z": 152.5
        }
      },
      {
        "position": {
          "x": 7.75,
          "y": 8.25,
          "z": 9
        },
        "rotation": {
          "x": -130,
          "y": -50,
          "z": -32.5
        }
      },
      {
        "position": {
          "x": 7.5,
          "y": 8.25,
          "z": 6.75
        },
        "rotation": {
          "x": 157.5,
          "y": 10,
          "z": 20
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 8.25,
          "z": 7.75
        },
        "rotation": {
          "x": 165,
          "y": 65,
          "z": -45
        }
      }
    ],
    "effectGroup": "stat_buff",
    "showdownEffect": null
  },
  "tamato_berry": {
    "id": "tamato_berry",
    "name": "Tamato Berry",
    "itemId": "lota:tamato_berry",
    "blockId": "lota:tamato_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:spelon_berry": "lota:salac_berry",
      "lota:pomeg_berry": "lota:starf_berry"
    },
    "sproutShape": "box-sprout",
    "matureShape": "box-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:tamato_berry.geo",
    "fruitTexture": "cobblemon:tamato",
    "flavours": {
      "SPICY": 20,
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10,
          "y": 26,
          "z": 1
        },
        "rotation": {
          "x": 10,
          "y": -7.5,
          "z": 7.5
        }
      },
      {
        "position": {
          "x": 15,
          "y": 23,
          "z": 12
        },
        "rotation": {
          "x": -17.5,
          "y": -20,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 28.25,
          "z": 12
        },
        "rotation": {
          "x": -17.5,
          "y": 17.5,
          "z": -22.5
        }
      },
      {
        "position": {
          "x": 5.5,
          "y": 20.5,
          "z": 1
        },
        "rotation": {
          "x": 15,
          "y": 2.5,
          "z": -7.5
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 27,
          "z": 15
        },
        "rotation": {
          "x": -15,
          "y": 17.5,
          "z": -5
        }
      },
      {
        "position": {
          "x": 1,
          "y": 22.5,
          "z": 7.5
        },
        "rotation": {
          "x": 10,
          "y": 12.5,
          "z": -15
        }
      },
      {
        "position": {
          "x": 15,
          "y": 28.75,
          "z": 7
        },
        "rotation": {
          "x": 167.5,
          "y": -35,
          "z": -157.5
        }
      },
      {
        "position": {
          "x": 1.5,
          "y": 27.5,
          "z": 1.5
        },
        "rotation": {
          "x": 10,
          "y": 47.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 15,
          "y": 21,
          "z": 3.5
        },
        "rotation": {
          "x": -2.5,
          "y": -22.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 4.5,
          "y": 20.75,
          "z": 15
        },
        "rotation": {
          "x": -15,
          "y": -22.5,
          "z": 15
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "tanga_berry": {
    "id": "tanga_berry",
    "name": "Tanga Berry",
    "itemId": "lota:tanga_berry",
    "blockId": "lota:tanga_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "GREEN",
    "favoriteMulches": [
      "humid",
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest",
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 8,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:magost_berry": "lota:watmel_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:tanga_berry.geo",
    "fruitTexture": "cobblemon:tanga",
    "flavours": {
      "SPICY": 20,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 4,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 10.25,
          "y": 5.75,
          "z": 2.5
        },
        "rotation": {
          "x": 0,
          "y": -45,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 5.5,
          "z": 13.5
        },
        "rotation": {
          "x": 0,
          "y": -167.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 2.5,
          "y": 6,
          "z": 5.75
        },
        "rotation": {
          "x": 0,
          "y": 77.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 13.5,
          "y": 5.5,
          "z": 10.25
        },
        "rotation": {
          "x": 0,
          "y": -87.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 5.5,
          "z": 2.5
        },
        "rotation": {
          "x": 0,
          "y": 27.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 2.5,
          "y": 5.75,
          "z": 10.25
        },
        "rotation": {
          "x": 0,
          "y": 130,
          "z": 0
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 6,
          "z": 13.5
        },
        "rotation": {
          "x": 0,
          "y": -147.5,
          "z": 0
        }
      },
      {
        "position": {
          "x": 13.5,
          "y": 5.75,
          "z": 5.75
        },
        "rotation": {
          "x": 0,
          "y": -105,
          "z": 0
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "touga_berry": {
    "id": "touga_berry",
    "name": "Touga Berry",
    "itemId": "lota:touga_berry",
    "blockId": "lota:touga_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 1,
    "colour": "RED",
    "favoriteMulches": [
      "peat"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_forest"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:occa_berry": "lota:tamato_berry",
      "lota:colbur_berry": "lota:spelon_berry"
    },
    "sproutShape": "blossom-sprout",
    "matureShape": "blossom-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:touga_berry.geo",
    "fruitTexture": "cobblemon:touga",
    "flavours": {
      "SPICY": 20,
      "DRY": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 0.75,
          "z": 8
        },
        "rotation": {
          "x": 75,
          "y": 65,
          "z": -37.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.75,
          "z": 8
        },
        "rotation": {
          "x": -47.5,
          "y": -57.5,
          "z": 155
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.5,
          "z": 8
        },
        "rotation": {
          "x": -30,
          "y": 37.5,
          "z": -147.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0.75,
          "z": 8
        },
        "rotation": {
          "x": 150,
          "y": -40,
          "z": -42.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0,
          "z": 8
        },
        "rotation": {
          "x": -75,
          "y": 25,
          "z": 170
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0,
          "z": 8
        },
        "rotation": {
          "x": 112.5,
          "y": -17.5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 8,
          "y": 0,
          "z": 7.75
        },
        "rotation": {
          "x": 125,
          "y": 20,
          "z": 5
        }
      },
      {
        "position": {
          "x": 8,
          "y": -0.25,
          "z": 8.5
        },
        "rotation": {
          "x": -52.5,
          "y": -32.5,
          "z": -175
        }
      },
      {
        "position": {
          "x": 7.25,
          "y": 0.5,
          "z": 8.25
        },
        "rotation": {
          "x": -70,
          "y": 42.5,
          "z": -157.5
        }
      },
      {
        "position": {
          "x": 9,
          "y": 0.5,
          "z": 7.75
        },
        "rotation": {
          "x": 87.5,
          "y": -45,
          "z": 7.5
        }
      }
    ],
    "effectGroup": "status_recovery",
    "showdownEffect": null
  },
  "wacan_berry": {
    "id": "wacan_berry",
    "name": "Wacan Berry",
    "itemId": "lota:wacan_berry",
    "blockId": "lota:wacan_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "YELLOW",
    "favoriteMulches": [
      "coarse",
      "loamy",
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_grassland",
      "cobblemon:is_hills",
      "cobblemon:is_sky"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 9,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:enigma_berry": "lota:maranga_berry"
    },
    "sproutShape": "tall-sprout",
    "matureShape": "tall-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:wacan_berry.geo",
    "fruitTexture": "cobblemon:wacan",
    "flavours": {
      "SWEET": 15,
      "SOUR": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.2,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 5.5,
          "y": 18.75,
          "z": 5.75
        },
        "rotation": {
          "x": 0,
          "y": -5,
          "z": -10
        }
      },
      {
        "position": {
          "x": 9.5,
          "y": 24.75,
          "z": 6.25
        },
        "rotation": {
          "x": 25,
          "y": -62.5,
          "z": -20
        }
      },
      {
        "position": {
          "x": 10,
          "y": 12.75,
          "z": 9.75
        },
        "rotation": {
          "x": 5,
          "y": 17.5,
          "z": 10
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 18.75,
          "z": 9.5
        },
        "rotation": {
          "x": -42.5,
          "y": -55,
          "z": 35
        }
      },
      {
        "position": {
          "x": 6,
          "y": 12.75,
          "z": 9.75
        },
        "rotation": {
          "x": -2.5,
          "y": -20,
          "z": -10
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 12.75,
          "z": 6
        },
        "rotation": {
          "x": 40,
          "y": 67.5,
          "z": 50
        }
      },
      {
        "position": {
          "x": 5.75,
          "y": 24.75,
          "z": 10
        },
        "rotation": {
          "x": 7.5,
          "y": -22.5,
          "z": -22.5
        }
      },
      {
        "position": {
          "x": 10.25,
          "y": 18.75,
          "z": 6
        },
        "rotation": {
          "x": -10,
          "y": -22.5,
          "z": 17.5
        }
      },
      {
        "position": {
          "x": 9.75,
          "y": 24.75,
          "z": 10
        },
        "rotation": {
          "x": -30,
          "y": 62.5,
          "z": -22.5
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  },
  "watmel_berry": {
    "id": "watmel_berry",
    "name": "Watmel Berry",
    "itemId": "lota:watmel_berry",
    "blockId": "lota:watmel_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 2,
    "growthMinutesMin": 50,
    "growthMinutesMax": 60,
    "refreshMinutesMin": 25,
    "refreshMinutesMax": 29,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.32,
    "weight": 1,
    "colour": "PINK",
    "favoriteMulches": [
      "humid"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_jungle",
      "cobblemon:is_swamp"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 4,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:qualot_berry": "lota:ganlon_berry",
      "lota:chilan_berry": "lota:custap_berry"
    },
    "sproutShape": "lilypad-sprout",
    "matureShape": "lilypad-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:watmel_berry.geo",
    "fruitTexture": "cobblemon:watmel",
    "flavours": {
      "SWEET": 30,
      "BITTER": 10
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.25,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7,
          "y": 1.75,
          "z": 7
        },
        "rotation": {
          "x": 80,
          "y": 30,
          "z": -5
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 2,
          "z": 7
        },
        "rotation": {
          "x": 80,
          "y": -35,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 2,
          "z": 7
        },
        "rotation": {
          "x": -77.5,
          "y": -25,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 1.5,
          "z": 7
        },
        "rotation": {
          "x": -85,
          "y": 22.5,
          "z": -2.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "wepear_berry": {
    "id": "wepear_berry",
    "name": "Wepear Berry",
    "itemId": "lota:wepear_berry",
    "blockId": "lota:wepear_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 36,
    "growthMinutesMax": 44,
    "refreshMinutesMin": 18,
    "refreshMinutesMax": 22,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.56,
    "weight": 15,
    "colour": "LIME",
    "favoriteMulches": [
      "loamy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_plains"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:oran_berry": "lota:leppa_berry",
      "lota:aguav_berry": "lota:rabuta_berry"
    },
    "sproutShape": "pyramid-sprout",
    "matureShape": "pyramid-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:wepear_berry.geo",
    "fruitTexture": "cobblemon:wepear",
    "flavours": {
      "BITTER": 10,
      "SOUR": 5
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3.75,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 9.5,
          "y": 14,
          "z": 3
        },
        "rotation": {
          "x": 17.5,
          "y": -22.5,
          "z": -12.5
        }
      },
      {
        "position": {
          "x": 4.75,
          "y": 18,
          "z": 9.25
        },
        "rotation": {
          "x": 117.5,
          "y": 85,
          "z": 90
        }
      },
      {
        "position": {
          "x": 4.5,
          "y": 13,
          "z": 13
        },
        "rotation": {
          "x": -10,
          "y": -25,
          "z": -10
        }
      },
      {
        "position": {
          "x": 11.25,
          "y": 15.75,
          "z": 10.5
        },
        "rotation": {
          "x": 37.5,
          "y": -80,
          "z": -5
        }
      },
      {
        "position": {
          "x": 8.75,
          "y": 20.75,
          "z": 11
        },
        "rotation": {
          "x": -22.5,
          "y": 10,
          "z": -10
        }
      },
      {
        "position": {
          "x": 10,
          "y": 11,
          "z": 13
        },
        "rotation": {
          "x": -17.5,
          "y": 35,
          "z": -2.5
        }
      },
      {
        "position": {
          "x": 13.25,
          "y": 10.5,
          "z": 5.25
        },
        "rotation": {
          "x": -10,
          "y": -67.5,
          "z": 20
        }
      },
      {
        "position": {
          "x": 11,
          "y": 20.75,
          "z": 5.75
        },
        "rotation": {
          "x": 35,
          "y": -75,
          "z": -15
        }
      },
      {
        "position": {
          "x": 6.25,
          "y": 20.75,
          "z": 5
        },
        "rotation": {
          "x": 155,
          "y": -40,
          "z": -177.5
        }
      },
      {
        "position": {
          "x": 3,
          "y": 11.25,
          "z": 4
        },
        "rotation": {
          "x": 22.5,
          "y": 65,
          "z": 12.5
        }
      }
    ],
    "effectGroup": "non_battle",
    "showdownEffect": null
  },
  "wiki_berry": {
    "id": "wiki_berry",
    "name": "Wiki Berry",
    "itemId": "lota:wiki_berry",
    "blockId": "lota:wiki_berry_bush",
    "baseYieldMin": 2,
    "baseYieldMax": 3,
    "growthMinutesMin": 41,
    "growthMinutesMax": 49,
    "refreshMinutesMin": 20,
    "refreshMinutesMax": 24,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.48,
    "weight": 1,
    "colour": "PURPLE",
    "favoriteMulches": [
      "sandy"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_arid"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [],
    "growthPointCount": 6,
    "randomizedGrowthPoints": true,
    "mutations": {
      "lota:lum_berry": "lota:sitrus_berry",
      "lota:bluk_berry": "lota:cornn_berry",
      "lota:leppa_berry": "lota:eggant_berry"
    },
    "sproutShape": "short-sprout",
    "matureShape": "short-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:wiki_berry.geo",
    "fruitTexture": "cobblemon:wiki",
    "flavours": {
      "DRY": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 2.5,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 7.5,
          "y": 14,
          "z": 8.5
        },
        "rotation": {
          "x": -15,
          "y": -25,
          "z": -147.5
        }
      },
      {
        "position": {
          "x": 8.5,
          "y": 14,
          "z": 8.5
        },
        "rotation": {
          "x": -15,
          "y": 25,
          "z": 147.5
        }
      },
      {
        "position": {
          "x": 8,
          "y": 14,
          "z": 7.5
        },
        "rotation": {
          "x": 152.5,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 14,
          "z": 9.5
        },
        "rotation": {
          "x": -130,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 9.25,
          "y": 14,
          "z": 7.5
        },
        "rotation": {
          "x": 25,
          "y": -20,
          "z": 125
        }
      },
      {
        "position": {
          "x": 6.75,
          "y": 14,
          "z": 7.5
        },
        "rotation": {
          "x": 25,
          "y": 20,
          "z": -127.5
        }
      }
    ],
    "effectGroup": "nature_recovery",
    "showdownEffect": null
  },
  "yache_berry": {
    "id": "yache_berry",
    "name": "Yache Berry",
    "itemId": "lota:yache_berry",
    "blockId": "lota:yache_berry_bush",
    "baseYieldMin": 1,
    "baseYieldMax": 3,
    "growthMinutesMin": 45,
    "growthMinutesMax": 55,
    "refreshMinutesMin": 23,
    "refreshMinutesMax": 27,
    "growthTimeMultiplier": 1.4,
    "boneMealChance": 0.4,
    "weight": 2,
    "colour": "CYAN",
    "favoriteMulches": [
      "coarse"
    ],
    "preferredBiomeTags": [
      "cobblemon:is_freezing",
      "cobblemon:is_taiga"
    ],
    "growthFactors": [
      {
        "variant": "cobblemon:preferred_biome",
        "bonusYield": {
          "min": 0,
          "max": 1
        }
      }
    ],
    "spawnConditions": [
      {
        "variant": "cobblemon:preferred_biome",
        "minGroveSize": 3,
        "maxGroveSize": 5
      }
    ],
    "growthPointCount": 10,
    "randomizedGrowthPoints": false,
    "mutations": {
      "lota:hopo_berry": "lota:enigma_berry",
      "lota:nomel_berry": "lota:grepa_berry"
    },
    "sproutShape": "sword-sprout",
    "matureShape": "sword-mature",
    "flowerModel": "cobblemon:flower.geo",
    "flowerTexture": "cobblemon:flower",
    "fruitModel": "cobblemon:yache_berry.geo",
    "fruitTexture": "cobblemon:yache",
    "flavours": {
      "DRY": 10,
      "SOUR": 15
    },
    "stageOnePositioning": {
      "position": {
        "x": 8.15,
        "y": 3,
        "z": 8.1
      },
      "rotation": {
        "x": 5,
        "y": -10,
        "z": -7.5
      }
    },
    "growthPoints": [
      {
        "position": {
          "x": 8,
          "y": 11.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 14.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 17.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 20.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 23.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 26.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 29.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -180,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 32.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": -90,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 35.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 0,
          "z": 0
        }
      },
      {
        "position": {
          "x": 8,
          "y": 38.5,
          "z": 8
        },
        "rotation": {
          "x": 0,
          "y": 90,
          "z": 0
        }
      }
    ],
    "effectGroup": "damage_reduction",
    "showdownEffect": null
  }
});

export const BERRY_IDS = Object.freeze([
  "aguav_berry",
  "apicot_berry",
  "aspear_berry",
  "babiri_berry",
  "belue_berry",
  "bluk_berry",
  "charti_berry",
  "cheri_berry",
  "chesto_berry",
  "chilan_berry",
  "chople_berry",
  "coba_berry",
  "colbur_berry",
  "cornn_berry",
  "custap_berry",
  "durin_berry",
  "eggant_berry",
  "enigma_berry",
  "figy_berry",
  "ganlon_berry",
  "grepa_berry",
  "haban_berry",
  "hondew_berry",
  "hopo_berry",
  "iapapa_berry",
  "jaboca_berry",
  "kasib_berry",
  "kebia_berry",
  "kee_berry",
  "kelpsy_berry",
  "lansat_berry",
  "leppa_berry",
  "liechi_berry",
  "lum_berry",
  "mago_berry",
  "magost_berry",
  "maranga_berry",
  "micle_berry",
  "nanab_berry",
  "nomel_berry",
  "occa_berry",
  "oran_berry",
  "pamtre_berry",
  "passho_berry",
  "payapa_berry",
  "pecha_berry",
  "persim_berry",
  "petaya_berry",
  "pinap_berry",
  "pomeg_berry",
  "qualot_berry",
  "rabuta_berry",
  "rawst_berry",
  "razz_berry",
  "rindo_berry",
  "roseli_berry",
  "rowap_berry",
  "salac_berry",
  "shuca_berry",
  "sitrus_berry",
  "spelon_berry",
  "starf_berry",
  "tamato_berry",
  "tanga_berry",
  "touga_berry",
  "wacan_berry",
  "watmel_berry",
  "wepear_berry",
  "wiki_berry",
  "yache_berry"
]);

export const BERRY_ITEM_TO_BLOCK = Object.freeze({
  "lota:aguav_berry": "lota:aguav_berry_bush",
  "lota:apicot_berry": "lota:apicot_berry_bush",
  "lota:aspear_berry": "lota:aspear_berry_bush",
  "lota:babiri_berry": "lota:babiri_berry_bush",
  "lota:belue_berry": "lota:belue_berry_bush",
  "lota:bluk_berry": "lota:bluk_berry_bush",
  "lota:charti_berry": "lota:charti_berry_bush",
  "lota:cheri_berry": "lota:cheri_berry_bush",
  "lota:chesto_berry": "lota:chesto_berry_bush",
  "lota:chilan_berry": "lota:chilan_berry_bush",
  "lota:chople_berry": "lota:chople_berry_bush",
  "lota:coba_berry": "lota:coba_berry_bush",
  "lota:colbur_berry": "lota:colbur_berry_bush",
  "lota:cornn_berry": "lota:cornn_berry_bush",
  "lota:custap_berry": "lota:custap_berry_bush",
  "lota:durin_berry": "lota:durin_berry_bush",
  "lota:eggant_berry": "lota:eggant_berry_bush",
  "lota:enigma_berry": "lota:enigma_berry_bush",
  "lota:figy_berry": "lota:figy_berry_bush",
  "lota:ganlon_berry": "lota:ganlon_berry_bush",
  "lota:grepa_berry": "lota:grepa_berry_bush",
  "lota:haban_berry": "lota:haban_berry_bush",
  "lota:hondew_berry": "lota:hondew_berry_bush",
  "lota:hopo_berry": "lota:hopo_berry_bush",
  "lota:iapapa_berry": "lota:iapapa_berry_bush",
  "lota:jaboca_berry": "lota:jaboca_berry_bush",
  "lota:kasib_berry": "lota:kasib_berry_bush",
  "lota:kebia_berry": "lota:kebia_berry_bush",
  "lota:kee_berry": "lota:kee_berry_bush",
  "lota:kelpsy_berry": "lota:kelpsy_berry_bush",
  "lota:lansat_berry": "lota:lansat_berry_bush",
  "lota:leppa_berry": "lota:leppa_berry_bush",
  "lota:liechi_berry": "lota:liechi_berry_bush",
  "lota:lum_berry": "lota:lum_berry_bush",
  "lota:mago_berry": "lota:mago_berry_bush",
  "lota:magost_berry": "lota:magost_berry_bush",
  "lota:maranga_berry": "lota:maranga_berry_bush",
  "lota:micle_berry": "lota:micle_berry_bush",
  "lota:nanab_berry": "lota:nanab_berry_bush",
  "lota:nomel_berry": "lota:nomel_berry_bush",
  "lota:occa_berry": "lota:occa_berry_bush",
  "lota:oran_berry": "lota:oran_berry_bush",
  "lota:pamtre_berry": "lota:pamtre_berry_bush",
  "lota:passho_berry": "lota:passho_berry_bush",
  "lota:payapa_berry": "lota:payapa_berry_bush",
  "lota:pecha_berry": "lota:pecha_berry_bush",
  "lota:persim_berry": "lota:persim_berry_bush",
  "lota:petaya_berry": "lota:petaya_berry_bush",
  "lota:pinap_berry": "lota:pinap_berry_bush",
  "lota:pomeg_berry": "lota:pomeg_berry_bush",
  "lota:qualot_berry": "lota:qualot_berry_bush",
  "lota:rabuta_berry": "lota:rabuta_berry_bush",
  "lota:rawst_berry": "lota:rawst_berry_bush",
  "lota:razz_berry": "lota:razz_berry_bush",
  "lota:rindo_berry": "lota:rindo_berry_bush",
  "lota:roseli_berry": "lota:roseli_berry_bush",
  "lota:rowap_berry": "lota:rowap_berry_bush",
  "lota:salac_berry": "lota:salac_berry_bush",
  "lota:shuca_berry": "lota:shuca_berry_bush",
  "lota:sitrus_berry": "lota:sitrus_berry_bush",
  "lota:spelon_berry": "lota:spelon_berry_bush",
  "lota:starf_berry": "lota:starf_berry_bush",
  "lota:tamato_berry": "lota:tamato_berry_bush",
  "lota:tanga_berry": "lota:tanga_berry_bush",
  "lota:touga_berry": "lota:touga_berry_bush",
  "lota:wacan_berry": "lota:wacan_berry_bush",
  "lota:watmel_berry": "lota:watmel_berry_bush",
  "lota:wepear_berry": "lota:wepear_berry_bush",
  "lota:wiki_berry": "lota:wiki_berry_bush",
  "lota:yache_berry": "lota:yache_berry_bush"
});

export const BERRY_BLOCK_TO_ITEM = Object.freeze({
  "lota:aguav_berry_bush": "lota:aguav_berry",
  "lota:apicot_berry_bush": "lota:apicot_berry",
  "lota:aspear_berry_bush": "lota:aspear_berry",
  "lota:babiri_berry_bush": "lota:babiri_berry",
  "lota:belue_berry_bush": "lota:belue_berry",
  "lota:bluk_berry_bush": "lota:bluk_berry",
  "lota:charti_berry_bush": "lota:charti_berry",
  "lota:cheri_berry_bush": "lota:cheri_berry",
  "lota:chesto_berry_bush": "lota:chesto_berry",
  "lota:chilan_berry_bush": "lota:chilan_berry",
  "lota:chople_berry_bush": "lota:chople_berry",
  "lota:coba_berry_bush": "lota:coba_berry",
  "lota:colbur_berry_bush": "lota:colbur_berry",
  "lota:cornn_berry_bush": "lota:cornn_berry",
  "lota:custap_berry_bush": "lota:custap_berry",
  "lota:durin_berry_bush": "lota:durin_berry",
  "lota:eggant_berry_bush": "lota:eggant_berry",
  "lota:enigma_berry_bush": "lota:enigma_berry",
  "lota:figy_berry_bush": "lota:figy_berry",
  "lota:ganlon_berry_bush": "lota:ganlon_berry",
  "lota:grepa_berry_bush": "lota:grepa_berry",
  "lota:haban_berry_bush": "lota:haban_berry",
  "lota:hondew_berry_bush": "lota:hondew_berry",
  "lota:hopo_berry_bush": "lota:hopo_berry",
  "lota:iapapa_berry_bush": "lota:iapapa_berry",
  "lota:jaboca_berry_bush": "lota:jaboca_berry",
  "lota:kasib_berry_bush": "lota:kasib_berry",
  "lota:kebia_berry_bush": "lota:kebia_berry",
  "lota:kee_berry_bush": "lota:kee_berry",
  "lota:kelpsy_berry_bush": "lota:kelpsy_berry",
  "lota:lansat_berry_bush": "lota:lansat_berry",
  "lota:leppa_berry_bush": "lota:leppa_berry",
  "lota:liechi_berry_bush": "lota:liechi_berry",
  "lota:lum_berry_bush": "lota:lum_berry",
  "lota:mago_berry_bush": "lota:mago_berry",
  "lota:magost_berry_bush": "lota:magost_berry",
  "lota:maranga_berry_bush": "lota:maranga_berry",
  "lota:micle_berry_bush": "lota:micle_berry",
  "lota:nanab_berry_bush": "lota:nanab_berry",
  "lota:nomel_berry_bush": "lota:nomel_berry",
  "lota:occa_berry_bush": "lota:occa_berry",
  "lota:oran_berry_bush": "lota:oran_berry",
  "lota:pamtre_berry_bush": "lota:pamtre_berry",
  "lota:passho_berry_bush": "lota:passho_berry",
  "lota:payapa_berry_bush": "lota:payapa_berry",
  "lota:pecha_berry_bush": "lota:pecha_berry",
  "lota:persim_berry_bush": "lota:persim_berry",
  "lota:petaya_berry_bush": "lota:petaya_berry",
  "lota:pinap_berry_bush": "lota:pinap_berry",
  "lota:pomeg_berry_bush": "lota:pomeg_berry",
  "lota:qualot_berry_bush": "lota:qualot_berry",
  "lota:rabuta_berry_bush": "lota:rabuta_berry",
  "lota:rawst_berry_bush": "lota:rawst_berry",
  "lota:razz_berry_bush": "lota:razz_berry",
  "lota:rindo_berry_bush": "lota:rindo_berry",
  "lota:roseli_berry_bush": "lota:roseli_berry",
  "lota:rowap_berry_bush": "lota:rowap_berry",
  "lota:salac_berry_bush": "lota:salac_berry",
  "lota:shuca_berry_bush": "lota:shuca_berry",
  "lota:sitrus_berry_bush": "lota:sitrus_berry",
  "lota:spelon_berry_bush": "lota:spelon_berry",
  "lota:starf_berry_bush": "lota:starf_berry",
  "lota:tamato_berry_bush": "lota:tamato_berry",
  "lota:tanga_berry_bush": "lota:tanga_berry",
  "lota:touga_berry_bush": "lota:touga_berry",
  "lota:wacan_berry_bush": "lota:wacan_berry",
  "lota:watmel_berry_bush": "lota:watmel_berry",
  "lota:wepear_berry_bush": "lota:wepear_berry",
  "lota:wiki_berry_bush": "lota:wiki_berry",
  "lota:yache_berry_bush": "lota:yache_berry"
});

export const MUTATION_EDGES = Object.freeze([
  {
    "parentA": "lota:aguav_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:aguav_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:aguav_berry",
    "parentB": "lota:wepear_berry",
    "result": "lota:rabuta_berry"
  },
  {
    "parentA": "lota:aspear_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:aspear_berry",
    "parentB": "lota:persim_berry",
    "result": "lota:iapapa_berry"
  },
  {
    "parentA": "lota:babiri_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:babiri_berry",
    "parentB": "lota:rabuta_berry",
    "result": "lota:durin_berry"
  },
  {
    "parentA": "lota:belue_berry",
    "parentB": "lota:coba_berry",
    "result": "lota:rowap_berry"
  },
  {
    "parentA": "lota:belue_berry",
    "parentB": "lota:grepa_berry",
    "result": "lota:apicot_berry"
  },
  {
    "parentA": "lota:bluk_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:bluk_berry",
    "parentB": "lota:wiki_berry",
    "result": "lota:cornn_berry"
  },
  {
    "parentA": "lota:charti_berry",
    "parentB": "lota:durin_berry",
    "result": "lota:jaboca_berry"
  },
  {
    "parentA": "lota:charti_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:cheri_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:cheri_berry",
    "parentB": "lota:persim_berry",
    "result": "lota:figy_berry"
  },
  {
    "parentA": "lota:chesto_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:chesto_berry",
    "parentB": "lota:persim_berry",
    "result": "lota:wiki_berry"
  },
  {
    "parentA": "lota:chilan_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:chilan_berry",
    "parentB": "lota:watmel_berry",
    "result": "lota:custap_berry"
  },
  {
    "parentA": "lota:chople_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:chople_berry",
    "parentB": "lota:spelon_berry",
    "result": "lota:lansat_berry"
  },
  {
    "parentA": "lota:coba_berry",
    "parentB": "lota:belue_berry",
    "result": "lota:rowap_berry"
  },
  {
    "parentA": "lota:coba_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:colbur_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:colbur_berry",
    "parentB": "lota:touga_berry",
    "result": "lota:spelon_berry"
  },
  {
    "parentA": "lota:cornn_berry",
    "parentB": "lota:passho_berry",
    "result": "lota:pamtre_berry"
  },
  {
    "parentA": "lota:cornn_berry",
    "parentB": "lota:rindo_berry",
    "result": "lota:kelpsy_berry"
  },
  {
    "parentA": "lota:durin_berry",
    "parentB": "lota:charti_berry",
    "result": "lota:jaboca_berry"
  },
  {
    "parentA": "lota:durin_berry",
    "parentB": "lota:hondew_berry",
    "result": "lota:petaya_berry"
  },
  {
    "parentA": "lota:enigma_berry",
    "parentB": "lota:kasib_berry",
    "result": "lota:kee_berry"
  },
  {
    "parentA": "lota:enigma_berry",
    "parentB": "lota:wacan_berry",
    "result": "lota:maranga_berry"
  },
  {
    "parentA": "lota:figy_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:figy_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:figy_berry",
    "parentB": "lota:razz_berry",
    "result": "lota:touga_berry"
  },
  {
    "parentA": "lota:grepa_berry",
    "parentB": "lota:belue_berry",
    "result": "lota:apicot_berry"
  },
  {
    "parentA": "lota:grepa_berry",
    "parentB": "lota:pomeg_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:haban_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:haban_berry",
    "parentB": "lota:sitrus_berry",
    "result": "lota:pomeg_berry"
  },
  {
    "parentA": "lota:hondew_berry",
    "parentB": "lota:durin_berry",
    "result": "lota:petaya_berry"
  },
  {
    "parentA": "lota:hondew_berry",
    "parentB": "lota:pomeg_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:babiri_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:charti_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:chilan_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:chople_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:coba_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:colbur_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:haban_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:kasib_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:kebia_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:occa_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:passho_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:payapa_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:rindo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:roseli_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:shuca_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:tanga_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:wacan_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:hopo_berry",
    "parentB": "lota:yache_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:iapapa_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:iapapa_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:iapapa_berry",
    "parentB": "lota:pinap_berry",
    "result": "lota:nomel_berry"
  },
  {
    "parentA": "lota:kasib_berry",
    "parentB": "lota:enigma_berry",
    "result": "lota:kee_berry"
  },
  {
    "parentA": "lota:kasib_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:kebia_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:kebia_berry",
    "parentB": "lota:pamtre_berry",
    "result": "lota:micle_berry"
  },
  {
    "parentA": "lota:kelpsy_berry",
    "parentB": "lota:pamtre_berry",
    "result": "lota:liechi_berry"
  },
  {
    "parentA": "lota:kelpsy_berry",
    "parentB": "lota:pomeg_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:aguav_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:figy_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:iapapa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:hopo_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:mago_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:leppa_berry",
    "parentB": "lota:wiki_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:aguav_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:figy_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:iapapa_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:hopo_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:mago_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:lum_berry",
    "parentB": "lota:wiki_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:mago_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:mago_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:mago_berry",
    "parentB": "lota:nanab_berry",
    "result": "lota:magost_berry"
  },
  {
    "parentA": "lota:magost_berry",
    "parentB": "lota:roseli_berry",
    "result": "lota:qualot_berry"
  },
  {
    "parentA": "lota:magost_berry",
    "parentB": "lota:tanga_berry",
    "result": "lota:watmel_berry"
  },
  {
    "parentA": "lota:nanab_berry",
    "parentB": "lota:mago_berry",
    "result": "lota:magost_berry"
  },
  {
    "parentA": "lota:nanab_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:nomel_berry",
    "parentB": "lota:payapa_berry",
    "result": "lota:belue_berry"
  },
  {
    "parentA": "lota:nomel_berry",
    "parentB": "lota:yache_berry",
    "result": "lota:grepa_berry"
  },
  {
    "parentA": "lota:occa_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:occa_berry",
    "parentB": "lota:touga_berry",
    "result": "lota:tamato_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:aspear_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:bluk_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:cheri_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:chesto_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:nanab_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:pecha_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:pinap_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:rawst_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:razz_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:oran_berry",
    "parentB": "lota:wepear_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:pamtre_berry",
    "parentB": "lota:kebia_berry",
    "result": "lota:micle_berry"
  },
  {
    "parentA": "lota:pamtre_berry",
    "parentB": "lota:kelpsy_berry",
    "result": "lota:liechi_berry"
  },
  {
    "parentA": "lota:passho_berry",
    "parentB": "lota:cornn_berry",
    "result": "lota:pamtre_berry"
  },
  {
    "parentA": "lota:passho_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:payapa_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:payapa_berry",
    "parentB": "lota:nomel_berry",
    "result": "lota:belue_berry"
  },
  {
    "parentA": "lota:pecha_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:pecha_berry",
    "parentB": "lota:persim_berry",
    "result": "lota:mago_berry"
  },
  {
    "parentA": "lota:persim_berry",
    "parentB": "lota:aspear_berry",
    "result": "lota:iapapa_berry"
  },
  {
    "parentA": "lota:persim_berry",
    "parentB": "lota:cheri_berry",
    "result": "lota:figy_berry"
  },
  {
    "parentA": "lota:persim_berry",
    "parentB": "lota:chesto_berry",
    "result": "lota:wiki_berry"
  },
  {
    "parentA": "lota:persim_berry",
    "parentB": "lota:pecha_berry",
    "result": "lota:mago_berry"
  },
  {
    "parentA": "lota:persim_berry",
    "parentB": "lota:rawst_berry",
    "result": "lota:aguav_berry"
  },
  {
    "parentA": "lota:pinap_berry",
    "parentB": "lota:iapapa_berry",
    "result": "lota:nomel_berry"
  },
  {
    "parentA": "lota:pinap_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:pomeg_berry",
    "parentB": "lota:grepa_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:pomeg_berry",
    "parentB": "lota:hondew_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:pomeg_berry",
    "parentB": "lota:kelpsy_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:pomeg_berry",
    "parentB": "lota:qualot_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:pomeg_berry",
    "parentB": "lota:tamato_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:qualot_berry",
    "parentB": "lota:pomeg_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:qualot_berry",
    "parentB": "lota:watmel_berry",
    "result": "lota:ganlon_berry"
  },
  {
    "parentA": "lota:rabuta_berry",
    "parentB": "lota:babiri_berry",
    "result": "lota:durin_berry"
  },
  {
    "parentA": "lota:rabuta_berry",
    "parentB": "lota:shuca_berry",
    "result": "lota:hondew_berry"
  },
  {
    "parentA": "lota:rawst_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:lum_berry"
  },
  {
    "parentA": "lota:rawst_berry",
    "parentB": "lota:persim_berry",
    "result": "lota:aguav_berry"
  },
  {
    "parentA": "lota:razz_berry",
    "parentB": "lota:figy_berry",
    "result": "lota:touga_berry"
  },
  {
    "parentA": "lota:razz_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:rindo_berry",
    "parentB": "lota:cornn_berry",
    "result": "lota:kelpsy_berry"
  },
  {
    "parentA": "lota:rindo_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:roseli_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:roseli_berry",
    "parentB": "lota:magost_berry",
    "result": "lota:qualot_berry"
  },
  {
    "parentA": "lota:shuca_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:shuca_berry",
    "parentB": "lota:rabuta_berry",
    "result": "lota:hondew_berry"
  },
  {
    "parentA": "lota:sitrus_berry",
    "parentB": "lota:haban_berry",
    "result": "lota:pomeg_berry"
  },
  {
    "parentA": "lota:spelon_berry",
    "parentB": "lota:chople_berry",
    "result": "lota:lansat_berry"
  },
  {
    "parentA": "lota:spelon_berry",
    "parentB": "lota:tamato_berry",
    "result": "lota:salac_berry"
  },
  {
    "parentA": "lota:tamato_berry",
    "parentB": "lota:pomeg_berry",
    "result": "lota:starf_berry"
  },
  {
    "parentA": "lota:tamato_berry",
    "parentB": "lota:spelon_berry",
    "result": "lota:salac_berry"
  },
  {
    "parentA": "lota:tanga_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:tanga_berry",
    "parentB": "lota:magost_berry",
    "result": "lota:watmel_berry"
  },
  {
    "parentA": "lota:touga_berry",
    "parentB": "lota:colbur_berry",
    "result": "lota:spelon_berry"
  },
  {
    "parentA": "lota:touga_berry",
    "parentB": "lota:occa_berry",
    "result": "lota:tamato_berry"
  },
  {
    "parentA": "lota:wacan_berry",
    "parentB": "lota:enigma_berry",
    "result": "lota:maranga_berry"
  },
  {
    "parentA": "lota:wacan_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:watmel_berry",
    "parentB": "lota:chilan_berry",
    "result": "lota:custap_berry"
  },
  {
    "parentA": "lota:watmel_berry",
    "parentB": "lota:qualot_berry",
    "result": "lota:ganlon_berry"
  },
  {
    "parentA": "lota:wepear_berry",
    "parentB": "lota:aguav_berry",
    "result": "lota:rabuta_berry"
  },
  {
    "parentA": "lota:wepear_berry",
    "parentB": "lota:oran_berry",
    "result": "lota:leppa_berry"
  },
  {
    "parentA": "lota:wiki_berry",
    "parentB": "lota:bluk_berry",
    "result": "lota:cornn_berry"
  },
  {
    "parentA": "lota:wiki_berry",
    "parentB": "lota:leppa_berry",
    "result": "lota:eggant_berry"
  },
  {
    "parentA": "lota:wiki_berry",
    "parentB": "lota:lum_berry",
    "result": "lota:sitrus_berry"
  },
  {
    "parentA": "lota:yache_berry",
    "parentB": "lota:hopo_berry",
    "result": "lota:enigma_berry"
  },
  {
    "parentA": "lota:yache_berry",
    "parentB": "lota:nomel_berry",
    "result": "lota:grepa_berry"
  }
]);

export const MINT_COLORS = Object.freeze([
  "red",
  "blue",
  "cyan",
  "pink",
  "green",
  "white"
]);

export const MINT_CROPS = Object.freeze({
  "red": {
    "color": "red",
    "blockId": "lota:red_mint",
    "seedId": "lota:red_mint_seeds",
    "leafId": "lota:red_mint_leaf"
  },
  "blue": {
    "color": "blue",
    "blockId": "lota:blue_mint",
    "seedId": "lota:blue_mint_seeds",
    "leafId": "lota:blue_mint_leaf"
  },
  "cyan": {
    "color": "cyan",
    "blockId": "lota:cyan_mint",
    "seedId": "lota:cyan_mint_seeds",
    "leafId": "lota:cyan_mint_leaf"
  },
  "pink": {
    "color": "pink",
    "blockId": "lota:pink_mint",
    "seedId": "lota:pink_mint_seeds",
    "leafId": "lota:pink_mint_leaf"
  },
  "green": {
    "color": "green",
    "blockId": "lota:green_mint",
    "seedId": "lota:green_mint_seeds",
    "leafId": "lota:green_mint_leaf"
  },
  "white": {
    "color": "white",
    "blockId": "lota:white_mint",
    "seedId": "lota:white_mint_seeds",
    "leafId": "lota:white_mint_leaf"
  }
});

export const NATURE_MINTS = Object.freeze({
  "adamant": {
    "id": "adamant_mint",
    "itemId": "lota:adamant_mint",
    "nature": "adamant",
    "recipe": {
      "lota:red_mint_leaf": 3,
      "lota:cyan_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "bold": {
    "id": "bold_mint",
    "itemId": "lota:bold_mint",
    "nature": "bold",
    "recipe": {
      "lota:blue_mint_leaf": 3,
      "lota:red_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "brave": {
    "id": "brave_mint",
    "itemId": "lota:brave_mint",
    "nature": "brave",
    "recipe": {
      "lota:red_mint_leaf": 3,
      "lota:green_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "calm": {
    "id": "calm_mint",
    "itemId": "lota:calm_mint",
    "nature": "calm",
    "recipe": {
      "lota:pink_mint_leaf": 3,
      "lota:red_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "careful": {
    "id": "careful_mint",
    "itemId": "lota:careful_mint",
    "nature": "careful",
    "recipe": {
      "lota:pink_mint_leaf": 3,
      "lota:cyan_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "gentle": {
    "id": "gentle_mint",
    "itemId": "lota:gentle_mint",
    "nature": "gentle",
    "recipe": {
      "lota:pink_mint_leaf": 3,
      "lota:blue_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "hasty": {
    "id": "hasty_mint",
    "itemId": "lota:hasty_mint",
    "nature": "hasty",
    "recipe": {
      "lota:green_mint_leaf": 3,
      "lota:blue_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "impish": {
    "id": "impish_mint",
    "itemId": "lota:impish_mint",
    "nature": "impish",
    "recipe": {
      "lota:blue_mint_leaf": 3,
      "lota:cyan_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "jolly": {
    "id": "jolly_mint",
    "itemId": "lota:jolly_mint",
    "nature": "jolly",
    "recipe": {
      "lota:green_mint_leaf": 3,
      "lota:cyan_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "lax": {
    "id": "lax_mint",
    "itemId": "lota:lax_mint",
    "nature": "lax",
    "recipe": {
      "lota:blue_mint_leaf": 3,
      "lota:pink_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "lonely": {
    "id": "lonely_mint",
    "itemId": "lota:lonely_mint",
    "nature": "lonely",
    "recipe": {
      "lota:red_mint_leaf": 3,
      "lota:blue_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "mild": {
    "id": "mild_mint",
    "itemId": "lota:mild_mint",
    "nature": "mild",
    "recipe": {
      "lota:cyan_mint_leaf": 3,
      "lota:blue_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "modest": {
    "id": "modest_mint",
    "itemId": "lota:modest_mint",
    "nature": "modest",
    "recipe": {
      "lota:cyan_mint_leaf": 3,
      "lota:red_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "naive": {
    "id": "naive_mint",
    "itemId": "lota:naive_mint",
    "nature": "naive",
    "recipe": {
      "lota:green_mint_leaf": 3,
      "lota:pink_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "naughty": {
    "id": "naughty_mint",
    "itemId": "lota:naughty_mint",
    "nature": "naughty",
    "recipe": {
      "lota:red_mint_leaf": 3,
      "lota:pink_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "quiet": {
    "id": "quiet_mint",
    "itemId": "lota:quiet_mint",
    "nature": "quiet",
    "recipe": {
      "lota:cyan_mint_leaf": 3,
      "lota:green_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "rash": {
    "id": "rash_mint",
    "itemId": "lota:rash_mint",
    "nature": "rash",
    "recipe": {
      "lota:cyan_mint_leaf": 3,
      "lota:pink_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "relaxed": {
    "id": "relaxed_mint",
    "itemId": "lota:relaxed_mint",
    "nature": "relaxed",
    "recipe": {
      "lota:blue_mint_leaf": 3,
      "lota:green_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "sassy": {
    "id": "sassy_mint",
    "itemId": "lota:sassy_mint",
    "nature": "sassy",
    "recipe": {
      "lota:pink_mint_leaf": 3,
      "lota:green_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  },
  "serious": {
    "id": "serious_mint",
    "itemId": "lota:serious_mint",
    "nature": "serious",
    "recipe": {
      "lota:white_mint_leaf": 4
    },
    "pattern": [
      "##",
      "##"
    ]
  },
  "timid": {
    "id": "timid_mint",
    "itemId": "lota:timid_mint",
    "nature": "timid",
    "recipe": {
      "lota:green_mint_leaf": 3,
      "lota:red_mint_leaf": 1
    },
    "pattern": [
      "##",
      "#W"
    ]
  }
});

export const MULCH_DATA = Object.freeze({
  "none": {
    "id": "none",
    "itemId": "",
    "duration": 0,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "coarse": {
    "id": "coarse",
    "itemId": "lota:coarse_mulch",
    "duration": -1,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "growth": {
    "id": "growth",
    "itemId": "lota:growth_mulch",
    "duration": 5,
    "growthTimeMultiplier": 0.5,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "humid": {
    "id": "humid",
    "itemId": "lota:humid_mulch",
    "duration": -1,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "loamy": {
    "id": "loamy",
    "itemId": "lota:loamy_mulch",
    "duration": -1,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "peat": {
    "id": "peat",
    "itemId": "lota:peat_mulch",
    "duration": -1,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "rich": {
    "id": "rich",
    "itemId": "lota:rich_mulch",
    "duration": 5,
    "growthTimeMultiplier": 1,
    "yieldBonus": [
      1,
      2
    ],
    "mutationChanceMultiplier": 1
  },
  "sandy": {
    "id": "sandy",
    "itemId": "lota:sandy_mulch",
    "duration": -1,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 1
  },
  "surprise": {
    "id": "surprise",
    "itemId": "lota:surprise_mulch",
    "duration": 3,
    "growthTimeMultiplier": 1,
    "yieldBonus": 0,
    "mutationChanceMultiplier": 4
  }
});

export const MULCH_ITEM_IDS = Object.freeze([
  "lota:mulch_base",
  "lota:coarse_mulch",
  "lota:growth_mulch",
  "lota:humid_mulch",
  "lota:loamy_mulch",
  "lota:peat_mulch",
  "lota:rich_mulch",
  "lota:sandy_mulch",
  "lota:surprise_mulch"
]);

export const TYPE_RESIST_BERRIES = Object.freeze({
  "occa_berry": "fire",
  "passho_berry": "water",
  "wacan_berry": "electric",
  "rindo_berry": "grass",
  "yache_berry": "ice",
  "chople_berry": "fighting",
  "kebia_berry": "poison",
  "shuca_berry": "ground",
  "coba_berry": "flying",
  "payapa_berry": "psychic",
  "tanga_berry": "bug",
  "charti_berry": "rock",
  "kasib_berry": "ghost",
  "haban_berry": "dragon",
  "colbur_berry": "dark",
  "babiri_berry": "steel",
  "chilan_berry": "normal",
  "roseli_berry": "fairy"
});

export const BERRY_BIOME_IDS = Object.freeze({
  "cobblemon:is_arid": [
    "desert",
    "badlands",
    "eroded_badlands",
    "wooded_badlands",
    "savanna",
    "savanna_plateau",
    "windswept_savanna"
  ],
  "cobblemon:is_badlands": [
    "badlands",
    "eroded_badlands",
    "wooded_badlands"
  ],
  "cobblemon:is_bamboo": [
    "bamboo_jungle"
  ],
  "cobblemon:is_coast": [
    "beach",
    "snowy_beach",
    "stony_shore"
  ],
  "cobblemon:is_desert": [
    "desert"
  ],
  "cobblemon:is_dripstone": [
    "dripstone_caves"
  ],
  "cobblemon:is_floral": [
    "flower_forest",
    "meadow",
    "sunflower_plains",
    "cherry_grove"
  ],
  "cobblemon:is_forest": [
    "forest",
    "flower_forest",
    "birch_forest",
    "old_growth_birch_forest",
    "dark_forest"
  ],
  "cobblemon:is_freezing": [
    "snowy_plains",
    "ice_spikes",
    "snowy_taiga",
    "snowy_slopes",
    "frozen_peaks",
    "jagged_peaks",
    "frozen_river",
    "frozen_ocean",
    "deep_frozen_ocean"
  ],
  "cobblemon:is_freshwater": [
    "river",
    "frozen_river"
  ],
  "cobblemon:is_grassland": [
    "plains",
    "sunflower_plains",
    "meadow",
    "savanna",
    "savanna_plateau",
    "windswept_savanna"
  ],
  "cobblemon:is_hills": [
    "windswept_hills",
    "windswept_gravelly_hills",
    "windswept_forest",
    "savanna_plateau"
  ],
  "cobblemon:is_island": [
    "mushroom_fields",
    "beach",
    "stony_shore"
  ],
  "cobblemon:is_jungle": [
    "jungle",
    "sparse_jungle",
    "bamboo_jungle"
  ],
  "cobblemon:is_lush": [
    "lush_caves",
    "jungle",
    "bamboo_jungle",
    "mangrove_swamp"
  ],
  "cobblemon:is_magical": [
    "cherry_grove",
    "flower_forest",
    "mushroom_fields"
  ],
  "cobblemon:is_mountain": [
    "jagged_peaks",
    "frozen_peaks",
    "stony_peaks",
    "meadow",
    "cherry_grove",
    "grove",
    "windswept_hills",
    "windswept_gravelly_hills",
    "windswept_forest"
  ],
  "cobblemon:is_mushroom": [
    "mushroom_fields"
  ],
  "cobblemon:is_ocean": [
    "ocean",
    "deep_ocean",
    "cold_ocean",
    "deep_cold_ocean",
    "lukewarm_ocean",
    "deep_lukewarm_ocean",
    "warm_ocean",
    "frozen_ocean",
    "deep_frozen_ocean"
  ],
  "cobblemon:is_peak": [
    "jagged_peaks",
    "frozen_peaks",
    "stony_peaks"
  ],
  "cobblemon:is_plains": [
    "plains",
    "sunflower_plains",
    "meadow"
  ],
  "cobblemon:is_sandy": [
    "desert",
    "beach",
    "snowy_beach",
    "badlands",
    "eroded_badlands",
    "wooded_badlands"
  ],
  "cobblemon:is_savanna": [
    "savanna",
    "savanna_plateau",
    "windswept_savanna"
  ],
  "cobblemon:is_sky": [
    "jagged_peaks",
    "frozen_peaks",
    "stony_peaks",
    "meadow",
    "grove",
    "windswept_hills"
  ],
  "cobblemon:is_spooky": [
    "dark_forest",
    "deep_dark",
    "swamp"
  ],
  "cobblemon:is_swamp": [
    "swamp",
    "mangrove_swamp"
  ],
  "cobblemon:is_taiga": [
    "taiga",
    "snowy_taiga",
    "old_growth_pine_taiga",
    "old_growth_spruce_taiga",
    "grove"
  ],
  "cobblemon:is_temperate": [
    "plains",
    "sunflower_plains",
    "meadow",
    "forest",
    "flower_forest",
    "birch_forest",
    "dark_forest"
  ],
  "cobblemon:is_thermal": [
    "desert",
    "badlands",
    "eroded_badlands",
    "wooded_badlands",
    "savanna",
    "basalt_deltas"
  ],
  "cobblemon:is_volcanic": [
    "badlands",
    "eroded_badlands",
    "stony_peaks",
    "basalt_deltas"
  ]
});

export function getBerryData(id) {
    if (!id) return undefined;
    const clean = String(id).replace(/^lota:/, '').replace(/^cobblemon:/, '').toLowerCase();
    const normalized = clean.endsWith('_berry') ? clean : clean + '_berry';
    return BERRY_DATA[normalized];
}

export function getBerryByBlock(blockId) {
    const itemId = BERRY_BLOCK_TO_ITEM[blockId];
    return itemId ? getBerryData(itemId) : undefined;
}

export function getMintCrop(colorOrId) {
    const clean = String(colorOrId).replace(/^lota:/, '').replace(/_mint$/, '').toLowerCase();
    return MINT_CROPS[clean];
}

export function getNatureMint(natureOrId) {
    const clean = String(natureOrId).replace(/^lota:/, '').replace(/_mint$/, '').toLowerCase();
    return NATURE_MINTS[clean];
}
