import { EquipmentSlot } from "@minecraft/server";
import { SPECIES_DATA } from "./species_registry.js";
import { pokemonModelVariant } from "./pokemon_visual_state.js";

export const MEGA_BRACELET_ITEM = "lota:mega_bracelet";
export const MEGA_BRACELET_ITEMS = new Set([
    "lota:mega_bracelet",
    "lota:mega_bracelet_rosa",
    "lota:mega_bracelet_roxo",
    "lota:mega_bracelet_laranja",
    "lota:mega_bracelet_azul",
    "lota:mega_bracelet_verde",
    "lota:mega_bracelet_vermelho",
    "lota:mega_bracelet_amarelo",
    "lota:mega_bracelet_ciano"
]);
export const MEGA_ACCESSORY_SLOT_PROPERTY = "lota:accessory_offhand_backup_v1";

const MEGA_FORMS_BY_BASE = new Map();
for (const [runtimeSpecies, record] of Object.entries(SPECIES_DATA)) {
    const baseSpecies = String(record?.baseSpecies || "");
    if (!baseSpecies || !record?.megaAspect) continue;
    const forms = MEGA_FORMS_BY_BASE.get(baseSpecies) || [];
    forms.push(Object.freeze({ runtimeSpecies, ...record }));
    MEGA_FORMS_BY_BASE.set(baseSpecies, forms);
}

function cleanId(value) {
    return String(value || "").replace(/^.*:/, "").toLowerCase();
}

function normalizedItem(value) {
    const id = cleanId(value);
    return id ? `lota:${id}` : "";
}

function heldMegaForm(pokemon) {
    if (!pokemon) return undefined;
    const species = cleanId(pokemon.species);
    const forms = MEGA_FORMS_BY_BASE.get(species) || [];
    const heldItem = normalizedItem(pokemon.heldItem);
    return forms.find(form => heldItem === normalizedItem(form.megaStone));
}

function normalizedMoveId(move) {
    return cleanId(typeof move === "string" ? move : move?.id);
}

function rayquazaMegaForm(pokemon) {
    if (cleanId(pokemon?.species) !== "rayquaza") return undefined;
    if (!(pokemon?.moves || []).some(move => normalizedMoveId(move) === "dragonascent")) return undefined;
    const variant = pokemonModelVariant({
        ...pokemon,
        aspects: [...(pokemon?.aspects || []), "mega"]
    });
    if (!variant) return undefined;
    return Object.freeze({
        runtimeSpecies: "rayquaza",
        baseSpecies: "rayquaza",
        megaAspect: "mega",
        ...variant.data
    });
}

function unavailableMegaMessage(pokemon) {
    if (cleanId(pokemon?.species) === "rayquaza") {
        return "Rayquaza must know Dragon Ascent to Mega Evolve.";
    }
    return "This Pokemon is not holding its matching Mega Stone.";
}

export function isOutsideMegaEvolved(pokemon) {
    return !!cleanId(pokemon?.megaState?.runtimeSpecies);
}

export function activeMegaSpecies(pokemon) {
    return cleanId(pokemon?.battleState?.megaSpecies || pokemon?.megaState?.runtimeSpecies);
}

export function megaFormForPokemon(pokemon) {
    if (!pokemon || activeMegaSpecies(pokemon)) return undefined;
    return rayquazaMegaForm(pokemon) || heldMegaForm(pokemon);
}

export function equippedMegaAccessory(player) {
    try {
        const equippable = player?.getComponent("minecraft:equippable");
        const typeId = equippable?.getEquipment(EquipmentSlot.Offhand)?.typeId;
        return typeId && MEGA_BRACELET_ITEMS.has(typeId) ? typeId : "";
    } catch (error) {}
    return "";
}

export function playerHasMegaBracelet(player) {
    return !!equippedMegaAccessory(player);
}

export function megaEvolutionFailure(player, pokemon, party = []) {
    if (!pokemon) return "There is no active Pokemon.";
    if (activeMegaSpecies(pokemon)) return "This Pokemon has already Mega Evolved.";
    if (!playerHasMegaBracelet(player)) return "Equip a Mega Bracelet in the Mega accessory slot first.";
    if (!megaFormForPokemon(pokemon)) return unavailableMegaMessage(pokemon);
    if ((party || []).some(member => member?.uuid !== pokemon?.uuid && isOutsideMegaEvolved(member))) {
        return "Another Pokemon is already Mega Evolved.";
    }
    return "";
}

export function applyMegaEvolution(player, pokemon) {
    const failure = megaEvolutionFailure(player, pokemon);
    if (failure) return { success: false, message: failure };
    const form = megaFormForPokemon(pokemon);
    if (!pokemon.battleState || typeof pokemon.battleState !== "object") pokemon.battleState = { stages: {} };
    pokemon.battleState.baseAbility = pokemon.ability;
    pokemon.battleState.megaSpecies = form.runtimeSpecies;
    pokemon.battleState.megaAspect = form.megaAspect;
    pokemon.ability = String(form.abilities?.[0] || pokemon.ability || "none").replace(/^h:/, "");
    return { success: true, form };
}

export function battleEntityType(pokemon) {
    const megaSpecies = activeMegaSpecies(pokemon);
    return megaSpecies ? `lota:${megaSpecies}` : pokemon?.species;
}

export function outsideMegaEvolutionFailure(player, pokemon, party = []) {
    if (!pokemon) return "There is no active Pokemon.";
    if (pokemon?.battleState?.megaSpecies) return "This Pokemon cannot change form during battle.";
    if (isOutsideMegaEvolved(pokemon)) return "";
    if (!playerHasMegaBracelet(player)) return "Equip a Mega Bracelet in the Mega accessory slot first.";
    if (!megaFormForPokemon(pokemon)) return unavailableMegaMessage(pokemon);
    if ((party || []).some(member => member?.uuid !== pokemon?.uuid && isOutsideMegaEvolved(member))) {
        return "Another Pokemon is already Mega Evolved.";
    }
    return "";
}

export function revertOutsideMegaEvolution(pokemon) {
    const state = pokemon?.megaState;
    if (!state?.runtimeSpecies) return false;
    if (state.baseAbility !== undefined) pokemon.ability = state.baseAbility;
    delete pokemon.megaState;
    return true;
}

export function toggleOutsideMegaEvolution(player, pokemon, party = []) {
    const failure = outsideMegaEvolutionFailure(player, pokemon, party);
    if (failure) return { success: false, message: failure };
    if (isOutsideMegaEvolved(pokemon)) {
        const form = SPECIES_DATA[cleanId(pokemon.megaState.runtimeSpecies)];
        revertOutsideMegaEvolution(pokemon);
        return { success: true, mode: "revert", form };
    }
    const form = megaFormForPokemon(pokemon);
    pokemon.megaState = {
        runtimeSpecies: form.runtimeSpecies,
        megaAspect: form.megaAspect,
        baseAbility: pokemon.ability
    };
    pokemon.ability = String(form.abilities?.[0] || pokemon.ability || "none").replace(/^h:/, "");
    return { success: true, mode: "evolve", form };
}

export function restoreMegaAbility(pokemon) {
    const state = pokemon?.battleState;
    if (!state?.megaSpecies) return;
    if (state.baseAbility !== undefined) pokemon.ability = state.baseAbility;
}

export function revertMegaEvolution(pokemon) {
    const state = pokemon?.battleState;
    if (!state?.megaSpecies) return false;
    restoreMegaAbility(pokemon);
    delete state.megaSpecies;
    delete state.megaAspect;
    delete state.baseAbility;
    return true;
}
