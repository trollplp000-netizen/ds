import { EquipmentSlot, ItemStack, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    equippedMegaAccessory,
    MEGA_ACCESSORY_SLOT_PROPERTY,
    MEGA_BRACELET_ITEMS
} from "./mega_evolution.js";

const ACCESSORY_FORM_TITLE = "cobbledrock.accessories";
const ACCESSORY_FORM_BUSY_RETRIES = 2;
const openForms = new Set();

function playerInventory(player) {
    try { return player?.getComponent("minecraft:inventory")?.container; }
    catch (error) { return undefined; }
}

function playerEquippable(player) {
    try { return player?.getComponent("minecraft:equippable"); }
    catch (error) { return undefined; }
}

function inBattle(player) {
    try { return player?.hasTag("lota:battle_player") || player?.hasTag("lota:in_battle"); }
    catch (error) { return false; }
}

function sendTranslated(player, key) {
    try { player.sendMessage({ rawtext: [{ translate: key }] }); }
    catch (error) { player.sendMessage(key); }
}

function storedItemData(stack) {
    const data = { typeId: String(stack?.typeId || ""), amount: 1 };
    try { if (stack.nameTag) data.nameTag = stack.nameTag; } catch (error) {}
    try {
        const lore = stack.getLore();
        if (lore.length) data.lore = lore;
    } catch (error) {}
    try {
        const dynamicProperties = {};
        for (const id of stack.getDynamicPropertyIds()) dynamicProperties[id] = stack.getDynamicProperty(id);
        if (Object.keys(dynamicProperties).length) data.dynamicProperties = dynamicProperties;
    } catch (error) {}
    return data;
}

function restoredItemStack(data) {
    const item = new ItemStack(data.typeId, 1);
    try { if (data.nameTag) item.nameTag = String(data.nameTag); } catch (error) {}
    try { if (Array.isArray(data.lore)) item.setLore(data.lore.map(String)); } catch (error) {}
    try {
        for (const [id, value] of Object.entries(data.dynamicProperties || {})) {
            item.setDynamicProperty(id, value);
        }
    } catch (error) {}
    return item;
}

function braceletInventorySlot(player, container) {
    const selected = Math.max(0, Math.floor(Number(player?.selectedSlotIndex) || 0));
    if (selected < container.size && MEGA_BRACELET_ITEMS.has(container.getItem(selected)?.typeId)) return selected;
    for (let slot = 0; slot < container.size; slot++) {
        if (MEGA_BRACELET_ITEMS.has(container.getItem(slot)?.typeId)) return slot;
    }
    return -1;
}

export function equipMegaBracelet(player) {
    if (inBattle(player)) {
        sendTranslated(player, "message.cobbledrock.accessory.battle_locked");
        return false;
    }

    const equippable = playerEquippable(player);
    if (!equippable) return false;

    const currentOffhand = equippable.getEquipment(EquipmentSlot.Offhand);
    if (currentOffhand && MEGA_BRACELET_ITEMS.has(currentOffhand.typeId)) {
        sendTranslated(player, "message.cobbledrock.accessory.slot_occupied");
        return false;
    }

    const container = playerInventory(player);
    if (!container) return false;
    const slot = braceletInventorySlot(player, container);
    if (slot < 0) {
        sendTranslated(player, "message.cobbledrock.accessory.no_bracelet");
        return false;
    }

    const bracelet = container.getItem(slot);
    if (!bracelet || !MEGA_BRACELET_ITEMS.has(bracelet.typeId)) return false;

    try {
        if (currentOffhand) {
            player.setDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY, JSON.stringify(storedItemData(currentOffhand)));
        } else {
            player.setDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY, undefined);
        }
        container.setItem(slot, undefined);
        equippable.setEquipment(EquipmentSlot.Offhand, bracelet);
    } catch (error) {
        try { container.setItem(slot, bracelet); } catch (restoreError) {}
        try { player.setDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY, undefined); } catch (restoreError) {}
        console.warn(`[Accessories] Could not equip Mega Bracelet for ${player?.name || "unknown"}: ${error}`);
        return false;
    }

    try { player.playSound("random.pop", { volume: 0.7, pitch: 1.35 }); } catch (error) {}
    sendTranslated(player, "message.cobbledrock.accessory.equipped");
    return true;
}

export function unequipMegaBracelet(player) {
    if (inBattle(player)) {
        sendTranslated(player, "message.cobbledrock.accessory.battle_locked");
        return false;
    }

    const equippable = playerEquippable(player);
    if (!equippable) return false;

    const worn = equippable.getEquipment(EquipmentSlot.Offhand);
    if (!worn || !MEGA_BRACELET_ITEMS.has(worn.typeId)) return false;

    const container = playerInventory(player);
    if (!container) return false;

    let raw;
    try { raw = player.getDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY); }
    catch (error) { raw = undefined; }
    let restore;
    try { restore = raw ? restoredItemStack(JSON.parse(raw)) : undefined; }
    catch (error) { restore = undefined; }

    try {
        const leftover = container.addItem(worn);
        if (leftover) {
            sendTranslated(player, "message.cobbledrock.accessory.inventory_full");
            return false;
        }
        equippable.setEquipment(EquipmentSlot.Offhand, restore);
        player.setDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY, undefined);
    } catch (error) {
        console.warn(`[Accessories] Could not unequip Mega Bracelet for ${player?.name || "unknown"}: ${error}`);
        return false;
    }

    try { player.playSound("random.pop", { volume: 0.7, pitch: 0.9 }); } catch (error) {}
    sendTranslated(player, "message.cobbledrock.accessory.unequipped");
    return true;
}

function reopenAccessoryMenu(player, options, busyRetries = 0) {
    system.run(() => showAccessoryMenu(player, { ...options, busyRetries }));
}

export function showAccessoryMenu(player, options = {}) {
    if (!player || openForms.has(player.id)) return;
    if (inBattle(player)) {
        sendTranslated(player, "message.cobbledrock.accessory.battle_locked");
        return;
    }

    const equipped = !!equippedMegaAccessory(player);
    const form = new ActionFormData()
        .title(ACCESSORY_FORM_TITLE)
        .body("Equip a Mega Bracelet here to enable Mega Evolution in battle.")
        .button(equipped
            ? "Mega Slot: Mega Bracelet (Equipped)\n|ACCESSORY:SLOT||ACCESSORY:EQUIPPED|"
            : "Mega Slot: Empty\n|ACCESSORY:SLOT||ACCESSORY:EMPTY|")
        .button("Back\n|ACCESSORY:BACK|");

    openForms.add(player.id);
    form.show(player).then(response => {
        openForms.delete(player.id);
        if (response.canceled) {
            const reason = String(response.cancelationReason || "").toLowerCase();
            const retries = Math.max(0, Math.floor(Number(options.busyRetries) || 0));
            if (reason.includes("busy") && retries < ACCESSORY_FORM_BUSY_RETRIES) {
                return reopenAccessoryMenu(player, options, retries + 1);
            }
            if (typeof options.onBack === "function") options.onBack();
            return;
        }
        if (Math.floor(Number(response.selection)) === 0) {
            if (equipped) unequipMegaBracelet(player);
            else equipMegaBracelet(player);
            return reopenAccessoryMenu(player, options);
        }
        if (typeof options.onBack === "function") options.onBack();
    }).catch(error => {
        openForms.delete(player.id);
        console.warn(`[Accessories] Mega slot form failed: ${error}`);
        if (typeof options.onBack === "function") options.onBack();
    });
}

world.afterEvents.itemUse.subscribe(event => {
    if (!MEGA_BRACELET_ITEMS.has(event.itemStack?.typeId)) return;
    system.run(() => showAccessoryMenu(event.source));
});

world.afterEvents.entityDie.subscribe(event => {
    const player = event.deadEntity;
    if (player?.typeId !== "minecraft:player") return;
    try { if (world.gameRules.keepInventory) return; }
    catch (error) { return; }

    let raw;
    try { raw = player.getDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY); }
    catch (error) { return; }
    if (!raw) return;
    try {
        const item = restoredItemStack(JSON.parse(raw));
        player.setDynamicProperty(MEGA_ACCESSORY_SLOT_PROPERTY, undefined);
        player.dimension.spawnItem(item, player.location);
    } catch (error) {
        console.warn(`[Accessories] Could not restore off-hand backup on death for ${player?.name || "unknown"}: ${error}`);
    }
});

world.afterEvents.playerLeave.subscribe(event => openForms.delete(event.playerId));
