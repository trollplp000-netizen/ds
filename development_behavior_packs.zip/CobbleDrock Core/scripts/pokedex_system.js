import { EquipmentSlot, system, world } from "@minecraft/server";
import { chestScreenActive, closeChestScreen, openChestScreen, registerChestScreen } from "./chest_ui.js";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import {
    capturedSpecies,
    captureSpeciesKey,
    encounteredSpecies,
    markSpeciesCaptured
} from "./capture_rate.js";
import { identify } from "./identification.js";
import { speciesData } from "./battle_math.js";
import { SPECIES_DATA } from "./species_registry.js";
import { claimPokedexUse, releasePokedexUse } from "./pokedex_input.js";
import { clearHudTitleTransient, setHudTitleTransient } from "./hud_title_bridge.js";
import {
    loadPartyFromPlayer,
    loadPCFromPlayer,
    loadPokemonFromEntity,
    PC_BOX_COUNT,
    subscribePokemonStorageSaved
} from "./storage.js";

export const POKEDEX_COLORS = Object.freeze([
    "red",
    "yellow",
    "green",
    "blue",
    "pink",
    "black",
    "white"
]);

export const POKEDEX_ITEM_IDS = Object.freeze(
    POKEDEX_COLORS.map(color => `lota:pokedex_${color}`)
);

export const POKEDEX_SCAN_RANGE = 12;
export const POKEDEX_SCAN_OPEN_TICKS = 3;
export const POKEDEX_SCAN_TICKS = 20;
export const POKEDEX_SCAN_RESULT_TICKS = 12;
export const POKEDEX_PAGE_SIZE = 25;

const POKEDEX_ITEM_SET = new Set(POKEDEX_ITEM_IDS);

export const POKEDEX_DEX_LIST = Object.freeze([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,
    22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,
    52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,
    82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,
    109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,
    132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,
    155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,
    178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,
    201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,
    224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,
    247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,
    270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,
    293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,
    316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,
    339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,
    362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,
    385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,
    408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,
    431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,
    454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,
    477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,
    500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,
    523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,
    546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,
    569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,
    592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,
    615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,633,634,635,636,637,
    638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,
    661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,
    684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,
    707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,
    730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,
    753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,
    776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,
    799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,
    822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,
    845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,
    868,869,870,871,872,873,874,875,876,877,878,879,880,881,882,883,884,885,886,887,888,889,890,
    891,892,893,894,895,896,897,898,899,900,901,902,903,904,905,906,907,908,909,910,911,912,913,
    914,915,916,917,918,919,920,921,922,923,924,925,926,927,928,929,930,931,932,933,934,935,936,
    937,938,939,940,941,942,943,944,945,946,947,948,949,950,951,952,953,954,955,956,957,958,959,
    960,961,962,963,964,965,966,967,968,969,970,971,972,973,974,975,976,977,978,979,980,981,982,
    983,984,985,986,987,988,989,990,991,992,993,994,995,996,997,998,999,1000,1001,1002,1003,
    1004,1005,1006,1007,1008,1009,1010,1011,1012,1013,1014,1015,1016,1017,1018,1019,1020,1021,
    1022,1023,1024,1025,1026,1027,1028,1029,1030,1031,1032,1033,1034,1044,1045,1064,1065,1066,
    1067]);

const POKEDEX_PAN_VARIANT = Object.freeze({1:3,2:4,3:25,4:15,5:15,6:25,7:15,8:22,9:25,10:3,11:8,
    12:8,13:3,14:8,15:8,16:15,17:15,18:15,19:3,20:8,23:8,24:8,25:8,26:8,27:15,28:15,29:8,30:15,
    32:8,33:15,34:15,35:8,36:8,37:15,41:15,42:8,43:8,44:8,45:8,46:3,47:3,48:8,49:8,50:15,51:15,
    54:4,55:11,56:3,57:3,59:22,61:15,62:15,63:15,64:25,65:25,66:15,67:3,68:3,69:8,70:8,71:15,
    72:11,73:11,74:11,75:18,76:15,77:15,78:15,79:18,80:11,81:25,82:25,83:15,84:25,85:25,88:18,
    90:8,91:25,92:15,95:16,96:25,97:25,98:15,99:8,100:15,101:15,102:15,103:15,106:15,107:15,
    108:8,109:18,110:25,111:15,112:25,113:8,115:15,116:8,117:8,118:15,119:24,120:8,121:8,123:15,
    125:15,127:25,128:25,129:25,130:25,131:25,132:18,137:15,138:15,139:15,140:15,141:15,142:22,
    143:15,147:15,148:15,149:25,150:25,151:25,152:11,153:15,154:18,155:11,156:25,157:11,158:15,
    159:15,160:15,163:8,164:25,165:8,166:3,167:11,168:18,169:25,170:8,171:15,172:8,173:8,176:25,
    179:8,180:8,181:15,182:3,187:15,188:15,189:8,190:8,191:25,192:8,194:6,198:3,199:11,200:25,
    201:15,202:25,203:15,206:15,208:25,209:15,210:15,212:15,213:8,214:8,215:11,216:8,217:25,
    218:22,219:22,220:15,221:8,222:15,226:8,227:15,231:15,232:25,233:15,234:15,236:15,237:15,
    239:15,240:8,241:22,242:15,245:25,248:25,251:15,255:15,257:25,262:8,263:15,264:8,267:1,
    269:1,271:8,272:4,276:15,277:15,278:4,279:8,280:15,281:15,282:25,283:8,284:8,285:8,286:25,
    289:15,299:12,300:12,302:25,304:15,311:15,312:15,313:8,314:8,315:15,316:15,317:15,318:25,
    320:25,321:25,322:15,324:15,325:25,327:8,330:15,331:8,332:15,333:25,334:25,337:22,338:22,
    339:3,341:15,342:11,343:15,344:15,345:22,346:22,347:8,348:18,349:8,350:15,351:9,352:25,
    353:8,354:11,355:15,356:15,357:18,358:25,363:3,366:15,369:25,370:15,371:25,372:8,373:15,
    374:25,375:25,376:25,382:17,383:12,385:25,386:15,387:15,388:15,389:15,390:8,391:6,392:8,
    393:4,394:4,395:11,398:25,399:8,401:15,402:15,406:8,407:25,408:15,409:15,410:25,411:25,
    412:5,413:7,415:15,416:15,418:15,420:15,421:25,422:11,424:25,427:15,428:15,430:25,433:15,
    436:25,437:25,438:25,439:8,440:15,442:11,443:8,444:8,445:15,446:15,447:15,448:15,449:25,
    450:25,453:15,454:8,455:15,456:15,457:15,458:8,459:8,460:15,461:11,462:25,463:15,464:25,
    468:25,473:15,474:8,476:15,477:15,480:3,481:3,482:3,483:15,484:15,485:15,487:15,489:8,490:3,
    491:15,492:11,493:25,494:15,495:15,497:15,498:8,499:15,500:25,501:15,502:8,504:15,505:15,
    509:15,510:25,519:11,520:8,521:11,522:25,523:11,524:15,525:15,526:15,529:15,530:15,532:15,
    533:15,534:15,535:25,536:15,537:25,540:15,541:15,542:15,543:8,544:8,545:8,546:15,547:15,
    548:15,551:15,552:25,553:25,554:11,555:15,557:15,558:19,561:3,564:22,565:25,566:15,567:15,
    577:25,578:25,579:25,582:8,583:11,584:15,592:15,594:25,595:11,596:18,597:8,598:8,599:15,
    600:25,601:15,604:15,605:18,606:25,607:15,608:15,609:8,610:15,612:15,613:4,615:15,618:15,
    622:25,626:15,627:8,628:15,629:12,630:24,631:15,633:15,634:25,635:10,636:8,637:25,638:15,
    639:25,640:15,641:25,642:11,643:15,644:20,645:25,646:15,647:15,648:20,649:8,650:11,651:15,
    653:14,655:22,656:8,657:15,658:15,659:15,660:15,661:3,662:8,663:15,664:8,665:15,666:15,
    669:18,670:25,671:25,672:8,673:15,679:15,680:15,681:15,682:15,683:15,690:15,696:25,697:25,
    698:15,699:22,702:6,703:21,704:15,705:15,706:15,708:15,709:15,710:15,711:8,712:8,716:15,
    717:12,718:8,719:8,720:25,721:15,725:25,726:15,727:25,728:15,729:15,730:15,734:25,735:15,
    736:8,737:3,738:15,741:4,749:15,750:25,753:25,754:25,759:8,760:25,764:18,766:15,767:6,
    768:15,770:11,772:8,773:8,774:15,775:15,778:15,780:25,781:15,785:8,786:25,787:25,788:25,
    789:15,790:15,791:15,793:15,794:8,795:15,796:15,797:20,798:25,799:23,801:3,802:25,805:15,
    806:25,807:15,808:25,809:15,810:8,811:8,812:8,813:3,814:25,816:8,817:15,818:8,819:25,820:18,
    821:3,822:8,823:25,824:15,825:15,826:15,827:8,828:25,829:25,830:25,831:11,832:15,840:11,
    846:15,847:25,850:25,851:25,854:8,855:11,862:25,864:25,868:25,869:15,870:8,873:8,874:15,
    878:25,879:25,880:25,881:15,882:25,883:22,885:15,886:15,887:25,888:25,889:8,890:20,892:8,
    894:5,896:5,897:25,898:15,899:15,900:8,901:24,903:11,905:25,906:8,907:15,908:15,909:15,
    910:15,911:25,912:6,914:8,915:11,916:15,921:8,922:13,923:5,924:2,925:2,926:8,927:8,932:11,
    933:15,934:25,938:8,939:8,940:8,941:15,944:15,945:25,946:22,947:22,948:8,949:11,951:15,
    952:15,953:8,954:25,955:25,965:11,966:11,967:25,971:8,972:15,973:25,974:15,975:15,977:25,
    979:20,981:15,982:15,984:25,985:11,986:15,987:25,988:25,989:25,990:15,993:15,994:15,995:15,
    996:15,997:15,998:15,999:8,1000:15,1001:25,1002:8,1003:15,1004:15,1005:8,1007:8,1008:22,
    1009:15,1012:8,1013:11,1014:25,1015:15,1016:22,1017:15,1020:25,1021:15,1022:15,1023:15,
    1024:8,1025:25,1031:8,1032:8,1033:15});

const POKEDEX_PAGE_COUNT = Math.max(1, Math.ceil(POKEDEX_DEX_LIST.length / POKEDEX_PAGE_SIZE));
const POKEDEX_THUMB_VARIANTS = 44;

const POKEDEX_DEX_MAP = new Map();
const POKEDEX_DEX_BY_KEY = new Map();
for (const [id, data] of Object.entries(SPECIES_DATA)) {
    const dex = Math.floor(Number(data?.pokedex) || 0);
    if (!(dex > 0) || POKEDEX_DEX_BY_KEY.has(id)) continue;
    POKEDEX_DEX_BY_KEY.set(id, dex);
    if (!POKEDEX_DEX_MAP.has(dex)) POKEDEX_DEX_MAP.set(dex, { id, ...data });
}

const POKEDEX_SEARCH_INDEX = new Map();
function normalizePokedexQuery(text) {
    let value = String(text ?? "").toLowerCase();
    try { value = value.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); } catch (error) {}
    return value.replace(/[^a-z0-9]/g, "");
}
function pokedexSearchText(dex) {
    let value = POKEDEX_SEARCH_INDEX.get(dex);
    if (value === undefined) {
        const entry = POKEDEX_DEX_MAP.get(dex);
        value = entry ? `${normalizePokedexQuery(entry.name)} ${normalizePokedexQuery(entry.id)}` : "";
        POKEDEX_SEARCH_INDEX.set(dex, value);
    }
    return value;
}
export function sanitizePokedexQuery(value) {
    return String(value ?? "").replace(/[\u00a7|\r\n\t]/g, "").trim().slice(0, 24);
}
export function searchPokedexList(query) {
    const text = sanitizePokedexQuery(query);
    if (!text) return POKEDEX_DEX_LIST;
    if (/^#?\s*\d+$/.test(text)) {
        const number = Number(text.replace(/[^0-9]/g, ""));
        return POKEDEX_DEX_LIST.filter(dex => dex === number);
    }
    const needle = normalizePokedexQuery(text);
    if (!needle) return [];
    return POKEDEX_DEX_LIST.filter(dex => pokedexSearchText(dex).includes(needle));
}

function pad4Number(value) {
    return String(Math.max(0, Math.floor(Number(value)) || 0)).padStart(4, "0");
}
function pokedexSpeciesInfo(dex) {
    return POKEDEX_DEX_MAP.get(Math.floor(Number(dex) || 0)) || null;
}
function pokedexSeenCaughtSets(player) {
    const caught = new Set();
    const seen = new Set();
    for (const key of capturedSpecies(player)) {
        const dex = POKEDEX_DEX_BY_KEY.get(key);
        if (dex) { caught.add(dex); seen.add(dex); }
    }
    for (const key of encounteredSpecies(player)) {
        const dex = POKEDEX_DEX_BY_KEY.get(key);
        if (dex) seen.add(dex);
    }
    return { seen, caught };
}
export function pokedexCaughtDexSet(player) {
    return pokedexSeenCaughtSets(player).caught;
}
export function pokedexPortraitTexture(dex) {
    return `textures/gui/pokedex/portrait_anim/${pad4Number(dex)}`;
}
export function pokedexSpriteTexture(dex) {
    return `textures/gui/pokedex/sprites/${pad4Number(dex)}`;
}
export function pokedexPanToken(dex) {
    const variant = POKEDEX_PAN_VARIANT[Math.floor(Number(dex))] ?? 0;
    return `|PAN:${String(variant).padStart(2, "0")}|`;
}
export function pokedexPanVariant(dex) {
    return POKEDEX_PAN_VARIANT[Math.floor(Number(dex))] ?? 0;
}
export function pokedexThumbToken(page, pageCount) {
    const count = pageCount <= 1 ? 1 : 1 + Math.round((page * (POKEDEX_PAGE_COUNT - 1)) / (pageCount - 1));
    return `|PDXTHUMB:${String(Math.max(1, Math.min(POKEDEX_THUMB_VARIANTS, count))).padStart(2, "0")}|`;
}
function pokedexEntries() {
    return Object.entries(SPECIES_DATA)
        .map(([id, data]) => ({ id, ...data }))
        .sort((left, right) => Number(left.pokedex) - Number(right.pokedex));
}
const POKEDEX_SCAN_HUD_KEY = "pokedex_scan";
const POKEDEX_SCAN_HUD_STATES = new Set([
    "OPEN", "TARGET", "SCANNING", "REGISTERED", "DETAIL",
    "NO_TARGET", "CLOSE"
]);
const FORM_USERS = new Set();
const SCAN_SESSIONS = new Map();
const ACTIVE_USES = new Set();
const SCAN_NAME_TAG_LOCKS = new Map();
const OWNED_SYNC_QUEUED = new Set();

function registerOwnedPokemon(player, pokemon) {
    const speciesKey = captureSpeciesKey(pokemon);
    if (!speciesKey || !SPECIES_DATA[speciesKey]) return;
    markSpeciesCaptured(player, speciesKey);
}

export function reconcileOwnedPokedex(player) {
    if (!player?.isValid) return;
    for (const pokemon of loadPartyFromPlayer(player)) registerOwnedPokemon(player, pokemon);
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        for (const pokemon of loadPCFromPlayer(player, boxIndex)) {
            if (pokemon) registerOwnedPokemon(player, pokemon);
        }
    }
}

function queueOwnedPokedexSync(player) {
    if (!player?.isValid || OWNED_SYNC_QUEUED.has(player.id)) return;
    OWNED_SYNC_QUEUED.add(player.id);
    system.run(() => {
        OWNED_SYNC_QUEUED.delete(player.id);
        reconcileOwnedPokedex(player);
    });
}

subscribePokemonStorageSaved(queueOwnedPokedexSync);

function playPokedexSound(player, soundId, options = {}) {
    try {
        player.playSound(soundId, options);
    } catch (error) {}
}

function translatedSpecies(entry, prefix = "") {
    return {
        rawtext: [
            { text: prefix },
            { translate: `lota.species.${Math.max(0, Number(entry?.pokedex) || 0)}` }
        ]
    };
}

function isPokemonEntity(entity) {
    if (!entity?.isValid) return false;
    const typeId = String(entity.typeId || "");
    return typeId.startsWith("lota:")
        && !typeId.endsWith("_projectile")
        && typeId !== "lota:poke_ball_capture"
        && !!speciesData(typeId);
}

export function pokedexItemColor(itemId) {
    const match = /^lota:pokedex_(red|yellow|green|blue|pink|black|white)$/.exec(String(itemId || ""));
    return match?.[1] || null;
}

export function isPokedexItem(itemId) {
    return POKEDEX_ITEM_SET.has(String(itemId || ""));
}

export function firstPokedexScanTarget(hits) {
    for (const hit of hits || []) {
        if (isPokemonEntity(hit?.entity)) return hit.entity;
    }
    return undefined;
}

function playerDistanceSquared(player, entity) {
    const left = player.location;
    const right = entity.location;
    const dx = left.x - right.x;
    const dy = left.y - right.y;
    const dz = left.z - right.z;
    return dx * dx + dy * dy + dz * dz;
}

function pokemonFromEntity(entity) {
    const stored = loadPokemonFromEntity(entity);
    if (stored?.species) return stored;
    return { species: entity?.typeId };
}

function scanGenderSuffix(pokemon) {
    const gender = String(pokemon?.gender || "").toLowerCase();
    if (gender === "male" || gender === "m") return " §b♂§r";
    if (gender === "female" || gender === "f") return " §c♀§r";
    return "";
}

function scanInfoSubtitle(pokemon, entry) {
    return {
        rawtext: [
            { translate: `lota.species.${Math.max(0, Number(entry?.pokedex) || 0)}` },
            { text: scanGenderSuffix(pokemon) }
        ]
    };
}

function scanDataTokens(pokemon, entry, owned) {
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const types = Array.isArray(entry?.types)
        ? entry.types.map(type => String(type || "").toLowerCase()).filter(Boolean).slice(0, 2)
        : [];
    let tokens = "";
    if (level >= 100) tokens += "|PDXLV100|";
    else if (level < 10) tokens += `|PDXLV1:${level}|`;
    else tokens += `|PDXLVT:${Math.floor(level / 10)}||PDXLVO:${level % 10}|`;
    if (owned) tokens += "|PDXOWNED|";
    if (types[0]) tokens += `|PDXTYPE1:${types[0]}|`;
    if (types[1]) tokens += `|PDXDUAL||PDXTYPE2:${types[1]}|`;
    return tokens;
}

function randomScanSlots() {
    const slots = [0, 1, 2, 3];
    for (let index = slots.length - 1; index > 0; index--) {
        const swapIndex = Math.floor(Math.random() * (index + 1));
        [slots[index], slots[swapIndex]] = [slots[swapIndex], slots[index]];
    }
    return slots;
}

function playerOwnsScanSpecies(player, speciesKey) {
    return capturedSpecies(player).has(speciesKey);
}

function scanProgressPercent(session) {
    const scanTick = Math.max(0, Math.floor(Number(session?.scanTick) || 0));
    return Math.min(100, Math.floor((scanTick * 10) / POKEDEX_SCAN_TICKS) * 10);
}

function scanHudState(player, state, session = undefined) {
    try {
        const safeState = POKEDEX_SCAN_HUD_STATES.has(state) ? state : "CLOSE";
        const color = POKEDEX_COLORS.includes(session?.color) ? session.color : "red";
        const progress = scanProgressPercent(session);
        const title = `|PDXSCAN:${safeState}||PDXCOLOR:${color}||PDXNAMEPOS:0||PDXLEVELPOS:1||PDXTYPEPOS:2||PDXPROGRESS:${progress}|${session?.dataTokens || ""}`;
        setHudTitleTransient(
            player,
            POKEDEX_SCAN_HUD_KEY,
            {
                title,
                subtitle: session?.infoSubtitle || ""
            }
        );
    } catch (error) {
        console.warn(`Pokedex scan HUD state failed: ${error}`);
    }
}

function clearScanHud(player) {
    try {
        clearHudTitleTransient(player, POKEDEX_SCAN_HUD_KEY);
    } catch (error) {
        console.warn(`Pokedex scan HUD clear failed: ${error}`);
    }
}

function closePokedex(player) {
    FORM_USERS.delete(player.id);
    playPokedexSound(player, "lota.item.pokedex.close", { volume: 1 });
}

function pokedexDetail(dex, info, seen, caught) {
    if (!info || !seen) {
        return {
            rawtext: [
                { text: `#${pad4Number(dex)}\n\n???\n\n` },
                { translate: "lota.ui.pokedex.registration_hint" }
            ]
        };
    }
    if (!caught) {
        return "This Pokemon has been sighted.\nDetailed information is registered after catching it.";
    }
    const value = x => (x ?? "-");
    const stats = info.baseStats || {};
    return `Type  ${(info.types || []).join(" / ")}\nCatch Rate  ${value(info.catchRate)}\n\n` +
        `HP ${value(stats.hp)}  Atk ${value(stats.attack)}  Def ${value(stats.defence)}\n` +
        `SpA ${value(stats.specialAttack)}  SpD ${value(stats.specialDefence)}  Spe ${value(stats.speed)}`;
}

function openPokedexScreen(player, page, color, selectedDex, playOpenSound, query = "") {
    if (!player?.isValid || FORM_USERS.has(player.id)) return;
    reconcileOwnedPokedex(player);
    const { seen, caught } = pokedexSeenCaughtSets(player);
    const isSeen = dex => seen.has(dex);
    const isCaught = dex => caught.has(dex);

    query = sanitizePokedexQuery(query);
    const searching = query.length > 0;
    const list = searching ? searchPokedexList(query) : POKEDEX_DEX_LIST;
    const pageCount = Math.max(1, Math.ceil(list.length / POKEDEX_PAGE_SIZE));
    page = Math.max(0, Math.min(pageCount - 1, Math.floor(Number(page) || 0)));
    const start = page * POKEDEX_PAGE_SIZE;
    const pageDex = list.slice(start, start + POKEDEX_PAGE_SIZE);

    let seenCount = 0, caughtCount = 0;
    for (const dex of POKEDEX_DEX_LIST) {
        if (isSeen(dex)) seenCount++;
        if (isCaught(dex)) caughtCount++;
    }

    const selected = pageDex.includes(selectedDex)
        ? selectedDex
        : (pageDex.find(isSeen) ?? pageDex[0] ?? 0);
    const selectedInfo = selected ? pokedexSpeciesInfo(selected) : null;
    const selectedSeen = !!selected && isSeen(selected);
    const selectedCaught = !!selected && isCaught(selected);

    const form = new ActionFormData()
        .title(`cobbledrock.pokedex.list.${color}`)
        .body(pokedexDetail(selected, selectedInfo, selectedSeen, selectedCaught));

    for (let slot = 0; slot < POKEDEX_PAGE_SIZE; slot++) {
        const dex = pageDex[slot];
        if (!dex) {
            form.button("§0");
            continue;
        }
        const label = `${isCaught(dex) ? "§a" : "§8"}${pad4Number(dex)}§r`;
        if (searching) form.button(label, pokedexSpriteTexture(dex));
        else form.button(label);
    }

    const pageToken = searching
        ? pokedexThumbToken(page, pageCount)
        : `|PDXPAGE:${String(page + 1).padStart(2, "0")}|${pokedexThumbToken(page, POKEDEX_PAGE_COUNT)}`;
    form.button(`${page > 0 ? "§f" : "§0"}${pageToken}`);
    form.button(page + 1 < pageCount ? "§f" : "§0");
    if (selectedSeen && selectedInfo) form.button(`§f|PROFILE|${pokedexPanToken(selected)}`, pokedexPortraitTexture(selected));
    else form.button("§0");
    form.button(selected ? `#${pad4Number(selected)}` : "#----");
    form.button(selectedSeen && selectedInfo ? translatedSpecies(selectedInfo) : "???");
    form.button(pad4Number(seenCount));
    form.button(pad4Number(caughtCount));
    form.button(selectedCaught ? "§a" : "§0");
    form.button("§f");
    form.button(searching ? query : "Search...");

    for (let slot = 0; slot < POKEDEX_PAGE_SIZE; slot++) {
        const dex = pageDex[slot];
        if (!dex) {
            form.button("§0");
            form.button("§0");
            form.button("§0");
            form.button("§0");
            form.button("§0");
            continue;
        }
        const info = pokedexSpeciesInfo(dex);
        const seenEntry = isSeen(dex);
        const caughtEntry = isCaught(dex);
        const portraitText = seenEntry && info ? `§f|PROFILE|${pokedexPanToken(dex)}` : "§0";
        if (seenEntry && info) form.button(portraitText, pokedexPortraitTexture(dex));
        else form.button(portraitText);
        form.button(`#${pad4Number(dex)}`);
        form.button(seenEntry && info ? translatedSpecies(info) : "???");
        form.button(caughtEntry ? "§a" : "§0");
        form.button(pokedexDetail(dex, info, seenEntry, caughtEntry));
    }

    FORM_USERS.add(player.id);
    if (playOpenSound) playPokedexSound(player, "lota.item.pokedex.open", { volume: 1 });
    let settled = false;
    const cleanup = () => {
        if (settled) return;
        settled = true;
        FORM_USERS.delete(player.id);
    };
    try {
        form.show(player).then(response => {
            cleanup();
            if (!player?.isValid) return;
            if (response.canceled) {
                if (response.cancelationReason !== "UserBusy") closePokedex(player);
                return;
            }
            const selection = Math.floor(Number(response.selection));
            if (selection >= 0 && selection < POKEDEX_PAGE_SIZE) return;
            if (selection === POKEDEX_PAGE_SIZE && page > 0) {
                playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
                return openPokedexScreen(player, page - 1, color, null, false, query);
            }
            if (selection === POKEDEX_PAGE_SIZE + 1 && page + 1 < pageCount) {
                playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
                return openPokedexScreen(player, page + 1, color, null, false, query);
            }
            if (selection === POKEDEX_PAGE_SIZE || selection === POKEDEX_PAGE_SIZE + 1) {
                return openPokedexScreen(player, page, color, selected, false, query);
            }
            if (selection === POKEDEX_PAGE_SIZE + 8) {
                playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
                return openPokedexSearch(player, page, color, selected, query);
            }
            closePokedex(player);
        }).catch(error => {
            cleanup();
            console.warn(`Pokedex form failed: ${error}`);
        });
    } catch (error) {
        cleanup();
        console.warn(`Pokedex form error: ${error}`);
    }
}

function openPokedexSearch(player, page, color, selectedDex, query) {
    try {
        if (!player?.isValid || FORM_USERS.has(player.id)) return;
        const form = new ModalFormData().title("Pokédex Search");
        form.textField("Pokémon name or number (empty = show all)", "e.g. Pikachu or 25", { defaultValue: String(query || "") });
        FORM_USERS.add(player.id);
        form.show(player).then(response => {
            FORM_USERS.delete(player.id);
            if (!player?.isValid) return;
            if (response.canceled) {
                if (response.cancelationReason === "UserBusy") return;
                return openPokedexScreen(player, page, color, selectedDex, false, query);
            }
            openPokedexScreen(player, 0, color, null, false, sanitizePokedexQuery(response.formValues?.[0]));
        }).catch(error => {
            FORM_USERS.delete(player.id);
            console.warn(`Pokedex search form failed: ${error}`);
        });
    } catch (error) {
        FORM_USERS.delete(player?.id);
        console.warn(`Pokedex search form error: ${error}`);
    }
}

export function showPokedex(player, requestedPage = 0, requestedColor = "red", requestedEntryId = null, playOpenSound = true) {
    if (!player?.isValid) return;
    const color = POKEDEX_COLORS.includes(requestedColor) ? requestedColor : "red";
    const requestedDex = requestedEntryId ? POKEDEX_DEX_BY_KEY.get(String(requestedEntryId)) ?? null : null;
    openPokedexScreen(player, requestedPage, color, requestedDex, playOpenSound);
}

const DEX_CHEST_KEY = "pokedex";
const DEX_CHEST_TITLE = "\u00a7r\u00a72\u00a7r\u00a72";
const DEX_MENU_FORM_TAG = "lota:menu_form";
const DEX_BATTLE_TAG = "lota:battle_player";
const DEX_SLOT = Object.freeze({
    PREV: 25, NEXT: 26, PROFILE: 27, NUMBER: 28, NAME: 29, SEEN: 30, CAUGHT: 31,
    CLOSE: 32, BODY: 33, COLOR_FIRST: 40, PORTRAIT: 47
});
const DEX_BODY_WRAP = 40;
const DEX_CHEST_LAYOUT = Object.freeze({
    title: DEX_CHEST_TITLE,
    n: 48,
    tex: [], txt: [], cap: [], btn: [],
    tb: [...Array.from({ length: DEX_SLOT.NEXT + 1 }, (_, i) => [i, i]), [DEX_SLOT.CLOSE, DEX_SLOT.CLOSE]],
    vis: POKEDEX_COLORS.map((color, i) => [DEX_SLOT.COLOR_FIRST + i, "|C:" + color + "|"]),
    ml: [
        [DEX_SLOT.PROFILE, "profile"], [DEX_SLOT.NUMBER, "number"], [DEX_SLOT.NAME, "name"],
        [DEX_SLOT.SEEN, "seen"], [DEX_SLOT.CAUGHT, "caught"], [DEX_SLOT.BODY, "body"]
    ],
    ic: [[DEX_SLOT.PORTRAIT, "portrait"]]
});

function heldPokedexItemId(player) {
    try {
        const id = player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot.Mainhand)?.typeId;
        return isPokedexItem(id) ? id : null;
    } catch (error) {
        return null;
    }
}

function dexChestWants(player) {
    try {
        if (player.hasTag(DEX_MENU_FORM_TAG) || player.hasTag(DEX_BATTLE_TAG)) return false;
        if (player.isSneaking) return false;
    } catch (error) { return false; }
    return !!heldPokedexItemId(player);
}

function newDexChestState(player) {
    return {
        color: pokedexItemColor(heldPokedexItemId(player)) || "red",
        page: 0,
        pageCount: 1,
        selectedDex: 0,
        entryDex: []
    };
}

function wrapDexText(text, limit) {
    const out = [];
    for (const raw of String(text ?? "").split("\n")) {
        let rest = raw;
        while (rest.length > limit) {
            const cut = rest.lastIndexOf(" ", limit);
            const at = cut > 0 ? cut : limit;
            out.push(rest.slice(0, at));
            rest = rest.slice(cut > 0 ? at + 1 : at);
        }
        out.push(rest);
    }
    return out.join("\n");
}

function pokedexChestDetailText(dex, info, seen, caught) {
    if (!info || !seen) {
        return wrapDexText("#" + pad4Number(dex) + "\n\n???\n\nOwn this Pok\u00e9mon at least once to register it in the Pok\u00e9dex.", DEX_BODY_WRAP);
    }
    if (!caught) {
        return wrapDexText("This Pokemon has been sighted.\nDetailed information is registered after catching it.", DEX_BODY_WRAP);
    }
    const value = x => (x ?? "-");
    const stats = info.baseStats || {};
    return "Type  " + (info.types || []).join(" / ") + "\nCatch Rate  " + value(info.catchRate) + "\n\n"
        + "HP " + value(stats.hp) + "  Atk " + value(stats.attack) + "  Def " + value(stats.defence) + "\n"
        + "SpA " + value(stats.specialAttack) + "  SpD " + value(stats.specialDefence) + "  Spe " + value(stats.speed);
}

function dexChestView(player, state) {
    const { seen, caught } = pokedexSeenCaughtSets(player);
    const list = POKEDEX_DEX_LIST;
    const pageCount = Math.max(1, Math.ceil(list.length / POKEDEX_PAGE_SIZE));
    const page = Math.max(0, Math.min(pageCount - 1, Math.floor(Number(state.page) || 0)));
    const start = page * POKEDEX_PAGE_SIZE;
    const pageDex = list.slice(start, start + POKEDEX_PAGE_SIZE);

    let seenCount = 0, caughtCount = 0;
    for (const dex of list) {
        if (seen.has(dex)) seenCount++;
        if (caught.has(dex)) caughtCount++;
    }

    const selected = pageDex.includes(state.selectedDex)
        ? state.selectedDex
        : (pageDex.find(dex => seen.has(dex)) ?? pageDex[0] ?? 0);
    const selectedInfo = selected ? pokedexSpeciesInfo(selected) : null;
    const selectedSeen = !!selected && seen.has(selected);
    const selectedCaught = !!selected && caught.has(selected);

    state.page = page;
    state.pageCount = pageCount;
    state.selectedDex = selected;
    state.entryDex = pageDex.slice();

    const buttons = new Array(DEX_SLOT.CLOSE + 1).fill("");
    for (let slot = 0; slot < POKEDEX_PAGE_SIZE; slot++) {
        const dex = pageDex[slot];
        if (!dex) { buttons[slot] = "|EMPTY|"; continue; }
        const isCaught = caught.has(dex);
        buttons[slot] = (isCaught ? "\u00a7a" : "\u00a78") + "#" + pad4Number(dex) + "\u00a7r"
            + (isCaught ? "|CAUGHT|" : "") + (dex === selected ? "|DEX_SELECTED|" : "");
    }
    const pageToken = "|PDXPAGE:" + String(page + 1).padStart(2, "0") + "|" + pokedexThumbToken(page, POKEDEX_PAGE_COUNT);
    buttons[DEX_SLOT.PREV] = (page > 0 ? "|NAV|" : "") + pageToken;
    buttons[DEX_SLOT.NEXT] = page + 1 < pageCount ? "|NAV|" : "";
    buttons[DEX_SLOT.CLOSE] = selectedCaught ? "|CAUGHT|" : "";

    const showProfile = selectedSeen && !!selectedInfo;
    return {
        title: "|C:" + state.color + "|",
        buttons,
        icons: { portrait: showProfile ? pokedexPortraitTexture(selected) : null },
        multi: {
            profile: showProfile ? "|PROFILE|" + pokedexPanToken(selected) : "",
            number: selected ? "#" + pad4Number(selected) : "#----",
            name: showProfile ? String(selectedInfo.name || "???") : "???",
            seen: pad4Number(seenCount),
            caught: pad4Number(caughtCount),
            body: pokedexChestDetailText(selected, selectedInfo, selectedSeen, selectedCaught)
        }
    };
}

function dexChestPress(player, state, button) {
    if (button >= 0 && button < POKEDEX_PAGE_SIZE) {
        const dex = state.entryDex[button];
        if (!dex) return "keep";
        playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
        state.selectedDex = dex;
        return "redraw";
    }
    if (button === DEX_SLOT.PREV) {
        if (state.page <= 0) return "keep";
        playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
        state.page -= 1;
        state.selectedDex = 0;
        return "redraw";
    }
    if (button === DEX_SLOT.NEXT) {
        if (state.page + 1 >= state.pageCount) return "keep";
        playPokedexSound(player, "lota.item.pokedex.click_short", { volume: 1 });
        state.page += 1;
        state.selectedDex = 0;
        return "redraw";
    }
    if (button === DEX_SLOT.CLOSE) {
        playPokedexSound(player, "lota.item.pokedex.close", { volume: 1 });
        return "close";
    }
    return "keep";
}

registerChestScreen({
    key: DEX_CHEST_KEY,
    layout: DEX_CHEST_LAYOUT,
    wants: dexChestWants,
    create: player => newDexChestState(player),
    onOpen: (player, state) => {
        const color = pokedexItemColor(heldPokedexItemId(player));
        if (color) state.color = color;
        reconcileOwnedPokedex(player);
        playPokedexSound(player, "lota.item.pokedex.open", { volume: 1 });
    },
    view: dexChestView,
    press: dexChestPress
});

export function openPokedex(player, color = "red") {
    if (dexChestWants(player) && openChestScreen(player, DEX_CHEST_KEY, { hold: 100 })) return;
    showPokedex(player, 0, color);
}

const DEX_SNEAK_STATES = new Map();
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        if (!player.isValid) continue;
        const sneaking = !!player.isSneaking;
        const wasSneaking = DEX_SNEAK_STATES.get(player.id) || false;
        DEX_SNEAK_STATES.set(player.id, sneaking);
        if (sneaking && !wasSneaking && chestScreenActive(player, DEX_CHEST_KEY)) closeChestScreen(player);
    }
}, 1);

function scanTargetForPlayer(player) {
    try {
        const directTarget = firstPokedexScanTarget(
            player.getEntitiesFromViewDirection({ maxDistance: POKEDEX_SCAN_RANGE })
        );
        if (directTarget) return directTarget;
    } catch (error) {}

    try {
        const origin = player.getHeadLocation();
        const direction = player.getViewDirection();
        let bestTarget;
        let bestScore = Number.POSITIVE_INFINITY;
        for (const entity of player.dimension.getEntities({ location: origin, maxDistance: POKEDEX_SCAN_RANGE })) {
            if (!isPokemonEntity(entity)) continue;
            const location = entity.location;
            let head = location;
            try { head = entity.getHeadLocation(); } catch (error) {}
            const points = [
                { x: location.x, y: location.y + 0.8, z: location.z },
                head
            ];
            let entityScore = Number.POSITIVE_INFINITY;
            for (const point of points) {
                const dx = point.x - origin.x;
                const dy = point.y - origin.y;
                const dz = point.z - origin.z;
                const projection = dx * direction.x + dy * direction.y + dz * direction.z;
                if (projection <= 0 || projection > POKEDEX_SCAN_RANGE) continue;
                const distanceSquared = dx * dx + dy * dy + dz * dz;
                const perpendicularSquared = Math.max(0, distanceSquared - projection * projection);
                const allowance = Math.max(1.15, projection * 0.07);
                if (perpendicularSquared > allowance * allowance) continue;
                entityScore = Math.min(entityScore, perpendicularSquared / (allowance * allowance) + projection * 0.0001);
            }
            if (entityScore < bestScore) {
                bestScore = entityScore;
                bestTarget = entity;
            }
        }
        return bestTarget;
    } catch (error) {
        return undefined;
    }
}

function showScanSessionState(session, state) {
    const signature = `${state}:${session.targetId || ""}:${scanProgressPercent(session)}`;
    if (session.hudSignature === signature) return;
    session.hudSignature = signature;
    scanHudState(session.player, state, session);
}

function releaseScanTargetNameTag(session) {
    const targetId = session.nameTagTargetId;
    session.nameTagTargetId = "";
    if (!targetId) return;

    const lock = SCAN_NAME_TAG_LOCKS.get(targetId);
    if (!lock) return;
    lock.viewers.delete(session.playerId);
    if (lock.viewers.size > 0) return;

    SCAN_NAME_TAG_LOCKS.delete(targetId);
    try {
        if (lock.entity?.isValid && String(lock.entity.nameTag || "") === "") {
            lock.entity.nameTag = lock.originalNameTag;
        }
    } catch (error) {}
}

function hideScanTargetNameTag(session, target) {
    releaseScanTargetNameTag(session);
    if (!target?.isValid) return;

    let lock = SCAN_NAME_TAG_LOCKS.get(target.id);
    if (!lock) {
        lock = {
            entity: target,
            originalNameTag: String(target.nameTag || ""),
            viewers: new Set()
        };
        SCAN_NAME_TAG_LOCKS.set(target.id, lock);
        try { target.nameTag = ""; } catch (error) {}
    }
    lock.viewers.add(session.playerId);
    session.nameTagTargetId = target.id;
}

function resetScanSessionTarget(session) {
    releaseScanTargetNameTag(session);
    session.targetId = "";
    session.target = undefined;
    session.pokemon = undefined;
    session.entry = undefined;
    session.speciesKey = "";
    session.scanTick = -1;
    session.scanCompleteShown = false;
    session.resultTick = -1;
    session.wasSeen = false;
    session.owned = false;
    session.layoutSlots = [0, 1, 2, 3];
    session.infoSubtitle = "";
    session.dataTokens = "";
    session.detailSoundPlayed = false;
    session.hudSignature = "";
}

function focusScanTarget(session, target) {
    const pokemon = pokemonFromEntity(target);
    const speciesKey = captureSpeciesKey(pokemon);
    const entry = speciesData(pokemon);
    if (!speciesKey || !entry) {
        resetScanSessionTarget(session);
        return false;
    }

    const owned = playerOwnsScanSpecies(session.player, speciesKey);
    session.targetId = target.id;
    hideScanTargetNameTag(session, target);
    session.target = target;
    session.pokemon = pokemon;
    session.entry = entry;
    session.speciesKey = speciesKey;
    session.scanTick = -1;
    session.scanCompleteShown = false;
    session.resultTick = -1;
    session.wasSeen = owned;
    session.owned = owned;
    session.layoutSlots = randomScanSlots();
    session.infoSubtitle = scanInfoSubtitle(pokemon, entry);
    session.dataTokens = scanDataTokens(pokemon, entry, owned);
    session.detailSoundPlayed = false;
    session.hudSignature = "";
    return true;
}

function updatePokedexScanSession(session) {
    const player = session.player;
    if (!player?.isValid || !ACTIVE_USES.has(player.id)) {
        if (player?.isValid) stopPokedexScan(player);
        else {
            releaseScanTargetNameTag(session);
            SCAN_SESSIONS.delete(session.playerId);
        }
        return;
    }

    const useTicks = system.currentTick - session.startedTick;
    if (useTicks < POKEDEX_SCAN_OPEN_TICKS) return;

    if (!session.opened) {
        session.opened = true;
        playPokedexSound(player, "lota.item.pokedex.scan_open", { volume: 0.6 });
        showScanSessionState(session, "OPEN");
        return;
    }

    const target = scanTargetForPlayer(player);
    if (!target) {
        if (session.targetId) resetScanSessionTarget(session);
        showScanSessionState(session, "NO_TARGET");
        return;
    }
    if (target.id !== session.targetId && !focusScanTarget(session, target)) {
        showScanSessionState(session, "NO_TARGET");
        return;
    }

    if (session.resultTick >= 0) {
        session.resultTick += 1;
        showScanSessionState(session, session.resultTick <= POKEDEX_SCAN_RESULT_TICKS ? "REGISTERED" : "DETAIL");
        return;
    }

    if (session.wasSeen) {
        if (!session.detailSoundPlayed) {
            session.detailSoundPlayed = true;
            playPokedexSound(player, "lota.item.pokedex.scan_detail", { volume: 0.55 });
        }
        showScanSessionState(session, "DETAIL");
        return;
    }

    session.scanTick = session.scanTick < 0 ? 0 : session.scanTick + 1;
    if (session.scanTick % 7 === 0) {
        playPokedexSound(player, "lota.item.pokedex.scan_loop", { volume: 0.35 });
    }
    if (session.scanTick >= POKEDEX_SCAN_TICKS) {
        if (!session.scanCompleteShown) {
            session.scanCompleteShown = true;
            showScanSessionState(session, "SCANNING");
            return;
        }
        identify(player, session.pokemon);
        session.wasSeen = true;
        playPokedexSound(player, "lota.item.pokedex.scan_detail", { volume: 0.55 });
        showScanSessionState(session, "DETAIL");
        return;
    }

    showScanSessionState(session, session.scanTick === 0 ? "TARGET" : "SCANNING");
}

export function registeredPokedexCount(player) {
    reconcileOwnedPokedex(player);
    const caught = capturedSpecies(player);
    return pokedexEntries().filter(entry => caught.has(entry.id)).length;
}

export function pokedexEntryCount() {
    return pokedexEntries().length;
}

function stopPokedexScan(player) {
    const session = SCAN_SESSIONS.get(player.id);
    SCAN_SESSIONS.delete(player.id);
    if (session) releaseScanTargetNameTag(session);
    if (!session?.opened) {
        clearScanHud(player);
        return;
    }

    playPokedexSound(player, "lota.item.pokedex.scan_close", { volume: 0.8 });
    clearScanHud(player);
}

export function beginPokedexScan(player, color = "red") {
    if (!player?.isValid || SCAN_SESSIONS.has(player.id)) return false;
    clearScanHud(player);
    SCAN_SESSIONS.set(player.id, {
        player,
        playerId: player.id,
        color,
        startedTick: system.currentTick,
        opened: false,
        hudSignature: "",
        targetId: ""
    });
    return true;
}

export function isPokedexScanActive(playerId) {
    return SCAN_SESSIONS.has(String(playerId || ""));
}

export function isScanTargetNameTagLocked(entityId) {
    return SCAN_NAME_TAG_LOCKS.has(String(entityId || ""));
}

system.runInterval(() => {
    for (const session of [...SCAN_SESSIONS.values()]) updatePokedexScanSession(session);
}, 1);
world.afterEvents.itemStartUse.subscribe(event => {
    const itemId = event.itemStack?.typeId;
    if (!isPokedexItem(itemId)) return;

    const player = event.source;
    if (!claimPokedexUse(ACTIVE_USES, player.id)) return;

    if (player.isSneaking) beginPokedexScan(player, pokedexItemColor(itemId));
    else system.run(() => openPokedex(player, pokedexItemColor(itemId)));
});

world.afterEvents.itemStopUse.subscribe(event => {
    releasePokedexUse(ACTIVE_USES, event.source.id);
    stopPokedexScan(event.source);
});

world.afterEvents.playerLeave.subscribe(event => {
    DEX_SNEAK_STATES.delete(event.playerId);
    FORM_USERS.delete(event.playerId);
    const session = SCAN_SESSIONS.get(event.playerId);
    if (session) releaseScanTargetNameTag(session);
    SCAN_SESSIONS.delete(event.playerId);
    ACTIVE_USES.delete(event.playerId);
    OWNED_SYNC_QUEUED.delete(event.playerId);
});

world.afterEvents.playerSpawn.subscribe(event => {
    if (event.initialSpawn) queueOwnedPokedexSync(event.player);
});
