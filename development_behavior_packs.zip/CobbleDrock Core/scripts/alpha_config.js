export const ALPHA_CONFIG = Object.freeze({
  naturalAlphaChanceSolo: 0.012,
  naturalAlphaChanceHerd: 0.012,
  naturalAlphaChanceLegendary: 0.002,

  levelBonusTable: [
    { maxHighest: 20, bonus: 4 },
    { maxHighest: 30, bonus: 8 },
    { maxHighest: 45, bonus: 12 },
    { maxHighest: 65, bonus: 16 },
    { maxHighest: Infinity, bonus: 20 },
  ],
  levelWhenNoParty: 5,
  maxAlphaLevel: 100,
  minLevelFloorRange: [50, 70],

  wildMightEnabled: true,
  wildMightStats: ["atk", "def", "spa", "spd", "spe"],

  herdEnabled: true,
  herdMinSize: 2,
  herdMaxSize: 4,
  herdSpawnRadius: 3.5,
  herdLevelPenalty: 6,
  herdLeashDistance: 14,
  herdLeashCheckIntervalTicks: 80,

  detectionRadius: 16,

  overworldAttackEnabled: true,
  overworldAttackDamage: 2,
  overworldAttackSpeedMultiplier: 1.0,
  overworldAttackReachMultiplier: 1.2,

  scanIntervalTicks: 8,
  glowIntervalTicks: 10,

  drops: {
    typeGem: true,
    expCandyByLevel: [
      { maxLevel: 20, item: "lota:exp_candy_xs" },
      { maxLevel: 40, item: "lota:exp_candy_s" },
      { maxLevel: 60, item: "lota:exp_candy_m" },
      { maxLevel: 80, item: "lota:exp_candy_l" },
      { maxLevel: Infinity, item: "lota:exp_candy_xl" },
    ],
    bonusItem: "lota:rare_candy",
  },

  keys: {
    isAlphaChecked: "lota:alpha_checked",
    herdMember: "lota:alpha_herd_member",
    herdLeaderId: "lota:alpha_herd_leader_id",
    totalCaptured: "lota:totalAlphaCaptureCount",
    firstCaught: "lota:has_caught_alpha",
    firstDefeated: "lota:has_defeated_alpha",
  },
});
