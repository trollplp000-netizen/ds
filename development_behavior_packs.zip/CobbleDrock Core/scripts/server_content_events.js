import { system } from "@minecraft/server";

export const WILD_BATTLE_VICTORY_EVENT = "lota:server_wild_battle_victory_v1";

function cleanSpecies(value) {
    return String(value || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();
}

export function publishServerWildBattleVictory(session) {
    if (session?.battleType !== "wild" || !session?.target?.isValid) return false;
    const species = cleanSpecies(session.wildPokemon?.species || session.wildPokemon?.id);
    const location = session.target.location;
    const dimensionId = session.target.dimension?.id;
    if (!species || !location || !dimensionId) return false;
    try {
        system.sendScriptEvent(WILD_BATTLE_VICTORY_EVENT, JSON.stringify({
            version: 1,
            playerId: String(session.playerId || ""),
            species,
            dimensionId: String(dimensionId),
            location: {
                x: Number(location.x) || 0,
                y: (Number(location.y) || 0) + 0.35,
                z: Number(location.z) || 0
            }
        }));
        return true;
    } catch (error) {
        console.warn(`[Server Content API] Wild battle result publish failed: ${error}`);
        return false;
    }
}
