import { SPECIES_DATA } from "./species_registry.js";
import { pokemonModelVariant } from './pokemon_visual_state.js';

export const TYPE_RESIST_BERRIES = Object.freeze({
    occa_berry: "fire",
    passho_berry: "water",
    wacan_berry: "electric",
    rindo_berry: "grass",
    yache_berry: "ice",
    chople_berry: "fighting",
    kebia_berry: "poison",
    shuca_berry: "ground",
    coba_berry: "flying",
    payapa_berry: "psychic",
    tanga_berry: "bug",
    charti_berry: "rock",
    kasib_berry: "ghost",
    haban_berry: "dragon",
    colbur_berry: "dark",
    babiri_berry: "steel",
    chilan_berry: "normal",
    roseli_berry: "fairy"
});
import { SPECIES_WEIGHTS } from "./battle_species_weights.js";
import { MOVE_DATA, moveData } from "./move_registry.js";
import { resetBattleState, stageMultiplier, statStage } from "./battle_effects.js";
import { specialHeldItemDamageMultiplier, specialMoveType } from "./special_forms.js";

const DEFAULT_BASE_STATS = Object.freeze({
    hp: 45,
    attack: 49,
    defence: 49,
    specialAttack: 49,
    specialDefence: 49,
    speed: 45
});

const NATURE_MODIFIERS = Object.freeze({
    lonely: ["attack", "defence"],
    brave: ["attack", "speed"],
    adamant: ["attack", "specialAttack"],
    naughty: ["attack", "specialDefence"],
    bold: ["defence", "attack"],
    relaxed: ["defence", "speed"],
    impish: ["defence", "specialAttack"],
    lax: ["defence", "specialDefence"],
    timid: ["speed", "attack"],
    hasty: ["speed", "defence"],
    jolly: ["speed", "specialAttack"],
    naive: ["speed", "specialDefence"],
    modest: ["specialAttack", "attack"],
    mild: ["specialAttack", "defence"],
    quiet: ["specialAttack", "speed"],
    rash: ["specialAttack", "specialDefence"],
    calm: ["specialDefence", "attack"],
    gentle: ["specialDefence", "defence"],
    sassy: ["specialDefence", "speed"],
    careful: ["specialDefence", "specialAttack"]
});

const TYPE_CHART = Object.freeze({
    normal: { rock: 0.5, ghost: 0, steel: 0.5 },
    fire: { fire: 0.5, water: 0.5, grass: 2, ice: 2, bug: 2, rock: 0.5, dragon: 0.5, steel: 2 },
    water: { fire: 2, water: 0.5, grass: 0.5, ground: 2, rock: 2, dragon: 0.5 },
    electric: { water: 2, electric: 0.5, grass: 0.5, ground: 0, flying: 2, dragon: 0.5 },
    grass: { fire: 0.5, water: 2, grass: 0.5, poison: 0.5, ground: 2, flying: 0.5, bug: 0.5, rock: 2, dragon: 0.5, steel: 0.5 },
    ice: { fire: 0.5, water: 0.5, grass: 2, ice: 0.5, ground: 2, flying: 2, dragon: 2, steel: 0.5 },
    fighting: { normal: 2, ice: 2, poison: 0.5, flying: 0.5, psychic: 0.5, bug: 0.5, rock: 2, ghost: 0, dark: 2, steel: 2, fairy: 0.5 },
    poison: { grass: 2, poison: 0.5, ground: 0.5, rock: 0.5, ghost: 0.5, steel: 0, fairy: 2 },
    ground: { fire: 2, electric: 2, grass: 0.5, poison: 2, flying: 0, bug: 0.5, rock: 2, steel: 2 },
    flying: { electric: 0.5, grass: 2, fighting: 2, bug: 2, rock: 0.5, steel: 0.5 },
    psychic: { fighting: 2, poison: 2, psychic: 0.5, dark: 0, steel: 0.5 },
    bug: { fire: 0.5, grass: 2, fighting: 0.5, poison: 0.5, flying: 0.5, psychic: 2, ghost: 0.5, dark: 2, steel: 0.5, fairy: 0.5 },
    rock: { fire: 2, ice: 2, fighting: 0.5, ground: 0.5, flying: 2, bug: 2, steel: 0.5 },
    ghost: { normal: 0, psychic: 2, ghost: 2, dark: 0.5 },
    dragon: { dragon: 2, steel: 0.5, fairy: 0 },
    dark: { fighting: 0.5, psychic: 2, ghost: 2, dark: 0.5, fairy: 0.5 },
    steel: { fire: 0.5, water: 0.5, electric: 0.5, ice: 2, rock: 2, steel: 0.5, fairy: 2 },
    fairy: { fire: 0.5, fighting: 2, poison: 0.5, dragon: 2, dark: 2, steel: 0.5 },
    typeless: {}
});

function cleanId(value) {
    return String(value || "")
        .replace("cobblemon:", "")
        .replace("lota:", "")
        .toLowerCase();
}

export function speciesKey(pokemonOrId) {
    const value = typeof pokemonOrId === "string"
        ? pokemonOrId
        : (pokemonOrId?.battleState?.megaSpecies || pokemonOrId?.megaState?.runtimeSpecies || pokemonOrId?.species);
    return cleanId(value);
}

export function speciesData(pokemonOrId) {
    const data = SPECIES_DATA[speciesKey(pokemonOrId)] || null;
    if (typeof pokemonOrId !== 'string') {
        const variant = pokemonModelVariant(pokemonOrId)?.data;
        const runtimeSpecies = cleanId(pokemonOrId?.battleState?.megaSpecies || pokemonOrId?.megaState?.runtimeSpecies);
        const baseSpecies = cleanId(pokemonOrId?.species);
        if (variant && (!runtimeSpecies || runtimeSpecies === baseSpecies)) return variant;
    }
    return data;
}

export function speciesWeight(pokemonOrId) {
    const key = speciesKey(pokemonOrId);
    const formWeight = pokemonModelVariant(pokemonOrId)?.data?.weight;
    if (formWeight !== undefined) return Math.max(1, Number(formWeight) || 1);
    return Math.max(1, Number(SPECIES_WEIGHTS[key] ?? SPECIES_DATA[key]?.weight) || 1);
}

export function pokemonTypes(pokemonOrId) {
    if (typeof pokemonOrId !== "string" && Array.isArray(pokemonOrId?.battleState?.typeOverride)) return pokemonOrId.battleState.typeOverride;
    const data = speciesData(pokemonOrId);
    const types = data?.types?.length ? [...data.types] : ["normal"];
    return typeof pokemonOrId !== "string" && pokemonOrId?.battleState?.roost ? types.filter(type => type !== "flying") : types;
}

export function isGrounded(pokemon) {
    const state = pokemon?.battleState || {};
    if (state.smackDown) return true;
    if (Number(state.magnetRiseTurns) > 0) return false;
    if (cleanId(pokemon?.ability) === "levitate") return false;
    return !pokemonTypes(pokemon).includes("flying");
}

function statNumber(source, key, fallback) {
    const value = Number(source?.[key]);
    return Number.isFinite(value) ? value : fallback;
}

export function natureMultiplier(pokemon, stat) {
    const nature = cleanId(pokemon?.mintedNature || pokemon?.nature || "");
    const modifier = NATURE_MODIFIERS[nature];
    if (!modifier) return 1;
    if (modifier[0] === stat) return 1.1;
    if (modifier[1] === stat) return 0.9;
    return 1;
}

export function calculateMaxHp(pokemon) {
    const data = speciesData(pokemon);
    const baseStats = data?.baseStats || DEFAULT_BASE_STATS;
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const iv = statNumber(pokemon?.ivs, "hp", 0);
    const ev = statNumber(pokemon?.evs, "hp", 0);
    return Math.max(1, Math.floor(((2 * baseStats.hp + iv + Math.floor(ev / 4)) * level) / 100) + level + 10);
}

export function calculateStat(pokemon, stat) {
    const data = speciesData(pokemon);
    const baseStats = data?.baseStats || DEFAULT_BASE_STATS;
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const iv = statNumber(pokemon?.ivs, stat, 0);
    const ev = statNumber(pokemon?.evs, stat, 0);
    const base = Math.floor(((2 * baseStats[stat] + iv + Math.floor(ev / 4)) * level) / 100) + 5;
    return Math.max(1, Math.floor(base * natureMultiplier(pokemon, stat)));
}

export function battleStats(pokemon) {
    const status = String(pokemon?.statusCondition || "NONE").toLowerCase();
    return {
        hp: calculateMaxHp(pokemon),
        attack: Math.max(1, Math.floor(calculateStat(pokemon, "attack") * stageMultiplier(statStage(pokemon, "atk")))),
        defence: Math.max(1, Math.floor(calculateStat(pokemon, "defence") * stageMultiplier(statStage(pokemon, "def")))),
        specialAttack: Math.max(1, Math.floor(calculateStat(pokemon, "specialAttack") * stageMultiplier(statStage(pokemon, "spa")))),
        specialDefence: Math.max(1, Math.floor(calculateStat(pokemon, "specialDefence") * stageMultiplier(statStage(pokemon, "spd")))),
        speed: Math.max(1, Math.floor(calculateStat(pokemon, "speed") * stageMultiplier(statStage(pokemon, "spe")) * (status === "par" ? 0.5 : 1)))
    };
}

function learnedMoveIds(pokemon) {
    const data = speciesData(pokemon);
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    if (!data?.levelMoves?.length) return [];

    const result = [];
    for (const move of data.levelMoves) {
        if (Number(move.level) <= level) {
            const id = cleanId(move.id);
            if (MOVE_DATA[id]) result.push(id);
        }
    }
    return result;
}

function lastUniqueMoveIds(ids) {
    const result = [];
    for (let i = ids.length - 1; i >= 0 && result.length < 4; i--) {
        const id = ids[i];
        if (!result.includes(id)) result.unshift(id);
    }
    return result;
}

export function effectiveMoves(pokemon, options = {}) {
    const learned = lastUniqueMoveIds(learnedMoveIds(pokemon));
    const current = Array.isArray(pokemon?.moves)
        ? pokemon.moves
            .map(move => cleanId(move?.id || move))
            .filter(id => MOVE_DATA[id])
        : [];

    const looksLikeGeneratedPlaceholder =
        current.length <= 1 &&
        current[0] === "tackle" &&
        learned.some(id => id !== "tackle");

    const chosen = options.forceMoves || current.length === 0 || looksLikeGeneratedPlaceholder
        ? learned
        : current.slice(0, 4);

    const safeChosen = chosen.length ? chosen : ["tackle"];
    return safeChosen.map(id => {
        const data = moveData(id);
        const existing = Array.isArray(pokemon?.moves)
            ? pokemon.moves.find(move => cleanId(move?.id || move) === id)
            : undefined;
        const pp = Number.isFinite(Number(existing?.pp)) ? Number(existing.pp) : data.pp;
        return {
            id,
            pp: Math.max(0, Math.min(data.pp, Math.floor(pp))),
            maxPp: data.pp
        };
    });
}

export function normalizePokemonForBattle(pokemon, options = {}) {
    if (!pokemon) return null;
    const normalized = pokemon;
    if (!normalized.species) return normalized;
    normalized.level = Math.max(1, Math.floor(Number(normalized.level) || 1));

    const maxHp = calculateMaxHp(normalized);
    const oldMaxHp = Number(normalized.maxHp);
    const oldCurrentHp = Number(normalized.currentHp);
    if (!Number.isFinite(oldCurrentHp)) {
        normalized.currentHp = maxHp;
    } else if (!Number.isFinite(oldMaxHp) || oldMaxHp <= 0 || oldCurrentHp >= oldMaxHp) {
        normalized.currentHp = maxHp;
    } else {
        normalized.currentHp = Math.max(0, Math.min(maxHp, Math.round(maxHp * (oldCurrentHp / oldMaxHp))));
    }
    normalized.maxHp = maxHp;
    normalized.moves = effectiveMoves(normalized, options);
    if (!normalized.statusCondition) normalized.statusCondition = "NONE";
    resetBattleState(normalized);
    return normalized;
}

export function typeEffectiveness(moveType, defenderTypes) {
    const chart = TYPE_CHART[cleanId(moveType)] || {};
    let multiplier = 1;
    for (const type of defenderTypes || ["normal"]) {
        const cleanType = cleanId(type);
        multiplier *= chart[cleanType] ?? 1;
    }
    return multiplier;
}

function rollMoveHitCount(move, attacker, random = Math.random) {
    if (Array.isArray(move.multihit)) {
        const minimum = Math.max(1, Number(move.multihit[0]) || 1);
        const maximum = Math.max(minimum, Number(move.multihit[1]) || minimum);
        if (cleanId(attacker?.ability).replace(/[^a-z0-9]/g, "") === "skilllink") return maximum;
        if (minimum === 2 && maximum === 5) {
            const roll = random();
            return roll < 0.35 ? 2 : roll < 0.70 ? 3 : roll < 0.85 ? 4 : 5;
        }
        return minimum + Math.floor(random() * (maximum - minimum + 1));
    }
    return Math.max(1, Math.floor(Number(move.multihit) || 1));
}

function damageResult(hitResults, effectiveness = 1, stab = false, extra = {}) {
    return {
        damage: hitResults.reduce((total, hit) => total + hit.damage, 0),
        effectiveness,
        critical: hitResults.some(hit => hit.critical),
        hits: hitResults.length,
        hitResults,
        stab,
        berryResistTriggered: hitResults.some(hit => hit.berryResistTriggered),
        consumedBerry: hitResults.find(hit => hit.consumedBerry)?.consumedBerry,
        ...extra
    };
}

function fixedCallbackDamage(attacker, defender, move, effectiveness, random) {
    const state = attacker?.battleState || {};
    let damage;
    if (move.id === "counter") {
        if (state.lastDamageCategory !== "physical" || Number(state.lastDamageTaken) <= 0) return { damage: 0, failed: true };
        damage = Number(state.lastDamageTaken) * 2;
    } else if (move.id === "mirrorcoat") {
        if (state.lastDamageCategory !== "special" || Number(state.lastDamageTaken) <= 0) return { damage: 0, failed: true };
        damage = Number(state.lastDamageTaken) * 2;
    } else if (move.id === "endeavor") {
        damage = Math.max(0, Number(defender?.currentHp) - Number(attacker?.currentHp));
        if (damage <= 0) return { damage: 0, failed: true };
    } else if (move.id === "finalgambit") {
        damage = Math.max(0, Number(attacker?.currentHp) || 0);
    } else if (move.id === "psywave") {
        damage = Math.max(1, Math.floor((Number(attacker?.level) || 1) * (0.5 + random())));
    } else if (move.id === "superfang") {
        damage = Math.max(1, Math.floor((Number(defender?.currentHp) || 1) / 2));
    } else {
        return undefined;
    }
    return { damage: effectiveness === 0 ? 0 : Math.floor(damage), failed: false };
}

function callbackPower(attacker, defender, move, random) {
    const attackerStats = battleStats(attacker);
    const defenderStats = battleStats(defender);
    if (["flail", "reversal"].includes(move.id)) {
        const ratio = Math.floor(48 * Math.max(0, Number(attacker?.currentHp) || 0) / Math.max(1, Number(attacker?.maxHp) || 1));
        return { power: ratio <= 1 ? 200 : ratio <= 4 ? 150 : ratio <= 9 ? 100 : ratio <= 16 ? 80 : ratio <= 32 ? 40 : 20 };
    }
    if (move.id === "electroball") {
        const ratio = attackerStats.speed / Math.max(1, defenderStats.speed);
        return { power: ratio >= 4 ? 150 : ratio >= 3 ? 120 : ratio >= 2 ? 80 : ratio >= 1 ? 60 : 40 };
    }
    if (move.id === "gyroball") return { power: Math.min(150, Math.floor(25 * defenderStats.speed / Math.max(1, attackerStats.speed)) + 1) };
    if (move.id === "heavyslam") {
        const ratio = speciesWeight(attacker) / Math.max(1, speciesWeight(defender));
        return { power: ratio >= 5 ? 120 : ratio >= 4 ? 100 : ratio >= 3 ? 80 : ratio >= 2 ? 60 : 40 };
    }
    if (move.id === "lowkick") {
        const weight = speciesWeight(defender);
        return { power: weight < 100 ? 20 : weight < 250 ? 40 : weight < 500 ? 60 : weight < 1000 ? 80 : weight < 2000 ? 100 : 120 };
    }
    if (move.id === "magnitude") {
        const roll = random();
        const magnitude = roll < 0.05 ? 4 : roll < 0.15 ? 5 : roll < 0.35 ? 6 : roll < 0.65 ? 7 : roll < 0.85 ? 8 : roll < 0.95 ? 9 : 10;
        return { power: ({ 4: 10, 5: 30, 6: 50, 7: 70, 8: 90, 9: 110, 10: 150 })[magnitude], magnitude };
    }
    if (move.id === "punishment") {
        const boosts = Object.values(defender?.battleState?.stages || {}).reduce((total, stage) => total + Math.max(0, Number(stage) || 0), 0);
        return { power: Math.min(200, 60 + boosts * 20) };
    }
    if (move.id === "trumpcard") {
        const pp = Number(attacker?.moves?.find(candidate => candidate.id === move.id)?.pp);
        return { power: pp <= 0 ? 200 : pp === 1 ? 80 : pp === 2 ? 60 : pp === 3 ? 50 : 40 };
    }
    if (move.id === "wringout") {
        return { power: Math.max(1, Math.floor(120 * Math.max(0, Number(defender?.currentHp) || 0) / Math.max(1, Number(defender?.maxHp) || 1)) + 1) };
    }
    if (move.id === "spitup") return { power: Math.max(0, Number(attacker?.battleState?.stockpile) || 0) * 100 };
    if (move.doublePowerIfTargetStatus
        && String(defender?.statusCondition || "NONE").toLowerCase() !== "none") {
        return { power: (Number(move.power) || 0) * 2 };
    }
    return { power: Number(move.power) || 0 };
}

export function calculateDamage(attacker, defender, moveId, options = {}) {
    const sourceMove = moveData(moveId);
    const move = { ...sourceMove, type: specialMoveType(attacker, sourceMove.id, sourceMove.type) };
    const random = typeof options.random === "function" ? options.random : Math.random;
    const defenderTypes = pokemonTypes(defender);
    const groundedTypes = move.type === "ground" && defender?.battleState?.smackDown ? defenderTypes.filter(type => type !== "flying") : defenderTypes;
    let effectiveness = typeEffectiveness(move.type, groundedTypes.length ? groundedTypes : ["normal"]);
    if (defender?.battleState?.foresight && ["normal", "fighting"].includes(move.type) && defenderTypes.includes("ghost")) {
        effectiveness = typeEffectiveness(move.type, defenderTypes.filter(type => type !== "ghost"));
    }
    if (defender?.battleState?.miracleEye && move.type === "psychic" && defenderTypes.includes("dark")) {
        effectiveness = typeEffectiveness(move.type, defenderTypes.filter(type => type !== "dark"));
    }
    if (move.type === "ground" && defender?.battleState?.magnetRiseTurns > 0 && !defender?.battleState?.smackDown) effectiveness = 0;
    if (move.id === "skydrop" && (defenderTypes.includes("flying") || speciesWeight(defender) >= 2000)) {
        return damageResult([{ damage: 0, critical: false }], defenderTypes.includes("flying") ? 0 : effectiveness, false, { failed: true });
    }
    if (move.ohko) {
        const succeeds = Number(attacker?.level) >= Number(defender?.level) && random() * 100 < Math.max(1, 30 + Number(attacker?.level) - Number(defender?.level));
        const hitResults = [{ damage: succeeds && effectiveness > 0 ? Math.max(1, Number(defender?.currentHp) || 1) : 0, critical: false }];
        return damageResult(hitResults, effectiveness, false, { ohkoFailed: !succeeds && effectiveness > 0 });
    }
    const hits = rollMoveHitCount(move, attacker, random);
    const callbackDamage = fixedCallbackDamage(attacker, defender, move, effectiveness, random);
    if (callbackDamage) {
        const hitDamage = callbackDamage.failed ? 0 : callbackDamage.damage;
        return damageResult([{ damage: hitDamage, critical: false }], effectiveness, false, { failed: callbackDamage.failed });
    }
    if (move.fixedDamage === "level") {
        const hitDamage = effectiveness === 0 ? 0 : Math.max(1, Number(attacker?.level) || 1);
        return damageResult(Array.from({ length: hits }, () => ({ damage: hitDamage, critical: false })), effectiveness);
    }
    if (Number.isFinite(Number(move.fixedDamage))) {
        const hitDamage = effectiveness === 0 ? 0 : Math.max(1, Number(move.fixedDamage));
        return damageResult(Array.from({ length: hits }, () => ({ damage: hitDamage, critical: false })), effectiveness);
    }
    const powerResult = callbackPower(attacker, defender, move, random);
    const dynamicPower = powerResult.power;
    if (move.category === "status" || dynamicPower <= 0) {
        return damageResult([{ damage: 0, critical: false }], move.ignoreImmunity === false ? effectiveness : 1);
    }

    const attackerStats = battleStats(attacker);
    const defenderStats = battleStats(defender);
    const attackKey = move.category === "special" ? "specialAttack" : "attack";
    const defenseKey = move.category === "special" ? "specialDefence" : "defence";
    const level = Math.max(1, Math.floor(Number(attacker?.level) || 1));
    const stab = pokemonTypes(attacker).includes(cleanId(move.type));

    let berryAlreadyConsumed = false;
    const hitResults = Array.from({ length: hits }, (_, hitIndex) => {
        const criticalStage = Math.max(0, (Number(move.critRatio) || 1) - 1 + (attacker?.battleState?.focusEnergy ? 2 : 0));
        const criticalChances = [1 / 24, 1 / 8, 1 / 2, 1];
        const critical = options.critical ?? (move.willCrit === true || random() < criticalChances[Math.min(3, criticalStage)]);
        const attackStage = statStage(attacker, move.category === "special" ? "spa" : "atk");
        const defenseStage = statStage(defender, move.category === "special" ? "spd" : "def");
        let attackStat = critical && attackStage < 0 ? calculateStat(attacker, attackKey) : attackerStats[attackKey];
        const defenseStat = critical && defenseStage > 0 ? calculateStat(defender, defenseKey) : defenderStats[defenseKey];
        if (move.category === "physical" && String(attacker?.statusCondition || "").toLowerCase() === "brn" && move.id !== "facade") {
            attackStat = Math.max(1, Math.floor(attackStat / 2));
        }
        const base = Math.floor(Math.floor(Math.floor(((2 * level / 5 + 2) * dynamicPower * attackStat) / Math.max(1, defenseStat)) / 50) + 2);
        const randomModifier = options.randomModifier ?? ((Math.floor(random() * 16) + 85) / 100);
        let fieldModifier = 1;
        const weather = String(options.weather || "").toLowerCase();
        const terrain = String(options.terrain || "").toLowerCase();
        if (["raindance", "rain"].includes(weather)) fieldModifier *= move.type === "water" ? 1.5 : move.type === "fire" ? 0.5 : 1;
        if (["sunnyday", "sun"].includes(weather)) fieldModifier *= move.type === "fire" ? 1.5 : move.type === "water" ? 0.5 : 1;
        if (terrain === "electricterrain" && move.type === "electric" && isGrounded(attacker)) fieldModifier *= 1.3;
        if (terrain === "grassyterrain" && move.type === "grass" && isGrounded(attacker)) fieldModifier *= 1.3;
        if (terrain === "grassyterrain" && ["bulldoze", "earthquake", "magnitude"].includes(move.id) && isGrounded(defender)) fieldModifier *= 0.5;
        if (options.reflect && move.category === "physical" && !critical) fieldModifier *= 0.5;
        if (options.lightScreen && move.category === "special" && !critical) fieldModifier *= 0.5;
        if (attacker?.battleState?.charge && move.type === "electric") fieldModifier *= 2;
        if (weather === "sandstorm" && move.category === "special" && defenderTypes.includes("rock")) fieldModifier /= 1.5;
        if (weather === "snow" && move.category === "physical" && defenderTypes.includes("ice")) fieldModifier /= 1.5;
        if ((options.semiInvulnerable === "dig" && ["earthquake", "magnitude"].includes(move.id))
            || (options.semiInvulnerable === "dive" && ["surf", "whirlpool"].includes(move.id))) fieldModifier *= 2;
        fieldModifier *= specialHeldItemDamageMultiplier(attacker, move.type);

        const defenderHeld = String(defender?.heldItem || "").replace(/^.*:/, "").toLowerCase();
        const resistType = TYPE_RESIST_BERRIES[defenderHeld];
        let berryResistTriggered = false;
        if (!berryAlreadyConsumed && resistType && resistType === cleanId(move.type)) {
            if (resistType === "normal" || effectiveness > 1) {
                fieldModifier *= 0.5;
                berryResistTriggered = true;
                berryAlreadyConsumed = true;
            }
        }

        const modifier = randomModifier * (stab ? 1.5 : 1) * effectiveness * (critical ? 1.5 : 1) * fieldModifier;
        const damage = effectiveness === 0 ? 0 : Math.max(1, Math.floor(base * modifier));
        return { damage, critical, berryResistTriggered, consumedBerry: berryResistTriggered ? defenderHeld : undefined };
    });
    return damageResult(hitResults, effectiveness, stab, powerResult.magnitude ? { magnitude: powerResult.magnitude } : {});
}

export function calculateConfusionDamage(pokemon, options = {}) {
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const stats = battleStats(pokemon);
    let attack = stats.attack;
    if (String(pokemon?.statusCondition || "").toLowerCase() === "brn") attack = Math.max(1, Math.floor(attack / 2));
    const base = Math.floor(Math.floor(Math.floor(((2 * level / 5 + 2) * 40 * attack) / Math.max(1, stats.defence)) / 50) + 2);
    const random = typeof options.random === "function" ? options.random : Math.random;
    const randomModifier = options.randomModifier ?? ((Math.floor(random() * 16) + 85) / 100);
    return Math.max(1, Math.floor(base * randomModifier));
}

export function formatPokemonName(pokemon) {
    const data = speciesData(pokemon);
    const fallback = speciesKey(pokemon) || "pokemon";
    return pokemon?.nickname || data?.name || fallback.charAt(0).toUpperCase() + fallback.slice(1);
}
