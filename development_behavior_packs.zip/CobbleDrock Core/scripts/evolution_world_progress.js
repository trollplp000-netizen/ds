import { system, world } from "@minecraft/server";
import { loadPartyFromPlayer, loadPokemonFromEntity, savePartyToPlayer, savePokemonToEntity } from "./storage.js";
import { recordEvolutionProgress } from "./evolution_progress.js";

const previous = new Map();
system.runInterval(() => {
    const seen = new Set();
    const entitiesByDimension = new Map();
    const getPartyEntities = dimension => {
        const dimensionId = dimension?.id;
        if (entitiesByDimension.has(dimensionId)) return entitiesByDimension.get(dimensionId);
        let entities = [];
        try {
            entities = dimension.getEntities({ tags: ["lota:party_pokemon"] });
        } catch (error) {}
        entitiesByDimension.set(dimensionId, entities);
        return entities;
    };
    for (const player of world.getAllPlayers()) {
        if (player.hasTag("lota:battle_player")) continue;
        const party = loadPartyFromPlayer(player);
        let changed = false;
        for (const entity of getPartyEntities(player.dimension)) {
            try {
                if (entity.getDynamicProperty("lota:party_owner_id") !== player.id) continue;
                const uuid = loadPokemonFromEntity(entity)?.uuid;
                const pokemon = party.find(p => p.uuid === uuid);
                if (!pokemon || Number(pokemon.currentHp) <= 0) continue;
                seen.add(entity.id);
                const location = entity.location;
                const last = previous.get(entity.id);
                previous.set(entity.id, { ...location, dimension: entity.dimension.id });
                if (!last || last.dimension !== entity.dimension.id || entity.hasTag("lota:shoulder_mounted")
                    || entity.getComponent("minecraft:rideable")?.getRiders().length || !entity.isOnGround) continue;
                const distance = Math.hypot(location.x - last.x, location.y - last.y, location.z - last.z);
                if (!(distance > 0 && distance <= 6)) continue;
                recordEvolutionProgress(pokemon, "blocks_traveled", distance);
                savePokemonToEntity(entity, pokemon);
                changed = true;
            } catch (error) {}
        }
        if (changed) savePartyToPlayer(player, party);
    }
    for (const id of previous.keys()) if (!seen.has(id)) previous.delete(id);
}, 10);

