const PLATFORM_ENTITY_TYPE = "lota:water_platform";
const PLATFORM_SIZE_PROPERTY = "lota:platform_size";
const PLATFORM_ANCHOR_OFFSET_Y = 0.25;

const PLATFORM_SIZE = Object.freeze({
    xs: 0,
    s: 1,
    m: 2,
    l: 3,
    xl: 4
});

const activePlatforms = new Map();

function isValidEntity(entity) {
    try {
        return !!entity && entity.isValid;
    } catch (error) {
        return false;
    }
}

function isWaterBlock(block) {
    if (!block) return false;
    try {
        const typeId = String(block.typeId || "");
        if (typeId === "minecraft:water") return true;
        if (block.isLiquid === true && typeId.includes("water")) return true;
    } catch (error) {}
    return false;
}

function platformSizeForWidth(width) {
    const value = Number(width);
    if (!Number.isFinite(value) || value < 0.5) return PLATFORM_SIZE.xs;
    if (value < 1.0) return PLATFORM_SIZE.s;
    if (value < 2.0) return PLATFORM_SIZE.m;
    if (value < 3.5) return PLATFORM_SIZE.l;
    return PLATFORM_SIZE.xl;
}

const WATER_SURFACE_SCAN_LIMIT = 32;

function getBlockSafe(dimension, x, y, z) {
    try {
        return dimension.getBlock({ x, y, z });
    } catch (error) {
        return undefined;
    }
}

function isAirBlock(block) {
    if (!block) return false;
    try {
        if (block.isAir === true) return true;
        return String(block.typeId || "").endsWith(":air");
    } catch (error) {}
    return false;
}

function findWaterSurfaceY(dimension, x, startY, z) {
    let y = Math.floor(startY);
    const block = getBlockSafe(dimension, x, y, z);

    if (isWaterBlock(block)) {
        for (let i = 0; i < WATER_SURFACE_SCAN_LIMIT; i++) {
            const above = getBlockSafe(dimension, x, y + 1, z);
            if (!isWaterBlock(above)) return y;
            y++;
        }
        return y;
    }

    if (isAirBlock(block)) {
        for (let i = 0; i < WATER_SURFACE_SCAN_LIMIT; i++) {
            y--;
            const below = getBlockSafe(dimension, x, y, z);
            if (isWaterBlock(below)) return y;
            if (!isAirBlock(below)) return null;
        }
        return null;
    }

    y++;
    const aboveStart = getBlockSafe(dimension, x, y, z);
    if (isWaterBlock(aboveStart)) {
        for (let i = 0; i < WATER_SURFACE_SCAN_LIMIT; i++) {
            const above = getBlockSafe(dimension, x, y + 1, z);
            if (!isWaterBlock(above)) return y;
            y++;
        }
        return y;
    }

    return null;
}

function teleportPlatform(platform, location) {
    try {
        if (typeof platform.tryTeleport === "function") {
            platform.tryTeleport(location, { dimension: platform.dimension, keepVelocity: false });
        } else {
            platform.teleport(location);
        }
    } catch (error) {}
}

export function releaseWaterPlatform(entityId) {
    if (!entityId) return;
    const platform = activePlatforms.get(entityId);
    activePlatforms.delete(entityId);
    if (isValidEntity(platform)) {
        try { platform.remove(); } catch (error) {}
    }
}

export function releaseAllWaterPlatforms() {
    for (const entityId of Array.from(activePlatforms.keys())) releaseWaterPlatform(entityId);
}

function resolveWaterSurfaceY(entity, anchor) {
    if (!isValidEntity(entity) || !anchor) return null;
    try {
        return findWaterSurfaceY(
            entity.dimension,
            Math.floor(anchor.x),
            Math.floor(anchor.y) - 1,
            Math.floor(anchor.z)
        );
    } catch (error) {
        return null;
    }
}

export function getWaterSurfaceAnchor(entity, anchor) {
    const surfaceY = resolveWaterSurfaceY(entity, anchor);
    if (surfaceY === null) return null;
    return { x: anchor.x, y: surfaceY + 1 + PLATFORM_ANCHOR_OFFSET_Y, z: anchor.z };
}

export function applyWaterPlatformAnchor(entity, anchor, width) {
    const surfaceY = resolveWaterSurfaceY(entity, anchor);

    if (surfaceY === null) {
        releaseWaterPlatform(entity.id);
        return null;
    }

    const restY = surfaceY + 1;

    const size = platformSizeForWidth(width);
    const platformLocation = { x: anchor.x, y: restY, z: anchor.z };
    let platform = activePlatforms.get(entity.id);

    if (!isValidEntity(platform)) {
        try {
            platform = entity.dimension.spawnEntity(PLATFORM_ENTITY_TYPE, platformLocation);
        } catch (error) {
            return null;
        }
        activePlatforms.set(entity.id, platform);
    } else {
        teleportPlatform(platform, platformLocation);
    }

    try { platform.setProperty(PLATFORM_SIZE_PROPERTY, size); } catch (error) {}

    return { x: anchor.x, y: restY + PLATFORM_ANCHOR_OFFSET_Y, z: anchor.z };
}
