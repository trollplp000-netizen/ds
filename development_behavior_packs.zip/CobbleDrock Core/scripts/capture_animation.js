import { MolangVariableMap, system } from "@minecraft/server";

export const CAPTURE_MOTION_TIMING = Object.freeze({
    OPEN_TICK: 4,
    RECALL_TICK: 14,
    ABSORB_TICK: 26,
    SHUT_TICK: 39,
    FALL_TICK: 44,
    SETTLE_TICK: 60,
    FIRST_ROLL_TICK: 64,
    ROLL_INTERVAL_TICKS: 25,
    SUCCESS_DURATION_TICKS: 15,
    BREAK_DURATION_TICKS: 24
});

const SHAKE_ANIMATIONS = Object.freeze([
    "animation.poke_ball.bob1",
    "animation.poke_ball.bob2",
    "animation.poke_ball.bob3",
    "animation.poke_ball.bob4",
    "animation.poke_ball.bob5",
    "animation.poke_ball.bob6"
]);

function isAncientBallType(ballType) {
    const type = Number(ballType) || 1;
    return type === 15 || (type >= 34 && type <= 47);
}

function validEntity(entity) {
    try {
        return !!entity?.isValid;
    } catch (error) {
        return false;
    }
}

function copyLocation(location) {
    return {
        x: Number(location?.x) || 0,
        y: Number(location?.y) || 0,
        z: Number(location?.z) || 0
    };
}

function entityCenter(entity, fallback) {
    if (!validEntity(entity)) return copyLocation(fallback);
    try {
        const feet = entity.location;
        const head = entity.getHeadLocation();
        return {
            x: (feet.x + head.x) * 0.5,
            y: feet.y + (head.y - feet.y) * 0.52,
            z: (feet.z + head.z) * 0.5
        };
    } catch (error) {
        return copyLocation(fallback || entity.location);
    }
}

function ballBeamPoint(ball, fallback) {
    const location = validEntity(ball) ? ball.location : fallback;
    return {
        x: Number(location?.x) || 0,
        y: (Number(location?.y) || 0) + 0.16,
        z: Number(location?.z) || 0
    };
}

function rotateMinecraftY(vector, angle) {
    return {
        x: vector.x * Math.cos(angle) + vector.z * Math.sin(angle),
        z: vector.z * Math.cos(angle) - vector.x * Math.sin(angle)
    };
}

function horizontalRecoilDirection(projectile, target, thrower) {
    let incomingX = 0;
    let incomingZ = 0;
    try {
        const velocity = validEntity(projectile) ? projectile.getVelocity() : undefined;
        incomingX = Number(velocity?.x) || 0;
        incomingZ = Number(velocity?.z) || 0;
    } catch (error) {}

    if (Math.hypot(incomingX, incomingZ) < 0.01 && validEntity(thrower)) {
        try {
            incomingX = target.location.x - thrower.location.x;
            incomingZ = target.location.z - thrower.location.z;
        } catch (error) {}
    }
    if (Math.hypot(incomingX, incomingZ) < 0.01) {
        try {
            const view = thrower?.getViewDirection();
            incomingX = Number(view?.x) || 0;
            incomingZ = Number(view?.z) || 0;
        } catch (error) {}
    }
    const length = Math.hypot(incomingX, incomingZ);
    if (length < 0.01) {
        incomingX = 0;
        incomingZ = 1;
    } else {
        incomingX /= length;
        incomingZ /= length;
    }

    const reverse = { x: -incomingX, z: -incomingZ };
    return rotateMinecraftY(reverse, -Math.PI / 3);
}

function setBallFacing(ball, target) {
    if (!validEntity(ball) || !target) return;
    try {
        const location = ball.location;
        const dx = target.x - location.x;
        const dz = target.z - location.z;
        if (Math.hypot(dx, dz) < 0.01) return;
        ball.setRotation({
            x: 0,
            y: Math.atan2(-dx, dz) * 180 / Math.PI
        });
    } catch (error) {}
}

function playSound(dimension, soundId, location, options = {}) {
    try {
        dimension.playSound(soundId, location, {
            volume: Number(options.volume) || 1,
            pitch: Number(options.pitch) || 1
        });
    } catch (error) {}
}

function playAnimation(entity, animation, controller, blendOutTime = 0) {
    if (!validEntity(entity)) return false;
    try {
        entity.playAnimation(animation, { controller, blendOutTime });
        return true;
    } catch (error) {
        return false;
    }
}

function spawnParticle(dimension, particleId, location, variables) {
    try {
        dimension.spawnParticle(particleId, location, variables);
        return true;
    } catch (error) {
        return false;
    }
}

function resolveBeamPoint(point, fallback) {
    try {
        return copyLocation(typeof point === "function" ? point() : point);
    } catch (error) {
        return copyLocation(fallback);
    }
}

function emitBeamSegments(dimension, from, to) {
    const start = copyLocation(from);
    const end = copyLocation(to);
    const delta = {
        x: end.x - start.x,
        y: end.y - start.y,
        z: end.z - start.z
    };
    const distance = Math.hypot(delta.x, delta.y, delta.z);
    if (distance < 0.04) return;
    const segmentCount = Math.max(4, Math.min(120, Math.ceil(distance * 8)));
    for (let index = 0; index <= segmentCount; index++) {
        const ratio = index / segmentCount;
        spawnParticle(dimension, "lota:capture_recall_beam_segment", {
            x: start.x + delta.x * ratio,
            y: start.y + delta.y * ratio,
            z: start.z + delta.z * ratio
        });
    }
}

function spawnBeam(dimension, from, to, durationTicks = 12) {
    const initialStart = resolveBeamPoint(from);
    const initialEnd = resolveBeamPoint(to, initialStart);
    emitBeamSegments(dimension, initialStart, initialEnd);

    try {
        const variables = new MolangVariableMap();
        variables.setVector3("variable.target_delta", {
            x: initialEnd.x - initialStart.x,
            y: initialEnd.y - initialStart.y,
            z: initialEnd.z - initialStart.z
        });
        spawnParticle(dimension, "lota:capture_recall_motes", initialStart, variables);
    } catch (error) {}

    let elapsed = 0;
    const beamRun = system.runInterval(() => {
        elapsed += 2;
        if (elapsed > durationTicks) {
            system.clearRun(beamRun);
            return;
        }
        const start = resolveBeamPoint(from, initialStart);
        const end = resolveBeamPoint(to, initialEnd);
        emitBeamSegments(dimension, start, end);
    }, 2);
}

const RECALL_TO_TRAINER_DURATION_TICKS = 12;

function trainerHandPoint(player) {
    if (!validEntity(player)) return { x: 0, y: 0, z: 0 };
    try {
        const view = player.getViewDirection();
        const head = player.getHeadLocation();
        const rightX = -view.z;
        const rightZ = view.x;
        const rightLength = Math.hypot(rightX, rightZ) || 1;
        const right = { x: rightX / rightLength, z: rightZ / rightLength };
        return {
            x: head.x + view.x * 0.3 + right.x * 0.45,
            y: head.y - 0.6,
            z: head.z + view.z * 0.3 + right.z * 0.45
        };
    } catch (error) {
        return copyLocation(player.location);
    }
}

export function playRecallToTrainerMotion(options) {
    const player = options?.player;
    const target = options?.target;
    const dimension = options?.dimension || target?.dimension;
    if (!dimension || !validEntity(target) || !validEntity(player)) return false;

    const targetOrigin = copyLocation(target.location);
    let cancelled = false;

    const holdRun = system.runInterval(() => {
        if (cancelled || !validEntity(target)) {
            system.clearRun(holdRun);
            return;
        }
        try {
            target.clearVelocity();
            target.teleport(targetOrigin);
        } catch (error) {}
    }, 1);

    playAnimation(target, "animation.lota.capture_recall", "controller.animation.lota.capture_transition", 0);
    playSound(dimension, "lota.capture.poke_ball_recall", targetOrigin, { volume: 0.6 });
    spawnBeam(
        dimension,
        () => entityCenter(target, targetOrigin),
        () => trainerHandPoint(player),
        RECALL_TO_TRAINER_DURATION_TICKS
    );

    system.runTimeout(() => {
        cancelled = true;
        system.clearRun(holdRun);
        try {
            if (typeof options?.onAbsorbed === "function") options.onAbsorbed(target);
        } catch (error) {
            console.warn(`Recall-to-trainer callback failed: ${error}`);
        }
    }, RECALL_TO_TRAINER_DURATION_TICKS);

    return true;
}

function setBallPose(ball, pose) {
    try {
        if (validEntity(ball)) ball.setProperty("lota:capture_pose", pose);
    } catch (error) {}
}

function breakoutDestination(resultLocation, targetOrigin, recoilDirection) {
    const destination = copyLocation(targetOrigin);
    const distance = Math.hypot(destination.x - resultLocation.x, destination.z - resultLocation.z);
    if (distance < 0.9) {
        destination.x = resultLocation.x - recoilDirection.x * 1.15;
        destination.z = resultLocation.z - recoilDirection.z * 1.15;
    }
    return destination;
}

function animateBreakout(entity, start, destination, onComplete) {
    const totalTicks = 8;
    let elapsed = 0;
    const breakoutRun = system.runInterval(() => {
        elapsed += 1;
        if (!validEntity(entity)) {
            system.clearRun(breakoutRun);
            if (typeof onComplete === "function") onComplete(undefined, destination);
            return;
        }
        const linear = Math.min(1, elapsed / totalTicks);
        const eased = 1 - (1 - linear) * (1 - linear);
        const arc = Math.sin(Math.PI * linear) * 0.35;
        try {
            entity.clearVelocity();
            entity.teleport({
                x: start.x + (destination.x - start.x) * eased,
                y: start.y + (destination.y - start.y) * eased + arc,
                z: start.z + (destination.z - start.z) * eased
            });
        } catch (error) {}
        if (elapsed >= totalTicks) {
            system.clearRun(breakoutRun);
            if (typeof onComplete === "function") onComplete(entity, destination);
        }
    }, 1);
    return breakoutRun;
}

function animateBallRecoil(activeState, start, direction, facingTarget) {
    const totalTicks = CAPTURE_MOTION_TIMING.RECALL_TICK;
    let elapsed = 0;
    const position = copyLocation(start);
    const velocity = {
        x: direction.x * 0.1,
        y: 1 / 3,
        z: direction.z * 0.1
    };
    try { activeState.ball?.triggerEvent("lota:hold"); } catch (error) {}
    activeState.recoilRun = system.runInterval(() => {
        elapsed += 1;
        if (activeState.cancelled || !validEntity(activeState.ball)) {
            system.clearRun(activeState.recoilRun);
            activeState.recoilRun = undefined;
            return;
        }
        position.x += velocity.x;
        position.y += velocity.y;
        position.z += velocity.z;
        try {
            activeState.ball.clearVelocity();
            activeState.ball.teleport(position);
            setBallFacing(activeState.ball, facingTarget);
        } catch (error) {}
        velocity.x *= 0.99;
        velocity.y = velocity.y * 0.99 - 0.03;
        velocity.z *= 0.99;
        if (elapsed >= totalTicks) {
            system.clearRun(activeState.recoilRun);
            activeState.recoilRun = undefined;
        }
    }, 1);
}

function captureBallLanding(dimension, start, fallback) {
    try {
        const hit = dimension.getBlockFromRay(
            { x: start.x, y: start.y - 0.01, z: start.z },
            { x: 0, y: -1, z: 0 },
            { includeLiquidBlocks: false, includePassableBlocks: false, maxDistance: 16 }
        );
        if (hit?.block) {
            return {
                x: start.x,
                y: Math.min(start.y, hit.block.location.y + 1.001),
                z: start.z
            };
        }
    } catch (error) {}
    return {
        x: start.x,
        y: Math.min(start.y, Number(fallback?.y) || start.y),
        z: start.z
    };
}

function animateBallFall(activeState, dimension, fallback) {
    const start = ballLocation(activeState.ball, fallback);
    const destination = captureBallLanding(dimension, start, fallback);
    const totalTicks = 5;
    let elapsed = 0;
    activeState.fallRun = system.runInterval(() => {
        elapsed += 1;
        if (activeState.cancelled || !validEntity(activeState.ball)) {
            system.clearRun(activeState.fallRun);
            activeState.fallRun = undefined;
            return;
        }
        const progress = Math.min(1, elapsed / totalTicks);
        const gravityProgress = progress * progress;
        try {
            activeState.ball.clearVelocity();
            activeState.ball.teleport({
                x: start.x,
                y: start.y + (destination.y - start.y) * gravityProgress,
                z: start.z
            });
        } catch (error) {}
        if (elapsed >= totalTicks) {
            system.clearRun(activeState.fallRun);
            activeState.fallRun = undefined;
        }
    }, 1);
}

function removeEntity(entity) {
    try {
        if (validEntity(entity)) entity.remove();
    } catch (error) {}
}

function ballLocation(ball, fallback) {
    try {
        return validEntity(ball) ? copyLocation(ball.location) : copyLocation(fallback);
    } catch (error) {
        return copyLocation(fallback);
    }
}

function schedule(activeState, callback, ticks) {
    system.runTimeout(() => {
        if (activeState.cancelled) return;
        if (!activeState.isActive()) {
            activeState.cancelled = true;
            if (activeState.holdRun !== undefined) system.clearRun(activeState.holdRun);
            if (activeState.breakoutRun !== undefined) system.clearRun(activeState.breakoutRun);
            if (activeState.recoilRun !== undefined) system.clearRun(activeState.recoilRun);
            if (activeState.fallRun !== undefined) system.clearRun(activeState.fallRun);
            removeEntity(activeState.ball);
            return;
        }
        try {
            callback();
        } catch (error) {
            console.warn(`Capture motion callback failed: ${error}`);
        }
    }, ticks);
}

export function captureResultTick(outcome) {
    const caught = !!outcome?.caught;
    const visibleShakes = caught
        ? 3
        : Math.max(0, Math.min(3, Math.trunc(Number(outcome?.shakes) || 0)));
    return CAPTURE_MOTION_TIMING.FIRST_ROLL_TICK
        + visibleShakes * CAPTURE_MOTION_TIMING.ROLL_INTERVAL_TICKS;
}

export function playCaptureMotion(options) {
    const projectile = options?.projectile;
    const target = options?.target;
    const thrower = options?.thrower;
    const dimension = options?.dimension || target?.dimension || projectile?.dimension;
    if (!dimension || !validEntity(target)) return undefined;

    const targetOrigin = copyLocation(target.location);
    const initialTargetCenter = entityCenter(target, targetOrigin);
    const impactLocation = validEntity(projectile)
        ? copyLocation(projectile.location)
        : { ...initialTargetCenter };
    const outcome = options?.outcome || { caught: false, shakes: 0 };
    const recoilDirection = horizontalRecoilDirection(projectile, target, thrower);
    const visibleShakes = outcome.caught
        ? 3
        : Math.max(0, Math.min(3, Math.trunc(Number(outcome.shakes) || 0)));
    const activeState = {
        ball: undefined,
        cancelled: false,
        holdRun: undefined,
        breakoutRun: undefined,
        recoilRun: undefined,
        fallRun: undefined,
        isActive: typeof options?.isActive === "function" ? options.isActive : () => true
    };

    try {
        activeState.ball = dimension.spawnEntity("lota:poke_ball_capture", impactLocation);
        activeState.ball.setProperty("lota:ball_type", Math.max(1, Math.min(47, Number(options?.ballType) || 1)));
        setBallPose(activeState.ball, 1);
        activeState.ball.clearVelocity();
        activeState.ball.applyImpulse({
            x: recoilDirection.x * 0.1,
            y: 1 / 3,
            z: recoilDirection.z * 0.1
        });
        animateBallRecoil(activeState, impactLocation, recoilDirection, initialTargetCenter);
    } catch (error) {
        removeEntity(activeState.ball);
        activeState.ball = undefined;
    }

    playSound(dimension, "lota.capture.poke_ball_hit", impactLocation);
    playSound(dimension, "lota.capture.poke_ball_bounce", impactLocation);
    try { projectile?.addTag("lota:hit_processed"); } catch (error) {}
    try { projectile?.clearVelocity(); } catch (error) {}
    schedule(activeState, () => removeEntity(projectile), 4);

    activeState.holdRun = system.runInterval(() => {
        if (activeState.cancelled || !validEntity(target)) {
            system.clearRun(activeState.holdRun);
            activeState.holdRun = undefined;
            return;
        }
        try {
            target.clearVelocity();
            target.teleport(targetOrigin);
        } catch (error) {}
    }, 1);

    schedule(activeState, () => {
        setBallPose(activeState.ball, 2);
        playSound(dimension, "lota.capture.poke_ball_open", ballLocation(activeState.ball, impactLocation));
    }, CAPTURE_MOTION_TIMING.OPEN_TICK);

    schedule(activeState, () => {
        try { activeState.ball?.triggerEvent("lota:hold"); } catch (error) {}
        try { activeState.ball?.clearVelocity(); } catch (error) {}
        setBallPose(activeState.ball, 3);
        playAnimation(target, "animation.lota.capture_recall", "controller.animation.lota.capture_transition", 0);
        const targetCenter = entityCenter(target, initialTargetCenter);
        const beamPoint = ballBeamPoint(activeState.ball, impactLocation);
        setBallFacing(activeState.ball, targetCenter);
        spawnBeam(dimension, targetCenter, beamPoint);
        playSound(dimension, "lota.capture.poke_ball_recall", targetCenter, { volume: 0.6 });
    }, CAPTURE_MOTION_TIMING.RECALL_TICK);

    schedule(activeState, () => {
        if (activeState.holdRun !== undefined) system.clearRun(activeState.holdRun);
        activeState.holdRun = undefined;
        try {
            if (typeof options?.onAbsorbed === "function") options.onAbsorbed(target);
            else removeEntity(target);
        } catch (error) {
            removeEntity(target);
        }
    }, CAPTURE_MOTION_TIMING.ABSORB_TICK);

    schedule(activeState, () => {
        setBallPose(activeState.ball, 4);
        playSound(dimension, "lota.capture.poke_ball_shut", ballLocation(activeState.ball, impactLocation));
    }, CAPTURE_MOTION_TIMING.SHUT_TICK);

    schedule(activeState, () => {
        animateBallFall(activeState, dimension, targetOrigin);
    }, CAPTURE_MOTION_TIMING.FALL_TICK);

    schedule(activeState, () => {
        try { activeState.ball?.triggerEvent("lota:hold"); } catch (error) {}
        try { activeState.ball?.clearVelocity(); } catch (error) {}
        if (activeState.fallRun !== undefined) system.clearRun(activeState.fallRun);
        activeState.fallRun = undefined;
        setBallPose(activeState.ball, 4);
    }, CAPTURE_MOTION_TIMING.SETTLE_TICK);

    const ancientBall = isAncientBallType(options?.ballType);
    let lastShakeIndex = -1;
    for (let index = 0; index < visibleShakes; index++) {
        schedule(activeState, () => {
            let animationIndex = Math.floor(Math.random() * SHAKE_ANIMATIONS.length);
            if (ancientBall && animationIndex === lastShakeIndex) {
                animationIndex = (animationIndex + 1) % SHAKE_ANIMATIONS.length;
            }
            lastShakeIndex = animationIndex;
            setBallPose(activeState.ball, 5 + animationIndex);
            playSound(
                dimension,
                `lota.capture.poke_ball_shake_${(index % 4) + 1}`,
                ballLocation(activeState.ball, impactLocation)
            );
            if (!ancientBall) schedule(activeState, () => setBallPose(activeState.ball, 4), 20);
        }, CAPTURE_MOTION_TIMING.FIRST_ROLL_TICK + index * CAPTURE_MOTION_TIMING.ROLL_INTERVAL_TICKS);
    }

    const resultTick = captureResultTick(outcome);
    schedule(activeState, () => {
        const resultLocation = ballLocation(activeState.ball, targetOrigin);
        if (outcome.caught) {
            setBallPose(activeState.ball, 11);
            playSound(dimension, "lota.capture.poke_ball_capture_succeeded", resultLocation);
            spawnParticle(dimension, "lota:capture_sparks", resultLocation);
            spawnParticle(dimension, "lota:capture_star", resultLocation);
            schedule(activeState, () => {
                spawnParticle(dimension, "lota:capture_afterspark", resultLocation);
            }, 2);
            schedule(activeState, () => {
                removeEntity(activeState.ball);
                activeState.ball = undefined;
                activeState.cancelled = true;
                if (typeof options?.onCaught === "function") options.onCaught(resultLocation);
            }, CAPTURE_MOTION_TIMING.SUCCESS_DURATION_TICKS);
            return;
        }

        setBallPose(activeState.ball, 12);
        playSound(dimension, "lota.capture.poke_ball_break", resultLocation);
        const breakoutStart = { ...resultLocation, y: resultLocation.y + 0.08 };
        const destination = breakoutDestination(resultLocation, targetOrigin, recoilDirection);
        let restored;
        if (typeof options?.onBreakFree === "function") restored = options.onBreakFree(breakoutStart);
        const restoredCenter = entityCenter(restored, { ...breakoutStart, y: breakoutStart.y + 0.8 });
        playAnimation(restored, "animation.lota.capture_send_out", "controller.animation.lota.capture_transition", 0);
        spawnBeam(
            dimension,
            () => ballBeamPoint(activeState.ball, resultLocation),
            () => entityCenter(restored, restoredCenter),
            10
        );
        spawnParticle(dimension, "lota:capture_send_flash", restoredCenter);
        playSound(dimension, "lota.capture.poke_ball_send_out", restoredCenter);
        activeState.breakoutRun = animateBreakout(restored, breakoutStart, destination, (entity, endLocation) => {
            activeState.breakoutRun = undefined;
            if (typeof options?.onBreakFreeComplete === "function") {
                options.onBreakFreeComplete(entity, endLocation);
            }
        });
        schedule(activeState, () => {
            removeEntity(activeState.ball);
            activeState.ball = undefined;
            activeState.cancelled = true;
        }, CAPTURE_MOTION_TIMING.BREAK_DURATION_TICKS);
    }, resultTick);

    return activeState;
}
