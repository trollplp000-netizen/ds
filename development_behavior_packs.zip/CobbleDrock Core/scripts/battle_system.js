import { EasingType, HudElement, ItemStack, world, system } from "@minecraft/server";
import { buildBattleStatusActors, createBattleStatusVisuals } from "./battle_status_visuals.js";
import { recordEvolutionProgress, resetEvolutionBattleProgress } from "./evolution_progress.js";
import { ActionFormData } from "@minecraft/server-ui";
import { applyAlphaWildMight } from "./alpha_system.js";
import {
    applyCaptureBallEffects,
    calculateCaptureRate,
    captureBallCode,
    captureBallForProjectile,
    rollCaptureOutcome
} from "./capture_rate.js";
import {
    addPokemonToPlayerParty,
    generateRandomPokemon,
    loadPartyFromPlayer,
    loadPokemonFromEntity,
    savePartyToPlayer,
    savePokemonToEntity
} from "./storage.js";
import {
    battleStats,
    calculateDamage,
    calculateConfusionDamage,
    formatPokemonName,
    isGrounded,
    normalizePokemonForBattle,
    pokemonTypes,
    speciesData,
    speciesKey,
    typeEffectiveness
} from "./battle_math.js";
import { moveData, moveEffectChance } from "./move_registry.js";
import { moveDescription } from "./battle_move_descriptions.js";
import { applyBattleItemEffect, BATTLE_ITEMS } from "./battle_item_effects.js";
import { NATURE_LOWERED_STATS } from "./pokemon_item_effects.js";
import {
    CAPTURE_BALLS,
    markCaptureEncounter,
    markSpeciesCaptured
} from "./capture_rate.js";
import { BATTLE_EVENT, createMoveEventQueue } from "./battle_events.js";
import { publishServerWildBattleVictory } from "./server_content_events.js";
import {
    advanceBattleField,
    applyFieldResidual,
    applyEntryHazards,
    applyMoveFieldEffects,
    battleSideState,
    clearEntryHazards,
    createBattleField,
    damageFieldOptions,
    fieldEffectWouldFail,
    queueFutureMove,
    setSideEffect,
    speedFieldMultiplier
} from "./battle_field.js";
import {
    applyHitDamage,
    applyMoveFinalEffects,
    applyMoveHitEffects,
    applyResidualEffects,
    beforeMove,
    battleState,
    clearBattleState,
    forcedMoveId,
    isTrapped,
    moveSelectionFailure,
    prepareMoveState,
    resetBattleState,
    resetTurnDamage
} from "./battle_effects.js";
import {
    addPokemonExperience,
    battleExperienceParticipationMultiplier,
    calculateBattleExperience,
    normalizePokemonExperience
} from "./experience.js";
import { playCaptureMotion } from "./capture_animation.js";
import {
    playOriginalBattleMoveEffect,
    playOriginalPokemonBattleAnimation,
    playOriginalBattleStatChangeEffect
} from "./battle_visual_effects.js";
import { calculateFixedBattleCameraView } from "./battle_camera.js";
import { isOriginalFlyingType } from "./air_follow_math.js";
import { battlePositionCorrection, findBattleSurfaceAnchor } from "./battle_position.js";
import { applyWaterPlatformAnchor, getWaterSurfaceAnchor, releaseWaterPlatform } from "./water_platform.js";
import { clearHudTitleBase, clearHudTitleTransient, setHudTitleBase } from "./hud_title_bridge.js";
import { getEffectiveLevelCap } from "./level_cap.js";
import { pokemonFormTexture } from "./form_ui_textures.js";
import {
    applyMegaEvolution,
    battleEntityType,
    megaEvolutionFailure,
    revertMegaEvolution
} from "./mega_evolution.js";
import { identify } from "./identification.js";
import { storedRealNameTag } from "./pokemon_nametag_display.js";
import { applyPokemonSkinToEntity, publishPokemonAppearanceEvent } from "./pokemon_skin_api.js";

const COMPASS_ITEM = "lota:pokemon_compass";
const BATTLE_HUD_KEY = "battle";
const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";
const BATTLE_TAG = "lota:in_battle";
const PLAYER_BATTLE_TAG = "lota:battle_player";
const battleHudClearedSubscribers = new Set();

export function subscribeBattleHudCleared(callback) {
    if (typeof callback !== "function") return () => {};
    battleHudClearedSubscribers.add(callback);
    return () => battleHudClearedSubscribers.delete(callback);
}

function notifyBattleHudCleared(player) {
    for (const callback of battleHudClearedSubscribers) {
        try { callback(player); } catch (error) {}
    }
}

const BATTLE_AIM_HUD = Object.freeze([
    HudElement.Crosshair,
    HudElement.Hotbar,
    HudElement.ItemText,
    HudElement.ToolTips
]);

const PHASE = Object.freeze({
    none: 0,
    menu: 1,
    moves: 2,
    switch: 3,
    busy: 4
});

const MOVE_ID_VALUES = Object.freeze({
    none: 0,
    tackle: 1,
    scratch: 2,
    pound: 3,
    quickattack: 4,
    bite: 5,
    peck: 6,
    gust: 7,
    vinewhip: 8,
    ember: 9,
    watergun: 10,
    bubble: 11,
    thundershock: 12,
    confusion: 13,
    poisonsting: 14,
    struggle: 15
});

const BALL_ITEMS = new Set(Object.values(CAPTURE_BALLS).map(ball => ball.itemId));

const BATTLE_FORM_TITLE = Object.freeze({
    menu: "cobbledrock.battle.menu",
    moves: "cobbledrock.battle.moves",
    switch: "cobbledrock.battle.switch"
});
const LOG_CONTROL_LABELS = Object.freeze({
    up: "Log Up",
    down: "Log Down",
    toggle: "Battle Log"
});
const BATTLE_LOG_OPEN_TOKEN = "|BLOGOPEN|";
const BATTLE_FORM_BUSY_RETRY_LIMIT = 2;
const BATTLE_FORM_IDENTITY_BUTTON_START = 12;
const BATTLE_INSTANT_PANES = false;
const UNIFIED_TITLE_PREFIX = "cobbledrock.battle.u.";
const UNIFIED_BUTTON = Object.freeze({ log: 4, moves: 14, mega: 18, movesBack: 19, party: 20, switchBack: 26 });

function isUnifiedBattleForm(session) {
    if (!BATTLE_INSTANT_PANES || !session || session.raidBattle) return false;
    return session.phase === "menu" || session.phase === "moves"
        || (session.phase === "switch" && session.forceSwitch !== true);
}
const TYPE_LABELS = Object.freeze({
    normal: "NORMAL",
    fire: "FIRE",
    water: "WATER",
    electric: "ELECTRIC",
    grass: "GRASS",
    ice: "ICE",
    fighting: "FIGHTING",
    poison: "POISON",
    ground: "GROUND",
    flying: "FLYING",
    psychic: "PSYCHIC",
    bug: "BUG",
    rock: "ROCK",
    ghost: "GHOST",
    dragon: "DRAGON",
    dark: "DARK",
    steel: "STEEL",
    fairy: "FAIRY",
    typeless: "TYPELESS"
});
const CATEGORY_LABELS = Object.freeze({
    physical: "Physical",
    special: "Special",
    status: "Status"
});
const NAVIGATION_COOLDOWN_TICKS = 7;
const HUD_KEEPALIVE_TICKS = 20;
const BATTLE_CHOICE_DELAY_TICKS = 4;
const BATTLE_ACTION_DELAY_TICKS = 8;
const MULTI_HIT_DELAY_TICKS = 20;
const BATTLE_TURN_END_DELAY_TICKS = 4;
const BATTLE_MENU_DELAY_TICKS = 4;
const BATTLE_RESULT_DELAY_TICKS = 30;
const MEGA_MODEL_HIDE_TICKS = 20;
const MEGA_FORM_APPLY_TICKS = 126;
const MEGA_CRY_TICKS = 158;
const MEGA_BATTLE_RESUME_TICKS = 170;
const MEGA_EFFECT_SOUND = "lota.mega_evolution";
const WILD_BATTLE_FLEE_DISTANCE = 32;
const PLAYER_CHALLENGE_DISTANCE = 32;
const PLAYER_CHALLENGE_TIMEOUT_TICKS = 600;
const BATTLE_BASE_CLEARANCE = 4;
const BATTLE_POSITION_DRIFT_SQUARED = 0.25;
const BATTLE_ENTITY_SEARCH_INTERVAL_TICKS = 10;

const activeBattles = new Map();
const entityBattles = new Map();
const outgoingChallenges = new Map();
const incomingChallenges = new Map();
const battleStatusVisuals = createBattleStatusVisuals();
let nextChallengeId = 1;
let nextPlayerBattleId = 1;

function isValidEntity(entity) {
    try {
        return !!entity && entity.isValid;
    } catch (error) {
        return false;
    }
}

function isPokemonEntity(entity) {
    if (!isValidEntity(entity)) return false;
    const typeId = String(entity.typeId || "");
    return typeId.startsWith("lota:")
        && !typeId.endsWith("_projectile")
        && typeId !== "lota:poke_ball_capture"
        && !!speciesData(typeId);
}

function playerById(playerId) {
    for (const player of world.getAllPlayers()) {
        if (player.id === playerId) return player;
    }
    return undefined;
}

function selectedSlot(player, party) {
    const stored = Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY));
    if (Number.isInteger(stored) && stored >= 0 && stored < party.length) return stored;
    return 0;
}

function cleanMoveId(value) {
    return String(value || "").replace("cobblemon:", "").replace("lota:", "").toLowerCase();
}

function moveValue(moveId) {
    return MOVE_ID_VALUES[cleanMoveId(moveId)] || MOVE_ID_VALUES.none;
}

function hpNumber(value, fallback = 0) {
    return Math.max(0, Math.min(999, Math.floor(Number(value) || fallback)));
}

function hpText(pokemon) {
    return `${hpNumber(pokemon.currentHp)}/${Math.max(1, hpNumber(pokemon.maxHp, 1))}`;
}

function raidHealth(session) {
    const health = session?.raidBattle?.health;
    if (!health) return undefined;
    return {
        current: Math.max(0, Number(health.current) || 0),
        max: Math.max(1, Number(health.max) || 1),
        shield: health.shield === true
    };
}

function raidHpText(session) {
    const health = raidHealth(session);
    if (!health) return hpText(opponentPokemon(session));
    return `${Math.ceil(health.current)}/${Math.ceil(health.max)}`;
}

function raidHpStep(session) {
    const health = raidHealth(session);
    if (!health) return battleHpStep(opponentPokemon(session));
    const ratio = Math.max(0, Math.min(100, Math.round(health.current / health.max * 100)));
    return ratio <= 0 ? 0 : Math.max(1, Math.min(20, Math.ceil(ratio / 5)));
}

function hpRatio(pokemon) {
    const current = Math.max(0, Number(pokemon?.currentHp) || 0);
    const max = Math.max(1, Number(pokemon?.maxHp) || 1);
    return Math.max(0, Math.min(100, Math.round((current / max) * 100)));
}

function speciesDexNumber(pokemon) {
    return Math.max(0, Math.floor(Number(speciesData(pokemon)?.pokedex) || 0));
}

function setPlayerProperty(player, key, value) {
    try {
        player.setProperty(key, value);
    } catch (error) {}
}

function activePokemon(session) {
    return session.party[session.playerSlot];
}

function opponentSession(session) {
    if (session?.battleType !== "pvp") return undefined;
    return session.pvpBattle?.sessions?.find(candidate => candidate.playerId !== session.playerId);
}

function opponentPokemon(session) {
    return session?.battleType === "pvp"
        ? activePokemon(opponentSession(session))
        : session?.wildPokemon;
}

function battleStatusActors(session) {
    return buildBattleStatusActors(session, { activePokemon, resolveBattlePokemonEntity });
}

function syncBattleStatusVisuals(session) {
    if (!session) return;
    const current = activeBattles.get(session.playerId) === session;
    const ended = session.ending === true || session.pvpBattle?.ended === true;
    if (!current || ended) { battleStatusVisuals.clearSession(session); return; }
    battleStatusVisuals.syncSession(session, battleStatusActors(session), system.currentTick, { active: current, ended });
}

export function battleCaptureContext(player) {
    if (!player?.id) return undefined;
    const session = activeBattles.get(player.id);
    if (!session || session.battleType !== "wild" || !session.wildPokemon) return undefined;
    if (!isValidEntity(session.target)) return undefined;
    return {
        pokemon: session.wildPokemon,
        target: session.target,
        turn: Math.max(1, Math.floor(Number(session.turn) || 1))
    };
}

export function isBattleCaptureInProgress(target) {
    if (!isValidEntity(target)) return false;
    const playerId = entityBattles.get(target.id);
    return !!(playerId && activeBattles.get(playerId)?.captureInProgress);
}

function safeGetRotation(entity) {
    try {
        return entity?.getRotation?.();
    } catch (error) {
        return undefined;
    }
}

function baseEntityFocusLocation(entity) {
    if (!isValidEntity(entity)) return undefined;
    try {
        return entity.getHeadLocation();
    } catch (error) {
        const location = entity.location;
        if (!location) return undefined;
        return {
            x: Number(location.x) || 0,
            y: (Number(location.y) || 0) + (entity.typeId === "minecraft:player" ? 1.62 : 0.8),
            z: Number(location.z) || 0
        };
    }
}

function midpoint(first, second) {
    if (!first || !second) return first || second;
    return {
        x: (Number(first.x) + Number(second.x)) / 2,
        y: (Number(first.y) + Number(second.y)) / 2,
        z: (Number(first.z) + Number(second.z)) / 2
    };
}

function horizontalDirection(from, to, fallbackEntity) {
    let x = Number(to?.x) - Number(from?.x);
    let z = Number(to?.z) - Number(from?.z);
    let length = Math.hypot(x, z);
    if (length < 0.001) {
        try {
            const view = fallbackEntity.getViewDirection();
            x = Number(view.x) || 0;
            z = Number(view.z) || 1;
            length = Math.max(0.001, Math.hypot(x, z));
        } catch (error) {
            x = 0;
            z = 1;
            length = 1;
        }
    }
    return { x: x / length, z: z / length };
}

function battleEntityWidth(entity) {
    let width = 1;
    try {
        width = Number(entity.getComponent("minecraft:collision_box")?.width) || width;
    } catch (error) {}
    try {
        width *= Number(entity.getProperty("lota:scale_factor")) || 1;
    } catch (error) {}
    return Math.max(0.25, Math.min(6, width));
}

function minimumBattleSeparation(first, second) {
    return BATTLE_BASE_CLEARANCE + (battleEntityWidth(first) + battleEntityWidth(second)) / 2;
}

function setEntityFacing(entity, target, levelPitch = false) {
    if (!isValidEntity(entity) || !target) return;
    const origin = entityFocusLocation(entity);
    if (!origin) return;
    const dx = Number(target.x) - Number(origin.x);
    const dy = Number(target.y) - Number(origin.y);
    const dz = Number(target.z) - Number(origin.z);
    const horizontal = Math.max(0.001, Math.hypot(dx, dz));
    try {
        entity.setRotation({
            x: levelPitch ? 0 : -Math.atan2(dy, horizontal) * 180 / Math.PI,
            y: Math.atan2(-dx, dz) * 180 / Math.PI
        });
    } catch (error) {}
}

function partyPokemonUuid(entity) {
    try {
        return String(JSON.parse(String(entity.getDynamicProperty("lota:pokemon_data") || "{}"))?.uuid || "");
    } catch (error) {
        return "";
    }
}

function resolveBattlePokemonEntity(session) {
    const pokemon = activePokemon(session);
    const pokemonUuid = String(pokemon?.uuid || "");
    const cached = session.__battlePokemonEntity;
    if (isValidEntity(cached) && session.__battlePokemonUuid === pokemonUuid) return cached;

    const tick = Number(system.currentTick) || 0;
    if (Number(session.__nextBattleEntitySearchTick) > tick) return undefined;
    session.__nextBattleEntitySearchTick = tick + BATTLE_ENTITY_SEARCH_INTERVAL_TICKS;
    session.__battlePokemonEntity = undefined;
    session.__battlePokemonUuid = pokemonUuid;

    const player = playerById(session.playerId);
    if (!player) return undefined;
    let speciesFallback;
    try {
        for (const entity of player.dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            if (!isValidEntity(entity)) continue;
            if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== session.playerId) continue;
            if (pokemonUuid && partyPokemonUuid(entity) === pokemonUuid) {
                session.__battlePokemonEntity = entity;
                return entity;
            }
            if (!speciesFallback && entity.typeId === pokemon?.species) speciesFallback = entity;
        }
    } catch (error) {}
    session.__battlePokemonEntity = speciesFallback;
    return speciesFallback;
}

function spawnBattlePokemonEntity(session, location) {
    const pokemon = activePokemon(session);
    const player = playerById(session?.playerId);
    if (!pokemon?.species || !player || !location) return undefined;
    let entity;
    try {
        entity = player.dimension.spawnEntity(battleEntityType(pokemon), location);
        savePokemonToEntity(entity, pokemon);
        entity.addTag("lota:party_pokemon");
        entity.setDynamicProperty("lota:party_owner_id", session.playerId);
        entity.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0);
        applyPokemonSkinToEntity(entity, pokemon);
        entity.nameTag = `§f${formatPokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        publishPokemonAppearanceEvent("battle_spawned", session.playerId, pokemon, entity);
        session.__battlePokemonEntity = entity;
        session.__battlePokemonUuid = String(pokemon.uuid || "");
        if (!Array.isArray(session.__playerBattleEntities)) session.__playerBattleEntities = [];
        session.__playerBattleEntities.push(entity);
        delete session.__nextBattleEntitySearchTick;
        system.run(() => {
            if (!isValidEntity(entity)) return;
            try { entity.getComponent("minecraft:tameable")?.tame(player); } catch (error) {}
        });
        return entity;
    } catch (error) {
        try { entity?.remove(); } catch (cleanupError) {}
        console.warn(`Player battle Pokemon spawn failed: ${error}`);
        return undefined;
    }
}

function safeTeleport(entity, location) {
    if (!isValidEntity(entity) || !location) return false;
    try {
        if (typeof entity.tryTeleport === "function") {
            return entity.tryTeleport(location, {
                dimension: entity.dimension,
                keepVelocity: false
            }) !== false;
        }
        entity.teleport(location, {
            dimension: entity.dimension,
            keepVelocity: false
        });
        return true;
    } catch (error) {
        return false;
    }
}

function battleAnchorForEntity(entity, location) {
    if (!isValidEntity(entity) || !location || !isOriginalFlyingType(entity.typeId)) return { ...location };
    return findBattleSurfaceAnchor(entity.dimension, location);
}

function battleEntityMetrics(entity) {
    const location = entity.location;
    let width = 0.8;
    let height = 1;
    let measuredBounds = false;
    try {
        if (typeof entity.getAABB === "function") {
            const bounds = entity.getAABB();
            const extent = bounds?.extent;
            if (extent) {
                width = Math.max(Number(extent.x) || 0, Number(extent.z) || 0) * 2;
                height = (Number(extent.y) || 0) * 2;
                measuredBounds = width > 0 && height > 0;
            }
        }
    } catch (error) {}
    try {
        const head = entity.getHeadLocation();
        const headHeight = Number(head?.y) - Number(location?.y);
        if (Number.isFinite(headHeight) && headHeight > 0) height = Math.max(height, headHeight);
    } catch (error) {}
    if (!measuredBounds) {
        try {
            const collision = entity.getComponent("minecraft:collision_box");
            const collisionWidth = Number(collision?.width);
            const collisionHeight = Number(collision?.height);
            const hasCollisionWidth = Number.isFinite(collisionWidth) && collisionWidth > 0;
            const hasCollisionHeight = Number.isFinite(collisionHeight) && collisionHeight > 0;
            if (hasCollisionWidth) width = collisionWidth;
            if (hasCollisionHeight) height = collisionHeight;
            measuredBounds = hasCollisionWidth && hasCollisionHeight;
        } catch (error) {}
    }
    if (!measuredBounds) {
        try {
            const scale = Number(entity.getComponent("minecraft:scale")?.value);
            if (Number.isFinite(scale) && scale > 0) {
                width *= scale;
                height *= scale;
            }
        } catch (error) {}
    }
    width = Math.max(0.4, Math.min(6, width));
    height = Math.max(0.5, Math.min(10, height));
    return {
        width,
        height,
        radius: Math.max(0.5, Math.min(3, Math.max(width * 0.6, height * 0.35)))
    };
}

function entityFocusLocation(entity) {
    const base = baseEntityFocusLocation(entity);
    const metrics = battleEntityMetrics(entity);
    if (metrics.width <= 1.2 && metrics.height <= 1.8) return base;
    try {
        const head = entity.getHeadLocation();
        return {
            x: base.x,
            y: Math.max(base.y, Number(head?.y) || base.y),
            z: base.z
        };
    } catch (error) {
        return {
            x: base.x,
            y: Math.max(base.y, entity.location.y + metrics.height * 0.75),
            z: base.z
        };
    }
}

function expandBattleAnchorsForEntitySize(state) {
    if (!Array.isArray(state?.entities) || state.entities.length !== 2) return;
    const [first, second] = state.entities;
    const firstBase = first.baseAnchor || first.anchor;
    const secondBase = second.baseAnchor || second.anchor;
    if (!firstBase || !secondBase) return;
    const dx = secondBase.x - firstBase.x;
    const dz = secondBase.z - firstBase.z;
    const distance = Math.hypot(dx, dz);
    if (distance < 0.001) return;
    const extraDistance = Math.max(
        0,
        (Number(first.battleRadius) || 0.5) + (Number(second.battleRadius) || 0.5) - 1
    );
    const shift = extraDistance * 0.5;
    const nx = dx / distance;
    const nz = dz / distance;
    first.anchor = {
        ...firstBase,
        y: first.anchor.y,
        x: firstBase.x - nx * shift,
        z: firstBase.z - nz * shift
    };
    second.anchor = {
        ...secondBase,
        y: second.anchor.y,
        x: secondBase.x + nx * shift,
        z: secondBase.z + nz * shift
    };
}

function saveAndLockBattleEntity(session, entity, anchor) {
    const state = session.__battlePositionState;
    if (!state || !isValidEntity(entity)) return;
    if (!Array.isArray(state.entities)) state.entities = [];
    let saved = state.entities.find(entry => entry.id === entity.id);
    let movement;
    try {
        movement = entity.getComponent("minecraft:movement");
    } catch (error) {}
    if (!saved) {
        let hadBattleTag = false;
        let wasPartyPokemon = false;
        try { hadBattleTag = entity.hasTag(BATTLE_TAG); } catch (error) {}
        try { wasPartyPokemon = entity.hasTag("lota:party_pokemon"); } catch (error) {}
        saved = {
            id: entity.id,
            entity,
            anchor: anchor ? { ...anchor } : { ...entity.location },
            baseAnchor: anchor ? { ...anchor } : { ...entity.location },
            battleRadius: battleEntityMetrics(entity).radius,
            rotation: safeGetRotation(entity),
            movementValue: Number(movement?.currentValue),
            hadBattleTag,
            wasPartyPokemon
        };
        state.entities.push(saved);
        try { entity.addTag(BATTLE_TAG); } catch (error) {}
        try { entity.triggerEvent("lota:enter_battle_focus"); } catch (error) {}
        try { entity.setProperty("lota:battle_acting", false); } catch (error) {}
        try { entity.clearVelocity(); } catch (error) {}
    } else if (anchor) {
        saved.anchor = { ...anchor };
        saved.baseAnchor = { ...anchor };
    }

    try { entity.setProperty("lota:in_battle", true); } catch (error) {}

    expandBattleAnchorsForEntitySize(state);
    try { movement?.setCurrentValue(0); } catch (error) {}

    const platformAnchor = saved.wasPartyPokemon
        ? applyWaterPlatformAnchor(entity, saved.anchor, battleEntityMetrics(entity).width)
        : (releaseWaterPlatform(entity.id), getWaterSurfaceAnchor(entity, saved.anchor));
    if (platformAnchor) saved.anchor = platformAnchor;

    const waterSurfaceLocked = !!platformAnchor;
    if (waterSurfaceLocked !== !!saved.waterSurfaceLocked) {
        try {
            entity.triggerEvent(waterSurfaceLocked
                ? "lota:enter_water_battle_focus"
                : "lota:enter_battle_focus");
        } catch (error) {}
        saved.waterSurfaceLocked = waterSurfaceLocked;
        if (waterSurfaceLocked) safeTeleport(entity, saved.anchor);
    }

    const correction = battlePositionCorrection(
        entity.location,
        saved.anchor,
        BATTLE_POSITION_DRIFT_SQUARED,
        waterSurfaceLocked
    );
    if (correction) safeTeleport(entity, correction);
}

function replaceActiveBattlePokemonEntity(session, previousEntity) {
    const pokemon = activePokemon(session);
    const state = session?.__battlePositionState;
    const player = playerById(session?.playerId);
    if (!pokemon?.species || !state || !player || !isValidEntity(previousEntity)) return undefined;

    const saved = state.entities?.find(entry => entry.id === previousEntity.id);
    const location = saved?.anchor || previousEntity.location;
    let replacement;
    try {
        replacement = previousEntity.dimension.spawnEntity(battleEntityType(pokemon), location);
        savePokemonToEntity(replacement, pokemon);
        replacement.addTag("lota:party_pokemon");
        replacement.setDynamicProperty("lota:party_owner_id", session.playerId);
        replacement.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0);
        applyPokemonSkinToEntity(replacement, pokemon);
        replacement.nameTag = `§f${formatPokemonName(pokemon)} Lv. ${pokemon.level}§r`;
    } catch (error) {
        try { replacement?.remove(); } catch (cleanupError) {}
        return undefined;
    }

    state.entities = (state.entities || []).filter(entry => entry.id !== previousEntity.id);
    releaseWaterPlatform(previousEntity.id);
    try { previousEntity.remove(); } catch (error) {}
    publishPokemonAppearanceEvent("battle_form_changed", session.playerId, pokemon, replacement);
    session.__battlePokemonEntity = replacement;
    session.__battlePokemonUuid = String(pokemon.uuid || "");
    if (!Array.isArray(session.__playerBattleEntities)) session.__playerBattleEntities = [];
    session.__playerBattleEntities.push(replacement);
    delete session.__nextBattleEntitySearchTick;
    delete session.__battleLayout;
    saveAndLockBattleEntity(session, replacement, location);
    system.run(() => {
        if (!isValidEntity(replacement)) return;
        try { replacement.getComponent("minecraft:tameable")?.tame(player); } catch (error) {}
    });
    try { player.setDynamicProperty(SELECTED_SLOT_PROPERTY, session.playerSlot); } catch (error) {}
    return replacement;
}

function playFaintIfCrossed(pokemon, entity, previousHp) {
    if (Number(previousHp) > 0 && Number(pokemon?.currentHp) <= 0) {
        playOriginalPokemonBattleAnimation(entity, "faint");
    }
}

function ensureWildBattleLayout(session, player, ally, target) {
    const current = session.__battleLayout;
    if (current?.allyId === ally.id && current?.targetId === target.id) return current;

    const targetAnchor = battleAnchorForEntity(target, target.location);
    let allyAnchor = session.battleAllyLocation
        ? { ...session.battleAllyLocation }
        : battleAnchorForEntity(ally, ally.location);
    if (session.battleAllyLocation) safeTeleport(ally, allyAnchor);
    const separation = Math.hypot(
        Number(targetAnchor.x) - Number(allyAnchor.x),
        Number(targetAnchor.z) - Number(allyAnchor.z)
    );
    const minimum = minimumBattleSeparation(ally, target);
    if (separation < minimum) {
        const direction = horizontalDirection(player.location, targetAnchor, player);
        const side = { x: direction.z, z: -direction.x };
        const desired = {
            x: Number(targetAnchor.x) - direction.x * minimum - side.x * (0.3 + battleEntityWidth(ally)),
            y: Number(allyAnchor.y),
            z: Number(targetAnchor.z) - direction.z * minimum - side.z * (0.3 + battleEntityWidth(ally))
        };
        if (safeTeleport(ally, desired)) allyAnchor = { ...ally.location };
    }

    session.__battleLayout = {
        allyId: ally.id,
        targetId: target.id,
        ally: allyAnchor,
        target: targetAnchor
    };
    return session.__battleLayout;
}

function ensurePlayerBattleLayout(battle, firstEntity, secondEntity, firstPlayer, secondPlayer) {
    const current = battle.__battleLayout;
    if (current?.firstId === firstEntity.id && current?.secondId === secondEntity.id) return current;

    let firstAnchor = battleAnchorForEntity(firstEntity, firstEntity.location);
    let secondAnchor = battleAnchorForEntity(secondEntity, secondEntity.location);
    const separation = Math.hypot(
        Number(secondAnchor.x) - Number(firstAnchor.x),
        Number(secondAnchor.z) - Number(firstAnchor.z)
    );
    const minimum = minimumBattleSeparation(firstEntity, secondEntity);
    if (separation < minimum) {
        const direction = horizontalDirection(firstPlayer.location, secondPlayer.location, firstPlayer);
        const center = midpoint(firstAnchor, secondAnchor);
        const side = { x: direction.z, z: -direction.x };
        const firstDesired = {
            x: center.x - direction.x * minimum / 2 - side.x * (0.3 + battleEntityWidth(firstEntity)),
            y: firstAnchor.y,
            z: center.z - direction.z * minimum / 2 - side.z * (0.3 + battleEntityWidth(firstEntity))
        };
        const secondDesired = {
            x: center.x + direction.x * minimum / 2 + side.x * (0.3 + battleEntityWidth(secondEntity)),
            y: secondAnchor.y,
            z: center.z + direction.z * minimum / 2 + side.z * (0.3 + battleEntityWidth(secondEntity))
        };
        if (safeTeleport(firstEntity, firstDesired)) firstAnchor = { ...firstEntity.location };
        if (safeTeleport(secondEntity, secondDesired)) secondAnchor = { ...secondEntity.location };
    }

    battle.__battleLayout = {
        firstId: firstEntity.id,
        secondId: secondEntity.id,
        first: firstAnchor,
        second: secondAnchor
    };
    return battle.__battleLayout;
}

function orientPlayerForBattle(session, player, ally, opponent, signature) {
    const state = session.__battlePositionState;
    if (!state || state.cameraSuspended || !isValidEntity(ally) || !isValidEntity(opponent)
        || state.viewSignature === signature) return;
    const allyFocus = entityFocusLocation(ally);
    const opponentFocus = entityFocusLocation(opponent);
    if (allyFocus && opponentFocus) {
        const view = calculateFixedBattleCameraView({
            allyFocus,
            opponentFocus,
            allyBase: ally.location,
            allyMetrics: battleEntityMetrics(ally),
            sideScale: session.cameraSideScale
        });
        try {
            player.camera.setCamera("minecraft:free", {
                location: view.location,
                facingLocation: view.facingLocation,
                easeOptions: { easeTime: 0.45, easeType: EasingType.InOutSine }
            });
            state.cameraActive = true;
            state.viewSignature = signature;
        } catch (error) {}
    }
}

function suspendBattleCamera(session, player) {
    const state = session?.__battlePositionState;
    if (!player || !state) return;
    state.cameraSuspended = true;
    state.viewSignature = undefined;
    if (state.cameraActive) {
        try { player.camera.clear(); } catch (error) {}
        state.cameraActive = false;
    }
}

function resumeBattleCamera(session, player) {
    const state = session?.__battlePositionState;
    if (state) state.cameraSuspended = false;
    lockBattleEntities(session);
}

function lockBattleEntities(session) {
    const player = playerById(session?.playerId);
    if (!session || !player) return;
    if (!session.__battlePositionState) {
        session.__battlePositionState = {
            entities: []
        };
    }

    if (session.battleType === "pvp") {
        const opponent = opponentSession(session);
        const opponentPlayer = opponent ? playerById(opponent.playerId) : undefined;
        if (!opponent || !opponentPlayer) return;
        const ally = resolveBattlePokemonEntity(session);
        const opposingPokemon = resolveBattlePokemonEntity(opponent);
        if (isValidEntity(ally) && isValidEntity(opposingPokemon)) {
            const firstSession = session.pvpBattle.sessions[0];
            const secondSession = session.pvpBattle.sessions[1];
            const firstEntity = resolveBattlePokemonEntity(firstSession);
            const secondEntity = resolveBattlePokemonEntity(secondSession);
            const firstPlayer = playerById(firstSession.playerId);
            const secondPlayer = playerById(secondSession.playerId);
            if (isValidEntity(firstEntity) && isValidEntity(secondEntity) && firstPlayer && secondPlayer) {
                const layout = ensurePlayerBattleLayout(
                    session.pvpBattle,
                    firstEntity,
                    secondEntity,
                    firstPlayer,
                    secondPlayer
                );
                saveAndLockBattleEntity(firstSession, firstEntity, layout.first);
                saveAndLockBattleEntity(secondSession, secondEntity, layout.second);
            }
            setEntityFacing(ally, entityFocusLocation(opposingPokemon), true);
            setEntityFacing(opposingPokemon, entityFocusLocation(ally), true);
            orientPlayerForBattle(
                session,
                player,
                ally,
                opposingPokemon,
                `${ally.id}:${opposingPokemon.id}`
            );
        }
        return;
    }

    if (!isValidEntity(session.target)) return;
    const target = session.target;
    const ally = resolveBattlePokemonEntity(session);
    if (isValidEntity(ally)) {
        const layout = ensureWildBattleLayout(session, player, ally, target);
        saveAndLockBattleEntity(session, ally, layout.ally);
        saveAndLockBattleEntity(session, target, layout.target);
        setEntityFacing(ally, entityFocusLocation(target), true);
        setEntityFacing(target, entityFocusLocation(ally), true);
        orientPlayerForBattle(
            session,
            player,
            ally,
            target,
            `${ally.id}:${target.id}`
        );
        return;
    }

    if (!session.__battleLayout || session.__battleLayout.targetId !== target.id) {
        session.__battleLayout = { targetId: target.id, target: battleAnchorForEntity(target, target.location) };
    }
    saveAndLockBattleEntity(session, target, session.__battleLayout.target);
    setEntityFacing(target, entityFocusLocation(player), true);
}

function releaseBattleEntities(session) {
    if (!session) return;
    const player = playerById(session.playerId);
    const state = session.__battlePositionState;
    if (player && state?.cameraActive) {
        try { player.camera.clear(); } catch (error) {}
    }
    for (const saved of state?.entities || []) {
        releaseWaterPlatform(saved.id);
        const entity = isValidEntity(saved.entity) && saved.entity.id === saved.id
            ? saved.entity
            : undefined;
        if (!entity) continue;
        if (saved.rotation) {
            try { entity.setRotation(saved.rotation); } catch (error) {}
        }
        if (Number.isFinite(saved.movementValue)) {
            try {
                entity.getComponent("minecraft:movement")?.setCurrentValue(saved.movementValue);
            } catch (error) {}
        }
        try { entity.triggerEvent("lota:exit_battle_focus"); } catch (error) {}
        try { entity.setProperty("lota:in_battle", false); } catch (error) {}
        try { entity.setProperty("lota:battle_acting", false); } catch (error) {}
        if (saved.wasPartyPokemon) {
            try { entity.triggerEvent("lota:enable_party_follow"); } catch (error) {}
            const ownerId = session.playerId;
            system.run(() => {
                if (!isValidEntity(entity)) return;
                const owner = playerById(ownerId);
                if (!owner) return;
                try { entity.getComponent("minecraft:tameable")?.tame(owner); } catch (error) {}
            });
        }
        if (!saved.hadBattleTag) {
            try { entity.removeTag(BATTLE_TAG); } catch (error) {}
        }
    }
    delete session.__battleLayout;
    delete session.__battlePokemonEntity;
    delete session.__battlePokemonUuid;
    delete session.__nextBattleEntitySearchTick;
    delete session.__battlePositionState;
}

function isUsablePokemon(pokemon) {
    return !!pokemon && Number(pokemon.currentHp) > 0;
}

function firstUsableSlot(party, preferredSlot = 0) {
    if (isUsablePokemon(party[preferredSlot])) return preferredSlot;
    for (let i = 0; i < party.length; i++) {
        if (isUsablePokemon(party[i])) return i;
    }
    return -1;
}

function normalizeParty(party) {
    let changed = false;
    for (let i = 0; i < party.length; i++) {
        if (!party[i]) continue;
        const before = JSON.stringify(party[i]);
        normalizePokemonExperience(party[i]);
        normalizePokemonForBattle(party[i]);
        if (JSON.stringify(party[i]) !== before) changed = true;
    }
    return changed;
}

const LOG_COLORS = Object.freeze({
    player: "§a",
    opponent: "§c",
    turn: "§b",
    critical: "§e",
    error: "§c",
    faint: "§c",
    capture_attempt: "§e",
    capture_success: "§a",
    capture_fail: "§c",
    win: "§6",
    loss: "§c",
    experience: "§f",
    neutral: "§f"
});

function pushLog(session, message, side = "neutral", formatted = "", marker = "") {
    const entry = {
        side,
        message: String(message || ""),
        formatted: String(formatted || ""),
        marker: String(marker || "")
    };
    session.log.push(entry);
    if (session.log.length > 40) session.log.shift();
    session.logScroll = 0;
    return entry;
}

function logMessage(entry) {
    return typeof entry === "string" ? entry : String(entry?.message || "");
}

function logSide(entry) {
    return typeof entry === "string" ? "neutral" : String(entry?.side || "neutral");
}

function formatLogEntry(entry) {
    if (typeof entry !== "string" && entry?.formatted) return `${entry.formatted}§r`;
    const color = LOG_COLORS[logSide(entry)] || LOG_COLORS.neutral;
    return `${color}${logMessage(entry)}§r`;
}

function pushTurnLog(session) {
    const turn = Math.max(0, Math.floor(Number(session.turn) || 0));
    pushLog(session, `Turn ${turn}`, "turn", `§8---- §eTurn ${turn} §8----`, "turn");
}

function phaseValue(session) {
    if (!session || session.phase === "busy" || session.busy) return PHASE.busy;
    return PHASE[session.phase] || PHASE.menu;
}

function battleHpStep(pokemon) {
    const ratio = hpRatio(pokemon);
    return ratio <= 0 ? 0 : Math.max(1, Math.min(20, Math.ceil(ratio / 5)));
}

function battleInfoName(pokemon) {
    return formatPokemonName(pokemon);
}

function battleInfoGender(pokemon) {
    const gender = String(pokemon?.gender || "").toUpperCase();
    if (gender === "MALE") return "\u00a7b\u2642\u00a7r";
    if (gender === "FEMALE") return "\u00a7c\u2640\u00a7r";
    return "";
}

function battleVisualTokens(session, includeSpecies = true) {
    const ally = activePokemon(session);
    const opponent = opponentPokemon(session);
    const allyDex = speciesDexNumber(ally);
    const opponentDex = speciesDexNumber(opponent);
    const species = includeSpecies
        ? `|ASP:${String(allyDex).padStart(3, "0")}||WSP:${String(opponentDex).padStart(3, "0")}|`
        : "";
    return `${species}|AHP:${String(battleHpStep(ally)).padStart(2, "0")}||WHP:${String(raidHpStep(session)).padStart(2, "0")}|`;
}

function syncBattleProperties(player, session) {
    try { player.addTag(PLAYER_BATTLE_TAG); } catch (error) {}
    try {
        const allowAiming = session?.phase === "capture" || session?.phase === "item";
        player.onScreenDisplay.resetHudElementsVisibility();
        player.onScreenDisplay.hideAllExcept(allowAiming ? BATTLE_AIM_HUD : []);
    } catch (error) {}
}

function clearBattleProperties(player) {
    if (!player) return;
    try { player.removeTag(PLAYER_BATTLE_TAG); } catch (error) {}
    try { player.onScreenDisplay.resetHudElementsVisibility(); } catch (error) {}
}

function compactName(value, width) {
    const text = String(value || "-");
    return text.length > width ? `${text.slice(0, Math.max(1, width - 1))}.` : text.padEnd(width, " ");
}

function percentageText(value) {
    const number = Number(value) || 0;
    if (number <= 0) return "-";
    return Number.isInteger(number) ? `${number}%` : `${number.toFixed(2)}%`;
}

function signedNumber(value) {
    const number = Number(value) || 0;
    return number > 0 ? `+${number}` : String(number);
}

function wrapTooltipDescription(value, width = 24, maxLines = 7) {
    const words = String(value || "-").replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
    const lines = [];
    let line = "";
    for (const word of words) {
        const candidate = line ? `${line} ${word}` : word;
        if (candidate.length <= width) {
            line = candidate;
            continue;
        }
        if (line) lines.push(line);
        line = word;
        if (lines.length >= maxLines) break;
    }
    if (lines.length < maxLines && line) lines.push(line);
    if (lines.length > maxLines) lines.length = maxLines;
    if (lines.length === maxLines && words.join(" ").length > lines.join(" ").length) {
        lines[maxLines - 1] = `${lines[maxLines - 1].slice(0, Math.max(1, width - 3))}...`;
    }
    while (lines.length < maxLines) lines.push("");
    return lines;
}

function battleField(session) {
    return session?.battleType === "pvp" ? session?.pvpBattle?.field : session?.field;
}

function moveDamagePreviewData(session, index) {
    const attacker = activePokemon(session);
    const defender = opponentPokemon(session);
    const move = attacker?.moves?.[index];
    if (!attacker || !defender || !move) return { valid: false, minPercent: 0, maxPercent: 0, ko: "-", koKind: "unlikely" };
    const field = battleField(session) || {};
    const options = {
        weather: field.weather?.id || "",
        terrain: field.terrain?.id || "",
        critical: false
    };
    try {
        const minimum = calculateDamage(attacker, defender, move.id, {
            ...options,
            random: () => 0,
            randomModifier: 0.85
        }).damage;
        const maximum = calculateDamage(attacker, defender, move.id, {
            ...options,
            random: () => 0.999999,
            randomModifier: 1
        }).damage;
        const hp = Math.max(1, Number(defender.currentHp) || Number(defender.maxHp) || 1);
        const minPercent = Math.max(0, Math.floor(minimum * 100 / hp));
        const maxPercent = Math.max(0, Math.ceil(maximum * 100 / hp));
        let ko = "Unlikely KO";
        let koKind = "unlikely";
        if (minimum >= hp) {
            ko = "1-Hit KO";
            koKind = "one_hit";
        } else if (maximum >= hp) {
            ko = "Possible KO";
            koKind = "possible";
        } else if (maximum * 2 >= hp) {
            ko = "2HKO range";
            koKind = "two_hit_range";
        }
        return { valid: true, minPercent, maxPercent, ko, koKind };
    } catch (error) {
        return { valid: false, minPercent: 0, maxPercent: 0, ko: "-", koKind: "unlikely" };
    }
}

function effectivenessText(multiplier) {
    const value = Number(multiplier);
    if (value === 0) return "Immune (x0)";
    if (value > 1) return `Super Effective (x${value})`;
    if (value < 1) return `Not Very Effective (x${value})`;
    return "Effective (x1)";
}

function effectivenessColorCode(multiplier) {
    const value = Number(multiplier);
    if (value === 0) return "§8";
    if (value > 1) return "§a";
    if (value < 1) return "§7";
    return "§f";
}

function moveTooltipText(session, index, data) {
    const description = wrapTooltipDescription(data.description);
    const damage = moveDamagePreviewData(session, index);
    const damageColor = damage.maxPercent < 25 ? "§c" : damage.maxPercent < 50 ? "§6" : "§a";
    const koColor = damage.koKind === "one_hit" ? "§c"
        : damage.koKind === "possible" ? "§6"
            : damage.koKind === "two_hit_range" ? "§e"
                : "§7";
    const footerPreview = damage.valid
        ? `${effectivenessColorCode(data.effectiveness)}${effectivenessText(data.effectiveness)} §f| ${damageColor}★ ${damage.minPercent}-${damage.maxPercent}% §f| ${koColor}${damage.ko}`
        : `${effectivenessColorCode(data.effectiveness)}${effectivenessText(data.effectiveness)} §f| §7Damage -`;
    return [
        `§f${data.name}`,
        data.stab && data.power !== "-" ? `§a${data.power}` : `§f${data.power}`,
        `§f${data.accuracy === "-" ? "-" : `${data.accuracy}%`}`,
        `§f${signedNumber(data.priority)}`,
        `§f${percentageText(data.effectChance)}`,
        `§f${percentageText(data.criticalChance)}`,
        ...description.map(line => `§f${line}`),
        footerPreview,
        `§f${data.type.toUpperCase()} / ${data.category}`,
        data.stab ? "§aSTAB" : "§7No STAB",
        `§f${data.pp}`
    ];
}

function moveUiData(session, index) {
    const move = activePokemon(session)?.moves?.[index];
    if (!move) {
        return {
            name: "-",
            pp: "0/0",
            typeId: "typeless",
            type: "-",
            categoryId: "status",
            category: "-",
            power: "-",
            accuracy: "-",
            priority: 0,
            effectChance: 0,
            criticalChance: 0,
            description: "No move is assigned to this slot.",
            stab: false,
            effectiveness: 1,
            token: "|EMPTY|"
        };
    }

    const data = moveData(move.id);
    const currentPp = Math.max(0, Math.floor(Number(move.pp) || 0));
    const maxPp = Math.max(0, Math.floor(Number(move.maxPp) || 0));
    const typeId = cleanMoveId(data.type || "typeless");
    const categoryId = cleanMoveId(data.category || "physical");
    const attacker = activePokemon(session);
    const defender = opponentPokemon(session);
    const stab = pokemonTypes(attacker).includes(typeId);
    const basePower = Math.max(0, Number(data.power) || 0);
    const power = basePower > 0 ? String(Math.floor(basePower * (stab ? 1.5 : 1))) : "-";
    const accuracy = Number(data.accuracy) > 0 ? String(Math.floor(Number(data.accuracy))) : "-";
    const criticalStage = Math.max(0, (Number(data.critRatio) || 1) - 1 + (battleState(attacker).focusEnergy ? 2 : 0));
    const criticalChances = [1 / 24, 1 / 8, 1 / 2, 1];
    return {
        name: data.name || formatPokemonName({ species: move.id }),
        pp: `${currentPp}/${maxPp}`,
        typeId,
        type: TYPE_LABELS[typeId] || typeId.toUpperCase(),
        categoryId,
        category: CATEGORY_LABELS[categoryId] || categoryId,
        power,
        accuracy,
        priority: Number(data.priority) || 0,
        effectChance: moveEffectChance(move.id),
        criticalChance: criticalChances[Math.min(3, criticalStage)] * 100,
        description: String(moveDescription(move.id) || data.description || data.shortDescription || "No additional effect."),
        stab,
        effectiveness: typeEffectiveness(typeId, pokemonTypes(defender)),
        token: currentPp > 0 ? "" : "|NOPP|"
    };
}

function moveGridText(session) {
    const move0 = moveUiData(session, 0);
    const move1 = moveUiData(session, 1);
    const move2 = moveUiData(session, 2);
    const move3 = moveUiData(session, 3);
    return [
        `${compactName(move0.name, 15)} ${compactName(move1.name, 15)}`,
        `${compactName(`PP ${move0.pp}`, 15)} ${compactName(`PP ${move1.pp}`, 15)}`,
        `${compactName(move2.name, 15)} ${compactName(move3.name, 15)}`,
        `${compactName(`PP ${move2.pp}`, 15)} ${compactName(`PP ${move3.pp}`, 15)}`
    ].join("\n");
}

function selectedMoveDetailLines(session) {
    if (session.phase !== "moves") return ["", "", "", "", "", ""];
    const index = Math.max(0, Math.min(3, Math.floor(Number(session.cursor) || 0)));
    const data = moveUiData(session, index);
    return [
        data.name,
        data.type,
        data.category,
        `PP ${data.pp}`,
        data.power,
        data.accuracy
    ];
}

function switchGridText(session) {
    const cells = [];
    for (let i = 0; i < 6; i++) {
        const pokemon = session.party[i];
        if (!pokemon) {
            cells.push(compactName("-", 18));
            continue;
        }
        const fainted = isUsablePokemon(pokemon) ? "" : " FNT";
        const active = i === session.playerSlot ? "*" : " ";
        cells.push(compactName(`${active}${i + 1} ${formatPokemonName(pokemon)} Lv.${pokemon.level}${fainted}`, 23));
    }
    return [
        `${cells[0]} ${cells[1]}`,
        `${cells[2]} ${cells[3]}`,
        `${cells[4]} ${cells[5]}`
    ].join("\n");
}

function logEntryMarkerToken(entry, rowIndex) {
    if (!entry || rowIndex < 0 || rowIndex > 9) return "";
    const marker = typeof entry === "string" ? "" : String(entry.marker || "").toLowerCase();
    if (marker === "turn") return `|BLOG_ROW_${rowIndex}:TURN|`;
    if (marker === "player_opponent") return `|BLOG_ROW_${rowIndex}:PLAYER_OPPONENT|`;
    if (marker === "opponent_player") return `|BLOG_ROW_${rowIndex}:OPPONENT_PLAYER|`;
    if (marker === "side_player") return `|BLOG_ROW_${rowIndex}:SIDE_PLAYER|`;
    if (marker === "side_opponent") return `|BLOG_ROW_${rowIndex}:SIDE_OPPONENT|`;
    return "";
}

function battleLogView(session) {
    const entries = session?.log?.length ? session.log : [{ side: "player", message: "What will you do?" }];
    const maxLines = session?.logExpanded ? 8 : 4;
    const maxScroll = Math.max(0, entries.length - maxLines);
    const scroll = Math.max(0, Math.min(maxScroll, Math.floor(Number(session?.logScroll) || 0)));
    if (session) session.logScroll = scroll;
    const start = Math.max(0, entries.length - maxLines - scroll);
    const visibleEntries = entries.slice(start, start + maxLines);
    const lines = visibleEntries.map(formatLogEntry);
    const markerTokens = visibleEntries.map((entry, index) => logEntryMarkerToken(entry, index)).join("");
    return {
        entries,
        visibleEntries,
        lines,
        text: lines.join("\n"),
        scroll,
        markerTokens
    };
}

function battleSubtitle(session) {
    return battleLogView(session).text;
}

function clearPlayerDisplay(player) {
    try {
        clearHudTitleTransient(player, BATTLE_HUD_KEY);
        clearHudTitleBase(player);
        player.onScreenDisplay.setActionBar("");
    } catch (error) {}
}

function battleTitleText(session) {
    const logToken = session?.logExpanded ? BATTLE_LOG_OPEN_TOKEN : "";
    const minimisedToken = session?.phase === "capture" || session?.phase === "item" ? "|MINIMISED|" : "";
    const formToken = session?.formOpen ? "|BATTLE_FORM_OPEN|" : "";
    return `|COBBLEDROCK_BATTLE|${minimisedToken}${formToken}${logToken}`;
}

function menuGridText(session) {
    const options = session.raidBattle
        ? ["Fight", "Pokemon", "Cheer", "Leave"]
        : session.battleType === "pvp" || session.battleType === "trainer"
        ? ["Fight", "Switch", "Bag", "Run"]
        : ["Fight", "Switch", "Catch", "Run"];
    const cells = options.map((label, index) => `${session.cursor === index ? ">" : " "} ${label.padEnd(8, " ")}`);
    return `${cells[0]} ${cells[1]}\n${cells[2]} ${cells[3]}`;
}

function battleActionText(session) {
    if (session.waiting) return "Waiting for opponent...";
    if (session.busy || session.phase === "busy") return "Resolving turn...";
    if (session.phase === "moves") return moveGridText(session);
    if (session.phase === "raid_cheer") return "Choose one of three raid cheers. Each trainer may cheer three times.";
    if (session.phase === "item") return "Hold and use a battle item or Poke Ball. Sneak-use the compass to go back.";
    if (session.phase === "item_move_target") return itemMoveGridText(session);
    if (session.phase === "switch" || session.phase === "item_target") return switchGridText(session);
    return "";
}

function battleFormTitle(session, forHud = false) {
    const phase = isUnifiedBattleForm(session)
        ? `${UNIFIED_TITLE_PREFIX}${session.phase}`
        : session?.phase === "moves" || session?.phase === "item_move_target"
            ? BATTLE_FORM_TITLE.moves
            : session?.phase === "switch" || session?.phase === "item_target"
                ? BATTLE_FORM_TITLE.switch : BATTLE_FORM_TITLE.menu;
    const ally = activePokemon(session);
    const opponent = opponentPokemon(session);
    return [
        phase,
        battleInfoName(ally),
        `${battleInfoName(opponent)}${raidHealth(session)?.shield ? " [Shield]" : ""}`,
        battleInfoGender(ally), battleInfoGender(opponent),
        `Lv.${Math.max(1, Math.floor(Number(ally?.level) || 1))}`,
        `Lv.${Math.max(1, Math.floor(Number(opponent?.level) || 1))}`,
        hpText(ally), raidHpText(session), battleVisualTokens(session, forHud), ...selectedMoveDetailLines(session)
    ].join("\n");
}

function battleHudTitle(session) {
    const lines = battleFormTitle(session, true).split("\n");
    lines[0] = battleTitleText(session);
    lines.push(battleLogView(session).markerTokens);
    return lines.join("\n");
}

function movePpTokens(ppText) {
    const display = String(ppText ?? "").slice(0, 5).padStart(5, " ");
    return [...display]
        .map((character, index) => character === " " ? "" : `|PP${index}:${character}|`)
        .join("");
}

function moveButtonText(session, index) {
    const data = moveUiData(session, index);
    if (data.token.includes("|EMPTY|")) return "|EMPTY|";
    const ppTokens = data.token.includes("|EMPTY|") ? "" : movePpTokens(data.pp);
    const detailLines = moveTooltipText(session, index, data);
    return `${detailLines.join("\n")}\n|TYPE:${data.typeId}||CAT:${data.categoryId}|${data.token}${ppTokens}`;
}

function switchBallToken(pokemon) {
    return `|BALL:${captureBallCode(pokemon?.caughtBall)}|`;
}

function switchStatusToken(pokemon) {
    const status = String(pokemon?.statusCondition ?? "NONE").toUpperCase();
    if (status === "BURN" || status === "BRN") return "|ST:BRN|";
    if (status === "FREEZE" || status === "FROZEN" || status === "FRZ") return "|ST:FRZ|";
    if (status === "PARALYSIS" || status === "PARALYZED" || status === "PAR") return "|ST:PAR|";
    if (status === "POISON" || status === "POISONED" || status === "PSN") return "|ST:PSN|";
    if (status === "BADLY_POISONED" || status === "TOXIC" || status === "TOX") return "|ST:TOX|";
    if (status === "SLEEP" || status === "ASLEEP" || status === "SLP") return "|ST:SLP|";
    return "";
}

function switchButtonText(session, index) {
    const pokemon = session.party[index];
    if (!pokemon) return "000|EMPTY|";
    const name = battleInfoName(pokemon);
    const hpStep = Math.max(0, Math.min(20, Math.ceil(hpRatio(pokemon) / 5)));
    const usable = isUsablePokemon(pokemon);
    const active = index === session.playerSlot && usable ? "|ACTIVE|" : "";
    const fainted = usable ? "" : "|FNT|";
    const status = usable ? switchStatusToken(pokemon) : "";
    return `Lv.${pokemon.level}\n${name}\n\n${hpText(pokemon)}${"\n".repeat(11)}|HP:${String(hpStep).padStart(2, "0")}|${switchBallToken(pokemon)}${status}${active}${fainted}`;
}

function appendBattleLogButtons(form, session) {
    form.button(LOG_CONTROL_LABELS.up);
    form.button(LOG_CONTROL_LABELS.down);
    form.button(LOG_CONTROL_LABELS.toggle);
}

export function buildBattlePartySelectionForm(party, options = {}) {
    const activeSlot = Number.isInteger(options.activeSlot) ? options.activeSlot : -1;
    const session = {
        party: Array.isArray(party) ? party : [],
        playerSlot: activeSlot,
        wildPokemon: options.opponent
    };
    const form = new ActionFormData()
        .title(BATTLE_FORM_TITLE.switch)
        .body("");
    for (let index = 0; index < 6; index++) {
        const pokemon = session.party[index];
        if (pokemon) form.button(switchButtonText(session, index), pokemonFormTexture(pokemon));
        else form.button(switchButtonText(session, index));
    }
    form.button("Back");
    return form;
}

function pendingBattleItemPokemon(session) {
    const slot = Math.floor(Number(session?.pendingBattleItem?.targetSlot));
    return session?.party?.[slot];
}

function itemMoveGridText(session) {
    const pokemon = pendingBattleItemPokemon(session);
    const cells = [];
    for (let index = 0; index < 4; index++) {
        const move = pokemon?.moves?.[index];
        if (!move) cells.push("-");
        else cells.push(`${moveData(move.id).name} PP ${Math.max(0, Number(move.pp) || 0)}/${Math.max(0, Number(move.maxPp) || 0)}`);
    }
    return `${cells[0]} ${cells[1]}\n${cells[2]} ${cells[3]}`;
}

function itemMoveButtonText(session, index) {
    const move = pendingBattleItemPokemon(session)?.moves?.[index];
    if (!move) return "|EMPTY|";
    const data = moveData(move.id);
    const typeId = cleanMoveId(data.type || "typeless");
    const categoryId = cleanMoveId(data.category || "physical");
    const currentPp = Math.max(0, Math.floor(Number(move.pp) || 0));
    const maxPp = Math.max(0, Math.floor(Number(move.maxPp) || 0));
    const noPp = currentPp >= maxPp ? "|NOPP|" : "";
    return `${data.name}\nPP ${currentPp}/${maxPp}\n|TYPE:${typeId}||CAT:${categoryId}|${noPp}`;
}

function megaEvolutionFailureForSession(session, player, pokemon) {
    if (session?.megaUsed) return "Only one Pokemon can Mega Evolve in each battle.";
    return megaEvolutionFailure(player, pokemon, session?.party || []);
}

function megaButtonText(session, player) {
    if (session.megaPending) return "Mega Evolution\nSelected\n|MEGA:ON|";
    const failure = megaEvolutionFailureForSession(session, player, activePokemon(session));
    return failure
        ? `Mega Evolution\n${failure}\n|MEGA:LOCKED|`
        : "Mega Evolution\nReady\n|MEGA:READY|";
}

function appendBattleFormIdentityButtons(form, visibleButtonCount, session) {
    for (let index = visibleButtonCount; index < BATTLE_FORM_IDENTITY_BUTTON_START; index++) {
        form.button("|FORM_DATA|");
    }
    form.button("|FORM_DATA:ALLY|", pokemonFormTexture(activePokemon(session)));
    form.button("|FORM_DATA:WILD|", pokemonFormTexture(opponentPokemon(session)));
}

function battleFormVisibleButtonCount(session) {
    if (session.phase === "moves") return 9;
    if (session.phase === "raid_cheer") return 4;
    if (session.phase === "item_move_target") return 5;
    if (session.phase === "switch") return 10;
    if (session.phase === "item_target") return 7;
    return 7;
}

function buildUnifiedBattleForm(player, session) {
    const form = new ActionFormData().title(battleFormTitle(session)).body(battleSubtitle(session));
    form.button("Fight"); form.button("Switch"); form.button("Item"); form.button("Run");
    appendBattleLogButtons(form, session);
    appendBattleFormIdentityButtons(form, 7, session);
    for (let index = 0; index < 4; index++) form.button(moveButtonText(session, index));
    form.button(megaButtonText(session, player));
    form.button("Back");
    for (let index = 0; index < 6; index++) {
        const pokemon = session.party[index];
        if (pokemon) form.button(switchButtonText(session, index), pokemonFormTexture(pokemon));
        else form.button(switchButtonText(session, index));
    }
    form.button("Back");
    return form;
}

function enterBattlePhaseSilently(session, player, phase) {
    if (session.phase === phase) return;
    session.busy = false;
    session.phase = phase;
    if (phase === "menu") {
        session.forceSwitch = false;
        session.megaPending = false;
        resetNavigationAnchor(session, player);
        resumeBattleCamera(session, player);
    } else if (phase === "switch") {
        session.forceSwitch = false;
        session.megaPending = false;
        resetNavigationAnchor(session, player);
    } else {
        resetNavigationAnchor(session, player);
    }
}

function handleUnifiedBattleSelection(session, index) {
    const player = playerById(session.playerId);
    if (!player) return;
    if (handleBattleLogControl(session, index)) return;
    if (index === 0) return showMoveMenu(player, session);
    if (index === 1) return showSwitchMenu(player, session, false);
    if (index === 2 || index === 3) {
        enterBattlePhaseSilently(session, player, "menu");
        session.cursor = index;
        return handleBattleConfirm(session);
    }
    if (index >= UNIFIED_BUTTON.moves && index < UNIFIED_BUTTON.moves + 4) {
        enterBattlePhaseSilently(session, player, "moves");
        session.cursor = index - UNIFIED_BUTTON.moves;
        return handleBattleConfirm(session);
    }
    if (index === UNIFIED_BUTTON.mega) {
        enterBattlePhaseSilently(session, player, "moves");
        return toggleMegaEvolution(session, player);
    }
    if (index >= UNIFIED_BUTTON.party && index < UNIFIED_BUTTON.party + 6) {
        enterBattlePhaseSilently(session, player, "switch");
        session.cursor = index - UNIFIED_BUTTON.party;
        return handleBattleConfirm(session);
    }
    if (index === UNIFIED_BUTTON.movesBack || index === UNIFIED_BUTTON.switchBack) return showBattleMenu(player, session);
    reopenBattleForm(session);
}

function buildBattleForm(player, session) {
    if (isUnifiedBattleForm(session)) return buildUnifiedBattleForm(player, session);
    const form = new ActionFormData().title(battleFormTitle(session)).body(battleSubtitle(session));
    if (session.phase === "moves") {
        for (let index = 0; index < 4; index++) form.button(moveButtonText(session, index));
        form.button(megaButtonText(session, player));
        form.button("Back"); appendBattleLogButtons(form, session);
    } else if (session.phase === "raid_cheer") {
        form.button("Go All Out!\nBoost damage");
        form.button("Hang Tough!\nReduce damage");
        form.button("Heal Up!\nRestore half HP");
        form.button("Back");
    } else if (session.phase === "item_move_target") {
        for (let index = 0; index < 4; index++) form.button(itemMoveButtonText(session, index));
        form.button("Back");
    } else if (session.phase === "switch" || session.phase === "item_target") {
        for (let index = 0; index < 6; index++) {
            const pokemon = session.party[index];
            if (pokemon) form.button(switchButtonText(session, index), pokemonFormTexture(pokemon));
            else form.button(switchButtonText(session, index));
        }
        form.button("Back");
        if (session.phase === "switch") appendBattleLogButtons(form, session);
    } else {
        if (session.raidBattle) {
            form.button("Fight"); form.button("Pokemon\nOne Pokemon only");
            form.button("Cheer"); form.button("Leave Raid");
        } else {
            form.button("Fight"); form.button("Switch"); form.button("Item");
            form.button("Run");
        }
        appendBattleLogButtons(form, session);
    }
    appendBattleFormIdentityButtons(form, battleFormVisibleButtonCount(session), session);
    return form;
}

function formIsBusy(reason) {
    return String(reason ?? "").toLowerCase().includes("busy");
}

function reopenBattleForm(session, delay = 0) {
    if (!session || session.busy || session.phase === "busy" || session.phase === "item" || session.formOpen) return;
    const requestToken = (session.formRequestToken || 0) + 1;
    session.formRequestToken = requestToken;
    const open = () => {
        if (!validateSession(session) || session.formRequestToken !== requestToken || session.busy
            || session.phase === "busy" || session.phase === "capture" || session.phase === "item" || session.formOpen) return;
        const player = playerById(session.playerId);
        if (player) openBattleForm(player, session);
    };
    if (delay > 0) system.runTimeout(open, delay); else open();
}

function retryBattleFormIfBusy(session, reason) {
    if (!formIsBusy(reason)) return false;
    const retries = Math.max(0, Math.floor(Number(session.formBusyRetries) || 0));
    if (retries >= BATTLE_FORM_BUSY_RETRY_LIMIT) return false;
    session.formBusyRetries = retries + 1;
    reopenBattleForm(session, 1);
    return true;
}

function handleBattleFormCancel(session) {
    if (!validateSession(session) || session.busy) return;
    if (session.phase === "moves") return handleBattleBack(session);
    if (session.phase === "raid_cheer") return handleBattleBack(session);
    if (session.phase === "switch" && !session.forceSwitch) return handleBattleBack(session);
    if (session.phase === "item_target") return enterItemMode(session);
    if (session.phase === "item_move_target") return returnToBattleItemTargeting(session);
    reopenBattleForm(session);
}

function battleLogControlStart(session) {
    if (isUnifiedBattleForm(session)) return UNIFIED_BUTTON.log;
    if (session.phase === "menu") return 4;
    if (session.phase === "moves") return 6;
    if (session.phase === "switch") return 7;
    return -1;
}

function handleBattleLogControl(session, index) {
    const start = battleLogControlStart(session);
    if (start < 0 || index < start || index > start + 2) return false;

    if (index === start) {
        if (session.logExpanded) session.logScroll = Math.min(99, Math.floor(Number(session.logScroll) || 0) + 1);
    } else if (index === start + 1) {
        if (session.logExpanded) session.logScroll = Math.max(0, Math.floor(Number(session.logScroll) || 0) - 1);
    } else {
        session.logExpanded = !session.logExpanded;
        session.logScroll = 0;
    }

    reopenBattleForm(session);
    return true;
}

function handleBattleFormSelection(session, selection) {
    if (!validateSession(session) || session.busy) return;
    const index = Math.floor(Number(selection));
    if (!Number.isInteger(index) || index < 0) return handleBattleFormCancel(session);
    if (isUnifiedBattleForm(session)) return handleUnifiedBattleSelection(session, index);
    if (index >= battleFormVisibleButtonCount(session)) return reopenBattleForm(session);
    if (session.phase === "item_target") {
        if (index === 6) return enterItemMode(session);
        session.cursor = index; return handleBattleConfirm(session);
    }
    if (session.phase === "item_move_target") {
        if (index === 4) return returnToBattleItemTargeting(session);
        session.cursor = index; return handleBattleConfirm(session);
    }
    if (session.phase === "raid_cheer") {
        if (index === 3) return handleBattleBack(session);
        session.cursor = index;
        return handleBattleConfirm(session);
    }
    if (handleBattleLogControl(session, index)) return;
    if (session.phase === "moves" && index === 4) return toggleMegaEvolution(session, playerById(session.playerId));
    if (session.phase === "moves" && index === 5) return handleBattleBack(session);
    if (session.phase === "switch" && index === 6) return handleBattleBack(session);
    session.cursor = index; handleBattleConfirm(session);
}

function renderBattleHud(player, session) {
    try {
        const title = battleHudTitle(session);
        const subtitle = battleSubtitle(session);
        const payload = title + "\u0000" + subtitle;
        session.__lastHudPayload = payload;
        clearHudTitleTransient(player, BATTLE_HUD_KEY);
        setHudTitleBase(player, title, subtitle);
        player.onScreenDisplay.setActionBar("");
        if (session.__lastHudError) session.__lastHudError = undefined;
    } catch (error) {
        const errStr = String(error?.message || error || "unknown");
        if (session.__lastHudError !== errStr) {
            session.__lastHudError = errStr;
            console.warn(`[CobbleDrockBattle] Battle HUD render failed for ${player?.name || session.playerId} (type: ${session.battleType}, phase: ${session.phase}): ${errStr}`);
        }
    }
}

function openBattleForm(player, session) {
    if (!validateSession(session) || session.busy || session.phase === "busy"
        || session.phase === "capture" || session.phase === "item" || session.formOpen) return;
    const token = (session.formToken || 0) + 1;
    session.formToken = token; session.formOpen = true;
    syncBattleProperties(player, session); renderBattleHud(player, session);
    buildBattleForm(player, session).show(player).then(response => {
        if (!validateSession(session) || session.formToken !== token) return;
        session.formOpen = false;
        renderBattleHud(player, session);
        if (!response || response.canceled) {
            if (formIsBusy(response?.cancelationReason)) { retryBattleFormIfBusy(session, response.cancelationReason); return; }
            session.formBusyRetries = 0; handleBattleFormCancel(session); return;
        }
        session.formBusyRetries = 0; handleBattleFormSelection(session, response.selection);
    }).catch(error => {
        if (session.formToken !== token) return;
        session.formOpen = false;
        renderBattleHud(player, session);
        if (formIsBusy(error)) { retryBattleFormIfBusy(session, error); return; }
        session.formBusyRetries = 0; console.warn(`Battle form failed: ${error}`);
    });
}

function updateBattleHud(session, force = false) {
    const player = playerById(session.playerId);
    if (!player) return;
    const tick = system.currentTick;
    if (!force && session.lastHudTick && session.lastHudTick + HUD_KEEPALIVE_TICKS > tick) return;
    session.lastHudTick = tick;
    syncBattleProperties(player, session);
    renderBattleHud(player, session);
    reopenBattleForm(session);
}

function clearBattleHud(player) {
    if (!player) return;
    clearBattleProperties(player);
    clearPlayerDisplay(player);
    notifyBattleHudCleared(player);
}

function saveSession(session) {
    const player = playerById(session.playerId);
    if (player) {
        savePartyToPlayer(player, session.party);
    }
    if (session.battleType === "pvp" || session.battleType === "trainer") return;
    if (isValidEntity(session.target)) savePokemonToEntity(session.target, session.wildPokemon);
}

function savePlayerBattle(battle) {
    if (!battle?.sessions) return;
    for (const session of battle.sessions) saveSession(session);
}

function clearPlayerBattle(battle, options = {}) {
    if (!battle || battle.ended) return;
    battle.ended = true;
    for (const session of battle.sessions || []) {
        battleStatusVisuals.clearSession(session);
        session.formToken = (session.formToken || 0) + 1;
        session.formRequestToken = (session.formRequestToken || 0) + 1;
        session.formOpen = false;
        revertSessionMegaEvolution(session);
        releaseBattleEntities(session);
        activeBattles.delete(session.playerId);
        const player = playerById(session.playerId);
        if (!player) continue;
        for (const pokemon of session.party) clearBattleState(pokemon);
        savePartyToPlayer(player, session.party);
        clearBattleHud(player);
        if (options.resultMessage) player.sendMessage(options.resultMessage);
        else if (options.message) player.sendMessage(options.message);
    }
}

function clearBattle(session, options = {}) {
    if (session?.battleType === "pvp") {
        clearPlayerBattle(session.pvpBattle, options);
        return;
    }
    battleStatusVisuals.clearSession(session);
    if (session.captureInProgress) {
        removeCaptureBall(session);
        restoreBattleTarget(session, session.captureLocation);
        session.captureInProgress = false;
    }
    revertSessionMegaEvolution(session);
    const trainerBattleEntities = session.battleType === "trainer"
        ? [
            session.target,
            session.__battlePokemonEntity,
            ...(session.__trainerBattleEntities || []),
            ...(session.__playerBattleEntities || []),
            ...(session.__battlePositionState?.entities || []).map(saved => saved?.entity)
        ].filter((entity, index, all) => isValidEntity(entity) && all.findIndex(candidate => candidate?.id === entity.id) === index)
        : [];
    releaseBattleEntities(session);
    session.formToken = (session.formToken || 0) + 1;
    session.formRequestToken = (session.formRequestToken || 0) + 1;
    session.formOpen = false;
    activeBattles.delete(session.playerId);
    if (session.targetId) entityBattles.delete(session.targetId);
    for (const entity of trainerBattleEntities) {
        try { entity.remove(); } catch (error) {}
    }
    if (isValidEntity(session.target)) {
        try { session.target.removeTag(BATTLE_TAG); } catch (error) {}
        if (options.removeTarget || session.battleType === "trainer") {
            try { session.target.remove(); } catch (error) {}
        }
    }

    const player = playerById(session.playerId);
    if (player) {
        for (const pokemon of session.party || []) clearBattleState(pokemon);
        savePartyToPlayer(player, session.party || []);
        clearBattleHud(player);
        if (options.message) player.sendMessage(options.message);
    }
}

function validateSession(session) {
    if (!session) return false;
    if (session.battleType === "pvp") {
        const battle = session.pvpBattle;
        const opponent = opponentSession(session);
        if (!battle || battle.ended || !playerById(session.playerId) || !opponent || !playerById(opponent.playerId)) {
            clearPlayerBattle(battle);
            return false;
        }
        return true;
    }
    const player = playerById(session.playerId);
    if (!player || (!isValidEntity(session.target) && !session.captureInProgress)) {
        clearBattle(session);
        return false;
    }
    return true;
}

function awardDefeatedExperience(session, defeatedPokemon) {
    const messages = [];
    const participants = new Set(session.participants || []);
    for (let slot = 0; slot < (session.party?.length || 0); slot++) {
        const pokemon = session.party[slot];
        if (!isUsablePokemon(pokemon)) continue;
        const participationMultiplier = battleExperienceParticipationMultiplier(pokemon, slot, participants);
        if (participationMultiplier <= 0) continue;
        const shared = !participants.has(slot);
        const gained = calculateBattleExperience(pokemon, defeatedPokemon, participationMultiplier, session.playerId);
        const experienceResult = addPokemonExperience(pokemon, gained, Number(session.levelCap) || 100);
        messages.push(experienceResult.amount > 0
            ? `${formatPokemonName(pokemon)} received ${experienceResult.amount} experience${shared ? " from Exp. Share" : ""}.`
            : `${formatPokemonName(pokemon)} is held at the Lv.${session.levelCap} level cap.`);
        if (experienceResult.queuedEvolutions?.length) {
            messages.push(`${formatPokemonName(pokemon)} is ready to evolve! Open the party menu and choose Evolve.`);
        }
    }
    return messages;
}

function replaceTrainerOpponentEntity(session, pokemon) {
    const previous = session.target;
    const state = session.__battlePositionState;
    const saved = state?.entities?.find(entry => entry.id === previous?.id);
    const location = saved?.anchor || session.captureLocation || previous?.location;
    if (!location || !previous?.dimension) return undefined;
    const dimension = previous.dimension;

    let replacement;
    try {
        replacement = dimension.spawnEntity(battleEntityType(pokemon), location);
        savePokemonToEntity(replacement, pokemon);
        replacement.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0);
        replacement.nameTag = `§f${formatPokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        replacement.addTag(BATTLE_TAG);
    } catch (error) {
        try { replacement?.remove(); } catch (cleanupError) {}
        console.warn(`Trainer opponent replacement failed for ${pokemon?.species || "unknown"}: ${error}`);
        return undefined;
    }
    if (previous?.id) entityBattles.delete(previous.id);
    if (state) state.entities = (state.entities || []).filter(entry => entry.id !== previous?.id);
    releaseWaterPlatform(previous?.id);
    try { previous.remove(); } catch (error) {}
    session.target = replacement;
    session.targetId = replacement.id;
    session.targetTypeId = replacement.typeId;
    session.targetNameTag = storedRealNameTag(replacement);
    const battler = playerById(session.playerId);
    if (battler) identify(battler, pokemon);
    session.captureDimension = dimension;
    session.captureLocation = { ...location };
    session.wildPokemon = pokemon;
    if (!Array.isArray(session.__trainerBattleEntities)) session.__trainerBattleEntities = [];
    session.__trainerBattleEntities.push(replacement);
    delete session.__battleLayout;
    entityBattles.set(replacement.id, session.playerId);
    saveAndLockBattleEntity(session, replacement, location);
    playOriginalPokemonBattleAnimation(replacement, "cry");
    return replacement;
}

function nextUsableTrainerSlot(session) {
    const party = session.trainerParty || [];
    for (let offset = 1; offset <= party.length; offset++) {
        const slot = (Number(session.trainerSlot) + offset) % party.length;
        if (slot !== Number(session.trainerSlot) && Number(party[slot]?.currentHp) > 0) return slot;
    }
    return -1;
}

function activateTrainerSlot(session, nextSlot, voluntary = false) {
    const current = session.wildPokemon;
    const nextPokemon = session.trainerParty?.[nextSlot];
    if (!nextPokemon || Number(nextPokemon.currentHp) <= 0) return false;
    battleState(session.party[session.playerSlot]).trapped = false;
    battleState(session.party[session.playerSlot]).partialTrapTurns = 0;
    clearBattleState(current, true);
    clearBattleState(nextPokemon, true);
    if (!replaceTrainerOpponentEntity(session, nextPokemon)) return false;
    session.trainerSlot = nextSlot;
    resetBattleState(nextPokemon);
    session.participants = [session.playerSlot];
    if (voluntary) pushLog(session, `${session.trainerName} withdrew ${formatPokemonName(current)}!`, "opponent", "", "side_opponent");
    pushLog(session, `${session.trainerName} sent out ${formatPokemonName(nextPokemon)}!`, "opponent", "", "side_opponent");
    const hpBeforeHazards = Number(nextPokemon.currentHp);
    for (const message of applyEntryHazards(session.field, "opponent", nextPokemon)) pushLog(session, message, "opponent", "", "side_opponent");
    playFaintIfCrossed(nextPokemon, session.target, hpBeforeHazards);
    session.trainerSwitchCooldown = voluntary ? 2 : 1;
    return true;
}

function continueTrainerBattle(session, nextSlot = nextUsableTrainerSlot(session)) {
    if (nextSlot < 0 || !activateTrainerSlot(session, nextSlot, false)) return false;
    session.turn = Math.max(1, Number(session.turn) || 1) + 1;
    pushTurnLog(session);
    saveSession(session);
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    system.runTimeout(() => showBattleMenu(playerById(session.playerId), session), BATTLE_MENU_DELAY_TICKS);
    return true;
}

function endVictory(session) {
    if (session.ending) return;
    session.ending = true;
    session.wildPokemon.currentHp = 0;
    const player = playerById(session.playerId);
    const experienceMessages = session.raidBattle ? [] : awardDefeatedExperience(session, session.wildPokemon);
    publishServerWildBattleVictory(session);
    saveSession(session);
    pushLog(session, `${formatPokemonName(session.wildPokemon)} fainted!`, "faint");
    for (const message of experienceMessages) pushLog(session, message, "experience");
    if (session.battleType === "trainer" && nextUsableTrainerSlot(session) >= 0) {
        session.ending = false;
        if (continueTrainerBattle(session)) return;
        session.ending = true;
        try { session.onAbort?.(player, session, "opponent_spawn_failed"); }
        catch (error) { console.warn(`Trainer abort callback failed: ${error}`); }
        clearBattle(session, { message: `§c${session.trainerName}'s next Pokemon could not enter battle. Please try again.§r` });
        return;
    }
    pushLog(session, `${player?.name || "Player"} won!`, "win");
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    if (session.battleType === "trainer") {
        try { session.onVictory?.(player, session); } catch (error) { console.warn(`Trainer victory callback failed: ${error}`); }
    }
    system.runTimeout(() => clearBattle(session, { removeTarget: true }), BATTLE_RESULT_DELAY_TICKS);
}

function endLoss(session) {
    if (session.ending) return;
    session.ending = true;
    const player = playerById(session.playerId);
    saveSession(session);
    pushLog(session, `${player?.name || "Player"} is out of usable Pokemon!`, "loss");
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    if (session.battleType === "trainer") {
        try { session.onLoss?.(player, session); } catch (error) { console.warn(`Trainer loss callback failed: ${error}`); }
    }
    system.runTimeout(() => clearBattle(session), BATTLE_RESULT_DELAY_TICKS);
}

function showBattleMenu(player, session) {
    if (!validateSession(session)) return;
    session.phase = "menu";
    session.cursor = 0;
    session.busy = false;
    session.forceSwitch = false;
    session.megaPending = false;
    resetNavigationAnchor(session, player);
    resumeBattleCamera(session, player);
    updateBattleHud(session, true);
}

function revertSessionMegaEvolution(session) {
    const active = activePokemon(session);
    const previousEntity = active?.battleState?.megaSpecies ? resolveBattlePokemonEntity(session) : undefined;
    setMegaEvolutionModelVisible(previousEntity, true);
    for (const pokemon of session?.party || []) revertMegaEvolution(pokemon);
    if (previousEntity && isValidEntity(previousEntity) && session?.__battlePositionState) {
        replaceActiveBattlePokemonEntity(session, previousEntity);
    }
    session.megaPending = false;
    session.megaUsed = false;
    delete session.megaSequenceToken;
}

function toggleMegaEvolution(session, player) {
    if (!player) return;
    if (session.megaPending) {
        session.megaPending = false;
        updateBattleHud(session, true);
        return;
    }
    const pokemon = activePokemon(session);
    const failure = megaEvolutionFailureForSession(session, player, pokemon);
    if (failure) {
        pushLog(session, failure, "error");
        updateBattleHud(session, true);
        return;
    }
    session.megaPending = true;
    updateBattleHud(session, true);
}

function megaEffectDimensions(entity) {
    const metrics = battleEntityMetrics(entity);
    const scale = Math.max(1.35, Math.min(3.4, Math.max(metrics.width, metrics.height * 0.6)));
    return {
        effect: scale < 1.65
            ? "cobblemon:mega_evolution_small"
            : (scale > 2.2 ? "cobblemon:mega_evolution_large" : "cobblemon:mega_evolution"),
        anchorY: Math.max(0.45, Math.min(1.35, metrics.height * 0.32))
    };
}

function playMegaEvolutionEffect(entity) {
    if (!isValidEntity(entity)) return false;
    const dimensions = megaEffectDimensions(entity);
    const location = {
        x: entity.location.x,
        y: entity.location.y + dimensions.anchorY,
        z: entity.location.z
    };
    try {
        entity.dimension.spawnParticle(dimensions.effect, location);
        entity.dimension.playSound(MEGA_EFFECT_SOUND, location, { volume: 0.3, pitch: 0.55 });
        return true;
    } catch (error) {
        return false;
    }
}

function setMegaEvolutionModelVisible(entity, visible, durationTicks = MEGA_BATTLE_RESUME_TICKS) {
    if (!isValidEntity(entity)) return false;
    try {
        if (visible) entity.removeEffect("invisibility");
        else entity.addEffect("invisibility", Math.max(1, Math.floor(durationTicks)), {
            amplifier: 0,
            showParticles: false
        });
        return true;
    } catch (error) {
        return false;
    }
}

function runMegaEvolutionSequence(session, complete = () => {}) {
    if (!validateSession(session)) return;
    const player = playerById(session.playerId);
    const pokemon = activePokemon(session);
    const failure = megaEvolutionFailureForSession(session, player, pokemon);
    session.megaPending = false;
    if (failure) {
        pushLog(session, failure, "error");
        updateBattleHud(session, true);
        complete();
        return;
    }
    const previousEntity = resolveBattlePokemonEntity(session);
    if (!isValidEntity(previousEntity)) {
        pushLog(session, "Mega Evolution could not start because the active Pokemon is unavailable.", "error");
        updateBattleHud(session, true);
        complete();
        return;
    }

    const token = `${system.currentTick}:${session.playerId}:${Math.random()}`;
    session.megaSequenceToken = token;
    const sequenceIsCurrent = () => validateSession(session) && session.megaSequenceToken === token;
    let replacement;
    let applied = false;
    playMegaEvolutionEffect(previousEntity);

    system.runTimeout(() => {
        if (!sequenceIsCurrent()) return;
        setMegaEvolutionModelVisible(
            previousEntity,
            false,
            MEGA_BATTLE_RESUME_TICKS - MEGA_MODEL_HIDE_TICKS
        );
    }, MEGA_MODEL_HIDE_TICKS);

    system.runTimeout(() => {
        if (!sequenceIsCurrent()) return;
        const result = applyMegaEvolution(playerById(session.playerId), pokemon);
        if (!result.success) {
            setMegaEvolutionModelVisible(previousEntity, true);
            pushLog(session, result.message, "error");
            updateBattleHud(session, true);
            return;
        }
        const currentEntity = isValidEntity(previousEntity) ? previousEntity : resolveBattlePokemonEntity(session);
        replacement = isValidEntity(currentEntity)
            ? replaceActiveBattlePokemonEntity(session, currentEntity)
            : spawnBattlePokemonEntity(session, player?.location || session.captureLocation);
        if (!isValidEntity(replacement)) {
            revertMegaEvolution(pokemon);
            setMegaEvolutionModelVisible(previousEntity, true);
            pushLog(session, "Mega Evolution could not replace the active Pokemon model.", "error");
            updateBattleHud(session, true);
            return;
        }
        setMegaEvolutionModelVisible(replacement, true);
        applied = true;
        session.megaUsed = true;
        pushLog(session, `${formatPokemonName(pokemon)} Mega Evolved into ${result.form.name}!`, "player");
        saveSession(session);
        updateBattleHud(session, true);
    }, MEGA_FORM_APPLY_TICKS);

    system.runTimeout(() => {
        if (!sequenceIsCurrent() || !applied) return;
        const activeEntity = isValidEntity(replacement) ? replacement : resolveBattlePokemonEntity(session);
        if (isValidEntity(activeEntity)) {
            setMegaEvolutionModelVisible(activeEntity, true);
            playOriginalPokemonBattleAnimation(activeEntity, "cry");
        }
    }, MEGA_CRY_TICKS);

    system.runTimeout(() => {
        if (!sequenceIsCurrent()) return;
        const activeEntity = isValidEntity(replacement) ? replacement : resolveBattlePokemonEntity(session);
        setMegaEvolutionModelVisible(activeEntity, true);
        delete session.megaSequenceToken;
        session.megaPending = false;
        saveSession(session);
        updateBattleHud(session, true);
        complete();
    }, MEGA_BATTLE_RESUME_TICKS);
}

function showMoveMenu(player, session) {
    if (!validateSession(session)) return;
    session.phase = "moves";
    const forced = forcedMoveId(activePokemon(session));
    const forcedIndex = forced ? activePokemon(session)?.moves?.findIndex(move => move.id === forced) : -1;
    session.cursor = forcedIndex >= 0 ? forcedIndex : 0;
    session.busy = false;
    resetNavigationAnchor(session, player);
    updateBattleHud(session, true);
}

function showRaidCheerMenu(player, session) {
    if (!validateSession(session) || !session.raidBattle) return;
    session.phase = "raid_cheer";
    session.cursor = 0;
    session.busy = false;
    session.megaPending = false;
    resetNavigationAnchor(session, player);
    updateBattleHud(session, true);
}

function useRaidCheer(session, cheerType) {
    if (!session?.raidBattle || session.busy) return { success: false, message: "The raid is not ready for a cheer." };
    let result;
    try { result = session.raidBattle.useCheer?.(cheerType, session); }
    catch (error) {
        console.warn(`Raid cheer callback failed: ${error}`);
        result = { success: false, message: "The cheer failed." };
    }
    if (!result?.success) {
        pushLog(session, result?.message || "No cheers remain.", "error");
        updateBattleHud(session, true);
        return result || { success: false, message: "The cheer failed." };
    }
    pushLog(session, result.message || "The team rallied!", "player", "", "side_player");
    session.phase = "busy";
    session.busy = true;
    saveSession(session);
    updateBattleHud(session, true);
    system.runTimeout(() => resolveWildOnlyTurn(session), BATTLE_CHOICE_DELAY_TICKS);
    return result;
}

function showSwitchMenu(player, session, forced) {
    if (!validateSession(session)) return;
    session.phase = "switch";
    session.cursor = Math.max(0, firstUsableSlot(session.party, 0));
    session.forceSwitch = forced === true;
    session.busy = false;
    session.megaPending = false;
    resetNavigationAnchor(session, player);
    updateBattleHud(session, true);
}

function usableMoveIndex(pokemon, preferredIndex = 0) {
    if (!Array.isArray(pokemon.moves) || pokemon.moves.length === 0) return -1;
    const forced = forcedMoveId(pokemon);
    if (forced) {
        const forcedIndex = pokemon.moves.findIndex(move => move.id === forced);
        if (forcedIndex >= 0) return forcedIndex;
    }
    if (pokemon.moves[preferredIndex]?.pp > 0) return preferredIndex;
    return pokemon.moves.findIndex(move => Number(move.pp) > 0);
}

function consumePp(pokemon, moveIndex) {
    if (moveIndex < 0) return { id: "struggle", ppConsumed: false };
    const move = pokemon.moves[moveIndex];
    const state = battleState(pokemon);
    if (move && (state.chargingMoveId === move.id || state.lockedMoveId === move.id)) return { id: move.id, ppConsumed: false };
    if (!move || Number(move.pp) <= 0) return { id: "struggle", ppConsumed: false };
    move.pp = Math.max(0, Math.floor(Number(move.pp) || 0) - 1);
    return { id: move.id, ppConsumed: true };
}

function chooseWildMoveIndex(wildPokemon) {
    const forced = forcedMoveId(wildPokemon);
    if (forced) {
        const forcedIndex = wildPokemon.moves.findIndex(move => move.id === forced && (Number(move.pp) > 0 || battleState(wildPokemon).chargingMoveId === forced || battleState(wildPokemon).lockedMoveId === forced));
        if (forcedIndex >= 0) return forcedIndex;
    }
    const usable = [];
    for (let i = 0; i < wildPokemon.moves.length; i++) {
        const move = moveData(wildPokemon.moves[i].id);
        if (Number(wildPokemon.moves[i].pp) > 0 && !moveSelectionFailure(wildPokemon, move)) usable.push(i);
    }
    if (!usable.length) return -1;
    return usable[Math.floor(Math.random() * usable.length)];
}

function chooseOpponentMoveIndex(session) {
    const pokemon = session.wildPokemon;
    if (session.battleType !== "trainer") return chooseWildMoveIndex(pokemon);
    if (session.trainerAi?.mode === "random") return chooseWildMoveIndex(pokemon);
    const defender = session.party[session.playerSlot];
    const candidates = [];
    for (let index = 0; index < (pokemon.moves || []).length; index++) {
        const slot = pokemon.moves[index];
        const move = moveData(slot.id);
        if (Number(slot.pp) <= 0 || moveSelectionFailure(pokemon, move)) continue;
        const defenderTypes = pokemonTypes(defender);
        const targetImmune = !["self", "allySide", "foeSide", "all"].includes(move.target)
            && typeEffectiveness(move.type, defenderTypes) === 0;
        const status = String(move.status || "").toLowerCase();
        const statusImmune = (status === "brn" && defenderTypes.includes("fire"))
            || (["psn", "tox"].includes(status) && defenderTypes.some(type => type === "poison" || type === "steel"))
            || (status === "par" && defenderTypes.includes("electric"))
            || (status === "slp" && move.flags?.includes("powder") && defenderTypes.includes("grass"));
        if (targetImmune || statusImmune) continue;
        const accuracy = Number(move.accuracy) > 0 ? Number(move.accuracy) / 100 : 1;
        if (fieldEffectWouldFail(session.field, "opponent", move, "player")) continue;
        const result = move.category === "status" ? undefined : calculateDamage(pokemon, defender, move.id, {
            critical: false,
            randomModifier: 1,
            ...damageFieldOptions(session.field, "player")
        });
        const damage = Math.max(0, Number(result?.damage) || 0);
        const defenderHp = Math.max(1, Number(defender.currentHp) || 1);
        const defenderMaxHp = Math.max(defenderHp, Number(defender.maxHp) || defenderHp);
        const sharedRaidHealth = raidHealth(session);
        const actorHpRatio = sharedRaidHealth
            ? Math.max(0, Math.min(1, sharedRaidHealth.current / sharedRaidHealth.max))
            : Math.max(0, Math.min(1, Number(pokemon.currentHp) / Math.max(1, Number(pokemon.maxHp) || 1)));
        let score = damage * accuracy;

        if (damage > 0) {
            if (damage >= defenderHp) score += defenderMaxHp * 4;
            if (Number(move.priority) > 0 && battleStats(pokemon).speed < battleStats(defender).speed) {
                score += defenderMaxHp * 0.2;
            }
            if (Array.isArray(move.drain) && actorHpRatio < 0.8) score += damage * (1 - actorHpRatio) * 0.45;
            if (Number(result?.effectiveness) > 1) score += defenderMaxHp * 0.12;
            if (Number(result?.effectiveness) === 0) score = 0;
            if (move.status && String(defender.statusCondition || "NONE").toLowerCase() === "none") {
                score += defenderMaxHp * 0.12 * Math.max(0, Math.min(1, (Number(moveEffectChance(move.id)) || 100) / 100));
            }
        } else {
            const defenderHasStatus = String(defender.statusCondition || "NONE").toLowerCase() !== "none";
            const selfHealing = Array.isArray(move.heal) || ["moonlight", "morningsun", "rest", "slackoff", "synthesis"].includes(move.id);
            const missingHp = Math.max(0, Number(pokemon.maxHp) - Number(pokemon.currentHp));
            if (selfHealing) score += actorHpRatio < 0.75 ? missingHp * 1.4 : -defenderMaxHp;
            if (status && !defenderHasStatus) {
                const statusWeight = status === "slp" ? 0.75 : status === "tox" ? 0.62 : status === "brn" || status === "par" ? 0.5 : 0.35;
                score += defenderMaxHp * statusWeight * accuracy;
            } else if (status) {
                score -= defenderMaxHp;
            }
            if (move.sideCondition) {
                const reserves = Math.max(0, (session.party || []).filter(candidate => Number(candidate?.currentHp) > 0).length - 1);
                score += defenderMaxHp * (reserves > 0 ? 0.48 : 0.08);
            }
            if (move.boosts) {
                const affectsSelf = move.target === "self";
                const target = affectsSelf ? pokemon : defender;
                let stageValue = 0;
                for (const [stat, amount] of Object.entries(move.boosts)) {
                    const current = Number(battleState(target).stages?.[stat]) || 0;
                    const useful = Number(amount) > 0 ? Math.max(0, 4 - current) : Math.max(0, 4 + current);
                    stageValue += Math.abs(Number(amount) || 0) * useful / 4;
                }
                const statBias = Math.max(0, Number(session.trainerAi?.statMoveBias) || 0);
                score += defenderMaxHp * 0.22 * stageValue * statBias * (affectsSelf && actorHpRatio < 0.4 ? 0.25 : 1);
            }
            if (move.volatileStatus === "protect") {
                const residualPressure = String(defender.statusCondition || "NONE").toLowerCase() !== "none";
                score += defenderMaxHp * (residualPressure ? 0.3 : 0.06) / (1 + Math.max(0, Number(battleState(pokemon).protectChain) || 0));
            }
            if (move.volatileStatus === "destinybond") {
                score += actorHpRatio <= 0.35 ? defenderMaxHp * 1.1 : defenderMaxHp * 0.05;
            }
        }
        candidates.push({ index, score: Math.max(0, score) });
    }
    if (!candidates.length) return -1;
    const maximum = Math.max(...candidates.map(entry => entry.score));
    const margin = Math.max(0, Number(session.trainerAi?.maxSelectMargin) || 0);
    const eligible = candidates.filter(entry => entry.score >= maximum * (1 - margin));
    return eligible[Math.floor(Math.random() * eligible.length)].index;
}

function trainerBestDamage(session, attacker, defender, defenderSide) {
    let best = 0;
    for (const slot of attacker?.moves || []) {
        if (Number(slot?.pp) <= 0) continue;
        const move = moveData(slot.id);
        if (move.category === "status") continue;
        const result = calculateDamage(attacker, defender, move.id, {
            critical: false,
            randomModifier: 1,
            ...damageFieldOptions(session.field, defenderSide)
        });
        best = Math.max(best, Number(result?.damage) || 0);
    }
    return best;
}

function chooseTrainerSwitchSlot(session) {
    if (session.battleType !== "trainer" || isTrapped(session.wildPokemon)) return -1;
    if (Math.max(0, Number(session.trainerSwitchCooldown) || 0) > 0) return -1;
    const switchBias = Math.max(0, Math.min(1, Number(session.trainerAi?.switchBias) || 0));
    if (switchBias <= 0 || Math.random() > switchBias) return -1;

    const defender = session.party[session.playerSlot];
    const current = session.wildPokemon;
    const currentOutgoing = trainerBestDamage(session, current, defender, "player");
    const currentIncoming = trainerBestDamage(session, defender, current, "opponent");
    const currentHp = Math.max(1, Number(current.currentHp) || 1);
    const defenderHp = Math.max(1, Number(defender.currentHp) || 1);
    const currentScore = currentOutgoing / defenderHp - currentIncoming / currentHp;
    let best;

    for (let slot = 0; slot < (session.trainerParty || []).length; slot++) {
        if (slot === Number(session.trainerSlot)) continue;
        const candidate = session.trainerParty[slot];
        if (!candidate || Number(candidate.currentHp) <= 0) continue;
        const outgoing = trainerBestDamage(session, candidate, defender, "player");
        const incoming = trainerBestDamage(session, defender, candidate, "opponent");
        const hp = Math.max(1, Number(candidate.currentHp) || 1);
        const score = outgoing / defenderHp - incoming / hp;
        if (!best || score > best.score) best = { slot, outgoing, incoming, hp, score };
    }
    if (!best) return -1;

    const cannotPressure = currentOutgoing < defenderHp * 0.18 && best.outgoing >= Math.max(defenderHp * 0.28, currentOutgoing * 1.5);
    const threatened = currentIncoming >= currentHp * 0.72 && best.incoming < best.hp * 0.6;
    const decisiveUpgrade = best.score >= currentScore + 0.55;
    return (cannotPressure || threatened) && decisiveUpgrade ? best.slot : -1;
}
function moveLogFormatting(actor, move, defender, actorSide, damage = 0) {
    const actorColor = actorSide === "player" ? "§a" : "§c";
    const defenderColor = actorSide === "player" ? "§c" : "§a";
    const maxHp = Math.max(1, Number(defender?.maxHp) || 1);
    const percent = damage > 0 ? `§f(§e${((damage / maxHp) * 100).toFixed(1)}%§f)` : "";
    return `${actorColor}${formatPokemonName(actor)}§f used §9[${move.name}]§f${percent} on ${defenderColor}${formatPokemonName(defender)}§f!`;
}

function cleanHeldItemId(pokemon) {
    return String(pokemon?.heldItem || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();
}

function consumeHeldBerry(pokemon) {
    pokemon.heldItem = "";
    if (pokemon.heldItemData) delete pokemon.heldItemData;
}

function lowHpBerryThreshold(pokemon) {
    const ability = String(pokemon?.ability || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();
    return Math.max(1, Number(pokemon?.maxHp) || 1) / (ability === "gluttony" ? 2 : 4);
}

function raiseHeldBerryStage(pokemon, stat, amount = 1) {
    const state = battleState(pokemon);
    const current = Number(state.stages[stat]) || 0;
    state.stages[stat] = Math.max(-6, Math.min(6, current + amount));
}

function heldBerryActionPriority(pokemon, basePriority) {
    const priority = Number(basePriority) || 0;
    if (priority > 0 || cleanHeldItemId(pokemon) !== "custap_berry") return priority;
    if (Number(pokemon?.currentHp) > lowHpBerryThreshold(pokemon)) return priority;
    consumeHeldBerry(pokemon);
    battleState(pokemon).custapActivated = true;
    return priority + 0.1;
}

function checkPostHitHeldBerryTriggers(pokemon, pokemonEntity, attacker, move, result, wasTarget, log, refresh) {
    if (!pokemon || Number(pokemon.currentHp) <= 0) return;
    const held = cleanHeldItemId(pokemon);
    if (!held || (!held.endsWith("_berry") && held !== "berry_juice")) return;

    const maxHp = Math.max(1, Number(pokemon.maxHp) || 1);
    const hp = Number(pokemon.currentHp) || 0;

    if (held === "oran_berry" && hp <= maxHp / 2) {
        consumeHeldBerry(pokemon);
        const healed = Math.min(10, maxHp - hp);
        pokemon.currentHp += healed;
        log(`${formatPokemonName(pokemon)} ate its Oran Berry and restored ${healed} HP!`, "neutral");
        refresh();
        return;
    }
    if (held === "berry_juice" && hp <= maxHp / 2) {
        consumeHeldBerry(pokemon);
        const healed = Math.min(20, maxHp - hp);
        pokemon.currentHp += healed;
        log(`${formatPokemonName(pokemon)} drank its Berry Juice and restored ${healed} HP!`, "neutral");
        refresh();
        return;
    }
    if (held === "sitrus_berry" && hp <= maxHp / 2) {
        consumeHeldBerry(pokemon);
        const healed = Math.min(Math.max(1, Math.floor(maxHp / 4)), maxHp - hp);
        pokemon.currentHp += healed;
        log(`${formatPokemonName(pokemon)} ate its Sitrus Berry and restored HP!`, "neutral");
        refresh();
        return;
    }
    if (["figy_berry", "wiki_berry", "mago_berry", "aguav_berry", "iapapa_berry"].includes(held) && hp <= lowHpBerryThreshold(pokemon)) {
        consumeHeldBerry(pokemon);
        const healed = Math.min(Math.floor(maxHp * 0.33), maxHp - hp);
        pokemon.currentHp += Math.max(1, healed);
        log(`${formatPokemonName(pokemon)} ate its ${held.replace(/_berry$/, "").replace(/\b\w/g, c => c.toUpperCase())} Berry!`, "neutral");
        const dislikedMap = { figy_berry: "attack", wiki_berry: "specialAttack", mago_berry: "speed", aguav_berry: "specialDefence", iapapa_berry: "defence" };
        const nature = String(pokemon.mintedNature || pokemon.nature || "").toLowerCase();
        if (NATURE_LOWERED_STATS[nature] === dislikedMap[held]) {
            if (!pokemon.battleState) pokemon.battleState = {};
            pokemon.battleState.confusionTurns = 2 + Math.floor(Math.random() * 4);
            log(`${formatPokemonName(pokemon)} became confused due to the bitter taste!`, "neutral");
        }
        refresh();
        return;
    }

    const status = String(pokemon.statusCondition || "NONE").toUpperCase();
    if (held === "cheri_berry" && status.includes("PAR")) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        log(`${formatPokemonName(pokemon)} ate its Cheri Berry and cured its paralysis!`, "neutral");
        refresh();
        return;
    }
    if (held === "chesto_berry" && status.includes("SLP")) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        log(`${formatPokemonName(pokemon)} ate its Chesto Berry and woke up!`, "neutral");
        refresh();
        return;
    }
    if (held === "pecha_berry" && (status.includes("PSN") || status.includes("TOX"))) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        log(`${formatPokemonName(pokemon)} ate its Pecha Berry and cured its poison!`, "neutral");
        refresh();
        return;
    }
    if (held === "rawst_berry" && status.includes("BRN")) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        log(`${formatPokemonName(pokemon)} ate its Rawst Berry and healed its burn!`, "neutral");
        refresh();
        return;
    }
    if (held === "aspear_berry" && status.includes("FRZ")) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        log(`${formatPokemonName(pokemon)} ate its Aspear Berry and thawed out!`, "neutral");
        refresh();
        return;
    }
    if (held === "persim_berry" && Number(pokemon?.battleState?.confusionTurns) > 0) {
        consumeHeldBerry(pokemon);
        delete pokemon.battleState.confusionTurns;
        log(`${formatPokemonName(pokemon)} ate its Persim Berry and snapped out of confusion!`, "neutral");
        refresh();
        return;
    }
    if (held === "lum_berry" && (status !== "NONE" || Number(pokemon?.battleState?.confusionTurns) > 0)) {
        consumeHeldBerry(pokemon);
        pokemon.statusCondition = "NONE";
        if (pokemon.battleState?.confusionTurns) delete pokemon.battleState.confusionTurns;
        log(`${formatPokemonName(pokemon)} ate its Lum Berry and cured its condition!`, "neutral");
        refresh();
        return;
    }

    if (wasTarget && held === "enigma_berry" && Number(result?.effectiveness) > 1 && hp < maxHp) {
        consumeHeldBerry(pokemon);
        const healed = Math.min(Math.max(1, Math.floor(maxHp / 4)), maxHp - hp);
        pokemon.currentHp += healed;
        log(`${formatPokemonName(pokemon)} ate its Enigma Berry and restored ${healed} HP!`, "neutral");
        refresh();
        return;
    }
    const moveCategory = String(move?.category || "").toLowerCase();
    if (wasTarget && Number(result?.damage) > 0 && ((held === "jaboca_berry" && moveCategory === "physical") || (held === "rowap_berry" && moveCategory === "special"))) {
        consumeHeldBerry(pokemon);
        const retaliation = Math.min(Number(attacker?.currentHp) || 0, Math.max(1, Math.floor((Number(attacker?.maxHp) || 1) / 8)));
        if (attacker && retaliation > 0) attacker.currentHp = Math.max(0, Number(attacker.currentHp) - retaliation);
        log(`${formatPokemonName(pokemon)}'s ${held === "jaboca_berry" ? "Jaboca" : "Rowap"} Berry hurt ${formatPokemonName(attacker)}!`, "neutral");
        refresh();
        return;
    }

    if (wasTarget && Number(result?.damage) > 0 && ((held === "kee_berry" && moveCategory === "physical") || (held === "maranga_berry" && moveCategory === "special"))) {
        consumeHeldBerry(pokemon);
        const stat = held === "kee_berry" ? "def" : "spd";
        raiseHeldBerryStage(pokemon, stat, 1);
        log(`${formatPokemonName(pokemon)}'s ${held === "kee_berry" ? "Kee" : "Maranga"} Berry raised its ${stat === "def" ? "Defense" : "Special Defense"}!`, "neutral");
        refresh();
        return;
    }

    if (hp <= lowHpBerryThreshold(pokemon)) {
        const statBerries = {
            liechi_berry: "atk",
            ganlon_berry: "def",
            salac_berry: "spe",
            petaya_berry: "spa",
            apicot_berry: "spd"
        };
        if (statBerries[held]) {
            consumeHeldBerry(pokemon);
            raiseHeldBerryStage(pokemon, statBerries[held], 1);
            log(`${formatPokemonName(pokemon)} ate its ${held.replace(/_berry$/, "").replace(/\b\w/g, c => c.toUpperCase())} Berry and raised a stat!`, "neutral");
            refresh();
            return;
        }
        if (held === "lansat_berry") {
            consumeHeldBerry(pokemon);
            battleState(pokemon).focusEnergy = true;
            log(`${formatPokemonName(pokemon)} ate its Lansat Berry and became pumped!`, "neutral");
            refresh();
            return;
        }
        if (held === "starf_berry") {
            const candidates = ["atk", "def", "spa", "spd", "spe"]
                .filter(stat => (Number(battleState(pokemon).stages[stat]) || 0) < 6);
            if (candidates.length) {
                consumeHeldBerry(pokemon);
                const stat = candidates[Math.floor(Math.random() * candidates.length)];
                raiseHeldBerryStage(pokemon, stat, 2);
                log(`${formatPokemonName(pokemon)} ate its Starf Berry and sharply raised a stat!`, "neutral");
                refresh();
                return;
            }
        }
        if (held === "micle_berry") {
            consumeHeldBerry(pokemon);
            battleState(pokemon).micleBerryAccuracy = true;
            log(`${formatPokemonName(pokemon)} ate its Micle Berry and heightened its accuracy!`, "neutral");
            refresh();
            return;
        }
    }

    if (held === "leppa_berry" || held === "hopo_berry") {
        const moveSlot = (pokemon.moves || []).find(candidate => Number(candidate?.pp) === 0);
        if (moveSlot) {
            consumeHeldBerry(pokemon);
            moveSlot.pp = Math.min(Number(moveSlot.maxPp) || 0, Number(moveSlot.pp) + 10);
            log(`${formatPokemonName(pokemon)} ate its ${held === "leppa_berry" ? "Leppa" : "Hopo"} Berry and restored PP!`, "neutral");
            refresh();
        }
    }
}

function applyDamageHitSequence({ actor, defender, actorEntity, defenderEntity, move, result, isValid, log, refresh, complete, field, actorSide, defenderSide, actorParty, damageTransform, onDamageApplied, visualStartedTick = 0, visualReleaseTicks = 0 }, hitIndex = 0, state = undefined) {
    if (!isValid()) return;
    const hitResults = Array.isArray(result.hitResults) && result.hitResults.length
        ? result.hitResults
        : [{ damage: Math.max(0, Number(result.damage) || 0), critical: result.critical === true }];
    const progress = state || { hits: 0, damage: 0, finished: false, targetAffected: move.category === "status", statChanges: [] };
    const effectOptions = {
        actorSide: {
            ...battleSideState(field, actorSide),
            terrain: field?.terrain?.id || "",
            grounded: isGrounded(actor),
            onStatStageChange: change => progress.statChanges.push({ ...change, entity: actorEntity })
        },
        defenderSide: {
            ...battleSideState(field, defenderSide),
            terrain: field?.terrain?.id || "",
            grounded: isGrounded(defender),
            onStatStageChange: change => progress.statChanges.push({ ...change, entity: defenderEntity })
        },
        actorParty,
        clearActorHazards: () => clearEntryHazards(field, actorSide),
        setActorSideEffect: (effect, value) => setSideEffect(field, actorSide, effect, value),
        ...damageFieldOptions(field, defenderSide)
    };

    const finish = () => {
        if (progress.finished) return;
        progress.finished = true;
        if (result.consumedBerry) {
            const bName = String(result.consumedBerry).replace(/_berry$/, "").replace(/\b\w/g, c => c.toUpperCase()) + " Berry";
            log(`${formatPokemonName(defender)}'s ${bName} weakened the damage of ${move.name || move.id || "the move"}!`, "neutral");
            defender.heldItem = "";
            if (defender.heldItemData) delete defender.heldItemData;
        }
        if (hitResults.length > 1) log(`It hit ${progress.hits} ${progress.hits === 1 ? "time" : "times"}!`, "neutral");
        if (result.effectiveness > 1) log("It was super effective!", "neutral");
        else if (result.effectiveness > 0 && result.effectiveness < 1) log("It wasn't very effective....", "neutral");
        if (progress.targetAffected || move.target === "self") {
            for (const message of applyMoveFinalEffects(actor, defender, move, progress.damage, effectOptions)) log(message);
        }
        checkPostHitHeldBerryTriggers(defender, defenderEntity, actor, move, result, true, log, refresh);
        checkPostHitHeldBerryTriggers(actor, actorEntity, defender, move, { damage: 0, effectiveness: 1 }, false, log, refresh);
        if (Number(actor.currentHp) <= 0) playOriginalPokemonBattleAnimation(actorEntity, "faint");
        for (const message of applyMoveFieldEffects(field, actorSide, move, defenderSide)) log(message);
        refresh();
        const elapsed = Math.max(0, (Number(system.currentTick) || visualStartedTick) - visualStartedTick);
        let followupTicks = Math.max(0, Number(visualReleaseTicks) - elapsed);
        for (const change of progress.statChanges) {
            const timing = playOriginalBattleStatChangeEffect(change.entity, change.amount, isValid, followupTicks);
            followupTicks += Math.max(0, Number(timing.releaseTicks) || 0);
        }
        complete({
            move,
            damage: progress.damage,
            hits: progress.hits,
            targetAffected: progress.targetAffected,
            followupTicks
        });
    };

    if (hitIndex >= hitResults.length || Number(defender.currentHp) <= 0) {
        finish();
        return;
    }

    const hit = hitResults[hitIndex];
    const transformedDamage = typeof damageTransform === "function"
        ? Math.max(0, Math.floor(Number(damageTransform(hit.damage, hitIndex, move)) || 0))
        : hit.damage;
    const applied = applyHitDamage(defender, transformedDamage, actor, move);
    recordEvolutionProgress(actor, "use_move", 1, move.id || move.name || "");
    if (applied.damage > 0) recordEvolutionProgress(defender, "damage_taken", applied.damage);
    progress.damage += applied.damage + applied.substituteDamage;
    progress.hits += 1;
    if (applied.damage > 0 || (Number(hit.damage) || 0) <= 0) progress.targetAffected = true;
    if (applied.damage > 0 && Number(defender.currentHp) <= 0) {
        playOriginalPokemonBattleAnimation(defenderEntity, "faint");
    }
    if (applied.substituteBroke) log(`${formatPokemonName(defender)}'s substitute faded!`, "neutral");
    if (hit.critical) {
        log("It was a critical hit!", "critical");
        recordEvolutionProgress(actor, "battle_critical_hits");
    }
    if (applied.substituteDamage <= 0) for (const message of applyMoveHitEffects(actor, defender, move, applied.damage, effectOptions)) log(message);
    if (typeof onDamageApplied === "function" && applied.damage > 0) {
        onDamageApplied(applied.damage, { hitIndex, move, actor, defender });
    }
    refresh();

    if (hitIndex + 1 >= hitResults.length || Number(defender.currentHp) <= 0) {
        finish();
        return;
    }
    system.runTimeout(
        () => applyDamageHitSequence({ actor, defender, actorEntity, defenderEntity, move, result, isValid, log, refresh, complete, field, actorSide, defenderSide, actorParty, damageTransform, onDamageApplied, visualStartedTick, visualReleaseTicks }, hitIndex + 1, progress),
        MULTI_HIT_DELAY_TICKS
    );
}

function executeMoveAction({ actor, defender, actorEntity, defenderEntity, moveId, actorSide, defenderSide, field, actorParty, isValid, log, formattedLog, refresh, complete, damageTransform, onDamageApplied }) {
    const move = moveData(moveId);
    const fieldOptions = damageFieldOptions(field, defenderSide);
    const releasingSkyDrop = move.id === "skydrop" && battleState(actor).chargingMoveId === move.id;
    const finishAction = result => {
        if (releasingSkyDrop) delete battleState(defender).skyDropHeld;
        complete(result);
    };
    const preparation = prepareMoveState(actor, move, Math.random, fieldOptions);
    const fieldFailure = !preparation.failed && fieldEffectWouldFail(field, actorSide, move, defenderSide);
    const resolution = preparation.failed || fieldFailure
        ? undefined
        : createMoveEventQueue(actor, defender, moveId, {
            ...fieldOptions,
            protected: battleState(defender).protected === true,
            substitute: Number(battleState(defender).substituteHp) > 0,
            semiInvulnerable: battleState(defender).semiInvulnerable || ""
        });
    const terminal = resolution?.events.find(event => [BATTLE_EVENT.miss, BATTLE_EVENT.fail, BATTLE_EVENT.immune, BATTLE_EVENT.protected].includes(event.type));
    const rawDamage = terminal || move.id === "futuresight" ? 0 : resolution?.result?.damage || 0;
    const damage = typeof damageTransform === "function"
        ? Math.max(0, Math.floor(Number(damageTransform(rawDamage, 0, move)) || 0))
        : rawDamage;
    log(`${formatPokemonName(actor)} used ${move.name} on ${formatPokemonName(defender)}!`, actorSide, formattedLog(damage, move), "move");
    if (preparation.failed) {
        log(preparation.message || "But it failed!", "error");
        finishAction({ move, failed: true });
        return;
    }
    if (fieldFailure) {
        log("But it failed!", "error");
        finishAction({ move, failed: true });
        return;
    }
    if (preparation.charging) {
        if (move.id === "skydrop" && terminal) {
            battleState(actor).chargingMoveId = "";
            battleState(actor).semiInvulnerable = "";
            log(terminal.type === BATTLE_EVENT.immune
                ? `But ${formatPokemonName(defender)} is immune!`
                : "But it failed!", "error");
            refresh();
            finishAction({ move, failed: true });
            return;
        }
        if (move.id === "skydrop") battleState(defender).skyDropHeld = true;
        log(preparation.message, "neutral");
        refresh();
        finishAction({ move, charging: true });
        return;
    }
    if (move.id === "healingwish" && !(actorParty || []).some(pokemon => pokemon !== actor && Number(pokemon?.currentHp) > 0)) {
        log("But it failed!", "error");
        finishAction({ move, failed: true });
        return;
    }
    if (move.id === "futuresight") {
        if (!queueFutureMove(field, defenderSide, actor, move.id)) {
            log("But it failed!", "error");
            finishAction({ move, failed: true });
            return;
        }
        log(`${formatPokemonName(actor)} foresaw an attack!`, "neutral");
        refresh();
        finishAction({ move, damage: 0, targetAffected: true });
        return;
    }

    const visualStartedTick = Number(system.currentTick) || 0;
    const visual = playOriginalBattleMoveEffect({
        move,
        actorEntity,
        defenderEntity,
        hit: !terminal,
        hurt: !terminal && damage > 0 && Number(battleState(defender).substituteHp) <= 0,
        isValid
    });
    let visualCompletionQueued = false;
    const completeAfterVisual = result => {
        if (visualCompletionQueued) return;
        visualCompletionQueued = true;
        const elapsed = Math.max(0, (Number(system.currentTick) || visualStartedTick) - visualStartedTick);
        const remaining = Math.max(0, visual.durationTicks - elapsed, Number(result?.followupTicks) || 0);
        const finish = () => {
            if (isValid()) finishAction(result);
        };
        if (remaining > 0) system.runTimeout(finish, remaining);
        else finish();
    };

    if (terminal?.type === BATTLE_EVENT.miss) log("But it missed.", "error");
    else if (terminal?.type === BATTLE_EVENT.fail) log("But it failed.", "error");
    else if (terminal?.type === BATTLE_EVENT.immune) log(`But ${formatPokemonName(defender)} is immune!`, "error");
    else if (terminal?.type === BATTLE_EVENT.protected) log(`${formatPokemonName(defender)} protected itself!`, "neutral");
    if (terminal) {
        if (move.selfdestruct) actor.currentHp = 0;
        if (Number(actor.currentHp) <= 0) playOriginalPokemonBattleAnimation(actorEntity, "faint");
        refresh();
        completeAfterVisual({ move, failed: true });
        return;
    }
    if (resolution.result.magnitude) log(`Magnitude ${resolution.result.magnitude}!`, "neutral");
    if (move.breaksProtect) battleState(defender).protected = false;
    const applyAtImpact = () => {
        if (!isValid()) return;
        applyDamageHitSequence({
            actor,
            defender,
            actorEntity,
            defenderEntity,
            move,
            result: resolution.result,
            isValid,
            log: (message, tone = actorSide) => log(message, tone),
            refresh,
            complete: completeAfterVisual,
            field,
            actorSide,
            defenderSide,
            actorParty,
            damageTransform,
            onDamageApplied,
            visualStartedTick,
            visualReleaseTicks: visual.releaseTicks
        });
    };
    if (visual.impactTicks > 0) system.runTimeout(applyAtImpact, visual.impactTicks);
    else applyAtImpact();
}

function resolveFutureMoveHits(field, dueMoves, pokemonForSide, log) {
    for (const futureMove of dueMoves || []) {
        const defender = pokemonForSide(futureMove.side);
        if (!defender || Number(defender.currentHp) <= 0) continue;
        const result = calculateDamage(futureMove.attacker, defender, futureMove.moveId, {
            ...damageFieldOptions(field, futureMove.side)
        });
        const applied = applyHitDamage(defender, result.damage, futureMove.attacker, moveData(futureMove.moveId));
        log(`${formatPokemonName(defender)} took the future attack!`, futureMove.side, applied.damage);
    }
}

function randomUsableBenchSlot(party, activeSlot) {
    const slots = [];
    for (let i = 0; i < (party?.length || 0); i++) if (i !== activeSlot && isUsablePokemon(party[i])) slots.push(i);
    return slots.length ? slots[Math.floor(Math.random() * slots.length)] : -1;
}

function queueMoveSwitch(session, copyVolatile, continuation) {
    const player = playerById(session.playerId);
    const hasBench = randomUsableBenchSlot(session.party, session.playerSlot) >= 0;
    if (!player || !hasBench) {
        continuation();
        return false;
    }
    session.pendingMoveSwitch = { copyVolatile: copyVolatile === true, continuation };
    session.forceSwitch = true;
    showSwitchMenu(player, session, true);
    return true;
}

function finishWildMoveAction(session, actorSide, result, continuation) {
    const move = result?.move;
    if (!move || result.failed) {
        continuation();
        return;
    }
    if (!session.raidBattle?.singlePokemon && move.forceSwitch && result.targetAffected !== false && actorSide === "wild" && !battleState(session.party[session.playerSlot]).ingrain) {
        const slot = randomUsableBenchSlot(session.party, session.playerSlot);
        if (slot >= 0) {
            const previousEntity = resolveBattlePokemonEntity(session);
            battleState(session.wildPokemon).trapped = false;
            battleState(session.wildPokemon).partialTrapTurns = 0;
            clearBattleState(session.party[session.playerSlot], true);
            session.playerSlot = slot;
            const replacementEntity = replaceActiveBattlePokemonEntity(session, previousEntity);
            resetBattleState(session.party[slot]);
            const hpBeforeHazards = Number(session.party[slot].currentHp);
            for (const message of applyEntryHazards(session.field, "player", session.party[slot])) pushLog(session, message, "player", "", "side_player");
            playFaintIfCrossed(session.party[slot], replacementEntity, hpBeforeHazards);
            pushLog(session, `${formatPokemonName(session.party[slot])} was dragged out!`, "player", "", "side_player");
            session.cancelPlayerAction = true;
        }
    }
    if (!session.raidBattle?.singlePokemon && move.selfSwitch && actorSide === "player") {
        if (queueMoveSwitch(session, move.selfSwitch === "copyvolatile", continuation)) return;
    }
    continuation();
}

function finishPlayerMoveAction(battle, session, result, continuation) {
    const move = result?.move;
    if (!move || result.failed) {
        continuation();
        return;
    }
    const opponent = opponentSession(session);
    if (move.forceSwitch && result.targetAffected !== false && opponent && !battleState(activePokemon(opponent)).ingrain) {
        const slot = randomUsableBenchSlot(opponent.party, opponent.playerSlot);
        if (slot >= 0) {
            applyPlayerBattleSwitch(battle, opponent, slot);
            pushPlayerBattleLog(battle, `${formatPokemonName(activePokemon(opponent))} was dragged out!`, session.playerId);
            if (!Array.isArray(battle.cancelledActionPlayerIds)) battle.cancelledActionPlayerIds = [];
            if (!battle.cancelledActionPlayerIds.includes(opponent.playerId)) battle.cancelledActionPlayerIds.push(opponent.playerId);
        }
    }
    if (move.selfSwitch) {
        if (queueMoveSwitch(session, move.selfSwitch === "copyvolatile", continuation)) return;
    }
    continuation();
}

function raidDamageMultiplier(session, actorSide) {
    const raid = session?.raidBattle;
    if (!raid) return 1;
    if (actorSide === "player") {
        const cheer = raid.attackCheer ? 1.5 : 1;
        const shield = raid.health?.shield ? (1 / 1.5) : 1;
        return cheer * shield;
    }
    return raid.defenseCheer ? (1 / 1.5) : 1;
}

function syncRaidBossLocal(session, proportional = false) {
    const health = raidHealth(session);
    const boss = session?.wildPokemon;
    if (!health || !boss) return;
    if (health.current <= 0) {
        boss.currentHp = 0;
        return;
    }
    const maximum = Math.max(1, Number(boss.maxHp) || 1);
    boss.currentHp = proportional
        ? Math.max(1, Math.min(maximum, Math.ceil(maximum * health.current / health.max)))
        : maximum;
}

function reportRaidBossHealthChange(session, delta, detail = {}) {
    if (!session?.raidBattle || !Number.isFinite(Number(delta)) || Number(delta) === 0) return;
    try { session.raidBattle.reportBossHealthChange?.(Number(delta), session, detail); }
    catch (error) { console.warn(`Raid shared-health callback failed: ${error}`); }
    syncRaidBossLocal(session, false);
}

function applyMoveAction(session, actorSide, moveId, complete = () => {}) {
    const actor = actorSide === "player" ? session.party[session.playerSlot] : session.wildPokemon;
    const defender = actorSide === "player" ? session.wildPokemon : session.party[session.playerSlot];
    const side = actorSide === "player" ? "player" : "opponent";
    if (session.raidBattle) syncRaidBossLocal(session, actorSide === "wild");
    const raidBossHpBefore = actorSide === "wild" && session.raidBattle
        ? Number(session.wildPokemon.currentHp) || 0
        : undefined;
    const playerPokemonEntity = resolveBattlePokemonEntity(session);
    executeMoveAction({
        actor,
        defender,
        actorEntity: actorSide === "player" ? playerPokemonEntity : session.target,
        defenderEntity: actorSide === "player" ? session.target : playerPokemonEntity,
        moveId,
        actorSide: side,
        defenderSide: side === "player" ? "opponent" : "player",
        field: session.field,
        actorParty: actorSide === "player" ? session.party : (session.trainerParty || [session.wildPokemon]),
        damageTransform: damage => {
            const raw = Math.max(0, Number(damage) || 0);
            if (raw <= 0) return 0;
            return Math.max(1, Math.floor(raw * raidDamageMultiplier(session, actorSide)));
        },
        onDamageApplied: actorSide === "player" && session.raidBattle
            ? damage => reportRaidBossHealthChange(session, damage, { source: "move", moveId })
            : undefined,
        isValid: () => validateSession(session),
        log: (message, tone = side, formatted = "", marker = "") => {
            const effectiveMarker = marker === "move"
                ? (actorSide === "player" ? "player_opponent" : "opponent_player")
                : marker;
            pushLog(session, message, tone, formatted, effectiveMarker);
        },
        formattedLog: (damage, move) => moveLogFormatting(actor, move, defender, actorSide, damage),
        refresh: () => {
            saveSession(session);
            updateBattleHud(session, true);
        },
        complete: result => {
            if (actorSide === "wild" && session.raidBattle) {
                const delta = raidBossHpBefore - (Number(session.wildPokemon.currentHp) || 0);
                reportRaidBossHealthChange(session, delta, { source: "boss_move", moveId });
            }
            finishWildMoveAction(session, actorSide, result, complete);
        }
    });
}

function trainerItemAction(session) {
    if (session.battleType !== "trainer"
        || Number(session.trainerItemUses) >= Number(session.trainerMaxItemUses)) return undefined;
    const pokemon = session.wildPokemon;
    const needsHealing = Number(pokemon.currentHp) <= Math.max(1, Math.floor(Number(pokemon.maxHp) / 3));
    const hasStatus = String(pokemon.statusCondition || "NONE").toUpperCase() !== "NONE";
    if (!needsHealing && !hasStatus) return undefined;
    const item = session.trainerBag?.find(entry => cleanMoveId(entry.item) === "full_restore" && Number(entry.quantity) > 0);
    if (!item) return undefined;
    const bias = Math.max(0, Math.min(1, Number(session.trainerAi?.itemBias) || 0));
    if (Math.random() > bias) return undefined;
    return item;
}

function useTrainerItem(session, item) {
    const pokemon = session.wildPokemon;
    pokemon.currentHp = pokemon.maxHp;
    pokemon.statusCondition = "NONE";
    item.quantity = Math.max(0, Number(item.quantity) - 1);
    session.trainerItemUses = Math.max(0, Number(session.trainerItemUses) || 0) + 1;
    pushLog(session, `${session.trainerName} used a Full Restore on ${formatPokemonName(pokemon)}!`, "opponent");
    try {
        session.target.dimension.playSound("lota.item.medicine_candy_use", session.target.location, { volume: 1, pitch: 1 });
    } catch (error) {}
}

function actionOrder(session, playerMoveIndex, wildMoveIndex, trainerSwitchSlot = -1) {
    const playerPokemon = session.party[session.playerSlot];
    const wildPokemon = session.wildPokemon;
    const playerMoveId = playerMoveIndex < 0 ? "struggle" : playerPokemon.moves[playerMoveIndex]?.id || "struggle";
    const wildMoveId = wildMoveIndex < 0 ? "struggle" : wildPokemon.moves[wildMoveIndex]?.id || "struggle";
    const playerMove = moveData(playerMoveId);
    const wildMove = moveData(wildMoveId);
    const playerSpeed = battleStats(playerPokemon).speed * speedFieldMultiplier(session.field, "player");
    const wildSpeed = battleStats(wildPokemon).speed * speedFieldMultiplier(session.field, "opponent");
    const trainerItem = trainerItemAction(session);
    const actions = [
        { side: "player", moveIndex: playerMoveIndex, priority: heldBerryActionPriority(playerPokemon, playerMove.priority), speed: playerSpeed, tie: Math.random() },
        trainerItem
            ? { side: "wild", item: trainerItem, priority: 7, speed: wildSpeed, tie: Math.random() }
            : trainerSwitchSlot >= 0
                ? { side: "wild", switchSlot: trainerSwitchSlot, priority: 6, speed: wildSpeed, tie: Math.random() }
                : { side: "wild", moveIndex: wildMoveIndex, priority: heldBerryActionPriority(wildPokemon, wildMove.priority), speed: wildSpeed, tie: Math.random() }
    ];

    actions.sort((a, b) => {
        if (b.priority !== a.priority) return b.priority - a.priority;
        if (b.speed !== a.speed) return b.speed - a.speed;
        return b.tie - a.tie;
    });
    return actions;
}

function handleFaintedPlayerPokemon(session) {
    if (Number(session.party[session.playerSlot].currentHp) <= 0) {
        pushLog(session, `${formatPokemonName(session.party[session.playerSlot])} fainted!`, "faint");
        if (session.raidBattle?.singlePokemon) {
            saveSession(session);
            return endLoss(session);
        }
        const nextSlot = firstUsableSlot(session.party, session.playerSlot + 1);
        saveSession(session);
        const player = playerById(session.playerId);
        if (nextSlot < 0) return endLoss(session);
        if (player) return showSwitchMenu(player, session, true);
    }
}

function afterTurn(session) {
    session.cancelPlayerAction = false;
    if (Number(session.wildPokemon.currentHp) <= 0) return endVictory(session);
    if (Number(session.party[session.playerSlot].currentHp) <= 0) return handleFaintedPlayerPokemon(session);

    const allyEntity = resolveBattlePokemonEntity(session);
    const wildEntity = session.target;
    const allyHpBeforeResidual = Number(session.party[session.playerSlot].currentHp);
    const wildHpBeforeResidual = Number(session.wildPokemon.currentHp);

    for (const message of applyResidualEffects(session.party[session.playerSlot], session.wildPokemon, {
        terrain: session.field?.terrain?.id || "",
        grounded: isGrounded(session.party[session.playerSlot])
    })) pushLog(session, message, "player", "", "side_player");
    for (const message of applyResidualEffects(session.wildPokemon, session.party[session.playerSlot], {
        terrain: session.field?.terrain?.id || "",
        grounded: isGrounded(session.wildPokemon)
    })) pushLog(session, message, "opponent", "", "side_opponent");
    for (const message of applyFieldResidual(session.field, session.party[session.playerSlot])) pushLog(session, message, "player", "", "side_player");
    for (const message of applyFieldResidual(session.field, session.wildPokemon)) pushLog(session, message, "opponent", "", "side_opponent");
    const dueFutureMoves = advanceBattleField(session.field);
    resolveFutureMoveHits(
        session.field,
        dueFutureMoves,
        side => side === "player" ? session.party[session.playerSlot] : session.wildPokemon,
        (message, side) => pushLog(session, message, side === "player" ? "player" : "opponent", "", side === "player" ? "side_player" : "side_opponent")
    );
    if (session.raidBattle) {
        const raidBossDelta = wildHpBeforeResidual - (Number(session.wildPokemon.currentHp) || 0);
        reportRaidBossHealthChange(session, raidBossDelta, { source: "residual" });
    }
    playFaintIfCrossed(session.party[session.playerSlot], allyEntity, allyHpBeforeResidual);
    playFaintIfCrossed(session.wildPokemon, wildEntity, wildHpBeforeResidual);
    if (Number(session.wildPokemon.currentHp) <= 0) return endVictory(session);
    if (Number(session.party[session.playerSlot].currentHp) <= 0) return handleFaintedPlayerPokemon(session);

    session.trainerSwitchCooldown = Math.max(0, (Number(session.trainerSwitchCooldown) || 0) - 1);
    session.turn = Math.max(1, Math.floor(Number(session.turn) || 1)) + 1;
    pushTurnLog(session);
    try { session.raidBattle?.onTurnStart?.(session.turn, session); }
    catch (error) { console.warn(`Raid turn callback failed: ${error}`); }
    saveSession(session);
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    const player = playerById(session.playerId);
    if (player) system.runTimeout(() => showBattleMenu(player, session), BATTLE_MENU_DELAY_TICKS);
}

function resolveWildActionSequence(session, actions, index = 0) {
    if (!validateSession(session)) return;
    if (index >= actions.length
        || Number(session.wildPokemon.currentHp) <= 0
        || Number(session.party[session.playerSlot].currentHp) <= 0) {
        system.runTimeout(() => afterTurn(session), BATTLE_TURN_END_DELAY_TICKS);
        return;
    }

    const action = actions[index];
    if (action.side === "player" && session.cancelPlayerAction) {
        session.cancelPlayerAction = false;
        system.runTimeout(() => resolveWildActionSequence(session, actions, index + 1), BATTLE_ACTION_DELAY_TICKS);
        return;
    }
    if (action.item) {
        useTrainerItem(session, action.item);
        saveSession(session);
        updateBattleHud(session, true);
        const nextIndex = index + 1;
        system.runTimeout(
            () => nextIndex >= actions.length ? afterTurn(session) : resolveWildActionSequence(session, actions, nextIndex),
            BATTLE_ACTION_DELAY_TICKS
        );
        return;
    }
    if (Number.isInteger(action.switchSlot)) {
        activateTrainerSlot(session, action.switchSlot, true);
        saveSession(session);
        updateBattleHud(session, true);
        const nextIndex = index + 1;
        system.runTimeout(
            () => nextIndex >= actions.length ? afterTurn(session) : resolveWildActionSequence(session, actions, nextIndex),
            BATTLE_ACTION_DELAY_TICKS
        );
        return;
    }
    const actor = action.side === "player" ? session.party[session.playerSlot] : session.wildPokemon;
    const selectedMove = moveData(action.moveIndex < 0 ? "struggle" : actor.moves[action.moveIndex]?.id);
    const readiness = beforeMove(actor, selectedMove);
    if (readiness.message) pushLog(session, readiness.message, action.side === "player" ? "player" : "opponent");
    if (!readiness.canMove) {
        if (readiness.confusionDamage) {
            actor.currentHp = Math.max(0, (Number(actor.currentHp) || 0) - calculateConfusionDamage(actor));
        }
        saveSession(session);
        updateBattleHud(session, true);
        const nextIndex = index + 1;
        const ended = nextIndex >= actions.length || Number(session.wildPokemon.currentHp) <= 0 || Number(session.party[session.playerSlot].currentHp) <= 0;
        system.runTimeout(
            () => ended ? afterTurn(session) : resolveWildActionSequence(session, actions, nextIndex),
            ended ? BATTLE_TURN_END_DELAY_TICKS : BATTLE_ACTION_DELAY_TICKS
        );
        return;
    }
    const consumed = consumePp(actor, action.moveIndex);
    applyMoveAction(session, action.side, consumed.id, () => {
        saveSession(session);
        updateBattleHud(session, true);
        const nextIndex = index + 1;
        const turnEnded = nextIndex >= actions.length
            || Number(session.wildPokemon.currentHp) <= 0
            || Number(session.party[session.playerSlot].currentHp) <= 0;
        if (turnEnded) {
            system.runTimeout(() => afterTurn(session), BATTLE_TURN_END_DELAY_TICKS);
        } else {
            system.runTimeout(
                () => resolveWildActionSequence(session, actions, nextIndex),
                BATTLE_ACTION_DELAY_TICKS
            );
        }
    });
}

function resolveTurn(session, selectedMoveIndex) {
    if (!validateSession(session)) return;
    resetTurnDamage(session.party[session.playerSlot]);
    resetTurnDamage(session.wildPokemon);
    const playerMoveIndex = usableMoveIndex(session.party[session.playerSlot], selectedMoveIndex);
    const trainerSwitchSlot = chooseTrainerSwitchSlot(session);
    const wildMoveIndex = trainerSwitchSlot >= 0 ? -1 : chooseOpponentMoveIndex(session);
    resolveWildActionSequence(session, actionOrder(session, playerMoveIndex, wildMoveIndex, trainerSwitchSlot));
}

function queueResolveTurn(session, selectedMoveIndex) {
    if (!validateSession(session) || session.busy) return;
    const megaRequested = session.megaPending === true;
    session.megaPending = false;
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    system.runTimeout(() => {
        if (!validateSession(session)) return;
        if (megaRequested) runMegaEvolutionSequence(session, () => resolveTurn(session, selectedMoveIndex));
        else resolveTurn(session, selectedMoveIndex);
    }, BATTLE_CHOICE_DELAY_TICKS);
}

function resolveWildOnlyTurn(session) {
    if (!validateSession(session)) return;
    resetTurnDamage(session.party[session.playerSlot]);
    resetTurnDamage(session.wildPokemon);
    const wildMoveIndex = chooseOpponentMoveIndex(session);
    const selectedMove = moveData(wildMoveIndex < 0 ? "struggle" : session.wildPokemon.moves[wildMoveIndex]?.id);
    const readiness = beforeMove(session.wildPokemon, selectedMove);
    if (readiness.message) pushLog(session, readiness.message, "opponent");
    if (!readiness.canMove) {
        if (readiness.confusionDamage) session.wildPokemon.currentHp = Math.max(0, Number(session.wildPokemon.currentHp) - calculateConfusionDamage(session.wildPokemon));
        saveSession(session);
        updateBattleHud(session, true);
        system.runTimeout(() => afterTurn(session), BATTLE_ACTION_DELAY_TICKS);
        return;
    }
    const wildMove = consumePp(session.wildPokemon, wildMoveIndex);
    applyMoveAction(session, "wild", wildMove.id, () => {
        saveSession(session);
        updateBattleHud(session, true);
        system.runTimeout(() => afterTurn(session), BATTLE_ACTION_DELAY_TICKS);
    });
}

function runFromBattle(session) {
    if (session.battleType === "pvp") {
        const opponent = opponentSession(session);
        if (opponent) finishPlayerBattle(session.pvpBattle, opponent.playerId, session.playerId);
        return;
    }
    if (session.battleType === "trainer") {
        const player = playerById(session.playerId);
        try { session.onLoss?.(player, session); } catch (error) { console.warn(`Trainer forfeit callback failed: ${error}`); }
        saveSession(session);
        clearBattle(session, { message: `§eYou forfeited against ${session.trainerName}.§r` });
        return;
    }
    if (isTrapped(activePokemon(session))) {
        pushLog(session, `${formatPokemonName(activePokemon(session))} cannot escape!`, "error");
        updateBattleHud(session, true);
        return;
    }
    saveSession(session);
    clearBattle(session, { message: "The battle was fled." });
}

function captureOutcome(session, ball, player, target) {
    return rollCaptureOutcome(calculateCaptureRate(
        session.wildPokemon,
        ball,
        true,
        {
            player,
            party: session.party,
            leadPokemon: activePokemon(session),
            leadPokemonLevel: activePokemon(session)?.level,
            targetEntity: target,
            battleTurn: session.turn,
            timeOfDay: world.getTimeOfDay(),
            moonPhase: world.getMoonPhase?.()
        }
    ));
}

function enterCaptureMode(session) {
    if (!validateSession(session) || session.busy || session.battleType !== "wild") return;
    const player = playerById(session.playerId);
    if (!player) return;
    session.formToken = (session.formToken || 0) + 1;
    session.formRequestToken = (session.formRequestToken || 0) + 1;
    session.formOpen = false;
    session.phase = "capture";
    session.busy = false;
    suspendBattleCamera(session, player);
    updateBattleHud(session, true);
    player.sendMessage("Throw a Poké Ball at your opponent to capture it.");
}

function projectileOwner(projectile, source) {
    if (source?.typeId === "minecraft:player") return source;
    try {
        const owner = projectile?.getComponent("minecraft:projectile")?.owner;
        if (owner?.typeId === "minecraft:player") return owner;
    } catch (error) {}
    return undefined;
}

function removeCaptureBall(session) {
    if (session.captureMotion) {
        session.captureMotion.cancelled = true;
        if (session.captureMotion.holdRun !== undefined) {
            try { system.clearRun(session.captureMotion.holdRun); } catch (error) {}
        }
    }
    try {
        const ball = session.captureMotion?.ball || session.captureBall;
        if (isValidEntity(ball)) ball.remove();
    } catch (error) {}
    session.captureMotion = undefined;
    session.captureBall = undefined;
}

function restoreBattleTarget(session, location = session.captureLocation) {
    if (isValidEntity(session.target)) return session.target;
    const dimension = session.captureDimension;
    if (!dimension || !session.targetTypeId || !location) return undefined;
    try {
        const target = dimension.spawnEntity(session.targetTypeId, location);
        savePokemonToEntity(target, session.wildPokemon);
        try { target.addTag(BATTLE_TAG); } catch (error) {}
        try {
            if (session.targetNameTag) target.nameTag = session.targetNameTag;
            target.setProperty("lota:is_shiny", session.wildPokemon?.isShiny ? 1 : 0);
            if (Number.isFinite(Number(session.captureScale))) {
                target.setProperty("lota:scale_factor", Math.max(0.8, Math.min(1.2, Number(session.captureScale))));
            }
        } catch (error) {}
        session.target = target;
        session.targetId = target.id;
        entityBattles.set(target.id, session.playerId);
        return target;
    } catch (error) {
        console.warn(`Battle target restore failed: ${error}`);
        return undefined;
    }
}

export function tryCaptureBattlePokemon(projectile, target, source) {
    if (!isValidEntity(projectile) || !isValidEntity(target)) return false;
    const ball = captureBallForProjectile(projectile.typeId);
    if (!ball || projectile.hasTag("lota:hit_processed")) return false;
    const playerId = entityBattles.get(target.id);
    const session = playerId ? activeBattles.get(playerId) : undefined;
    const player = projectileOwner(projectile, source);
    if (!session
        || session.battleType === "pvp"
        || (session.phase !== "capture" && session.phase !== "item")
        || session.captureInProgress) return false;
    if (!player || player.id !== session.playerId || target.id !== session.targetId) return false;
    const outcome = captureOutcome(session, ball, player, target);

    try { projectile.addTag("lota:hit_processed"); } catch (error) {}
    session.captureInProgress = true;
    session.busy = true;
    session.targetTypeId = target.typeId;
    session.targetNameTag = storedRealNameTag(target);
    session.captureDimension = target.dimension;
    session.captureLocation = { ...target.location };
    try { session.captureScale = Number(target.getProperty("lota:scale_factor")); } catch (error) {}
    pushLog(
        session,
        `${player.name} threw their ${ball.name} at ${formatPokemonName(session.wildPokemon)}!`,
        "capture_attempt"
    );
    updateBattleHud(session, true);

    const dimension = target.dimension;
    session.captureMotion = playCaptureMotion({
        projectile,
        target,
        thrower: player,
        dimension,
        ballType: ball.type,
        outcome,
        ballRefund: { ball },
        isActive: () => activeBattles.get(session.playerId) === session && session.captureInProgress,
        onAbsorbed: (absorbedPokemon) => {
            entityBattles.delete(session.targetId);
            try { if (isValidEntity(absorbedPokemon)) absorbedPokemon.remove(); } catch (error) {}
            session.target = undefined;
            session.targetId = "";
        },
        onCaught: (resultLocation) => {
            if (activeBattles.get(session.playerId) !== session) return;
            session.captureMotion = undefined;
            session.captureBall = undefined;
            const previousCaptureState = {
                caughtBall: session.wildPokemon.caughtBall,
                friendship: session.wildPokemon.friendship,
                currentHp: session.wildPokemon.currentHp,
                statusCondition: session.wildPokemon.statusCondition,
                moves: (session.wildPokemon.moves || []).map(move => ({ ...move }))
            };
            session.wildPokemon.caughtBall = ball.caughtBall;
            applyCaptureBallEffects(session.wildPokemon, ball);
            const result = addPokemonToPlayerParty(player, session.wildPokemon, session.party);
            if (result.success) {
                markCaptureEncounter(player, session.wildPokemon);
                markSpeciesCaptured(player, session.wildPokemon);
                session.captureInProgress = false;
                session.ending = true;
                pushLog(session, `Gotcha! Caught the ${formatPokemonName(session.wildPokemon)}.`, "capture_success");
                updateBattleHud(session, true);
                system.runTimeout(() => clearBattle(session), BATTLE_RESULT_DELAY_TICKS);
                return;
            }

            session.wildPokemon.caughtBall = previousCaptureState.caughtBall;
            session.wildPokemon.friendship = previousCaptureState.friendship;
            session.wildPokemon.currentHp = previousCaptureState.currentHp;
            session.wildPokemon.statusCondition = previousCaptureState.statusCondition;
            session.wildPokemon.moves = previousCaptureState.moves;
            pushLog(session, "The Pokémon could not be stored.", "error");
            const restored = restoreBattleTarget(session, resultLocation);
            session.captureInProgress = false;
            if (!restored) {
                clearBattle(session, { message: "The battle could not continue." });
                return;
            }
            session.phase = "busy";
            session.busy = true;
            saveSession(session);
            updateBattleHud(session, true);
            system.runTimeout(() => resolveWildOnlyTurn(session), BATTLE_ACTION_DELAY_TICKS);
        },
        onBreakFree: (resultLocation) => {
            if (activeBattles.get(session.playerId) !== session) return undefined;
            pushLog(session, `The ${formatPokemonName(session.wildPokemon)} broke free!`, "capture_fail");
            const restored = restoreBattleTarget(session, resultLocation);
            if (!restored) {
                session.captureInProgress = false;
                clearBattle(session, { message: "The battle could not continue." });
                return undefined;
            }
            return restored;
        },
        onBreakFreeComplete: (restored) => {
            if (activeBattles.get(session.playerId) !== session) return;
            session.captureInProgress = false;
            if (!restored) {
                clearBattle(session, { message: "The battle could not continue." });
                return;
            }
            session.phase = "busy";
            session.busy = true;
            saveSession(session);
            updateBattleHud(session, true);
            system.runTimeout(() => resolveWildOnlyTurn(session), BATTLE_ACTION_DELAY_TICKS);
            system.runTimeout(() => {
                if (session.captureMotion?.cancelled) session.captureMotion = undefined;
                if (!isValidEntity(session.captureBall)) session.captureBall = undefined;
            }, 25);
        }
    });
    session.captureBall = session.captureMotion?.ball;
    if (!session.captureMotion) {
        session.captureInProgress = false;
        session.busy = false;
        session.phase = "capture";
        try { if (isValidEntity(projectile)) projectile.remove(); } catch (error) {}
        updateBattleHud(session, true);
        return false;
    }
    return true;
}

function pushPlayerBattleLog(battle, message, actorId = "", side = "", formattedForSession, markerForSession) {
    for (const session of battle?.sessions || []) {
        const localSide = side || (actorId === session.playerId ? "player" : "opponent");
        const formatted = typeof formattedForSession === "function" ? formattedForSession(session) : "";
        let marker = "";
        if (typeof markerForSession === "function") {
            marker = markerForSession(session);
        } else if (typeof markerForSession === "string" && markerForSession) {
            marker = markerForSession;
        } else if (actorId) {
            marker = actorId === session.playerId ? "side_player" : "side_opponent";
        }
        pushLog(session, message, localSide, formatted, marker);
    }
}

function setPlayerBattleTurn(battle, turn) {
    battle.turn = turn;
    for (const session of battle.sessions) session.turn = turn;
}

function beginPlayerBattleMenus(battle, delay = BATTLE_MENU_DELAY_TICKS) {
    if (!battle || battle.ended) return;
    battle.resolving = true;
    for (const session of battle.sessions) {
        session.choice = undefined;
        session.waiting = false;
        session.phase = "busy";
        session.busy = true;
        updateBattleHud(session, true);
    }
    system.runTimeout(() => {
        if (!battle || battle.ended) return;
        battle.resolving = false;
        for (const session of battle.sessions) {
            const player = playerById(session.playerId);
            if (player) showBattleMenu(player, session);
        }
    }, delay);
}

function applyPlayerBattleSwitch(battle, session, slot, options = {}) {
    const opposingPokemon = activePokemon(opponentSession(session));
    if (opposingPokemon) {
        battleState(opposingPokemon).trapped = false;
        battleState(opposingPokemon).partialTrapTurns = 0;
    }
    const previousEntity = resolveBattlePokemonEntity(session);
    const previousState = { ...battleState(activePokemon(session)), stages: { ...battleState(activePokemon(session)).stages } };
    clearBattleState(activePokemon(session), true);
    session.playerSlot = slot;
    const replacementEntity = replaceActiveBattlePokemonEntity(session, previousEntity);
    resetBattleState(activePokemon(session));
    if (options.copyVolatile) {
        const nextState = battleState(activePokemon(session));
        nextState.stages = previousState.stages;
        for (const key of ["substituteHp", "focusEnergy", "ingrain", "aquaRing"]) {
            if (previousState[key] !== undefined) nextState[key] = previousState[key];
        }
    }
    const hpBeforeHazards = Number(activePokemon(session).currentHp);
    for (const message of applyEntryHazards(battle.field, session.playerId, activePokemon(session))) {
        pushPlayerBattleLog(battle, message, session.playerId);
    }
    playFaintIfCrossed(activePokemon(session), replacementEntity, hpBeforeHazards);
    if (!session.participants.includes(slot)) session.participants.push(slot);
    pushPlayerBattleLog(battle, `Go! ${formatPokemonName(activePokemon(session))}!`, session.playerId);
}

function applyPlayerBattleMove(battle, session, moveIndex, complete = () => {}) {
    const opponent = opponentSession(session);
    const actor = activePokemon(session);
    const defender = activePokemon(opponent);
    if (!actor || !defender || !isUsablePokemon(actor) || !isUsablePokemon(defender)) {
        complete();
        return;
    }
    if (Array.isArray(battle.cancelledActionPlayerIds) && battle.cancelledActionPlayerIds.includes(session.playerId)) {
        battle.cancelledActionPlayerIds = battle.cancelledActionPlayerIds.filter(id => id !== session.playerId);
        complete();
        return;
    }
    const usableIndex = usableMoveIndex(actor, moveIndex);
    const selectedMove = moveData(usableIndex < 0 ? "struggle" : actor.moves[usableIndex]?.id);
    const readiness = beforeMove(actor, selectedMove);
    if (readiness.message) pushPlayerBattleLog(battle, readiness.message, session.playerId);
    if (!readiness.canMove) {
        if (readiness.confusionDamage) {
            actor.currentHp = Math.max(0, (Number(actor.currentHp) || 0) - calculateConfusionDamage(actor));
        }
        complete();
        return;
    }

    const consumed = consumePp(actor, usableIndex);
    executeMoveAction({
        actor,
        defender,
        actorEntity: resolveBattlePokemonEntity(session),
        defenderEntity: resolveBattlePokemonEntity(opponent),
        moveId: consumed.id,
        actorSide: session.playerId,
        defenderSide: opponent.playerId,
        field: battle.field,
        actorParty: session.party,
        isValid: () => !battle.ended && battle.sessions.every(candidate => validateSession(candidate)),
        log: (message, tone = "", formatted = "", marker = "") => {
            const markerResolver = marker === "move"
                ? (viewer => viewer.playerId === session.playerId ? "player_opponent" : "opponent_player")
                : marker;
            pushPlayerBattleLog(battle, message, session.playerId, tone, formatted, markerResolver);
        },
        formattedLog: (damage, move) => viewer => moveLogFormatting(
            actor,
            move,
            defender,
            viewer.playerId === session.playerId ? "player" : "wild",
            damage
        ),
        refresh: () => {
            savePlayerBattle(battle);
            for (const candidate of battle.sessions) updateBattleHud(candidate, true);
        },
        complete: result => finishPlayerMoveAction(battle, session, result, complete)
    });
}

function playerBattleActionOrder(battle) {
    const actions = [];
    for (const session of battle.sessions) {
        const choice = session.choice;
        if (!choice) continue;
        const pokemon = activePokemon(session);
        if (choice.type === "switch") {
            actions.push({ session, choice, priority: 6, speed: battleStats(pokemon).speed * speedFieldMultiplier(battle.field, session.playerId), tie: Math.random() });
            continue;
        }
        const move = moveData(pokemon?.moves?.[choice.moveIndex]?.id || "struggle");
        actions.push({
            session,
            choice,
            priority: heldBerryActionPriority(pokemon, move.priority),
            speed: battleStats(pokemon).speed * speedFieldMultiplier(battle.field, session.playerId),
            tie: Math.random()
        });
    }
    actions.sort((a, b) => {
        if (b.priority !== a.priority) return b.priority - a.priority;
        if (b.speed !== a.speed) return b.speed - a.speed;
        return b.tie - a.tie;
    });
    return actions;
}

function publishRankedBattleResult(battle, winnerId, forfeitId = "") {
    if (!battle?.ranked || !winnerId) return;
    const loserId = String(battle.sessions.find(session => String(session.playerId) !== String(winnerId))?.playerId || "");
    if (!loserId) return;
    try {
        system.sendScriptEvent("lota:server_ranked_battle_result_v1", JSON.stringify({
            version: 1,
            battleId: String(battle.id),
            ranked: true,
            winnerId: String(winnerId),
            loserId,
            forfeitId: String(forfeitId || "")
        }));
    } catch (error) {
        console.warn(`[Battle] Ranked result event failed: ${error}`);
    }
}

function finishPlayerBattle(battle, winnerId = "", forfeitId = "") {
    if (!battle || battle.ended) return;
    savePlayerBattle(battle);
    let resultMessage = "";
    if (winnerId) {
        const winner = playerById(winnerId);
        const winnerSession = battle.sessions.find(session => session.playerId === winnerId);
        const loserSession = battle.sessions.find(session => session.playerId !== winnerId);
        const loser = playerById(loserSession?.playerId);
        const winnerName = winner?.name || winnerSession?.playerName || "Player";
        const loserName = loser?.name || loserSession?.playerName || "Player";
        if (forfeitId) {
            const forfeiter = playerById(forfeitId);
            const forfeiterSession = battle.sessions.find(session => session.playerId === forfeitId);
            const forfeiterName = forfeiter?.name || forfeiterSession?.playerName || "Player";
            pushPlayerBattleLog(battle, `${forfeiterName} forfeited the battle!`, "", "loss");
            resultMessage = `${forfeiterName} forfeited the battle!\n${winnerName} won!`;
        } else {
            pushPlayerBattleLog(battle, `${loserName} is out of usable Pokemon!`, "", "loss");
            resultMessage = `${loserName} is out of usable Pokemon!\n${winnerName} won!`;
        }
        pushPlayerBattleLog(battle, `${winnerName} won!`, "", "win");
    }
    publishRankedBattleResult(battle, winnerId, forfeitId);
    clearPlayerBattle(battle, { winnerId, resultMessage });
}

function afterPlayerBattleTurn(battle) {
    if (!battle || battle.ended) return;
    battle.cancelledActionPlayerIds = [];
    const fainted = [];
    const directlyFainted = battle.sessions.some(
        session => Number(activePokemon(session)?.currentHp) <= 0
    );
    const residualStates = battle.sessions.map(session => ({
        session,
        pokemon: activePokemon(session),
        entity: resolveBattlePokemonEntity(session),
        hp: Number(activePokemon(session)?.currentHp)
    }));
    if (!directlyFainted) {
        for (const session of battle.sessions) {
            for (const message of applyResidualEffects(activePokemon(session), activePokemon(opponentSession(session)), {
                terrain: battle.field?.terrain?.id || "",
                grounded: isGrounded(activePokemon(session))
            })) pushPlayerBattleLog(battle, message, session.playerId);
            for (const message of applyFieldResidual(battle.field, activePokemon(session))) pushPlayerBattleLog(battle, message, session.playerId);
        }
    }
    const dueFutureMoves = advanceBattleField(battle.field);
    resolveFutureMoveHits(
        battle.field,
        dueFutureMoves,
        side => activePokemon(battle.sessions.find(session => session.playerId === side)),
        (message, side) => pushPlayerBattleLog(battle, message, side)
    );
    for (const state of residualStates) {
        playFaintIfCrossed(state.pokemon, state.entity, state.hp);
    }
    for (const session of battle.sessions) {
        if (Number(activePokemon(session)?.currentHp) <= 0) {
            fainted.push(session);
            pushPlayerBattleLog(
                battle,
                `${formatPokemonName(activePokemon(session))} fainted!`,
                session.playerId,
                "faint"
            );
        }
    }

    const usable = battle.sessions.map(session => firstUsableSlot(session.party, session.playerSlot));
    if (usable[0] < 0 && usable[1] < 0) return finishPlayerBattle(battle);
    if (usable[0] < 0) return finishPlayerBattle(battle, battle.sessions[1].playerId);
    if (usable[1] < 0) return finishPlayerBattle(battle, battle.sessions[0].playerId);

    savePlayerBattle(battle);
    if (fainted.length) {
        battle.resolving = false;
        for (const session of battle.sessions) {
            session.choice = undefined;
            if (fainted.includes(session)) {
                const player = playerById(session.playerId);
                if (player) showSwitchMenu(player, session, true);
            } else {
                session.waiting = true;
                session.phase = "busy";
                session.busy = true;
                updateBattleHud(session, true);
            }
        }
        return;
    }

    const nextTurn = Math.max(1, Number(battle.turn) || 1) + 1;
    setPlayerBattleTurn(battle, nextTurn);
    for (const session of battle.sessions) pushTurnLog(session);
    beginPlayerBattleMenus(battle);
}

function resolvePlayerBattleActionSequence(battle, actions, index = 0) {
    if (!battle || battle.ended || !battle.sessions.every(session => validateSession(session))) return;

    const activePokemonFainted = battle.sessions.some(
        session => Number(activePokemon(session)?.currentHp) <= 0
    );
    if (index >= actions.length || activePokemonFainted) {
        system.runTimeout(() => afterPlayerBattleTurn(battle), BATTLE_TURN_END_DELAY_TICKS);
        return;
    }

    const action = actions[index];
    const finishAction = () => {
        savePlayerBattle(battle);
        for (const session of battle.sessions) updateBattleHud(session, true);

        const nextIndex = index + 1;
        const turnEnded = nextIndex >= actions.length || battle.sessions.some(
            session => Number(activePokemon(session)?.currentHp) <= 0
        );
        if (turnEnded) {
            system.runTimeout(() => afterPlayerBattleTurn(battle), BATTLE_TURN_END_DELAY_TICKS);
        } else {
            system.runTimeout(
                () => resolvePlayerBattleActionSequence(battle, actions, nextIndex),
                BATTLE_ACTION_DELAY_TICKS
            );
        }
    };
    if (action.choice.type === "switch") {
        applyPlayerBattleSwitch(battle, action.session, action.choice.slot);
        finishAction();
    } else {
        applyPlayerBattleMove(battle, action.session, action.choice.moveIndex, finishAction);
    }
}

function resolvePlayerBattleTurn(battle) {
    if (!battle || battle.ended || !battle.sessions.every(session => session.choice)) return;
    for (const session of battle.sessions) resetTurnDamage(activePokemon(session));
    battle.resolving = true;
    const megaSessions = battle.sessions.filter(
        session => session.choice?.type === "move" && session.choice?.mega === true
    );
    const runMega = index => {
        if (!battle || battle.ended || !battle.sessions.every(session => validateSession(session))) return;
        if (index >= megaSessions.length) {
            resolvePlayerBattleActionSequence(battle, playerBattleActionOrder(battle));
            return;
        }
        runMegaEvolutionSequence(megaSessions[index], () => runMega(index + 1));
    };
    runMega(0);
}

function submitPlayerBattleChoice(session, choice) {
    if (!validateSession(session) || session.busy || session.choice) return;
    const battle = session.pvpBattle;
    session.choice = choice;
    session.waiting = true;
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    if (!battle.sessions.every(candidate => candidate.choice)) return;

    for (const candidate of battle.sessions) {
        candidate.waiting = false;
        updateBattleHud(candidate, true);
    }
    system.runTimeout(() => resolvePlayerBattleTurn(battle), BATTLE_CHOICE_DELAY_TICKS);
}

function handleForcedPlayerSwitch(session, slot) {
    if (!validateSession(session) || !session.forceSwitch) return;
    if (slot < 0 || slot >= session.party.length || !isUsablePokemon(session.party[slot])) {
        pushLog(session, "That Pokemon cannot battle.", "error");
        updateBattleHud(session, true);
        return;
    }
    const battle = session.pvpBattle;
    const pendingMoveSwitch = session.pendingMoveSwitch;
    session.forceSwitch = false;
    session.waiting = false;
    session.pendingMoveSwitch = undefined;
    applyPlayerBattleSwitch(battle, session, slot, { copyVolatile: pendingMoveSwitch?.copyVolatile });
    saveSession(session);

    if (pendingMoveSwitch) {
        updateBattleHud(session, true);
        pendingMoveSwitch.continuation();
        return;
    }

    const stillChoosing = battle.sessions.some(candidate => candidate.forceSwitch);
    if (stillChoosing) {
        session.phase = "busy";
        session.busy = true;
        session.waiting = true;
        updateBattleHud(session, true);
        return;
    }

    const nextTurn = Math.max(1, Number(battle.turn) || 1) + 1;
    setPlayerBattleTurn(battle, nextTurn);
    for (const candidate of battle.sessions) pushTurnLog(candidate);
    beginPlayerBattleMenus(battle, BATTLE_MENU_DELAY_TICKS);
}

function handleSwitchSelection(session, slot) {
    const player = playerById(session.playerId);
    if (!player) return;
    if (slot < 0 || slot >= session.party.length) {
        reopenBattleForm(session, 1);
        return;
    }
    if (slot === session.playerSlot) {
        reopenBattleForm(session, 1);
        return;
    }
    if (!isUsablePokemon(session.party[slot])) {
        pushLog(session, "That Pokemon cannot battle.", "error");
        updateBattleHud(session, true);
        reopenBattleForm(session, 1);
        return;
    }
    if (!session.forceSwitch && isTrapped(activePokemon(session))) {
        pushLog(session, `${formatPokemonName(activePokemon(session))} cannot escape!`, "error");
        updateBattleHud(session, true);
        reopenBattleForm(session, 1);
        return;
    }

    if (session.battleType === "pvp") {
        if (session.forceSwitch) return handleForcedPlayerSwitch(session, slot);
        return submitPlayerBattleChoice(session, { type: "switch", slot });
    }

    const pendingMoveSwitch = session.pendingMoveSwitch;
    const previousEntity = resolveBattlePokemonEntity(session);
    const previousState = { ...battleState(session.party[session.playerSlot]), stages: { ...battleState(session.party[session.playerSlot]).stages } };
    battleState(session.wildPokemon).trapped = false;
    battleState(session.wildPokemon).partialTrapTurns = 0;
    clearBattleState(session.party[session.playerSlot], true);
    session.playerSlot = slot;
    const replacementEntity = replaceActiveBattlePokemonEntity(session, previousEntity);
    resetBattleState(session.party[slot]);
    if (pendingMoveSwitch?.copyVolatile) {
        const nextState = battleState(session.party[slot]);
        nextState.stages = previousState.stages;
        for (const key of ["substituteHp", "focusEnergy", "ingrain", "aquaRing"]) {
            if (previousState[key] !== undefined) nextState[key] = previousState[key];
        }
    }
    const hpBeforeHazards = Number(session.party[slot].currentHp);
    for (const message of applyEntryHazards(session.field, "player", session.party[slot])) pushLog(session, message, "player", "", "side_player");
    playFaintIfCrossed(session.party[slot], replacementEntity, hpBeforeHazards);
    if (!session.participants.includes(slot)) session.participants.push(slot);
    pushLog(session, `Go! ${formatPokemonName(session.party[slot])}!`, "player", "", "side_player");
    saveSession(session);
    if (pendingMoveSwitch) {
        session.pendingMoveSwitch = undefined;
        session.forceSwitch = false;
        pendingMoveSwitch.continuation();
        return;
    }
    if (session.forceSwitch) return showBattleMenu(player, session);
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    system.runTimeout(() => resolveWildOnlyTurn(session), 8);
}

function enterItemMode(session) {
    if (!validateSession(session) || session.busy) return;
    const player = playerById(session.playerId);
    if (!player) return;
    session.formToken = (session.formToken || 0) + 1;
    session.formRequestToken = (session.formRequestToken || 0) + 1;
    session.formOpen = false;
    session.pendingBattleItem = undefined;
    session.phase = "item";
    session.busy = false;
    suspendBattleCamera(session, player);
    updateBattleHud(session, true);
}

function completeItemModeTurn(session, itemAction) {
    if (!validateSession(session)
        || session.busy
        || session.phase !== "item"
        || session.captureInProgress) return;

    if (session.battleType === "pvp") {
        submitPlayerBattleChoice(session, { type: "item", itemAction });
        return;
    }

    if (itemAction && !applyBattleItemAction(session, itemAction)) return;

    resumeBattleCamera(session, playerById(session.playerId));
    session.phase = "busy";
    session.busy = true;
    updateBattleHud(session, true);
    system.runTimeout(() => resolveWildOnlyTurn(session), BATTLE_ACTION_DELAY_TICKS);
}

function isCreativePlayer(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function consumeHeldBattleItem(player, slot, itemId) {
    if (isCreativePlayer(player)) return { success: true, consumed: false };
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const stack = container?.getItem(slot);
        if (!container || stack?.typeId !== itemId) return { success: false, consumed: false };
        if (stack.amount <= 1) container.setItem(slot, undefined);
        else {
            stack.amount -= 1;
            container.setItem(slot, stack);
        }
        return { success: true, consumed: true };
    } catch (error) {
        return { success: false, consumed: false };
    }
}

function giveBattleReturnItem(player, itemId) {
    if (!player || !itemId) return;
    try {
        const stack = new ItemStack(itemId, 1);
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) {
            player.dimension.spawnItem(stack, player.location);
            return;
        }
        const remainder = container.addItem(stack);
        if (remainder) player.dimension.spawnItem(remainder, player.location);
    } catch (error) {}
}

function applyBattleItemAction(session, action) {
    const item = BATTLE_ITEMS[action?.itemId];
    const slot = Math.floor(Number(action?.slot));
    const pokemon = session.party?.[slot];
    if (!item || !pokemon || !item.canUse(pokemon)) return false;
    const result = applyBattleItemEffect(action.itemId, pokemon, action);
    if (!result) return false;
    for (const message of result.messages) {
        if (session.battleType === "pvp") pushPlayerBattleLog(session.pvpBattle, message, session.playerId);
        else pushLog(session, message, "player");
    }
    if (action.consumed && result.returnItem) giveBattleReturnItem(playerById(session.playerId), result.returnItem);
    saveSession(session);
    return true;
}

function beginBattleItemTargeting(session, player, itemId) {
    const item = BATTLE_ITEMS[itemId];
    if (!item || !validateSession(session) || session.phase !== "item" || session.busy) return false;
    const firstTarget = session.party.findIndex(pokemon => pokemon && item.canUse(pokemon));
    if (firstTarget < 0) {
        player.sendMessage("It won't have any effect.");
        return false;
    }
    session.pendingBattleItem = {
        itemId,
        inventorySlot: player.selectedSlotIndex
    };
    session.phase = "item_target";
    session.cursor = firstTarget;
    session.busy = false;
    resetNavigationAnchor(session, player);
    updateBattleHud(session, true);
    return true;
}

function handleBattleItemTargetSelection(session, slot) {
    const player = playerById(session.playerId);
    const pending = session.pendingBattleItem;
    const item = BATTLE_ITEMS[pending?.itemId];
    const pokemon = session.party?.[slot];
    if (!player || !pending || !item) return enterItemMode(session);
    if (!pokemon || !item.canUse(pokemon)) {
        player.sendMessage("It won't have any effect.");
        reopenBattleForm(session, 1);
        return;
    }
    if (item.requiresMove) {
        const firstMove = (pokemon.moves || []).findIndex(move => item.canUseMove(move));
        if (firstMove < 0) {
            player.sendMessage("It won't have any effect.");
            reopenBattleForm(session, 1);
            return;
        }
        pending.targetSlot = slot;
        session.phase = "item_move_target";
        session.cursor = firstMove;
        resetNavigationAnchor(session, player);
        updateBattleHud(session, true);
        return;
    }

    commitBattleItemSelection(session, slot);
}

function returnToBattleItemTargeting(session) {
    const player = playerById(session.playerId);
    if (!player || !session.pendingBattleItem) return enterItemMode(session);
    session.phase = "item_target";
    session.cursor = Math.max(0, Math.floor(Number(session.pendingBattleItem.targetSlot) || 0));
    delete session.pendingBattleItem.targetSlot;
    resetNavigationAnchor(session, player);
    updateBattleHud(session, true);
}

function commitBattleItemSelection(session, slot, moveIndex = undefined) {
    const player = playerById(session.playerId);
    const pending = session.pendingBattleItem;
    const item = BATTLE_ITEMS[pending?.itemId];
    const pokemon = session.party?.[slot];
    if (!player || !pending || !item || !pokemon || !item.canUse(pokemon)) return enterItemMode(session);
    if (item.requiresMove && !item.canUseMove(pokemon.moves?.[moveIndex])) {
        player.sendMessage("It won't have any effect.");
        reopenBattleForm(session, 1);
        return;
    }

    const consumption = consumeHeldBattleItem(player, pending.inventorySlot, pending.itemId);
    if (!consumption.success) {
        player.sendMessage("That item is no longer held.");
        return enterItemMode(session);
    }

    const itemAction = { itemId: pending.itemId, slot, moveIndex, consumed: consumption.consumed };
    session.pendingBattleItem = undefined;
    if (session.battleType === "pvp") {
        session.phase = "item";
        completeItemModeTurn(session, itemAction);
        return;
    }
    session.phase = "item";
    completeItemModeTurn(session, itemAction);
}

function handleBattleConfirm(session) {
    if (!validateSession(session) || session.busy) return;
    const player = playerById(session.playerId);
    if (!player) return;

    if (session.phase === "menu") {
        if (session.cursor === 0) return showMoveMenu(player, session);
        if (session.cursor === 1) {
            if (session.raidBattle?.singlePokemon) {
                pushLog(session, "Only the selected Pokemon may enter this raid.", "error");
                updateBattleHud(session, true);
                return;
            }
            return showSwitchMenu(player, session, false);
        }
        if (session.cursor === 2) {
            if (session.raidBattle) return showRaidCheerMenu(player, session);
            if (session.battleType === "pvp") {
                pushLog(session, "Items cannot be used in this battle.", "error");
                updateBattleHud(session, true);
                return;
            }
            return enterItemMode(session);
        }
        if (session.cursor === 3) return runFromBattle(session);
        return;
    }

    if (session.phase === "raid_cheer") {
        const cheerTypes = ["attack", "defense", "heal"];
        const cheerType = cheerTypes[session.cursor];
        if (cheerType) return useRaidCheer(session, cheerType);
        return;
    }

    if (session.phase === "moves") {
        const move = activePokemon(session)?.moves?.[session.cursor];
        if (!move) {
            updateBattleHud(session, true);
            return;
        }
        const activeState = battleState(activePokemon(session));
        const continuingMove = activeState.chargingMoveId === move.id || activeState.lockedMoveId === move.id;
        if (!continuingMove && Number(move.pp) <= 0 && activePokemon(session).moves.some(candidate => Number(candidate.pp) > 0)) {
            pushLog(session, `${moveData(move.id).name} has no PP left!`, "error");
            updateBattleHud(session, true);
            return;
        }
        const selectionFailure = moveSelectionFailure(activePokemon(session), moveData(move.id));
        if (selectionFailure) {
            pushLog(session, selectionFailure, "error");
            updateBattleHud(session, true);
            return;
        }
        const raidMoveId = cleanMoveId(move.id);
        if (session.raidBattle?.moveBlacklist?.has(raidMoveId)) {
            pushLog(session, `${moveData(move.id).name} cannot be used in a raid.`, "error");
            updateBattleHud(session, true);
            return;
        }
        if (session.battleType === "pvp") {
            const megaRequested = session.megaPending === true;
            session.megaPending = false;
            return submitPlayerBattleChoice(session, {
                type: "move",
                moveIndex: session.cursor,
                mega: megaRequested
            });
        }
        return queueResolveTurn(session, session.cursor);
    }

    if (session.phase === "switch") {
        return handleSwitchSelection(session, session.cursor);
    }
    if (session.phase === "item_target") return handleBattleItemTargetSelection(session, session.cursor);
    if (session.phase === "item_move_target") return commitBattleItemSelection(session, session.pendingBattleItem?.targetSlot, session.cursor);
}

function handleBattleBack(session) {
    if (!validateSession(session) || session.busy) return;
    const player = playerById(session.playerId);
    if (!player) return;
    if (session.phase === "moves") return showBattleMenu(player, session);
    if (session.phase === "raid_cheer") return showBattleMenu(player, session);
    if (session.phase === "switch" && !session.forceSwitch) return showBattleMenu(player, session);
    if (session.phase === "item_target") return enterItemMode(session);
    if (session.phase === "item_move_target") return returnToBattleItemTargeting(session);
    updateBattleHud(session, true);
}

function cursorLimit(session) {
    if (session.phase === "menu") return 4;
    if (session.phase === "switch" || session.phase === "item_target") return Math.max(1, Math.min(6, session.party.length));
    if (session.phase === "item_move_target") return 4;
    if (session.phase === "raid_cheer") return 4;
    return 4;
}

function moveCursor(session, dx, dy) {
    const count = cursorLimit(session);
    const columns = 2;
    let cursor = Math.max(0, Math.min(count - 1, Math.floor(Number(session.cursor) || 0)));
    let col = cursor % columns;
    let row = Math.floor(cursor / columns);
    if (dx !== 0) col = Math.max(0, Math.min(columns - 1, col + dx));
    if (dy !== 0) row = Math.max(0, row + dy);
    let next = row * columns + col;
    if (next >= count) next = count - 1;
    if (next !== cursor) {
        session.cursor = next;
        updateBattleHud(session, true);
    }
}

function resetNavigationAnchor(session, player) {
    session.lastNavigationTick = 0;
}

function processDirectionalInput(session, player) {
    if (session.formOpen || session.phase === "capture" || session.phase === "item") return;
    if (session.busy || session.phase === "busy") return;
    const tick = system.currentTick;
    if (session.lastNavigationTick && session.lastNavigationTick + NAVIGATION_COOLDOWN_TICKS > tick) return;
    let input;
    try { input = player.inputInfo.getMovementVector(); } catch (error) { return; }
    const x = Number(input?.x) || 0; const y = Number(input?.y) || 0;
    if (Math.abs(x) < 0.55 && Math.abs(y) < 0.55) return;
    session.lastNavigationTick = tick;
    if (Math.abs(x) >= Math.abs(y)) moveCursor(session, x > 0 ? 1 : -1, 0);
    else moveCursor(session, 0, y > 0 ? -1 : 1);
}

function playerFromProjectileEvent(event) {
    const source = event.source;
    if (source?.typeId === "minecraft:player") return source;
    try {
        const owner = event.projectile?.getComponent("minecraft:projectile")?.owner;
        if (owner?.typeId === "minecraft:player") return owner;
    } catch (error) {}
    return undefined;
}

function playerDistanceSquared(first, second) {
    const dx = Number(first?.location?.x || 0) - Number(second?.location?.x || 0);
    const dy = Number(first?.location?.y || 0) - Number(second?.location?.y || 0);
    const dz = Number(first?.location?.z || 0) - Number(second?.location?.z || 0);
    return dx * dx + dy * dy + dz * dz;
}

function wildBattleOutOfRange(session, player) {
    const target = isValidEntity(session.target) ? session.target : undefined;
    const anchor = target?.location || session.captureLocation;
    const dimension = target?.dimension || session.captureDimension;
    if (!anchor || !dimension || !player) return false;
    if (player.dimension?.id !== dimension.id) return true;
    const dx = Number(player.location?.x || 0) - Number(anchor.x || 0);
    const dy = Number(player.location?.y || 0) - Number(anchor.y || 0);
    const dz = Number(player.location?.z || 0) - Number(anchor.z || 0);
    return dx * dx + dy * dy + dz * dz > WILD_BATTLE_FLEE_DISTANCE * WILD_BATTLE_FLEE_DISTANCE;
}

function fleeWildBattle(session) {
    if (!session || session.battleType === "pvp") return;
    if (session.battleType === "trainer") {
        const player = playerById(session.playerId);
        try { session.onLoss?.(player, session); } catch (error) { console.warn(`Trainer range-forfeit callback failed: ${error}`); }
        clearBattle(session, { message: `§eYou moved too far away from ${session.trainerName}.§r` });
        return;
    }
    session.wildPokemon.currentHp = session.wildPokemon.maxHp;
    if (session.captureInProgress) {
        removeCaptureBall(session);
        restoreBattleTarget(session, session.captureLocation);
        session.captureInProgress = false;
    }
    saveSession(session);
    clearBattle(session, { message: "§eThe battle was fled.§r" });
}

function playersCanChallenge(first, second) {
    if (!first || !second || first.id === second.id) return false;
    if (first.dimension?.id !== second.dimension?.id) return false;
    return playerDistanceSquared(first, second) <= PLAYER_CHALLENGE_DISTANCE * PLAYER_CHALLENGE_DISTANCE;
}

function viewedPlayer(player) {
    try {
        const hits = player.getEntitiesFromViewDirection({ maxDistance: PLAYER_CHALLENGE_DISTANCE });
        for (const hit of hits) {
            if (hit?.entity?.typeId === "minecraft:player" && hit.entity.id !== player.id) return hit.entity;
        }
    } catch (error) {}
    return undefined;
}

function preparedPlayerParty(player) {
    const party = loadPartyFromPlayer(player);
    party.forEach(resetEvolutionBattleProgress);
    if (!party.length) return undefined;
    const changed = normalizeParty(party);
    const preferred = selectedSlot(player, party);
    const slot = firstUsableSlot(party, preferred);
    if (changed) savePartyToPlayer(player, party);
    if (slot < 0) return undefined;
    if (slot !== preferred) player.setDynamicProperty(SELECTED_SLOT_PROPERTY, slot);
    return { party, slot };
}

function createPlayerBattleSession(player, prepared) {
    return {
        battleType: "pvp",
        playerId: player.id,
        playerName: player.name,
        party: prepared.party,
        playerSlot: prepared.slot,
        participants: [prepared.slot],
        log: [],
        turn: 0,
        logExpanded: false,
        logScroll: 0,
        phase: "menu",
        cursor: 0,
        forceSwitch: false,
        busy: false,
        waiting: false,
        choice: undefined,
        megaPending: false,
        megaUsed: false,
        lastNavigationTick: 0,
        lastHudTick: 0,
        formOpen: false,
        formToken: 0,
        formRequestToken: 0,
        formBusyRetries: 0
    };
}

function startPlayerBattle(challenger, receiver) {
    if (!playersCanChallenge(challenger, receiver)) return false;
    if (activeBattles.has(challenger.id) || activeBattles.has(receiver.id)) return false;

    const firstPrepared = preparedPlayerParty(challenger);
    const secondPrepared = preparedPlayerParty(receiver);
    if (!firstPrepared || !secondPrepared) return false;

    const firstSession = createPlayerBattleSession(challenger, firstPrepared);
    const secondSession = createPlayerBattleSession(receiver, secondPrepared);
    const battle = {
        id: nextPlayerBattleId++,
        sessions: [firstSession, secondSession],
        field: createBattleField(),
        turn: 0,
        resolving: false,
        ended: false,
        ranked: challenger.getDynamicProperty("lota:ranked_opt_in_v1") === true
            && receiver.getDynamicProperty("lota:ranked_opt_in_v1") === true
    };
    firstSession.pvpBattle = battle;
    secondSession.pvpBattle = battle;
    activeBattles.set(challenger.id, firstSession);
    activeBattles.set(receiver.id, secondSession);

    pushTurnLog(firstSession);
    pushTurnLog(secondSession);
    pushLog(firstSession, `Go! ${formatPokemonName(activePokemon(firstSession))}!`, "player", "", "side_player");
    pushLog(firstSession, `Go! ${formatPokemonName(activePokemon(secondSession))}!`, "opponent", "", "side_opponent");
    pushLog(secondSession, `Go! ${formatPokemonName(activePokemon(secondSession))}!`, "player", "", "side_player");
    pushLog(secondSession, `Go! ${formatPokemonName(activePokemon(firstSession))}!`, "opponent", "", "side_opponent");
    setPlayerBattleTurn(battle, 1);
    pushTurnLog(firstSession);
    pushTurnLog(secondSession);
    savePlayerBattle(battle);
    lockBattleEntities(firstSession);
    lockBattleEntities(secondSession);
    showBattleMenu(challenger, firstSession);
    showBattleMenu(receiver, secondSession);
    return true;
}

function clearChallenge(challenge) {
    if (!challenge) return;
    if (outgoingChallenges.get(challenge.challengerId)?.id === challenge.id) {
        outgoingChallenges.delete(challenge.challengerId);
    }
    if (incomingChallenges.get(challenge.receiverId)?.id === challenge.id) {
        incomingChallenges.delete(challenge.receiverId);
    }
    challenge.active = false;
}

function declineChallenge(challenge) {
    if (!challenge?.active) return;
    const challenger = playerById(challenge.challengerId);
    const receiver = playerById(challenge.receiverId);
    clearChallenge(challenge);
    if (challenger && receiver) challenger.sendMessage(`${receiver.name} declined your challenge...`);
    if (challenger && receiver) receiver.sendMessage(`You declined ${challenger.name}'s challenge.`);
}

function acceptChallenge(challenge) {
    if (!challenge?.active) return;
    const challenger = playerById(challenge.challengerId);
    const receiver = playerById(challenge.receiverId);
    clearChallenge(challenge);
    if (!challenger || !receiver || !playersCanChallenge(challenger, receiver)) return;
    challenger.sendMessage(`${receiver.name} accepted the challenge!`);
    receiver.sendMessage(`You accepted ${challenger.name}'s challenge!`);
    if (!startPlayerBattle(challenger, receiver)) {
        challenger.sendMessage("The battle could not be started.");
        receiver.sendMessage("The battle could not be started.");
    }
}

function openIncomingChallenge(challenge, attempt = 0) {
    if (!challenge?.active) return;
    const challenger = playerById(challenge.challengerId);
    const receiver = playerById(challenge.receiverId);
    if (!challenger || !receiver) {
        clearChallenge(challenge);
        return;
    }
    new ActionFormData()
        .title("cobbledrock.challenge.received")
        .body(`${challenger.name} challenged you to a Single Battle!\nAnything Goes`)
        .button("Accept")
        .button("Decline")
        .show(receiver)
        .then(response => {
            if (!challenge.active) return;
            if (response.canceled) return declineChallenge(challenge);
            if (response.selection === 0) acceptChallenge(challenge);
            else declineChallenge(challenge);
        })
        .catch(() => {
            if (!challenge.active) return;
            if (attempt < 3) system.runTimeout(() => openIncomingChallenge(challenge, attempt + 1), 10);
            else declineChallenge(challenge);
        });
}

function sendPlayerChallenge(challenger, receiver) {
    if (!playersCanChallenge(challenger, receiver)) return;
    if (activeBattles.has(challenger.id) || activeBattles.has(receiver.id)) return;
    if (!preparedPlayerParty(challenger)) {
        challenger.sendMessage("You don't have any Pokemon to battle with!");
        return;
    }
    if (!preparedPlayerParty(receiver)) {
        challenger.sendMessage(`${receiver.name} doesn't have any Pokemon to battle with!`);
        return;
    }
    const duplicate = outgoingChallenges.get(challenger.id);
    if (duplicate?.active) {
        challenger.sendMessage(`You already have a pending battle request sent to ${receiver.name}.`);
        return;
    }
    const reverse = incomingChallenges.get(challenger.id);
    if (reverse?.active && reverse.challengerId === receiver.id) {
        challenger.sendMessage(`${receiver.name} already has a pending battle request for you.`);
        return;
    }
    const receiverPending = incomingChallenges.get(receiver.id) || outgoingChallenges.get(receiver.id);
    if (receiverPending?.active) {
        challenger.sendMessage(`${receiver.name} already has a pending battle request.`);
        return;
    }

    const challenge = {
        id: nextChallengeId++,
        challengerId: challenger.id,
        receiverId: receiver.id,
        active: true
    };
    outgoingChallenges.set(challenger.id, challenge);
    incomingChallenges.set(receiver.id, challenge);
    challenger.sendMessage(`You challenged ${receiver.name} to a Single Battle.`);
    receiver.sendMessage(`${challenger.name} challenged you to a Single Battle!`);
    openIncomingChallenge(challenge);
    system.runTimeout(() => {
        if (!challenge.active) return;
        const currentChallenger = playerById(challenge.challengerId);
        const currentReceiver = playerById(challenge.receiverId);
        clearChallenge(challenge);
        if (currentChallenger && currentReceiver) {
            currentChallenger.sendMessage(`Your challenge to ${currentReceiver.name} has timed out!`);
            currentReceiver.sendMessage(`The challenge from ${currentChallenger.name} has timed out!`);
        }
    }, PLAYER_CHALLENGE_TIMEOUT_TICKS);
}

function openChallengeConfiguration(challenger, receiver) {
    new ActionFormData()
        .title("cobbledrock.challenge.configure")
        .body(`${receiver.name}\nSingle Battle\nAnything Goes`)
        .button("Single Battle")
        .show(challenger)
        .then(response => {
            if (response.canceled || response.selection !== 0) return;
            sendPlayerChallenge(challenger, receiver);
        })
        .catch(() => {});
}

export function tryStartPlayerChallenge(player) {
    if (!player || activeBattles.has(player.id)) return false;
    const target = viewedPlayer(player);
    if (!target) return false;
    system.run(() => openChallengeConfiguration(player, target));
    return true;
}

export function finishRaidTrainerBattle(playerId) {
    const session = activeBattles.get(String(playerId || ""));
    if (!session?.raidBattle || session.battleType !== "trainer") return false;
    if (session.raidBattle.health) session.raidBattle.health.current = 0;
    session.wildPokemon.currentHp = 0;
    endVictory(session);
    return true;
}

export function abortRaidTrainerBattle(playerId, detail = "raid_aborted", message = "§cThe raid was aborted.§r") {
    const session = activeBattles.get(String(playerId || ""));
    if (!session?.raidBattle || session.battleType !== "trainer") return false;
    const player = playerById(session.playerId);
    try { session.onAbort?.(player, session, detail); }
    catch (error) { console.warn(`Raid abort callback failed: ${error}`); }
    clearBattle(session, { message });
    return true;
}

export function refreshRaidTrainerBattle(playerId) {
    const session = activeBattles.get(String(playerId || ""));
    if (!session?.raidBattle) return false;
    saveSession(session);
    updateBattleHud(session, true);
    return true;
}

export function applyRaidTrainerBattleActions(playerId, actions = []) {
    const session = activeBattles.get(String(playerId || ""));
    if (!session?.raidBattle) return false;
    for (const action of actions) {
        if (action === "RESET_BOSS") {
            resetBattleState(session.wildPokemon);
            pushLog(session, `${formatPokemonName(session.wildPokemon)} nullified its stat changes and conditions!`, "opponent");
        } else if (action === "RESET_PLAYER") {
            resetBattleState(activePokemon(session));
            pushLog(session, `${formatPokemonName(activePokemon(session))}'s stat changes and conditions were nullified!`, "player");
        } else if (action === "BOSS_STAT_DEF_1") {
            const state = battleState(session.wildPokemon);
            state.stages.def = Math.min(6, (Number(state.stages.def) || 0) + 1);
            pushLog(session, `${formatPokemonName(session.wildPokemon)}'s Defense rose!`, "opponent");
        } else if (action === "SHIELD_UP") {
            pushLog(session, `${formatPokemonName(session.wildPokemon)} put up a shield!`, "opponent");
        } else if (action === "SHIELD_DOWN") {
            pushLog(session, `${formatPokemonName(session.wildPokemon)}'s shield broke!`, "player");
        }
    }
    updateBattleHud(session, true);
    return true;
}

export function startTrainerBattle(player, trainerEntity, options = {}) {
    if (!isValidEntity(player) || !isValidEntity(trainerEntity)) return false;
    const existing = activeBattles.get(player.id);
    if (existing) {
        updateBattleHud(existing, true);
        return false;
    }

    const trainerParty = (options.party || []).filter(Boolean);
    if (!trainerParty.length) return false;
    for (const pokemon of trainerParty) {
        normalizePokemonForBattle(pokemon);
        normalizePokemonExperience(pokemon);
        pokemon.currentHp = pokemon.maxHp;
    }

    const party = loadPartyFromPlayer(player);
    if (!party.length) {
        player.sendMessage("You have no Pokemon.");
        return false;
    }
    const levelCap = Math.max(1, Math.min(100, Number(options.levelCap) || getEffectiveLevelCap(player)));
    if (options.enforceLevelCap) {
        const overCap = party.find(pokemon => pokemon && Number(pokemon.level) > levelCap);
        if (overCap) {
            player.sendMessage({
                rawtext: [{
                    translate: "lota.message.battle.level_cap_exceeded",
                    with: [String(overCap.level), String(levelCap)]
                }]
            });
            return false;
        }
    }
    const partyChanged = normalizeParty(party);
    const preferredSlot = Number.isInteger(Number(options.playerSlot))
        ? Math.max(0, Math.min(5, Math.floor(Number(options.playerSlot))))
        : selectedSlot(player, party);
    const slot = options.raidBattle?.singlePokemon
        ? (isUsablePokemon(party[preferredSlot]) ? preferredSlot : -1)
        : firstUsableSlot(party, preferredSlot);
    if (slot < 0) {
        if (partyChanged) savePartyToPlayer(player, party);
        player.sendMessage("You have no Pokemon left that can battle.");
        return false;
    }
    if (slot !== preferredSlot) player.setDynamicProperty(SELECTED_SLOT_PROPERTY, slot);

    if (options.playerLocation) {
        try { player.teleport(options.playerLocation, { dimension: trainerEntity.dimension }); } catch (error) {}
    }

    const direction = horizontalDirection(player.location, trainerEntity.location, player);
    const requestedOpponentLocation = options.opponentLocation;
    const spawnLocation = requestedOpponentLocation
        ? findBattleSurfaceAnchor(trainerEntity.dimension, requestedOpponentLocation, 24)
        : {
            x: Number(trainerEntity.location.x) - direction.x * 2.25,
            y: Number(trainerEntity.location.y),
            z: Number(trainerEntity.location.z) - direction.z * 2.25
        };
    const battleAllyLocation = options.playerPokemonLocation
        ? findBattleSurfaceAnchor(trainerEntity.dimension, options.playerPokemonLocation, 24)
        : undefined;
    const first = trainerParty[0];
    let target;
    try {
        target = trainerEntity.dimension.spawnEntity(first.species, spawnLocation);
        savePokemonToEntity(target, first);
        target.setProperty("lota:is_shiny", first.isShiny ? 1.0 : 0.0);
        if (options.raidBossHidden === true) {
            target.addEffect("invisibility", 20_000_000, {
                amplifier: 0,
                showParticles: false
            });
        }
        target.nameTag = options.raidBossHidden === true
            ? ""
            : `§f${formatPokemonName(first)} Lv. ${first.level}§r`;
        target.addTag(BATTLE_TAG);
    } catch (error) {
        try { target?.remove(); } catch (cleanupError) {}
        player.sendMessage(`§c${options.trainerName || "Trainer"}'s Pokemon could not enter battle.§r`);
        console.warn(`Trainer battle spawn failed: ${error}`);
        return false;
    }
    identify(player, first);

    const session = {
        battleType: "trainer",
        playerId: player.id,
        targetId: target.id,
        target,
        targetTypeId: target.typeId,
        targetNameTag: storedRealNameTag(target),
        captureDimension: target.dimension,
        captureLocation: { ...target.location },
        captureInProgress: false,
        party,
        playerSlot: slot,
        participants: [slot],
        wildPokemon: first,
        trainerParty,
        trainerSlot: 0,
        __trainerBattleEntities: [target],
        trainerName: String(options.trainerName || "Trainer"),
        trainerBag: (options.bag || []).map(entry => ({ ...entry, quantity: Math.max(0, Number(entry.quantity) || 0) })),
        trainerItemUses: 0,
        trainerMaxItemUses: Math.max(0, Number(options.maxItemUses) || 0),
        trainerAi: { ...(options.ai || {}) },
        trainerSwitchCooldown: 0,
        cameraSideScale: Number.isFinite(Number(options.cameraSideScale))
            ? Math.max(-1, Math.min(1, Number(options.cameraSideScale)))
            : 1,
        battleAllyLocation,
        raidBattle: options.raidBattle,
        onVictory: options.onVictory,
        onLoss: options.onLoss,
        onAbort: options.onAbort,
        levelCap,
        field: createBattleField(),
        log: [],
        turn: 0,
        logExpanded: false,
        logScroll: 0,
        phase: "menu",
        cursor: 0,
        forceSwitch: false,
        busy: false,
        megaPending: false,
        megaUsed: false,
        lastNavigationTick: 0,
        lastHudTick: 0,
        formOpen: false,
        formToken: 0,
        formRequestToken: 0,
        formBusyRetries: 0
    };

    const ally = resolveBattlePokemonEntity(session)
        || spawnBattlePokemonEntity(session, session.battleAllyLocation || player.location);
    if (!isValidEntity(ally)) {
        try { target.remove(); } catch (error) {}
        player.sendMessage("Your Pokemon could not enter battle.");
        return false;
    }

    activeBattles.set(player.id, session);
    entityBattles.set(target.id, player.id);
    lockBattleEntities(session);
    playOriginalPokemonBattleAnimation(ally, "cry");
    playOriginalPokemonBattleAnimation(target, "cry");
    saveSession(session);
    pushLog(session, `${session.trainerName} wants to battle!`, "opponent", "", "side_opponent");
    pushLog(session, `Go! ${formatPokemonName(party[slot])}!`, "player", "", "side_player");
    pushLog(session, `${session.trainerName} sent out ${formatPokemonName(first)}!`, "opponent", "", "side_opponent");
    session.turn = 1;
    pushTurnLog(session);
    try { session.raidBattle?.onTurnStart?.(session.turn, session); }
    catch (error) { console.warn(`Raid turn callback failed: ${error}`); }
    try { options.onStarted?.(player, session); }
    catch (error) { console.warn(`Trainer start callback failed: ${error}`); }
    showBattleMenu(player, session);
    return true;
}

export function startWildBattle(player, target) {
    if (!isValidEntity(player) || !isPokemonEntity(target)) return;
    if (target.hasTag("lota:pastured_pokemon")) return;
    const existing = activeBattles.get(player.id);
    if (existing) {
        updateBattleHud(existing, true);
        return;
    }
    if (target.hasTag("lota:party_pokemon")) {
        player.sendMessage("Party Pokemon cannot be challenged this way.");
        return;
    }
    if (entityBattles.has(target.id) || target.hasTag(BATTLE_TAG)) {
        player.sendMessage("That Pokemon is already in battle.");
        return;
    }

    const party = loadPartyFromPlayer(player);
    if (!party.length) {
        player.sendMessage("You have no Pokemon.");
        return;
    }
    const partyChanged = normalizeParty(party);
    const preferredSlot = selectedSlot(player, party);
    const slot = firstUsableSlot(party, preferredSlot);
    if (slot < 0) {
        if (partyChanged) savePartyToPlayer(player, party);
        player.sendMessage("You have no Pokemon left that can battle.");
        return;
    }
    if (slot !== preferredSlot) player.setDynamicProperty(SELECTED_SLOT_PROPERTY, slot);

    let wildPokemon = loadPokemonFromEntity(target);
    const generated = !wildPokemon;
    if (!wildPokemon) wildPokemon = generateRandomPokemon(target.typeId, 5);
    normalizePokemonForBattle(wildPokemon, { forceMoves: generated });
    applyAlphaWildMight(wildPokemon);
    normalizePokemonExperience(wildPokemon);
    if (Number(wildPokemon.currentHp) <= 0) wildPokemon.currentHp = wildPokemon.maxHp;

    identify(player, wildPokemon);

    const session = {
        playerId: player.id,
        targetId: target.id,
        target,
        targetTypeId: target.typeId,
        targetNameTag: storedRealNameTag(target),
        captureDimension: target.dimension,
        captureLocation: { ...target.location },
        captureInProgress: false,
        party,
        playerSlot: slot,
        participants: [slot],
        wildPokemon,
        battleType: "wild",
        levelCap: getEffectiveLevelCap(player),
        field: createBattleField(),
        log: [],
        turn: 0,
        logExpanded: false,
        logScroll: 0,
        phase: "menu",
        cursor: 0,
        forceSwitch: false,
        busy: false,
        megaPending: false,
        megaUsed: false,
        lastNavigationTick: 0,
        lastHudTick: 0,
        formOpen: false,
        formToken: 0,
        formRequestToken: 0,
        formBusyRetries: 0
    };

    activeBattles.set(player.id, session);
    entityBattles.set(target.id, player.id);
    try { target.addTag(BATTLE_TAG); } catch (error) {}
    lockBattleEntities(session);
    saveSession(session);
    pushTurnLog(session);
    pushLog(session, `Go! ${formatPokemonName(party[slot])}!`, "player", "", "side_player");
    pushLog(session, `A wild ${formatPokemonName(wildPokemon)} appeared!`, "opponent", "", "side_opponent");
    session.turn = 1;
    pushTurnLog(session);
    showBattleMenu(player, session);
}

world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    if (!player) return;
    const session = activeBattles.get(player.id);
    if (!session) return;
    const raidCheerType = {
        "lota:raid_cheer_attack": "attack",
        "lota:raid_cheer_defense": "defense",
        "lota:raid_cheer_heal": "heal"
    }[event.itemStack?.typeId];
    if (session.raidBattle && raidCheerType) {
        const result = useRaidCheer(session, raidCheerType);
        if (result?.success) {
            consumeHeldBattleItem(player, player.selectedSlotIndex, event.itemStack.typeId);
        } else if (result?.message) {
            player.sendMessage(`§e${result.message}§r`);
        }
        return;
    }
    if (session.phase === "item") {
        const itemId = String(event.itemStack?.typeId || "");
        if (itemId === COMPASS_ITEM) {
            if (player.isSneaking && !session.captureInProgress) showBattleMenu(player, session);
            return;
        }
        if (BALL_ITEMS.has(itemId)) return;
        beginBattleItemTargeting(session, player, itemId);
        return;
    }
    if (event.itemStack?.typeId !== COMPASS_ITEM) return;
    if (session.phase === "capture" && !session.captureInProgress) { showBattleMenu(player, session); return; }
    if (player.isSneaking) handleBattleBack(session); else handleBattleConfirm(session);
});

world.afterEvents.projectileHitEntity.subscribe(event => {
    const projectile = event.projectile;
    if (!isValidEntity(projectile)) return;
    try {
        if (!projectile.hasTag("lota:party_summon_ball")) return;
    } catch (error) {
        return;
    }

    const target = event.getEntityHit()?.entity;
    if (!isPokemonEntity(target)) return;
    try {
        if (target.hasTag("lota:party_pokemon")) return;
    } catch (error) {
        return;
    }

    const player = playerFromProjectileEvent(event);
    if (!player) return;

    system.runTimeout(() => startWildBattle(player, target), 2);
});

function clearStaleBattleHud(player) {
    if (!player || activeBattles.has(player.id)) return;
    clearBattleHud(player);
}

world.afterEvents.playerSpawn.subscribe(event => {
    system.runTimeout(() => clearStaleBattleHud(event.player), 1);
});

world.afterEvents.playerLeave.subscribe(event => {
    const session = activeBattles.get(event.playerId);
    if (session?.battleType === "pvp") {
        const opponent = opponentSession(session);
        finishPlayerBattle(session.pvpBattle, opponent?.playerId || "", event.playerId);
    } else if (session) {
        if (session.battleType === "trainer") {
            try { session.onLoss?.(undefined, session); }
            catch (error) { console.warn(`Trainer disconnect callback failed: ${error}`); }
        }
        clearBattle(session);
    }
    const outgoing = outgoingChallenges.get(event.playerId);
    const incoming = incomingChallenges.get(event.playerId);
    if (outgoing) clearChallenge(outgoing);
    if (incoming) clearChallenge(incoming);
});

system.runTimeout(() => {
    for (const player of world.getAllPlayers()) clearStaleBattleHud(player);
}, 1);

system.runInterval(() => {
    for (const session of activeBattles.values()) {
        syncBattleStatusVisuals(session);
        const player = playerById(session.playerId);
        lockBattleEntities(session);
        if (session.battleType === "pvp") {
            if (!validateSession(session)) continue;
            processDirectionalInput(session, player);
        } else if (!player || (!isValidEntity(session.target) && !session.captureInProgress)) {
            clearBattle(session);
        } else if (wildBattleOutOfRange(session, player)) {
            fleeWildBattle(session);
        } else {
            processDirectionalInput(session, player);
        }
    }
}, 2);
