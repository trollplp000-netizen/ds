export function claimPokedexUse(activeUses, playerId) {
    if (activeUses.has(playerId)) return false;
    activeUses.add(playerId);
    return true;
}

export function releasePokedexUse(activeUses, playerId) {
    activeUses.delete(playerId);
}
