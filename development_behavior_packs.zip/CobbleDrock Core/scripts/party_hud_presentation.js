const STATUS_ALIASES = Object.freeze({
    NONE: "",
    NORMAL: "",
    PSN: "psn",
    POISON: "psn",
    POISONED: "psn",
    TOX: "tox",
    TOXIC: "tox",
    TOXIC_POISON: "tox",
    BADLY_POISONED: "tox",
    BRN: "brn",
    BURN: "brn",
    BURNED: "brn",
    PAR: "par",
    PARALYSIS: "par",
    PARALYZED: "par",
    SLP: "slp",
    SLEEP: "slp",
    ASLEEP: "slp",
    FRZ: "frz",
    FREEZE: "frz",
    FROZEN: "frz"
});

export function normalizePartyStatus(value) {
    const key = String(value || "NONE").trim().toUpperCase().replace(/[- ]+/g, "_");
    return STATUS_ALIASES[key] || "";
}

export function partyStatusCode(pokemon) {
    if (!pokemon || Number(pokemon.currentHp) <= 0) return "";
    return normalizePartyStatus(pokemon.statusCondition);
}

function entityPokemonUuid(entity) {
    try {
        const data = entity?.getDynamicProperty?.("lota:pokemon_data");
        return data ? JSON.parse(String(data)).uuid : "";
    } catch (error) {
        return "";
    }
}

function entityOwnerId(entity) {
    try { return String(entity?.getDynamicProperty?.("lota:party_owner_id") || ""); }
    catch (error) { return ""; }
}

function entityIsMounted(entity) {
    try { return (entity?.getComponent?.("minecraft:rideable")?.getRiders?.() || []).length > 0; }
    catch (error) { return false; }
}

function entityShoulderSide(entity) {
    try {
        if (!entity?.hasTag?.("lota:shoulder_mounted")) return 0;
        const side = Number(entity?.getDynamicProperty?.("lota:shoulder_side"));
        return side === 1 ? 1 : (side === -1 ? -1 : 0);
    } catch (error) { return 0; }
}

function entityShoulderOwner(entity) {
    try { return String(entity?.getDynamicProperty?.("lota:shoulder_owner") || ""); }
    catch (error) { return ""; }
}

export function partyActivityForPokemon(pokemon, entities, ownerId = "") {
    const uuid = String(pokemon?.uuid || "");
    if (!uuid || !Array.isArray(entities)) return "";
    let released = false;
    let shoulder = "";
    for (const entity of entities) {
        try {
            if (!entity?.isValid || !entity.hasTag?.("lota:party_pokemon")) continue;
            if (ownerId && entityOwnerId(entity) !== String(ownerId)) continue;
            if (entityPokemonUuid(entity) !== uuid) continue;
            if (entityIsMounted(entity)) return "mounted";
            const side = entityShoulderSide(entity);
            if (side !== 0) {
                if (!ownerId || entityShoulderOwner(entity) === String(ownerId)) {
                    shoulder = side === 1 ? "shoulder_right" : "shoulder_left";
                }
                continue;
            }
            released = true;
        } catch (error) {}
    }
    return shoulder || (released ? "released" : "");
}

export function partyActivityMarkers(party, activities = []) {
    return (Array.isArray(party) ? party : []).slice(0, 6).map((pokemon, slot) => {
        const activity = activities[slot] || "";
        if (!pokemon || !activity) return "";
        if (activity === "mounted") return `|M${slot}|`;
        if (activity === "shoulder_left") return `|SL${slot}|`;
        if (activity === "shoulder_right") return `|SR${slot}|`;
        return `|R${slot}|`;
    }).join("");
}

export function partyGenderCode(pokemon) {
    if (!pokemon) return "";
    const raw = String(pokemon.gender || "").trim().toLowerCase();
    if (raw === "male" || raw === "m") return "m";
    if (raw === "female" || raw === "f") return "f";
    if (raw === "genderless" || raw === "n" || raw === "none") return "";
    const aspects = Array.isArray(pokemon.aspects) ? pokemon.aspects.map(String) : [];
    if (aspects.includes("male")) return "m";
    if (aspects.includes("female")) return "f";
    return "";
}

export function partyGenderMarkers(party) {
    return (Array.isArray(party) ? party : []).slice(0, 6).map((pokemon, slot) => {
        const code = partyGenderCode(pokemon);
        return code ? `|G${slot}:${code}|` : "";
    }).join("");
}

export function partyActiveMarker(slot) {
    const index = Number(slot);
    return Number.isInteger(index) && index >= 0 && index < 6 ? `|A${index}|` : "";
}
