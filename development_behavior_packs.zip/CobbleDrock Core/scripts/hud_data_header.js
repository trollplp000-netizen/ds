import { pokemonPortraitGlyph } from "./species_registry.js";

const PARTY_SLOT_COUNT = 6;

const BALL_HUD_CODE = Object.freeze({
    P: "01",
    G: "02",
    U: "03",
    MASTER: "04",
    ANCIENT_ULTRA: "05",
    FAST: "06",
    DIVE: "07",
    DUSK: "08",
    NEST: "09",
    NET: "10",
    QUICK: "11",
    REPEAT: "12",
    TIMER: "13",
    CITRINE: "14",
    ROSEATE: "15",
    SLATE: "16",
    VERDANT: "17",
    AZURE: "18",
    PREMIER: "19",
    SAFARI: "20",
    LEVEL: "21",
    LURE: "22",
    HEAVY: "23",
    LOVE: "24",
    FRIEND: "25",
    MOON: "26",
    SPORT: "27",
    PARK: "28",
    LUXURY: "29",
    HEAL: "30",
    DREAM: "31",
    BEAST: "32",
    CHERISH: "33",
    A_POKE: "34",
    A_CITRINE: "35",
    A_VERDANT: "36",
    A_AZURE: "37",
    A_ROSEATE: "38",
    A_SLATE: "39",
    A_GREAT: "40",
    A_HEAVY: "41",
    A_FEATHER: "42",
    A_WING: "43",
    A_JET: "44",
    A_LEADEN: "45",
    A_GIGATON: "46",
    A_IVORY: "47"
});

export const HUD_BALL_TEXTURE_BY_CODE = Object.freeze({
    "01": "poke_ball",
    "02": "great_ball",
    "03": "ultra_ball",
    "04": "master_ball",
    "05": "ancient_ultra_ball",
    "06": "fast_ball",
    "07": "dive_ball",
    "08": "dusk_ball",
    "09": "nest_ball",
    "10": "net_ball",
    "11": "quick_ball",
    "12": "repeat_ball",
    "13": "timer_ball",
    "14": "citrine_ball",
    "15": "roseate_ball",
    "16": "slate_ball",
    "17": "verdant_ball",
    "18": "azure_ball",
    "19": "premier_ball",
    "20": "safari_ball",
    "21": "level_ball",
    "22": "lure_ball",
    "23": "heavy_ball",
    "24": "love_ball",
    "25": "friend_ball",
    "26": "moon_ball",
    "27": "sport_ball",
    "28": "park_ball",
    "29": "luxury_ball",
    "30": "heal_ball",
    "31": "dream_ball",
    "32": "beast_ball",
    "33": "cherish_ball",
    "34": "ancient_poke_ball",
    "35": "ancient_citrine_ball",
    "36": "ancient_verdant_ball",
    "37": "ancient_azure_ball",
    "38": "ancient_roseate_ball",
    "39": "ancient_slate_ball",
    "40": "ancient_great_ball",
    "41": "ancient_heavy_ball",
    "42": "ancient_feather_ball",
    "43": "ancient_wing_ball",
    "44": "ancient_jet_ball",
    "45": "ancient_leaden_ball",
    "46": "ancient_gigaton_ball",
    "47": "ancient_ivory_ball"
});

function markerValue(source, marker, width, fallback) {
    const start = source.indexOf(marker);
    if (start < 0) return fallback;
    const valueStart = start + marker.length;
    const value = source.slice(valueStart, valueStart + width);
    return value.length === width && source[valueStart + width] === "|" ? value : fallback;
}

function markerText(source, marker) {
    const start = source.indexOf(marker);
    if (start < 0) return "";
    const valueStart = start + marker.length;
    const end = source.indexOf("|", valueStart);
    return end < 0 ? "" : source.slice(valueStart, end);
}

function numericMarker(source, marker, width, maximum) {
    const value = markerValue(source, marker, width, "0".repeat(width));
    const number = /^\d+$/.test(value) ? Number(value) : 0;
    return Math.max(0, Math.min(maximum, Math.floor(number) || 0));
}

function glyph(codepoint) {
    return String.fromCharCode(codepoint);
}

function pokemonGlyph(dex) {
    return glyph(pokemonPortraitGlyph(dex));
}

function partyPortraitGlyph(source, slot, dex) {
    const hex = markerText(source, `|G${slot}:`);
    if (/^[0-9A-Fa-f]{4}$/.test(hex)) {
        const codepoint = parseInt(hex, 16);
        if (codepoint >= 0xF000 && codepoint <= 0xF8FF) return glyph(codepoint);
    }
    return pokemonGlyph(dex);
}

function partyLevelDigitTokens(source) {
    let tokens = "";
    for (let slot = 0; slot < PARTY_SLOT_COUNT; slot++) {
        const species = Math.max(0, Math.min(1025, Number(markerText(source, `|${slot}:`)) || 0));
        if (species <= 0) continue;
        const level = Math.max(1, numericMarker(source, `|L${slot}:`, 3, 100));
        for (const [position, digit] of [...String(level)].entries()) {
            tokens += `|D${slot}:${position}:${digit}|`;
        }
    }
    return tokens;
}

function injectBattlePortraitGlyphs(source) {
    const lines = source.split("\n");
    const ally = Math.max(0, Math.min(1025, Number(markerText(source, "|ASP:")) || 0));
    const opponent = Math.max(0, Math.min(1025, Number(markerText(source, "|WSP:")) || 0));
    while (lines.length < 9) lines.push("");

    lines.splice(9, 0, pokemonGlyph(ally), "", "", "", pokemonGlyph(opponent), "", "", "");
    return lines.join("\n");
}

function isPartyHudTitle(source) {
    return source.includes("|PARTY_HUD_READY|")
        && !source.includes("|COBBLEDROCK_BATTLE|")
        && !source.includes("|COBBLEDROCK_PARTY_SELECT|")
        && !source.includes("|PDXSCAN:");
}

export function withHudPortraitSubtitle(title, subtitle) {
    const source = String(title || "");
    const originalRows = String(subtitle || "").split("\n");
    if (!isPartyHudTitle(source)) return String(subtitle || "");
    const rows = [];
    for (let slot = 0; slot < PARTY_SLOT_COUNT; slot++) {
        const species = Math.max(0, Math.min(1025, Number(markerText(source, `|${slot}:`)) || 0));
        rows.push(partyPortraitGlyph(source, slot, species) + " " + (originalRows[slot] || " "));
    }
    return rows.join("\n");
}

export function withHudDataHeader(title) {
    const source = String(title || "");
    if (source.includes("|COBBLEDROCK_BATTLE|")) return injectBattlePortraitGlyphs(source);
    return isPartyHudTitle(source) ? `${source}${partyLevelDigitTokens(source)}` : source;
}

export function hudBallCode(value) {
    return BALL_HUD_CODE[String(value || "").toUpperCase()] || "00";
}
