import { withHudDataHeader, withHudPortraitSubtitle } from "./hud_data_header.js";

const HUD_TITLE_BASE = new Map();
const HUD_TITLE_TRANSIENT = new Map();

function renderHudTitle(player) {
    if (!player?.isValid) return;
    const base = HUD_TITLE_BASE.get(player.id) || {
        title: "",
        subtitle: "",
        stayDuration: 20 * 60 * 60 * 24
    };
    const transient = HUD_TITLE_TRANSIENT.get(player.id);
    let tokens = "";
    let subtitle = base.subtitle;
    if (transient) {
        for (const value of transient.values()) {
            if (typeof value === "string") {
                tokens += value;
                continue;
            }
            tokens += String(value?.title || "");
            if (value && Object.prototype.hasOwnProperty.call(value, "subtitle")) {
                subtitle = value.subtitle;
            }
        }
    }
    const titleSource = `${base.title}${tokens}`;
    const title = withHudDataHeader(titleSource);
    subtitle = withHudPortraitSubtitle(titleSource, subtitle);
    player.onScreenDisplay.setTitle(title, {
        subtitle,
        fadeInDuration: 0,
        stayDuration: base.stayDuration,
        fadeOutDuration: 0
    });
}

export function setHudTitleBase(player, title, subtitle = "", stayDuration = 20 * 60 * 60 * 24) {
    HUD_TITLE_BASE.set(player.id, { title, subtitle, stayDuration });
    renderHudTitle(player);
}

export function clearHudTitleBase(player) {
    if (!player?.isValid) return;
    HUD_TITLE_BASE.delete(player.id);
    renderHudTitle(player);
}

export function setHudTitleTransient(player, key, token) {
    let transient = HUD_TITLE_TRANSIENT.get(player.id);
    if (!transient) {
        transient = new Map();
        HUD_TITLE_TRANSIENT.set(player.id, transient);
    }
    transient.set(key, token);
    renderHudTitle(player);
}

export function clearHudTitleTransient(player, key) {
    const transient = HUD_TITLE_TRANSIENT.get(player.id);
    if (!transient?.delete(key)) return;
    if (transient.size === 0) HUD_TITLE_TRANSIENT.delete(player.id);
    renderHudTitle(player);
}

export function forgetHudTitlePlayer(playerId) {
    HUD_TITLE_BASE.delete(playerId);
    HUD_TITLE_TRANSIENT.delete(playerId);
}
