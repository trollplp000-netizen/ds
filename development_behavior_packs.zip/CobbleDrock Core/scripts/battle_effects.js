import { recordEvolutionProgress } from "./evolution_progress.js";
import { SPECIES_DATA } from "./species_registry.js";
import { moveData } from "./move_registry.js";

const STATUS_NAMES = Object.freeze({
    brn: "burned",
    par: "paralyzed",
    psn: "poisoned",
    tox: "badly poisoned",
    slp: "fell asleep",
    frz: "was frozen"
});

function cleanStatus(value) {
    const status = String(value || "NONE").toLowerCase();
    return status === "none" ? "" : status;
}

function pokemonTypes(pokemon) {
    if (Array.isArray(pokemon?.battleState?.typeOverride)) return pokemon.battleState.typeOverride;
    const key = String(pokemon?.battleState?.megaSpecies || pokemon?.megaState?.runtimeSpecies || pokemon?.species || "")
        .replace(/^cobblemon:/, "")
        .replace(/^lota:/, "")
        .toLowerCase();
    return SPECIES_DATA[key]?.types || ["normal"];
}

export function battleState(pokemon) {
    if (!pokemon.battleState || typeof pokemon.battleState !== "object") pokemon.battleState = {};
    if (!pokemon.battleState.stages || typeof pokemon.battleState.stages !== "object") pokemon.battleState.stages = {};
    return pokemon.battleState;
}

export function resetBattleState(pokemon) {
    if (!pokemon) return;
    const previous = pokemon.battleState || {};
    pokemon.battleState = { stages: {}, protectChain: 0 };
    for (const key of ["megaSpecies", "megaAspect", "baseAbility"]) {
        if (previous[key] !== undefined) pokemon.battleState[key] = previous[key];
    }
}

export function clearBattleState(pokemon, preserveMega = false) {
    if (!pokemon) return;
    if (preserveMega && pokemon.battleState?.megaSpecies) {
        const { megaSpecies, megaAspect, baseAbility } = pokemon.battleState;
        pokemon.battleState = { stages: {}, protectChain: 0, megaSpecies, megaAspect, baseAbility };
        return;
    }
    delete pokemon.battleState;
}

export function statStage(pokemon, stat) {
    return Math.max(-6, Math.min(6, Math.floor(Number(pokemon?.battleState?.stages?.[stat]) || 0)));
}

export function stageMultiplier(stage, accuracy = false) {
    const value = Math.max(-6, Math.min(6, Math.floor(Number(stage) || 0)));
    if (accuracy) return value >= 0 ? (3 + value) / 3 : 3 / (3 - value);
    return value >= 0 ? (2 + value) / 2 : 2 / (2 - value);
}

export function moveAccuracy(attacker, defender, move, options = {}) {
    const state = battleState(attacker);
    if (state.lockOn) {
        state.lockOn = false;
        return 100;
    }
    if (move?.ohko) return 100;
    const weather = String(options.weather || "").toLowerCase();
    if (["thunder", "hurricane"].includes(move?.id) && ["raindance", "rain"].includes(weather)) return 100;
    if (["thunder", "hurricane"].includes(move?.id) && ["sunnyday", "sun"].includes(weather)) return 50;
    if (move?.id === "blizzard" && weather === "snow") return 100;
    const accuracy = Number(move?.accuracy);
    if (!Number.isFinite(accuracy) || accuracy <= 0) return 100;
    const accuracyStage = statStage(attacker, "accuracy");
    const evasionStage = options.ignoreEvasion || move?.ignoreEvasion ? 0 : statStage(defender, "evasion");
    let modifier = stageMultiplier(accuracyStage - evasionStage, true);
    if (state.micleBerryAccuracy) {
        modifier *= 1.2;
        delete state.micleBerryAccuracy;
    }
    return Math.max(1, Math.min(100, accuracy * modifier));
}

export function beforeMove(pokemon, move = undefined) {
    const state = battleState(pokemon);
    if (state.skyDropHeld) return { canMove: false, message: `${pokemon.nickname || "Pokemon"} can't move while held in the sky!` };
    const selectionFailure = moveSelectionFailure(pokemon, move);
    if (selectionFailure) return { canMove: false, message: selectionFailure };
    if (state.flinch) {
        state.flinch = false;
        return { canMove: false, message: `${pokemon.nickname || "Pokemon"} flinched!` };
    }
    if (state.recharge) {
        state.recharge = false;
        return { canMove: false, message: `${pokemon.nickname || "Pokemon"} must recharge!` };
    }

    const status = cleanStatus(pokemon.statusCondition);
    if (status === "slp" && move?.sleepUsable !== true) {
        state.sleepTurns = Math.max(0, Math.floor(Number(state.sleepTurns) || 0) - 1);
        if (state.sleepTurns > 0) return { canMove: false, message: `${pokemon.nickname || "Pokemon"} is fast asleep.` };
        pokemon.statusCondition = "NONE";
        return { canMove: true, message: `${pokemon.nickname || "Pokemon"} woke up!` };
    }
    if (status === "frz") {
        if (Math.random() < 0.2) {
            pokemon.statusCondition = "NONE";
            return { canMove: true, message: `${pokemon.nickname || "Pokemon"} thawed out!` };
        }
        return { canMove: false, message: `${pokemon.nickname || "Pokemon"} is frozen solid!` };
    }
    if (status === "par" && Math.random() < 0.25) {
        return { canMove: false, message: `${pokemon.nickname || "Pokemon"} is paralyzed! It can't move!` };
    }
    if (state.confusionTurns > 0) {
        state.confusionTurns--;
        if (state.confusionTurns <= 0) return { canMove: true, message: `${pokemon.nickname || "Pokemon"} snapped out of confusion!` };
        if (Math.random() < (1 / 3)) return { canMove: false, confusionDamage: true, message: `${pokemon.nickname || "Pokemon"} hurt itself in its confusion!` };
    }
    return { canMove: true };
}

export function moveSelectionFailure(pokemon, move) {
    const state = battleState(pokemon);
    const moveId = String(move?.id || "").toLowerCase();
    if (state.disabledMoveId && state.disabledMoveId === moveId && state.disableTurns > 0) return "That move is disabled!";
    if (state.tauntTurns > 0 && move?.category === "status") return `${pokemon.nickname || "Pokemon"} can't use that move after the taunt!`;
    if (state.lockedMoveTurns > 0 && state.lockedMoveId && state.lockedMoveId !== moveId) return `${pokemon.nickname || "Pokemon"} must continue the attack!`;
    if (state.chargingMoveId && state.chargingMoveId !== moveId) return `${pokemon.nickname || "Pokemon"} must finish the attack!`;
    if (state.encoreTurns > 0 && state.encoreMoveId && state.encoreMoveId !== moveId) return `${pokemon.nickname || "Pokemon"} must use the encored move!`;
    if (move?.flags?.includes("cantusetwice") && state.lastMoveId === moveId) return `${move.name || moveId} can't be used twice in a row!`;
    return "";
}

export function forcedMoveId(pokemon) {
    const state = battleState(pokemon);
    if (state.chargingMoveId) return String(state.chargingMoveId);
    if (state.lockedMoveTurns > 0) return String(state.lockedMoveId || "");
    return state.encoreTurns > 0 ? String(state.encoreMoveId || "") : "";
}

export function isTrapped(pokemon) {
    const state = battleState(pokemon);
    return state.trapped === true || state.ingrain === true || state.partialTrapTurns > 0 || state.skyDropHeld === true;
}

export function prepareMoveState(pokemon, move, random = Math.random, options = {}) {
    const state = battleState(pokemon);
    const moveId = String(move?.id || "").toLowerCase();
    const protectionMove = ["protect", "detect", "endure"].includes(moveId);
    if (!protectionMove) state.protectChain = 0;
    state.protected = false;
    state.endure = false;

    const chargingMove = Array.isArray(move?.flags) && move.flags.includes("charge");
    const skipsCharge = moveId === "solarbeam" && ["sunnyday", "sun"].includes(String(options.weather || "").toLowerCase());
    if (chargingMove && !skipsCharge) {
        if (state.chargingMoveId === moveId) {
            state.chargingMoveId = "";
            state.semiInvulnerable = "";
        }
        else {
            state.chargingMoveId = moveId;
            state.semiInvulnerable = ["dig", "dive", "skydrop"].includes(moveId) ? moveId : "";
            if (moveId === "skullbash") state.stages.def = Math.min(6, statStage(pokemon, "def") + 1);
            state.lastMoveId = moveId;
            return { failed: false, charging: true, message: `${pokemon.nickname || "Pokemon"} began charging the attack!` };
        }
    }

    if (protectionMove) {
        const chance = 1 / Math.pow(3, Math.max(0, Number(state.protectChain) || 0));
        if (random() >= chance) {
            state.protectChain = 0;
            state.lastMoveId = moveId;
            return { failed: true, message: "But it failed!" };
        }
        state.protectChain = Math.max(0, Number(state.protectChain) || 0) + 1;
        if (moveId === "endure") state.endure = true;
        else state.protected = true;
    }
    state.lastMoveId = moveId;
    return { failed: false };
}

function canReceiveStatus(pokemon, status, options = {}) {
    if (cleanStatus(pokemon.statusCondition)) return false;
    const types = pokemonTypes(pokemon);
    if (status === "slp" && options.grounded && String(options.terrain || "").toLowerCase() === "electricterrain") return false;
    if (status === "brn" && types.includes("fire")) return false;
    if (status === "par" && types.includes("electric")) return false;
    if ((status === "psn" || status === "tox") && (types.includes("poison") || types.includes("steel"))) return false;
    if (status === "frz" && types.includes("ice")) return false;
    return true;
}

function applyStatus(pokemon, status, messages, options = {}) {
    const clean = cleanStatus(status);
    if (!clean || options.safeguard || !canReceiveStatus(pokemon, clean, options)) return;
    pokemon.statusCondition = clean.toUpperCase();
    const state = battleState(pokemon);
    if (clean === "slp") state.sleepTurns = 2 + Math.floor(Math.random() * 3);
    if (clean === "tox") state.toxicTurns = 0;
    messages.push(`${pokemon.nickname || "Pokemon"} ${STATUS_NAMES[clean] || `was affected by ${clean}`}!`);
}

function applyVolatile(pokemon, volatileStatus, messages, source = undefined) {
    const state = battleState(pokemon);
    if (volatileStatus === "flinch") {
        state.flinch = true;
    } else if (volatileStatus === "confusion") {
        state.confusionTurns = 2 + Math.floor(Math.random() * 4);
        messages.push(`${pokemon.nickname || "Pokemon"} became confused!`);
    } else if (volatileStatus === "mustrecharge") {
        state.recharge = true;
    } else if (volatileStatus === "disable") {
        if (state.lastMoveId) {
            state.disabledMoveId = state.lastMoveId;
            state.disableTurns = 5;
            messages.push(`${pokemon.nickname || "Pokemon"}'s ${state.lastMoveId} was disabled!`);
        }
    } else if (volatileStatus === "encore") {
        if (state.lastMoveId) {
            state.encoreMoveId = state.lastMoveId;
            state.encoreTurns = 4;
            messages.push(`${pokemon.nickname || "Pokemon"} received an encore!`);
        }
    } else if (volatileStatus === "taunt") {
        state.tauntTurns = 4;
        messages.push(`${pokemon.nickname || "Pokemon"} fell for the taunt!`);
    } else if (volatileStatus === "partiallytrapped") {
        state.partialTrapTurns = 4 + Math.floor(Math.random() * 2);
        state.partialTrapMove = String(source?.lastMoveId || "the attack");
    } else if (volatileStatus === "ingrain") {
        state.ingrain = true;
        messages.push(`${pokemon.nickname || "Pokemon"} planted its roots!`);
    } else if (volatileStatus === "aquaring") {
        state.aquaRing = true;
    } else if (volatileStatus === "leechseed") {
        if (pokemonTypes(pokemon).includes("grass")) return;
        state.leechSeed = true;
        messages.push(`${pokemon.nickname || "Pokemon"} was seeded!`);
    } else if (volatileStatus === "yawn") {
        state.yawnTurns = 2;
    } else if (volatileStatus === "endure") {
        state.endure = true;
    } else if (volatileStatus === "protect") {
        state.protected = true;
    } else if (volatileStatus === "focusenergy") {
        state.focusEnergy = true;
    } else if (volatileStatus === "lockedmove") {
        if (state.lockedMoveTurns <= 0) {
            state.lockedMoveId = state.lastMoveId;
            state.lockedMoveTurns = 2 + Math.floor(Math.random() * 2);
        }
    } else if (volatileStatus === "stockpile") {
        const previousStockpile = Math.max(0, Number(state.stockpile) || 0);
        state.stockpile = Math.min(3, previousStockpile + 1);
        if (previousStockpile < 3) {
            state.stages.def = Math.min(6, statStage(pokemon, "def") + 1);
            state.stages.spd = Math.min(6, statStage(pokemon, "spd") + 1);
        }
    } else if (volatileStatus === "nightmare") {
        if (cleanStatus(pokemon.statusCondition) === "slp") state.nightmare = true;
    } else if (volatileStatus === "magnetrise") {
        state.magnetRiseTurns = 5;
        state.smackDown = false;
    } else if (volatileStatus === "smackdown") {
        state.smackDown = true;
        state.magnetRiseTurns = 0;
    } else if (volatileStatus === "roost") {
        state.roost = true;
    } else if (volatileStatus === "charge") {
        state.charge = true;
    } else if (volatileStatus === "foresight") {
        state.foresight = true;
    } else if (volatileStatus === "miracleeye") {
        state.miracleEye = true;
    }
}

function applySpecialMoveEffects(actor, defender, move, messages, options) {
    const actorState = battleState(actor);
    const defenderState = battleState(defender);
    const heal = (pokemon, amount) => {
        const before = Number(pokemon.currentHp) || 0;
        pokemon.currentHp = Math.min(Number(pokemon.maxHp) || before, before + Math.max(0, Math.floor(amount)));
        if (pokemon.currentHp > before) messages.push(`${pokemon.nickname || "Pokemon"} restored HP!`);
    };
    if (move.id === "acupressure") {
        const stats = ["atk", "def", "spa", "spd", "spe", "accuracy", "evasion"].filter(stat => statStage(actor, stat) < 6);
        if (stats.length) applyBoosts(actor, { [stats[Math.floor(Math.random() * stats.length)]]: 2 }, messages, options.actorSide);
    } else if (move.id === "bellydrum") {
        const cost = Math.floor((Number(actor.maxHp) || 1) / 2);
        if (Number(actor.currentHp) > cost && statStage(actor, "atk") < 6) {
            actor.currentHp -= cost;
            actorState.stages.atk = 6;
            messages.push(`${actor.nickname || "Pokemon"} maximized its Attack!`);
        }
    } else if (move.id === "haze") {
        actorState.stages = {};
        defenderState.stages = {};
        messages.push("All stat changes were eliminated!");
    } else if (move.id === "guardswap") {
        for (const stat of ["def", "spd"]) [actorState.stages[stat], defenderState.stages[stat]] = [defenderState.stages[stat] || 0, actorState.stages[stat] || 0];
    } else if (move.id === "powerswap") {
        for (const stat of ["atk", "spa"]) [actorState.stages[stat], defenderState.stages[stat]] = [defenderState.stages[stat] || 0, actorState.stages[stat] || 0];
    } else if (move.id === "psychup") {
        actorState.stages = { ...defenderState.stages };
    } else if (move.id === "healpulse") {
        heal(defender, (Number(defender.maxHp) || 1) / 2);
    } else if (["lockon", "mindreader"].includes(move.id)) {
        actorState.lockOn = true;
    } else if (["moonlight", "synthesis", "morningsun"].includes(move.id)) {
        const weather = String(options.weather || "").toLowerCase();
        const ratio = ["sunnyday", "sun"].includes(weather) ? 2 / 3 : weather ? 1 / 4 : 1 / 2;
        heal(actor, (Number(actor.maxHp) || 1) * ratio);
    } else if (move.id === "refresh") {
        if (["brn", "par", "psn", "tox"].includes(cleanStatus(actor.statusCondition))) actor.statusCondition = "NONE";
    } else if (move.id === "rest") {
        const electricTerrain = options.actorSide?.grounded
            && String(options.actorSide?.terrain || "").toLowerCase() === "electricterrain";
        if (!electricTerrain && (Number(actor.currentHp) < Number(actor.maxHp) || cleanStatus(actor.statusCondition))) {
            actor.currentHp = actor.maxHp;
            actor.statusCondition = "SLP";
            actorState.sleepTurns = 3;
            messages.push(`${actor.nickname || "Pokemon"} slept and became healthy!`);
        }
    } else if (move.id === "soak") {
        defenderState.typeOverride = ["water"];
    } else if (move.id === "spite") {
        const targetMove = defender.moves?.find(candidate => candidate.id === defenderState.lastMoveId);
        if (targetMove) targetMove.pp = Math.max(0, Number(targetMove.pp) - 4);
    } else if (move.id === "swallow") {
        const stockpile = Math.max(0, Number(actorState.stockpile) || 0);
        if (stockpile > 0) {
            heal(actor, (Number(actor.maxHp) || 1) * (stockpile === 1 ? 1 / 4 : stockpile === 2 ? 1 / 2 : 1));
            actorState.stockpile = 0;
        }
    } else if (move.id === "spitup") {
        actorState.stockpile = 0;
    } else if (move.id === "perishsong") {
        actorState.perishTurns = 4;
        defenderState.perishTurns = 4;
        messages.push("All Pokemon that heard the song will faint in three turns!");
    } else if (move.id === "aromatherapy") {
        for (const pokemon of options.actorParty || [actor]) {
            if (!pokemon) continue;
            pokemon.statusCondition = "NONE";
            const state = battleState(pokemon);
            state.sleepTurns = 0;
            state.toxicTurns = 0;
        }
        messages.push("The party was cured of its status conditions!");
    } else if (move.id === "rapidspin") {
        actorState.leechSeed = false;
        actorState.partialTrapTurns = 0;
        actorState.partialTrapMove = "";
        if (typeof options.clearActorHazards === "function") options.clearActorHazards();
    } else if (move.id === "healingwish") {
        if (typeof options.setActorSideEffect === "function") options.setActorSideEffect("healingwish", 1);
    } else if (move.id === "conversion") {
        const firstMove = moveData(actor.moves?.[0]?.id);
        if (firstMove?.type) actorState.typeOverride = [firstMove.type];
    } else if (move.id === "reflecttype") {
        actorState.typeOverride = [...pokemonTypes(defender)];
    } else if (move.id === "venomdrench") {
        if (["psn", "tox"].includes(cleanStatus(defender.statusCondition))) {
            applyBoosts(defender, { atk: -1, spa: -1, spe: -1 }, messages, options.defenderSide);
        }
    }
}

function statLabel(stat) {
    return ({
        atk: "Attack",
        def: "Defense",
        spa: "Sp. Atk",
        spd: "Sp. Def",
        spe: "Speed",
        accuracy: "accuracy",
        evasion: "evasiveness"
    })[stat] || stat;
}

function applyBoosts(pokemon, boosts, messages, options = {}) {
    if (!boosts) return;
    const state = battleState(pokemon);
    for (const [stat, rawAmount] of Object.entries(boosts)) {
        const amount = Math.floor(Number(rawAmount) || 0);
        if (!amount) continue;
        if (amount < 0 && options.mist) continue;
        const before = statStage(pokemon, stat);
        const after = Math.max(-6, Math.min(6, before + amount));
        state.stages[stat] = after;
        if (after === before) continue;
        if (typeof options.onStatStageChange === "function") {
            options.onStatStageChange({ pokemon, stat, amount: after - before, before, after });
        }
        const direction = amount > 0 ? "rose" : "fell";
        const intensity = Math.abs(amount) >= 2 ? (amount > 0 ? " sharply" : " harshly") : "";
        messages.push(`${pokemon.nickname || "Pokemon"}'s ${statLabel(stat)}${intensity} ${direction}!`);
    }
}

function applySecondary(actor, defender, effect, messages, options = {}) {
    if (!effect || Math.random() * 100 >= (Number(effect.chance) || 100)) return;
    applyStatus(defender, effect.status, messages, options.defenderSide);
    applyVolatile(defender, effect.volatileStatus, messages, battleState(actor));
    applyBoosts(defender, effect.boosts, messages, options.defenderSide);
    applyStatus(actor, effect.selfStatus, messages, options.actorSide);
    applyVolatile(actor, effect.selfVolatileStatus, messages, battleState(actor));
    applyBoosts(actor, effect.selfBoosts, messages, options.actorSide);
}

function cleanHeldItemId(pokemon) {
    return String(pokemon?.heldItem || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();
}

function applyRazorFangSecondary(actor, defender, move, damage, messages, options = {}) {
    if (damage <= 0 || !["physical", "special"].includes(String(move?.category || "").toLowerCase())) return;
    if (cleanHeldItemId(actor) !== "razor_fang" || (move?.secondaries || []).some(effect => effect?.volatileStatus === "flinch")) return;
    if (Number(defender?.currentHp) <= 0 || options.substitute || options.missed || options.protected || options.immune || options.failed) return;
    applySecondary(actor, defender, { chance: 10, volatileStatus: "flinch" }, messages, options);
}

function ratioAmount(base, ratio) {
    if (!Array.isArray(ratio) || ratio.length < 2) return 0;
    return Math.max(0, Math.floor(base * Number(ratio[0]) / Math.max(1, Number(ratio[1]))));
}

export function applyMoveEffects(actor, defender, move, damage, options = {}) {
    const messages = [];
    const selfTarget = String(move.target) === "self";
    applyStatus(selfTarget ? actor : defender, move.status, messages, selfTarget ? options.actorSide : options.defenderSide);
    applyVolatile(selfTarget ? actor : defender, move.volatileStatus, messages, battleState(actor));
    applyBoosts(selfTarget ? actor : defender, move.boosts, messages, selfTarget ? options.actorSide : options.defenderSide);
    applyStatus(actor, move.selfStatus, messages, options.actorSide);
    applyVolatile(actor, move.selfVolatileStatus, messages, battleState(actor));
    applyBoosts(actor, move.selfBoosts, messages, options.actorSide);
    for (const effect of move.secondaries || []) applySecondary(actor, defender, effect, messages, options);

    const healed = ratioAmount(Number(actor.maxHp) || 1, move.heal) + ratioAmount(damage, move.drain);
    if (healed > 0 && Number(actor.currentHp) > 0) {
        const before = Number(actor.currentHp) || 0;
        actor.currentHp = Math.min(Number(actor.maxHp) || before, before + healed);
        if (actor.currentHp > before) messages.push(`${actor.nickname || "Pokemon"} restored HP!`);
    }

    let recoil = ratioAmount(damage, move.recoil);
    if (Array.isArray(move.maxHpRecoil) && String(actor?.ability || "").replace(/^(lota|cobblemon):/, "").toLowerCase() !== "magicguard") {
        recoil += Math.ceil((Number(actor.maxHp) || 1) * Number(move.maxHpRecoil[0]) / Math.max(1, Number(move.maxHpRecoil[1]) || 1));
    }
    if (move.name === "Struggle") recoil = Math.max(recoil, Math.floor((Number(actor.maxHp) || 1) / 4));
    if (recoil > 0) {
        recordEvolutionProgress(actor, "recoil", Math.min(recoil, Number(actor.currentHp) || 0));
        actor.currentHp = Math.max(0, (Number(actor.currentHp) || 0) - recoil);
        messages.push(`${actor.nickname || "Pokemon"} was damaged by recoil!`);
    }
    if (move.selfdestruct) actor.currentHp = 0;
    if (move.trapTarget) {
        battleState(defender).trapped = true;
        messages.push(`${defender.nickname || "Pokemon"} can no longer escape!`);
    }
    applySpecialMoveEffects(actor, defender, move, messages, options);
    if (battleState(actor).charge && move.type === "electric" && move.category !== "status") battleState(actor).charge = false;
    return messages;
}

export function applyHitDamage(defender, rawDamage, source = undefined, move = undefined) {
    const state = battleState(defender);
    const damage = Math.max(0, Math.floor(Number(rawDamage) || 0));
    if (state.substituteHp > 0) {
        const before = state.substituteHp;
        state.substituteHp = Math.max(0, before - damage);
        return { damage: 0, substituteDamage: before - state.substituteHp, substituteBroke: state.substituteHp <= 0 };
    }
    const before = Math.max(0, Math.floor(Number(defender.currentHp) || 0));
    const minimum = state.endure && before > 0 ? 1 : 0;
    defender.currentHp = Math.max(minimum, before - damage);
    const dealt = before - defender.currentHp;
    if (source && dealt > 0 && ["physical", "special"].includes(move?.category)) {
        state.lastDamageTaken = dealt;
        state.lastDamageCategory = move.category;
    }
    return { damage: dealt, substituteDamage: 0, substituteBroke: false };
}

export function resetTurnDamage(pokemon) {
    const state = battleState(pokemon);
    state.lastDamageTaken = 0;
    state.lastDamageCategory = "";
}

export function applyMoveHitEffects(actor, defender, move, damage = 0, options = {}) {
    if (damage && typeof damage === "object") { options = damage; damage = Number(options.damage) || 0; }
    const messages = [];
    for (const effect of move.secondaries || []) applySecondary(actor, defender, effect, messages, options);
    applyRazorFangSecondary(actor, defender, move, Math.max(0, Number(damage) || 0), messages, options);
    return messages;
}

export function applyMoveFinalEffects(actor, defender, move, damage, options = {}) {
    const moveWithoutSecondaries = { ...move, secondaries: [] };
    return applyMoveEffects(actor, defender, moveWithoutSecondaries, damage, options);
}

export function applyResidualEffects(pokemon, opponent = undefined, options = {}) {
    const messages = [];
    const status = cleanStatus(pokemon?.statusCondition);
    if (status === "brn" || status === "psn") {
        const divisor = status === "brn" ? 16 : 8;
        const damage = Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / divisor));
        pokemon.currentHp = Math.max(0, (Number(pokemon.currentHp) || 0) - damage);
        messages.push(`${pokemon.nickname || "Pokemon"} was hurt by its ${status === "brn" ? "burn" : "poison"}!`);
    } else if (status === "tox") {
        const state = battleState(pokemon);
        state.toxicTurns = Math.min(15, (Number(state.toxicTurns) || 0) + 1);
        const damage = Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) * state.toxicTurns / 16));
        pokemon.currentHp = Math.max(0, (Number(pokemon.currentHp) || 0) - damage);
        messages.push(`${pokemon.nickname || "Pokemon"} was hurt by poison!`);
    }
    const state = battleState(pokemon);
    if (Number(pokemon.currentHp) > 0 && (state.ingrain || state.aquaRing)) {
        const amount = Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 16));
        const before = Number(pokemon.currentHp) || 0;
        pokemon.currentHp = Math.min(Number(pokemon.maxHp) || before, before + amount);
        if (pokemon.currentHp > before) messages.push(`${pokemon.nickname || "Pokemon"} restored HP!`);
    }
    if (Number(pokemon.currentHp) > 0 && state.leechSeed) {
        const amount = Math.min(Number(pokemon.currentHp) || 0, Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 8)));
        pokemon.currentHp = Math.max(0, (Number(pokemon.currentHp) || 0) - amount);
        if (opponent && Number(opponent.currentHp) > 0) opponent.currentHp = Math.min(Number(opponent.maxHp) || 1, Number(opponent.currentHp) + amount);
        messages.push(`${pokemon.nickname || "Pokemon"}'s health was sapped by Leech Seed!`);
    }
    if (Number(pokemon.currentHp) > 0 && state.partialTrapTurns > 0) {
        state.partialTrapTurns--;
        pokemon.currentHp = Math.max(0, (Number(pokemon.currentHp) || 0) - Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 8)));
        messages.push(`${pokemon.nickname || "Pokemon"} was hurt by ${state.partialTrapMove || "the binding move"}!`);
    }
    if (Number(pokemon.currentHp) > 0 && state.nightmare && cleanStatus(pokemon.statusCondition) === "slp") {
        pokemon.currentHp = Math.max(0, Number(pokemon.currentHp) - Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 4)));
        messages.push(`${pokemon.nickname || "Pokemon"} is locked in a nightmare!`);
    }
    if (state.yawnTurns > 0 && --state.yawnTurns <= 0 && canReceiveStatus(pokemon, "slp", options)) applyStatus(pokemon, "slp", messages, options);
    if (state.perishTurns > 0) {
        state.perishTurns--;
        if (state.perishTurns <= 0) {
            pokemon.currentHp = 0;
            messages.push(`${pokemon.nickname || "Pokemon"}'s perish count fell to zero!`);
        } else messages.push(`${pokemon.nickname || "Pokemon"}'s perish count is ${state.perishTurns}!`);
    }
    for (const key of ["disableTurns", "encoreTurns", "tauntTurns"]) if (state[key] > 0) state[key]--;
    if (state.disableTurns <= 0) state.disabledMoveId = "";
    if (state.encoreTurns <= 0) state.encoreMoveId = "";
    if (state.magnetRiseTurns > 0) state.magnetRiseTurns--;
    if (state.lockedMoveTurns > 0 && --state.lockedMoveTurns <= 0) {
        state.lockedMoveId = "";
        if (state.confusionTurns <= 0) {
            state.confusionTurns = 2 + Math.floor(Math.random() * 4);
            messages.push(`${pokemon.nickname || "Pokemon"} became confused due to fatigue!`);
        }
    }
    state.protected = false;
    state.endure = false;
    state.flinch = false;
    state.roost = false;
    return messages;
}
