import { system, world } from "@minecraft/server";
import { runPlayerStorageMaintenance } from "./storage_service.js";

const maintenanceCooldown = new Map();
const MAINTENANCE_COOLDOWN_TICKS = 100;

function shouldRun(player) {
    const last = maintenanceCooldown.get(player.id);
    const now = system.currentTick;
    if (last !== undefined && now - last < MAINTENANCE_COOLDOWN_TICKS) return false;
    maintenanceCooldown.set(player.id, now);
    return true;
}

world.afterEvents.playerSpawn.subscribe(event => {
    if (!event.initialSpawn) return;
    const player = event.player;
    system.run(() => {
        try {
            if (!player?.isValid || !shouldRun(player)) return;
            runPlayerStorageMaintenance(player);
        } catch (error) {
            console.error(`[Storage] Join maintenance failed: ${error}`);
        }
    });
});

world.afterEvents.playerLeave.subscribe(event => {
    maintenanceCooldown.delete(event.playerId);
});
