import { BATTLE_ITEMS } from "./battle_item_effects.js";

export const BATTLE_ITEM_IDS = Object.freeze(Object.keys(BATTLE_ITEMS));
export const BATTLE_ITEM_ID_SET = new Set(BATTLE_ITEM_IDS);

function tooltipKey(itemId) {
    return `item.cobblemon.${String(itemId).replace(/^lota:/, "")}.tooltip`;
}

function containsTranslation(rawMessage, key) {
    if (!rawMessage || typeof rawMessage !== "object") return false;
    if (rawMessage.translate === key) return true;
    return Array.isArray(rawMessage.rawtext)
        && rawMessage.rawtext.some(part => containsTranslation(part, key));
}

function isGrayTooltip(rawMessage, key) {
    if (!containsTranslation(rawMessage, key)) return false;
    return Array.isArray(rawMessage?.rawtext)
        && rawMessage.rawtext.some(part => typeof part?.text === "string" && part.text.includes("§7"));
}

export function battleItemTooltipLine(itemId) {
    if (!BATTLE_ITEM_ID_SET.has(itemId)) return undefined;
    return {
        rawtext: [
            { text: "§7" },
            { translate: tooltipKey(itemId) }
        ]
    };
}

export function withBattleItemTooltip(itemId, rawLore = []) {
    const line = battleItemTooltipLine(itemId);
    if (!line) return undefined;

    const key = tooltipKey(itemId);
    const current = Array.isArray(rawLore) ? rawLore : [];
    if (current.length > 0 && isGrayTooltip(current[0], key)) return undefined;

    const preserved = current.filter(existing => !containsTranslation(existing, key));
    return [line, ...preserved].slice(0, 20);
}
