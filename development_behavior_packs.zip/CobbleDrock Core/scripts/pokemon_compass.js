import { world, system } from "@minecraft/server";
import { updateMountFlight, forgetMountFlight } from "./flight_riding.js";
import { releaseShoulderMount } from "./shoulder_mount.js";
import { ActionFormData } from "@minecraft/server-ui";
import { captureBallCode, CAPTURE_BALLS } from "./capture_rate.js";
import { loadPartyFromPlayer, savePartyToPlayer, savePokemonToEntity, generateRandomPokemon, addPokemonToPlayerParty } from "./storage.js";
import { RIDE_STATS } from "./ride_stats.js";
import { validateSummonTarget } from "./storage_service.js";
import { tryStartPlayerChallenge } from "./battle_system.js";
import { battleStats, speciesData } from "./battle_math.js";
import { SUMMARY_STAT_MODES, summaryStatButtons } from "./summary_stats.js";
import { MOVE_DATA, moveEffectChance } from "./move_registry.js";
import { experienceForLevel } from "./experience.js";
import { evolvePokemon, pendingEvolutions } from "./evolution.js";
import {
    spawnColoredFlame,
    spawnPokeballSendFlash,
    detectPokemonEvolutionMetrics,
    runEvolutionSequence,
    settleRevealedPokemon
} from "./particle_utils.js";
import { heldItemHudCode } from "./held_items.js";
import { pokemonFormTexture } from "./form_ui_textures.js";
import { showAccessoryMenu } from "./accessory_system.js";
import { battleEntityType, playerHasMegaBracelet } from "./mega_evolution.js";
import { applyPokemonSkinToEntity, publishPokemonAppearanceEvent } from "./pokemon_skin_api.js";
import { playRecallToTrainerMotion } from "./capture_animation.js";
import { partyActivityForPokemon, partyStatusCode } from "./party_hud_presentation.js";
import {
    airFollowMode,
    directAirVelocity,
    distanceBetween,
    isOriginalFlyingType,
    ownerAirTarget,
    shortestYawDifference,
    velocityCorrection,
    yawForVelocity
} from "./air_follow_math.js";

const COMPASS_PAN_VARIANT = Object.freeze({1:3,2:4,3:25,4:15,5:15,6:25,7:15,8:22,9:25,10:3,11:8,
    12:8,13:3,14:8,15:8,16:15,17:15,18:15,19:3,20:8,23:8,24:8,25:8,26:8,27:15,28:15,29:8,30:15,
    32:8,33:15,34:15,35:8,36:8,37:15,41:15,42:8,43:8,44:8,45:8,46:3,47:3,48:8,49:8,50:15,51:15,
    54:4,55:11,56:3,57:3,59:22,61:15,62:15,63:15,64:25,65:25,66:15,67:3,68:3,69:8,70:8,71:15,
    72:11,73:11,74:11,75:18,76:15,77:15,78:15,79:18,80:11,81:25,82:25,83:15,84:25,85:25,88:18,
    90:8,91:25,92:15,95:16,96:25,97:25,98:15,99:8,100:15,101:15,102:15,103:15,106:15,107:15,
    108:8,109:18,110:25,111:15,112:25,113:8,115:15,116:8,117:8,118:15,119:24,120:8,121:8,123:15,
    125:15,127:25,128:25,129:25,130:25,131:25,132:18,137:15,138:15,139:15,140:15,141:15,142:22,
    143:15,147:15,148:15,149:25,150:25,151:25,152:11,153:15,154:18,155:11,156:25,157:11,158:15,
    159:15,160:15,163:8,164:25,165:8,166:3,167:11,168:18,169:25,170:8,171:15,172:8,173:8,176:25,
    179:8,180:8,181:15,182:3,187:15,188:15,189:8,190:8,191:25,192:8,194:6,198:3,199:11,200:25,
    201:15,202:25,203:15,206:15,208:25,209:15,210:15,212:15,213:8,214:8,215:11,216:8,217:25,
    218:22,219:22,220:15,221:8,222:15,226:8,227:15,231:15,232:25,233:15,234:15,236:15,237:15,
    239:15,240:8,241:22,242:15,245:25,248:25,251:15,255:15,257:25,262:8,263:15,264:8,267:1,
    269:1,271:8,272:4,276:15,277:15,278:4,279:8,280:15,281:15,282:25,283:8,284:8,285:8,286:25,
    289:15,299:12,300:12,302:25,304:15,311:15,312:15,313:8,314:8,315:15,316:15,317:15,318:25,
    320:25,321:25,322:15,324:15,325:25,327:8,330:15,331:8,332:15,333:25,334:25,337:22,338:22,
    339:3,341:15,342:11,343:15,344:15,345:22,346:22,347:8,348:18,349:8,350:15,351:9,352:25,
    353:8,354:11,355:15,356:15,357:18,358:25,363:3,366:15,369:25,370:15,371:25,372:8,373:15,
    374:25,375:25,376:25,382:17,383:12,385:25,386:15,387:15,388:15,389:15,390:8,391:6,392:8,
    393:4,394:4,395:11,398:25,399:8,401:15,402:15,406:8,407:25,408:15,409:15,410:25,411:25,
    412:5,413:7,415:15,416:15,418:15,420:15,421:25,422:11,424:25,427:15,428:15,430:25,433:15,
    436:25,437:25,438:25,439:8,440:15,442:11,443:8,444:8,445:15,446:15,447:15,448:15,449:25,
    450:25,453:15,454:8,455:15,456:15,457:15,458:8,459:8,460:15,461:11,462:25,463:15,464:25,
    468:25,473:15,474:8,476:15,477:15,480:3,481:3,482:3,483:15,484:15,485:15,487:15,489:8,490:3,
    491:15,492:11,493:25,494:15,495:15,497:15,498:8,499:15,500:25,501:15,502:8,504:15,505:15,
    509:15,510:25,519:11,520:8,521:11,522:25,523:11,524:15,525:15,526:15,529:15,530:15,532:15,
    533:15,534:15,535:25,536:15,537:25,540:15,541:15,542:15,543:8,544:8,545:8,546:15,547:15,
    548:15,551:15,552:25,553:25,554:11,555:15,557:15,558:19,561:3,564:22,565:25,566:15,567:15,
    577:25,578:25,579:25,582:8,583:11,584:15,592:15,594:25,595:11,596:18,597:8,598:8,599:15,
    600:25,601:15,604:15,605:18,606:25,607:15,608:15,609:8,610:15,612:15,613:4,615:15,618:15,
    622:25,626:15,627:8,628:15,629:12,630:24,631:15,633:15,634:25,635:10,636:8,637:25,638:15,
    639:25,640:15,641:25,642:11,643:15,644:20,645:25,646:15,647:15,648:20,649:8,650:11,651:15,
    653:14,655:22,656:8,657:15,658:15,659:15,660:15,661:3,662:8,663:15,664:8,665:15,666:15,
    669:18,670:25,671:25,672:8,673:15,679:15,680:15,681:15,682:15,683:15,690:15,696:25,697:25,
    698:15,699:22,702:6,703:21,704:15,705:15,706:15,708:15,709:15,710:15,711:8,712:8,716:15,
    717:12,718:8,719:8,720:25,721:15,725:25,726:15,727:25,728:15,729:15,730:15,734:25,735:15,
    736:8,737:3,738:15,741:4,749:15,750:25,753:25,754:25,759:8,760:25,764:18,766:15,767:6,
    768:15,770:11,772:8,773:8,774:15,775:15,778:15,780:25,781:15,785:8,786:25,787:25,788:25,
    789:15,790:15,791:15,793:15,794:8,795:15,796:15,797:20,798:25,799:23,801:3,802:25,805:15,
    806:25,807:15,808:25,809:15,810:8,811:8,812:8,813:3,814:25,816:8,817:15,818:8,819:25,820:18,
    821:3,822:8,823:25,824:15,825:15,826:15,827:8,828:25,829:25,830:25,831:11,832:15,840:11,
    846:15,847:25,850:25,851:25,854:8,855:11,862:25,864:25,868:25,869:15,870:8,873:8,874:15,
    878:25,879:25,880:25,881:15,882:25,883:22,885:15,886:15,887:25,888:25,889:8,890:20,892:8,
    894:5,896:5,897:25,898:15,899:15,900:8,901:24,903:11,905:25,906:8,907:15,908:15,909:15,
    910:15,911:25,912:6,914:8,915:11,916:15,921:8,922:13,923:5,924:2,925:2,926:8,927:8,932:11,
    933:15,934:25,938:8,939:8,940:8,941:15,944:15,945:25,946:22,947:22,948:8,949:11,951:15,
    952:15,953:8,954:25,955:25,965:11,966:11,967:25,971:8,972:15,973:25,974:15,975:15,977:25,
    979:20,981:15,982:15,984:25,985:11,986:15,987:25,988:25,989:25,990:15,993:15,994:15,995:15,
    996:15,997:15,998:15,999:8,1000:15,1001:25,1002:8,1003:15,1004:15,1005:8,1007:8,1008:22,
    1009:15,1012:8,1013:11,1014:25,1015:15,1016:22,1017:15,1020:25,1021:15,1022:15,1023:15,
    1024:8,1025:25,1031:8,1032:8,1033:15});
const COMPASS_PORTRAIT_MIN_DEX = 1;
const COMPASS_PORTRAIT_MAX_DEX = 1025;
const COMPASS_PORTRAIT_FALLBACK_DEX = 1;
function compassPad4(value) {
    return String(Math.max(0, Math.floor(Number(value)) || 0)).padStart(4, "0");
}
function compassDexOf(pokemon) {
    const direct = Math.floor(Number(pokemon?.pokedex));
    if (Number.isInteger(direct) && direct > 0) return direct;
    const data = speciesData(pokemon) || {};
    return Math.max(0, Math.floor(Number(data.pokedex) || 0));
}
function compassPortraitDex(pokemon) {
    const dex = compassDexOf(pokemon);
    if (dex < COMPASS_PORTRAIT_MIN_DEX || dex > COMPASS_PORTRAIT_MAX_DEX) {
        return COMPASS_PORTRAIT_FALLBACK_DEX;
    }
    return dex;
}
function compassPortraitTexture(pokemon) {
    return `textures/gui/pokedex/portrait_anim/${compassPad4(compassPortraitDex(pokemon))}`;
}
function compassPanToken(pokemon) {
    const variant = COMPASS_PAN_VARIANT[compassPortraitDex(pokemon)] ?? 0;
    return `|PAN:${String(variant).padStart(2, "0")}|`;
}

const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";
const SELECTED_SLOT_SUBSCRIBERS = new Set();
const PARTY_SELECT_TAG = "lota:party_selecting";
const PARTY_FORM_TITLE = "cobbledrock.party.summary";
const SUMMARY_TAB_NAMES = ["info", "moves", "stats", "marks"];
const SUMMARY_PARTY_BUTTONS = 6;
const SUMMARY_TAB_BUTTON_START = 6;
const SUMMARY_SWAP_BUTTON = 10;
const SUMMARY_BACK_BUTTON = 11;
const SUMMARY_MOVE_BUTTON_START = 22;
const SUMMARY_MOVE_UP_BUTTON_START = 26;
const SUMMARY_MOVE_DOWN_BUTTON_START = 30;
const SUMMARY_MOVE_SWAP_BUTTON_START = 34;
const SUMMARY_MOVE_DETAIL_BUTTON = 38;
const SUMMARY_RELEARN_BUTTON_START = 39;
const SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT = 4;
const SUMMARY_REMOVE_MOVE_BUTTON = 43;
const SUMMARY_EVOLVE_BUTTON = 49;
const SUMMARY_RELEARN_EXTRA_BUTTON_START = 50;
const SUMMARY_RELEARN_EXTRA_BUTTON_COUNT = 25;
const SUMMARY_RELEARN_BUTTON_COUNT = SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT + SUMMARY_RELEARN_EXTRA_BUTTON_COUNT;
const SUMMARY_ACCESSORY_BUTTON = SUMMARY_RELEARN_EXTRA_BUTTON_START + SUMMARY_RELEARN_EXTRA_BUTTON_COUNT;
const SUMMARY_STAT_MODE_BUTTON_START = SUMMARY_ACCESSORY_BUTTON + 1;
const SUMMARY_PORTRAIT_BUTTON_START = SUMMARY_STAT_MODE_BUTTON_START + SUMMARY_STAT_MODES.length;
const SUMMARY_INFO_BUTTON_START = SUMMARY_PORTRAIT_BUTTON_START + SUMMARY_PARTY_BUTTONS;
const SUMMARY_MARKS_TEXT_BUTTON = SUMMARY_INFO_BUTTON_START + 9;
const FORM_BUSY_RETRY_LIMIT = 2;
const NINCADA_SPECIES_KEY = "nincada";
const NINJASK_SPECIES_KEY = "ninjask";
const SHEDINJA_SPECIES_ID = "lota:shedinja";
const MAX_PARTY_SIZE = 6;
const summonThrows = new Map();
const selectorSessions = new Map();
const flyingMounts = new Map();
const pendingFlightTransitions = new Map();
const trackedRiddenMounts = new Map();
const riderControlStates = new Map();
const airFollowerStates = new Map();
let nextAirFollowerDiscoveryTick = 0;

function setSelectedPartySlot(player, slot) {
    const next = Math.max(0, Math.min(5, Math.floor(Number(slot) || 0)));
    player.setDynamicProperty(SELECTED_SLOT_PROPERTY, next);
    for (const callback of SELECTED_SLOT_SUBSCRIBERS) {
        try { callback(player, next); }
        catch (error) { console.warn(`Selected party slot subscriber failed: ${error}`); }
    }
}
const PARTY_DIMENSION_IDS = Object.freeze([
    "minecraft:overworld", "minecraft:nether", "minecraft:the_end",
    "overworld", "nether", "the_end",
    "lota:wild_world", "lota:island_world", "lota:raid_arena"
]);

function partyDimensions() {
    const found = new Map();
    for (const dimensionId of PARTY_DIMENSION_IDS) {
        try {
            const dimension = world.getDimension(dimensionId);
            found.set(String(dimension.id), dimension);
        } catch (error) {}
    }
    return [...found.values()];
}

function pokemonName(pokemon) {
    const species = String(pokemon?.species || "lota:unknown").replace("lota:", "");
    return pokemon?.nickname || species;
}

function selectedSlot(player, party) {
    const stored = Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY));
    return Number.isInteger(stored) && stored >= 0 && stored < party.length ? stored : 0;
}

function isUsablePokemon(pokemon) {
    return !!pokemon && Number(pokemon.currentHp) > 0;
}

function firstUsableSlot(party, preferredSlot = 0) {
    if (isUsablePokemon(party[preferredSlot])) return preferredSlot;
    for (let slot = 0; slot < party.length; slot++) {
        if (isUsablePokemon(party[slot])) return slot;
    }
    return -1;
}

function closePartySelector(player) {
    selectorSessions.delete(player.id);
    try { player.removeTag(PARTY_SELECT_TAG); } catch (error) {}
}

function titleCase(value) {
    return String(value || "-")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

function summaryBallToken(pokemon) {
    return `|BALL:${captureBallCode(pokemon?.caughtBall)}|`;
}

function summaryHeldItemToken(pokemon) {
    const code = heldItemHudCode(pokemon?.heldItem);
    return code ? `|I:${code}|` : "";
}

function summaryPartyActivities(player, party) {
    const entities = [];
    for (const dimension of partyDimensions()) {
        try { entities.push(...dimension.getEntities({ tags: ["lota:party_pokemon"] })); }
        catch (error) {}
    }
    return (Array.isArray(party) ? party : []).slice(0, SUMMARY_PARTY_BUTTONS).map(pokemon =>
        partyActivityForPokemon(pokemon, entities, player?.id)
    );
}

function summaryPartyButtonText(pokemon, slot, session, currentSlot, activities = []) {
    if (!pokemon) return `|SUM:S${slot}||EMPTY|`;
    const name = pokemonName(pokemon);
    const level = Math.max(1, Math.floor(Number(pokemon.level) || 1));
    const maxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || 1));
    const currentHp = Math.max(0, Math.min(maxHp, Math.floor(Number(pokemon.currentHp) || 0)));
    const hpStep = currentHp <= 0 ? 0 : Math.max(1, Math.min(10, Math.ceil((currentHp / maxHp) * 10)));
    const fainted = currentHp <= 0;
    const status = partyStatusCode(pokemon);
    const activity = activities[slot] || "";
    const tokens = [
        `|SUM:S${slot}|`,
        `|HP:${String(hpStep).padStart(2, "0")}|`,
        summaryBallToken(pokemon),
        summaryHeldItemToken(pokemon),
        slot === currentSlot ? "|ACTIVE|" : "",
        slot === session.detailSlot ? "|DETAIL|" : "",
        slot === session.swapSource ? "|SWAP_SOURCE|" : "",
        fainted ? "|FNT|" : "",
        status ? `|STATUS:${status}|` : "",
        activity ? `|ACT:${activity}|` : ""
    ].join("");
    const heldItem = pokemon.heldItem ? titleCase(pokemon.heldItem) : "-";
    return `Lv.${level}\n${name}\n${heldItem}${"\n".repeat(10)}${tokens}`;
}

const ABILITY_DESCRIPTIONS = Object.freeze({
    overgrow: "Powers up Grass-type moves when the Pokemon's HP is low.",
    blaze: "Powers up Fire-type moves when the Pokemon's HP is low.",
    torrent: "Powers up Water-type moves when the Pokemon's HP is low.",
    swarm: "Powers up Bug-type moves when the Pokemon's HP is low."
});

function infoSummaryFields(player, pokemon) {
    const data = speciesData(pokemon) || {};
    const level = Math.max(1, Math.floor(Number(pokemon.level) || 1));
    const experience = Math.max(0, Math.floor(Number(pokemon.experience) || 0));
    const nextLevel = level >= 100
        ? 0
        : Math.max(0, experienceForLevel(data.experienceGroup, level + 1) - experience);
    const ability = String(pokemon.ability || "-").replace(/^.*:/, "").toLowerCase();
    const types = Array.isArray(data.types) && data.types.length
        ? data.types.map(titleCase).join("/")
        : "Normal";
    const trainer = String(pokemon.originalTrainer?.name || player.name || "Unknown");
    const description = ABILITY_DESCRIPTIONS[ability] || "-";
    return [
        String(Math.max(0, Number(data.pokedex) || 0).toString().padStart(4, "0")),
        String(data.name || pokemonName(pokemon)),
        types,
        trainer,
        titleCase(pokemon.mintedNature || pokemon.nature),
        titleCase(ability),
        description,
        String(experience),
        String(nextLevel)
    ];
}

function infoSummaryText(player, pokemon) {
    return infoSummaryFields(player, pokemon).join("\n");
}

function summaryInfoButtonText(value, field) {
    return `${value}${"\n".repeat(12)}|INFO:${field}|`;
}

function normalizedMoveId(move) {
    return String(move?.id || move || "").replace(/^cobblemon:/, "").toLowerCase();
}

function summaryMoveData(move) {
    const id = normalizedMoveId(move);
    return {
        id,
        ...(MOVE_DATA[id] || {
            name: titleCase(id),
            type: "typeless",
            category: "physical",
            power: 0,
            accuracy: 100,
            pp: 1
        })
    };
}

function summaryMovePpTokens(ppText) {
    const display = String(ppText ?? "").slice(0, 5).padStart(5, " ");
    return [...display]
        .map((character, index) => character === " " ? "" : `|PP${index}:${character}|`)
        .join("");
}

function summaryMoveButtonText(pokemon, index, selectedIndex = -1) {
    const move = Array.isArray(pokemon?.moves) ? pokemon.moves[index] : undefined;
    if (!move) return `${"\n".repeat(12)}|MOVE:M${index}||EMPTY|`;

    const data = summaryMoveData(move);
    const pp = Math.max(0, Math.floor(Number(move?.pp) || 0));
    const maxPp = Math.max(1, Math.floor(Number(move?.maxPp) || Number(data.pp) || 1));
    const selected = index === selectedIndex ? "|MOVE_SELECTED|" : "";
    const ppTokens = summaryMovePpTokens(`${pp}/${maxPp}`);
    return `${data.name}${"\n".repeat(12)}|MOVE:M${index}||TYPE:${data.type}||CAT:${data.category}|${selected}${ppTokens}`;
}

function summaryMoveActionText(pokemon, index, action, activeSwapIndex = -1) {
    const move = Array.isArray(pokemon?.moves) ? pokemon.moves[index] : undefined;
    const active = action === "SWAP" && index === activeSwapIndex ? "|MOVE_SWAP_ACTIVE|" : "";
    if (move) return `|MOVE:${action}${index}|${action === "SWAP" ? "|MOVE_SWAP|" : ""}${active}`;
    return action === "SWAP" ? `|MOVE:${action}${index}||MOVE_ADD|${active}` : `|MOVE:${action}${index}||EMPTY|`;
}

function summaryPokemonTypeButtonTexts(pokemon) {
    const types = Array.isArray(speciesData(pokemon)?.types)
        ? speciesData(pokemon).types.map(type => String(type).toLowerCase()).slice(0, 2)
        : ["normal"];
    if (types.length > 1) {
        return ["|PKTYPE:S||EMPTY|", `|PKTYPE:D1||TYPE:${types[0]}|`, `|PKTYPE:D2||TYPE:${types[1]}|`];
    }
    return [`|PKTYPE:S||TYPE:${types[0] || "normal"}|`, "|PKTYPE:D1||EMPTY|", "|PKTYPE:D2||EMPTY|"];
}

function summaryMoveDetailText(pokemon, selectedIndex) {
    const move = Array.isArray(pokemon?.moves) ? pokemon.moves[selectedIndex] : undefined;
    if (!move) return `-\n-\n-\n${"\n".repeat(8)}|DETAIL_EMPTY|`;

    const data = summaryMoveData(move);
    const power = Number(data.power) > 0 ? String(Math.floor(Number(data.power))) : "-";
    const accuracy = Number(data.accuracy) > 0 ? `${Math.floor(Number(data.accuracy))}%` : "-";
    const chance = moveEffectChance(data.id);
    const effect = chance > 0 ? `${chance}%` : "-";
    const description = data.description || data.shortDescription || "-";
    return `${power}\n${accuracy}\n${effect}\n${description}${"\n".repeat(8)}|DETAIL:${selectedIndex}|`;
}

function availableRelearnMoves(pokemon) {
    const known = new Set((Array.isArray(pokemon?.moves) ? pokemon.moves : []).map(normalizedMoveId));
    const candidates = [];
    const append = rawId => {
        const id = normalizedMoveId(rawId);
        if (!id || known.has(id) || candidates.includes(id)) return;
        candidates.push(id);
    };

    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const levelMoves = Array.isArray(speciesData(pokemon)?.levelMoves) ? speciesData(pokemon).levelMoves : [];
    for (const entry of levelMoves) {
        if (Math.floor(Number(entry?.level) || 0) <= level) append(entry?.id);
    }
    if (Array.isArray(pokemon?.benchedMoves)) pokemon.benchedMoves.forEach(append);
    if (Array.isArray(pokemon?.relearnableMoves)) pokemon.relearnableMoves.forEach(append);
    return candidates;
}

function summaryRelearnButtonText(moveId, index) {
    if (!moveId) return `${"\n".repeat(12)}|RELEARN:R${index}||EMPTY|`;
    const data = summaryMoveData(moveId);
    const power = Number(data.power) > 0 ? String(Math.floor(Number(data.power))) : "-";
    const accuracy = Number(data.accuracy) > 0 ? `${Math.floor(Number(data.accuracy))}%` : "-";
    const chance = moveEffectChance(data.id);
    const effect = chance > 0 ? `${chance}%` : "-";
    return `${data.name}\n${power}\n${accuracy}\n${effect}\n${data.pp}PP${"\n".repeat(7)}|RELEARN:R${index}||TYPE:${data.type}||CAT:${data.category}|`;
}

function removeSummaryMove(player, session) {
    const pokemon = session.party[session.detailSlot];
    const index = session.moveSwapIndex;
    if (!pokemon || !Number.isInteger(index) || !Array.isArray(pokemon.moves) || pokemon.moves.length <= 1 || !pokemon.moves[index]) return false;

    const removedId = normalizedMoveId(pokemon.moves[index]);
    pokemon.moves.splice(index, 1);
    const benched = (Array.isArray(pokemon.benchedMoves) ? pokemon.benchedMoves : []).map(normalizedMoveId).filter(Boolean);
    if (removedId && !benched.includes(removedId)) benched.push(removedId);
    pokemon.benchedMoves = [...new Set(benched)];
    savePartyToPlayer(player, session.party);
    session.moveSelection = -1;
    session.moveSwapIndex = null;
    session.relearnPage = 0;
    return true;
}

function reorderSummaryMove(player, session, source, direction) {
    const pokemon = session.party[session.detailSlot];
    const moves = Array.isArray(pokemon?.moves) ? pokemon.moves : [];
    if (source < 0 || source >= moves.length || moves.length < 2) return;
    const target = (source + direction + moves.length) % moves.length;
    [moves[source], moves[target]] = [moves[target], moves[source]];
    pokemon.moves = moves;
    savePartyToPlayer(player, session.party);
    session.moveSelection = -1;
}

function replaceSummaryMove(player, session, replacementId) {
    const pokemon = session.party[session.detailSlot];
    const index = session.moveSwapIndex;
    if (!pokemon || !Number.isInteger(index) || !Array.isArray(pokemon.moves) || index < 0 || index > pokemon.moves.length || index >= 4) return false;
    const data = summaryMoveData(replacementId);
    if (!data.id) return false;

    const oldId = normalizedMoveId(pokemon.moves[index]);
    const benched = [
        ...(Array.isArray(pokemon.benchedMoves) ? pokemon.benchedMoves : []),
        ...(Array.isArray(pokemon.relearnableMoves) ? pokemon.relearnableMoves : [])
    ].map(normalizedMoveId).filter(Boolean);
    if (oldId && oldId !== replacementId && !benched.includes(oldId)) benched.push(oldId);
    pokemon.benchedMoves = [...new Set(benched)].filter(id => id !== replacementId);
    if (Array.isArray(pokemon.relearnableMoves)) {
        pokemon.relearnableMoves = pokemon.relearnableMoves.map(normalizedMoveId).filter(id => id && id !== replacementId);
    }
    const learnedMove = { id: replacementId, pp: data.pp, maxPp: data.pp };
    if (index === pokemon.moves.length) pokemon.moves.push(learnedMove);
    else pokemon.moves[index] = learnedMove;
    savePartyToPlayer(player, session.party);
    session.moveSelection = -1;
    session.moveSwapIndex = null;
    session.relearnPage = 0;
    return true;
}

function marksSummaryText(pokemon) {
    const markings = Array.isArray(pokemon.markings) ? pokemon.markings.filter(Boolean) : [];
    return [
        "Marks",
        "",
        markings.length ? markings.map(titleCase).join("\n") : "-"
    ].join("\n");
}

function summaryBody(player, pokemon, tab) {
    if (tab === 1) return "";
    if (tab === 2) return "";
    if (tab === 3) return marksSummaryText(pokemon);
    return infoSummaryText(player, pokemon);
}

function evolutionButtonText(evolutions) {
    if (!Array.isArray(evolutions) || evolutions.length === 0) {
        return `Evolve${"\n".repeat(12)}|SUM:EVOLVE||EMPTY|`;
    }
    return `Evolve${"\n".repeat(12)}|SUM:EVOLVE|`;
}

function detachSummonTrackers(entityId) {
    forgetMountFlight({ id: entityId });
    flyingMounts.delete(entityId);
    pendingFlightTransitions.delete(entityId);
    trackedRiddenMounts.delete(entityId);
    riderControlStates.delete(entityId);
    airFollowerStates.delete(entityId);
}

function spawnEvolvedSummon(player, pokemon, location, dimension) {
    try {
        const entity = dimension.spawnEntity(battleEntityType(pokemon), location);
        savePokemonToEntity(entity, pokemon);
        entity.addTag("lota:party_pokemon");
        entity.setDynamicProperty("lota:party_owner_id", player.id);
        initializePartyFollower(entity, player.id);
        try { entity.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
        applyPokemonSkinToEntity(entity, pokemon);
        entity.nameTag = `§f${pokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        publishPokemonAppearanceEvent("evolved", player, pokemon, entity);
        return entity;
    } catch (error) {
        console.warn(`Evolved party Pokemon could not be respawned: ${error}`);
        return undefined;
    }
}

function isCreativePlayer(player) {
    try { return String(player.getGameMode()).toLowerCase() === "creative"; } catch (error) { return false; }
}

function pokeBallInventorySlot(container) {
    if (!container) return -1;
    const ballItemIds = new Set(Object.values(CAPTURE_BALLS).map(ball => ball.itemId));
    for (let slot = 0; slot < container.size; slot++) {
        const stack = container.getItem(slot);
        if (stack && ballItemIds.has(stack.typeId)) return slot;
    }
    return -1;
}

function consumePokeBallAtSlot(player, container, slot) {
    if (isCreativePlayer(player)) return true;
    const stack = container.getItem(slot);
    if (!stack) return false;
    if (stack.amount <= 1) {
        container.setItem(slot, undefined);
    } else {
        stack.amount -= 1;
        container.setItem(slot, stack);
    }
    return true;
}

function trySpawnShedinjaFromNincada(player, session, level) {
    if (!Array.isArray(session.party) || session.party.length >= MAX_PARTY_SIZE) return false;

    const container = player.getComponent("minecraft:inventory")?.container;
    const ballSlot = pokeBallInventorySlot(container);
    if (ballSlot < 0) return false;
    if (!consumePokeBallAtSlot(player, container, ballSlot)) return false;

    const shedinja = generateRandomPokemon(SHEDINJA_SPECIES_ID, level);
    const outcome = addPokemonToPlayerParty(player, shedinja, session.party);
    if (!outcome.success) return false;

    session.party = loadPartyFromPlayer(player);
    try { player.playSound("lota.evolution.notification", { volume: 0.7, pitch: 1.3 }); } catch (error) {}
    player.sendMessage(`§aA Shedinja emerged from the discarded shell!`);
    return true;
}

function completeEvolution(player, session, evolutionId) {
    const pokemon = session.party[session.detailSlot];
    if (!pokemon) return closePartySelector(player);

    const summoned = findExistingSummon(pokemon.uuid);
    if (summoned?.hasTag("lota:shoulder_mounted")) releaseShoulderMount(summoned);
    const effectLocation = summoned?.isValid ? { ...summoned.location } : { ...player.location };
    const evoMetrics = summoned?.isValid ? detectPokemonEvolutionMetrics(summoned) : { scale: 1, height: undefined };

    const result = evolvePokemon(pokemon, evolutionId);
    if (!result) return closePartySelector(player);

    savePartyToPlayer(player, session.party);
    try { player.playSound("lota.evolution.full", { volume: 0.85, pitch: 1.0 }); } catch (error) {}
    player.sendMessage(`§a${result.oldName} evolved into ${result.newName}!`);

    if (result.oldSpecies === NINCADA_SPECIES_KEY && result.result === NINJASK_SPECIES_KEY) {
        trySpawnShedinjaFromNincada(player, session, pokemon.level);
    }

    session.moveSelection = -1;
    session.moveSwapIndex = null;
    session.relearnPage = 0;

    if (summoned?.isValid) {
        const dimension = summoned.dimension;
        const swapSummonedModel = () => {
            const oldEntityId = summoned.id;
            detachSummonTrackers(oldEntityId);
            try { if (summoned.isValid) summoned.remove(); } catch (error) {}
            const evolved = spawnEvolvedSummon(player, pokemon, effectLocation, dimension);
            try { dimension.playSound("lota.evolution.notification", effectLocation, { volume: 0.7, pitch: 1.0 }); } catch (error) {}
            settleRevealedPokemon(evolved);
        };
        try {
            runEvolutionSequence(dimension, effectLocation, evoMetrics.scale, evoMetrics.height, summoned, player, () => {
                try {
                    swapSummonedModel();
                } catch (error) {
                    console.warn(`Evolution model swap failed: ${error}`);
                }
            });
        } catch (error) {
            console.warn(`Evolution particle sequence failed: ${error}`);
            swapSummonedModel();
        }
    }

    return closePartySelector(player);
}

function showEvolutionSelection(player, session) {
    const pokemon = session.party[session.detailSlot];
    const evolutions = pendingEvolutions(pokemon);
    if (evolutions.length === 0) return closePartySelector(player);
    if (evolutions.length === 1) return completeEvolution(player, session, evolutions[0].id);

    session.formOpen = true;
    const form = new ActionFormData()
        .title("cobbledrock.evolution")
        .body(`${pokemonName(pokemon)} is ready to evolve!`);
    for (const evolution of evolutions) {
        const name = speciesData(evolution.result)?.name || titleCase(evolution.result);
        form.button(`${name}${"\n".repeat(8)}|FORM_IDENTITY|`, pokemonFormTexture(evolution.result));
    }
    form.button("Back");

    form.show(player).then(response => {
        session.formOpen = false;
        if (response.canceled || response.selection === evolutions.length) return closePartySelector(player);
        const selected = evolutions[Math.floor(Number(response.selection))];
        if (!selected) return closePartySelector(player);
        completeEvolution(player, session, selected.id);
    }).catch(error => {
        session.formOpen = false;
        console.warn(`Evolution selection form failed: ${error}`);
        closePartySelector(player);
    });
}

function reopenPartySelector(player, session) {
    showPartySelector(player, session);
}

function retryPartySelectorIfBusy(player, session, reason) {
    if (!String(reason ?? "").toLowerCase().includes("busy")) return false;

    const retries = Math.max(0, Math.floor(Number(session.busyRetries) || 0));
    if (retries >= FORM_BUSY_RETRY_LIMIT) return false;

    session.busyRetries = retries + 1;
    system.run(() => showPartySelector(player, session));
    return true;
}

function handlePartySummarySelection(player, session, selection) {
    if (selection === SUMMARY_ACCESSORY_BUTTON) {
        closePartySelector(player);
        return showAccessoryMenu(player, { onBack: () => showPartySelector(player, session) });
    }

    if (selection >= SUMMARY_STAT_MODE_BUTTON_START
        && selection < SUMMARY_STAT_MODE_BUTTON_START + SUMMARY_STAT_MODES.length) {
        session.statMode = selection - SUMMARY_STAT_MODE_BUTTON_START;
        session.tab = 2;
        return reopenPartySelector(player, session);
    }

    if (Number.isInteger(session.moveSwapIndex)) {
        session.tab = 1;
        if (selection === SUMMARY_BACK_BUTTON) {
            session.moveSwapIndex = null;
            session.moveSelection = -1;
            session.relearnPage = 0;
            return reopenPartySelector(player, session);
        }
        if (selection >= SUMMARY_MOVE_SWAP_BUTTON_START && selection < SUMMARY_MOVE_SWAP_BUTTON_START + 4) {
            const requestedIndex = selection - SUMMARY_MOVE_SWAP_BUTTON_START;
            const moves = Array.isArray(session.party[session.detailSlot]?.moves) ? session.party[session.detailSlot].moves : [];
            const targetIndex = moves[requestedIndex] ? requestedIndex : moves.length;
            session.moveSwapIndex = targetIndex === session.moveSwapIndex ? null : targetIndex;
            session.moveSelection = -1;
            session.relearnPage = 0;
            return reopenPartySelector(player, session);
        }
        const pokemon = session.party[session.detailSlot];
        const allOptions = availableRelearnMoves(pokemon);
        if (selection === SUMMARY_REMOVE_MOVE_BUTTON) {
            removeSummaryMove(player, session);
            return reopenPartySelector(player, session);
        }
        if (selection >= SUMMARY_RELEARN_BUTTON_START && selection < SUMMARY_RELEARN_BUTTON_START + SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT) {
            replaceSummaryMove(player, session, allOptions[selection - SUMMARY_RELEARN_BUTTON_START]);
        } else if (selection >= SUMMARY_RELEARN_EXTRA_BUTTON_START && selection < SUMMARY_RELEARN_EXTRA_BUTTON_START + SUMMARY_RELEARN_EXTRA_BUTTON_COUNT) {
            replaceSummaryMove(
                player,
                session,
                allOptions[SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT + selection - SUMMARY_RELEARN_EXTRA_BUTTON_START]
            );
        }
        return reopenPartySelector(player, session);
    }

    if (selection >= 0 && selection < SUMMARY_PARTY_BUTTONS) {
        const pokemon = session.party[selection];
        if (!pokemon) return reopenPartySelector(player, session);

        if (Number.isInteger(session.swapSource)) {
            const source = session.swapSource;
            if (source !== selection && session.party[source] && session.party[selection]) {
                [session.party[source], session.party[selection]] = [session.party[selection], session.party[source]];
                savePartyToPlayer(player, session.party);
                const current = selectedSlot(player, session.party);
                if (current === source) setSelectedPartySlot(player, selection);
                else if (current === selection) setSelectedPartySlot(player, source);
            }
            session.swapSource = null;
        }

        session.detailSlot = selection;
        session.moveSelection = -1;
        if (isUsablePokemon(session.party[selection])) {
            setSelectedPartySlot(player, selection);
        }
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_TAB_BUTTON_START && selection < SUMMARY_TAB_BUTTON_START + SUMMARY_TAB_NAMES.length) {
        session.tab = selection - SUMMARY_TAB_BUTTON_START;
        session.moveSelection = -1;
        session.moveSwapIndex = null;
        session.relearnPage = 0;
        return reopenPartySelector(player, session);
    }

    if (selection === SUMMARY_SWAP_BUTTON) {
        session.swapSource = Number.isInteger(session.swapSource) ? null : session.detailSlot;
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_MOVE_BUTTON_START && selection < SUMMARY_MOVE_BUTTON_START + 4) {
        session.tab = 1;
        const index = selection - SUMMARY_MOVE_BUTTON_START;
        const move = session.party[session.detailSlot]?.moves?.[index];
        session.moveSelection = move ? index : -1;
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_MOVE_UP_BUTTON_START && selection < SUMMARY_MOVE_UP_BUTTON_START + 4) {
        session.tab = 1;
        reorderSummaryMove(player, session, selection - SUMMARY_MOVE_UP_BUTTON_START, -1);
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_MOVE_DOWN_BUTTON_START && selection < SUMMARY_MOVE_DOWN_BUTTON_START + 4) {
        session.tab = 1;
        reorderSummaryMove(player, session, selection - SUMMARY_MOVE_DOWN_BUTTON_START, 1);
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_MOVE_SWAP_BUTTON_START && selection < SUMMARY_MOVE_SWAP_BUTTON_START + 4) {
        session.tab = 1;
        const index = selection - SUMMARY_MOVE_SWAP_BUTTON_START;
        const moves = Array.isArray(session.party[session.detailSlot]?.moves) ? session.party[session.detailSlot].moves : [];
        const targetIndex = moves[index] ? index : moves.length;
        if (targetIndex < 4) session.moveSwapIndex = session.moveSwapIndex === targetIndex ? null : targetIndex;
        session.moveSelection = -1;
        session.relearnPage = 0;
        return reopenPartySelector(player, session);
    }

    if (selection === SUMMARY_EVOLVE_BUTTON) {
        return showEvolutionSelection(player, session);
    }

    if (selection === SUMMARY_MOVE_DETAIL_BUTTON || selection >= SUMMARY_RELEARN_BUTTON_START) {
        return reopenPartySelector(player, session);
    }

    if (selection >= SUMMARY_INFO_BUTTON_START) {
        return reopenPartySelector(player, session);
    }

    closePartySelector(player);
}

export function showPartySelector(player, existingSession = null) {
    const party = existingSession?.party || loadPartyFromPlayer(player);
    if (party.length === 0) {
        player.sendMessage("You have no Pokemon.");
        return;
    }

    const current = selectedSlot(player, party);
    const session = existingSession || {
        party,
        detailSlot: current,
        tab: 0,
        swapSource: null,
        moveSelection: -1,
        moveSwapIndex: null,
        relearnPage: 0,
        statMode: 0,
        formOpen: false,
        busyRetries: 0
    };
    session.statMode = Math.max(0, Math.min(SUMMARY_STAT_MODES.length - 1, Math.floor(Number(session.statMode) || 0)));
    if (session.formOpen) return;
    session.party = party;
    if (!session.party[session.detailSlot]) session.detailSlot = current;
    session.formOpen = true;
    selectorSessions.set(player.id, session);
    try { player.addTag(PARTY_SELECT_TAG); } catch (error) {}

    const selectedPokemon = party[session.detailSlot];
    const activities = summaryPartyActivities(player, party);
    const evolutionStateBefore = JSON.stringify({
        version: selectedPokemon?.evolutionTrackingVersion,
        pending: selectedPokemon?.pendingEvolutions
    });
    const evolutions = pendingEvolutions(selectedPokemon);
    const evolutionStateAfter = JSON.stringify({
        version: selectedPokemon?.evolutionTrackingVersion,
        pending: selectedPokemon?.pendingEvolutions
    });
    if (evolutionStateBefore !== evolutionStateAfter) savePartyToPlayer(player, party);
    const relearnMoves = availableRelearnMoves(selectedPokemon).slice(0, SUMMARY_RELEARN_BUTTON_COUNT);
    const tabName = SUMMARY_TAB_NAMES[session.tab] || SUMMARY_TAB_NAMES[0];
    const statMode = SUMMARY_STAT_MODES[session.statMode] || SUMMARY_STAT_MODES[0];
    const statModeToken = `|SMODE:${statMode}|`;
    const swapSuffix = session.tab === 1 && Number.isInteger(session.moveSwapIndex) ? ".swap" : "";
    const partySwapSuffix = Number.isInteger(session.swapSource) ? "|PARTYSWAP|" : "";
    const form = new ActionFormData()
        .title(`${PARTY_FORM_TITLE}.${tabName}${swapSuffix}${partySwapSuffix}${statModeToken}`)
        .body("");
    for (let slot = 0; slot < SUMMARY_PARTY_BUTTONS; slot++) {
        const pokemon = party[slot];
        const label = summaryPartyButtonText(pokemon, slot, session, current, activities);
        if (pokemon) form.button(label, pokemonFormTexture(pokemon));
        else form.button(label);
    }
    for (let tab = 0; tab < SUMMARY_TAB_NAMES.length; tab++) {
        form.button(`|SUM:T${tab}|${tab === session.tab ? "|TAB_ACTIVE|" : ""}`);
    }
    form.button(`|SUM:SWAP|${Number.isInteger(session.swapSource) ? "|SWAP_ACTIVE|" : ""}`);
    form.button("|SUM:BACK|");
    const statFields = summaryStatButtons(
        selectedPokemon,
        battleStats(selectedPokemon),
        statMode,
        speciesData(selectedPokemon)
    );
    for (const field of statFields) {
        if (typeof field === "string") form.button(field);
        else form.button(field.text, field.iconPath);
    }
    form.button(pokemonName(selectedPokemon));
    for (let index = 0; index < 4; index++) {
        form.button(summaryMoveButtonText(selectedPokemon, index, session.moveSelection));
    }
    for (let index = 0; index < 4; index++) form.button(summaryMoveActionText(selectedPokemon, index, "UP"));
    for (let index = 0; index < 4; index++) form.button(summaryMoveActionText(selectedPokemon, index, "DOWN"));
    for (let index = 0; index < 4; index++) form.button(summaryMoveActionText(selectedPokemon, index, "SWAP", session.moveSwapIndex));
    form.button(summaryMoveDetailText(selectedPokemon, session.moveSelection));
    for (let index = 0; index < SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT; index++) {
        form.button(summaryRelearnButtonText(relearnMoves[index], index));
    }
    const canRemoveMove = Number.isInteger(session.moveSwapIndex)
        && selectedPokemon?.moves?.[session.moveSwapIndex]
        && selectedPokemon.moves.length > 1;
    form.button(canRemoveMove ? "|RELEARN:REMOVE|" : "|RELEARN:REMOVE||EMPTY|");
    form.button("|RELEARN:PAGE_UP||EMPTY|");
    form.button("|RELEARN:PAGE_DOWN||EMPTY|");
    for (const typeButton of summaryPokemonTypeButtonTexts(selectedPokemon)) form.button(typeButton);
    form.button(evolutionButtonText(evolutions));
    for (
        let moveIndex = SUMMARY_RELEARN_VISIBLE_BUTTON_COUNT;
        moveIndex < SUMMARY_RELEARN_BUTTON_COUNT;
        moveIndex++
    ) {
        form.button(summaryRelearnButtonText(relearnMoves[moveIndex], moveIndex));
    }
    form.button(playerHasMegaBracelet(player)
        ? "|ACCESSORY:OPEN||ACCESSORY:EQUIPPED|"
        : "|ACCESSORY:OPEN||ACCESSORY:EMPTY|");
    for (let mode = 0; mode < SUMMARY_STAT_MODES.length; mode++) {
        form.button(`|STAT_MODE:${SUMMARY_STAT_MODES[mode].toUpperCase()}|${mode === session.statMode ? "|ACTIVE|" : ""}`);
    }
    for (let slot = 0; slot < SUMMARY_PARTY_BUTTONS; slot++) {
        const portraitPokemon = party[slot];
        if (!portraitPokemon) {
            form.button("|EMPTY|");
            continue;
        }
        const detailMarker = slot === session.detailSlot ? "|DETAIL|" : "";
        form.button(`${pokemonName(portraitPokemon)}${"\n".repeat(12)}|PROFILE|${compassPanToken(portraitPokemon)}${detailMarker}`, compassPortraitTexture(portraitPokemon));
    }
    const infoFields = infoSummaryFields(player, selectedPokemon).map((value, index) => summaryInfoButtonText(
        value ?? "-",
        ["DEX", "SPECIES", "TYPE", "OT", "NATURE", "ABILITY", "DESCRIPTION", "EXP", "NEXT"][index]
    ));
    for (const field of infoFields) {
        if (typeof field === "string") form.button(field);
        else form.button(field.text, field.iconPath);
    }
    form.button(marksSummaryText(selectedPokemon));

    form.show(player).then(response => {
        session.formOpen = false;
        if (response.canceled) {
            if (retryPartySelectorIfBusy(player, session, response.cancelationReason)) return;
            return closePartySelector(player);
        }
        session.busyRetries = 0;
        const selection = Math.floor(Number(response.selection));
        if (!Number.isInteger(selection) || selection < 0) return closePartySelector(player);
        handlePartySummarySelection(player, session, selection);
    }).catch(error => {
        session.formOpen = false;
        if (retryPartySelectorIfBusy(player, session, error)) return;
        closePartySelector(player);
        console.warn(`Party selector form failed: ${error}`);
    });
}

export function openPartyPokemonSummary(player, pokemonUuid) {
    const party = loadPartyFromPlayer(player);
    const detailSlot = party.findIndex(pokemon => pokemon?.uuid === pokemonUuid);
    if (detailSlot < 0) return false;
    showPartySelector(player, {
        party,
        detailSlot,
        tab: 0,
        swapSource: null,
        moveSelection: -1,
        moveSwapIndex: null,
        relearnPage: 0,
        statMode: 0,
        formOpen: false,
        busyRetries: 0
    });
    return true;
}

function findExistingSummons(pokemonUuid) {
    const matches = [];
    for (const dimension of partyDimensions()) {
        for (const entity of dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            try {
                const data = entity.getDynamicProperty("lota:pokemon_data");
                if (data && JSON.parse(String(data)).uuid === pokemonUuid) matches.push(entity);
            } catch (error) {}
        }
    }
    return matches;
}

function findExistingSummon(pokemonUuid) {
    return findExistingSummons(pokemonUuid)[0];
}

function removeSummonedEntity(entity) {
    if (!entity?.isValid) return;
    const location = { ...entity.location };
    const dimension = entity.dimension;
    flyingMounts.delete(entity.id);
    pendingFlightTransitions.delete(entity.id);
    trackedRiddenMounts.delete(entity.id);
    riderControlStates.delete(entity.id);
    airFollowerStates.delete(entity.id);
    entity.remove();
    spawnColoredFlame(dimension, location);
}

function recallExistingSummon(player, pokemon) {
    const entities = findExistingSummons(pokemon.uuid).filter(entity => {
        try {
            return String(entity.getDynamicProperty("lota:party_owner_id") || "") === player.id;
        } catch (error) {
            return false;
        }
    });
    if (!entities.length) return false;
    for (const entity of entities) {
        publishPokemonAppearanceEvent("recalled", player, pokemon, entity);
        removeSummonedEntity(entity);
    }
    try {
        player.onScreenDisplay.setActionBar(`§e${pokemonName(pokemon)}§f has been returned to its Poké Ball.`);
    } catch (error) {
        player.sendMessage(`§e${pokemonName(pokemon)}§f has been returned to its Poké Ball.`);
    }
    return true;
}

export function recallPartyPokemon(player, pokemon) {
    return recallExistingSummon(player, pokemon);
}

const recallingSummons = new Set();

function isPlayerRidingEntity(player, entity) {
    try {
        return player.getComponent("minecraft:riding")?.entityRidingOn?.id === entity.id;
    } catch (error) {
        return false;
    }
}

function ownerSummonEntities(player, pokemon) {
    return findExistingSummons(pokemon.uuid).filter(entity => {
        try {
            return String(entity.getDynamicProperty("lota:party_owner_id") || "") === player.id;
        } catch (error) {
            return false;
        }
    });
}

export function recallPartyPokemonAnimated(player, pokemon, entity) {
    const candidates = ownerSummonEntities(player, pokemon);
    const summonEntity = entity?.isValid && candidates.some(copy => copy.id === entity.id)
        ? entity
        : candidates[0];
    if (!summonEntity?.isValid) return recallExistingSummon(player, pokemon);
    if (recallingSummons.has(summonEntity.id)) return true;
    if (isPlayerRidingEntity(player, summonEntity)) return recallExistingSummon(player, pokemon);

    recallingSummons.add(summonEntity.id);
    const summonId = summonEntity.id;
    const started = playRecallToTrainerMotion({
        player,
        target: summonEntity,
        dimension: summonEntity.dimension,
        onAbsorbed: () => {
            recallingSummons.delete(summonId);
            const copies = ownerSummonEntities(player, pokemon);
            if (!copies.some(copy => copy.id === summonId) && summonEntity.isValid) copies.push(summonEntity);
            for (const copy of copies) {
                publishPokemonAppearanceEvent("recalled", player, pokemon, copy);
                removeSummonedEntity(copy);
            }
            try {
                player.onScreenDisplay.setActionBar(`§e${pokemonName(pokemon)}§f has been returned to its Poké Ball.`);
            } catch (error) {
                player.sendMessage(`§e${pokemonName(pokemon)}§f has been returned to its Poké Ball.`);
            }
        }
    });
    if (!started) recallingSummons.delete(summonId);

    return started || recallExistingSummon(player, pokemon);
}

export function recallPartyPokemonEntityAnimated(player, entity) {
    try {
        if (!player?.isValid || player.hasTag("lota:battle_player")) return false;
    } catch (error) {
        return false;
    }
    if (!entity?.isValid || !entity.hasTag("lota:party_pokemon")) return false;

    let ownerId = "";
    try { ownerId = String(entity.getDynamicProperty("lota:party_owner_id") || ""); }
    catch (error) { return false; }
    if (ownerId !== player.id) return false;

    let pokemon;
    try {
        const data = entity.getDynamicProperty("lota:pokemon_data");
        pokemon = data ? JSON.parse(String(data)) : undefined;
    } catch (error) {
        return false;
    }
    if (!pokemon?.uuid) return false;

    return recallPartyPokemonAnimated(player, pokemon, entity);
}

function activatePartyFollow(entity) {
    try { entity.triggerEvent("lota:enable_party_follow"); } catch (error) {}
    if (!isOriginalFlyingType(entity.typeId)) return;
    try { entity.setDynamicProperty("lota:air_follow_after_ride", true); } catch (error) {}
    airFollowerStates.set(entity.id, { entity, following: false, lastYaw: undefined });
}

function assignPartyOwner(entity, playerId, attemptsLeft = 5, activateFollow = false) {
    if (!entity?.isValid || attemptsLeft <= 0) return;

    const owner = world.getPlayers().find(player => player.id === playerId);
    const tameable = entity.getComponent("minecraft:tameable");
    if (owner && tameable) {
        try {
            const assigned = tameable.tame(owner)
                || (tameable.isTamed && tameable.tamedToPlayerId === playerId);
            if (assigned) {
                if (activateFollow) activatePartyFollow(entity);
                return;
            }
        } catch (error) {
            console.warn(`Party Pokemon owner assignment failed: ${error}`);
        }
    }

    if (attemptsLeft === 1) {
        console.warn(`Party Pokemon owner assignment timed out: ${entity.typeId}`);
        return;
    }
    system.runTimeout(() => assignPartyOwner(entity, playerId, attemptsLeft - 1, activateFollow), 1);
}

export function initializePartyFollower(entity, playerId, attemptsLeft = 10) {
    if (!entity?.isValid) return;
    try { entity.triggerEvent("lota:prepare_party_owner"); } catch (error) {}
    system.run(() => assignPartyOwner(entity, playerId, attemptsLeft, true));
}

export function replacePartyPokemonSummon(player, pokemon, previousEntity) {
    if (!player?.isValid || !pokemon?.uuid || !previousEntity?.isValid) return undefined;
    const dimension = previousEntity.dimension;
    const location = { ...previousEntity.location };
    let rotation;
    try { rotation = previousEntity.getRotation(); } catch (error) {}
    let replacement;
    try {
        replacement = dimension.spawnEntity(battleEntityType(pokemon), location);
        savePokemonToEntity(replacement, pokemon);
        replacement.addTag("lota:party_pokemon");
        replacement.setDynamicProperty("lota:party_owner_id", player.id);
        initializePartyFollower(replacement, player.id);
        try { replacement.setProperty("lota:is_shiny", pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
        applyPokemonSkinToEntity(replacement, pokemon);
        replacement.nameTag = `§f${pokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        try { if (rotation) replacement.setRotation(rotation); } catch (error) {}
        detachSummonTrackers(previousEntity.id);
        previousEntity.remove();
        publishPokemonAppearanceEvent("form_changed", player, pokemon, replacement);
        return replacement;
    } catch (error) {
        try {
            if (replacement?.isValid) {
                detachSummonTrackers(replacement.id);
                replacement.remove();
            }
        } catch (cleanupError) {}
        console.warn(`Party Pokemon form could not be replaced: ${error}`);
        return undefined;
    }
}

function getSendOutVelocity(view) {
    const horizontalLength = Math.hypot(view.x, view.z);
    const yawX = horizontalLength > 0.0001 ? view.x / horizontalLength : 0;
    const yawZ = horizontalLength > 0.0001 ? view.z / horizontalLength : 1;
    const pitch = Math.asin(Math.max(-1, Math.min(1, view.y)));
    const clampedPitch = Math.max(-Math.PI / 4, Math.min(Math.PI / 9, pitch));
    const speed = 0.8;
    const horizontalSpeed = Math.cos(clampedPitch) * speed;

    return {
        x: yawX * horizontalSpeed,
        y: Math.sin(clampedPitch) * speed,
        z: yawZ * horizontalSpeed
    };
}

function matchEntityVelocity(entity, velocity) {
    const correction = velocityCorrection(entity.getVelocity(), velocity);
    if (correction) entity.applyImpulse(correction);
}

function playerById(playerId) {
    return world.getPlayers().find(player => player.id === playerId);
}

function clearRideState(mount) {
    riderControlStates.delete(mount.id);
    try {
        if (mount.getProperty("lota:ride_sprinting") === true) {
            mount.setProperty("lota:ride_sprinting", false);
        }
    } catch (error) {}

    if (isOriginalFlyingType(mount.typeId)) {
        try { mount.setDynamicProperty("lota:air_follow_after_ride", true); } catch (error) {}
        airFollowerStates.set(mount.id, { entity: mount, following: false, lastYaw: undefined });
    }

    const ownerId = String(mount.getDynamicProperty("lota:party_owner_id") || "");
    system.runTimeout(() => {
        if (!mount?.isValid) return;

        try {
            if (mount.getProperty("lota:ride_active") === true) {
                mount.triggerEvent("lota:clear_riding");
            }
        } catch (error) {}

        if (ownerId) assignPartyOwner(mount, ownerId, 10);
    }, 1);
}

function discoverAirFollowers() {
    for (const dimension of partyDimensions()) {
        let entities = [];
        try {
            entities = dimension.getEntities({ tags: ["lota:party_pokemon"] });
        } catch (error) {
            continue;
        }
        for (const entity of entities) {
            if (!entity?.isValid || !isOriginalFlyingType(entity.typeId)) continue;
            try {
                if (entity.getDynamicProperty("lota:air_follow_after_ride") !== true) continue;
                if (entity.getProperty("lota:ride_active") === true) continue;
            } catch (error) {
                continue;
            }
            if (!airFollowerStates.has(entity.id)) {
                airFollowerStates.set(entity.id, { entity, following: false, lastYaw: undefined });
            }
        }
    }
}

function holdAirFollower(entity) {
    try { matchEntityVelocity(entity, { x: 0, y: 0, z: 0 }); } catch (error) {}
}

function updateAirFollower(state) {
    const entity = state.entity;
    if (!entity?.isValid || !entity.hasTag("lota:party_pokemon")) return false;
    try {
        if (entity.getProperty("lota:ride_active") === true) return false;
        if (entity.hasTag("lota:in_battle") || entity.getProperty("lota:in_battle") === true) {
            state.following = false;
            return true;
        }
    } catch (error) {}

    const ownerId = String(entity.getDynamicProperty("lota:party_owner_id") || "");
    const owner = playerById(ownerId);
    if (!owner?.isValid) {
        state.following = false;
        holdAirFollower(entity);
        return true;
    }

    const sameDimension = owner.dimension.id === entity.dimension.id;
    const ownerDistance = sameDimension ? distanceBetween(entity.location, owner.location) : Infinity;
    const mode = airFollowMode(ownerDistance, state.following, sameDimension);
    const target = ownerAirTarget(owner.location, owner.getHeadLocation());

    if (mode === "teleport") {
        try {
            entity.teleport(target, { dimension: owner.dimension });
            matchEntityVelocity(entity, { x: 0, y: 0, z: 0 });
        } catch (error) {}
        state.following = false;
        state.lastYaw = undefined;
        return true;
    }

    if (mode === "hold") {
        state.following = false;
        holdAirFollower(entity);
        return true;
    }

    state.following = true;
    const desiredVelocity = directAirVelocity(entity.location, target);
    try { matchEntityVelocity(entity, desiredVelocity); } catch (error) {}

    const yaw = yawForVelocity(desiredVelocity);
    if (yaw !== undefined && (state.lastYaw === undefined || Math.abs(shortestYawDifference(state.lastYaw, yaw)) >= 1)) {
        try {
            entity.setRotation({ x: 0, y: yaw });
            state.lastYaw = yaw;
        } catch (error) {}
    }
    return true;
}

function finishSummon(projectile) {
    if (!projectile || !projectile.isValid) return;
    const pending = summonThrows.get(projectile.id);
    if (!pending) return;

    summonThrows.delete(projectile.id);
    const thrower = (() => {
        try { return world.getPlayers().find(candidate => candidate.id === pending.playerId); }
        catch (error) { return undefined; }
    })();
    const summonCheck = thrower?.isValid ? validateSummonTarget(thrower, pending.pokemon?.uuid) : { ok: false };
    if (!summonCheck.ok) {
        try { if (projectile.isValid) projectile.remove(); } catch (error) {}
        return;
    }
    pending.pokemon = summonCheck.pokemon;
    projectile.addTag("lota:hit_processed");
    if (projectile.hasTag("lota:trainer_challenge_ball")) {
        system.runTimeout(() => {
            try { if (projectile.isValid) projectile.remove(); } catch (error) {}
        }, 1);
        return;
    }
    const dimension = projectile.dimension;
    const impact = projectile.location;
    const spawnLocation = { x: impact.x, y: impact.y + 0.25, z: impact.z };

    try {
        for (const oldSummon of findExistingSummons(pending.pokemon.uuid)) removeSummonedEntity(oldSummon);
        const entity = dimension.spawnEntity(battleEntityType(pending.pokemon), spawnLocation);
        savePokemonToEntity(entity, pending.pokemon);
        entity.addTag("lota:party_pokemon");
        entity.setDynamicProperty("lota:party_owner_id", pending.playerId);
        initializePartyFollower(entity, pending.playerId);
        try { entity.setProperty("lota:is_shiny", pending.pokemon.isShiny ? 1.0 : 0.0); } catch (error) {}
        applyPokemonSkinToEntity(entity, pending.pokemon);
        entity.nameTag = `§f${pokemonName(pending.pokemon)} Lv. ${pending.pokemon.level}§r`;
        publishPokemonAppearanceEvent("summoned", pending.playerId, pending.pokemon, entity);
        spawnPokeballSendFlash(dimension, spawnLocation);
        const sendOutSound = pending.pokemon.isShiny ? "lota.poke_ball.send_out_shiny" : "lota.poke_ball.send_out";
        try { dimension.playSound(sendOutSound, spawnLocation, { volume: 0.7, pitch: 1.0 }); } catch (error) {}
    } catch (error) {
        console.error(`Party Pokemon summon failed: ${error}`);
    }

    system.runTimeout(() => {
        try { if (projectile.isValid) projectile.remove(); } catch (error) {}
    }, 2);
}

function throwSelectedPokemon(player) {
    const party = loadPartyFromPlayer(player);
    if (party.length === 0) {
        player.sendMessage("§cYou do not have any Pokemon in your party.");
        return;
    }

    const requestedSlot = selectedSlot(player, party);
    const slot = firstUsableSlot(party, requestedSlot);
    if (slot < 0) {
        player.sendMessage("You have no Pokemon left that can battle.");
        return;
    }
    if (slot !== requestedSlot) {
        setSelectedPartySlot(player, slot);
        const fainted = party[requestedSlot];
        player.sendMessage(`${pokemonName(fainted)} is fainted. ${pokemonName(party[slot])} selected.`);
    }

    const pokemon = party[slot];
    if (!pokemon) return;
    if (Number(pokemon.currentHp) <= 0) {
        player.sendMessage(`§c${pokemonName(pokemon)} is fainted and cannot be sent out.`);
        return;
    }

    if (recallExistingSummon(player, pokemon)) return;
    if ([...summonThrows.values()].some(pending => pending.playerId === player.id
        && String(pending.pokemon?.uuid || "") === String(pokemon.uuid || ""))) return;

    const projectileTypes = {
        great_ball: "lota:great_ball_projectile",
        ultra_ball: "lota:ultra_ball_projectile"
    };
    const projectileType = projectileTypes[pokemon.caughtBall] || "lota:poke_ball_projectile";
    const view = player.getViewDirection();
    const head = player.getHeadLocation();
    const spawnLocation = {
        x: head.x + view.x * 0.6,
        y: head.y + view.y * 0.6 - 0.15,
        z: head.z + view.z * 0.6
    };

    try {
        const projectile = player.dimension.spawnEntity(projectileType, spawnLocation);
        projectile.addTag("lota:party_summon_ball");
        summonThrows.set(projectile.id, {
            playerId: player.id,
            pokemon: JSON.parse(JSON.stringify(pokemon))
        });
        const projectileId = projectile.id;
        system.runTimeout(() => summonThrows.delete(projectileId), 200);
        const projectileComponent = projectile.getComponent("minecraft:projectile");
        if (!projectileComponent) throw new Error(`${projectileType} has no projectile component.`);
        projectileComponent.owner = player;
        projectileComponent.shoot(getSendOutVelocity(view), { uncertainty: 0 });
    } catch (error) {
        console.error(`Party Pokemon throw failed: ${error}`);
        player.sendMessage("§cFailed to throw the Pokemon.");
    }
}

export function recallSelectedPartyPokemonAnimated(player) {
    try {
        if (!player?.isValid || player.hasTag("lota:battle_player")) return false;
    } catch (error) {
        return false;
    }
    const party = loadPartyFromPlayer(player);
    if (party.length === 0) return false;
    const pokemon = party[selectedSlot(player, party)];
    if (!pokemon || !findExistingSummon(pokemon.uuid)) return false;
    return recallPartyPokemonAnimated(player, pokemon);
}

export function useSelectedPartyPokemon(player) {
    try {
        if (!player?.isValid || player.hasTag("lota:battle_player")) return false;
    } catch (error) {
        return false;
    }
    if (tryStartPlayerChallenge(player)) return true;
    throwSelectedPokemon(player);
    return true;
}

export function cycleSelectedPartySlot(player) {
    try {
        if (!player?.isValid || player.hasTag("lota:battle_player")) return false;
    } catch (error) {
        return false;
    }

    const party = loadPartyFromPlayer(player);
    if (party.length === 0) {
        player.sendMessage("§cYou do not have any Pokemon in your party.");
        return false;
    }

    const current = selectedSlot(player, party);
    const next = (current + 1) % party.length;
    setSelectedPartySlot(player, next);
    return true;
}

export function shiftSelectedPartySlot(player, delta) {
    try {
        if (!player?.isValid || player.hasTag("lota:battle_player")) return -1;
    } catch (error) {
        return -1;
    }

    const party = loadPartyFromPlayer(player);
    if (party.length === 0) {
        player.sendMessage("§cYou do not have any Pokemon in your party.");
        return -1;
    }

    const current = selectedSlot(player, party);
    const next = (((current + delta) % party.length) + party.length) % party.length;
    setSelectedPartySlot(player, next);
    return next;
}

export function subscribeSelectedPartySlotChanged(callback) {
    if (typeof callback !== "function") return () => {};
    SELECTED_SLOT_SUBSCRIBERS.add(callback);
    return () => SELECTED_SLOT_SUBSCRIBERS.delete(callback);
}

system.runInterval(() => {
    for (const [playerId, session] of selectorSessions) {
        const player = playerById(playerId);
        if (!player || !player.isValid) {
            selectorSessions.delete(playerId);
            continue;
        }
    }
}, 20);

world.afterEvents.playerLeave.subscribe((event) => {
    selectorSessions.delete(event.playerId);
});

world.afterEvents.playerSpawn.subscribe((event) => {
    system.runTimeout(() => {
        const player = event.player;
        if (!player || selectorSessions.has(player.id)) return;
        try { player.removeTag(PARTY_SELECT_TAG); } catch (error) {}
    }, 1);
});

system.runInterval(() => {
    if (system.currentTick >= nextAirFollowerDiscoveryTick) {
        discoverAirFollowers();
        nextAirFollowerDiscoveryTick = system.currentTick + 20;
    }

    for (const [id, state] of airFollowerStates) {
        if (!updateAirFollower(state)) airFollowerStates.delete(id);
    }
}, 2);

system.runInterval(() => {
    const activelyRidden = new Set();
    const clearedThisTick = new Set();
    for (const player of world.getPlayers()) {
        const riding = player.getComponent("minecraft:riding");
        const mount = riding?.entityRidingOn;
        if (!mount?.isValid || !mount.hasTag("lota:party_pokemon")) continue;
        const rideStats = RIDE_STATS[mount.typeId] || { ground: 0.22, air: 0.38, canAir: false };
        const canRideAir = rideStats.canAir === true;
        const mountedFromAirFollow = canRideAir && !mount.isOnGround;

        activelyRidden.add(mount.id);
        trackedRiddenMounts.set(mount.id, mount);
        airFollowerStates.delete(mount.id);
        const controlState = riderControlStates.get(mount.id) || { sprinting: undefined };
        const sprinting = player.isSprinting === true;
        if (controlState.sprinting !== sprinting) {
            try {
                mount.setProperty("lota:ride_sprinting", sprinting);
                controlState.sprinting = sprinting;
            } catch (error) {}
        }
        riderControlStates.set(mount.id, controlState);

        if (RIDE_STATS[mount.typeId]?.canAir === true) {
            updateMountFlight(player, mount);
            continue;
        }

        let justStartedFlight = false;
        if (mountedFromAirFollow && !flyingMounts.has(mount.id)) {
            pendingFlightTransitions.delete(mount.id);
            flyingMounts.set(mount.id, { mount, startedAt: system.currentTick - 12 });
            try { mount.triggerEvent("lota:start_riding_air"); } catch (error) {}
        }
        if (canRideAir && !flyingMounts.has(mount.id)) {
            const velocity = mount.getVelocity();
            let transitionTick = pendingFlightTransitions.get(mount.id);
            if (!transitionTick && !mount.isOnGround && velocity.y >= 0.52) {
                transitionTick = system.currentTick + 4;
                pendingFlightTransitions.set(mount.id, transitionTick);
            }
            if (transitionTick && system.currentTick >= transitionTick) {
                pendingFlightTransitions.delete(mount.id);
                flyingMounts.set(mount.id, { mount, startedAt: system.currentTick });
                try { mount.triggerEvent("lota:start_riding_air"); } catch (error) {}
                justStartedFlight = true;
            } else if (transitionTick && mount.isOnGround) {
                pendingFlightTransitions.delete(mount.id);
            }
        }

        const flight = flyingMounts.get(mount.id);
        if (flight) {
            if (justStartedFlight) continue;
            if (system.currentTick - flight.startedAt > 12 && mount.isOnGround) {
                flyingMounts.delete(mount.id);
                try { mount.triggerEvent("lota:stop_riding_air"); } catch (error) {}
            }
        } else {
        }
    }

    for (const [id, flight] of flyingMounts) {
        const mount = flight.mount;
        if (!mount.isValid) {
            forgetMountFlight(mount);
            flyingMounts.delete(id);
            pendingFlightTransitions.delete(id);
            riderControlStates.delete(id);
        } else if (!activelyRidden.has(id)) {
            forgetMountFlight(mount);
            clearRideState(mount);
            clearedThisTick.add(id);
            flyingMounts.delete(id);
            pendingFlightTransitions.delete(id);
            riderControlStates.delete(id);
        }
    }
    for (const id of pendingFlightTransitions.keys()) {
        if (!activelyRidden.has(id)) pendingFlightTransitions.delete(id);
    }
    for (const [id, mount] of trackedRiddenMounts) {
        if (clearedThisTick.has(id)) {
            trackedRiddenMounts.delete(id);
            riderControlStates.delete(id);
            continue;
        }
        if (activelyRidden.has(id)) continue;
        if (mount.isValid) {
            clearRideState(mount);
        }
        trackedRiddenMounts.delete(id);
        riderControlStates.delete(id);
    }

}, 1);

world.afterEvents.projectileHitEntity.subscribe((event) => {
    const projectile = event.projectile;
    system.run(() => {
        try {
            if (projectile?.isValid && projectile.hasTag("lota:party_summon_ball")) finishSummon(projectile);
        } catch (error) {}
    });
});

world.afterEvents.projectileHitBlock.subscribe((event) => {
    const projectile = event.projectile;
    try {
        if (projectile?.isValid && projectile.hasTag("lota:party_summon_ball")) finishSummon(projectile);
    } catch (error) {}
});
