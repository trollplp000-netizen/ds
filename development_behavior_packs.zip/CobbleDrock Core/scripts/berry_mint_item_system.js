﻿

import { ItemStack, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { buildFieldPartySelectionForm } from "./party_target_form.js";
import { claimPokemonInteraction } from "./pokemon_interaction_claims.js";
import { calculateMaxHp, speciesData } from "./battle_math.js";
import {
    loadPartyFromPlayer,
    savePartyToPlayer,
    savePokemonToEntity
} from "./storage.js";
import {
    BERRY_DATA,
    BERRY_ITEM_TO_BLOCK,
    MINT_CROPS,
    NATURE_MINTS,
    getBerryData,
    getNatureMint
} from "./berry_mint_data.js";
import {
    applyOranBerry,
    applySitrusBerry,
    applyFlavorPortionBerry,
    applyStatusCureBerry,
    applyPpRestoreBerry,
    applyFriendshipBerry,
    applyNatureMint,
    canRestorePp,
    healPokemonHp,
    pokemonName
} from "./pokemon_item_effects.js";

const selectionSessions = new Map();

const TRAINING_ITEM_EFFECTS = Object.freeze({
    health_feather: { kind: "ev", stat: "hp", amount: 1 },
    muscle_feather: { kind: "ev", stat: "attack", amount: 1 },
    resist_feather: { kind: "ev", stat: "defence", amount: 1 },
    clever_feather: { kind: "ev", stat: "specialDefence", amount: 1 },
    genius_feather: { kind: "ev", stat: "specialAttack", amount: 1 },
    swift_feather: { kind: "ev", stat: "speed", amount: 1 },
    health_mochi: { kind: "ev", stat: "hp", amount: 4 },
    muscle_mochi: { kind: "ev", stat: "attack", amount: 4 },
    resist_mochi: { kind: "ev", stat: "defence", amount: 4 },
    clever_mochi: { kind: "ev", stat: "specialDefence", amount: 4 },
    genius_mochi: { kind: "ev", stat: "specialAttack", amount: 4 },
    swift_mochi: { kind: "ev", stat: "speed", amount: 4 },
    health_candy: { kind: "iv", stat: "hp", amount: 1 },
    mighty_candy: { kind: "iv", stat: "attack", amount: 1 },
    tough_candy: { kind: "iv", stat: "defence", amount: 1 },
    smart_candy: { kind: "iv", stat: "specialAttack", amount: 1 },
    courage_candy: { kind: "iv", stat: "specialDefence", amount: 1 },
    quick_candy: { kind: "iv", stat: "speed", amount: 1 },
    sickly_candy: { kind: "iv", stat: "hp", amount: -1 },
    weak_candy: { kind: "iv", stat: "attack", amount: -1 },
    brittle_candy: { kind: "iv", stat: "defence", amount: -1 },
    numb_candy: { kind: "iv", stat: "specialAttack", amount: -1 },
    coward_candy: { kind: "iv", stat: "specialDefence", amount: -1 },
    slow_candy: { kind: "iv", stat: "speed", amount: -1 }
});

const STAT_LABELS = Object.freeze({
    hp: "HP",
    attack: "Attack",
    defence: "Defense",
    specialAttack: "Sp. Atk",
    specialDefence: "Sp. Def",
    speed: "Speed"
});

const ABILITY_ITEMS = new Set(["ability_capsule", "ability_patch"]);

const MOVE_SELECTING_ITEMS = new Set(["lota:leppa_berry", "lota:hopo_berry"]);

const PLANTABLE_SOIL_BLOCKS = new Set([
    "minecraft:farmland",
    "minecraft:grass_block",
    "minecraft:dirt",
    "minecraft:coarse_dirt",
    "minecraft:podzol",
    "minecraft:dirt_with_roots",
    "minecraft:moss_block",
    "minecraft:mud"
]);

function selectedInventorySlot(player) {
    return Math.max(0, Math.floor(Number(player?.selectedSlotIndex) || 0));
}

function heldStack(player, slot = selectedInventorySlot(player)) {
    try {
        return player.getComponent("minecraft:inventory")?.container?.getItem(slot);
    } catch (error) {
        return undefined;
    }
}

function isCreativePlayer(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function consumeHeldItem(player, slot, itemId) {
    if (isCreativePlayer(player)) return true;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const stack = container?.getItem(slot);
        if (!container || stack?.typeId !== itemId) return false;
        if (stack.amount <= 1) container.setItem(slot, undefined);
        else {
            stack.amount -= 1;
            container.setItem(slot, stack);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function findSummonedPokemon(player, uuid) {
    if (!uuid) return undefined;
    try {
        for (const entity of player.dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            if (!entity?.isValid) continue;
            if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== player.id) continue;
            const data = JSON.parse(String(entity.getDynamicProperty("lota:pokemon_data") || "{}"));
            if (String(data.uuid || "") === String(uuid)) return entity;
        }
    } catch (error) {}
    return undefined;
}

function syncSummonedPokemon(player, pokemon, preferredEntity = undefined) {
    const entity = preferredEntity?.isValid ? preferredEntity : findSummonedPokemon(player, pokemon?.uuid);
    if (!entity) return;
    try {
        savePokemonToEntity(entity, pokemon);
        entity.nameTag = `§f${pokemonName(pokemon)} Lv. ${pokemon.level}§r`;
        entity.dimension.playSound("lota.item.medicine_herb_use", entity.location, {
            volume: 1,
            pitch: 1
        });
    } catch (error) {}
}

function refreshCalculatedHp(pokemon) {
    const previousMax = Math.max(1, Number(pokemon?.maxHp) || 1);
    const previousCurrent = Math.max(0, Number(pokemon?.currentHp) || 0);
    const nextMax = calculateMaxHp(pokemon);
    if (previousCurrent <= 0) pokemon.currentHp = 0;
    else if (previousCurrent >= previousMax) pokemon.currentHp = nextMax;
    else pokemon.currentHp = Math.max(1, Math.min(nextMax, Math.round(nextMax * previousCurrent / previousMax)));
    pokemon.maxHp = nextMax;
}

function applyTrainingItem(pokemon, cleanId) {
    const effect = TRAINING_ITEM_EFFECTS[cleanId];
    if (effect?.kind === "ev") {
        pokemon.evs ||= { hp: 0, attack: 0, defence: 0, specialAttack: 0, specialDefence: 0, speed: 0 };
        const current = Math.max(0, Math.floor(Number(pokemon.evs[effect.stat]) || 0));
        const total = Object.values(pokemon.evs).reduce((sum, value) => sum + Math.max(0, Math.floor(Number(value) || 0)), 0);
        const gained = Math.min(effect.amount, 252 - current, 510 - total);
        if (gained <= 0) return undefined;
        pokemon.evs[effect.stat] = current + gained;
        if (effect.stat === "hp") refreshCalculatedHp(pokemon);
        return {
            success: true,
            messages: [`${pokemonName(pokemon)} gained ${gained} ${STAT_LABELS[effect.stat]} EV${gained === 1 ? "" : "s"}!`]
        };
    }
    if (effect?.kind === "iv") {
        pokemon.ivs ||= { hp: 0, attack: 0, defence: 0, specialAttack: 0, specialDefence: 0, speed: 0 };
        const current = Math.max(0, Math.min(31, Math.floor(Number(pokemon.ivs[effect.stat]) || 0)));
        const next = Math.max(0, Math.min(31, current + effect.amount));
        if (next === current) return undefined;
        pokemon.ivs[effect.stat] = next;
        if (effect.stat === "hp") refreshCalculatedHp(pokemon);
        return {
            success: true,
            messages: [`${pokemonName(pokemon)}'s ${STAT_LABELS[effect.stat]} IV changed to ${next}!`]
        };
    }
    if (!ABILITY_ITEMS.has(cleanId)) return undefined;
    const abilities = Array.isArray(speciesData(pokemon)?.abilities) ? speciesData(pokemon).abilities : [];
    const ordinary = abilities.filter(value => !String(value).startsWith("h:")).map(String);
    const hidden = abilities.find(value => String(value).startsWith("h:"));
    const current = String(pokemon.ability || "").replace(/^h:/, "");
    let next;
    if (cleanId === "ability_capsule") {
        if (ordinary.length < 2) return undefined;
        const index = ordinary.indexOf(current);
        next = ordinary[index < 0 ? 0 : (index + 1) % ordinary.length];
    } else {
        const hiddenAbility = hidden ? String(hidden).replace(/^h:/, "") : "";
        if (!hiddenAbility || !ordinary.length) return undefined;
        next = current === hiddenAbility ? ordinary[0] : hiddenAbility;
    }
    if (!next || next === current) return undefined;
    pokemon.ability = next;
    return { success: true, messages: [`${pokemonName(pokemon)}'s Ability changed to ${next}!`] };
}

export function executeItemEffectOnPokemon(pokemon, itemId) {
    const cleanId = String(itemId || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();

    const trainingResult = applyTrainingItem(pokemon, cleanId);
    if (trainingResult) return trainingResult;

    if (cleanId.endsWith("_mint") && !cleanId.endsWith("_crop")) {
        const nature = cleanId.replace(/_mint$/, "");
        if (NATURE_MINTS[nature]) {
            return applyNatureMint(pokemon, nature);
        }
    }

    if (cleanId === "oran_berry") return applyOranBerry(pokemon);
    if (cleanId === "sitrus_berry") return applySitrusBerry(pokemon);
    if (cleanId === "figy_berry") return applyFlavorPortionBerry(pokemon, "attack");
    if (cleanId === "wiki_berry") return applyFlavorPortionBerry(pokemon, "specialAttack");
    if (cleanId === "mago_berry") return applyFlavorPortionBerry(pokemon, "speed");
    if (cleanId === "aguav_berry") return applyFlavorPortionBerry(pokemon, "specialDefence");
    if (cleanId === "iapapa_berry") return applyFlavorPortionBerry(pokemon, "defence");

    if (cleanId === "berry_juice") {
        const healed = healPokemonHp(pokemon, 20);
        if (healed > 0) {
            return { success: true, healed, messages: [`${pokemonName(pokemon)} drank the Berry Juice and regained ${healed} HP!`] };
        }
        return undefined;
    }

    if (cleanId === "cheri_berry") return applyStatusCureBerry(pokemon, ["paralysis"]);
    if (cleanId === "chesto_berry") return applyStatusCureBerry(pokemon, ["sleep"]);
    if (cleanId === "pecha_berry") return applyStatusCureBerry(pokemon, ["poison"]);
    if (cleanId === "rawst_berry") return applyStatusCureBerry(pokemon, ["burn"]);
    if (cleanId === "aspear_berry") return applyStatusCureBerry(pokemon, ["frozen"]);
    if (cleanId === "persim_berry") return applyStatusCureBerry(pokemon, [], { confusion: true });
    if (cleanId === "lum_berry") return applyStatusCureBerry(pokemon, "all", { confusion: true });
    if (cleanId === "eggant_berry") return applyStatusCureBerry(pokemon, [], { infatuation: true });

    if (cleanId === "leppa_berry" || cleanId === "hopo_berry") return applyPpRestoreBerry(pokemon, undefined, 10);

    if (["pomeg_berry", "kelpsy_berry", "qualot_berry", "hondew_berry", "grepa_berry", "tamato_berry"].includes(cleanId)) {
        return applyFriendshipBerry(pokemon, cleanId);
    }

    return undefined;
}

export function isConsumableFieldItem(itemId) {
    const cleanId = String(itemId || "").replace(/^lota:/, "").replace(/^cobblemon:/, "").toLowerCase();
    if (TRAINING_ITEM_EFFECTS[cleanId] || ABILITY_ITEMS.has(cleanId)) return true;
    if (cleanId.endsWith("_mint") && NATURE_MINTS[cleanId.replace(/_mint$/, "")]) return true;
    if (["oran_berry", "sitrus_berry", "figy_berry", "wiki_berry", "mago_berry", "aguav_berry", "iapapa_berry",
         "cheri_berry", "chesto_berry", "pecha_berry", "rawst_berry", "aspear_berry", "persim_berry", "lum_berry", "eggant_berry",
         "leppa_berry", "hopo_berry", "pomeg_berry", "kelpsy_berry", "qualot_berry", "hondew_berry", "grepa_berry", "tamato_berry",
         "berry_juice"].includes(cleanId)) {
        return true;
    }
    return false;
}

function applyItemToPartySlot(player, itemId, inventorySlot, partySlot, preferredEntity = undefined, moveIndex = undefined) {
    const stack = heldStack(player, inventorySlot);
    if (stack?.typeId !== itemId) {
        player.sendMessage("§cYou are no longer holding that item.");
        return false;
    }

    const party = loadPartyFromPlayer(player);
    const pokemon = party[partySlot];
    if (!pokemon) return false;

    const result = MOVE_SELECTING_ITEMS.has(itemId)
        ? applyPpRestoreBerry(pokemon, moveIndex, 10)
        : executeItemEffectOnPokemon(pokemon, itemId);
    if (!result || !result.success) {
        if (result?.sameNature) {
            player.sendMessage(`§e${pokemonName(pokemon)} already has the effects of that mint.`);
        } else {
            player.sendMessage("§7It won't have any effect.");
        }
        return false;
    }

    if (!consumeHeldItem(player, inventorySlot, itemId)) {
        player.sendMessage("§cYou are no longer holding that item.");
        return false;
    }

    if (!savePartyToPlayer(player, party)) {
        restoreHeldItem(player, inventorySlot, itemId);
        player.sendMessage("§cFailed to save Pokemon data. The item was returned to your inventory.");
        return false;
    }

    syncSummonedPokemon(player, pokemon, preferredEntity);

    for (const msg of result.messages || []) {
        player.sendMessage(`§a${msg}`);
    }

    return true;
}

function restoreHeldItem(player, slot, itemId) {
    if (isCreativePlayer(player)) return true;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) return false;
        const stack = container.getItem(slot);
        if (!stack) {
            container.setItem(slot, new ItemStack(itemId, 1));
        } else if (stack.typeId === itemId) {
            stack.amount += 1;
            container.setItem(slot, stack);
        } else {
            container.addItem(new ItemStack(itemId, 1));
        }
        return true;
    } catch (error) {
        return false;
    }
}

function showBerryPartySelection(player, itemId, inventorySlot) {
    if (selectionSessions.has(player.id)) return;
    const party = loadPartyFromPlayer(player);
    if (!party.some(Boolean)) return;

    const session = { itemId, inventorySlot, formOpen: true };
    selectionSessions.set(player.id, session);
    const form = buildFieldPartySelectionForm(player, party);

    form.show(player).then(response => {
        selectionSessions.delete(player.id);
        if (response.canceled) return;
        const partySlot = Math.floor(Number(response.selection));
        if (partySlot >= 0 && partySlot < 6 && party[partySlot]) {
            if (MOVE_SELECTING_ITEMS.has(itemId)) {
                showMoveSelection(player, itemId, inventorySlot, party, partySlot);
            } else {
                applyItemToPartySlot(player, itemId, inventorySlot, partySlot);
            }
        }
    }).catch(error => {
        selectionSessions.delete(player.id);
    });
}

function showMoveSelection(player, itemId, inventorySlot, party, partySlot) {
    if (selectionSessions.has(player.id)) return;
    const pokemon = party[partySlot];
    const missing = (pokemon?.moves || [])
        .map((move, index) => ({ move, index }))
        .filter(entry => entry.move && Number(entry.move.pp) < Number(entry.move.maxPp));
    if (missing.length === 0 || !canRestorePp(pokemon)) {
        player.sendMessage("§7It won't have any effect.");
        return;
    }

    const session = { itemId, inventorySlot, formOpen: true };
    selectionSessions.set(player.id, session);
    const form = new ActionFormData();
    form.title("item.cobblemon.leppa_berry");
    form.body(`Choose a move of ${pokemonName(pokemon)} to restore PP:`);
    for (const entry of missing) {
        form.button(`${entry.move.name || entry.move.id} (${Number(entry.move.pp)}/${Number(entry.move.maxPp)})`);
    }

    form.show(player).then(response => {
        selectionSessions.delete(player.id);
        if (response.canceled) return;
        const choice = Math.floor(Number(response.selection));
        const entry = missing[choice];
        if (entry) {
            applyItemToPartySlot(player, itemId, inventorySlot, partySlot, undefined, entry.index);
        }
    }).catch(error => {
        selectionSessions.delete(player.id);
    });
}

function isPlantingUse(player, itemId) {
    const blockId = BERRY_ITEM_TO_BLOCK[itemId] || (() => {
        const clean = String(itemId || "").replace(/^lota:/, "");
        if (/_mint_seeds$/.test(clean)) return "lota:" + clean.replace(/_mint_seeds$/, "") + "_mint";
        return undefined;
    })();
    if (!blockId) return false;
    try {
        const hit = player.getBlockFromViewDirection({ maxDistance: 6, includePassableBlocks: true, includeLiquidBlocks: false });
        const target = hit?.block;
        if (!target) return false;
        return PLANTABLE_SOIL_BLOCKS.has(target.typeId) || target.typeId === "minecraft:farmland";
    } catch (error) {
        return false;
    }
}

world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    const item = event.itemStack;
    if (!player || !item) return;

    const itemId = item.typeId;
    const slot = selectedInventorySlot(player);

    if (isPlantingUse(player, itemId)) return;

    if (isConsumableFieldItem(itemId)) {
        showBerryPartySelection(player, itemId, slot);
    }
});

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    const player = event.player;
    const target = event.target;
    if (!player || !target || !target.hasTag("lota:party_pokemon")) return;

    const slot = selectedInventorySlot(player);
    const item = heldStack(player, slot);
    if (!item || !isConsumableFieldItem(item.typeId)) return;

    if (!claimPokemonInteraction(player, target)) return;

    try {
        const rawData = target.getDynamicProperty("lota:pokemon_data");
        if (!rawData) return;
        const pokemon = JSON.parse(String(rawData));
        const party = loadPartyFromPlayer(player);
        const partySlot = party.findIndex(p => p && String(p.uuid) === String(pokemon.uuid));

        if (partySlot >= 0) {
            system.run(() => {
                applyItemToPartySlot(player, item.typeId, slot, partySlot, target);
            });
            event.cancel = true;
        }
    } catch (error) {}
});
