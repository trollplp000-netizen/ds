import { calculateMaxHp, speciesData } from "./battle_math.js";
import { MOVE_DATA } from "./move_registry.js";
import { queueLevelUpEvolutions } from "./evolution.js";

export const MAX_POKEMON_LEVEL = 100;
export const COBBLEVERSE_EXPERIENCE_MULTIPLIER = 2;
export const EXPERIENCE_SHARE_MULTIPLIER = 0.5;
export const EXPERIENCE_SHARE_ITEM_ID = "lota:exp_share";

function integer(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.floor(number) : fallback;
}

function growthGroup(pokemon) {
    return String(speciesData(pokemon)?.experienceGroup || "medium_fast").toLowerCase();
}

export function experienceForLevel(group, rawLevel) {
    const level = Math.max(1, integer(rawLevel, 1));
    if (level === 1) return 0;
    const cube = level * level * level;

    switch (String(group || "medium_fast").toLowerCase()) {
        case "erratic":
            if (level < 50) return Math.floor((cube * (100 - level)) / 50);
            if (level < 68) return Math.floor((cube * (150 - level)) / 100);
            if (level < 98) return Math.floor((cube * (1911 - 10 * level)) / 1500);
            return Math.floor((cube * (160 - level)) / 100);
        case "fast":
            return Math.floor((4 * cube) / 5);
        case "medium_slow":
            return Math.max(0, Math.floor((6 * cube) / 5) - 15 * level * level + 100 * level - 140);
        case "slow":
            return Math.floor((5 * cube) / 4);
        case "fluctuating":
            if (level < 15) return Math.floor((cube * (Math.floor((level + 1) / 3) + 24)) / 50);
            if (level < 36) return Math.floor((cube * (level + 14)) / 50);
            return Math.floor((cube * (Math.floor(level / 2) + 32)) / 50);
        case "medium_fast":
        default:
            return cube;
    }
}

export function normalizePokemonExperience(pokemon) {
    if (!pokemon || !speciesData(pokemon)) return false;
    const originalLevel = pokemon.level;
    const originalExperience = pokemon.experience;
    const level = Math.max(1, Math.min(MAX_POKEMON_LEVEL, integer(pokemon.level, 1)));
    const minimum = experienceForLevel(growthGroup(pokemon), level);
    const stored = integer(pokemon.experience, minimum);

    pokemon.level = level;
    const maximum = experienceForLevel(growthGroup(pokemon), MAX_POKEMON_LEVEL);
    pokemon.experience = Math.max(minimum, Math.min(maximum, stored));
    return pokemon.level !== originalLevel || pokemon.experience !== originalExperience;
}

export function experienceToNextLevel(pokemon) {
    if (!pokemon) return 0;
    normalizePokemonExperience(pokemon);
    const level = Math.max(1, integer(pokemon.level, 1));
    if (level >= MAX_POKEMON_LEVEL) return 0;
    return Math.max(0, experienceForLevel(growthGroup(pokemon), level + 1) - pokemon.experience);
}

export function experienceProgress(pokemon) {
    if (!pokemon || !speciesData(pokemon)) return 0;
    normalizePokemonExperience(pokemon);
    const level = Math.max(1, integer(pokemon.level, 1));
    if (level >= MAX_POKEMON_LEVEL) return 0;

    const group = growthGroup(pokemon);
    const currentThreshold = experienceForLevel(group, level);
    const nextThreshold = experienceForLevel(group, level + 1);
    const needed = Math.max(1, nextThreshold - currentThreshold);
    return Math.max(0, Math.min(1, (pokemon.experience - currentThreshold) / needed));
}

function learnLevelMoves(pokemon, oldLevel, newLevel) {
    const learned = [];
    const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
    const known = new Set(moves.map(move => String(move?.id || move || "").replace("cobblemon:", "").toLowerCase()));
    const levelMoves = speciesData(pokemon)?.levelMoves || [];

    for (const entry of levelMoves) {
        const learnedAt = integer(entry?.level, 0);
        const id = String(entry?.id || "").replace("cobblemon:", "").toLowerCase();
        if (learnedAt <= oldLevel || learnedAt > newLevel || !MOVE_DATA[id] || known.has(id)) continue;
        learned.push(id);
        if (moves.length < 4) {
            const move = MOVE_DATA[id];
            moves.push({ id, pp: move.pp, maxPp: move.pp });
        } else {
            const benched = Array.isArray(pokemon.benchedMoves) ? pokemon.benchedMoves : [];
            if (!benched.some(move => String(move?.id || move || "").replace("cobblemon:", "").toLowerCase() === id)) {
                benched.push(id);
            }
            pokemon.benchedMoves = benched;
        }
        known.add(id);
    }

    pokemon.moves = moves;
    return learned;
}

export function addPokemonExperience(pokemon, rawAmount, rawLevelCap = MAX_POKEMON_LEVEL) {
    if (!pokemon) return { amount: 0, oldLevel: 0, newLevel: 0, learnedMoves: [], queuedEvolutions: [] };
    normalizePokemonExperience(pokemon);

    const amount = Math.max(0, integer(rawAmount, 0));
    const oldLevel = Math.max(1, integer(pokemon.level, 1));
    const levelCap = Math.max(1, Math.min(MAX_POKEMON_LEVEL, integer(rawLevelCap, MAX_POKEMON_LEVEL)));
    if (amount <= 0 || oldLevel >= levelCap) {
        return { amount: 0, oldLevel, newLevel: oldLevel, learnedMoves: [], queuedEvolutions: [], capped: oldLevel >= levelCap };
    }

    const oldMaxHp = Math.max(1, integer(pokemon.maxHp, calculateMaxHp(pokemon)));
    const oldCurrentHp = Math.max(0, Math.min(oldMaxHp, integer(pokemon.currentHp, oldMaxHp)));
    const hpRatio = Math.max(0, Math.min(1, oldCurrentHp / oldMaxHp));
    const maximumExperience = experienceForLevel(growthGroup(pokemon), levelCap);
    const previousExperience = pokemon.experience;
    pokemon.experience = Math.min(maximumExperience, previousExperience + amount);
    const experienceAdded = pokemon.experience - previousExperience;
    if (experienceAdded <= 0) {
        return { amount: 0, oldLevel, newLevel: oldLevel, learnedMoves: [], queuedEvolutions: [], capped: true };
    }

    const group = growthGroup(pokemon);
    let newLevel = oldLevel;
    while (newLevel < levelCap && pokemon.experience >= experienceForLevel(group, newLevel + 1)) {
        newLevel++;
    }

    pokemon.level = newLevel;
    if (newLevel !== oldLevel) {
        const newMaxHp = calculateMaxHp(pokemon);
        pokemon.maxHp = newMaxHp;
        pokemon.currentHp = Math.max(0, Math.min(newMaxHp, Math.ceil(hpRatio * newMaxHp)));
    }

    const queuedEvolutions = queueLevelUpEvolutions(pokemon, oldLevel, newLevel);
    return {
        amount: experienceAdded,
        oldLevel,
        newLevel,
        learnedMoves: learnLevelMoves(pokemon, oldLevel, newLevel),
        queuedEvolutions,
        capped: pokemon.experience >= maximumExperience
    };
}

export function holdsExperienceShare(pokemon) {
    const heldItem = String(pokemon?.heldItem || "").trim().toLowerCase();
    return heldItem === EXPERIENCE_SHARE_ITEM_ID || heldItem === "cobblemon:exp_share" || heldItem === "exp_share";
}

export function battleExperienceParticipationMultiplier(pokemon, slot, participants = []) {
    const participantSlots = participants instanceof Set ? participants : new Set(participants || []);
    if (participantSlots.has(slot)) return 1;
    return holdsExperienceShare(pokemon) ? EXPERIENCE_SHARE_MULTIPLIER : 0;
}

export function calculateBattleExperience(pokemon, defeatedPokemon, participationMultiplier = 1, trainerId = "") {
    if (!pokemon || !defeatedPokemon) return 0;
    const defeatedData = speciesData(defeatedPokemon);
    const baseYield = Math.max(0, integer(defeatedData?.baseExperienceYield, 0));
    const defeatedLevel = Math.max(1, integer(defeatedPokemon.level, 1));
    const pokemonLevel = Math.max(1, integer(pokemon.level, 1));
    if (baseYield <= 0) return 0;

    const base = (baseYield * defeatedLevel) / 5;
    const levelAdjustment = Math.pow(
        (2 * defeatedLevel + 10) / (defeatedLevel + pokemonLevel + 10),
        2.5
    );
    const originalTrainer = pokemon.originalTrainer || {};
    const sameTrainer = String(originalTrainer.type || "").toUpperCase() === "PLAYER"
        && String(originalTrainer.uuid || "") === String(trainerId || "");
    const tradedMultiplier = sameTrainer ? 1 : 1.5;
    const friendshipMultiplier = integer(pokemon.friendship, 0) >= 220 ? 1.2 : 1;

    return Math.max(1, Math.round(
        (base * Math.max(0, Number(participationMultiplier) || 0) * levelAdjustment + 1)
        * tradedMultiplier
        * friendshipMultiplier
        * COBBLEVERSE_EXPERIENCE_MULTIPLIER
    ));
}
