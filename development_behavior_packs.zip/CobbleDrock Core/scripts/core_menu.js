import { EquipmentSlot, system, world } from "@minecraft/server";
import { cycleSelectedPartySlot, recallPartyPokemonEntityAnimated, recallSelectedPartyPokemonAnimated, showPartySelector, useSelectedPartyPokemon } from "./pokemon_compass.js";
import { showPokedex } from "./pokedex_system.js";
import { hasChosenStarter, openStarterSelection } from "./starter_selection.js";
import { showAccessoryMenu } from "./accessory_system.js";
import { wantsThrowFocus } from "./compass_focus.js";

const COMPASS_ITEM = "lota:pokemon_compass";
const SERVER_MODE_TAG = "lota:server_mode";
const SERVER_MENU_EVENT = "lota:server_menu_v1";
const USE_COOLDOWNS = new Map();
const THROW_FROM_HIT_COOLDOWNS = new Map();
const THROW_FROM_HIT_COOLDOWN_TICKS = 10;
const SNEAK_CYCLE_COOLDOWNS = new Map();
const SNEAK_CYCLE_COOLDOWN_TICKS = 10;
const SNEAK_STATES = new Map();

function isPlayer(entity) {
    return entity?.typeId === "minecraft:player";
}

function eventPlayer(event) {
    if (isPlayer(event.sourceEntity)) return event.sourceEntity;
    const requestedId = String(event.message || "");
    return world.getAllPlayers().find(player => player.id === requestedId);
}

function runUi(action) {
    system.run(action);
}

function isServerManaged(player) {
    try { return player.hasTag(SERVER_MODE_TAG); }
    catch (error) { return false; }
}

function showMainMenu(player) {
    if (!isServerManaged(player)) return showPartySelector(player);
    try {
        system.sendScriptEvent(SERVER_MENU_EVENT, player.id);
    } catch (error) {
        console.warn(`[CoreMenu] Server menu bridge failed for ${player?.name || "unknown"}: ${error}`);
        showPartySelector(player);
    }
}

function openStarterOrMenu(player) {
    if (!hasChosenStarter(player)) return runUi(() => openStarterSelection(player));
    runUi(() => showMainMenu(player));
}

world.afterEvents.itemStartUse.subscribe(event => {
    if (event.itemStack?.typeId !== COMPASS_ITEM) return;
    const player = event.source;
    try { if (player.hasTag("lota:battle_player")) return; }
    catch (error) {}
    const tick = system.currentTick;
    if ((USE_COOLDOWNS.get(player.id) || -20) + 5 > tick) return;
    USE_COOLDOWNS.set(player.id, tick);
    if (!hasChosenStarter(player)) return runUi(() => openStarterSelection(player));
    runUi(() => showMainMenu(player));
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    const player = eventPlayer(event);
    if (!isPlayer(player)) return;
    if (event.id === "lota:core_party") return runUi(() => showPartySelector(player));
    if (event.id === "lota:core_pokedex") return runUi(() => showPokedex(player));
    if (event.id === "lota:core_starter") return runUi(() => openStarterSelection(player));
    if (event.id === "lota:core_use_selected") return runUi(() => useSelectedPartyPokemon(player));
    if (event.id === "lota:core_accessories") return runUi(() => showAccessoryMenu(player));
    if (event.id === "lota:core_menu") return runUi(() => openStarterOrMenu(player));
});

function isEmptyHanded(player) {
    try {
        const equippable = player.getComponent("minecraft:equippable");
        return !equippable?.getEquipment(EquipmentSlot.Mainhand);
    } catch (error) {
        return false;
    }
}

function trySneakCycle(player) {
    try { if (player.hasTag("lota:battle_player")) return; }
    catch (error) {}
    if (!isEmptyHanded(player)) return;
    const tick = system.currentTick;
    if ((SNEAK_CYCLE_COOLDOWNS.get(player.id) || -SNEAK_CYCLE_COOLDOWN_TICKS) + SNEAK_CYCLE_COOLDOWN_TICKS > tick) return;
    SNEAK_CYCLE_COOLDOWNS.set(player.id, tick);
    if (!hasChosenStarter(player)) return;
    runUi(() => cycleSelectedPartySlot(player));
}

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        if (!player.isValid) continue;
        const wasSneaking = SNEAK_STATES.get(player.id) || false;
        const isSneakingNow = !!player.isSneaking;
        if (isSneakingNow && !wasSneaking) trySneakCycle(player);
        SNEAK_STATES.set(player.id, isSneakingNow);
    }
}, 1);

function tryThrowFromHit(player, hitEntity) {
    if (!isPlayer(player)) return;
    const hitOwnPokemon = hitEntity?.hasTag("lota:party_pokemon");
    try { if (player.hasTag("lota:battle_player")) return; }
    catch (error) {}

    if (hitOwnPokemon && isEmptyHanded(player)) {
        const tick = system.currentTick;
        if ((THROW_FROM_HIT_COOLDOWNS.get(player.id) || -THROW_FROM_HIT_COOLDOWN_TICKS) + THROW_FROM_HIT_COOLDOWN_TICKS > tick) return;
        THROW_FROM_HIT_COOLDOWNS.set(player.id, tick);
        if (!hasChosenStarter(player)) return;
        runUi(() => recallPartyPokemonEntityAnimated(player, hitEntity));
        return;
    }

    if (!wantsThrowFocus(player)) return;
    const tick = system.currentTick;
    if ((THROW_FROM_HIT_COOLDOWNS.get(player.id) || -THROW_FROM_HIT_COOLDOWN_TICKS) + THROW_FROM_HIT_COOLDOWN_TICKS > tick) return;
    THROW_FROM_HIT_COOLDOWNS.set(player.id, tick);
    if (!hasChosenStarter(player)) return;
    runUi(() => {
        if (recallSelectedPartyPokemonAnimated(player)) return;
        if (!hitOwnPokemon) useSelectedPartyPokemon(player);
    });
}

world.afterEvents.entityHitEntity.subscribe(event => {
    const hitEntity = event.hitEntity;
    tryThrowFromHit(event.damagingEntity, hitEntity);
});

world.afterEvents.entityHitBlock.subscribe(event => {
    tryThrowFromHit(event.damagingEntity, undefined);
});

world.afterEvents.playerLeave.subscribe(event => {
    USE_COOLDOWNS.delete(event.playerId);
    THROW_FROM_HIT_COOLDOWNS.delete(event.playerId);
    SNEAK_CYCLE_COOLDOWNS.delete(event.playerId);
    SNEAK_STATES.delete(event.playerId);
});
