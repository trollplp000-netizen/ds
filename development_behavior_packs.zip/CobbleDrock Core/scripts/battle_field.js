import { isGrounded, pokemonTypes, typeEffectiveness } from "./battle_math.js";

const TIMED_SIDE_CONDITIONS = new Set(["reflect", "lightscreen", "mist", "safeguard", "tailwind", "luckychant"]);
const ONE_TURN_SIDE_CONDITIONS = new Set(["quickguard", "wideguard"]);

function sideState(field, side) {
    if (!field.sides || typeof field.sides !== "object") field.sides = {};
    if (!field.sides[side] || typeof field.sides[side] !== "object") field.sides[side] = {};
    return field.sides[side];
}

export function battleSideState(field, side) {
    return sideState(createBattleField(field), side);
}

export function createBattleField(existing = undefined) {
    const field = existing && typeof existing === "object" ? existing : {};
    if (!field.sides) field.sides = {};
    sideState(field, "player");
    sideState(field, "opponent");
    return field;
}

export function damageFieldOptions(field, defenderSide) {
    const state = sideState(createBattleField(field), defenderSide);
    return {
        weather: field.weather?.id || "",
        terrain: field.terrain?.id || "",
        reflect: Number(state.reflect) > 0,
        lightScreen: Number(state.lightscreen) > 0,
        quickGuard: Number(state.quickguard) > 0,
        wideGuard: Number(state.wideguard) > 0,
        safeguard: Number(state.safeguard) > 0,
        mist: Number(state.mist) > 0
    };
}

export function speedFieldMultiplier(field, side) {
    return Number(sideState(createBattleField(field), side).tailwind) > 0 ? 2 : 1;
}

export function applyFieldResidual(field, pokemon) {
    const messages = [];
    const types = pokemonTypes(pokemon);
    const weather = String(field?.weather?.id || "").toLowerCase();
    if (weather === "sandstorm" && !types.some(type => ["ground", "rock", "steel"].includes(type))) {
        pokemon.currentHp = Math.max(0, Number(pokemon.currentHp) - Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 16)));
        messages.push(`${pokemon.nickname || "Pokemon"} was buffeted by the sandstorm!`);
    }
    if (String(field?.terrain?.id || "").toLowerCase() === "grassyterrain" && isGrounded(pokemon) && Number(pokemon.currentHp) > 0) {
        const before = Number(pokemon.currentHp) || 0;
        pokemon.currentHp = Math.min(Number(pokemon.maxHp) || before, before + Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / 16)));
        if (pokemon.currentHp > before) messages.push(`${pokemon.nickname || "Pokemon"} was healed by the grassy terrain!`);
    }
    return messages;
}

export function applyMoveFieldEffects(field, actorSide, move, defenderSide = undefined) {
    const messages = [];
    createBattleField(field);
    const targetSide = move.target === "foeSide" || move.sideConditionTarget === "foe"
        ? (defenderSide || (actorSide === "player" ? "opponent" : "player"))
        : actorSide;
    const state = sideState(field, targetSide);
    if (move.weather) {
        field.weather = { id: move.weather, turns: 5 };
        messages.push(`The weather changed to ${move.weather}!`);
    }
    if (move.terrain) {
        field.terrain = { id: move.terrain, turns: 5 };
        messages.push(`${move.terrain} spread across the battlefield!`);
    }
    if (move.pseudoWeather) {
        if (!field.pseudoWeather) field.pseudoWeather = {};
        field.pseudoWeather[move.pseudoWeather] = 5;
    }
    if (move.sideCondition) {
        const id = move.sideCondition;
        if (id === "spikes") state.spikes = Math.min(3, (Number(state.spikes) || 0) + 1);
        else if (id === "toxicspikes") state.toxicspikes = Math.min(2, (Number(state.toxicspikes) || 0) + 1);
        else if (id === "stealthrock") state.stealthrock = 1;
        else if (id === "tailwind") state[id] = 4;
        else state[id] = TIMED_SIDE_CONDITIONS.has(id) ? 5 : 1;
        messages.push(`${move.name}'s effect began on the allied side!`);
    }
    return messages;
}

export function fieldEffectWouldFail(field, actorSide, move, defenderSide = undefined) {
    createBattleField(field);
    if (move.weather && String(field.weather?.id || "") === String(move.weather)) return true;
    if (move.terrain && String(field.terrain?.id || "") === String(move.terrain)) return true;
    if (move.pseudoWeather && Number(field.pseudoWeather?.[move.pseudoWeather]) > 0) return true;
    if (!move.sideCondition) return false;
    const targetSide = move.target === "foeSide" || move.sideConditionTarget === "foe"
        ? (defenderSide || (actorSide === "player" ? "opponent" : "player"))
        : actorSide;
    const state = sideState(field, targetSide);
    if (move.sideCondition === "spikes") return Number(state.spikes) >= 3;
    if (move.sideCondition === "toxicspikes") return Number(state.toxicspikes) >= 2;
    if (move.sideCondition === "stealthrock") return Number(state.stealthrock) > 0;
    return Number(state[move.sideCondition]) > 0;
}

export function applyEntryHazards(field, side, pokemon) {
    const state = sideState(createBattleField(field), side);
    const messages = [];
    const types = pokemonTypes(pokemon);
    if (state.healingwish && (Number(pokemon.currentHp) < Number(pokemon.maxHp) || String(pokemon.statusCondition || "NONE").toLowerCase() !== "none")) {
        pokemon.currentHp = pokemon.maxHp;
        pokemon.statusCondition = "NONE";
        state.healingwish = 0;
        messages.push("The healing wish came true!");
    }
    if (state.stealthrock && Number(pokemon.currentHp) > 0) {
        const damage = Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) * typeEffectiveness("rock", types) / 8));
        pokemon.currentHp = Math.max(0, Number(pokemon.currentHp) - damage);
        messages.push("Pointed stones dug into the Pokemon!");
    }
    if (state.spikes && isGrounded(pokemon) && Number(pokemon.currentHp) > 0) {
        const divisor = Number(state.spikes) === 1 ? 8 : Number(state.spikes) === 2 ? 6 : 4;
        pokemon.currentHp = Math.max(0, Number(pokemon.currentHp) - Math.max(1, Math.floor((Number(pokemon.maxHp) || 1) / divisor)));
        messages.push("The Pokemon was hurt by Spikes!");
    }
    if (state.toxicspikes && isGrounded(pokemon) && !types.includes("steel") && Number(pokemon.currentHp) > 0) {
        if (types.includes("poison")) state.toxicspikes = 0;
        else if (!state.safeguard && String(pokemon.statusCondition || "NONE").toLowerCase() === "none") pokemon.statusCondition = Number(state.toxicspikes) > 1 ? "TOX" : "PSN";
    }
    return messages;
}

export function clearEntryHazards(field, side) {
    const state = sideState(createBattleField(field), side);
    state.spikes = 0;
    state.toxicspikes = 0;
    state.stealthrock = 0;
}

export function setSideEffect(field, side, effect, value = 1) {
    sideState(createBattleField(field), side)[effect] = value;
}

export function queueFutureMove(field, targetSide, attacker, moveId = "futuresight") {
    createBattleField(field);
    if (!field.futureMoves || typeof field.futureMoves !== "object") field.futureMoves = {};
    if (field.futureMoves[targetSide]) return false;
    field.futureMoves[targetSide] = { turns: 3, attacker, moveId };
    return true;
}

export function advanceBattleField(field) {
    createBattleField(field);
    const dueFutureMoves = [];
    for (const side of Object.values(field.sides)) {
        for (const id of TIMED_SIDE_CONDITIONS) if (Number(side[id]) > 0) side[id]--;
        for (const id of ONE_TURN_SIDE_CONDITIONS) side[id] = 0;
    }
    if (field.weather?.turns > 0 && --field.weather.turns <= 0) field.weather = undefined;
    if (field.terrain?.turns > 0 && --field.terrain.turns <= 0) field.terrain = undefined;
    for (const [id, turns] of Object.entries(field.pseudoWeather || {})) {
        field.pseudoWeather[id] = Math.max(0, Number(turns) - 1);
        if (field.pseudoWeather[id] <= 0) delete field.pseudoWeather[id];
    }
    for (const [side, futureMove] of Object.entries(field.futureMoves || {})) {
        futureMove.turns = Math.max(0, Number(futureMove.turns) - 1);
        if (futureMove.turns <= 0) {
            dueFutureMoves.push({ side, ...futureMove });
            delete field.futureMoves[side];
        }
    }
    return dueFutureMoves;
}
