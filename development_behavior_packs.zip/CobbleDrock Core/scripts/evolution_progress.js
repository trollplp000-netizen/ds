export function recordEvolutionProgress(pokemon, kind, amount = 1, key = "") {
    if (!pokemon || !Number.isFinite(amount) || amount <= 0) return;
    const progress = pokemon.evolutionProgress ??= {};
    if (key) {
        const values = progress[kind] ??= {};
        values[key] = (Number(values[key]) || 0) + amount;
    } else progress[kind] = (Number(progress[kind]) || 0) + amount;
}

export function resetEvolutionBattleProgress(pokemon) {
    if (pokemon?.evolutionProgress) pokemon.evolutionProgress.battle_critical_hits = 0;
}

