function blockIsFallbackSurface(block) {
    if (!block) return false;
    try {
        if (block.isLiquid === true) return true;
        if (block.isAir === true) return false;
    } catch (error) { return false; }
    return !String(block?.typeId || "").endsWith(":air");
}

export function battlePositionCorrection(location, anchor, maxHorizontalDriftSquared = 0.25, lockHeight = false) {
    const locationX = Number(location?.x);
    const locationY = Number(location?.y);
    const locationZ = Number(location?.z);
    const anchorX = Number(anchor?.x);
    const anchorZ = Number(anchor?.z);
    const targetY = lockHeight ? Number(anchor?.y) : locationY;
    const configuredDrift = Number(maxHorizontalDriftSquared);
    if (![locationX, locationY, locationZ, anchorX, anchorZ, targetY].every(Number.isFinite)) return undefined;

    const dx = locationX - anchorX;
    const dz = locationZ - anchorZ;
    const allowedDriftSquared = Number.isFinite(configuredDrift) ? Math.max(0, configuredDrift) : 0.25;
    if (dx * dx + dz * dz <= allowedDriftSquared && Math.abs(locationY - targetY) <= 0.01) return undefined;
    return { x: anchorX, y: targetY, z: anchorZ };
}

export function findBattleSurfaceAnchor(dimension, location, maxDrop = 48) {
    const x = Number(location?.x);
    const y = Number(location?.y);
    const z = Number(location?.z);
    if (!dimension || !Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
        return location ? { ...location } : undefined;
    }

    let minimumY = -64;
    try {
        const configuredMinimum = Number(dimension.heightRange?.min);
        if (Number.isFinite(configuredMinimum)) minimumY = configuredMinimum;
    } catch (error) {}
    const startY = Math.floor(y);
    const endY = Math.max(minimumY, startY - Math.max(1, Math.floor(Number(maxDrop) || 48)));
    const blockX = Math.floor(x);
    const blockZ = Math.floor(z);

    try {
        if (typeof dimension.getBlockBelow === "function") {
            const surface = dimension.getBlockBelow({ x, y, z }, {
                includeLiquidBlocks: true,
                includePassableBlocks: false,
                maxDistance: Math.max(1, Math.floor(Number(maxDrop) || 48))
            });
            const surfaceY = Number(surface?.location?.y ?? surface?.y);
            if (Number.isFinite(surfaceY)) return { x, y: surfaceY + 1, z };
        }
    } catch (error) {}

    for (let blockY = startY; blockY >= endY; blockY--) {
        let block;
        try { block = dimension.getBlock({ x: blockX, y: blockY, z: blockZ }); } catch (error) {}
        if (!blockIsFallbackSurface(block)) continue;
        return { x, y: blockY + 1, z };
    }
    return { x, y, z };
}
