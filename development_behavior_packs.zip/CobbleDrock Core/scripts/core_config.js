export const CORE_CONFIG = Object.freeze({
    defaultBoxCount: 30,
    experienceMultiplier: 1.0,
    preventCompletePartyDeposit: true,
    remotePcEnabled: false,
    shinyRate: 4096
});
