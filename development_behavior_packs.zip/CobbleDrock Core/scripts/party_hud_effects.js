export const BAR_UPDATE_BEFORE_TIME = 15;
export const BAR_UPDATE_AFTER_TIME = 15;
export const BAR_FLASH_TIME = 2;
export const BAR_UPDATE_NO_LEVEL_TIME = 32;

export const LEVEL_UP_PORTRAIT_TIME = 10;

export const POPUP_TIME = Object.freeze({ fadeIn: 3, hold: 40, fadeOut: 3 });
export const EXP_POPUP_TIME = Object.freeze({
    fadeIn: 3,
    hold: 17 + (POPUP_TIME.fadeIn + POPUP_TIME.hold + POPUP_TIME.fadeOut) - 6,
    fadeOut: 3
});

export const EXP_GAINED_TICKS_MAX = 17 + (3 + 40 + 3);
export const EVOLUTION_TICKS_MAX = 3 + 40 + 3;
export const MOVES_TICKS_MAX = 3 + 40 + 3;

export const LEVEL_SCROLL_STEPS = 14;
export const LEVEL_SCROLL_WINDOW = LEVEL_UP_PORTRAIT_TIME;

export const RenderTarget = Object.freeze({
    NONE: 0,
    EXP_GAINED: 1,
    EVOLUTION: 2,
    MOVES: 3
});

export function fadeTimingsTotal(timings) {
    return timings.fadeIn + timings.hold + timings.fadeOut;
}

export function popupCurve(ticks, timings = POPUP_TIME) {
    if (!(ticks > 0)) return { yOffset: 0, transparency: 0 };
    if (ticks <= timings.fadeIn) {
        const transition = ticks / timings.fadeIn;
        const step = Math.floor(transition * 3) + 1;
        return { yOffset: 4 - step, transparency: step * 0.25 };
    }
    if (ticks <= timings.fadeIn + timings.hold) {
        return { yOffset: 0, transparency: 1 };
    }
    const adjusted = ticks - (timings.fadeIn + timings.hold);
    const transition = adjusted / timings.fadeOut;
    const step = Math.floor(transition * 3) + 1;
    return { yOffset: -step, transparency: 1 - step * 0.25 };
}

export function levelScrollFrame(ticks) {
    const transition = (ticks - 17) / LEVEL_SCROLL_WINDOW;
    if (!(transition >= 0) || !(transition < 1)) return null;
    const step = Math.ceil(transition * LEVEL_SCROLL_STEPS);
    if (step < 1) return null;
    return Math.min(LEVEL_SCROLL_STEPS, step);
}

function makeExpData({ oldLevel = null, expGained = 0, movesLearned = 0, evosUnlocked = 0 } = {}) {
    return {
        kind: RenderTarget.EXP_GAINED,
        ticks: 0,
        ticksMax: EXP_GAINED_TICKS_MAX,
        oldLevel,
        expGained,
        movesLearned,
        evosUnlocked
    };
}

function makeEvoData(evolutionCount = 1) {
    return { kind: RenderTarget.EVOLUTION, ticks: 0, ticksMax: EVOLUTION_TICKS_MAX, evolutionCount };
}

function makeMoveData(movesCount = 1) {
    return { kind: RenderTarget.MOVES, ticks: 0, ticksMax: MOVES_TICKS_MAX, movesCount };
}

export const PARTY_EFFECT_SOUNDS = Object.freeze({
    start: { vanilla: "random.orb", pack: null },
    levelup: { vanilla: "random.levelup", pack: null },
    evo: { vanilla: "random.levelup", pack: "lota.evolution.notification" }
});

export class PartyOverlayEffects {
    constructor() {
        this.records = new Map();
        this.sounds = new Map();
    }

    clear() {
        this.records.clear();
        this.sounds.clear();
    }

    _dataFor(key, create = false) {
        let data = this.records.get(key);
        if (!data && create) {
            data = { exp: null, evo: null, move: null };
            this.records.set(key, data);
        }
        return data || null;
    }

    _queueSound(key, name) {
        if (!key) return;
        const list = this.sounds.get(key) || [];
        list.push(name);
        this.sounds.set(key, list);
    }

    drainSounds(uuid) {
        const key = String(uuid || "");
        const list = this.sounds.get(key) || [];
        this.sounds.delete(key);
        return list;
    }

    expGained(uuid, result) {
        const key = String(uuid || "");
        if (!key || !result || !(result.amount > 0)) return;

        let movesLearned = Array.isArray(result.learnedMoves) ? result.learnedMoves.length : 0;
        let evosUnlocked = Array.isArray(result.queuedEvolutions) ? result.queuedEvolutions.length : 0;
        let oldLevel = result.newLevel !== result.oldLevel ? result.oldLevel : null;
        let expGained = result.amount;

        const data = this._dataFor(key, true);
        if (data.move) {
            movesLearned += Number(data.move.movesCount) || 0;
            data.move = null;
        }
        if (data.evo) {
            evosUnlocked += Number(data.evo.evolutionCount) || 0;
            data.evo = null;
        }
        if (data.exp) {
            movesLearned += Number(data.exp.movesLearned) || 0;
            evosUnlocked += Number(data.exp.evosUnlocked) || 0;
            if (data.exp.oldLevel != null) oldLevel = data.exp.oldLevel;
            expGained += Number(data.exp.expGained) || 0;
        }

        data.exp = makeExpData({ oldLevel, expGained, movesLearned, evosUnlocked });
        this._queueSound(key, "start");
    }

    evolutionGained(uuid, evolutionCount = 1) {
        const key = String(uuid || "");
        if (!key || !(evolutionCount > 0)) return;
        const data = this._dataFor(key, true);
        if (data.exp) {
            data.exp.evosUnlocked = (data.exp.evosUnlocked || 0) + evolutionCount;
            return;
        }
        if (data.evo) {
            data.evo.evolutionCount = (data.evo.evolutionCount || 0) + evolutionCount;
            data.evo.ticks = 0;
            return;
        }
        data.evo = makeEvoData(evolutionCount);
    }

    movesGained(uuid, movesCount = 1) {
        const key = String(uuid || "");
        if (!key || !(movesCount > 0)) return;
        const data = this._dataFor(key, true);
        if (data.exp) {
            data.exp.movesLearned = (data.exp.movesLearned || 0) + movesCount;
            return;
        }
        if (data.move) {
            data.move.movesCount = (data.move.movesCount || 0) + movesCount;
            data.move.ticks = 0;
            return;
        }
        data.move = makeMoveData(movesCount);
    }

    tick(uuids, paused = false, onSound = null) {
        if (paused) return;
        for (const [key, data] of [...this.records]) {
            if (data.exp) {
                data.exp.ticks += 1;
                if (data.exp.ticks === BAR_UPDATE_BEFORE_TIME && data.exp.oldLevel != null) {
                    const cue = (data.exp.evosUnlocked || 0) > 0 ? "evo" : "levelup";
                    this._queueSound(key, cue);
                    if (typeof onSound === "function") {
                        try { onSound(key, cue); } catch (error) {}
                    }
                }
                if (data.exp.ticks >= data.exp.ticksMax) data.exp = null;
            } else {
                if (data.evo) {
                    data.evo.ticks += 1;
                    if (data.evo.ticks >= data.evo.ticksMax) data.evo = null;
                }
                if (data.move) {
                    data.move.ticks += 1;
                    if (data.move.ticks >= data.move.ticksMax) data.move = null;
                }
            }
            if (!data.exp && !data.evo && !data.move) {
                this.records.delete(key);
                continue;
            }
        }
        if (Array.isArray(uuids)) {
            const known = new Set(uuids.map(String));
            for (const key of [...this.records.keys()]) {
                if (!known.has(key)) {
                    this.records.delete(key);
                    this.sounds.delete(key);
                }
            }
        }
    }

    markersFor(uuid, progress = 0) {
        const data = this.records.get(String(uuid || ""));
        if (!data) return { levelScrollFrame: null, movePopup: false, evoPopup: false, expPopup: false, expAmount: 0 };
        const exp = data.exp;

        if (exp) {
            const ticks = exp.ticks;
            return {
                levelScrollFrame: levelScrollFrame(ticks),
                movePopup: ticks - 17 > 0 && (exp.movesLearned || 0) > 0,
                evoPopup: ticks - 17 > 0 && (exp.evosUnlocked || 0) > 0,
                expPopup: popupCurveWithin(ticks, EXP_POPUP_TIME) > 0,
                expAmount: Number(exp.expGained) || 0,
                levelOverride: ticks < BAR_UPDATE_BEFORE_TIME ? exp.oldLevel : null,
                expBar: expBarFill(exp, ticks, progress)
            };
        }
        if (data.evo) {
            return {
                levelScrollFrame: null,
                movePopup: false,
                evoPopup: popupCurveWithin(data.evo.ticks, POPUP_TIME) > 0,
                expPopup: false,
                expAmount: 0,
                levelOverride: null,
                expBar: null
            };
        }
        if (data.move) {
            return {
                levelScrollFrame: null,
                movePopup: popupCurveWithin(data.move.ticks, POPUP_TIME) > 0,
                evoPopup: false,
                expPopup: false,
                expAmount: 0,
                levelOverride: null,
                expBar: null
            };
        }
        return { levelScrollFrame: null, movePopup: false, evoPopup: false, expPopup: false, expAmount: 0 };
    }

    renderTarget(uuid) {
        const data = this.records.get(String(uuid || ""));
        if (!data) return RenderTarget.NONE;
        if (data.exp) return RenderTarget.EXP_GAINED;
        if (data.evo) return RenderTarget.EVOLUTION;
        if (data.move) return RenderTarget.MOVES;
        return RenderTarget.NONE;
    }
}

function popupCurveWithin(ticks, timings) {
    return popupCurve(ticks, timings).transparency;
}

export function expBarFill(record, ticks, progress = 0) {
    if (record.oldLevel == null) {
        const transition = clamp01(ticks / BAR_UPDATE_NO_LEVEL_TIME);
        return { ratio: clamp01(Number(progress) || 0) * transition, flash: false };
    }
    if (ticks <= BAR_UPDATE_BEFORE_TIME) {
        const transition = clamp01(ticks / BAR_UPDATE_BEFORE_TIME);
        return { ratio: Math.max(0, 1 - transition), flash: false };
    }
    if (ticks <= BAR_UPDATE_BEFORE_TIME + BAR_FLASH_TIME) {
        return { ratio: 1, flash: true };
    }
    const adjusted = ticks - (BAR_UPDATE_BEFORE_TIME + BAR_FLASH_TIME);
    const transition = clamp01(adjusted / BAR_UPDATE_AFTER_TIME);
    return { ratio: clamp01(progress) * transition, flash: false };
}

function clamp01(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 0;
    return Math.max(0, Math.min(1, number));
}

export function expRecordLifetime(record) {
    void record;
    return EXP_GAINED_TICKS_MAX;
}

const EFFECTS = new Map();

export function partyEffectsFor(playerId) {
    const key = String(playerId || "");
    if (!key) return null;
    let effects = EFFECTS.get(key);
    if (!effects) {
        effects = new PartyOverlayEffects();
        EFFECTS.set(key, effects);
    }
    return effects;
}

export function dropPartyEffects(playerId) {
    EFFECTS.delete(String(playerId || ""));
}

export function tickPartyEffects(playersWithUuids = []) {
    for (const entry of playersWithUuids) {
        const effects = partyEffectsFor(entry.playerId);
        if (effects) effects.tick(entry.uuids || [], false);
    }
}
