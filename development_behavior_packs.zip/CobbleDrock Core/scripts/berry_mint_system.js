import { EnchantmentTypes, ItemStack, system } from "@minecraft/server";
import {
    BERRY_BIOME_IDS,
    MULCH_DATA,
    getBerryByBlock,
    getMintCrop
} from "./berry_mint_data.js";
import {
    getCropData,
    setCropData,
    deleteCropData
} from "./berry_mint_storage.js";
import {
    BERRY_MAX_STAGE,
    HARVEST_RESET_STAGE,
    MINT_MAX_STAGE,
    berryBreakDrops,
    berrySoilValid,
    buildHarvestDrops,
    canBeMulched,
    chooseMutationSlot,
    createGrowthPool,
    findNeighborMutations,
    mintLightSufficient,
    mintLoot,
    mintSoilValid,
    nextStageTimerFromPool,
    rollMutation,
    stagesLeftInPhase,
    calculateYield
} from "./berry_mint_logic.js";

const GROWTH_STATE = "lota:growth_stage";
const MULCH_STATE = "lota:mulch";
const IS_WILD_STATE = "lota:is_wild";
const YIELD_STATE = "lota:yield_count";
const MUTATION_RESULT_STATE = "lota:mutation_result";

const MULCH_ITEM_SUFFIX = "_mulch";
const TICK_CLAIM_TTL_TICKS = 2;

const actionClaims = new Map();
function claim(key) {
    const now = Number(system.currentTick) || 0;
    const existing = actionClaims.get(key);
    if (existing !== undefined && now - existing <= TICK_CLAIM_TTL_TICKS) return false;
    actionClaims.set(key, now);
    if (actionClaims.size > 2048) {
        for (const [k, t] of actionClaims) {
            if (now - t > TICK_CLAIM_TTL_TICKS) actionClaims.delete(k);
        }
    }
    return true;
}

function getBlockSafe(dimension, location, ox = 0, oy = 0, oz = 0) {
    try {
        return dimension.getBlock({
            x: Math.floor(location.x + ox),
            y: Math.floor(location.y + oy),
            z: Math.floor(location.z + oz)
        });
    } catch (error) {
        return undefined;
    }
}

function belowBlock(dimension, location) {
    return getBlockSafe(dimension, location, 0, -1, 0);
}

function selectedItem(player) {
    try {
        const container = player?.getComponent("minecraft:inventory")?.container;
        const slot = Math.max(0, Math.floor(Number(player?.selectedSlotIndex) || 0));
        return { container, slot, item: container?.getItem(slot) };
    } catch (error) {
        return { container: undefined, slot: -1, item: undefined };
    }
}

function isCreativePlayer(player) {
    try {
        return String(player?.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function consumeSelectedItem(player, expectedTypeId) {
    if (isCreativePlayer(player)) return true;
    const { container, slot, item } = selectedItem(player);
    if (!container || !item || item.typeId !== expectedTypeId) return false;
    if (item.amount <= 1) {
        container.setItem(slot, undefined);
    } else {
        item.amount -= 1;
        container.setItem(slot, item);
    }
    return true;
}

function spawnDrop(dimension, location, itemTypeId, count = 1) {
    if (!dimension || !location || !itemTypeId || count <= 0) return;
    try {
        const stack = new ItemStack(itemTypeId, count);
        dimension.spawnItem(stack, {
            x: location.x + 0.5,
            y: location.y + 0.3,
            z: location.z + 0.5
        });
    } catch (error) {
        console.warn(`Failed to spawn drop ${itemTypeId}: ${error}`);
    }
}

function playSound(dimension, location, soundId, volume = 1) {
    try {
        dimension.playSound(soundId, location, { volume, pitch: 1 });
    } catch (error) {}
}

function playGrowthParticles(dimension, location) {
    try {
        dimension.spawnParticle("minecraft:crop_growth_emitter", {
            x: location.x + 0.5,
            y: location.y + 0.5,
            z: location.z + 0.5
        });
    } catch (error) {}
}

function cleanBiomeId(id) {
    return String(id || "").replace(/^minecraft:/, "").toLowerCase();
}

function stateMutationToItemId(value) {
    const clean = String(value || "none");
    return clean === "none" ? undefined : "lota:" + clean;
}

function isPreferredBerryBiome(berry, dimension, location) {
    if (!berry?.preferredBiomeTags?.length || !dimension || !location) return false;
    let biomeId = "";
    try {
        biomeId = cleanBiomeId(dimension.getBiome(location)?.id);
    } catch (error) {
        return false;
    }
    return berry.preferredBiomeTags.some(tag => BERRY_BIOME_IDS[tag]?.includes(biomeId));
}

function mulchDurationAfter(delta, mulchType, currentDuration) {
    const configured = Number(MULCH_DATA[mulchType]?.duration) || 0;
    const base = Number.isFinite(currentDuration) && currentDuration > 0 ? currentDuration : configured;
    const next = base + delta;
    if (configured === -1) return -1;
    return next <= 0 ? 0 : next;
}

function mulchExpired(duration) {
    return duration === 0;
}

function applyMulchDelta(block, cropData, delta) {
    if (!delta) return cropData;
    const mulch = cropData.mulch || "none";
    if (mulch === "none") return cropData;
    const duration = mulchDurationAfter(delta, mulch, cropData.mulchDuration);
    const expired = mulchExpired(duration) && Number(MULCH_DATA[mulch]?.duration) !== -1;
    const nextMulch = expired ? "none" : mulch;
    try {
        block.setPermutation(block.permutation.withState(MULCH_STATE, nextMulch));
    } catch (error) {}
    const updated = { ...cropData, mulch: nextMulch, mulchDuration: expired ? 0 : duration };
    return updated;
}

function recoverBerryCropData(block, berry, stage, mulch) {
    const stateMutation = String(block.permutation.getState(MUTATION_RESULT_STATE) || "none");
    const poolData = createGrowthPool(berry, stage, mulch);
    return {
        blockId: berry.blockId,
        stage,
        mulch,
        mulchDuration: mulch === "none" ? 0 : Number(MULCH_DATA[mulch]?.duration) || 0,
        pool: poolData.pool,
        stagesLeft: poolData.stagesLeft,
        stageTimer: poolData.stageTimer,
        yieldCount: Number(block.permutation.getState(YIELD_STATE)) || 0,
        mutationResult: stateMutation === "none" ? "none" : "lota:" + stateMutation,
        mutationSlot: 0,
        drops: []
    };
}

function getStoredBerryCropData(block, berry) {
    const stored = getCropData(block.dimension, block.location);
    if (stored?.blockId && stored.blockId !== berry?.blockId) return undefined;
    return stored;
}

function getGrowthBerryCropData(block, berry, stage, mulch) {
    const stored = getStoredBerryCropData(block, berry);
    const timer = Number(stored?.stageTimer);
    const pool = Number(stored?.pool);
    const stageMatches = Number(stored?.stage) === stage;
    if (stageMatches && Number.isFinite(timer) && timer > 0 && Number.isFinite(pool)) {
        return stored;
    }
    return recoverBerryCropData(block, berry, stage, mulch);
}

function advanceBerryStage(block, isBoneMeal = false) {
    const dimension = block.dimension;
    const location = block.location;
    const berry = getBerryByBlock(block.typeId);
    if (!berry) return;
    const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
    if (stage >= BERRY_MAX_STAGE) return;
    const nextStage = stage + 1;
    const mulch = String(block.permutation.getState(MULCH_STATE) || "none");
    const cropData = getGrowthBerryCropData(block, berry, stage, mulch);

    let updated = { ...cropData, stage: nextStage };

    if (nextStage === HARVEST_RESET_STAGE + 1) {
        const biomeMatches = isPreferredBerryBiome(berry, dimension, location);
        const { yieldCount, mulchDurationDelta: richDelta } = calculateYield(berry, mulch, biomeMatches);
        updated = applyMulchDelta(block, updated, richDelta);
        const activeMulch = updated.mulch;

        const neighborItems = [];
        for (const offset of [
            { x: 0, z: -1 }, { x: 0, z: 1 }, { x: -1, z: 0 }, { x: 1, z: 0 }
        ]) {
            const neighbor = getBlockSafe(dimension, location, offset.x, 0, offset.z);
            if (!neighbor || !neighbor.typeId.endsWith("_berry_bush")) continue;
            const neighborBerry = getBerryByBlock(neighbor.typeId);
            if (neighborBerry) neighborItems.push(neighborBerry.itemId);
        }
        const offered = findNeighborMutations(berry, neighborItems);
        const { result: mutationResult, mulchDurationDelta: surpriseDelta } = rollMutation(offered, activeMulch);
        updated = applyMulchDelta(block, updated, surpriseDelta);

        const finalYield = yieldCount;
        const finalMutation = mutationResult && finalYield > 0 ? mutationResult : "none";
        const visualYield = Math.min(finalYield, 2);
        const mutationSlot = finalMutation !== "none" ? chooseMutationSlot(finalYield) : 0;
        const stateMutation = finalMutation === "none" ? "none" : finalMutation.replace(/^lota:/, "");
        const drops = buildHarvestDrops(berry, finalYield, finalMutation !== "none" ? finalMutation : undefined, mutationSlot);

        try {
            block.setPermutation(
                block.permutation
                    .withState(GROWTH_STATE, nextStage)
                    .withState(YIELD_STATE, visualYield)
                    .withState(MUTATION_RESULT_STATE, stateMutation)
            );
        } catch (error) {}
        updated = {
            ...updated,
            stage: nextStage,
            yieldCount: finalYield,
            visualYieldCount: visualYield,
            mutationResult: finalMutation,
            mutationSlot: finalMutation !== "none" ? mutationSlot : 0,
            drops
        };
    } else {
        try {
            block.setPermutation(block.permutation.withState(GROWTH_STATE, nextStage));
        } catch (error) {}
    }

    const currentMulch = updated.mulch;
    if (nextStage === HARVEST_RESET_STAGE || nextStage === 0) {
        const poolData = createGrowthPool(berry, nextStage, currentMulch);
        updated = applyMulchDelta(block, { ...updated, pool: poolData.pool, stagesLeft: poolData.stagesLeft, stageTimer: poolData.stageTimer }, poolData.mulchDurationDelta);
    } else if (nextStage < BERRY_MAX_STAGE) {
        const stagesLeft = stagesLeftInPhase(nextStage);
        const stageTimer = nextStageTimerFromPool(updated.pool, stagesLeft);
        updated = { ...updated, pool: Math.max(0, updated.pool - stageTimer), stagesLeft, stageTimer };
    }

    setCropData(dimension, location, updated);

    if (isBoneMeal) {
        playGrowthParticles(dimension, location);
        playSound(dimension, location, "item.bone_meal.use");
    }
}

function harvestBerryBush(block, player = undefined) {
    const dimension = block.dimension;
    const location = block.location;
    const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
    if (stage !== BERRY_MAX_STAGE) return;
    const berry = getBerryByBlock(block.typeId);
    if (!berry) return;
    const mulch = String(block.permutation.getState(MULCH_STATE) || "none");
    const cropData = getStoredBerryCropData(block, berry);

    const drops = cropData?.drops?.length
        ? [...cropData.drops]
        : buildHarvestDrops(berry, Number(block.permutation.getState(YIELD_STATE)) || berry.baseYieldMin || 2, stateMutationToItemId(String(block.permutation.getState(MUTATION_RESULT_STATE) || "none")));

    for (const dropId of drops) spawnDrop(dimension, location, dropId, 1);
    playSound(dimension, location, "lota.cobblemon.berry_bush_harvest");

    let updated = {
        ...(cropData || {}),
        stage: HARVEST_RESET_STAGE,
        yieldCount: 0,
        mutationResult: "none",
        mutationSlot: 0,
        drops: []
    };
    try {
        block.setPermutation(
            block.permutation
                .withState(GROWTH_STATE, HARVEST_RESET_STAGE)
                .withState(YIELD_STATE, 0)
                .withState(MUTATION_RESULT_STATE, "none")
        );
    } catch (error) {}
    const poolData = createGrowthPool(berry, HARVEST_RESET_STAGE, mulch);
    updated = applyMulchDelta(block, { ...updated, mulch, pool: poolData.pool, stagesLeft: poolData.stagesLeft, stageTimer: poolData.stageTimer }, poolData.mulchDurationDelta);
    setCropData(dimension, location, updated);
}

function applyMulchToBerryBush(block, mulchType) {
    const dimension = block.dimension;
    const location = block.location;
    const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
    const currentMulch = String(block.permutation.getState(MULCH_STATE) || "none");
    if (!canBeMulched(stage, currentMulch)) return false;
    if (!MULCH_DATA[mulchType]) return false;

    const berry = getBerryByBlock(block.typeId);
    try {
        block.setPermutation(block.permutation.withState(MULCH_STATE, mulchType));
    } catch (error) {
        return false;
    }
    let cropData = getGrowthBerryCropData(block, berry, stage, currentMulch);
    cropData = {
        ...cropData,
        stage,
        mulch: mulchType,
        mulchDuration: Number(MULCH_DATA[mulchType]?.duration) || 0
    };
    if (mulchType === "growth") {
        cropData = {
            ...cropData,
            pool: cropData.pool * 0.5,
            stageTimer: Math.max(1, Math.round(cropData.stageTimer * 0.5))
        };
    }
    setCropData(dimension, location, cropData);
    playSound(dimension, location, "lota.cobblemon.mulch_place", 0.8);
    return true;
}

function removeMulchFromBerryBush(block) {
    const dimension = block.dimension;
    const location = block.location;
    const berry = getBerryByBlock(block.typeId);
    const currentMulch = String(block.permutation.getState(MULCH_STATE) || "none");
    if (currentMulch === "none") return false;

    try {
        block.setPermutation(
            block.permutation
                .withState(MULCH_STATE, "none")
                .withState(GROWTH_STATE, 0)
                .withState(YIELD_STATE, 0)
                .withState(MUTATION_RESULT_STATE, "none")
        );
    } catch (error) {
        return false;
    }
    const poolData = berry ? createGrowthPool(berry, 0, "none") : undefined;
    setCropData(dimension, location, {
        blockId: berry?.blockId,
        stage: 0,
        mulch: "none",
        mulchDuration: 0,
        pool: poolData?.pool || 0,
        stagesLeft: poolData?.stagesLeft || 3,
        stageTimer: poolData?.stageTimer || 1,
        yieldCount: 0,
        mutationResult: "none",
        mutationSlot: 0,
        drops: []
    });
    playSound(dimension, location, "lota.cobblemon.mulch_remove", 0.8);
    return true;
}

function validateBerrySoil(block) {
    const below = belowBlock(block.dimension, block.location);
    if (berrySoilValid(String(below?.typeId || ""), false)) return true;
    try {
        block.setType("minecraft:air");
    } catch (error) {}
    deleteCropData(block.dimension, block.location);
    return false;
}

function advanceMintStage(block, isBoneMeal = false) {
    const dimension = block.dimension;
    const location = block.location;
    const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
    if (stage >= MINT_MAX_STAGE) return;
    try {
        block.setPermutation(block.permutation.withState(GROWTH_STATE, stage + 1));
    } catch (error) {
        return;
    }
    if (isBoneMeal) {
        playGrowthParticles(dimension, location);
        playSound(dimension, location, "item.bone_meal.use");
    }
}

function mintLightLevel(block) {
    const location = {
        x: block.location.x,
        y: block.location.y + 1,
        z: block.location.z
    };
    try {
        return Number(block.dimension.getLightLevel(location)) || 0;
    } catch (error) {
        return 15;
    }
}

function validateMintSurvival(block) {
    const below = belowBlock(block.dimension, block.location);
    const isWild = !!block.permutation.getState(IS_WILD_STATE);
    const light = mintLightLevel(block);
    if (light >= 8 && mintSoilValid(String(below?.typeId || ""), isWild)) return true;
    try {
        block.setType("minecraft:air");
    } catch (error) {}
    return false;
}

function fortuneLevelFor(player) {
    try {
        const tool = selectedItem(player).item;
        const enchantable = tool?.getComponent("minecraft:enchantable");
        if (!enchantable) return 0;
        const type = EnchantmentTypes.get("fortune");
        if (!type) return 0;
        const enchantment = enchantable.getEnchantment(type);
        return Number(enchantment?.level) || 0;
    } catch (error) {
        return 0;
    }
}

system.beforeEvents.startup.subscribe(event => {
    event.blockComponentRegistry.registerCustomComponent("lota:berry_crop", {
        onPlace: eventData => {
            const block = eventData.block;
            if (!block) return;
            const berry = getBerryByBlock(block.typeId);
            if (!berry) return;
            const dimension = block.dimension;
            const location = block.location;
            const existing = getStoredBerryCropData(block, berry);
            const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
            if (existing && Number(existing.stage) === stage && Number.isFinite(Number(existing.stageTimer)) && Number.isFinite(Number(existing.pool))) return;
            const mulch = String(block.permutation.getState(MULCH_STATE) || "none");
            const poolData = createGrowthPool(berry, stage, mulch);
            setCropData(dimension, location, {
                blockId: berry.blockId,
                stage,
                mulch,
                mulchDuration: mulch === "none" ? 0 : Number(MULCH_DATA[mulch]?.duration) || 0,
                pool: poolData.pool,
                stagesLeft: poolData.stagesLeft,
                stageTimer: poolData.stageTimer,
                yieldCount: Number(block.permutation.getState(YIELD_STATE)) || 0,
                mutationResult: String(block.permutation.getState(MUTATION_RESULT_STATE) || "none"),
                mutationSlot: 0,
                drops: []
            });
            playSound(dimension, location, "lota.cobblemon.berry_bush_place");
        },
        onTick: eventData => {
            const block = eventData.block;
            if (!block) return;
            const berry = getBerryByBlock(block.typeId);
            if (!berry) return;
            if (!validateBerrySoil(block)) return;

            const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
            if (stage >= BERRY_MAX_STAGE) return;

            const dimension = block.dimension;
            const location = block.location;
            const mulch = String(block.permutation.getState(MULCH_STATE) || "none");
            const cropData = getGrowthBerryCropData(block, berry, stage, mulch);

            const stageTimer = Number(cropData.stageTimer) - 1;
            if (stageTimer <= 0) {
                advanceBerryStage(block, false);
            } else {
                setCropData(dimension, location, { ...cropData, stageTimer });
            }
        },
        onPlayerInteract: eventData => {
            const { block, player } = eventData;
            if (!block || !player) return;
            const { item } = selectedItem(player);
            const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
            const mulch = String(block.permutation.getState(MULCH_STATE) || "none");
            const dimension = block.dimension;
            const location = block.location;

            if (item?.typeId === "minecraft:shears" && mulch !== "none") {
                const key = `${dimension.id}:${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}:shear`;
                if (!claim(key)) return;
                system.run(() => {
                    removeMulchFromBerryBush(block);
                });
                return;
            }

            if (item?.typeId === "minecraft:bone_meal") {
                if (stage >= BERRY_MAX_STAGE) return;
                const berry = getBerryByBlock(block.typeId);
                const boneMealChance = berry?.boneMealChance || 0.4;
                const key = `${dimension.id}:${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}:bm`;
                if (!claim(key)) return;
                const success = Math.random() < boneMealChance;
                const consumed = consumeSelectedItem(player, "minecraft:bone_meal");
                if (!consumed) return;
                system.run(() => {
                    if (success) {
                        advanceBerryStage(block, true);
                    } else {
                        playGrowthParticles(dimension, location);
                    }
                });
                return;
            }

            if (item?.typeId?.startsWith("lota:") && item.typeId.endsWith(MULCH_ITEM_SUFFIX) && item.typeId !== "lota:mulch_base") {
                const mulchType = item.typeId.replace(/^lota:/, "").replace(new RegExp(MULCH_ITEM_SUFFIX + "$"), "");
                if (!MULCH_DATA[mulchType]) return;
                if (!canBeMulched(stage, mulch)) return;
                const key = `${dimension.id}:${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}:mulch`;
                if (!claim(key)) return;
                const applied = applyMulchToBerryBush(block, mulchType);
                if (applied) consumeSelectedItem(player, item.typeId);
                return;
            }

            if (stage === BERRY_MAX_STAGE) {
                const key = `${dimension.id}:${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}:harvest`;
                if (!claim(key)) return;
                system.run(() => {
                    const current = Number(block.permutation.getState(GROWTH_STATE)) || 0;
                    if (current !== BERRY_MAX_STAGE) return;
                    harvestBerryBush(block, player);
                });
            }
        },
        onPlayerBreak: eventData => {
            const block = eventData.block;
            const player = eventData.player;
            if (!block) return;
            const permutation = eventData.brokenBlockPermutation || block.permutation;
            const dimension = block.dimension;
            const location = { ...block.location };
            const stage = Number(permutation.getState(GROWTH_STATE)) || 0;
            const berry = getBerryByBlock(permutation.type.id);

            const scheduledDrops = [];
            if (berry) {
                if (stage === BERRY_MAX_STAGE) {
                    const cropData = getStoredBerryCropData(block, berry);
                    if (cropData?.drops?.length) {
                        scheduledDrops.push(...cropData.drops);
                    } else {
                        scheduledDrops.push(...buildHarvestDrops(berry, Number(permutation.getState(YIELD_STATE)) || berry.baseYieldMin || 2, stateMutationToItemId(String(permutation.getState(MUTATION_RESULT_STATE) || "none"))));
                    }
                } else {
                    scheduledDrops.push(...berryBreakDrops(stage, berry, undefined));
                }
            }
            const sound = stage === BERRY_MAX_STAGE ? "lota.cobblemon.berry_bush_harvest" : "lota.cobblemon.berry_bush_break";
            system.run(() => {
                for (const dropId of scheduledDrops) spawnDrop(dimension, location, dropId, 1);
                playSound(dimension, location, sound);
                deleteCropData(dimension, location);
            });
        },
        onBreak: eventData => {
            if (eventData.entitySource?.typeId === "minecraft:player") return;
            const block = eventData.block;
            if (!block) return;
            const permutation = eventData.brokenBlockPermutation || block.permutation;
            const dimension = block.dimension;
            const location = { ...block.location };
            const stage = Number(permutation.getState(GROWTH_STATE)) || 0;
            const berry = getBerryByBlock(permutation.type.id);
            const scheduledDrops = berry ? berryBreakDrops(stage, berry, undefined) : [];
            system.run(() => {
                for (const dropId of scheduledDrops) spawnDrop(dimension, location, dropId, 1);
                deleteCropData(dimension, location);
            });
        }
    });

    event.blockComponentRegistry.registerCustomComponent("lota:mint_crop", {
        onTick: eventData => {
            const block = eventData.block;
            if (!block) return;
            if (!validateMintSurvival(block)) return;

            const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
            if (stage >= MINT_MAX_STAGE) return;
            if (mintLightSufficient(mintLightLevel(block)) && Math.random() < 1 / 8) {
                advanceMintStage(block, false);
            }
        },
        onPlayerInteract: eventData => {
            const { block, player } = eventData;
            if (!block || !player) return;
            const { item } = selectedItem(player);
            if (item?.typeId !== "minecraft:bone_meal") return;
            const stage = Number(block.permutation.getState(GROWTH_STATE)) || 0;
            if (stage >= MINT_MAX_STAGE) return;
            const dimension = block.dimension;
            const location = block.location;
            const key = `${dimension.id}:${Math.floor(location.x)},${Math.floor(location.y)},${Math.floor(location.z)}:mintbm`;
            if (!claim(key)) return;
            const consumed = consumeSelectedItem(player, "minecraft:bone_meal");
            if (!consumed) return;
            system.run(() => {
                advanceMintStage(block, true);
            });
        },
        onPlayerBreak: eventData => {
            const block = eventData.block;
            if (!block) return;
            const permutation = eventData.brokenBlockPermutation || block.permutation;
            const dimension = block.dimension;
            const location = { ...block.location };
            const stage = Number(permutation.getState(GROWTH_STATE)) || 0;
            const crop = getMintCrop(permutation.type.id);
            if (!crop) return;
            const player = eventData.player;
            const fortune = player ? fortuneLevelFor(player) : 0;
            const drops = mintLoot(stage, crop, fortune);
            system.run(() => {
                for (const drop of drops) spawnDrop(dimension, location, drop.item, drop.count);
                playSound(dimension, location, "lota.cobblemon.mint_break");
            });
        }
    });
});

