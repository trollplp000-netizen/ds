import { ScriptEventSource, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    abortRaidTrainerBattle,
    applyRaidTrainerBattleActions,
    finishRaidTrainerBattle,
    refreshRaidTrainerBattle,
    startTrainerBattle
} from "./battle_system.js";
import { calculateMaxHp, normalizePokemonForBattle, speciesData } from "./battle_math.js";
import { captureBallForItem, applyCaptureBallEffects, markCaptureEncounter, markSpeciesCaptured } from "./capture_rate.js";
import { moveData } from "./move_registry.js";
import {
    addPokemonToPlayerParty,
    generateRandomPokemon,
    generateUUID,
    loadPartyFromPlayer
} from "./storage.js";
import {
    RAID_ABILITY_BLACKLIST,
    RAID_MOVE_BLACKLIST,
    raidContributionEligible,
    raidSharedMaxHealth,
    raidTierConfig
} from "./raid_config.js";

export const RAID_API_VERSION = 1;
export const RAID_REQUEST_EVENT = "lota:server_raid_battle_request_v1";
export const RAID_RESET_EVENT = "lota:server_raid_battle_reset_v1";
export const RAID_RESULT_EVENT = "lota:server_raid_battle_result_v1";
export const RAID_REWARD_RESULT_EVENT = "lota:server_raid_reward_result_v1";

const MAX_REQUEST_LENGTH = 24_000;
const REQUEST_TTL_TICKS = 20 * 60 * 10;
const FINISHED_RAID_TTL_TICKS = 20 * 60 * 5;
const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";
const STAT_KEYS = Object.freeze(["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"]);
const activeRaids = new Map();
const playerRaids = new Map();
const recentRequests = new Map();

function cleanText(value, fallback = "", maximumLength = 96) {
    const text = String(value ?? "").trim();
    return (text || fallback).slice(0, maximumLength);
}

function parseMessage(message) {
    const serialized = String(message || "");
    if (!serialized || serialized.length > MAX_REQUEST_LENGTH) return undefined;
    try {
        const value = JSON.parse(serialized);
        return value && typeof value === "object" ? value : undefined;
    } catch (error) {
        return undefined;
    }
}

function playerById(playerId) {
    const id = String(playerId || "");
    return id ? world.getAllPlayers().find(player => String(player.id) === id) : undefined;
}

function selectedPartySlot(player) {
    const value = Math.floor(Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY)));
    return Number.isInteger(value) && value >= 0 && value < 6 ? value : 0;
}

function entityById(entityId) {
    try { return world.getEntity(String(entityId || "")); }
    catch (error) { return undefined; }
}

function speciesId(value) {
    return cleanText(value, "", 64).replace(/^(lota|cobblemon):/, "").toLowerCase();
}

function knownMove(id) {
    const normalized = cleanText(id, "", 64).replace(/^(lota|cobblemon):/, "").toLowerCase();
    return !!normalized && String(moveData(normalized)?.id || "").toLowerCase() === normalized;
}

function pokemonMoves(values, raidLegal = true) {
    if (!Array.isArray(values)) return undefined;
    const ids = values
        .map(value => cleanText(typeof value === "string" ? value : value?.id, "", 64).toLowerCase())
        .filter(Boolean)
        .slice(0, 4);
    if (!ids.length) return undefined;
    for (const id of ids) {
        if (!knownMove(id) || (raidLegal && RAID_MOVE_BLACKLIST.has(id))) throw new Error(`invalid_move:${id}`);
    }
    return ids.map(id => {
        const pp = Math.max(1, Math.floor(Number(moveData(id)?.pp) || 1));
        return { id, pp, maxPp: pp };
    });
}

function setMinimumPerfectIvs(pokemon, minimum) {
    pokemon.ivs ||= {};
    const shuffled = [...STAT_KEYS].sort(() => Math.random() - 0.5);
    let perfect = STAT_KEYS.filter(stat => Number(pokemon.ivs[stat]) === 31).length;
    for (const stat of shuffled) {
        if (perfect >= minimum) break;
        if (Number(pokemon.ivs[stat]) === 31) continue;
        pokemon.ivs[stat] = 31;
        perfect++;
    }
}

function setRequestedIvs(pokemon, values) {
    if (!values || typeof values !== "object") return;
    pokemon.ivs ||= {};
    for (const stat of STAT_KEYS) {
        if (Number.isFinite(Number(values[stat]))) {
            pokemon.ivs[stat] = Math.max(0, Math.min(31, Math.floor(Number(values[stat]))));
        }
    }
}

function syncIdentityAspects(pokemon) {
    const genderTokens = new Set(["male", "female", "genderless"]);
    pokemon.aspects = [...new Set([
        ...(pokemon.aspects || []).filter(value => {
            const token = String(value).toLowerCase();
            return token !== "shiny" && !genderTokens.has(token);
        }),
        String(pokemon.gender || "genderless").toLowerCase(),
        ...(pokemon.isShiny ? ["shiny"] : [])
    ])];
}

function selectAbility(pokemon, data, request, hiddenAbilityRate) {
    const explicit = cleanText(request?.ability, "", 64);
    if (explicit) {
        pokemon.ability = explicit;
        return;
    }
    const hidden = (data?.abilities || [])
        .map(value => String(value || ""))
        .filter(value => value.startsWith("h:"))
        .map(value => value.slice(2))
        .filter(Boolean);
    if (hidden.length && Math.random() < hiddenAbilityRate) {
        pokemon.ability = hidden[Math.floor(Math.random() * hidden.length)];
    }
}

function configuredPokemon(request, species, level, tier, reward = false) {
    const data = speciesData(species);
    if (!data) throw new Error(`unknown_species:${species || "empty"}`);
    const pokemon = generateRandomPokemon(`lota:${species}`, level);
    pokemon.nickname = cleanText(request?.nickname, data.name || species, 64);
    if (request?.form) pokemon.form = cleanText(request.form, "normal", 32);
    if (request?.gender) pokemon.gender = cleanText(request.gender, pokemon.gender, 16).toUpperCase();
    if (request?.nature) {
        pokemon.nature = cleanText(request.nature, pokemon.nature, 32).toLowerCase();
        pokemon.mintedNature = pokemon.nature;
    }
    if (typeof request?.isShiny === "boolean") pokemon.isShiny = request.isShiny;
    if (request?.heldItem && !reward) pokemon.heldItem = cleanText(request.heldItem, "", 64);
    if (Array.isArray(request?.aspects)) {
        pokemon.aspects = [...new Set(request.aspects
            .map(value => cleanText(value, "", 32))
            .filter(Boolean)
            .slice(0, 12))];
    }
    syncIdentityAspects(pokemon);
    selectAbility(pokemon, data, request, tier.hiddenAbilityRate);
    setRequestedIvs(pokemon, request?.ivs);
    setMinimumPerfectIvs(pokemon, tier.perfectIvs);
    const moves = pokemonMoves(request?.moves, false);
    if (moves) pokemon.moves = moves;
    if (!reward) {
        pokemon.moves = (pokemon.moves || []).filter(move => {
            const id = cleanText(move?.id, "", 64).toLowerCase();
            return knownMove(id);
        });
        if (!pokemon.moves.length) throw new Error("no_raid_legal_moves");
    }
    normalizePokemonForBattle(pokemon);
    pokemon.maxHp = calculateMaxHp(pokemon);
    pokemon.currentHp = pokemon.maxHp;
    pokemon.statusCondition = "NONE";
    return pokemon;
}

function rewardTemplate(request, boss, tier) {
    const rewardRequest = request.reward && typeof request.reward === "object" ? request.reward : {};
    const rewardSpecies = speciesId(rewardRequest.species || request.boss?.rewardSpecies || request.boss?.species);
    const reward = configuredPokemon(rewardRequest, rewardSpecies, tier.rewardLevel, tier, true);
    reward.isShiny = boss.isShiny === true;
    reward.gender = boss.gender;
    reward.nature = boss.nature;
    reward.mintedNature = boss.nature;
    const teraType = cleanText(rewardRequest.teraType || rewardRequest.raidType, "", 16).toLowerCase();
    if (teraType) reward.teraType = teraType;
    syncIdentityAspects(reward);
    normalizePokemonForBattle(reward);
    reward.maxHp = calculateMaxHp(reward);
    reward.currentHp = reward.maxHp;
    return reward;
}

function cloneReward(template) {
    const pokemon = JSON.parse(JSON.stringify(template));
    pokemon.uuid = generateUUID();
    pokemon.currentHp = pokemon.maxHp;
    pokemon.statusCondition = "NONE";
    delete pokemon.battleState;
    return pokemon;
}

function resultParticipants(state) {
    return [...state.participants.values()].map(participant => ({
        playerId: participant.playerId,
        damage: Math.round(participant.damage),
        contribution: Number((participant.damage / state.health.max).toFixed(6)),
        eligible: participant.withdrawn !== true
            && raidContributionEligible(participant.damage, state.health.max, state.tier),
        defeated: participant.defeated === true,
        cheersUsed: participant.cheersUsed
    }));
}

function sendEvent(id, payload) {
    try { system.sendScriptEvent(id, JSON.stringify(payload)); }
    catch (error) { console.warn(`[CobbleDrockRaid] Result event '${id}' failed: ${error}`); }
}

function publishRaidResult(state, outcome, detail = "", requestId = state?.requestId || "") {
    sendEvent(RAID_RESULT_EVENT, {
        version: RAID_API_VERSION,
        requestId,
        raidId: state?.raidId || "",
        outcome,
        detail,
        tier: state?.tierNumber || 0,
        bossSpecies: state?.bossSpecies || "",
        sharedHp: Math.max(0, Math.ceil(Number(state?.health?.current) || 0)),
        sharedMaxHp: Math.max(0, Math.ceil(Number(state?.health?.max) || 0)),
        currency: state?.tier?.currency || 0,
        energy: state?.tier?.energy || 0,
        participants: state ? resultParticipants(state) : []
    });
}

function publishRejected(request, detail) {
    const state = {
        requestId: cleanText(request?.requestId, "", 128),
        raidId: cleanText(request?.raidId, "", 128),
        tierNumber: Math.floor(Number(request?.tier) || 0),
        bossSpecies: speciesId(request?.boss?.species),
        health: { current: 0, max: 0 },
        participants: new Map()
    };
    console.warn(`[CobbleDrockRaid] Raid '${state.raidId || state.requestId}' rejected: ${detail}`);
    publishRaidResult(state, "rejected", detail);
}

function publishReward(state, participant, outcome, detail = "", storage = undefined) {
    sendEvent(RAID_REWARD_RESULT_EVENT, {
        version: RAID_API_VERSION,
        requestId: participant.requestId || state.requestId,
        raidId: state.raidId,
        playerId: participant.playerId,
        outcome,
        detail,
        tier: state.tierNumber,
        contribution: Number((participant.damage / state.health.max).toFixed(6)),
        currency: state.tier.currency,
        energy: state.tier.energy,
        raidType: state.rewardRaidType,
        pokemonSpecies: speciesId(state.reward.species),
        storage: storage ? { ...storage } : undefined
    });
}

function applyScriptActions(state, actions) {
    const list = Array.isArray(actions) ? actions : [];
    if (list.includes("SHIELD_UP")) state.health.shield = true;
    if (list.includes("SHIELD_DOWN")) state.health.shield = false;
    for (const participant of state.participants.values()) {
        applyRaidTrainerBattleActions(participant.playerId, list);
    }
}

function evaluateRaidScripts(state, turn = undefined) {
    if (!state || state.outcome || state.starting) return;
    const hpRatio = state.health.current / state.health.max;
    state.tier.scripts.forEach((script, index) => {
        const key = `${index}`;
        if (state.triggeredScripts.has(key)) return;
        const dueByTurn = Number.isFinite(Number(script.turn)) && Number(turn) >= Number(script.turn);
        const dueByHealth = Number.isFinite(Number(script.hp)) && hpRatio <= Number(script.hp);
        if (!dueByTurn && !dueByHealth) return;
        state.triggeredScripts.add(key);
        applyScriptActions(state, script.actions);
    });
}

function reportBossHealthChange(state, participant, delta, detail) {
    if (!state || state.outcome || state.starting) return;
    const requested = Number(delta) || 0;
    if (requested > 0) {
        const applied = Math.min(state.health.current, requested);
        state.health.current = Math.max(0, state.health.current - applied);
        if (["move", "residual"].includes(detail?.source)) participant.damage += applied;
    } else if (requested < 0) {
        state.health.current = Math.min(state.health.max, state.health.current - requested);
    }
    evaluateRaidScripts(state);
    for (const member of state.participants.values()) refreshRaidTrainerBattle(member.playerId);
    if (state.health.current <= 0) completeRaid(state, "victory");
}

function useCheer(state, participant, type) {
    if (!state || state.outcome || participant.defeated) return { success: false, message: "The raid is no longer active." };
    if (participant.cheersUsed >= state.tier.maxCheers) return { success: false, message: "You have no cheers remaining." };
    participant.cheersUsed++;
    if (type === "attack") {
        for (const member of state.participants.values()) if (member.session?.raidBattle) member.session.raidBattle.attackCheer = true;
        return { success: true, message: `${participant.playerName} cheered: Go All Out!` };
    }
    if (type === "defense") {
        for (const member of state.participants.values()) if (member.session?.raidBattle) member.session.raidBattle.defenseCheer = true;
        return { success: true, message: `${participant.playerName} cheered: Hang Tough!` };
    }
    for (const member of state.participants.values()) {
        const session = member.session;
        const pokemon = session?.party?.[session.playerSlot];
        if (!pokemon || Number(pokemon.currentHp) <= 0) continue;
        pokemon.currentHp = Math.min(Number(pokemon.maxHp) || 1, Number(pokemon.currentHp) + Math.max(1, Math.floor(Number(pokemon.maxHp) * 0.5)));
        refreshRaidTrainerBattle(member.playerId);
    }
    return { success: true, message: `${participant.playerName} cheered: Heal Up!` };
}

function participantLost(state, participant) {
    if (!state || state.starting || state.outcome || participant.defeated) return;
    participant.defeated = true;
    if ([...state.participants.values()].every(value => value.defeated)) completeRaid(state, "loss");
}

function availableBalls(player) {
    let container;
    try { container = player.getComponent("minecraft:inventory")?.container; }
    catch (error) { return []; }
    if (!container) return [];
    const grouped = new Map();
    for (let slot = 0; slot < container.size; slot++) {
        const stack = container.getItem(slot);
        const ball = captureBallForItem(stack?.typeId);
        if (!ball) continue;
        const current = grouped.get(stack.typeId) || { ball, itemId: stack.typeId, amount: 0, slots: [] };
        current.amount += Math.max(1, Number(stack.amount) || 1);
        current.slots.push(slot);
        grouped.set(stack.typeId, current);
    }
    return [...grouped.values()];
}

function consumeBall(player, entry) {
    try {
        if (String(player.getGameMode()).toLowerCase() === "creative") return true;
        const container = player.getComponent("minecraft:inventory")?.container;
        const slot = entry.slots.find(index => container?.getItem(index)?.typeId === entry.itemId);
        if (!Number.isInteger(slot)) return false;
        const stack = container.getItem(slot);
        if (stack.amount <= 1) container.setItem(slot, undefined);
        else {
            stack.amount -= 1;
            container.setItem(slot, stack);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function showRewardForm(state, participant) {
    if (participant.rewardClaimed) return;
    const player = playerById(participant.playerId);
    if (!player?.isValid) return;
    const entries = availableBalls(player);
    const form = new ActionFormData()
        .title("Raid Victory!")
        .body(`Catch ${state.reward.nickname || speciesId(state.reward.species)}? The raid catch is guaranteed.`);
    for (const entry of entries) form.button(`${entry.ball.name} x${entry.amount}`);
    form.button("Pass");
    form.show(player).then(response => {
        if (participant.rewardClaimed) return;
        const selection = Math.floor(Number(response?.selection));
        if (response?.canceled || !Number.isInteger(selection) || selection === entries.length) {
            participant.rewardClaimed = true;
            publishReward(state, participant, "passed");
            return;
        }
        const entry = entries[selection];
        if (!entry) return showRewardForm(state, participant);
        const fresh = availableBalls(player).find(value => value.itemId === entry.itemId);
        if (!fresh) {
            player.sendMessage("§cThat Poké Ball is no longer in your inventory.§r");
            return showRewardForm(state, participant);
        }
        const reward = cloneReward(state.reward);
        reward.caughtBall = fresh.ball.caughtBall;
        applyCaptureBallEffects(reward, fresh.ball);
        const storage = addPokemonToPlayerParty(player, reward);
        if (!storage.success) {
            player.sendMessage("§cNo storage space is available for the raid Pokémon.§r");
            publishReward(state, participant, "storage_failed", storage.reason || "storage_full");
            return;
        }
        if (!consumeBall(player, fresh)) {
            player.sendMessage("§eThe Pokémon was stored, but the selected Poké Ball could not be consumed.§r");
            console.warn(`[CobbleDrockRaid] Ball consumption failed after storing reward for ${participant.playerId}.`);
        }
        participant.rewardClaimed = true;
        markCaptureEncounter(player, reward);
        markSpeciesCaptured(player, reward);
        player.sendMessage(`§a${reward.nickname || speciesId(reward.species)} was sent to ${storage.location === "PARTY" ? "your party" : `PC Box ${Number(storage.box) + 1}`}!§r`);
        publishReward(state, participant, "caught", "", storage);
    }).catch(error => console.warn(`[CobbleDrockRaid] Reward form failed: ${error}`));
}

function releaseRaid(state) {
    activeRaids.delete(state.raidId);
    for (const participant of state.participants.values()) {
        if (playerRaids.get(participant.playerId) === state.raidId) playerRaids.delete(participant.playerId);
    }
    state.finishedTick = system.currentTick;
}

function cancelRaid(state, detail = "raid_reset") {
    if (!state || state.outcome) return false;
    state.outcome = "cancelled";
    for (const participant of state.participants.values()) {
        participant.withdrawn = true;
        abortRaidTrainerBattle(participant.playerId, detail, "§eThe raid was reset.§r");
    }
    publishRaidResult(state, "cancelled", detail);
    releaseRaid(state);
    return true;
}

function resetRaidParticipant(playerId, detail = "raid_replaced", expectedRaidId = "") {
    const normalizedPlayerId = String(playerId || "");
    if (!normalizedPlayerId) return false;
    const currentRaidId = playerRaids.get(normalizedPlayerId);
    if (expectedRaidId && currentRaidId !== expectedRaidId) return false;
    const state = currentRaidId ? activeRaids.get(currentRaidId) : undefined;
    const participant = state?.participants.get(normalizedPlayerId);
    if (participant) participant.withdrawn = true;
    const aborted = abortRaidTrainerBattle(
        normalizedPlayerId,
        detail,
        "§eYour previous raid was reset for the new challenge.§r"
    );
    if (participant && !aborted) participantLost(state, participant);
    if (playerRaids.get(normalizedPlayerId) === currentRaidId) playerRaids.delete(normalizedPlayerId);
    return !!currentRaidId || aborted;
}

function resetConflictingRaidParticipants(participants, nextRaidId) {
    for (const participant of participants) {
        const currentRaidId = playerRaids.get(participant.playerId);
        if (currentRaidId && currentRaidId !== nextRaidId) {
            resetRaidParticipant(participant.playerId, "raid_replaced", currentRaidId);
        } else if (!currentRaidId) {
            abortRaidTrainerBattle(
                participant.playerId,
                "stale_raid_reset",
                "§eYour previous raid was reset for the new challenge.§r"
            );
        }
    }
}

function completeRaid(state, outcome) {
    if (!state || state.outcome) return;
    state.outcome = outcome;
    if (outcome === "victory") {
        state.health.current = 0;
        for (const participant of state.participants.values()) finishRaidTrainerBattle(participant.playerId);
        publishRaidResult(state, "victory");
        for (const participant of state.participants.values()) {
            const eligible = participant.withdrawn !== true
                && raidContributionEligible(participant.damage, state.health.max, state.tier);
            const ineligibleDetail = participant.withdrawn === true
                ? "participant_withdrawn"
                : "insufficient_contribution";
            publishReward(state, participant, eligible ? "available" : "ineligible", eligible ? "" : ineligibleDetail);
            if (eligible) system.runTimeout(() => showRewardForm(state, participant), 60);
        }
    } else {
        publishRaidResult(state, "loss", "all_participants_defeated");
    }
    releaseRaid(state);
}

function validateParticipants(request, tier, anchor) {
    const requested = Array.isArray(request.participants) ? request.participants : [];
    if (!requested.length || requested.length > tier.maxPlayers) throw new Error("invalid_participant_count");
    const seen = new Set();
    return requested.map(value => {
        const playerId = String(value?.playerId || "");
        const player = playerById(playerId);
        if (!player?.isValid) throw new Error("participant_unavailable");
        if (seen.has(playerId)) throw new Error("duplicate_participant");
        if (player.dimension?.id !== anchor.dimension?.id) throw new Error("participant_dimension_mismatch");
        const hasRequestedSlot = Object.prototype.hasOwnProperty.call(value || {}, "partySlot");
        const partySlot = hasRequestedSlot
            ? Math.floor(Number(value.partySlot))
            : selectedPartySlot(player);
        if (!Number.isInteger(partySlot) || partySlot < 0 || partySlot > 5) throw new Error("invalid_party_slot");
        const pokemon = loadPartyFromPlayer(player)[partySlot];
        if (!pokemon || Number(pokemon.currentHp) <= 0) throw new Error("unusable_party_slot");
        const ability = cleanText(pokemon.ability, "", 64).replace(/^(lota|cobblemon):/, "").toLowerCase();
        if (RAID_ABILITY_BLACKLIST.has(ability)) throw new Error(`blacklisted_ability:${ability}`);
        const hasRaidMove = (pokemon.moves || []).some(move => {
            const id = cleanText(move?.id, "", 64).replace(/^(lota|cobblemon):/, "").toLowerCase();
            return knownMove(id) && !RAID_MOVE_BLACKLIST.has(id);
        });
        if (!hasRaidMove) throw new Error("no_raid_legal_moves");
        seen.add(playerId);
        return { player, playerId, playerName: player.name, partySlot, damage: 0, cheersUsed: 0, defeated: false, session: undefined, rewardClaimed: false };
    });
}

function resizeSharedRaidHealth(state, participantCount) {
    const previousMax = Math.max(1, Number(state.health.max) || 1);
    const healthRatio = Math.max(0, Math.min(1, Number(state.health.current) / previousMax));
    const nextMax = raidSharedMaxHealth(state.baseBossMaxHp, state.tier, participantCount);
    state.health.max = nextMax;
    state.health.current = nextMax * healthRatio;
}

function raidPlayerPokemonLocation(participant, anchor) {
    const playerLocation = participant.player.location;
    const bossLocation = anchor.location;
    let dx = Number(playerLocation.x) - Number(bossLocation.x);
    let dz = Number(playerLocation.z) - Number(bossLocation.z);
    const distance = Math.hypot(dx, dz);
    if (distance < 0.001) {
        dx = 0;
        dz = 1;
    } else {
        dx /= distance;
        dz /= distance;
    }
    return {
        x: Number(bossLocation.x) + dx * 8,
        y: Number(playerLocation.y),
        z: Number(bossLocation.z) + dz * 8
    };
}

function startRaidParticipantBattle(state, participant, anchor) {
    const participantBoss = JSON.parse(JSON.stringify(state.boss));
    participantBoss.uuid = generateUUID();
    const raidBattle = {
        health: state.health,
        singlePokemon: true,
        moveBlacklist: RAID_MOVE_BLACKLIST,
        attackCheer: false,
        defenseCheer: false,
        reportBossHealthChange: (delta, session, detail) => reportBossHealthChange(state, participant, delta, detail),
        useCheer: type => useCheer(state, participant, type),
        onTurnStart: turn => evaluateRaidScripts(state, turn)
    };
    return startTrainerBattle(participant.player, anchor, {
        trainerName: state.raidName,
        party: [participantBoss],
        playerSlot: participant.partySlot,
        opponentLocation: { ...anchor.location },
        playerPokemonLocation: raidPlayerPokemonLocation(participant, anchor),
        raidBossHidden: true,
        raidBattle,
        ai: { mode: state.tier.ai, switchBias: 0, itemBias: 0 },
        maxItemUses: 0,
        levelCap: 100,
        cameraSideScale: state.cameraSideScale,
        onStarted: (player, session) => { participant.session = session; },
        onVictory: () => completeRaid(state, "victory"),
        onLoss: () => participantLost(state, participant),
        onAbort: () => participantLost(state, participant)
    });
}

function joinActiveRaid(request, state, requestId) {
    if (!state || state.outcome) return publishRejected(request, "raid_finished");
    const tierNumber = Math.floor(Number(request.tier));
    if (tierNumber !== state.tierNumber) return publishRejected(request, "raid_tier_mismatch");
    const anchor = entityById(request.anchorEntityId);
    if (!anchor?.isValid || String(anchor.id) !== state.anchorEntityId) {
        return publishRejected(request, "anchor_mismatch");
    }

    let participants;
    try { participants = validateParticipants(request, state.tier, anchor); }
    catch (error) { return publishRejected(request, cleanText(error?.message || error, "invalid_request", 128)); }
    if (state.participants.size + participants.length > state.tier.maxPlayers) {
        return publishRejected(request, "raid_full");
    }
    if (participants.some(participant => state.participants.has(participant.playerId))) {
        return publishRejected(request, "participant_already_joined");
    }
    resetConflictingRaidParticipants(participants, state.raidId);
    if (participants.some(participant => playerRaids.has(participant.playerId))) {
        return publishRejected(request, "participant_already_raiding");
    }

    const previousCount = state.participants.size;
    state.starting = true;
    resizeSharedRaidHealth(state, previousCount + participants.length);
    const started = [];
    for (const participant of participants) {
        participant.requestId = requestId;
        state.participants.set(participant.playerId, participant);
        playerRaids.set(participant.playerId, state.raidId);
        if (!startRaidParticipantBattle(state, participant, anchor)) {
            for (const prior of started) abortRaidTrainerBattle(prior.playerId, "raid_join_failed", "§cYou could not join the raid.§r");
            for (const member of participants) {
                state.participants.delete(member.playerId);
                if (playerRaids.get(member.playerId) === state.raidId) playerRaids.delete(member.playerId);
            }
            resizeSharedRaidHealth(state, previousCount);
            state.starting = false;
            return publishRejected(request, "battle_unavailable");
        }
        started.push(participant);
    }
    state.starting = false;
    evaluateRaidScripts(state, 1);
    publishRaidResult(state, "started", "", requestId);
}

function startRaid(request) {
    if (Number(request?.version) !== RAID_API_VERSION) return publishRejected(request, "version_mismatch");
    const requestId = cleanText(request.requestId, "", 128);
    const raidId = cleanText(request.raidId, "", 128);
    if (!requestId || !raidId) return publishRejected(request, "missing_identifier");
    if (recentRequests.has(requestId)) return publishRejected(request, "duplicate_request");
    recentRequests.set(requestId, system.currentTick);
    const activeRaid = activeRaids.get(raidId);
    if (activeRaid) return joinActiveRaid(request, activeRaid, requestId);
    const tierNumber = Math.floor(Number(request.tier));
    const tier = raidTierConfig(tierNumber);
    if (!tier) return publishRejected(request, "invalid_tier");
    const anchor = entityById(request.anchorEntityId);
    if (!anchor?.isValid) return publishRejected(request, "anchor_unavailable");

    let boss;
    let reward;
    let participants;
    try {
        const bossSpecies = speciesId(request.boss?.species);
        boss = configuredPokemon(request.boss || {}, bossSpecies, tier.bossLevel, tier, false);
        reward = rewardTemplate(request, boss, tier);
        participants = validateParticipants(request, tier, anchor);
    } catch (error) {
        return publishRejected(request, cleanText(error?.message || error, "invalid_request", 128));
    }
    resetConflictingRaidParticipants(participants, raidId);
    if (participants.some(participant => playerRaids.has(participant.playerId))) {
        return publishRejected(request, "participant_already_raiding");
    }

    const sharedMaxHp = raidSharedMaxHealth(boss.maxHp, tier, participants.length);
    const state = {
        requestId,
        raidId,
        tierNumber,
        tier,
        bossSpecies: speciesId(boss.species),
        boss,
        baseBossMaxHp: boss.maxHp,
        anchorEntityId: String(anchor.id),
        raidName: cleanText(request.raidName, `Tier ${tierNumber} Raid`, 80),
        cameraSideScale: Number.isFinite(Number(request.cameraSideScale)) ? Number(request.cameraSideScale) : 1,
        reward,
        rewardRaidType: cleanText(request.reward?.raidType, "normal", 16).toLowerCase(),
        health: { current: sharedMaxHp, max: sharedMaxHp, shield: false },
        participants: new Map(participants.map(value => [value.playerId, value])),
        triggeredScripts: new Set(),
        starting: true,
        outcome: ""
    };
    activeRaids.set(raidId, state);
    for (const participant of participants) playerRaids.set(participant.playerId, raidId);

    const started = [];
    for (const participant of participants) {
        participant.requestId = requestId;
        const success = startRaidParticipantBattle(state, participant, anchor);
        if (!success) {
            for (const prior of started) abortRaidTrainerBattle(prior.playerId, "raid_start_failed", "§cThe raid could not start.§r");
            activeRaids.delete(raidId);
            for (const member of participants) if (playerRaids.get(member.playerId) === raidId) playerRaids.delete(member.playerId);
            return publishRejected(request, "battle_unavailable");
        }
        started.push(participant);
    }
    state.starting = false;
    evaluateRaidScripts(state, 1);
    publishRaidResult(state, "started");
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.sourceType !== ScriptEventSource.Server
        || ![RAID_REQUEST_EVENT, RAID_RESET_EVENT].includes(event.id)) return;
    const request = parseMessage(event.message);
    if (!request) return;
    if (event.id === RAID_REQUEST_EVENT) {
        system.run(() => startRaid(request));
        return;
    }
    if (Number(request.version) !== RAID_API_VERSION) return;
    system.run(() => {
        const raidId = cleanText(request.raidId, "", 128);
        const playerId = String(request.playerId || "");
        const detail = cleanText(request.detail, "raid_reset", 128);
        if (raidId && playerId) {
            resetRaidParticipant(playerId, detail, raidId);
        } else if (raidId) {
            cancelRaid(activeRaids.get(raidId), detail);
        } else if (playerId) {
            resetRaidParticipant(playerId, detail);
        }
    });
});

system.runInterval(() => {
    for (const [requestId, tick] of recentRequests) {
        if (system.currentTick - tick > REQUEST_TTL_TICKS) recentRequests.delete(requestId);
    }
    for (const state of activeRaids.values()) {
        if (state.finishedTick && system.currentTick - state.finishedTick > FINISHED_RAID_TTL_TICKS) activeRaids.delete(state.raidId);
    }
}, 100);
