import { world, system } from "@minecraft/server";
import { refreshChestScreen, registerChestScreen } from "./chest_ui.js";

const KEY = "badges";
const TITLE = "\u00a7r\u00a73\u00a7r\u00a73";
const STATE_EVENT = "lota:gym_badge_state_v1";
const REQUEST_EVENT = "lota:gym_badge_request_v1";
const CLICK_EVENT = "lota:gym_badge_click_v1";
const CASE_ITEM = "lota:gym_badge_case";
const OPEN_PROPERTY = "lota:badge_case_open";
const MASK_PROPERTY = "lota:badge_case_mask";
const MENU_FORM_TAG = "lota:menu_form";
const BADGE_ITEM_PREFIX = "lota:badge_";
const BADGES = Object.freeze(["stone", "water", "electric", "fighter", "fire", "metal", "grass", "flying", "ghost", "ground"]);
const COUNT = BADGES.length;

const ON_SLOT = 0;
const HAS_SLOT = 10;
const BUTTON_SLOT = 20;
const CLOSE_SLOT = 30;
const BODY_SLOT = 40;
const CLOSE_BUTTON = COUNT;

const states = new Map();

const LAYOUT = Object.freeze({
    title: TITLE,
    n: 41,
    tex: [], txt: [], cap: [],
    btn: [...Array.from({ length: COUNT }, (_, i) => [BUTTON_SLOT + i, i]), [CLOSE_SLOT, CLOSE_BUTTON]],
    vis: [
        ...Array.from({ length: COUNT }, (_, i) => [ON_SLOT + i, `|GYM:ON:${i}|`]),
        ...Array.from({ length: COUNT }, (_, i) => [HAS_SLOT + i, `|GYM:HAS:${i}|`])
    ],
    ml: [[BODY_SLOT, "body"]]
});

function bitCount(mask) {
    let value = mask & 0x3ff, count = 0;
    while (value) { count += value & 1; value >>>= 1; }
    return count;
}

function menuOn(player) {
    try { return !player.hasTag(MENU_FORM_TAG); } catch (error) { return true; }
}

function isCaseOpen(player) {
    try { return player.getProperty(OPEN_PROPERTY) === true; } catch (error) { return false; }
}

function holdsCase(player) {
    try {
        return player.getComponent("minecraft:inventory")?.container?.getItem(player.selectedSlotIndex)?.typeId === CASE_ITEM;
    } catch (error) { return false; }
}

function carriedMask(player) {
    let mask = 0;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) return 0;
        for (let slot = 0; slot < container.size; slot++) {
            const id = container.getItem(slot)?.typeId;
            if (typeof id !== "string" || !id.startsWith(BADGE_ITEM_PREFIX)) continue;
            const index = BADGES.indexOf(id.slice(BADGE_ITEM_PREFIX.length));
            if (index >= 0) mask |= 1 << index;
        }
    } catch (error) {}
    return mask;
}

function wants(player) {
    if (!menuOn(player)) return false;
    try { if (player.hasTag("lota:battle_player")) return false; } catch (error) { return false; }
    return isCaseOpen(player) && holdsCase(player);
}

function requestState(player) {
    try { system.sendScriptEvent(REQUEST_EVENT, String(player.id)); } catch (error) {}
}

function view(player) {
    const known = states.get(player.id);
    let equipped = known?.equipped;
    if (equipped === undefined) {
        try { equipped = Number(player.getProperty(MASK_PROPERTY)) || 0; } catch (error) { equipped = 0; }
    }
    const earned = known?.earned ?? equipped;
    const ready = carriedMask(player) & earned & ~equipped;
    let title = "";
    for (let i = 0; i < COUNT; i++) {
        const bit = 1 << i;
        if (equipped & bit) title += `|GYM:ON:${i}|`;
        if (ready & bit) title += `|GYM:HAS:${i}|`;
    }
    const cap = known?.cap ? `  \u00a77\u00b7  \u00a7aLv.${known.cap}` : "";
    return {
        title,
        buttons: [],
        icons: {},
        multi: { body: `\u00a7e${bitCount(earned)} / ${COUNT}${cap}` }
    };
}

function press(player, state, button) {
    if (button === CLOSE_BUTTON) return "close";
    if (button >= 0 && button < COUNT) {
        try { system.sendScriptEvent(CLICK_EVENT, JSON.stringify({ playerId: player.id, index: button })); } catch (error) {}
    }
    return "redraw";
}

registerChestScreen({
    key: KEY,
    layout: LAYOUT,
    wants,
    create: (player) => { requestState(player); return {}; },
    onOpen: (player) => requestState(player),
    view,
    press
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== STATE_EVENT) return;
    let data;
    try { data = JSON.parse(event.message); } catch (error) { return; }
    const id = String(data?.playerId ?? "");
    if (!id) return;
    states.set(id, {
        earned: Math.max(0, Math.floor(Number(data.earned) || 0)) & 0x3ff,
        equipped: Math.max(0, Math.floor(Number(data.equipped) || 0)) & 0x3ff,
        cap: Math.max(0, Math.floor(Number(data.cap) || 0))
    });
    const player = world.getAllPlayers().find(p => p.id === id);
    if (player?.isValid) refreshChestScreen(player, KEY);
});

world.afterEvents.playerLeave.subscribe(event => states.delete(event.playerId));
