export const POKEMON_TIME_RANGES = Object.freeze({
    any: [[0, 23999]],
    day: [[23460, 23999], [0, 12541]],
    night: [[12542, 23459]],
    morning: [[23000, 23999], [0, 4999]],
    noon: [[5000, 6999]],
    afternoon: [[7000, 12999]],
    evening: [[13000, 16999]],
    midnight: [[17000, 18999]],
    predawn: [[19000, 22999]],
    dawn: [[22300, 23999], [0, 166]],
    dusk: [[11834, 13701]],
    twilight: [[11834, 13701], [22300, 23999], [0, 166]]
});

export function pokemonTimeRangeMatches(time, range) {
    const tick = ((Math.floor(Number(time) || 0) % 24000) + 24000) % 24000;
    return POKEMON_TIME_RANGES[String(range || '').toLowerCase()]?.some(([min, max]) => tick >= min && tick <= max) === true;
}
