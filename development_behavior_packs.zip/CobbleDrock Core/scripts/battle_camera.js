function finite(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

function clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, finite(value, minimum)));
}

export function calculateFixedBattleCameraView({ allyFocus, opponentFocus, allyBase, allyMetrics, sideScale }) {
    const from = {
        x: finite(allyFocus?.x),
        y: finite(allyFocus?.y, finite(allyBase?.y) + 0.8),
        z: finite(allyFocus?.z)
    };
    const to = {
        x: finite(opponentFocus?.x, from.x),
        y: finite(opponentFocus?.y, from.y),
        z: finite(opponentFocus?.z, from.z + 1)
    };
    let dx = to.x - from.x;
    let dz = to.z - from.z;
    let separation = Math.hypot(dx, dz);
    if (separation < 0.001) {
        dx = 0;
        dz = 1;
        separation = 1;
    }
    const direction = { x: dx / separation, z: dz / separation };
    const right = { x: direction.z, z: -direction.x };
    const width = clamp(allyMetrics?.width, 0.4, 6);
    const height = clamp(allyMetrics?.height, 0.5, 10);
    const radius = clamp(allyMetrics?.radius, 0.5, 3);
    const backDistance = clamp(2.3 + radius + separation * 0.18, 3.4, 7.5);
    const sideDistance = clamp(4.2 + width * 0.4 + separation * 0.12, 4.8, 7.5);
    const resolvedSideScale = Math.max(-1, Math.min(1, finite(sideScale, 1)));
    const lift = clamp(1.05 + height * 0.45 + separation * 0.06, 1.7, 5.5);
    const baseY = finite(allyBase?.y, from.y - height * 0.75);
    const location = {
        x: from.x - direction.x * backDistance + right.x * sideDistance * resolvedSideScale,
        y: Math.max(from.y + lift, baseY + height + 0.8),
        z: from.z - direction.z * backDistance + right.z * sideDistance * resolvedSideScale
    };
    const facingLocation = {
        x: from.x * 0.2 + to.x * 0.8,
        y: from.y * 0.3 + to.y * 0.7,
        z: from.z * 0.2 + to.z * 0.8
    };
    return Object.freeze({ location: Object.freeze(location), facingLocation: Object.freeze(facingLocation) });
}
