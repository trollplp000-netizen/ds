import { EquipmentSlot, ItemLockMode, ItemStack, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    addPokemonToPlayerParty,
    generateRandomPokemon
} from "./storage.js";
import { calculateMaxHp } from "./battle_math.js";
import { chestScreenActive, openChestScreen, registerChestScreen } from "./chest_ui.js";

const STARTER_CHOSEN_PROPERTY = "lota:starter_chosen";
const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";
const STARTER_UI_BODY = "CBSTARTER_V114";
const REGION_NAMES = Object.freeze([
    "Kanto",
    "Johto",
    "Hoenn",
    "Sinnoh",
    "Unova",
    "Kalos",
    "Alola",
    "Galar",
    "Paldea"
]);
const FORM_BUSY_RETRY_LIMIT = 2;
const STARTERS_PER_REGION = 3;
const FIRST_JOIN_COMPASS = Object.freeze({
    typeId: "lota:pokemon_compass",
    amount: 1,
    preferredSlot: 7,
    unique: true,
    protected: true
});
const CORE_STARTER_ITEMS = Object.freeze([
    Object.freeze({ typeId: "lota:pokedex_red", amount: 1, preferredSlot: 6, unique: true, protected: true }),
    Object.freeze({ typeId: "lota:poke_ball", amount: 10 }),
    Object.freeze({ typeId: "lota:oran_berry", amount: 10 })
]);
const STARTERS = Object.freeze([
    {
        species: "lota:bulbasaur",
        dexId: 1,
        name: "Bulbasaur",
        region: "Kanto",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:charmander",
        dexId: 4,
        name: "Charmander",
        region: "Kanto",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:squirtle",
        dexId: 7,
        name: "Squirtle",
        region: "Kanto",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:chikorita",
        dexId: 152,
        name: "Chikorita",
        region: "Johto",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:cyndaquil",
        dexId: 155,
        name: "Cyndaquil",
        region: "Johto",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:totodile",
        dexId: 158,
        name: "Totodile",
        region: "Johto",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:treecko",
        dexId: 252,
        name: "Treecko",
        region: "Hoenn",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:torchic",
        dexId: 255,
        name: "Torchic",
        region: "Hoenn",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:mudkip",
        dexId: 258,
        name: "Mudkip",
        region: "Hoenn",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:turtwig",
        dexId: 387,
        name: "Turtwig",
        region: "Sinnoh",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:chimchar",
        dexId: 390,
        name: "Chimchar",
        region: "Sinnoh",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:piplup",
        dexId: 393,
        name: "Piplup",
        region: "Sinnoh",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:snivy",
        dexId: 495,
        name: "Snivy",
        region: "Unova",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:tepig",
        dexId: 498,
        name: "Tepig",
        region: "Unova",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:oshawott",
        dexId: 501,
        name: "Oshawott",
        region: "Unova",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:chespin",
        dexId: 650,
        name: "Chespin",
        region: "Kalos",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:fennekin",
        dexId: 653,
        name: "Fennekin",
        region: "Kalos",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:froakie",
        dexId: 656,
        name: "Froakie",
        region: "Kalos",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:rowlet",
        dexId: 722,
        name: "Rowlet",
        region: "Alola",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:litten",
        dexId: 725,
        name: "Litten",
        region: "Alola",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:popplio",
        dexId: 728,
        name: "Popplio",
        region: "Alola",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:grookey",
        dexId: 810,
        name: "Grookey",
        region: "Galar",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:scorbunny",
        dexId: 813,
        name: "Scorbunny",
        region: "Galar",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:sobble",
        dexId: 816,
        name: "Sobble",
        region: "Galar",
        ability: "torrent",
        ball: "poke_ball"
    },
    {
        species: "lota:sprigatito",
        dexId: 906,
        name: "Sprigatito",
        region: "Paldea",
        ability: "overgrow",
        ball: "poke_ball"
    },
    {
        species: "lota:fuecoco",
        dexId: 909,
        name: "Fuecoco",
        region: "Paldea",
        ability: "blaze",
        ball: "poke_ball"
    },
    {
        species: "lota:quaxly",
        dexId: 912,
        name: "Quaxly",
        region: "Paldea",
        ability: "torrent",
        ball: "poke_ball"
    }
]);

const sessions = new Map();
const starterClaims = new Set();

function tryClaimStarter(player) {
    if (hasChosenStarter(player)) return false;
    if (starterClaims.has(player.id)) return false;
    starterClaims.add(player.id);
    if (hasChosenStarter(player)) {
        starterClaims.delete(player.id);
        return false;
    }
    return true;
}

function releaseStarterClaim(player) {
    starterClaims.delete(player.id);
}

function wrapStarterIndex(index) {
    const count = STARTERS.length;
    return ((Math.floor(Number(index)) % count) + count) % count;
}

function clampRegionIndex(index) {
    const count = REGION_NAMES.length;
    return ((Math.floor(Number(index) || 0) % count) + count) % count;
}

function wrapPickIndex(index) {
    return ((Math.floor(Number(index) || 0) % STARTERS_PER_REGION) + STARTERS_PER_REGION) % STARTERS_PER_REGION;
}

function isPlayer(entity) {
    return entity?.typeId === "minecraft:player";
}

export function hasChosenStarter(player) {
    const value = player.getDynamicProperty(STARTER_CHOSEN_PROPERTY);
    return value === true || String(value || "").toLowerCase() === "true";
}

function markStarterChosen(player) {
    player.setDynamicProperty(STARTER_CHOSEN_PROPERTY, true);
}

function normalizeStarterPokemon(player, starter) {
    const pokemon = generateRandomPokemon(starter.species, 5);
    pokemon.nickname = starter.name;
    pokemon.ability = starter.ability;
    pokemon.caughtBall = starter.ball;
    pokemon.friendship = 70;
    pokemon.experience = 0;
    pokemon.statusCondition = "NONE";
    pokemon.pendingEvolutions = [];
    pokemon.evolutionTrackingVersion = 2;

    const maxHp = calculateMaxHp(pokemon);
    pokemon.maxHp = maxHp;
    pokemon.currentHp = maxHp;

    pokemon.originalTrainer = {
        name: player.name,
        uuid: player.id,
        type: "PLAYER"
    };

    return pokemon;
}

function actionBar(player, message) {
    try {
        player.onScreenDisplay.setActionBar(message);
    } catch (error) {}
}

function closeSession(player) {
    sessions.delete(player.id);
}

function retryIfBusy(player, session, reason) {
    if (!String(reason ?? "").toLowerCase().includes("busy")) return false;
    const retries = Math.max(0, Math.floor(Number(session.busyRetries) || 0));
    if (retries >= FORM_BUSY_RETRY_LIMIT) return false;
    session.busyRetries = retries + 1;
    system.run(() => showStarterSelection(player, session));
    return true;
}

function chooseStarter(player, session, index) {
    if (hasChosenStarter(player)) {
        actionBar(player, "Starter already chosen.");
        closeSession(player);
        return;
    }
    if (!tryClaimStarter(player)) {
        closeSession(player);
        return;
    }

    try {
        if (hasChosenStarter(player)) {
            actionBar(player, "Starter already chosen.");
            closeSession(player);
            return;
        }

        const starter = STARTERS[index];
        if (!starter) {
            closeSession(player);
            return;
        }

        const pokemon = normalizeStarterPokemon(player, starter);
        const result = addPokemonToPlayerParty(player, pokemon);
        if (!result.success) {
            actionBar(player, "No space left for your starter.");
            closeSession(player);
            return;
        }

        markStarterChosen(player);
        if (result.location === "PARTY") {
            player.setDynamicProperty(SELECTED_SLOT_PROPERTY, result.slot);
        }
        grantCoreStarterItems(player);

        actionBar(player, `${starter.name} joined your party.`);
        closeSession(player);
    } finally {
        releaseStarterClaim(player);
    }
}

function grantInventoryItem(player, item) {
    let inventory;
    try { inventory = player.getComponent("minecraft:inventory")?.container; }
    catch (error) { return false; }
    if (!inventory) return false;

    if (item.unique) {
        for (let slot = 0; slot < inventory.size; slot += 1) {
            const existing = inventory.getItem(slot);
            if (existing?.typeId === item.typeId) return true;
        }
    }

    const stack = new ItemStack(item.typeId, item.amount);
    if (item.protected) {
        stack.keepOnDeath = true;
        stack.lockMode = ItemLockMode.inventory;
    }
    if (Number.isInteger(item.preferredSlot)
        && item.preferredSlot >= 0
        && item.preferredSlot < inventory.size
        && !inventory.getItem(item.preferredSlot)) {
        inventory.setItem(item.preferredSlot, stack);
        return true;
    }

    const remainder = inventory.addItem(stack);
    if (!remainder) return true;

    try {
        player.dimension.spawnItem(remainder, player.location);
        return true;
    } catch (error) {
        return false;
    }
}

function grantCoreStarterItems(player) {
    for (const item of CORE_STARTER_ITEMS) grantInventoryItem(player, item);
    return true;
}

const STARTER_SCREEN = "starter";
const STARTER_TITLE = "\u00a7r\u00a70\u00a7r\u00a70";
const STATE_FIRST_SLOT = 37;
const stateTag = index => `|ST:${String(index).padStart(2, "0")}|`;
const BTN_CHOOSE = 0;
const BTN_REGION = 1;
const BTN_PICK = 10;
const BTN_COUNT = BTN_PICK + 27;
const STARTER_LAYOUT = Object.freeze({
    title: STARTER_TITLE,
    n: STATE_FIRST_SLOT + 27,
    tex: [],
    vis: Array.from({ length: 27 }, (_, i) => [STATE_FIRST_SLOT + i, stateTag(i)]),
    txt: [],
    cap: [],
    btn: Array.from({ length: BTN_COUNT }, (_, i) => [i, i])
});
const MENU_FORM_TAG = "lota:menu_form";

function chestMenuEnabled(player) {
    try { return !player.hasTag(MENU_FORM_TAG); }
    catch (error) { return true; }
}

function holdsCompass(player) {
    try {
        const equippable = player.getComponent("minecraft:equippable");
        return equippable?.getEquipment(EquipmentSlot.Mainhand)?.typeId === FIRST_JOIN_COMPASS.typeId;
    } catch (error) {
        return false;
    }
}

function starterChestWants(player) {
    if (!chestMenuEnabled(player) || hasChosenStarter(player)) return false;
    try { if (player.hasTag("lota:battle_player")) return false; }
    catch (error) {}
    return holdsCompass(player);
}

function starterChestView(state) {
    return { title: stateTag(wrapStarterIndex(state.selection)), lines: [], buttons: [] };
}

function newChestState(selection = 1) {
    const pick = wrapStarterIndex(selection);
    const last = new Array(9).fill(1);
    last[Math.floor(pick / STARTERS_PER_REGION)] = pick % STARTERS_PER_REGION;
    return { selection: pick, last };
}

function starterChestPress(player, state, button) {
    if (hasChosenStarter(player)) return "close";
    if (button === BTN_CHOOSE) {
        chooseStarter(player, state, wrapStarterIndex(state.selection));
        return "close";
    }
    if (button >= BTN_REGION && button < BTN_REGION + 9) {
        const region = button - BTN_REGION;
        state.selection = region * STARTERS_PER_REGION + (state.last[region] ?? 1);
    } else if (button >= BTN_PICK && button < BTN_COUNT) {
        state.selection = wrapStarterIndex(button - BTN_PICK);
        state.last[Math.floor(state.selection / STARTERS_PER_REGION)] = state.selection % STARTERS_PER_REGION;
    }
    return "redraw";
}

registerChestScreen({
    key: STARTER_SCREEN,
    layout: STARTER_LAYOUT,
    wants: starterChestWants,
    create: () => newChestState(1),
    view: (player, state) => starterChestView(state),
    press: starterChestPress
});

function openStarterChest(player, options) {
    if (!chestMenuEnabled(player)) return false;
    const wasActive = chestScreenActive(player, STARTER_SCREEN);
    const explicit = options.selection !== undefined;
    const opened = openChestScreen(player, STARTER_SCREEN, {
        hold: explicit ? 1200 : 100,
        state: explicit ? newChestState(options.selection) : undefined
    });
    if (opened && !wasActive) actionBar(player, "Starter screen ready - right-click to open it.");
    return opened;
}

function showStarterSelection(player, session) {
    if (!isPlayer(player) || !player.isValid) return;
    if (hasChosenStarter(player)) {
        closeSession(player);
        return;
    }
    if (session.formOpen) return;

    session.selectedRegionIndex = clampRegionIndex(session.selectedRegionIndex ?? 0);
    session.selectedStarterIndex = wrapPickIndex(session.selectedStarterIndex ?? 1);
    if (!Array.isArray(session.lastStarterIndexByRegion) || session.lastStarterIndexByRegion.length !== REGION_NAMES.length) {
        session.lastStarterIndexByRegion = new Array(REGION_NAMES.length).fill(1);
    }
    session.lastStarterIndexByRegion[session.selectedRegionIndex] = session.selectedStarterIndex;

    const form = new ActionFormData()
        .title(`CBSTARTER_STATE_${session.selectedRegionIndex}_${session.selectedStarterIndex}`)
        .body(STARTER_UI_BODY);

    const actionIds = [];
    REGION_NAMES.forEach((regionName, regionIndex) => {
        const regionId = regionName.toUpperCase();
        form.button(regionId);
        actionIds.push(`CBSTARTER_REGION_${regionId}`);
        for (let localIndex = 0; localIndex < STARTERS_PER_REGION; localIndex += 1) {
            const starter = STARTERS[regionIndex * STARTERS_PER_REGION + localIndex];
            form.button(
                `CBSTARTER_PICK_${regionId}_${localIndex}`,
                `textures/ui/cobble_starter/icons/${starter.dexId}`
            );
            actionIds.push(`CBSTARTER_PICK_${regionId}_${localIndex}`);
        }
    });
    form.button("CBSTARTER_PREVIOUS");
    form.button("CBSTARTER_NEXT");
    form.button("CBSTARTER_CHOOSE", "textures/ui/cobble_starter/starterselection_button");
    form.button("CBSTARTER_EXIT", "textures/ui/cobble_starter/starterselection_exit");
    actionIds.push("CBSTARTER_PREVIOUS", "CBSTARTER_NEXT", "CBSTARTER_CHOOSE", "CBSTARTER_EXIT");

    session.formOpen = true;
    sessions.set(player.id, session);

    form.show(player).then(response => {
        session.formOpen = false;
        if (!sessions.has(player.id)) return;
        if (response.canceled) {
            if (retryIfBusy(player, session, response.cancelationReason)) return;
            closeSession(player);
            return;
        }

        session.busyRetries = 0;
        const actionId = actionIds[Math.floor(Number(response.selection))];
        if (!actionId) {
            closeSession(player);
            return;
        }

        let reopen = false;
        const pickMatch = actionId.match(/^CBSTARTER_PICK_([A-Z]+)_(\d)$/);
        const regionMatch = actionId.match(/^CBSTARTER_REGION_([A-Z]+)$/);
        if (pickMatch || regionMatch) {
            const regionIndex = REGION_NAMES.findIndex(
                name => name.toUpperCase() === (pickMatch ? pickMatch[1] : regionMatch[1])
            );
            if (regionIndex >= 0) {
                session.selectedRegionIndex = regionIndex;
                if (pickMatch) {
                    session.selectedStarterIndex = wrapPickIndex(Number(pickMatch[2]));
                    session.lastStarterIndexByRegion[regionIndex] = session.selectedStarterIndex;
                } else {
                    session.selectedStarterIndex = wrapPickIndex(session.lastStarterIndexByRegion[regionIndex] ?? 1);
                }
                reopen = true;
            }
        } else if (actionId === "CBSTARTER_PREVIOUS" || actionId === "CBSTARTER_NEXT") {
            const delta = actionId === "CBSTARTER_PREVIOUS" ? -1 : 1;
            session.selectedStarterIndex = wrapPickIndex(session.selectedStarterIndex + delta);
            session.lastStarterIndexByRegion[session.selectedRegionIndex] = session.selectedStarterIndex;
            reopen = true;
        } else if (actionId === "CBSTARTER_CHOOSE") {
            chooseStarter(
                player,
                session,
                session.selectedRegionIndex * STARTERS_PER_REGION + session.selectedStarterIndex
            );
            reopen = !hasChosenStarter(player);
        } else if (actionId === "CBSTARTER_EXIT") {
            reopen = true;
        }

        if (reopen && !hasChosenStarter(player)) showStarterSelection(player, session);
    }).catch(error => {
        session.formOpen = false;
        if (retryIfBusy(player, session, error)) return;
        console.warn(`Starter selection form failed: ${error}`);
        closeSession(player);
    });
}

export function openStarterSelection(player, options = {}) {
    if (!isPlayer(player) || !player.isValid) return false;
    const force = options.force === true;
    if (hasChosenStarter(player)) return false;

    if (openStarterChest(player, options)) return true;

    const session = sessions.get(player.id) || {
        formOpen: false,
        busyRetries: 0,
        selectedRegionIndex: 0,
        selectedStarterIndex: 1,
        lastStarterIndexByRegion: new Array(REGION_NAMES.length).fill(1)
    };
    session.force = force;
    if (options.selection !== undefined) {
        const selection = wrapStarterIndex(options.selection);
        const regionIndex = clampRegionIndex(Math.floor(selection / STARTERS_PER_REGION));
        const starterIndex = wrapPickIndex(selection % STARTERS_PER_REGION);
        session.selectedRegionIndex = regionIndex;
        session.selectedStarterIndex = starterIndex;
        session.lastStarterIndexByRegion[regionIndex] = starterIndex;
    }
    showStarterSelection(player, session);
    return true;
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== "lota:starter") return;
    const player = event.sourceEntity;
    if (!isPlayer(player)) return;

    if (hasChosenStarter(player)) {
        actionBar(player, "Starter already chosen.");
        return;
    }

    const message = String(event.message || "").trim().toLowerCase();
    const requestedSelection = Number.parseInt(message, 10);
    openStarterSelection(player, {
        force: false,
        selection: Number.isFinite(requestedSelection) ? requestedSelection : 0
    });
});

world.afterEvents.playerSpawn.subscribe(event => {
    if (!event.initialSpawn) return;
    system.runTimeout(() => {
        const player = event.player;
        if (!isPlayer(player) || !player.isValid) return;
        grantInventoryItem(player, FIRST_JOIN_COMPASS);
    }, 1);
});
