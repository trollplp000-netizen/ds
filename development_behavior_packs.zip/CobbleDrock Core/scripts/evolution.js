import { pokemonTimeRangeMatches } from './pokemon_time_ranges.js';
import { calculateMaxHp, calculateStat, speciesData, speciesKey } from "./battle_math.js";
import { MOVE_DATA } from "./move_registry.js";
import { LEVEL_EVOLUTION_DATA } from "./level_evolution_data.js";
import { CONDITIONAL_EVOLUTION_DATA, TRADE_EVOLUTION_ITEM } from "./conditional_evolution_data.js";
import { EVOLUTION_BIOME_TAGS, EVOLUTION_DIMENSION_TAGS } from "./evolution_biome_tags.js";
import { pokemonModelVariant, pokemonVisualAspects } from './pokemon_visual_state.js';

export const EVOLUTION_TRACKING_VERSION = 2;

const GENERATION_ONE_LEVEL_EVOLUTIONS = Object.freeze({
    abra: [{ id: "abra_kadabra", result: "kadabra", minLevel: 16, learnableMoves: ["kinesis", "confusion"] }],
    bellsprout: [{ id: "bellsprout_weepinbell", result: "weepinbell", minLevel: 21 }],
    bulbasaur: [{ id: "bulbasaur_ivysaur", result: "ivysaur", minLevel: 16 }],
    caterpie: [{ id: "caterpie_metapod", result: "metapod", minLevel: 7, learnableMoves: ["harden"] }],
    charmander: [{ id: "charmander_charmeleon", result: "charmeleon", minLevel: 16 }],
    charmeleon: [{ id: "charmeleon_charizard", result: "charizard", minLevel: 36, learnableMoves: ["wingattack", "airslash"] }],
    cubone: [{ id: "cubone_marowak", result: "marowak", minLevel: 28 }],
    diglett: [{ id: "diglett_dugtrio", result: "dugtrio", minLevel: 26, learnableMoves: ["sandtomb"] }],
    doduo: [{ id: "doduo_dodrio", result: "dodrio", minLevel: 31, learnableMoves: ["triattack"] }],
    dragonair: [{ id: "dragonair_dragonite", result: "dragonite", minLevel: 55, learnableMoves: ["wingattack", "hurricane"] }],
    dratini: [{ id: "dratini_dragonair", result: "dragonair", minLevel: 30 }],
    drowzee: [{ id: "drowzee_hypno", result: "hypno", minLevel: 26 }],
    ekans: [{ id: "ekans_arbok", result: "arbok", minLevel: 22, learnableMoves: ["crunch"] }],
    gastly: [{ id: "gastly_haunter", result: "haunter", minLevel: 25, learnableMoves: ["shadowpunch"] }],
    geodude: [{ id: "geodude_graveler", result: "graveler", minLevel: 25 }],
    goldeen: [{ id: "goldeen_seaking", result: "seaking", minLevel: 33 }],
    grimer: [{ id: "grimer_muk", result: "muk", minLevel: 38, learnableMoves: ["venomdrench"] }],
    horsea: [{ id: "horsea_seadra", result: "seadra", minLevel: 32 }],
    ivysaur: [{ id: "ivysaur_venusaur", result: "venusaur", minLevel: 32, learnableMoves: ["petaldance", "petalblizzard"] }],
    kabuto: [{ id: "kabuto_kabutops", result: "kabutops", minLevel: 40, learnableMoves: ["slash"] }],
    kakuna: [{ id: "kakuna_beedrill", result: "beedrill", minLevel: 10, learnableMoves: ["twineedle", "furyattack"] }],
    koffing: [{ id: "koffing_weezing", result: "weezing", minLevel: 35, learnableMoves: ["doublehit"] }],
    krabby: [{ id: "krabby_kingler", result: "kingler", minLevel: 28 }],
    machop: [{ id: "machop_machoke", result: "machoke", minLevel: 28 }],
    magikarp: [{ id: "magikarp_gyarados", result: "gyarados", minLevel: 20, learnableMoves: ["bite"] }],
    magnemite: [{ id: "magnemite_magneton", result: "magneton", minLevel: 30, learnableMoves: ["triattack"] }],
    mankey: [{ id: "mankey_primeape", result: "primeape", minLevel: 28, learnableMoves: ["rage"] }],
    meowth: [{ id: "meowth_persian", result: "persian", minLevel: 28, learnableMoves: ["swift", "powergem"] }],
    metapod: [{ id: "metapod_butterfree", result: "butterfree", minLevel: 10, learnableMoves: ["gust"] }],
    nidoranf: [{ id: "nidoranf_nidorina", result: "nidorina", minLevel: 16 }],
    nidoranm: [{ id: "nidoranm_nidorino", result: "nidorino", minLevel: 16 }],
    oddish: [{ id: "oddish_gloom", result: "gloom", minLevel: 21 }],
    omanyte: [{ id: "omanyte_omastar", result: "omastar", minLevel: 40, learnableMoves: ["spikecannon", "crunch"] }],
    paras: [{ id: "paras_parasect", result: "parasect", minLevel: 24 }],
    pidgeotto: [{ id: "pidgeotto_pidgeot", result: "pidgeot", minLevel: 36 }],
    pidgey: [{ id: "pidgey_pidgeotto", result: "pidgeotto", minLevel: 18 }],
    poliwag: [{ id: "poliwag_poliwhirl", result: "poliwhirl", minLevel: 25 }],
    ponyta: [{ id: "ponyta_rapidash", result: "rapidash", minLevel: 40, learnableMoves: ["furyattack", "smartstrike"] }],
    psyduck: [{ id: "psyduck_golduck", result: "golduck", minLevel: 33 }],
    rattata: [{ id: "rattata_raticate", result: "raticate", minLevel: 20, learnableMoves: ["scaryface"] }],
    rhyhorn: [{ id: "rhyhorn_rhydon", result: "rhydon", minLevel: 42, learnableMoves: ["hammerarm"] }],
    sandshrew: [{ id: "sandshrew_sandslash", result: "sandslash", minLevel: 22, learnableMoves: ["crushclaw"] }],
    seel: [{ id: "seel_dewgong", result: "dewgong", minLevel: 34, learnableMoves: ["sheercold"] }],
    slowpoke: [{ id: "slowpoke_slowbro", result: "slowbro", minLevel: 37, learnableMoves: ["withdraw"] }],
    spearow: [{ id: "spearow_fearow", result: "fearow", minLevel: 20 }],
    squirtle: [{ id: "squirtle_wartortle", result: "wartortle", minLevel: 16 }],
    tentacool: [{ id: "tentacool_tentacruel", result: "tentacruel", minLevel: 30 }],
    venonat: [{ id: "venonat_venomoth", result: "venomoth", minLevel: 31, learnableMoves: ["gust", "airslash"] }],
    voltorb: [{ id: "voltorb_electrode", result: "electrode", minLevel: 30 }],
    wartortle: [{ id: "wartortle_blastoise", result: "blastoise", minLevel: 36, learnableMoves: ["flashcannon"] }],
    weedle: [{ id: "weedle_kakuna", result: "kakuna", minLevel: 7, learnableMoves: ["harden"] }],
    zubat: [{ id: "zubat_golbat", result: "golbat", minLevel: 22 }]
});

const LEVEL_EVOLUTIONS = Object.freeze({
    ...GENERATION_ONE_LEVEL_EVOLUTIONS,
    ...LEVEL_EVOLUTION_DATA
});


function normalizedMoveId(move) {
    return String(move?.id || move || "")
        .replace(/^cobblemon:/, "")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "");
}

function learnedMoves(pokemon) {
    return [...(pokemon.moves || []), ...(pokemon.benchedMoves || [])]
        .map(normalizedMoveId)
        .filter(Boolean);
}

function copyEvolution(evolution) {
    return {
        id: evolution.id,
        result: evolution.result,
        resultForm: evolution.resultForm || "normal",
        consumeHeldItem: evolution.consumeHeldItem === true,
        learnableMoves: [...(evolution.learnableMoves || [])]
    };
}

function evolutionRules(pokemon) {
    const key = speciesKey(pokemon);
    const pureLevel = (LEVEL_EVOLUTIONS[key] || []).map(evolution => ({
        ...evolution,
        variant: "level_up",
        consumeHeldItem: false,
        requirements: [{ variant: "level", minLevel: evolution.minLevel }]
    }));
    return [...pureLevel, ...(CONDITIONAL_EVOLUTION_DATA[key] || [])];
}

function cleanItemId(value) {
    return String(value || "").replace(/^cobblemon:/, "").replace(/^lota:/, "").toLowerCase();
}

function cleanBiomeId(value) {
    return String(value || "").replace(/^minecraft:/, "").toLowerCase();
}

let evolutionContextProvider = () => ({});

export function setEvolutionContextProvider(provider) {
    evolutionContextProvider = typeof provider === "function" ? provider : () => ({});
}

function lazyContextValue(value) {
    if (typeof value !== "function") return () => value;
    let resolved = false;
    let cached;
    return () => {
        if (!resolved) {
            resolved = true;
            try { cached = value(); } catch (error) { cached = undefined; }
        }
        return cached;
    };
}

function resolvedContext(pokemon, supplied = undefined) {
    const provided = supplied || evolutionContextProvider(pokemon) || {};
    const player = provided?.dimension && provided?.location ? provided : provided?.player;
    let biomeId = cleanBiomeId(provided?.biomeId);
    let dimensionId = String(provided?.dimensionId || player?.dimension?.id || "").toLowerCase();
    if (!biomeId && player) {
        try { biomeId = cleanBiomeId(player.dimension.getBiome(player.location)?.id); } catch (error) {}
    }
    const rawMoonPhase = Number(provided?.moonPhase);
    return {
        player,
        biomeId,
        dimensionId,
        time: Number.isFinite(Number(provided?.time)) ? Number(provided.time) : 0,
        party: Array.isArray(provided?.party) ? provided.party : [],
        isRaining: provided?.isRaining === true,
        moonPhase: Number.isFinite(rawMoonPhase) ? Math.max(0, Math.min(7, Math.floor(rawMoonPhase))) : undefined,
        structureTags: lazyContextValue(provided?.structureTags)
    };
}

export const MOON_PHASES = Object.freeze([
    "FULL_MOON",
    "WANING_GIBBOUS",
    "THIRD_QUARTER",
    "WANING_CRESCENT",
    "NEW_MOON",
    "WAXING_CRESCENT",
    "FIRST_QUARTER",
    "WAXING_GIBBOUS"
]);

function moonPhaseMet(context, expected) {
    if (context.moonPhase === undefined) return false;
    const actual = MOON_PHASES[context.moonPhase];
    return !!actual && actual === String(expected || "").toUpperCase();
}

function structureRequirementMet(context, tag) {
    const wanted = String(tag || "").toLowerCase();
    if (!wanted) return false;
    const tags = context.structureTags?.();
    if (!Array.isArray(tags)) return false;
    return tags.some(entry => String(entry || "").toLowerCase() === wanted);
}

export function pokemonFeatureValue(pokemon, feature) {
    const key = String(feature || "");
    if (!key) return undefined;
    for (const source of [pokemon?.features, pokemon?.evolutionProperties, pokemon]) {
        const value = source?.[key];
        if (value === undefined || value === null || value === "") continue;
        const numeric = Number(value);
        if (Number.isFinite(numeric)) return numeric;
    }
    return undefined;
}

function propertyRangeMet(pokemon, requirement) {
    const value = pokemonFeatureValue(pokemon, requirement?.feature);
    if (value === undefined) return false;
    const match = String(requirement?.range || "").match(/^(-?\d+)\s*-\s*(-?\d+)$/);
    if (!match) return false;
    const low = Math.min(Number(match[1]), Number(match[2]));
    const high = Math.max(Number(match[1]), Number(match[2]));
    return value >= low && value <= high;
}

export function defeatProgressTarget(pokemon) {
    const species = speciesKey(pokemon);
    if (!species) return "";
    const item = cleanItemId(pokemon?.heldItem);
    return item ? `${species} held_item=${item}` : species;
}

function defeatRequirementMet(pokemon, requirement) {
    const wanted = normalizeDefeatTarget(requirement?.target);
    if (!wanted) return false;
    const progress = pokemon?.evolutionProgress?.defeat;
    if (!progress || typeof progress !== "object") return false;
    const amount = Number(requirement?.amount);
    const needed = Number.isFinite(amount) ? amount : 1;
    return Object.entries(progress).some(([target, count]) =>
        normalizeDefeatTarget(target) === wanted && Number(count) >= needed);
}

function normalizeDefeatTarget(value) {
    return String(value || "")
        .replace(/cobblemon:|lota:/g, "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();
}

const ADVANCEMENT_REQUIREMENTS = new Map();

export function registerAdvancementRequirement(id, predicate) {
    const key = String(id || "").toLowerCase();
    if (!key) return false;
    if (typeof predicate === "function") ADVANCEMENT_REQUIREMENTS.set(key, predicate);
    else ADVANCEMENT_REQUIREMENTS.delete(key);
    return true;
}

function advancementRequirementMet(pokemon, requirement, context) {
    const predicate = ADVANCEMENT_REQUIREMENTS.get(String(requirement?.requiredAdvancement || "").toLowerCase());
    if (!predicate) return false;
    try { return predicate(pokemon, context.player, context) === true; } catch (error) { return false; }
}

const HAND_RESOLVED_BIOME_TAGS = Object.freeze({
    "#cobblemon:evolution/regional/cubone_alolabiome": ["beach", "cold_beach", "snowy_beach", "stone_beach", "basalt_deltas"],
    "#cobblemon:evolution/regional/cubone_kantobiome": ["desert", "desert_hills", "badlands", "wooded_badlands", "eroded_badlands", "savanna", "savanna_plateau"],
    "#cobblemon:evolution/regional/exeggcute_alolabiome": ["beach", "jungle", "jungle_hills", "bamboo_jungle"],
    "#cobblemon:evolution/regional/koffing_galarbiome": ["mushroom_fields", "mushroom_field_shore", "mushroom_island"],
    "#cobblemon:evolution/regional/pikachu_alolabiome": ["beach", "jungle", "jungle_hills", "bamboo_jungle"],
    "#cobblemon:evolution/regional/pikachu_kantobiome": ["forest", "birch_forest", "flower_forest", "dark_forest"],
    "#cobblemon:evolution/regional/quilava_hisuibiome": ["taiga", "old_growth_pine_taiga", "old_growth_spruce_taiga", "snowy_taiga", "crimson_forest", "warped_forest"]
});

const REGIONAL_BIOME_TAGS = Object.freeze(Object.fromEntries(
    Object.entries({ ...EVOLUTION_BIOME_TAGS, ...HAND_RESOLVED_BIOME_TAGS })
        .map(([tag, biomes]) => [tag, new Set(biomes)])
));

const DIMENSION_BIOME_TAGS = new Set([
    "#minecraft:is_nether",
    "#minecraft:is_end",
    "#cobblemon:is_overworld"
]);

function dimensionRequirementMet(context, tag) {
    if (tag === "#minecraft:is_nether") return context.dimensionId.includes("nether");
    if (tag === "#minecraft:is_end") return context.dimensionId.includes("the_end");
    if (tag === "#cobblemon:is_overworld") return context.dimensionId.includes("overworld");
    return false;
}

function biomeRequirementMet(context, tag) {
    const normalizedTag = String(tag || "").toLowerCase();
    if (DIMENSION_BIOME_TAGS.has(normalizedTag)) return dimensionRequirementMet(context, normalizedTag);
    if (!normalizedTag.startsWith("#")) return cleanItemId(normalizedTag) === context.biomeId;
    const dimension = EVOLUTION_DIMENSION_TAGS[normalizedTag];
    if (dimension && dimensionRequirementMet(context, dimension)) return true;
    return REGIONAL_BIOME_TAGS[normalizedTag]?.has(context.biomeId) === true;
}

function timeRangeMet(time, range) {
    return pokemonTimeRangeMatches(time, range);
}

function deterministicWurmpleCocoon(pokemon) {
    pokemon.evolutionProperties ??= {};
    const stored = String(pokemon.evolutionProperties.cocoon_species || "").toLowerCase();
    if (stored === "silcoon" || stored === "cascoon") return stored;
    let hash = 0;
    for (const character of String(pokemon.uuid || pokemon.species || "wurmple")) {
        hash = ((hash * 31) + character.codePointAt(0)) | 0;
    }
    const result = (Math.abs(hash) % 2) === 0 ? "silcoon" : "cascoon";
    pokemon.evolutionProperties.cocoon_species = result;
    return result;
}

function propertyRequirementMet(pokemon, target) {
    const match = String(target || "").match(/\b([a-z0-9_]+)=([a-z0-9_]+)\b/i);
    if (!match) return false;
    const key = match[1].toLowerCase();
    const expected = match[2].toLowerCase();
    const actual = key === "cocoon_species"
        ? deterministicWurmpleCocoon(pokemon)
        : String(pokemon.evolutionProperties?.[key] || pokemon[key] || "").toLowerCase();
    return actual === expected;
}

export function evolutionRequirementsMet(pokemon, evolution, suppliedContext = undefined) {
    if (!pokemon || !evolution) return false;
    const sourceForm = pokemonModelVariant(pokemon)?.aspects.filter(aspect => !['female', 'male'].includes(aspect)) || [];
    const requiredForm = evolution.sourceAspects || [];
    if (sourceForm.length !== requiredForm.length || requiredForm.some(aspect => !pokemonVisualAspects(pokemon).has(aspect))) return false;
    const context = resolvedContext(pokemon, suppliedContext);
    for (const requirement of evolution.requirements || []) {
        const variant = String(requirement?.variant || "").toLowerCase();
        if (variant === "level" && Number(pokemon.level) < Number(requirement.minLevel)) return false;
        if (["blocks_traveled", "battle_critical_hits", "recoil", "damage_taken", "use_move"].includes(variant)) {
            const progress = pokemon.evolutionProgress || {};
            const key = requirement.key || (variant === "use_move" ? requirement.move : undefined);
            const current = key && progress[variant] && typeof progress[variant] === "object"
                ? Number(progress[variant][key]) || 0
                : Number(progress[variant]) || 0;
            if (current < Number(requirement.amount || requirement.count || 1)) return false;
        }
        if (variant === "friendship" && Number(pokemon.friendship) < Number(requirement.amount)) return false;
        if (variant === "time_range" && !timeRangeMet(context.time, requirement.range)) return false;
        if (variant === "held_item" && cleanItemId(pokemon.heldItem) !== cleanItemId(requirement.itemCondition)) return false;
        if (variant === "has_move" && !learnedMoves(pokemon).includes(normalizedMoveId(requirement.move))) return false;
        if (variant === "has_move_type" && !learnedMoves(pokemon)
            .some(move => String(MOVE_DATA[move]?.type || "").toLowerCase() === String(requirement.type || "").toLowerCase())) return false;
        if (variant === "party_member") {
            const contains = context.party.some(member => speciesKey(member) === cleanItemId(requirement.target));
            if (contains !== (requirement.contains !== false)) return false;
        }
        if (variant === "weather" && context.isRaining !== (requirement.isRaining === true)) return false;
        if (variant === "stat_compare" && calculateStat(pokemon, requirement.highStat) <= calculateStat(pokemon, requirement.lowStat)) return false;
        if (variant === "stat_equal" && calculateStat(pokemon, requirement.statOne) !== calculateStat(pokemon, requirement.statTwo)) return false;
        if (variant === "properties" && !propertyRequirementMet(pokemon, requirement.target)) return false;
        if (variant === "biome") {
            if (requirement.biomeCondition && !biomeRequirementMet(context, requirement.biomeCondition)) return false;
            if (requirement.biomeAnticondition && biomeRequirementMet(context, requirement.biomeAnticondition)) return false;
        }
        if (variant === "structure") {
            if (requirement.structureCondition && !structureRequirementMet(context, requirement.structureCondition)) return false;
            if (requirement.structureAnticondition && structureRequirementMet(context, requirement.structureAnticondition)) return false;
        }
        if (variant === "moon_phase" && !moonPhaseMet(context, requirement.moonPhase)) return false;
        if (variant === "property_range" && !propertyRangeMet(pokemon, requirement)) return false;
        if (variant === "defeat" && !defeatRequirementMet(pokemon, requirement)) return false;
        if (variant === "advancement" && !advancementRequirementMet(pokemon, requirement, context)) return false;
        if (!["level", "blocks_traveled", "battle_critical_hits", "recoil", "damage_taken", "use_move", "friendship", "time_range", "held_item", "has_move", "has_move_type", "party_member", "weather", "stat_compare", "stat_equal", "properties", "biome", "structure", "moon_phase", "property_range", "defeat", "advancement"].includes(variant)) return false;
    }
    return true;
}

function queueEvolution(pokemon, evolution) {
    const pending = Array.isArray(pokemon.pendingEvolutions) ? pokemon.pendingEvolutions : [];
    if (pending.some(entry => entry?.id === evolution.id)) return null;
    const stored = copyEvolution(evolution);
    pending.push(stored);
    pokemon.pendingEvolutions = pending;
    return stored;
}

export function queueLevelUpEvolutions(pokemon, oldLevel, newLevel, suppliedContext = undefined) {
    if (!pokemon || Number(newLevel) <= Number(oldLevel)) return [];
    pokemon.evolutionTrackingVersion = EVOLUTION_TRACKING_VERSION;
    const queued = [];

    for (const evolution of evolutionRules(pokemon)) {
        if (evolution.variant !== "level_up" || !evolutionRequirementsMet(pokemon, evolution, suppliedContext)) continue;
        const stored = queueEvolution(pokemon, evolution);
        if (stored) queued.push(stored);
    }
    return queued;
}

export function initializeEvolutionTracking(pokemon, suppliedContext = undefined) {
    if (!pokemon || Number(pokemon.evolutionTrackingVersion) >= EVOLUTION_TRACKING_VERSION) return false;
    pokemon.evolutionTrackingVersion = EVOLUTION_TRACKING_VERSION;
    pokemon.pendingEvolutions = Array.isArray(pokemon.pendingEvolutions) ? pokemon.pendingEvolutions : [];

    for (const evolution of evolutionRules(pokemon)) {
        if (evolution.variant !== "level_up" || !evolutionRequirementsMet(pokemon, evolution, suppliedContext)) continue;
        queueEvolution(pokemon, evolution);
    }
    return true;
}

export function pendingEvolutions(pokemon) {
    if (!pokemon) return [];
    initializeEvolutionTracking(pokemon);
    const validIds = new Set(evolutionRules(pokemon).map(evolution => evolution.id));
    const pending = (Array.isArray(pokemon.pendingEvolutions) ? pokemon.pendingEvolutions : [])
        .filter(evolution => evolution && validIds.has(evolution.id) && speciesData(evolution.result));
    pokemon.pendingEvolutions = pending;
    return pending;
}

export function itemEvolutionOptions(pokemon, itemTypeId, suppliedContext = undefined) {
    if (!pokemon) return [];
    const item = cleanItemId(itemTypeId);
    return evolutionRules(pokemon).filter(evolution => {
        const matchingInteraction = evolution.variant === "item_interact" && cleanItemId(evolution.requiredContext) === item;
        const matchingTrade = evolution.variant === "trade" && item === TRADE_EVOLUTION_ITEM;
        return (matchingInteraction || matchingTrade) && evolutionRequirementsMet(pokemon, evolution, suppliedContext);
    });
}

export function queueItemEvolution(pokemon, evolutionId, itemTypeId, suppliedContext = undefined) {
    const evolution = itemEvolutionOptions(pokemon, itemTypeId, suppliedContext)
        .find(option => option.id === evolutionId);
    if (!evolution) return null;
    pokemon.evolutionTrackingVersion = EVOLUTION_TRACKING_VERSION;
    return queueEvolution(pokemon, evolution);
}

export function queueHeldItemEvolutions(pokemon, suppliedContext = undefined) {
    if (!pokemon) return [];
    const heldItem = cleanItemId(pokemon.heldItem);
    if (!heldItem) return [];
    pokemon.evolutionTrackingVersion = EVOLUTION_TRACKING_VERSION;
    const queued = [];
    for (const evolution of evolutionRules(pokemon)) {
        if (evolution.variant !== "item_interact") continue;
        if (cleanItemId(evolution.requiredContext) !== heldItem) continue;
        if (!evolutionRequirementsMet(pokemon, evolution, suppliedContext)) continue;
        const stored = queueEvolution(pokemon, { ...evolution, consumeHeldItem: true });
        if (stored) queued.push(stored);
    }
    return queued;
}

function addEvolutionMoves(pokemon, moveIds) {
    const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
    const known = new Set(moves.map(normalizedMoveId));
    const benched = Array.isArray(pokemon.benchedMoves) ? pokemon.benchedMoves.map(normalizedMoveId).filter(Boolean) : [];

    for (const rawId of moveIds || []) {
        const id = normalizedMoveId(rawId);
        const data = MOVE_DATA[id];
        if (!id || !data || known.has(id) || benched.includes(id)) continue;
        if (moves.length < 4) {
            moves.push({ id, pp: data.pp, maxPp: data.pp });
            known.add(id);
        } else {
            benched.push(id);
        }
    }

    pokemon.moves = moves;
    pokemon.benchedMoves = [...new Set(benched)];
}

export function evolvePokemon(pokemon, evolutionId) {
    if (!pokemon) return null;
    const evolution = pendingEvolutions(pokemon).find(entry => entry.id === evolutionId);
    if (!evolution) return null;

    const oldSpecies = speciesKey(pokemon);
    const oldName = pokemon.nickname || speciesData(oldSpecies)?.name || oldSpecies;
    const oldMaxHp = Math.max(1, Math.floor(Number(pokemon.maxHp) || calculateMaxHp(pokemon)));
    const oldCurrentHp = Math.max(0, Math.min(oldMaxHp, Math.floor(Number(pokemon.currentHp) || 0)));
    const hpRatio = oldCurrentHp / oldMaxHp;

    pokemon.species = `lota:${evolution.result}`;
    pokemon.form = evolution.resultForm || "normal";
    const genderAspects = (pokemon.aspects || []).filter(aspect => ['male', 'female', 'genderless', 'shiny'].includes(aspect));
    pokemon.aspects = genderAspects;
    delete pokemon.spawnProperties;
    pokemon.aspects = [...pokemonVisualAspects(pokemon)];
    const evolvedAbilities = (pokemonModelVariant(pokemon)?.data || speciesData(evolution.result))?.abilities || [];
    const ordinaryEvolvedAbilities = evolvedAbilities.filter(ability => !String(ability).startsWith("h:"));
    const evolvedAbilityIds = evolvedAbilities.map(ability => String(ability).replace(/^h:/, ""));
    if (!evolvedAbilityIds.includes(String(pokemon.ability || ""))) {
        pokemon.ability = String(ordinaryEvolvedAbilities[0] || evolvedAbilities[0] || pokemon.ability || "none").replace(/^h:/, "");
    }
    pokemon.nickname = speciesData(evolution.result)?.name || evolution.result;
    const consumedHeldItem = evolution.consumeHeldItem ? pokemon.heldItem : undefined;
    if (evolution.consumeHeldItem) {
        delete pokemon.heldItem;
        delete pokemon.heldItemData;
    }
    pokemon.pendingEvolutions = [];
    pokemon.evolutionTrackingVersion = EVOLUTION_TRACKING_VERSION;
    addEvolutionMoves(pokemon, evolution.learnableMoves);

    const newMaxHp = calculateMaxHp(pokemon);
    pokemon.maxHp = newMaxHp;
    pokemon.currentHp = Math.max(0, Math.min(newMaxHp, Math.ceil(hpRatio * newMaxHp)));

    return {
        id: evolution.id,
        oldSpecies,
        result: evolution.result,
        oldName,
        newName: pokemon.nickname || speciesData(evolution.result)?.name || evolution.result,
        consumedHeldItem
    };
}
