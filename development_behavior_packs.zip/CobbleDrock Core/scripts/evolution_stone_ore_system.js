import { ItemStack, world } from "@minecraft/server";

const ORE_DROPS = Object.freeze({
    "lota:dawn_stone_ore": "lota:dawn_stone",
    "lota:deepslate_dawn_stone_ore": "lota:dawn_stone",
    "lota:deepslate_dusk_stone_ore": "lota:dusk_stone",
    "lota:deepslate_fire_stone_ore": "lota:fire_stone",
    "lota:deepslate_ice_stone_ore": "lota:ice_stone",
    "lota:deepslate_leaf_stone_ore": "lota:leaf_stone",
    "lota:deepslate_moon_stone_ore": "lota:moon_stone",
    "lota:deepslate_shiny_stone_ore": "lota:shiny_stone",
    "lota:deepslate_sun_stone_ore": "lota:sun_stone",
    "lota:deepslate_thunder_stone_ore": "lota:thunder_stone",
    "lota:deepslate_water_stone_ore": "lota:water_stone",
    "lota:dripstone_moon_stone_ore": "lota:moon_stone",
    "lota:dusk_stone_ore": "lota:dusk_stone",
    "lota:fire_stone_ore": "lota:fire_stone",
    "lota:ice_stone_ore": "lota:ice_stone",
    "lota:leaf_stone_ore": "lota:leaf_stone",
    "lota:moon_stone_ore": "lota:moon_stone",
    "lota:nether_fire_stone_ore": "lota:fire_stone",
    "lota:shiny_stone_ore": "lota:shiny_stone",
    "lota:sun_stone_ore": "lota:sun_stone",
    "lota:terracotta_sun_stone_ore": "lota:sun_stone",
    "lota:thunder_stone_ore": "lota:thunder_stone",
    "lota:water_stone_ore": "lota:water_stone"
});
const CORRECT_PICKAXES = new Set([
    "minecraft:stone_pickaxe",
    "minecraft:iron_pickaxe",
    "minecraft:diamond_pickaxe",
    "minecraft:netherite_pickaxe"
]);

function enchantmentLevel(stack, enchantmentId) {
    if (!stack) return 0;
    try {
        const enchantable = stack.getComponent("minecraft:enchantable");
        return Number(
            enchantable?.getEnchantment(enchantmentId)?.level
            ?? enchantable?.getEnchantment(`minecraft:${enchantmentId}`)?.level
            ?? 0
        );
    } catch (error) {
        return 0;
    }
}

function fortuneOreCount(level) {
    if (level <= 0) return 1;
    return Math.max(0, Math.floor(Math.random() * (level + 2)) - 1) + 1;
}

world.afterEvents.playerBreakBlock.subscribe(event => {
    const oreId = event.brokenBlockPermutation?.type?.id;
    const stoneId = ORE_DROPS[oreId];
    if (!stoneId) return;

    const player = event.player;
    try {
        if (String(player.getGameMode()).toLowerCase().includes("creative")) return;
    } catch (error) {}

    const tool = event.itemStackBeforeBreak;
    if (!tool || !CORRECT_PICKAXES.has(tool.typeId)) return;

    const silkTouch = enchantmentLevel(tool, "silk_touch") > 0;
    const fortune = silkTouch ? 0 : enchantmentLevel(tool, "fortune");
    const dropId = silkTouch ? oreId : stoneId;
    const amount = silkTouch ? 1 : fortuneOreCount(fortune);
    const location = event.block.location;

    try {
        player.dimension.spawnItem(new ItemStack(dropId, amount), {
            x: location.x + 0.5,
            y: location.y + 0.25,
            z: location.z + 0.5
        });
        if (!silkTouch) player.addExperience(1 + Math.floor(Math.random() * 2));
    } catch (error) {
        console.warn(`Evolution-stone ore drop failed for '${oreId}': ${error}`);
    }
});
