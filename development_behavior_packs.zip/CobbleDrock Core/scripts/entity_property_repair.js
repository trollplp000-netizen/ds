import { world } from "@minecraft/server";

const POKEMON_PROPERTY_DEFAULTS = [
    { name: "lota:scale_factor", fallback: () => 0.8 + Math.random() * 0.4 },
    { name: "lota:is_shiny", fallback: () => 0 },
    { name: "lota:skin_index", fallback: () => 0 },
    { name: "lota:ride_flying", fallback: () => false },
    { name: "lota:in_battle", fallback: () => false },
    { name: "lota:ride_sprinting", fallback: () => false },
    { name: "lota:battle_acting", fallback: () => false }
];

const repairedEntities = new Set();
const unrepairableWarned = new Set();
const PROCESSED_CACHE_LIMIT = 8192;

function isPokemonEntity(entity) {
    try {
        return entity?.isValid === true && entity.matches({ families: ["pokemon"] });
    } catch {
        return false;
    }
}

export function attemptPropertyRepair(entity) {
    const missing = [];
    for (const property of POKEMON_PROPERTY_DEFAULTS) {
        try {
            if (entity.getProperty(property.name) === undefined) missing.push(property);
        } catch {
            return { status: "ok", missing: [] };
        }
    }
    if (!missing.length) return { status: "ok", missing: [] };

    let repaired = 0;
    for (const property of missing) {
        let done = false;
        try {
            entity.resetProperty(property.name);
            done = true;
        } catch {
            try {
                entity.setProperty(property.name, property.fallback());
                done = true;
            } catch {
                done = false;
            }
        }
        if (done) repaired++;
    }

    if (repaired === missing.length) return { status: "repaired", missing, repaired };
    return { status: "unrepairable", missing, repaired };
}

function repairEntity(entity) {
    if (!isPokemonEntity(entity)) return;
    if (repairedEntities.has(entity.id)) return;
    repairedEntities.add(entity.id);

    let result;
    try {
        result = attemptPropertyRepair(entity);
    } catch (error) {
        console.warn(`[PropertyRepair] Repair pass failed for ${entity.typeId}: ${error}`);
        return;
    }

    if (result.status === "repaired") {
        console.warn(
            `[PropertyRepair] Initialized ${result.repaired} missing propert${result.repaired === 1 ? "y" : "ies"} on actor ${entity.typeId}.`
        );
        return;
    }

    if (result.status === "unrepairable" && !unrepairableWarned.has(entity.typeId)) {
        unrepairableWarned.add(entity.typeId);
        console.warn(
            `[PropertyRepair] Could not initialize missing properties on actor ${entity.typeId}; the engine rejected in-place repair. Verify the entity definition and actor lifecycle.`
        );
    }
}

world.afterEvents.entityLoad.subscribe(event => {
    if (repairedEntities.size > PROCESSED_CACHE_LIMIT) repairedEntities.clear();
    try {
        repairEntity(event.entity);
    } catch (error) {
        console.warn(`[PropertyRepair] Load repair failed: ${error}`);
    }
});

world.afterEvents.entitySpawn.subscribe(event => {
    try {
        repairEntity(event.entity);
    } catch {
    }
});
