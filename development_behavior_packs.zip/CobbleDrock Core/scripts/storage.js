import { world } from "@minecraft/server";
import { SPECIES_DATA } from "./species_registry.js";
import { MOVE_DATA } from "./move_registry.js";
import { CORE_CONFIG } from "./core_config.js";
import { capturePartyReference } from "./capture_storage.js";
import { applyPokemonVisualState, pokemonGenderRatio, pokemonModelVariant } from "./pokemon_visual_state.js";
import {
    storePokemon as serviceStorePokemon,
    storePokemonInPC as serviceStorePokemonInPC
} from "./storage_service.js";
import { MAX_PARTY_SIZE } from "./storage_consts.js";
import { reconcileSpecialForm } from "./special_forms.js";

export { MAX_PARTY_SIZE };

const partySavedListeners = new Set();
const pokemonStorageSavedListeners = new Set();

export function subscribePartySaved(listener) {
    if (typeof listener !== "function") return () => {};
    partySavedListeners.add(listener);
    return () => partySavedListeners.delete(listener);
}

export function subscribePokemonStorageSaved(listener) {
    if (typeof listener !== "function") return () => {};
    pokemonStorageSavedListeners.add(listener);
    return () => pokemonStorageSavedListeners.delete(listener);
}

function notifyPartySaved(player) {
    for (const listener of partySavedListeners) {
        try { listener(player); } catch (error) {
            console.error(`Party save listener failed: ${error}`);
        }
    }
}

function notifyPokemonStorageSaved(player) {
    for (const listener of pokemonStorageSavedListeners) {
        try { listener(player); } catch (error) {
            console.error(`Pokemon storage save listener failed: ${error}`);
        }
    }
}

export const NATURES = [
    "hardy", "lonely", "brave", "adamant", "naughty",
    "bold", "docile", "relaxed", "impish", "lax",
    "timid", "hasty", "serious", "jolly", "naive",
    "modest", "mild", "quiet", "rash", "bashful",
    "calm", "gentle", "sassy", "careful", "quirky"
];

const FIXED_GENDERS = Object.freeze({
    nidoranf: "FEMALE",
    nidorina: "FEMALE",
    nidoqueen: "FEMALE",
    nidoranm: "MALE",
    nidorino: "MALE",
    nidoking: "MALE"
});

function speciesKey(species) {
    return String(species || "").replace(/^.*:/, "").toLowerCase();
}

function generatedGender(species) {
    const key = speciesKey(species);
    if (FIXED_GENDERS[key]) return FIXED_GENDERS[key];
    const maleRatio = pokemonGenderRatio(key, SPECIES_DATA[key]);
    if (Number.isFinite(maleRatio) && maleRatio < 0) return "GENDERLESS";
    return Math.random() < (Number.isFinite(maleRatio) ? maleRatio : 0.5) ? "MALE" : "FEMALE";
}

export function initialMovesForSpecies(species, level, definition = undefined) {
    const learned = [];
    const seen = new Set();
    const levelMoves = (definition || SPECIES_DATA[speciesKey(species)])?.levelMoves || [];

    for (const entry of levelMoves) {
        const id = String(entry?.id || "").replace(/^cobblemon:/, "").toLowerCase();
        if (Number(entry?.level) > level || !MOVE_DATA[id] || seen.has(id)) continue;
        learned.push(id);
        seen.add(id);
    }

    const selected = learned.slice(-4);
    if (selected.length === 0) selected.push("tackle");
    return selected.map(id => ({
        id,
        pp: MOVE_DATA[id].pp,
        maxPp: MOVE_DATA[id].pp
    }));
}

export function normalizePokemonGender(pokemon) {
    if (!pokemon || typeof pokemon !== "object") return false;
    const key = speciesKey(pokemon.species);
    const ratio = Number(pokemonModelVariant(pokemon)?.data?.maleRatio ?? SPECIES_DATA[key]?.maleRatio);
    const fixedGender = FIXED_GENDERS[key]
        || (Number.isFinite(ratio) && ratio < 0 ? "GENDERLESS" : undefined)
        || (ratio === 1 ? "MALE" : ratio === 0 ? "FEMALE" : undefined);
    if (!fixedGender || pokemon.gender === fixedGender) return false;

    pokemon.gender = fixedGender;
    const aspects = Array.isArray(pokemon.aspects) ? pokemon.aspects : [];
    pokemon.aspects = aspects.filter(aspect => !["male", "female", "genderless"].includes(aspect));
    pokemon.aspects.push(fixedGender.toLowerCase());
    return true;
}

function normalizePokemonList(pokemonList) {
    let changed = false;
    for (const pokemon of pokemonList) {
        if (!pokemon || typeof pokemon !== "object") continue;
        if (normalizePokemonGender(pokemon)) changed = true;
        if (!Number.isInteger(pokemon.currentFullness) || pokemon.currentFullness < 0) {
            pokemon.currentFullness = 0;
            changed = true;
        }
        if (reconcileSpecialForm(pokemon)) changed = true;
    }
    return changed;
}

export function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

export function generateRandomPokemon(species, level = 5) {
    const naturesCount = NATURES.length;
    const nature = NATURES[Math.floor(Math.random() * naturesCount)];
    let data = SPECIES_DATA[speciesKey(species)] || {};
    
    const gender = generatedGender(species);
    data = pokemonModelVariant({ species, gender, form: 'normal' })?.data || data;
    
    const isShiny = Math.random() < (1 / CORE_CONFIG.shinyRate);
    
    const ivs = {
        hp: Math.floor(Math.random() * 32),
        attack: Math.floor(Math.random() * 32),
        defence: Math.floor(Math.random() * 32),
        specialAttack: Math.floor(Math.random() * 32),
        specialDefence: Math.floor(Math.random() * 32),
        speed: Math.floor(Math.random() * 32)
    };
    
    const evs = {
        hp: 0,
        attack: 0,
        defence: 0,
        specialAttack: 0,
        specialDefence: 0,
        speed: 0
    };
    
    const baseHp = Math.max(1, Number(data.baseStats?.hp) || 45);
    const maxHp = Math.floor(((2 * baseHp + ivs.hp + (evs.hp / 4)) * level) / 100) + level + 10;
    
    const formattedSpecies = species.replace("lota:", "");
    const nameFormatted = data.name || (formattedSpecies.charAt(0).toUpperCase() + formattedSpecies.slice(1));
    
    const ordinaryAbilities = Array.isArray(data.abilities)
        ? data.abilities.filter(ability => !String(ability).startsWith("h:"))
        : [];
    const abilityPool = ordinaryAbilities.length
        ? ordinaryAbilities
        : (data.abilities || []).map(ability => String(ability).replace(/^h:/, ""));
    const ability = abilityPool.length
        ? abilityPool[Math.floor(Math.random() * abilityPool.length)]
        : "none";
    
    const aspects = ["normal", gender.toLowerCase()];
    if (isShiny) {
        aspects.push("shiny");
    }
    
    return {
        uuid: generateUUID(),
        species: species,
        form: "normal",
        nickname: nameFormatted,
        level: level,
        experience: 0,
        gender: gender,
        isShiny: isShiny,
        nature: nature,
        mintedNature: nature,
        friendship: Number.isFinite(Number(data.baseFriendship)) ? Number(data.baseFriendship) : 50,
        currentFullness: 0,
        caughtBall: "poke_ball",
        ability: ability,
        aspects: aspects,
        originalTrainer: {
            name: "Unknown",
            uuid: "",
            type: "NPC"
        },
        ivs: ivs,
        hyperTrainedIVs: {
            hp: false,
            attack: false,
            defence: false,
            specialAttack: false,
            specialDefence: false,
            speed: false
        },
        evs: evs,
        maxHp: maxHp,
        currentHp: maxHp,
        statusCondition: "NONE",
        evolutionTrackingVersion: 2,
        pendingEvolutions: [],
        moves: initialMovesForSpecies(species, level, data),
        benchedMoves: []
    };
}

export function savePokemonToEntity(entity, data) {
    try {
        if (entity && entity.isValid) {
            normalizePokemonGender(data);
            reconcileSpecialForm(data);
            entity.setDynamicProperty("lota:pokemon_data", JSON.stringify(data));
            applyPokemonVisualState(entity, data);
            return true;
        }
    } catch (e) {
        console.error(`Error saving Pokemon data to Entity: ${e}`);
    }
    return false;
}

export function loadPokemonFromEntity(entity) {
    try {
        if (entity && entity.isValid) {
            const dataString = entity.getDynamicProperty("lota:pokemon_data");
            if (dataString) {
                const data = JSON.parse(dataString);
                const genderChanged = normalizePokemonGender(data);
                const formChanged = reconcileSpecialForm(data);
                const changed = genderChanged || formChanged;
                if (changed) {
                    entity.setDynamicProperty("lota:pokemon_data", JSON.stringify(data));
                }
                applyPokemonVisualState(entity, data);
                return data;
            }
        }
    } catch (e) {
        console.error(`Error loading Pokemon data from Entity: ${e}`);
    }
    return null;
}

export const PC_BOX_SIZE = 30;
export const PC_BOX_COUNT = CORE_CONFIG.defaultBoxCount;

function emptyPCBox() {
    return Array(PC_BOX_SIZE).fill(null);
}

function validBoxIndex(boxIndex) {
    return Number.isInteger(boxIndex) && boxIndex >= 0 && boxIndex < PC_BOX_COUNT;
}

function readRawPCBox(player, boxIndex) {
    try {
        const dataString = player.getDynamicProperty(`lota:pc_box_${boxIndex}`);
        return dataString ? JSON.parse(dataString) : [];
    } catch (e) {
        console.error(`Error reading raw PC Box ${boxIndex}: ${e}`);
    }
    return [];
}

function normalizePCBox(boxArray) {
    const source = Array.isArray(boxArray) ? boxArray : [];
    const box = emptyPCBox();
    for (let slot = 0; slot < Math.min(source.length, PC_BOX_SIZE); slot++) {
        box[slot] = source[slot] || null;
    }
    return box;
}

function migrateLegacyPCStorage(player) {
    const pokemon = [];
    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const rawBox = readRawPCBox(player, boxIndex);
        if (!Array.isArray(rawBox)) continue;
        for (const entry of rawBox) {
            if (entry) pokemon.push(entry);
        }
    }

    for (let boxIndex = 0; boxIndex < PC_BOX_COUNT; boxIndex++) {
        const start = boxIndex * PC_BOX_SIZE;
        savePCToPlayer(player, boxIndex, pokemon.slice(start, start + PC_BOX_SIZE));
    }
}

export function savePartyToPlayer(player, partyArray) {
    const key = "lota:party_data";
    let previous;
    try {
        normalizePokemonList(partyArray);
        const serialized = JSON.stringify(partyArray);
        if (String(player.getDynamicProperty(key) || "[]") === serialized) return true;
        try {
            previous = player.getDynamicProperty(key);
        } catch (e) {
            previous = undefined;
        }
        player.setDynamicProperty(key, serialized);
        let written;
        try {
            written = player.getDynamicProperty(key);
        } catch (e) {
            written = undefined;
        }
        if (written !== serialized) {
            try {
                if (previous !== undefined) player.setDynamicProperty(key, previous);
            } catch (restoreError) {}
            console.error(`Party write verification failed (expected ${serialized.length} chars).`);
            return false;
        }
        notifyPartySaved(player);
        notifyPokemonStorageSaved(player);
        return true;
    } catch (e) {
        console.error(`Error saving party to player: ${e}`);
        try {
            if (previous !== undefined) player.setDynamicProperty(key, previous);
        } catch (restoreError) {}
    }
    return false;
}

export function loadPartyFromPlayer(player) {
    try {
        const dataString = player.getDynamicProperty("lota:party_data");
        if (dataString) {
            const party = JSON.parse(dataString);
            if (normalizePokemonList(party)) {
                savePartyToPlayer(player, party);
            }
            return party;
        }
    } catch (e) {
        console.error(`Error loading party from player: ${e}`);
    }
    return [];
}

export function addPokemonToPlayerParty(player, pokemonData, currentParty = undefined) {
    try {
        const party = capturePartyReference(currentParty, () => loadPartyFromPlayer(player));
        normalizePokemonList(party);
        pokemonData.originalTrainer = {
            name: player.name,
            uuid: player.id,
            type: "PLAYER"
        };

        const result = serviceStorePokemon(player, pokemonData, party);
        if (!result.success) {
            return { success: false, location: "NONE", reason: result.reason };
        }
        if (result.location === "PARTY") {
            return { success: true, location: "PARTY", slot: result.slot };
        }
        return { success: true, location: "PC_BOX", box: result.box, slot: result.slot };
    } catch (e) {
        console.error(`Error adding Pokemon to player party: ${e}`);
    }
    return { success: false, location: "NONE" };
}

export function addPokemonToPC(player, pokemonData) {
    try {
        normalizePokemonGender(pokemonData);
        const result = serviceStorePokemonInPC(player, pokemonData);
        if (!result.success) {
            return { success: false, box: -1, slot: -1, reason: result.reason };
        }
        return { success: true, box: result.box, slot: result.slot };
    } catch (e) {
        console.error(`Error adding Pokemon to PC: ${e}`);
    }
    return { success: false, box: -1, slot: -1 };
}

export function savePCToPlayer(player, boxIndex, boxArray) {
    const key = `lota:pc_box_${boxIndex}`;
    let previous;
    try {
        if (!validBoxIndex(boxIndex)) return false;
        const box = normalizePCBox(boxArray);
        normalizePokemonList(box);
        const serialized = JSON.stringify(box);
        try {
            previous = player.getDynamicProperty(key);
        } catch (e) {
            previous = undefined;
        }
        player.setDynamicProperty(key, serialized);
        let written;
        try {
            written = player.getDynamicProperty(key);
        } catch (e) {
            written = undefined;
        }
        if (written !== serialized) {
            try {
                if (previous === undefined) {
                    player.setDynamicProperty(key, JSON.stringify(emptyPCBox()));
                } else {
                    player.setDynamicProperty(key, previous);
                }
            } catch (restoreError) {}
            console.error(`PC Box ${boxIndex} write verification failed (expected ${serialized.length} chars).`);
            return false;
        }
        notifyPokemonStorageSaved(player);
        return true;
    } catch (e) {
        console.error(`Error saving PC Box ${boxIndex} to player: ${e}`);
        try {
            if (previous !== undefined) player.setDynamicProperty(key, previous);
        } catch (restoreError) {}
    }
    return false;
}

export function loadPCFromPlayer(player, boxIndex) {
    try {
        if (!validBoxIndex(boxIndex)) return emptyPCBox();
        let rawBox = readRawPCBox(player, boxIndex);
        if (Array.isArray(rawBox) && rawBox.length > PC_BOX_SIZE) {
            migrateLegacyPCStorage(player);
            rawBox = readRawPCBox(player, boxIndex);
        }
        const box = normalizePCBox(rawBox);
        const serialized = JSON.stringify(box);
        const normalized = normalizePokemonList(box);
        if (normalized || String(player.getDynamicProperty(`lota:pc_box_${boxIndex}`) || "") !== serialized) {
            player.setDynamicProperty(`lota:pc_box_${boxIndex}`, normalized ? JSON.stringify(box) : serialized);
        }
        return box;
    } catch (e) {
        console.error(`Error loading PC Box ${boxIndex} from player: ${e}`);
    }
    return emptyPCBox();
}
