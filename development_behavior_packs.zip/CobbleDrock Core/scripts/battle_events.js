import { calculateDamage, pokemonTypes } from "./battle_math.js";
import { moveAccuracy } from "./battle_effects.js";
import { moveData, normalizeMoveId } from "./move_registry.js";

export const BATTLE_EVENT = Object.freeze({
    move: "move",
    miss: "miss",
    fail: "fail",
    immune: "immune",
    protected: "protected",
    hit: "hit",
    hitCount: "hit_count",
    complete: "complete"
});

export function createMoveEventQueue(actor, defender, moveId, options = {}) {
    const id = normalizeMoveId(moveId);
    const move = moveData(id);
    const random = typeof options.random === "function" ? options.random : Math.random;
    const events = [{ type: BATTLE_EVENT.move, moveId: id }];
    const semiInvulnerable = String(options.semiInvulnerable || "");
    const canHitSemiInvulnerable = semiInvulnerable === "dig"
        ? ["earthquake", "magnitude"].includes(id)
        : semiInvulnerable === "dive"
            ? ["surf", "whirlpool"].includes(id)
            : true;
    if (semiInvulnerable && !canHitSemiInvulnerable) {
        events.push({ type: BATTLE_EVENT.miss });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }

    if (Array.isArray(move.flags) && move.flags.includes("powder") && pokemonTypes(defender).includes("grass")) {
        events.push({ type: BATTLE_EVENT.immune });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }
    const protectable = Array.isArray(move.flags) && move.flags.includes("protect");
    const guarded = protectable && (options.protected === true
        || (options.quickGuard === true && Number(move.priority) > 0)
        || (options.wideGuard === true && ["allAdjacent", "allAdjacentFoes"].includes(move.target)));
    if (guarded && move.breaksProtect !== true && move.target !== "self") {
        events.push({ type: BATTLE_EVENT.protected });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }
    const bypassesSubstitute = Array.isArray(move.flags) && move.flags.includes("bypasssub");
    if (options.substitute === true && move.category === "status" && move.target === "normal" && !bypassesSubstitute) {
        events.push({ type: BATTLE_EVENT.fail, reason: "substitute" });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }
    if (move.ignoreImmunity === false && calculateDamage(actor, defender, id, { ...options, random: () => 0, critical: false, randomModifier: 1 }).effectiveness === 0) {
        events.push({ type: BATTLE_EVENT.immune });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }

    if (random() * 100 >= moveAccuracy(actor, defender, move, options)) {
        events.push({ type: BATTLE_EVENT.miss });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result: undefined, events };
    }
    const result = calculateDamage(actor, defender, id, { ...options, random });
    if (result.ohkoFailed || result.failed) {
        events.push({ type: BATTLE_EVENT.fail });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result, events };
    }
    if (result.damage <= 0 && result.effectiveness === 0) {
        events.push({ type: BATTLE_EVENT.immune });
        events.push({ type: BATTLE_EVENT.complete });
        return { id, move, result, events };
    }
    for (const hit of result.hitResults || []) events.push({ type: BATTLE_EVENT.hit, ...hit });
    if ((result.hitResults?.length || 0) > 1) events.push({ type: BATTLE_EVENT.hitCount, hits: result.hitResults.length });
    events.push({ type: BATTLE_EVENT.complete });
    return { id, move, result, events };
}
