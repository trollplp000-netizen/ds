export const POKE_BALL_IDS = Object.freeze([
    "lota:poke_ball",
    "lota:great_ball",
    "lota:ultra_ball",
    "lota:master_ball",
    "lota:safari_ball",
    "lota:level_ball",
    "lota:lure_ball",
    "lota:heavy_ball",
    "lota:love_ball",
    "lota:friend_ball",
    "lota:moon_ball",
    "lota:sport_ball",
    "lota:net_ball",
    "lota:dive_ball",
    "lota:nest_ball",
    "lota:repeat_ball",
    "lota:timer_ball",
    "lota:luxury_ball",
    "lota:premier_ball",
    "lota:dusk_ball",
    "lota:heal_ball",
    "lota:quick_ball",
    "lota:cherish_ball",
    "lota:park_ball",
    "lota:dream_ball",
    "lota:beast_ball",
    "lota:azure_ball",
    "lota:verdant_ball",
    "lota:citrine_ball",
    "lota:roseate_ball",
    "lota:slate_ball",
    "lota:fast_ball",
    "lota:ancient_poke_ball",
    "lota:ancient_citrine_ball",
    "lota:ancient_verdant_ball",
    "lota:ancient_azure_ball",
    "lota:ancient_roseate_ball",
    "lota:ancient_slate_ball",
    "lota:ancient_ivory_ball",
    "lota:ancient_great_ball",
    "lota:ancient_ultra_ball",
    "lota:ancient_heavy_ball",
    "lota:ancient_leaden_ball",
    "lota:ancient_gigaton_ball",
    "lota:ancient_feather_ball",
    "lota:ancient_wing_ball",
    "lota:ancient_jet_ball"
]);

export const POKE_BALL_ID_SET = new Set(POKE_BALL_IDS);

function tooltipKey(itemId) {
    return `item.cobblemon.${String(itemId).replace(/^lota:/, "")}.tooltip`;
}

function containsTranslation(rawMessage, key) {
    if (!rawMessage || typeof rawMessage !== "object") return false;
    if (rawMessage.translate === key) return true;
    return Array.isArray(rawMessage.rawtext)
        && rawMessage.rawtext.some(part => containsTranslation(part, key));
}

function isGrayTooltip(rawMessage, key) {
    if (!containsTranslation(rawMessage, key)) return false;
    return Array.isArray(rawMessage?.rawtext)
        && rawMessage.rawtext.some(part => typeof part?.text === "string" && part.text.includes("§7"));
}

export function pokeBallTooltipLine(itemId) {
    if (!POKE_BALL_ID_SET.has(itemId)) return undefined;
    return {
        rawtext: [
            { text: "§7" },
            { translate: tooltipKey(itemId) }
        ]
    };
}

export function withPokeBallTooltip(itemId, rawLore = []) {
    const line = pokeBallTooltipLine(itemId);
    if (!line) return undefined;

    const key = tooltipKey(itemId);
    const current = Array.isArray(rawLore) ? rawLore : [];
    if (current.length > 0 && isGrayTooltip(current[0], key)) return undefined;

    const preserved = current.filter(existing => !containsTranslation(existing, key));
    return [line, ...preserved].slice(0, 20);
}
