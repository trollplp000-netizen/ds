import { MOVE_DATA } from "./battle_moves.js";
import { SPECIES_DATA } from "./battle_species.js";
import { pokemonModelVariant, pokemonVisualAspects } from "./pokemon_visual_state.js";

const TYPES = Object.freeze([
    "bug", "dark", "dragon", "electric", "fairy", "fighting", "fire", "flying", "ghost",
    "grass", "ground", "ice", "poison", "psychic", "rock", "steel", "water"
]);

export const PLATE_TYPES = Object.freeze({
    flame_plate: "fire", splash_plate: "water", zap_plate: "electric", meadow_plate: "grass",
    icicle_plate: "ice", fist_plate: "fighting", toxic_plate: "poison", earth_plate: "ground",
    sky_plate: "flying", mind_plate: "psychic", insect_plate: "bug", stone_plate: "rock",
    spooky_plate: "ghost", draco_plate: "dragon", dread_plate: "dark", iron_plate: "steel",
    pixie_plate: "fairy"
});

export const MEMORY_TYPES = Object.freeze(Object.fromEntries(TYPES.map(type => [`${type}_memory`, type])));

export const SPECIAL_FORM_HELD_ITEMS = Object.freeze([
    "red_orb", "blue_orb", "griseous_core", "adamant_crystal", "lustrous_globe",
    ...Object.keys(PLATE_TYPES), ...Object.keys(MEMORY_TYPES), "rusted_sword", "rusted_shield"
]);

export const SPECIAL_FORM_USE_ITEMS = Object.freeze(["reveal_glass", "prison_bottle", "dna_splicer"]);

const HELD_FORM_RULES = Object.freeze({
    groudon: { red_orb: "primal" },
    kyogre: { blue_orb: "primal" },
    giratina: { griseous_core: "origin-forme" },
    dialga: { adamant_crystal: "origin-forme" },
    palkia: { lustrous_globe: "origin-forme" },
    arceus: Object.freeze(Object.fromEntries(Object.entries(PLATE_TYPES).map(([item, type]) => [item, `${type}-plate`]))),
    silvally: Object.freeze(Object.fromEntries(Object.entries(MEMORY_TYPES).map(([item, type]) => [item, `${type}-memory`]))),
    zacian: { rusted_sword: "crowned" },
    zamazenta: { rusted_shield: "crowned" }
});

const MANAGED_ASPECTS = Object.freeze({
    groudon: ["primal"], kyogre: ["primal"], giratina: ["origin-forme"], dialga: ["origin-forme"],
    palkia: ["origin-forme"], arceus: TYPES.map(type => `${type}-plate`),
    silvally: TYPES.map(type => `${type}-memory`), zacian: ["crowned"], zamazenta: ["crowned"],
    keldeo: ["resolute-form"]
});

const INTERACTION_RULES = Object.freeze({
    prison_bottle: Object.freeze({ hoopa: "unbound" }),
    reveal_glass: Object.freeze({
        tornadus: "therian-forme", thundurus: "therian-forme", landorus: "therian-forme", enamorus: "therian-forme"
    })
});

function cleanId(value) {
    return String(value || "").replace(/^.*:/, "").toLowerCase();
}

function normalizedMoveId(move) {
    return cleanId(typeof move === "string" ? move : move?.id);
}

function aspectsOf(pokemon) {
    return Array.isArray(pokemon?.aspects) ? pokemon.aspects.map(aspect => String(aspect).toLowerCase()) : [];
}

function setManagedAspect(pokemon, managed, desired) {
    const before = aspectsOf(pokemon);
    const next = before.filter(aspect => !managed.includes(aspect));
    if (desired && !next.includes(desired)) next.push(desired);
    if (before.length === next.length && before.every((value, index) => value === next[index])) return false;
    pokemon.aspects = next;
    return true;
}

function ordinaryAbilities(definition) {
    const abilities = Array.isArray(definition?.abilities) ? definition.abilities.map(String) : [];
    const ordinary = abilities.filter(ability => !ability.startsWith("h:"));
    return ordinary.length ? ordinary : abilities.map(ability => ability.replace(/^h:/, ""));
}

function syncFormAbility(pokemon, desiredAspect) {
    const species = cleanId(pokemon?.species);
    const state = pokemon.specialFormState || {};
    let changed = false;
    if (desiredAspect) {
        if (!state.originalAbility) {
            state.originalAbility = cleanId(pokemon.ability) || ordinaryAbilities(SPECIES_DATA[species])[0] || "none";
            changed = true;
        }
        const definition = pokemonModelVariant(pokemon)?.data;
        const allowed = ordinaryAbilities(definition);
        if (allowed.length && !allowed.includes(cleanId(pokemon.ability))) {
            pokemon.ability = allowed[0];
            changed = true;
        }
        pokemon.specialFormState = state;
    } else if (state.originalAbility) {
        const baseAllowed = ordinaryAbilities(SPECIES_DATA[species]);
        const restored = baseAllowed.includes(cleanId(state.originalAbility)) ? cleanId(state.originalAbility) : baseAllowed[0];
        if (restored && cleanId(pokemon.ability) !== restored) {
            pokemon.ability = restored;
            changed = true;
        }
        delete state.originalAbility;
        if (Object.keys(state).length) pokemon.specialFormState = state;
        else delete pokemon.specialFormState;
        changed = true;
    }
    return changed;
}

function replaceCrownedMove(pokemon, desiredAspect) {
    const species = cleanId(pokemon?.species);
    const crownedMove = species === "zacian" ? "behemothblade" : species === "zamazenta" ? "behemothbash" : "";
    if (!crownedMove) return false;
    const source = desiredAspect ? "ironhead" : crownedMove;
    const target = desiredAspect ? crownedMove : "ironhead";
    let changed = false;
    for (const move of Array.isArray(pokemon.moves) ? pokemon.moves : []) {
        if (normalizedMoveId(move) !== source) continue;
        if (typeof move === "string") continue;
        move.id = target;
        move.pp = Math.min(Number(move.pp) || MOVE_DATA[target]?.pp || 1, MOVE_DATA[target]?.pp || Number(move.pp) || 1);
        move.maxPp = MOVE_DATA[target]?.pp || move.maxPp;
        changed = true;
    }
    if (Array.isArray(pokemon.benchedMoves)) {
        pokemon.benchedMoves = pokemon.benchedMoves.map(move => {
            if (normalizedMoveId(move) !== source) return move;
            changed = true;
            return target;
        });
    }
    return changed;
}

export function desiredHeldFormAspect(pokemon) {
    const species = cleanId(pokemon?.species);
    const held = cleanId(pokemon?.heldItem);
    return HELD_FORM_RULES[species]?.[held] || "";
}

export function reconcileSpecialForm(pokemon) {
    if (!pokemon || typeof pokemon !== "object") return false;
    const species = cleanId(pokemon.species);
    const managed = MANAGED_ASPECTS[species];
    if (!managed) return false;
    let desired = desiredHeldFormAspect(pokemon);
    if (species === "keldeo") {
        desired = (pokemon.moves || []).some(move => normalizedMoveId(move) === "secretsword") ? "resolute-form" : "";
    }
    let changed = setManagedAspect(pokemon, managed, desired);
    if (syncFormAbility(pokemon, desired)) changed = true;
    if (replaceCrownedMove(pokemon, desired)) changed = true;
    return changed;
}

export function specialFormUseAction(pokemon, itemTypeId) {
    const item = cleanId(itemTypeId);
    const species = cleanId(pokemon?.species);
    if (item === "dna_splicer" && species === "kyurem") {
        const fused = aspectsOf(pokemon).some(aspect => ["black-fusion", "white-fusion"].includes(aspect));
        return { item, species, mode: fused ? "unfuse" : "fuse", label: fused ? "Unfuse Kyurem" : "Fuse Kyurem" };
    }
    const aspect = INTERACTION_RULES[item]?.[species];
    if (!aspect) return null;
    const active = aspectsOf(pokemon).includes(aspect);
    return { item, species, aspect, mode: active ? "revert" : "transform", label: active ? `Return ${species} to its ordinary form` : `Change ${species} to ${aspect}` };
}

export function toggleInteractionForm(pokemon, itemTypeId) {
    const action = specialFormUseAction(pokemon, itemTypeId);
    if (!action || action.item === "dna_splicer") return null;
    setManagedAspect(pokemon, [action.aspect], action.mode === "transform" ? action.aspect : "");
    syncFormAbility(pokemon, action.mode === "transform" ? action.aspect : "");
    return action;
}

function restoreMoveSnapshot(pokemon, snapshot) {
    pokemon.moves = (snapshot?.moves || []).map(move => typeof move === "string" ? move : { ...move });
    pokemon.benchedMoves = [...(snapshot?.benchedMoves || [])];
}

function addFusionMove(pokemon, id) {
    if (!MOVE_DATA[id]) return;
    const known = new Set((pokemon.moves || []).map(normalizedMoveId));
    const benched = new Set((pokemon.benchedMoves || []).map(normalizedMoveId));
    if (known.has(id) || benched.has(id)) return;
    if ((pokemon.moves || []).length < 4) pokemon.moves.push({ id, pp: MOVE_DATA[id].pp, maxPp: MOVE_DATA[id].pp });
    else pokemon.benchedMoves = [...(pokemon.benchedMoves || []), id];
}

export function fuseKyurem(kyurem, partner) {
    if (cleanId(kyurem?.species) !== "kyurem") return null;
    const partnerSpecies = cleanId(partner?.species);
    const aspect = partnerSpecies === "zekrom" ? "black-fusion" : partnerSpecies === "reshiram" ? "white-fusion" : "";
    if (!aspect || kyurem.fusionState) return null;
    kyurem.fusionState = {
        partner: JSON.parse(JSON.stringify(partner)),
        originalAbility: kyurem.ability,
        moves: (kyurem.moves || []).map(move => typeof move === "string" ? move : { ...move }),
        benchedMoves: [...(kyurem.benchedMoves || [])]
    };
    setManagedAspect(kyurem, ["black-fusion", "white-fusion"], aspect);
    const variant = pokemonModelVariant(kyurem)?.data;
    kyurem.ability = ordinaryAbilities(variant)[0] || kyurem.ability;
    if (aspect === "black-fusion") {
        addFusionMove(kyurem, "fusionbolt");
        addFusionMove(kyurem, "freezeshock");
    } else {
        addFusionMove(kyurem, "fusionflare");
        addFusionMove(kyurem, "iceburn");
    }
    return { mode: "fuse", aspect, partnerSpecies, partner: kyurem.fusionState.partner };
}

export function unfuseKyurem(kyurem) {
    if (cleanId(kyurem?.species) !== "kyurem" || !kyurem?.fusionState?.partner) return null;
    const state = kyurem.fusionState;
    const partner = JSON.parse(JSON.stringify(state.partner));
    setManagedAspect(kyurem, ["black-fusion", "white-fusion"], "");
    restoreMoveSnapshot(kyurem, state);
    kyurem.ability = state.originalAbility || ordinaryAbilities(SPECIES_DATA.kyurem)[0] || kyurem.ability;
    delete kyurem.fusionState;
    return { mode: "unfuse", partner, partnerSpecies: cleanId(partner.species) };
}

export function specialMoveType(pokemon, moveId, fallbackType) {
    const id = cleanId(moveId);
    const species = cleanId(pokemon?.species);
    if ((id === "judgment" && species === "arceus") || (id === "multiattack" && species === "silvally")) {
        return cleanId(pokemonModelVariant(pokemon)?.data?.types?.[0] || fallbackType || "normal");
    }
    return cleanId(fallbackType);
}

export function specialHeldItemDamageMultiplier(pokemon, moveType) {
    const species = cleanId(pokemon?.species);
    const held = cleanId(pokemon?.heldItem);
    const type = cleanId(moveType);
    if (species === "arceus" && PLATE_TYPES[held] === type) return 1.2;
    if (species === "giratina" && held === "griseous_core" && ["ghost", "dragon"].includes(type)) return 1.2;
    if (species === "dialga" && held === "adamant_crystal" && ["steel", "dragon"].includes(type)) return 1.2;
    if (species === "palkia" && held === "lustrous_globe" && ["water", "dragon"].includes(type)) return 1.2;
    return 1;
}

export function specialFormName(pokemon) {
    return pokemonModelVariant({ ...pokemon, aspects: [...pokemonVisualAspects(pokemon)] })?.name || "Normal";
}
