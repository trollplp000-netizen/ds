import { MolangVariableMap, system } from "@minecraft/server";

export function spawnColoredFlame(dimension, location) {
    try {
        const variables = new MolangVariableMap();
        variables.setColorRGB("variable.color", { red: 1, green: 0.45, blue: 0.1 });
        dimension.spawnParticle("minecraft:colored_flame_particle", location, variables);
        return true;
    } catch (error) {
        return false;
    }
}

export function spawnPokeballSendFlash(dimension, location) {
    try {
        dimension.spawnParticle("cobblemon:pokeball_casual_sendflash", location);
        return true;
    } catch (error) {
        return false;
    }
}

const MS_PER_TICK = 50;

export const EVOLUTION_PARTICLE_ENVELOP_TICKS = 100;

const EVOLUTION_POST_REVEAL_HOLD_TICKS = 40;

const EVOLUTION_LIFT_HEIGHT = 1.4;
const EVOLUTION_LIFT_DURATION_TICKS = 50;
const EVOLUTION_LIFT_START_MS = EVOLUTION_PARTICLE_ENVELOP_TICKS * MS_PER_TICK;
const EVOLUTION_LIFT_END_MS = EVOLUTION_LIFT_START_MS + EVOLUTION_LIFT_DURATION_TICKS * MS_PER_TICK;
const EVOLUTION_REVEAL_DESCEND_TICKS = 12;

function easeOutCubic(fraction) {
    const clamped = Math.min(1, Math.max(0, fraction));
    return 1 - Math.pow(1 - clamped, 3);
}

export function evolutionLiftOffset(elapsedMs) {
    if (elapsedMs <= EVOLUTION_LIFT_START_MS) return 0;
    if (elapsedMs >= EVOLUTION_LIFT_END_MS) return EVOLUTION_LIFT_HEIGHT;
    const fraction = (elapsedMs - EVOLUTION_LIFT_START_MS) / (EVOLUTION_LIFT_END_MS - EVOLUTION_LIFT_START_MS);
    return EVOLUTION_LIFT_HEIGHT * easeOutCubic(fraction);
}

const EVOLUTION_REVEAL_SETTLE_DIP = 0.2;
const EVOLUTION_REVEAL_SETTLE_DOWN_TICKS = 6;
const EVOLUTION_REVEAL_SETTLE_UP_TICKS = 10;

const EVOLUTION_SPIN_DEGREES_PER_SECOND = 720;

export function holdPokemonDuringEvolution(
    entity,
    spinAfterTicks = EVOLUTION_PARTICLE_ENVELOP_TICKS,
    spinDurationTicks = 100,
    player = undefined,
    descendFromLift = false
) {
    if (!entity?.isValid) return () => {};

    try {
        entity.triggerEvent("lota:enter_battle_focus");
    } catch (error) {}

    const dimension = entity.dimension;
    const anchor = { ...entity.location };
    let baseYaw = 0;
    let pitch = 0;
    try {
        const rotation = entity.getRotation();
        baseYaw = rotation.y;
        pitch = rotation.x;
    } catch (error) {}

    const spinAfterMs = Number.isFinite(spinAfterTicks) ? spinAfterTicks * MS_PER_TICK : Infinity;
    const descendMs = descendFromLift ? EVOLUTION_REVEAL_DESCEND_TICKS * MS_PER_TICK : 0;
    const settleDownMs = descendMs + EVOLUTION_REVEAL_SETTLE_DOWN_TICKS * MS_PER_TICK;
    const settleUpEndMs = settleDownMs + EVOLUTION_REVEAL_SETTLE_UP_TICKS * MS_PER_TICK;

    const spinDurationMs = Number.isFinite(spinDurationTicks) ? spinDurationTicks * MS_PER_TICK : null;
    let spinRotations = 1;
    let spinDegreesPerSecond = EVOLUTION_SPIN_DEGREES_PER_SECOND;
    if (spinDurationMs > 0) {
        spinRotations = Math.max(1, Math.round((EVOLUTION_SPIN_DEGREES_PER_SECOND * spinDurationMs) / 1000 / 360));
        spinDegreesPerSecond = (spinRotations * 360) / (spinDurationMs / 1000);
    }

    const start = Date.now();
    const runId = system.runInterval(() => {
        if (!entity.isValid) {
            system.clearRun(runId);
            return;
        }
        const elapsed = Date.now() - start;
        try { entity.clearVelocity(); } catch (error) {}

        let y = anchor.y;
        let yaw = baseYaw;

        if (!Number.isFinite(spinAfterMs) && elapsed < settleUpEndMs) {
            if (descendMs > 0 && elapsed < descendMs) {
                const fraction = elapsed / descendMs;
                y = anchor.y + EVOLUTION_LIFT_HEIGHT * (1 - easeOutCubic(fraction));
            } else if (elapsed < settleDownMs) {
                const fraction = (elapsed - descendMs) / (settleDownMs - descendMs);
                y = anchor.y - EVOLUTION_REVEAL_SETTLE_DIP * fraction;
            } else {
                const fraction = (elapsed - settleDownMs) / (settleUpEndMs - settleDownMs);
                y = anchor.y - EVOLUTION_REVEAL_SETTLE_DIP * (1 - fraction);
            }
        } else if (Number.isFinite(spinAfterMs) && elapsed >= spinAfterMs) {
            y = anchor.y + evolutionLiftOffset(elapsed);
            const rawSpinElapsedMs = elapsed - spinAfterMs;
            const spinElapsedMs = spinDurationMs > 0 ? Math.min(rawSpinElapsedMs, spinDurationMs) : rawSpinElapsedMs;
            yaw = baseYaw + (spinElapsedMs / 1000) * spinDegreesPerSecond;
            yaw = ((yaw % 360) + 360) % 360;
        }

        try {
            entity.teleport({ x: anchor.x, y, z: anchor.z }, { dimension, rotation: { x: pitch, y: yaw } });
        } catch (error) {}
    }, 1);

    return () => {
        try { system.clearRun(runId); } catch (error) {}
    };
}

const EVOLUTION_SCALE_REFERENCE = 2.0;
const EVOLUTION_SCALE_MIN = 0.35;
const EVOLUTION_SCALE_MAX = 3.0;

const EVOLUTION_HEIGHT_OVERRIDES = {
    "lota:onix": 8.8
};

function evolutionEntityBounds(entity) {
    let width = 0.6;
    let height = 1.8;
    let heightMeasured = false;

    try {
        const headHeight = Number(entity.getHeadLocation()?.y) - Number(entity.location?.y);
        if (Number.isFinite(headHeight) && headHeight > 0) {
            height = headHeight;
            heightMeasured = true;
        }
    } catch (error) {}

    if (!heightMeasured) {
        try {
            const collision = entity.getComponent("minecraft:collision_box");
            const collisionHeight = Number(collision?.height);
            if (Number.isFinite(collisionHeight) && collisionHeight > 0) height = collisionHeight;
        } catch (error) {}
    }

    return { width, height };
}

function clampEvolutionScale(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 1;
    return Math.min(EVOLUTION_SCALE_MAX, Math.max(EVOLUTION_SCALE_MIN, number));
}

export function detectPokemonEvolutionScale(entity) {
    return detectPokemonEvolutionMetrics(entity).scale;
}

export function detectPokemonEvolutionMetrics(entity) {
    try {
        if (!entity?.isValid) return { scale: 1, height: EVOLUTION_SCALE_REFERENCE };
        let { height } = evolutionEntityBounds(entity);

        try {
            const override = EVOLUTION_HEIGHT_OVERRIDES[entity.typeId];
            if (Number.isFinite(override) && override > 0) height = override;
        } catch (error) {}

        let individualFactor = 1;
        try {
            const raw = entity.getProperty("lota:scale_factor");
            if (Number.isFinite(raw)) individualFactor = raw;
        } catch (error) {}

        const bodySize = height * individualFactor;
        return {
            scale: clampEvolutionScale(bodySize / EVOLUTION_SCALE_REFERENCE),
            height: bodySize
        };
    } catch (error) {
        return { scale: 1, height: EVOLUTION_SCALE_REFERENCE };
    }
}

const EVOLUTION_ENVELOP_PULSE_EFFECTS = [
    "cobblemon:evo_obscuring_pulse",
    "cobblemon:evo_godrays_small_pulse",
    "cobblemon:evo_godrays_pulse"
];
const EVOLUTION_ENVELOP_PULSE_START_MS = EVOLUTION_PARTICLE_ENVELOP_TICKS * MS_PER_TICK;
const EVOLUTION_ENVELOP_PULSE_END_MS = 9580;
const EVOLUTION_ENVELOP_PULSE_INTERVAL_MS = 250;

const EVOLUTION_STAGE_TIMELINE = [
    ["cobblemon:evo_sparkle", 0],
    ["cobblemon:evo_buildup", 2.00],
    ["cobblemon:evo_flyingsparkles", 6.00],
    ["cobblemon:evo_bigsparkle", 7.00],
    ["cobblemon:evo_implode", 9.58],
    ["cobblemon:evo_smokeburst", 10.00],
    ["cobblemon:evo_sparkleburst", 10.01],
    ["cobblemon:evo_sparklefetti", 10.02]
];

const EVOLUTION_SEQUENCE_DURATION_MS = Math.max(
    EVOLUTION_ENVELOP_PULSE_END_MS,
    ...EVOLUTION_STAGE_TIMELINE.map(([, delaySeconds]) => delaySeconds * 1000)
);

export function runEvolutionSequence(dimension, location, sizeSource, heightHint, trackEntity, player, onSwap) {
    let scale;
    let height;
    if (typeof sizeSource === "number") {
        scale = clampEvolutionScale(sizeSource);
        height = Number.isFinite(Number(heightHint)) ? Number(heightHint) : scale * EVOLUTION_SCALE_REFERENCE;
    } else {
        const metrics = detectPokemonEvolutionMetrics(sizeSource);
        scale = metrics.scale;
        height = metrics.height;
    }
    const variables = new MolangVariableMap();
    variables.setFloat("variable.evo_scale", scale);
    const verticalOffset = Math.max(height, 0.5) / 2;

    const liveEntity = (trackEntity?.isValid) ? trackEntity
        : (sizeSource && typeof sizeSource !== "number" && sizeSource.isValid) ? sizeSource
        : null;

    const anchorLocation = (liveEntity?.isValid) ? liveEntity.location : location;
    const groundSpawnX = anchorLocation.x;
    const groundSpawnY = anchorLocation.y + verticalOffset;
    const groundSpawnZ = anchorLocation.z;

    const spinDurationTicks = Math.max(1, (EVOLUTION_SEQUENCE_DURATION_MS / MS_PER_TICK) - EVOLUTION_PARTICLE_ENVELOP_TICKS);
    const stopHold = liveEntity?.isValid
        ? holdPokemonDuringEvolution(liveEntity, EVOLUTION_PARTICLE_ENVELOP_TICKS, spinDurationTicks, player)
        : () => {};

    const start = Date.now();
    const pending = EVOLUTION_STAGE_TIMELINE.map(([effect, delaySeconds]) => ({
        effect,
        atMs: delaySeconds * 1000,
        fired: false
    }));
    let swapped = false;
    let nextPulseMs = EVOLUTION_ENVELOP_PULSE_START_MS;

    const runId = system.runInterval(() => {
        const elapsed = Date.now() - start;

        if (elapsed >= nextPulseMs && elapsed <= EVOLUTION_ENVELOP_PULSE_END_MS) {
            nextPulseMs += EVOLUTION_ENVELOP_PULSE_INTERVAL_MS;
            const livePoint = (liveEntity?.isValid)
                ? { x: liveEntity.location.x, y: liveEntity.location.y + verticalOffset, z: liveEntity.location.z }
                : { x: groundSpawnX, y: groundSpawnY + evolutionLiftOffset(elapsed), z: groundSpawnZ };
            for (const effect of EVOLUTION_ENVELOP_PULSE_EFFECTS) {
                try { dimension.spawnParticle(effect, livePoint, variables); } catch (error) {}
            }
        }

        let remaining = elapsed < EVOLUTION_ENVELOP_PULSE_END_MS;
        for (const stage of pending) {
            if (stage.fired) continue;
            if (elapsed >= stage.atMs) {
                stage.fired = true;
                const stageSpawnPoint = {
                    x: groundSpawnX,
                    y: groundSpawnY + evolutionLiftOffset(elapsed),
                    z: groundSpawnZ
                };
                try { dimension.spawnParticle(stage.effect, stageSpawnPoint, variables); } catch (error) {}
            } else {
                remaining = true;
            }
        }
        if (!remaining && !swapped) {
            swapped = true;
            system.clearRun(runId);
            stopHold();
            try { onSwap?.(); } catch (error) {}
        }
    }, 1);
}

export function settleRevealedPokemon(entity) {
    if (!entity?.isValid) return;
    const stopReveal = holdPokemonDuringEvolution(entity, Infinity, 100, undefined, true);
    system.runTimeout(
        () => stopReveal(),
        EVOLUTION_REVEAL_DESCEND_TICKS + EVOLUTION_REVEAL_SETTLE_UP_TICKS + EVOLUTION_POST_REVEAL_HOLD_TICKS
    );
}
