import { ScriptEventSource, system, world } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { closeChestScreen, openChestScreen, refreshChestScreen, registerChestScreen } from "./chest_ui.js";
import { executeTrade, requestPartySnapshot } from "./server_content_api.js";
import { pokemonFormTexture, regionalFormTexture } from "./form_ui_textures.js";
import { heldItemIconPath } from "./held_items.js";
import { MOVE_DATA } from "./battle_moves.js";
import { pokedexCaughtDexSet, pokedexPanToken, pokedexPortraitTexture } from "./pokedex_system.js";

const TRADE_COMMAND_EVENTS = new Set(["lota:trade", "lota_server:trade", "lota:open_trade"]);
// Solo mode: opens the trade UI against a simulated "ghost" partner (no 2nd player needed).
// Usage: /scriptevent lota:trade_solo   (or lota:trade_ui)
const TRADE_SOLO_EVENTS = new Set(["lota:trade_solo", "lota:trade_ui"]);
const SOLO_PARTNER_NAME = "Treinador Fantasma";
const MAX_DISTANCE = 12;
const FORM_BUSY_RETRY_LIMIT = 20;
const SESSION_TIMEOUT_TICKS = 6000;
const TRADE_ANIMATION_TICKS = 46;

const TITLE_ROOT = "cobbledrock.trade.select";
const MARK_OWNMON = "#OWNMON";
const MARK_OPPMON = "#OPPMON";
const MARK_T2_OWN = "#T2O";
const MARK_T2_OPP = "#T2P";
const MARK_IACC = "#IACC";
const MARK_OACC = "#OACC";
const MARK_TRADING = "#TRADING";
const MARK_BTN = "#BTN";
const MARK_SLOT_SEL = "|SL";
const MARK_SLOT_LOCK = "|LK";
const MARK_SLOT_MALE = "|M";
const MARK_SLOT_FEMALE = "|F";
const MARK_NEW = "|NW";
// Pane focus (own/opponent party) is now a client-side radio toggle in the JSON UI
// (tr_pane_toggle_*), exactly like the summary tabs: it switches instantly and never
// round-trips through this script, so there is nothing to track here.

const BALL_TEXTURE_ROOT = "textures/item/poke_balls";
const PC_SPRITE_ROOT = "textures/gui/pc/pc_sprite";
const TYPE_ICON_ROOT = "textures/gui/trade/type_icon_";
const SHINY_ICON = "textures/gui/summary/icon_shiny";

const TYPE_NAMES = new Set([
    "normal", "fire", "water", "grass", "electric", "ice", "fighting", "poison",
    "ground", "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark",
    "steel", "fairy"
]);

const STAT_KEYS = ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"];

const IDX_LOCAL = 0;
const IDX_OPP = IDX_LOCAL + 6;
const IDX_OWN_PORTRAIT = IDX_OPP + 6;
const IDX_OPP_PORTRAIT = IDX_OWN_PORTRAIT + 1;
const IDX_TRADE = IDX_OPP_PORTRAIT + 1;
const IDX_EXIT = IDX_TRADE + 1;
const IDX_CARRIER = IDX_EXIT + 1;

const CARRIER_ORDER = ["level", "ball", "name", "gender", "shiny", "held",
                       "type1s", "type1d", "type2", "nature", "ability", "moves",
                       "ivs", "evs"];
const IDX_PLAYER_NAME = IDX_CARRIER + 2 * CARRIER_ORDER.length;
const IDX_TRADER_NAME = IDX_PLAYER_NAME + 1;
const IDX_SLOT_CARRIER = IDX_TRADER_NAME + 1;
const SLOT_CARRIERS_LOCAL = ["gender", "locked", "pointer", "held"];
const SLOT_CARRIERS_OPP = ["gender", "locked", "held"];
const IDX_SLOT_CARRIER_OPP = IDX_SLOT_CARRIER + 6 * SLOT_CARRIERS_LOCAL.length;
const IDX_NEW_PORTRAIT = IDX_SLOT_CARRIER_OPP + 6 * SLOT_CARRIERS_OPP.length;
const IDX_NEW_SLOT = IDX_NEW_PORTRAIT + 1;
const BUTTON_COUNT = IDX_NEW_SLOT + 6;

const busy = new Set();
const activeSessions = new Map();

function distance(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

async function show(form, player, shouldAbort = () => false) {
    let lastBusyError;
    for (let attempt = 0; attempt <= FORM_BUSY_RETRY_LIMIT; attempt++) {
        if (shouldAbort()) return { canceled: true };
        try {
            const response = await form.show(player);
            const reason = String(response?.cancelationReason ?? "").toLowerCase();
            if (!response?.canceled || !reason.includes("busy")) return response;
        } catch (error) {
            if (!String(error ?? "").toLowerCase().includes("busy")) throw error;
            lastBusyError = error;
        }
        await new Promise(resolve => system.runTimeout(resolve, 1));
    }
    throw lastBusyError || new Error("Trade form remained busy after retrying.");
}

function sleep(ticks) {
    return new Promise(resolve => system.runTimeout(resolve, Math.max(1, Math.floor(ticks))));
}

function pokemonSlotTexture(pokemon) {
    const regional = regionalFormTexture(pokemon);
    if (regional) return regional;
    const dex = Math.max(0, Math.min(999, Math.floor(Number(pokemon?.pokedex) || 0)));
    return `textures/gui/pokemon_form_ui/${String(dex).padStart(3, "0")}`;
}

function titleCase(value) {
    return String(value || "-")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

const ABILITY_DISPLAY_NAMES = Object.freeze({ innerfocus: "Inner Focus" });

function abilityName(value) {
    const id = String(value || "").replace(/^.*:/, "").toLowerCase();
    return ABILITY_DISPLAY_NAMES[id] || titleCase(value);
}

function pokemonDex(pokemon) {
    const direct = Math.floor(Number(pokemon?.pokedex));
    if (Number.isInteger(direct) && direct > 0) return direct;
    return 0;
}

function spriteTexture(pokemon) {
    const dex = pokemonDex(pokemon);
    if (dex) return `${PC_SPRITE_ROOT}/${String(dex).padStart(4, "0")}`;
    return pokemonFormTexture(pokemon?.species);
}

function portraitButton(pokemon) {
    if (!pokemon) return { text: " ", texture: undefined };
    const dex = pokemonDex(pokemon);
    if (!dex) return { text: " ", texture: spriteTexture(pokemon) };
    return { text: pokedexPanToken(dex), texture: pokedexPortraitTexture(dex) };
}

function caughtDexSetFor(player) {
    try {
        return pokedexCaughtDexSet(player);
    } catch {
        return null;
    }
}

function newBadgeText(caught, pokemon) {
    const dex = pokemonDex(pokemon);
    return caught && pokemon && dex > 0 && !caught.has(dex) ? MARK_NEW : " ";
}

function ballTexture(pokemon) {
    const ball = String(pokemon?.caughtBall || "").replace(/^.*:/, "").toLowerCase();
    return ball ? `${BALL_TEXTURE_ROOT}/${ball}` : "";
}

function heldItemTexture(pokemon) {
    const id = String(pokemon?.heldItem || "").trim();
    if (!id) return "";
    return heldItemIconPath(id);
}

function knownTypes(pokemon) {
    const types = Array.isArray(pokemon?.types) ? pokemon.types : [];
    return types.map(type => String(type).replace(/^.*:/, "").toLowerCase())
        .filter(type => TYPE_NAMES.has(type));
}

function typeIconTexture(type) {
    return type ? TYPE_ICON_ROOT + type : "";
}

function genderGlyph(pokemon) {
    const gender = String(pokemon?.gender || "").toUpperCase();
    if (gender === "MALE") return "§b\u2642";
    if (gender === "FEMALE") return "§c\u2640";
    return "";
}

function slotText(pokemon, selected) {
    if (!pokemon) return " ";
    let text = `Lv.${Math.max(1, Math.floor(Number(pokemon.level) || 1))}`;
    const gender = String(pokemon.gender || "").toUpperCase();
    if (gender === "MALE") text += MARK_SLOT_MALE;
    else if (gender === "FEMALE") text += MARK_SLOT_FEMALE;
    if (isUntradeable(pokemon)) text += MARK_SLOT_LOCK;
    if (selected) text += MARK_SLOT_SEL;
    return text;
}

function isUntradeable(pokemon) {
    return pokemon?.tradeable === false;
}

function statColumn(pokemon, key) {
    if (!pokemon) return "";
    const raw = key === "ivs" ? (pokemon.ivs || {}) : (pokemon.evs || {});
    const source = Array.isArray(raw)
        ? Object.fromEntries(STAT_KEYS.map((stat, index) => [stat, raw[index]]))
        : raw;
    return STAT_KEYS
        .map(stat => String(Math.max(0, Math.floor(Number(source[stat]) || 0))))
        .join("\n");
}

function moveNames(pokemon) {
    if (!pokemon) return "";
    const moves = Array.isArray(pokemon.moves) ? pokemon.moves.slice(0, 4) : [];
    return moves.map(move => {
        const id = String(typeof move === "string" ? move : move?.id || "")
            .replace(/^.*:/, "").toLowerCase();
        return String(typeof move === "object" && move?.name || MOVE_DATA[id]?.name || titleCase(id));
    }).join("\n");
}

function tradeButtonState(player, partner, ownOffer, oppOffer, state) {
    if (state.trading) return 0;
    const enabled = Boolean(ownOffer && oppOffer);
    if (!enabled) return 0;
    const active = state.ready.has(player.id) && !state.ready.has(partner.id);
    return active ? 2 : 1;
}

function buildTitle(player, partner, ownOffer, oppOffer, state) {
    let title = TITLE_ROOT;
    if (ownOffer) {
        title += MARK_OWNMON;
        if (knownTypes(ownOffer).length > 1) title += MARK_T2_OWN;
    }
    if (oppOffer) {
        title += MARK_OPPMON;
        if (knownTypes(oppOffer).length > 1) title += MARK_T2_OPP;
    }
    if (state.ready.has(player.id)) title += MARK_IACC;
    if (state.ready.has(partner.id)) title += MARK_OACC;
    if (state.trading) title += MARK_TRADING;
    return title + MARK_BTN + String(tradeButtonState(player, partner, ownOffer, oppOffer, state));
}

function infoCarriers(mon) {
    const types = knownTypes(mon);
    const primary = types[0] || "";
    const secondary = types[1] || "";
    const level = mon ? String(Math.max(1, Math.floor(Number(mon.level) || 1))) : "";
    return [
        { text: level, texture: undefined },
        { text: " ", texture: ballTexture(mon) },
        { text: mon ? String(mon.name || "") : "", texture: undefined },
        { text: genderGlyph(mon), texture: undefined },
        { text: " ", texture: mon?.isShiny === true ? SHINY_ICON : undefined },
        { text: " ", texture: heldItemTexture(mon) },
        { text: " ", texture: typeIconTexture(primary) },
        { text: " ", texture: typeIconTexture(primary) },
        { text: " ", texture: typeIconTexture(secondary) },
        { text: mon ? titleCase(mon.nature) : "", texture: undefined },
        { text: mon ? abilityName(mon.ability) : "", texture: undefined },
        { text: moveNames(mon), texture: undefined },
        { text: statColumn(mon, "ivs"), texture: undefined },
        { text: statColumn(mon, "evs"), texture: undefined }
    ];
}

function tradeLabel(player, partner, ownOffer, oppOffer, state) {
    if (tradeButtonState(player, partner, ownOffer, oppOffer, state) === 2) return "…";
    return "cobblemon.ui.trade";
}

function buildTradeButtons(player, partner, party, opposingParty, ownOffer, oppOffer, state) {
    const buttons = [];
    const push = (text, texture) => buttons.push({ text, texture });

    for (let slot = 0; slot < 6; slot++) {
        const mon = party[slot] || null;
        push(mon ? slotText(mon, mon.uuid === ownOffer?.uuid) : " ",
             mon ? spriteTexture(mon) : undefined);
    }
    for (let slot = 0; slot < 6; slot++) {
        const mon = opposingParty[slot] || null;
        push(mon ? slotText(mon, mon.uuid === oppOffer?.uuid) : " ",
             mon ? spriteTexture(mon) : undefined);
    }

    const ownPortrait = portraitButton(ownOffer);
    const oppPortrait = portraitButton(oppOffer);
    push(ownPortrait.text, ownPortrait.texture);
    push(oppPortrait.text, oppPortrait.texture);

    push(tradeLabel(player, partner, ownOffer, oppOffer, state), undefined);
    push(" ", undefined);

    for (const entry of infoCarriers(ownOffer)) push(entry.text, entry.texture);
    for (const entry of infoCarriers(oppOffer)) push(entry.text, entry.texture);

    push(player.name, undefined);
    push(partner.name, undefined);

    const slotOverlays = (pokemon, selected) => [
        { text: " ", texture: pokemon ? genderIconTexture(pokemon) : undefined },
        { text: isUntradeable(pokemon) ? MARK_SLOT_LOCK : " ", texture: undefined },
        { text: selected ? MARK_SLOT_SEL : " ", texture: undefined },
        { text: " ", texture: pokemon ? heldItemTexture(pokemon) : undefined }
    ];
    for (let slot = 0; slot < 6; slot++) {
        const mon = party[slot] || null;
        for (const item of slotOverlays(mon, mon?.uuid === ownOffer?.uuid)) {
            push(item.text, item.texture || undefined);
        }
    }
    for (let slot = 0; slot < 6; slot++) {
        const mon = opposingParty[slot] || null;
        const [gender, locked, , held] = slotOverlays(mon, false);
        push(gender.text, gender.texture || undefined);
        push(locked.text, locked.texture || undefined);
        push(held.text, held.texture || undefined);
    }

    const caught = caughtDexSetFor(player);
    push(newBadgeText(caught, oppOffer), undefined);
    for (let slot = 0; slot < 6; slot++) push(newBadgeText(caught, opposingParty[slot] || null), undefined);

    return buttons;
}

function genderIconTexture(pokemon) {
    const gender = String(pokemon?.gender || "").toUpperCase();
    if (gender === "MALE") return "textures/gui/pc/gender_icon_male";
    if (gender === "FEMALE") return "textures/gui/pc/gender_icon_female";
    return "";
}

function closeTradeScreen(player) {
    if (!player?.isValid || player.isSolo) return;
    closeChestScreen(player);
}

// ---------------------------------------------------------------------------
// Container screen (replaces the old per-player ActionFormData loop).
// Every player gets their own anchor container. The screen is drawn from item slots:
//   0..94    text slots  (same index the old form buttons had)
//   100 + i  texture slots for the indexes in TRADE_TEX_INDEXES
//   200..205 press slots for the own party, 206 = Trade, 207 = Exit
//   210      marker string the layout searches (was the form title)
// Both players read the same shared trade state, so a change made by one player is
// redrawn on the other player's screen immediately.
// ---------------------------------------------------------------------------
const TRADE_KEY = "trade";
const TRADE_CHEST_TITLE = "\u00a7r\u00a77\u00a7r\u00a77";
const TRADE_TEX_OFFSET = 100;
const TRADE_PRESS_OWN = 200;
const TRADE_PRESS_TRADE = 206;
const TRADE_PRESS_EXIT = 207;
const TRADE_TITLE_SLOT = 210;
const BTN_TRADE = 6;
const BTN_EXIT = 7;
const TRADE_MULTILINE = new Set([27, 28, 29, 41, 42, 43]);
const TRADE_TEX_INDEXES = [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 20, 21, 22, 23, 24, 31, 34, 35, 36, 37, 38,
    46, 49, 50, 53, 54, 57, 58, 61, 62, 65, 66, 69, 70, 72, 73, 75, 76, 78, 79, 81, 82, 84, 85, 87
];

const tradeContexts = new Map();

const TRADE_LAYOUT = Object.freeze({
    title: TRADE_CHEST_TITLE,
    n: 211,
    tex: [],
    vis: [],
    cap: [],
    st: [TRADE_TITLE_SLOT],
    txt: Array.from({ length: BUTTON_COUNT }, (_, i) => i)
        .filter(i => !TRADE_MULTILINE.has(i))
        .map(i => [i, i]),
    ml: [...TRADE_MULTILINE].map(i => [i, `m${i}`]),
    ic: TRADE_TEX_INDEXES.map(i => [TRADE_TEX_OFFSET + i, `t${i}`]),
    btn: [
        ...Array.from({ length: 6 }, (_, k) => [TRADE_PRESS_OWN + k, k]),
        [TRADE_PRESS_TRADE, BTN_TRADE],
        [TRADE_PRESS_EXIT, BTN_EXIT]
    ]
});

function tradeView(player, ctx) {
    const { partner, party, opposingParty, state } = ctx;
    const ownOffer = state.offers.get(player.id);
    const oppOffer = state.offers.get(partner.id);
    const buttons = buildTradeButtons(player, partner, party, opposingParty, ownOffer, oppOffer, state);
    const lines = {};
    const multi = {};
    const icons = {};
    buttons.forEach((button, i) => {
        if (TRADE_MULTILINE.has(i)) multi[`m${i}`] = button.text;
        else lines[i] = button.text;
        if (button.texture) icons[`t${i}`] = button.texture;
    });
    return { title: buildTitle(player, partner, ownOffer, oppOffer, state), lines, multi, icons, buttons: [] };
}

function refreshPartnerScreen(partner) {
    if (partner?.isValid && !partner.isSolo) refreshChestScreen(partner, TRADE_KEY);
}

function tradePress(player, ctx, button) {
    const { partner, party, state } = ctx;
    if (state.canceled || state.completed) return "close";
    if (!canTrade(player, partner)) {
        state.canceled = true;
        closeTradeScreen(partner);
        return "close";
    }
    if (state.trading) return "redraw";

    if (button === BTN_EXIT) {
        state.canceled = true;
        closeTradeScreen(partner);
        return "close";
    }
    if (button >= 0 && button < 6) {
        const selected = party[button];
        if (!selected || selected.uuid === state.offers.get(player.id)?.uuid) return "redraw";
        state.offers.set(player.id, selected);
        state.ready.delete(player.id);
        state.ready.delete(partner.id);
        state.revision++;
        refreshPartnerScreen(partner);
        return "redraw";
    }
    if (button === BTN_TRADE && state.offers.get(player.id) && state.offers.get(partner.id)) {
        state.ready.add(player.id);
        if (partner.isSolo) state.ready.add(partner.id); // ghost partner accepts instantly
        state.revision++;
        refreshPartnerScreen(partner);
        if (state.ready.has(partner.id)) startTradeAnimation(state, player, partner);
    }
    return "redraw";
}

registerChestScreen({
    key: TRADE_KEY,
    layout: TRADE_LAYOUT,
    wants: player => {
        const ctx = tradeContexts.get(player?.id);
        return Boolean(ctx) && !ctx.state.canceled && !ctx.state.completed;
    },
    create: player => tradeContexts.get(player.id),
    view: tradeView,
    press: tradePress
});

function runTradeScreen(player, partner, party, opposingParty, state) {
    return new Promise(resolve => {
        const ctx = { player, partner, party, opposingParty, state };
        tradeContexts.set(player.id, ctx);
        if (!canTrade(player, partner)) state.canceled = true;
        else if (!openChestScreen(player, TRADE_KEY, { state: ctx, hold: SESSION_TIMEOUT_TICKS })) {
            state.canceled = true;
            player.sendMessage("§cNão foi possível abrir a tela de troca aqui.");
        } else {
            player.sendMessage("§eUse (clique direito / toque) para abrir a tela de troca.");
        }
        const timer = system.runInterval(() => {
            if (!state.canceled && !state.completed && player.isValid) return;
            system.clearRun(timer);
            tradeContexts.delete(player.id);
            closeChestScreen(player);
            resolve(state.completed && !state.canceled ? state.offers.get(player.id) : undefined);
        }, 2);
    });
}

function startTradeAnimation(state, player, partner) {
    if (state.trading) return;
    state.trading = true;
    state.revision++;
    refreshPartnerScreen(player);
    refreshPartnerScreen(partner);
    state.animationDone = sleep(TRADE_ANIMATION_TICKS).then(() => {
        state.completed = true;
        closeTradeScreen(player);
        closeTradeScreen(partner);
    });
}

function canTrade(player, partner) {
    if (partner?.isSolo) return Boolean(player?.isValid) && !player.hasTag("lota:battle_player");
    return player?.isValid && partner?.isValid
        && player.id !== partner.id
        && !player.hasTag("lota:battle_player") && !partner.hasTag("lota:battle_player")
        && player.dimension.id === partner.dimension.id
        && distance(player.location, partner.location) <= MAX_DISTANCE;
}

async function openPlayerInteractionWheel(player, partner) {
    if (!canTrade(player, partner)) return player?.sendMessage("§cStand within 12 blocks of the other trainer.");
    const form = new ActionFormData()
        .title("cobbledrock.interact.player")
        .body(partner.name)
        .button("Close", "textures/ui/cancel")
        .button("Trade", "textures/gui/interact/interact_wheel_icon_trade");
    for (let index = 2; index < 8; index++) form.button("|EMPTY|");
    try {
        const response = await show(form, player);
        if (!response.canceled && response.selection === 1) await tradeWithPlayer(player, partner);
    } catch (error) {
        player.sendMessage(`§cTrade failed: ${error.message || error}`);
    }
}

function newTradeState(players) {
    return {
        players,
        startedTick: system.currentTick,
        offers: new Map(),
        ready: new Set(),
        displayedRevisions: new Map(),
        forcedRefreshes: new Map(),
        revision: 0,
        canceled: false,
        completed: false,
        trading: false,
        animationDone: null
    };
}

// Opens the trade UI alone. The partner is a simulated ghost whose party is a copy of
// the player's own party. Nothing is ever executed: the trade is only simulated.
async function soloTrade(player) {
    if (!player?.isValid) return;
    if (busy.has(player.id)) return player.sendMessage("§7Você já está em uma troca.");
    if (player.hasTag("lota:battle_player")) return player.sendMessage("§cVocê não pode abrir a troca durante uma batalha.");
    const ghost = Object.freeze({ id: `solo_trade_${player.id}`, name: SOLO_PARTNER_NAME, isValid: true, isSolo: true });
    busy.add(player.id);
    const state = newTradeState([player, ghost]);
    activeSessions.set(player.id, state);
    try {
        const snapshot = await requestPartySnapshot([player.id], player.id);
        if (snapshot.outcome !== "snapshot") throw new Error(snapshot.detail || "Party data unavailable.");
        const own = snapshot.players.find(entry => entry.playerId === String(player.id));
        if (!own?.party.length) throw new Error("Você precisa de pelo menos um Pokémon na party.");

        const ghostParty = own.party.map(pokemon => ({ ...pokemon, uuid: `solo-${pokemon.uuid}` }));
        const ghostOffer = ghostParty.find(pokemon => !isUntradeable(pokemon)) || ghostParty[0];
        state.offers.set(ghost.id, ghostOffer);

        const offered = await runTradeScreen(player, ghost, own.party, ghostParty, state);
        if (!offered) return player.sendMessage("§7Troca solo cancelada.");
        player.sendMessage(`§aModo solo: troca simulada, você receberia ${ghostOffer.name}. Nada foi alterado.`);
    } catch (error) {
        state.canceled = true;
        closeTradeScreen(player);
        player.sendMessage(`§cTrade failed: ${error.message || error}`);
    } finally {
        activeSessions.delete(player.id);
        busy.delete(player.id);
    }
}

async function tradeWithPlayer(player, partner, initialUuid) {
    if (!canTrade(player, partner)) return player?.sendMessage("§cStand within 12 blocks of the other trainer.");
    if (busy.has(player.id) || busy.has(partner.id)) return player.sendMessage("§7One of these trainers is already trading.");
    busy.add(player.id);
    busy.add(partner.id);
    const tradeState = newTradeState([player, partner]);
    activeSessions.set(player.id, tradeState);
    try {
        const invitation = await show(new MessageFormData()
            .title("cobbledrock.trade.request")
            .body(`${player.name} wants to trade Pokémon with you.`)
            .button1("Decline")
            .button2("Accept"), partner);
        if (invitation.canceled || invitation.selection !== 1) {
            player.sendMessage(`§7${partner.name} declined the trade request.`);
            return;
        }
        if (tradeState.canceled || !canTrade(player, partner)) throw new Error("Both trainers must remain available within 12 blocks.");

        const snapshot = await requestPartySnapshot([player.id, partner.id], player.id);
        if (snapshot.outcome !== "snapshot") throw new Error(snapshot.detail || "Party data unavailable.");
        const own = snapshot.players.find(entry => entry.playerId === String(player.id));
        const other = snapshot.players.find(entry => entry.playerId === String(partner.id));
        if (!own?.party.length || !other?.party.length) throw new Error("Both trainers need at least one Pokémon.");

        if (initialUuid) {
            const initialOffer = own.party.find(pokemon => pokemon.uuid === initialUuid);
            if (!initialOffer) throw new Error("The offered Pokémon is no longer in your party.");
            tradeState.offers.set(player.id, initialOffer);
        }
        const [offered, requested] = await Promise.all([
            runTradeScreen(player, partner, own.party, other.party, tradeState),
            runTradeScreen(partner, player, other.party, own.party, tradeState)
        ]);
        if (!offered || !requested) {
            player.sendMessage("§7The trade was canceled.");
            partner.sendMessage("§7The trade was canceled.");
            return;
        }
        if (!canTrade(player, partner)) throw new Error("Both trainers must remain within 12 blocks.");

        const result = await executeTrade(player.id, {
            playerOneId: String(player.id),
            playerTwoId: String(partner.id),
            slotOne: offered.slot,
            slotTwo: requested.slot,
            uuidOne: offered.uuid,
            uuidTwo: requested.uuid,
            expectedOne: offered,
            expectedTwo: requested
        });
        if (result.outcome !== "completed") throw new Error(result.detail || "Trade rejected.");
        player.sendMessage(`§aTrade complete! You received ${result.receivedByOne.name}.`);
        partner.sendMessage(`§aTrade complete! You received ${result.receivedByTwo.name}.`);
        for (const evolution of result.evolutions || []) {
            const readyMessage = `§d${evolution.oldName} is ready to evolve into ${evolution.newName}! Open your Pokémon Compass and press Evolve.`;
            player.sendMessage(readyMessage);
            partner.sendMessage(readyMessage);
        }
    } catch (error) {
        tradeState.canceled = true;
        closeTradeScreen(player);
        closeTradeScreen(partner);
        player.sendMessage(`§cTrade failed: ${error.message || error}`);
        if (partner?.isValid) partner.sendMessage(`§cTrade failed: ${error.message || error}`);
    } finally {
        activeSessions.delete(player.id);
        busy.delete(player.id);
        busy.delete(partner.id);
    }
}

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    if (event.target?.typeId !== "minecraft:player") return;
    event.cancel = true;
    const player = event.player;
    const partner = event.target;
    system.run(() => openPlayerInteractionWheel(player, partner));
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (!TRADE_COMMAND_EVENTS.has(event.id) || event.sourceType !== ScriptEventSource.Entity) return;
    const player = event.sourceEntity;
    if (!player?.isValid || player.typeId !== "minecraft:player") return;
    const name = String(event.message || "").trim().toLowerCase();
    // No partner name supplied → open the nearby-trainer picker directly.
    // This lets a player open the trade screen on their own without having to
    // physically interact with another trainer entity.
    if (!name) {
        system.run(() => offerPokemonTrade(player));
        return;
    }
    const partner = world.getAllPlayers().find(candidate => candidate.id !== player.id && candidate.name.toLowerCase() === name);
    system.run(() => partner ? tradeWithPlayer(player, partner) : player.sendMessage("§cOnline trainer not found."));
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (!TRADE_SOLO_EVENTS.has(event.id)) return;
    const name = String(event.message || "").trim().toLowerCase();
    const source = event.sourceType === ScriptEventSource.Entity ? event.sourceEntity : undefined;
    // Optional player name lets console/command blocks open it for someone.
    const player = name
        ? world.getAllPlayers().find(candidate => candidate.name.toLowerCase() === name)
        : source;
    if (!player?.isValid || player.typeId !== "minecraft:player") {
        if (source?.isValid) source.sendMessage("§cJogador não encontrado.");
        return;
    }
    system.run(() => soloTrade(player));
});

function cancelSession(state) {
    state.canceled = true;
    for (const player of state.players) closeTradeScreen(player);
}

world.afterEvents.playerLeave.subscribe(event => {
    for (const state of activeSessions.values()) {
        if (state.players.some(player => player.id === event.playerId)) cancelSession(state);
    }
});

system.runInterval(() => {
    for (const state of activeSessions.values()) {
        if (!state.completed && !state.canceled && !state.trading
            && (!canTrade(...state.players) || system.currentTick - state.startedTick >= SESSION_TIMEOUT_TICKS)) {
            cancelSession(state);
        }
    }
}, 5);

export async function offerPokemonTrade(player, uuid) {
    if (!player?.isValid || busy.has(player.id)) return;
    const candidates = world.getAllPlayers().filter(partner => canTrade(player, partner) && !busy.has(partner.id));
    if (!candidates.length) return player.sendMessage("§eNo available trainer within 12 blocks.");
    const form = new ActionFormData().title("Trade Pokémon").body("Choose a nearby trainer.");
    for (const partner of candidates) form.button(partner.name);
    try {
        const response = await show(form, player);
        if (!response.canceled && candidates[response.selection]) {
            await tradeWithPlayer(player, candidates[response.selection], uuid);
        }
    } catch (error) {
        player.sendMessage(`§cTrade failed: ${error.message || error}`);
    }
}

export const __tradeScreenTest = {
    showForTest: show,
    runTradeScreenForTest: runTradeScreen,
    tradeWithPlayerForTest: tradeWithPlayer,
    TITLE_ROOT, MARK_OWNMON, MARK_OPPMON, MARK_T2_OWN, MARK_T2_OPP, MARK_IACC,
    MARK_OACC, MARK_TRADING, MARK_BTN, MARK_SLOT_SEL, MARK_SLOT_LOCK,
    MARK_SLOT_MALE, MARK_SLOT_FEMALE, MARK_NEW,
    IDX_LOCAL, IDX_OPP, IDX_OWN_PORTRAIT, IDX_OPP_PORTRAIT, IDX_TRADE, IDX_EXIT,
    IDX_CARRIER, IDX_PLAYER_NAME, IDX_TRADER_NAME, IDX_SLOT_CARRIER,
    IDX_SLOT_CARRIER_OPP, IDX_NEW_PORTRAIT, IDX_NEW_SLOT, BUTTON_COUNT, CARRIER_ORDER,
    SLOT_CARRIERS_LOCAL, SLOT_CARRIERS_OPP, statColumn, moveNames, abilityName
};
