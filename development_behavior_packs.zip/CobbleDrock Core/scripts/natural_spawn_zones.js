const DIMENSION_IDS = new Set([
    "minecraft:overworld",
    "minecraft:nether",
    "minecraft:the_end"
]);
const MAX_ZONE_COUNT = 128;
const MAX_ZONE_ID_LENGTH = 96;
const MAX_ZONE_SPAN = 512;

const ZONES_BY_ID = new Map();
const ZONES_BY_DIMENSION = new Map();

function normalizedDimensionId(value) {
    const text = String(value || "").trim();
    if (DIMENSION_IDS.has(text)) return text;
    const raw = text.replace(/^minecraft:/, "");
    const dimensionId = raw ? `minecraft:${raw}` : "";
    return DIMENSION_IDS.has(dimensionId) ? dimensionId : undefined;
}

function finitePoint(value) {
    if (!value || typeof value !== "object") return undefined;
    const point = {
        x: Number(value.x),
        y: Number(value.y),
        z: Number(value.z)
    };
    return Object.values(point).every(Number.isFinite) ? point : undefined;
}

function normalizedBounds(minimum, maximum) {
    const min = finitePoint(minimum);
    const max = finitePoint(maximum);
    if (!min || !max) return undefined;
    if (min.x > max.x || min.y > max.y || min.z > max.z) return undefined;
    if (max.x - min.x > MAX_ZONE_SPAN
        || max.y - min.y > MAX_ZONE_SPAN
        || max.z - min.z > MAX_ZONE_SPAN) return undefined;
    return { min, max };
}

function removeFromDimension(zone) {
    const zones = ZONES_BY_DIMENSION.get(zone.dimensionId);
    if (!zones) return;
    zones.delete(zone.id);
    if (!zones.size) ZONES_BY_DIMENSION.delete(zone.dimensionId);
}

export function upsertNaturalSpawnZone(request) {
    const id = String(request?.zoneId || "").trim().slice(0, MAX_ZONE_ID_LENGTH);
    const dimensionId = normalizedDimensionId(request?.dimensionId);
    const bounds = normalizedBounds(request?.min, request?.max);
    if (!id || !dimensionId || !bounds) return false;
    if (!ZONES_BY_ID.has(id) && ZONES_BY_ID.size >= MAX_ZONE_COUNT) return false;

    const previous = ZONES_BY_ID.get(id);
    if (previous) removeFromDimension(previous);
    const zone = { id, dimensionId, ...bounds };
    ZONES_BY_ID.set(id, zone);
    let zones = ZONES_BY_DIMENSION.get(dimensionId);
    if (!zones) {
        zones = new Map();
        ZONES_BY_DIMENSION.set(dimensionId, zones);
    }
    zones.set(id, zone);
    return true;
}

export function removeNaturalSpawnZone(zoneId) {
    const id = String(zoneId || "").trim().slice(0, MAX_ZONE_ID_LENGTH);
    const zone = ZONES_BY_ID.get(id);
    if (!zone) return false;
    ZONES_BY_ID.delete(id);
    removeFromDimension(zone);
    return true;
}

export function clearNaturalSpawnsInZone(zoneId) {
    const zone = ZONES_BY_ID.get(String(zoneId || "").trim().slice(0, MAX_ZONE_ID_LENGTH));
    if (!zone) return 0;
    try {
        const dimension = world.getDimension(zone.dimensionId.replace("minecraft:", ""));
        const entities = dimension.getEntities({
            location: zone.min,
            volume: {
                x: zone.max.x - zone.min.x,
                y: zone.max.y - zone.min.y,
                z: zone.max.z - zone.min.z
            },
            tags: ["lota:natural_spawn"]
        });
        let removed = 0;
        for (const entity of entities) {
            try {
                entity.remove();
                removed++;
            } catch (error) {}
        }
        return removed;
    } catch (error) {
        return 0;
    }
}

export function isNaturalSpawnLocationBlocked(dimensionId, location) {
    const point = finitePoint(location);
    const zones = ZONES_BY_DIMENSION.get(normalizedDimensionId(dimensionId));
    if (!point || !zones) return false;
    for (const zone of zones.values()) {
        if (point.x >= zone.min.x && point.x <= zone.max.x
            && point.y >= zone.min.y && point.y <= zone.max.y
            && point.z >= zone.min.z && point.z <= zone.max.z) return true;
    }
    return false;
}

export function hasNaturalSpawnZones(dimensionId) {
    return ZONES_BY_DIMENSION.has(normalizedDimensionId(dimensionId));
}

export function doesNaturalSpawnAreaIntersectZone(dimensionId, area) {
    const min = finitePoint({ x: area?.minX, y: area?.minY, z: area?.minZ });
    const max = finitePoint({ x: area?.maxX, y: area?.maxY, z: area?.maxZ });
    const zones = ZONES_BY_DIMENSION.get(normalizedDimensionId(dimensionId));
    if (!min || !max || !zones) return false;
    for (const zone of zones.values()) {
        if (max.x >= zone.min.x && min.x <= zone.max.x
            && max.y >= zone.min.y && min.y <= zone.max.y
            && max.z >= zone.min.z && min.z <= zone.max.z) return true;
    }
    return false;
}

export function isNaturalSpawnAreaFullyBlocked(dimensionId, area) {
    const min = finitePoint({ x: area?.minX, y: area?.minY, z: area?.minZ });
    const max = finitePoint({ x: area?.maxX, y: area?.maxY, z: area?.maxZ });
    const zones = ZONES_BY_DIMENSION.get(normalizedDimensionId(dimensionId));
    if (!min || !max || !zones) return false;
    for (const zone of zones.values()) {
        if (min.x >= zone.min.x && max.x <= zone.max.x
            && min.y >= zone.min.y && max.y <= zone.max.y
            && min.z >= zone.min.z && max.z <= zone.max.z) return true;
    }
    return false;
}
import { world } from "@minecraft/server";
