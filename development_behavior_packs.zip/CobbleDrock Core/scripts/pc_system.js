import { ItemStack, system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { speciesData } from "./battle_math.js";
import { normalizePartyStatus } from "./party_hud_presentation.js";
import {
    loadPartyFromPlayer,
    savePartyToPlayer,
    loadPCFromPlayer,
    savePCToPlayer,
    PC_BOX_COUNT,
    PC_BOX_SIZE
} from "./storage.js";
import { commitPartyAndBox, commitTwoBoxes } from "./storage_service.js";
import { spawnColoredFlame } from "./particle_utils.js";
import { CORE_CONFIG } from "./core_config.js";
import { pokemonFormTexture } from "./form_ui_textures.js";
import { heldItemIconPath } from "./held_items.js";
import {
    attachChestScreen,
    chestScreenActive,
    closeChestScreen,
    openChestScreen,
    refreshChestScreen,
    registerChestScreen,
    registerFixedAnchor
} from "./chest_ui.js";

const BLOCK_ID = "lota:pc";
const TOP_BLOCK_ID = "lota:pc_top";
const BATTLE_TAG = "lota:battle_player";
const SELECTED_SLOT_PROPERTY = "lota:selected_party_slot";

const TITLE_ROOT = "cobbledrock.pc";
const MARK_IV = "#IV";
const MARK_EV = "#EV";
const MARK_STATS = "#STATS";
const MARK_MALE = "#MALE";
const MARK_FEMALE = "#FEMALE";
const MARK_SHINY = "#SHINY";
const MARK_HELD = "#HELD";
const MARK_MON = "#MON";
const MARK_SELECTED = "#SEL";
const MARK_STATUS = "#ST:";
const MARK_TYPE = "#T:";
const MARK_TYPE2 = "#T2:";

const IDX_BOX = 0;
const IDX_PARTY = IDX_BOX + PC_BOX_SIZE;
const IDX_PREV = IDX_PARTY + 6;
const IDX_NEXT = IDX_PREV + 1;
const IDX_OPTIONS = IDX_NEXT + 1;
const IDX_WALLPAPER = IDX_OPTIONS + 1;
const IDX_SORT = IDX_WALLPAPER + 1;
const IDX_FILTER = IDX_SORT + 5;
const IDX_INFO = IDX_FILTER + 1;
const IDX_RELEASE = IDX_INFO + 1;
const IDX_RELEASE_YES = IDX_RELEASE + 1;
const IDX_RELEASE_NO = IDX_RELEASE_YES + 1;
const IDX_EXIT = IDX_RELEASE_NO + 1;
const IDX_PORTRAIT = IDX_EXIT + 1;
const IDX_LEVEL = IDX_PORTRAIT + 1;
const IDX_NAME = IDX_LEVEL + 1;
const IDX_BALL = IDX_NAME + 1;
const IDX_HELD_ITEM = IDX_BALL + 1;
const IDX_BOX_NAME = IDX_HELD_ITEM + 1;
const IDX_FILTER_TEXT = IDX_BOX_NAME + 1;
const IDX_NATURE = IDX_FILTER_TEXT + 1;
const IDX_ABILITY = IDX_NATURE + 1;
const IDX_MOVES = IDX_ABILITY + 1;
const IDX_STATS = IDX_MOVES + 1;
const IDX_WALLPAPER_ART = IDX_STATS + 1;
const IDX_WALLPAPER_GLOW = IDX_WALLPAPER_ART + 1;
const IDX_HELD_BOX = IDX_WALLPAPER_GLOW + 1;
const IDX_HELD_PARTY = IDX_HELD_BOX + PC_BOX_SIZE;
const BUTTON_COUNT = IDX_HELD_PARTY + 6;

const SORT_MODES = ["name", "level", "type", "pokedex_number", "gender"];

const STAT_INFO = 0;
const STAT_IV = 1;
const STAT_EV = 2;

const SOUND = Object.freeze({
    click: "cobblemon.pc.click",
    on: "cobblemon.pc.on",
    off: "cobblemon.pc.off",
    grab: "cobblemon.pc.grab",
    drop: "cobblemon.pc.drop",
    release: "cobblemon.pc.release",
    wallpaperUnlock: "cobblemon.pc.wallpaper_unlock"
});

const PC_CHEST_KEY = "pc";
const PC_ANCHOR_TYPE = "lota:pc_anchor";
const PC_CHEST_TITLE = "\u00a7r\u00a74\u00a7r\u00a74";
const MENU_FORM_TAG = "lota:menu_form";
const ICON_BASE = 100;
const STATE_SLOT = 200;

const WALLPAPER_ROOT = "textures/gui/pc/wallpaper";
const DEFAULT_WALLPAPER = "basic/wallpaper_basic_05";
const WALLPAPERS = [
    "basic/wallpaper_basic_01", "basic/wallpaper_basic_02", "basic/wallpaper_basic_03",
    "basic/wallpaper_basic_04", "basic/wallpaper_basic_05", "basic/wallpaper_basic_06",
    "basic/wallpaper_basic_07", "basic/wallpaper_basic_08", "basic/wallpaper_basic_09",
    "basic/wallpaper_basic_10", "basic/wallpaper_basic_11",
    "basic/alt/wallpaper_basic_01", "basic/alt/wallpaper_basic_02", "basic/alt/wallpaper_basic_03",
    "basic/alt/wallpaper_basic_04", "basic/alt/wallpaper_basic_05", "basic/alt/wallpaper_basic_06",
    "basic/alt/wallpaper_basic_07", "basic/alt/wallpaper_basic_08", "basic/alt/wallpaper_basic_09",
    "basic/alt/wallpaper_basic_10", "basic/alt/wallpaper_basic_11",
    "biome/wallpaper_biome_cave", "biome/wallpaper_biome_forest", "biome/wallpaper_biome_nether",
    "biome/wallpaper_biome_ocean", "biome/wallpaper_biome_the_end",
    "biome/alt/wallpaper_biome_cave", "biome/alt/wallpaper_biome_forest",
    "biome/alt/wallpaper_biome_nether", "biome/alt/wallpaper_biome_ocean",
    "biome/alt/wallpaper_biome_the_end",
    "misc/wallpaper_pokemon_alpha", "misc/alt/wallpaper_pokemon_alpha"
];

function wallpaperGlowPath(wallpaper) {
    const parts = String(wallpaper).split("/");
    parts.splice(parts.length - 1, 0, "glow");
    return parts.join("/");
}

const BALL_TEXTURE_ROOT = "textures/item/poke_balls";
const PC_SPRITE_ROOT = "textures/gui/pc/pc_sprite";

const TYPE_NAMES = new Set([
    "normal", "fire", "water", "grass", "electric", "ice", "fighting", "poison",
    "ground", "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark",
    "steel", "fairy"
]);

const FACE_OFFSETS = {
    Up: { x: 0, y: 1, z: 0 },
    Down: { x: 0, y: -1, z: 0 },
    North: { x: 0, y: 0, z: -1 },
    South: { x: 0, y: 0, z: 1 },
    West: { x: -1, y: 0, z: 0 },
    East: { x: 1, y: 0, z: 0 }
};

const TYPE_BADGE_COLOR = Object.freeze({
    normal: "7", fire: "c", water: "9", electric: "e", grass: "a",
    ice: "b", fighting: "c", poison: "5", ground: "6", flying: "b",
    psychic: "d", bug: "a", rock: "e", ghost: "5", dragon: "9",
    dark: "8", steel: "7", fairy: "d", stellar: "f"
});

const sessions = new Map();

function titleCase(value) {
    return String(value || "-")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

function speciesKey(pokemon) {
    return String(pokemon?.species || "unknown").replace(/^.*:/, "").toLowerCase();
}

function pokemonTypes(pokemon) {
    try {
        const types = speciesData(speciesKey(pokemon))?.types;
        return Array.isArray(types)
            ? types.map(type => String(type).toLowerCase()).filter(Boolean)
            : [];
    } catch (error) {
        return [];
    }
}

function typeBadges(pokemon) {
    const types = pokemonTypes(pokemon);
    if (!types.length) return "";
    return types.map(type => `\u00a7${TYPE_BADGE_COLOR[type] || "f"}[${titleCase(type)}]\u00a7r`).join(" ");
}

function statusLabel(pokemon) {
    const code = normalizePartyStatus(pokemon?.statusCondition);
    return code ? code.toUpperCase() : "";
}

function levelOf(pokemon) {
    return Math.max(1, Math.floor(Number(pokemon?.level) || 1));
}

function pokemonName(pokemon) {
    return pokemon?.nickname || titleCase(speciesKey(pokemon));
}

function isShiny(pokemon) {
    return Boolean(pokemon?.isShiny) || (Array.isArray(pokemon?.aspects) && pokemon.aspects.includes("shiny"));
}

function slotUuid(pokemon) {
    return String(pokemon?.uuid || "");
}

function playSound(player, id, pitch = 1) {
    try {
        player.playSound(id, { volume: 1, pitch });
    } catch (error) {}
}

function blockKey(block) {
    const { x, y, z } = block.location;
    return `${block.dimension.id}:${x},${y},${z}`;
}

function blockAtOffset(block, yOffset) {
    try {
        const { x, y, z } = block.location;
        return block.dimension.getBlock({ x, y: y + yOffset, z });
    } catch (error) {
        return undefined;
    }
}

function syncTopState(bottom, top) {
    try {
        let permutation = top.permutation.withState(
            "minecraft:cardinal_direction",
            bottom.permutation.getState("minecraft:cardinal_direction")
        );
        permutation = permutation.withState(
            "lota:screen_on",
            bottom.permutation.getState("lota:screen_on") === true
        );
        top.setPermutation(permutation);
    } catch (error) {}
}

function ensureTop(bottom) {
    if (bottom?.typeId !== BLOCK_ID) return undefined;
    const top = blockAtOffset(bottom, 1);
    if (!top) return undefined;
    try {
        if (top.typeId === "minecraft:air") top.setType(TOP_BLOCK_ID);
        if (top.typeId !== TOP_BLOCK_ID) return undefined;
        syncTopState(bottom, top);
        return top;
    } catch (error) {
        return undefined;
    }
}

function setScreen(block, enabled) {
    try {
        if (block?.typeId !== BLOCK_ID) return;
        block.setPermutation(block.permutation.withState("lota:screen_on", enabled));
        const top = ensureTop(block);
        if (top) top.setPermutation(top.permutation.withState("lota:screen_on", enabled));
    } catch (error) {}
}

function isCreative(player) {
    try {
        return String(player.getGameMode()).toLowerCase() === "creative";
    } catch (error) {
        return false;
    }
}

function canPlacePc(player) {
    try {
        const mode = String(player.getGameMode()).toLowerCase();
        return mode === "survival" || mode === "creative";
    } catch (error) {
        return false;
    }
}

function returnPcItem(player, dimension, location) {
    if (isCreative(player)) return;
    const item = new ItemStack(BLOCK_ID, 1);
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        if (container) {
            const remainder = container.addItem(item);
            if (!remainder) return;
            dimension.spawnItem(remainder, location);
            return;
        }
    } catch (error) {}
    try {
        dimension.spawnItem(item, location);
    } catch (error) {}
}

function pcFacingForPlayer(player) {
    try {
        const view = player.getViewDirection();
        if (Math.abs(view.x) > Math.abs(view.z)) return view.x > 0 ? "west" : "east";
        return view.z > 0 ? "north" : "south";
    } catch (error) {
        return "north";
    }
}

function consumePcItem(player, slot) {
    if (isCreative(player)) return true;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const item = container?.getItem(slot);
        if (!container || item?.typeId !== BLOCK_ID) return false;
        if (item.amount <= 1) container.setItem(slot, undefined);
        else {
            item.amount -= 1;
            container.setItem(slot, item);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function placePcPair(player, dimension, location, slot) {
    if (!player?.isValid || !canPlacePc(player)) return;
    const bottom = dimension.getBlock(location);
    const top = dimension.getBlock({ ...location, y: location.y + 1 });
    if (!bottom || !top || bottom.typeId !== "minecraft:air" || top.typeId !== "minecraft:air") return;

    try {
        bottom.setType(BLOCK_ID);
        bottom.setPermutation(bottom.permutation.withState(
            "minecraft:cardinal_direction",
            pcFacingForPlayer(player)
        ));
        const placedTop = ensureTop(bottom);
        if (placedTop) ensurePcAnchor(dimension, bottom.location);
        if (!placedTop || !consumePcItem(player, slot)) {
            if (placedTop?.typeId === TOP_BLOCK_ID) placedTop.setType("minecraft:air");
            if (bottom.typeId === BLOCK_ID) bottom.setType("minecraft:air");
        }
    } catch (error) {
        try {
            const placedTop = dimension.getBlock({ ...location, y: location.y + 1 });
            if (placedTop?.typeId === TOP_BLOCK_ID) placedTop.setType("minecraft:air");
            if (bottom.typeId === BLOCK_ID) bottom.setType("minecraft:air");
        } catch (cleanupError) {}
        console.warn(`Failed to place PC pair at ${location.x},${location.y},${location.z}: ${error}`);
    }
}

function blockFromSession(session) {
    try {
        return world.getDimension(session.dimensionId).getBlock(session.location);
    } catch (error) {
        return undefined;
    }
}

function isCurrentSession(player, session) {
    try {
        return Boolean(player?.isValid) && sessions.get(player.id) === session;
    } catch (error) {
        return false;
    }
}

function isBattlePlayer(player) {
    try {
        return Boolean(player?.hasTag?.(BATTLE_TAG));
    } catch (error) {
        return false;
    }
}

function closeSession(player, expected = undefined) {
    const session = sessions.get(player.id);
    if (!session || (expected && session !== expected)) return false;
    sessions.delete(player.id);
    setScreen(blockFromSession(session), false);
    if (session.chest && chestScreenActive(player, PC_CHEST_KEY)) closeChestScreen(player);
    playSound(player, SOUND.off);
    return true;
}

function newSession() {
    return {
        boxIndex: 0,
        held: null,
        statIndex: STAT_INFO,
        filter: "",
        sortMode: null,
        sortReverse: false,
        formOpen: false,
        busyRetries: 0
    };
}

function actionBar(player, key, withArgs = []) {
    try {
        player.onScreenDisplay.setActionBar({
            rawtext: [{ translate: key, with: withArgs.map(value => String(value)) }]
        });
    } catch (error) {}
}

function wallpaperProperty(boxIndex) {
    return `lota:pc_wallpaper_${boxIndex}`;
}

function boxNameProperty(boxIndex) {
    return `lota:pc_boxname_${boxIndex}`;
}

function loadWallpaper(player, boxIndex) {
    try {
        const value = String(player.getDynamicProperty(wallpaperProperty(boxIndex)) || "");
        return WALLPAPERS.includes(value) ? value : DEFAULT_WALLPAPER;
    } catch (error) {
        return DEFAULT_WALLPAPER;
    }
}

function saveWallpaper(player, boxIndex, wallpaper) {
    try {
        player.setDynamicProperty(wallpaperProperty(boxIndex), String(wallpaper));
        return true;
    } catch (error) {
        return false;
    }
}

function loadBoxName(player, boxIndex) {
    try {
        return String(player.getDynamicProperty(boxNameProperty(boxIndex)) || "");
    } catch (error) {
        return "";
    }
}

function saveBoxName(player, boxIndex, name) {
    try {
        player.setDynamicProperty(boxNameProperty(boxIndex), String(name || "").slice(0, 24));
        return true;
    } catch (error) {
        return false;
    }
}

function boxLabel(player, boxIndex) {
    const custom = loadBoxName(player, boxIndex);
    return custom || `Box ${boxIndex + 1}`;
}

function parseFilter(source) {
    const text = String(source || "").trim();
    if (!text) return null;

    const tests = [];
    for (const raw of text.split(/\s+/)) {
        const token = raw.toLowerCase();
        if (!token) continue;
        if (token === "shiny") { tests.push(p => isShiny(p)); continue; }

        const qualifier = /^(lvl|level|type|gender|held|ball)(>=|<=|>|<|=|:)(.+)$/.exec(token);
        if (qualifier) {
            const [, key, op, value] = qualifier;
            if (key === "lvl" || key === "level") {
                const target = Number(value);
                if (!Number.isFinite(target)) continue;
                tests.push(p => {
                    const level = levelOf(p);
                    if (op === ">" || op === ">=") return op === ">" ? level > target : level >= target;
                    if (op === "<" || op === "<=") return op === "<" ? level < target : level <= target;
                    return level === target;
                });
            } else if (key === "type") {
                tests.push(p => pokemonTypes(p).includes(value));
            } else if (key === "gender") {
                tests.push(p => String(p?.gender || "").toLowerCase().startsWith(value));
            } else if (key === "held") {
                tests.push(p => titleCase(p?.heldItem).toLowerCase().includes(value));
            } else {
                tests.push(p => titleCase(p?.caughtBall).toLowerCase().includes(value));
            }
            continue;
        }
        tests.push(p => pokemonName(p).toLowerCase().includes(token) || speciesKey(p).includes(token));
    }
    if (!tests.length) return null;
    return pokemon => tests.every(test => {
        try { return test(pokemon); } catch (error) { return false; }
    });
}

function passesFilter(pokemon, filter) {
    if (!filter) return true;
    if (!pokemon) return true;
    return filter(pokemon);
}

function sortBox(box, mode, reverse) {
    const dexOf = pokemon => {
        try {
            return Number(speciesData(speciesKey(pokemon))?.pokedex) || Number.MAX_SAFE_INTEGER;
        } catch (error) {
            return Number.MAX_SAFE_INTEGER;
        }
    };
    const mapper = pokemon => {
        switch (mode) {
            case "name": return pokemonName(pokemon).toLowerCase();
            case "level": return levelOf(pokemon);
            case "type": return pokemonTypes(pokemon)[0] || "zzz";
            case "pokedex_number": return dexOf(pokemon);
            case "gender": return String(pokemon?.gender || "");
            default: return dexOf(pokemon);
        }
    };
    const entries = box.map((pokemon, index) => ({ pokemon, index }));
    entries.sort((a, b) => {
        if (!a.pokemon && !b.pokemon) return a.index - b.index;
        if (!a.pokemon) return 1;
        if (!b.pokemon) return -1;
        const left = mapper(a.pokemon);
        const right = mapper(b.pokemon);
        let result = 0;
        if (typeof left === "number" && typeof right === "number") result = left - right;
        else result = String(left).localeCompare(String(right));
        if (result !== 0) return reverse ? -result : result;
        const byDex = dexOf(a.pokemon) - dexOf(b.pokemon);
        if (byDex !== 0) return byDex;
        return levelOf(b.pokemon) - levelOf(a.pokemon);
    });
    return entries.map(entry => entry.pokemon);
}

function normalizeSelectedSlot(player, party) {
    const current = Math.floor(Number(player.getDynamicProperty(SELECTED_SLOT_PROPERTY)) || 0);
    if (!party.length) {
        player.setDynamicProperty(SELECTED_SLOT_PROPERTY, 0);
        return;
    }
    if (!Number.isInteger(current) || current < 0 || current >= party.length) {
        player.setDynamicProperty(SELECTED_SLOT_PROPERTY, Math.max(0, party.length - 1));
    }
}

function recallPartyPokemon(player, pokemon) {
    const uuid = slotUuid(pokemon);
    if (!uuid) return;
    for (const dimensionId of ["overworld", "nether", "the_end"]) {
        let entities = [];
        try {
            entities = world.getDimension(dimensionId).getEntities({ tags: ["lota:party_pokemon"] });
        } catch (error) {
            continue;
        }
        for (const entity of entities) {
            try {
                if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== player.id) continue;
                const data = entity.getDynamicProperty("lota:pokemon_data");
                if (!data || JSON.parse(String(data)).uuid !== uuid) continue;
                const location = { ...entity.location };
                const dimension = entity.dimension;
                entity.remove();
                spawnColoredFlame(dimension, location);
            } catch (error) {}
        }
    }
}

function cloneContainer(value) {
    return JSON.parse(JSON.stringify(value ?? []));
}

function savePartyAndBox(player, party, boxIndex, box, prevParty, prevBox) {
    const commit = commitPartyAndBox(player, party, boxIndex, box, prevParty, prevBox);
    if (!commit.ok) {
        actionBar(player, "cobblemon.pc.save_failed");
        return false;
    }
    normalizeSelectedSlot(player, party);
    return true;
}

function saveFailed(player, session) {
    actionBar(player, "cobblemon.pc.save_failed");
    session.held = null;
    return showPC(player, session);
}

function heldPokemon(player, session) {
    if (!session.held) return null;
    if (session.held.kind === "party") {
        const pokemon = loadPartyFromPlayer(player)[session.held.slot] || null;
        return pokemon && (!session.held.uuid || slotUuid(pokemon) === session.held.uuid) ? pokemon : null;
    }
    const pokemon = loadPCFromPlayer(player, session.held.box)[session.held.slot] || null;
    return pokemon && (!session.held.uuid || slotUuid(pokemon) === session.held.uuid) ? pokemon : null;
}

function isHeldAt(session, kind, box, slot) {
    if (!session.held || session.held.kind !== kind) return false;
    if (kind === "party") return session.held.slot === slot;
    return session.held.box === box && session.held.slot === slot;
}

function renderedMatches(session, kind, slot, pokemon) {
    const rendered = kind === "party" ? session.renderedParty : session.renderedBox;
    if (kind === "box" && session.renderedBoxIndex !== session.boxIndex) return false;
    return Array.isArray(rendered) && rendered[slot] === slotUuid(pokemon);
}

function slotCaption(pokemon, held) {
    if (!pokemon) return " ";
    let text = `Lv.${levelOf(pokemon)}`;
    if (held) text += "|H";
    const gender = String(pokemon.gender || "").toUpperCase();
    if (gender === "MALE") text += "|M";
    else if (gender === "FEMALE") text += "|F";
    return text;
}

function pokemonDex(pokemon) {
    try {
        const direct = Math.floor(Number(pokemon?.pokedex));
        if (Number.isInteger(direct) && direct > 0) return direct;
        const dex = Math.floor(Number(speciesData(speciesKey(pokemon))?.pokedex));
        return Number.isInteger(dex) && dex > 0 ? dex : 0;
    } catch (error) {
        return 0;
    }
}

export function spriteSheetTexture(pokemon) {
    const dex = pokemonDex(pokemon);
    if (dex) return `${PC_SPRITE_ROOT}/${String(dex).padStart(4, "0")}`;
    return pokemonFormTexture(pokemon);
}

function statusCode(pokemon) {
    if (!pokemon) return "";
    if (Number(pokemon.currentHp) <= 0) return "fnt";
    return normalizePartyStatus(pokemon.statusCondition);
}

function knownTypes(pokemon) {
    return pokemonTypes(pokemon).filter(type => TYPE_NAMES.has(type));
}

function primaryType(pokemon) {
    return knownTypes(pokemon)[0] || "";
}

function secondaryType(pokemon) {
    return knownTypes(pokemon)[1] || "";
}

function ballTexture(pokemon) {
    const ball = String(pokemon?.caughtBall || "").replace(/^.*:/, "").toLowerCase();
    return ball ? `${BALL_TEXTURE_ROOT}/${ball}` : undefined;
}

function heldItemTexture(pokemon) {
    const id = String(pokemon?.heldItem || "").trim();
    if (!id) return undefined;
    return heldItemIconPath(id);
}

function infoValues(pokemon) {
    return {
        nature: titleCase(pokemon.mintedNature || pokemon.nature),
        ability: titleCase(pokemon.ability),
        moves: (Array.isArray(pokemon.moves) ? pokemon.moves.slice(0, 4) : [])
            .map(move => titleCase(typeof move === "string" ? move : move?.id))
            .join("\n")
    };
}

function statValues(pokemon, statIndex) {
    const source = statIndex === STAT_IV ? (pokemon.ivs || {}) : (pokemon.evs || {});
    return ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"]
        .map(key => String(Math.max(0, Math.floor(Number(source[key]) || 0))))
        .join("\n");
}

function buildTitle(session, selected) {
    let title = TITLE_ROOT;
    if (session.held?.kind === "pc") title += MARK_SELECTED;
    if (session.statIndex === STAT_IV) title += MARK_IV + MARK_STATS;
    else if (session.statIndex === STAT_EV) title += MARK_EV + MARK_STATS;
    if (!selected) return title;

    title += MARK_MON;
    const gender = String(selected.gender || "").toUpperCase();
    if (gender === "MALE") title += MARK_MALE;
    else if (gender === "FEMALE") title += MARK_FEMALE;
    if (isShiny(selected)) title += MARK_SHINY;
    if (selected.heldItem) title += MARK_HELD;

    const status = statusCode(selected);
    if (status) title += MARK_STATUS + status;
    const primary = primaryType(selected);
    if (primary) title += MARK_TYPE + primary;
    const secondary = secondaryType(selected);
    if (secondary) title += MARK_TYPE2 + secondary;
    return title;
}

function sortIcon(session, mode) {
    const reverse = session.sortMode === mode && session.sortReverse;
    return `textures/gui/pc/pc_button_sort_${mode}${reverse ? "_reverse" : ""}`;
}

function buildModel(player, session) {
    const party = loadPartyFromPlayer(player);
    const box = loadPCFromPlayer(player, session.boxIndex);
    const filter = parseFilter(session.filter);
    const selected = heldPokemon(player, session);
    const wallpaper = loadWallpaper(player, session.boxIndex);

    session.renderedParty = Array.from({ length: 6 }, (_, slot) => slotUuid(party[slot]));
    session.renderedBox = Array.from({ length: PC_BOX_SIZE }, (_, slot) => slotUuid(box[slot]));
    session.renderedBoxIndex = session.boxIndex;

    const entries = [];
    const add = (text, texture) => entries.push({ text, texture });

    for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
        const pokemon = box[slot] || null;
        const visible = passesFilter(pokemon, filter);
        add(
            visible ? slotCaption(pokemon, isHeldAt(session, "pc", session.boxIndex, slot)) : " ",
            visible && pokemon ? spriteSheetTexture(pokemon) : undefined
        );
    }
    for (let slot = 0; slot < 6; slot++) {
        const pokemon = party[slot] || null;
        const visible = passesFilter(pokemon, filter);
        add(
            visible ? slotCaption(pokemon, isHeldAt(session, "party", undefined, slot)) : " ",
            visible && pokemon ? spriteSheetTexture(pokemon) : undefined
        );
    }

    add(" ", "textures/gui/pc/pc_arrow_previous");
    add(" ", "textures/gui/pc/pc_arrow_next");
    add(" ", "textures/gui/pc/pc_icon_options");
    add(" ", "textures/gui/pc/pc_button_set_wallpaper");
    for (const mode of SORT_MODES) add(" ", sortIcon(session, mode));
    add(session.filter ? "|ON" : " ", "textures/gui/pc/pc_icon_filter");
    add(" ", "textures/gui/pc/info_arrow");
    add(" ", "textures/gui/pc/pc_release_button");
    add(" ", "textures/gui/pc/pc_release_button_confirm");
    add(" ", "textures/gui/pc/pc_release_button_confirm");
    add(" ", "textures/gui/common/back_button");

    const info = selected ? infoValues(selected) : null;
    add(" ", selected ? spriteSheetTexture(selected) : undefined);
    add(selected ? String(levelOf(selected)) : " ");
    add(selected ? pokemonName(selected) : " ");
    add(" ", selected ? ballTexture(selected) : undefined);
    add(" ", selected ? heldItemTexture(selected) : undefined);
    add(boxLabel(player, session.boxIndex));
    add(session.filter || "Filter");
    add(info ? info.nature : " ");
    add(info ? info.ability : " ");
    add(info && info.moves ? info.moves : " ");
    add(selected && session.statIndex !== STAT_INFO
        ? statValues(selected, session.statIndex) : " ");
    add(" ", `${WALLPAPER_ROOT}/${wallpaper}`);
    add(" ", `${WALLPAPER_ROOT}/${wallpaperGlowPath(wallpaper)}`);

    for (let slot = 0; slot < PC_BOX_SIZE; slot++) {
        const pokemon = box[slot] || null;
        add(" ", passesFilter(pokemon, filter) ? heldItemTexture(pokemon) : undefined);
    }
    for (let slot = 0; slot < 6; slot++) {
        const pokemon = party[slot] || null;
        add(" ", passesFilter(pokemon, filter) ? heldItemTexture(pokemon) : undefined);
    }
    return { title: buildTitle(session, selected), entries };
}

function showPC(player, session) {
    if (!player?.isValid) return;
    if (!isCurrentSession(player, session)) return;
    if (isBattlePlayer(player)) { closeSession(player, session); return; }
    if (session.chest) {
        if (!refreshChestScreen(player, PC_CHEST_KEY)) closeSession(player, session);
        return;
    }
    if (session.formOpen) return;

    const model = buildModel(player, session);
    const form = new ActionFormData().title(model.title);
    for (const entry of model.entries) form.button(entry.text, entry.texture);

    session.formOpen = true;
    sessions.set(player.id, session);
    setScreen(blockFromSession(session), true);

    form.show(player).then(response => {
        if (!isCurrentSession(player, session) || isBattlePlayer(player)) return closeSession(player, session);
        session.formOpen = false;
        if (response.canceled) {
            if (retryIfBusy(player, session, response.cancelationReason)) return;
            return closeSession(player, session);
        }
        session.busyRetries = 0;
        return handleSelection(player, session, Math.floor(Number(response.selection)));
    }).catch(error => {
        if (!isCurrentSession(player, session) || isBattlePlayer(player)) return closeSession(player, session);
        session.formOpen = false;
        if (retryIfBusy(player, session, error)) return;
        console.warn(`PC form failed: ${error}`);
        closeSession(player, session);
    });
}

function retryIfBusy(player, session, reason) {
    if (!String(reason ?? "").toLowerCase().includes("busy")) return false;
    if (!isCurrentSession(player, session) || isBattlePlayer(player)) return false;
    const retries = Math.max(0, Math.floor(Number(session.busyRetries) || 0));
    if (retries >= 4) return false;
    session.busyRetries = retries + 1;
    system.runTimeout(() => {
        if (!isCurrentSession(player, session) || isBattlePlayer(player)) return closeSession(player, session);
        showPC(player, session);
    }, 4);
    return true;
}

function handleSelection(player, session, selection) {
    if (!Number.isFinite(selection) || selection < 0 || selection >= BUTTON_COUNT) {
        return showPC(player, session);
    }
    if (selection >= IDX_BOX && selection < IDX_BOX + PC_BOX_SIZE) {
        const slot = selection - IDX_BOX;
        const box = loadPCFromPlayer(player, session.boxIndex);
        if (!renderedMatches(session, "box", slot, box[slot])) return showPC(player, session);
        return handleBoxClick(player, session, slot);
    }
    if (selection >= IDX_PARTY && selection < IDX_PARTY + 6) {
        const slot = selection - IDX_PARTY;
        const party = loadPartyFromPlayer(player);
        if (!renderedMatches(session, "party", slot, party[slot])) return showPC(player, session);
        return handlePartyClick(player, session, slot);
    }
    if (selection >= IDX_SORT && selection < IDX_SORT + SORT_MODES.length) {
        return handleSort(player, session, SORT_MODES[selection - IDX_SORT]);
    }

    switch (selection) {
        case IDX_PREV:
            playSound(player, SOUND.click);
            session.boxIndex = (session.boxIndex + PC_BOX_COUNT - 1) % PC_BOX_COUNT;
            return showPC(player, session);
        case IDX_NEXT:
            playSound(player, SOUND.click);
            session.boxIndex = (session.boxIndex + 1) % PC_BOX_COUNT;
            return showPC(player, session);
        case IDX_OPTIONS:
            return showPC(player, session);
        case IDX_WALLPAPER:
            playSound(player, SOUND.click);
            if (session.chest) return cycleWallpaper(player, session);
            return showWallpaperForm(player, session);
        case IDX_FILTER:
        case IDX_FILTER_TEXT:
            playSound(player, SOUND.click, 0.25);
            return showFilterForm(player, session);
        case IDX_INFO:
            playSound(player, SOUND.click);
            session.statIndex = (session.statIndex + 1) % 3;
            return showPC(player, session);
        case IDX_RELEASE:
            return showPC(player, session);
        case IDX_RELEASE_YES:
            return confirmRelease(player, session);
        case IDX_RELEASE_NO:
            return showPC(player, session);
        case IDX_BOX_NAME:
            return showBoxNameForm(player, session);
        case IDX_EXIT:
            return closeSession(player, session);
        default:
            return showPC(player, session);
    }
}

function handleBoxClick(player, session, slot) {
    const box = loadPCFromPlayer(player, session.boxIndex);
    const pokemon = box[slot] || null;
    const filter = parseFilter(session.filter);

    if (pokemon && !passesFilter(pokemon, filter)) {
        actionBar(player, "cobblemon.pc.filtered_out");
        return showPC(player, session);
    }
    if (session.held && !heldPokemon(player, session)) {
        session.held = null;
        return showPC(player, session);
    }

    if (!session.held) {
        if (!pokemon) {
            actionBar(player, "cobblemon.pc.empty_slot");
            return showPC(player, session);
        }
        session.held = { kind: "pc", box: session.boxIndex, slot, uuid: slotUuid(pokemon) };
        playSound(player, SOUND.grab);
        return showPC(player, session);
    }

    if (session.held.kind === "party") {
        const party = loadPartyFromPlayer(player);
        const source = session.held.slot;
        const outgoing = party[source];
        if (!outgoing) {
            session.held = null;
            return showPC(player, session);
        }
        if (CORE_CONFIG.preventCompletePartyDeposit && !pokemon && party.length <= 1) {
            actionBar(player, "cobblemon.pc.last_pokemon");
            return showPC(player, session);
        }
        const prevParty = cloneContainer(party);
        const prevBox = cloneContainer(box);
        if (pokemon) party[source] = pokemon;
        else party.splice(source, 1);
        box[slot] = outgoing;
        if (!savePartyAndBox(player, party, session.boxIndex, box, prevParty, prevBox)) {
            return saveFailed(player, session);
        }
        recallPartyPokemon(player, outgoing);
        playSound(player, SOUND.drop);
        session.held = null;
        return showPC(player, session);
    }

    const sourceBoxIndex = session.held.box;
    const sourceSlot = session.held.slot;
    const sourceBox = sourceBoxIndex === session.boxIndex ? box : loadPCFromPlayer(player, sourceBoxIndex);
    const moving = sourceBox[sourceSlot];
    if (!moving) {
        session.held = null;
        return showPC(player, session);
    }
    if (sourceBoxIndex === session.boxIndex && sourceSlot === slot) {
        session.held = null;
        return showPC(player, session);
    }

    if (sourceBoxIndex === session.boxIndex) {
        const prevBox = cloneContainer(box);
        sourceBox[sourceSlot] = pokemon || null;
        box[slot] = moving;
        if (!savePCToPlayer(player, sourceBoxIndex, sourceBox)) {
            try { savePCToPlayer(player, sourceBoxIndex, prevBox); } catch (error) {}
            return saveFailed(player, session);
        }
    } else {
        const prevSource = cloneContainer(sourceBox);
        const prevBox = cloneContainer(box);
        sourceBox[sourceSlot] = pokemon || null;
        box[slot] = moving;
        const commit = commitTwoBoxes(
            player, sourceBoxIndex, sourceBox, prevSource, session.boxIndex, box, prevBox
        );
        if (!commit.ok) return saveFailed(player, session);
    }
    playSound(player, SOUND.drop);
    session.held = null;
    return showPC(player, session);
}

function handlePartyClick(player, session, slot) {
    const party = loadPartyFromPlayer(player);
    const pokemon = party[slot] || null;
    const filter = parseFilter(session.filter);

    if (pokemon && !passesFilter(pokemon, filter)) {
        actionBar(player, "cobblemon.pc.filtered_out");
        return showPC(player, session);
    }
    if (session.held && !heldPokemon(player, session)) {
        session.held = null;
        return showPC(player, session);
    }

    if (!session.held) {
        if (!pokemon) {
            actionBar(player, "cobblemon.pc.empty_slot");
            return showPC(player, session);
        }
        session.held = { kind: "party", slot, uuid: slotUuid(pokemon) };
        playSound(player, SOUND.grab);
        return showPC(player, session);
    }

    if (session.held.kind === "party") {
        const source = session.held.slot;
        if (source !== slot && party[source] && party[slot]) {
            [party[source], party[slot]] = [party[slot], party[source]];
            if (!savePartyToPlayer(player, party)) return saveFailed(player, session);
            normalizeSelectedSlot(player, party);
            playSound(player, SOUND.drop);
        }
        session.held = null;
        return showPC(player, session);
    }

    const sourceBox = loadPCFromPlayer(player, session.held.box);
    const incoming = sourceBox[session.held.slot];
    if (!incoming) {
        session.held = null;
        return showPC(player, session);
    }

    const prevParty = cloneContainer(party);
    const prevSource = cloneContainer(sourceBox);
    if (pokemon) {
        sourceBox[session.held.slot] = pokemon;
        party[slot] = incoming;
    } else if (party.length < 6) {
        sourceBox[session.held.slot] = null;
        party.push(incoming);
    } else {
        actionBar(player, "cobblemon.pc.party_full");
        return showPC(player, session);
    }

    if (!savePartyAndBox(player, party, session.held.box, sourceBox, prevParty, prevSource)) {
        return saveFailed(player, session);
    }
    if (pokemon) recallPartyPokemon(player, pokemon);
    playSound(player, SOUND.drop);
    session.held = null;
    return showPC(player, session);
}

function handleSort(player, session, mode) {
    session.held = null;
    if (session.sortMode === mode) session.sortReverse = !session.sortReverse;
    else {
        session.sortMode = mode;
        session.sortReverse = false;
    }
    const box = loadPCFromPlayer(player, session.boxIndex);
    const sorted = sortBox(box, mode, session.sortReverse);
    if (!savePCToPlayer(player, session.boxIndex, sorted)) return saveFailed(player, session);
    playSound(player, SOUND.click);
    actionBar(player, "cobblemon.pc.sorted", [mode]);
    return showPC(player, session);
}

function confirmRelease(player, session) {
    if (!session.held || session.held.kind !== "pc") {
        return showPC(player, session);
    }
    const box = loadPCFromPlayer(player, session.held.box);
    const pokemon = box[session.held.slot];
    if (!pokemon || (session.held.uuid && slotUuid(pokemon) !== session.held.uuid)) {
        session.held = null;
            return showPC(player, session);
    }
    if (pokemon.fusionState?.partner) {
        session.held = null;
        player.sendMessage("§cUse the DNA Splicers to separate Kyurem before releasing it.");
        return showPC(player, session);
    }
    box[session.held.slot] = null;
    if (!savePCToPlayer(player, session.held.box, box)) return saveFailed(player, session);
    playSound(player, SOUND.release);
    actionBar(player, "cobblemon.pc.released", [pokemonName(pokemon)]);
    session.held = null;
    return showPC(player, session);
}

function resume(player, session, run) {
    if (!isCurrentSession(player, session) || isBattlePlayer(player)) return closeSession(player, session);
    return run();
}

function leaveChestForModal(player, session, run) {
    if (!session.chest) return run();
    session.chest = false;
    if (chestScreenActive(player, PC_CHEST_KEY)) closeChestScreen(player);
    system.runTimeout(() => {
        if (!isCurrentSession(player, session)) return;
        if (isBattlePlayer(player)) return closeSession(player, session);
        run();
    }, 8);
}

function cycleWallpaper(player, session) {
    const current = loadWallpaper(player, session.boxIndex);
    const next = WALLPAPERS[(Math.max(0, WALLPAPERS.indexOf(current)) + 1) % WALLPAPERS.length];
    if (saveWallpaper(player, session.boxIndex, next)) playSound(player, SOUND.wallpaperUnlock);
    return showPC(player, session);
}

function showFilterForm(player, session) {
    if (!player?.isValid || !isCurrentSession(player, session)) return;
    if (session.chest) return leaveChestForModal(player, session, () => showFilterForm(player, session));
    const form = new ModalFormData()
        .title("cobblemon.ui.pc.filter")
        .textField("cobblemon.ui.pc.filter.tooltip", "pikachu shiny lvl>20", String(session.filter || ""));
    form.show(player).then(response => {
        resume(player, session, () => {
            if (response.canceled) return showPC(player, session);
            const value = Array.isArray(response.formValues) ? String(response.formValues[0] || "") : "";
            session.filter = value.trim().slice(0, 48);
                    return showPC(player, session);
        });
    }).catch(() => resume(player, session, () => showPC(player, session)));
}

function showBoxNameForm(player, session) {
    if (!player?.isValid || !isCurrentSession(player, session)) return;
    if (session.chest) return leaveChestForModal(player, session, () => showBoxNameForm(player, session));
    const form = new ModalFormData()
        .title("cobbledrock.pc.rename_box")
        .textField("cobblemon.ui.pc.box.title", `Box ${session.boxIndex + 1}`, loadBoxName(player, session.boxIndex));
    form.show(player).then(response => {
        resume(player, session, () => {
            if (response.canceled) return showPC(player, session);
            const value = Array.isArray(response.formValues) ? String(response.formValues[0] || "") : "";
            saveBoxName(player, session.boxIndex, value.trim());
            return showPC(player, session);
        });
    }).catch(() => resume(player, session, () => showPC(player, session)));
}

function showWallpaperForm(player, session) {
    if (!player?.isValid || !isCurrentSession(player, session)) return;
    if (session.chest) return cycleWallpaper(player, session);
    const current = loadWallpaper(player, session.boxIndex);
    const index = Math.max(0, WALLPAPERS.indexOf(current));
    const form = new ModalFormData()
        .title("cobblemon.ui.pc.wallpaper")
        .dropdown("Wallpaper", WALLPAPERS.map(id => titleCase(id.split("/").pop())), index);
    form.show(player).then(response => {
        resume(player, session, () => {
            if (response.canceled) return showPC(player, session);
            const picked = Array.isArray(response.formValues) ? Math.floor(Number(response.formValues[0])) : -1;
            const wallpaper = WALLPAPERS[picked];
            if (wallpaper && saveWallpaper(player, session.boxIndex, wallpaper)) {
                playSound(player, SOUND.wallpaperUnlock);
            }
            return showPC(player, session);
        });
    }).catch(() => resume(player, session, () => showPC(player, session)));
}

const TEXT_CARRIERS = [IDX_LEVEL, IDX_NAME, IDX_BOX_NAME, IDX_FILTER_TEXT, IDX_NATURE, IDX_ABILITY, IDX_MOVES, IDX_STATS];
const ICON_INDICES = [
    ...Array.from({ length: 36 }, (_, i) => i),
    IDX_SORT, IDX_SORT + 1, IDX_SORT + 2, IDX_SORT + 3, IDX_SORT + 4,
    IDX_PORTRAIT, IDX_BALL, IDX_HELD_ITEM, IDX_WALLPAPER_ART, IDX_WALLPAPER_GLOW,
    ...Array.from({ length: 36 }, (_, i) => IDX_HELD_BOX + i)
];
const CAPTION_BUTTONS = [...Array.from({ length: 36 }, (_, i) => i), IDX_FILTER];
const PLAIN_BUTTONS = [
    IDX_PREV, IDX_NEXT, IDX_WALLPAPER,
    IDX_SORT, IDX_SORT + 1, IDX_SORT + 2, IDX_SORT + 3, IDX_SORT + 4,
    IDX_INFO, IDX_RELEASE_YES, IDX_RELEASE_NO, IDX_EXIT
];

const PC_CHEST_LAYOUT = Object.freeze({
    title: PC_CHEST_TITLE,
    n: STATE_SLOT + 1,
    tex: [], txt: [], cap: [],
    vis: [[IDX_OPTIONS, "#__none__"], [IDX_RELEASE, "#__none__"]],
    st: [STATE_SLOT],
    tb: CAPTION_BUTTONS.map(i => [i, i]),
    btn: PLAIN_BUTTONS.map(i => [i, i]),
    ml: TEXT_CARRIERS.map(i => [i, String(i)]),
    ic: ICON_INDICES.map(i => [ICON_BASE + i, i])
});

function pcChestMenuOn(player) {
    try { return !player.hasTag(MENU_FORM_TAG); } catch (error) { return true; }
}

function pcChestView(player, state) {
    const session = state.session;
    if (!session || !player?.isValid || isBattlePlayer(player)) {
        return { title: "", buttons: [], icons: {}, multi: {} };
    }
    const model = buildModel(player, session);
    const buttons = [];
    const icons = {};
    const multi = {};
    for (let index = 0; index < model.entries.length; index++) {
        const entry = model.entries[index];
        buttons[index] = entry.text;
        if (TEXT_CARRIERS.includes(index)) multi[String(index)] = entry.text;
        if (entry.texture) icons[index] = entry.texture;
    }
    return { title: model.title, buttons, icons, multi };
}

function pcChestPress(player, state, button) {
    const session = state.session;
    if (!session || !isCurrentSession(player, session)) return "close";
    if (isBattlePlayer(player)) {
        closeSession(player, session);
        return "close";
    }
    handleSelection(player, session, button);
    return isCurrentSession(player, session) && session.chest ? "redraw" : "close";
}

registerChestScreen({
    key: PC_CHEST_KEY,
    layout: PC_CHEST_LAYOUT,
    wants: () => false,
    create: player => ({ session: sessions.get(player.id) || null }),
    view: pcChestView,
    press: pcChestPress,
    onOpen: (player, state) => {
        const session = state?.session || sessions.get(player?.id);
        if (session) setScreen(blockFromSession(session), true);
    }
});

function anchorsAt(dimension, bottom) {
    try {
        return dimension.getEntities({
            type: PC_ANCHOR_TYPE,
            location: { x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 },
            maxDistance: 1.6
        });
    } catch (error) {
        return [];
    }
}

function hideAnchor(entity) {
    try {
        entity.addEffect("invisibility", 20000000, { amplifier: 0, showParticles: false });
    } catch (error) {}
}

function alignAnchor(entity, bottom) {
    try {
        if (Math.abs(entity.location.y - (bottom.y + 1)) > 0.05) {
            entity.teleport({ x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 });
        }
    } catch (error) {}
}

function ensurePcAnchor(dimension, bottom) {
    try {
        const found = anchorsAt(dimension, bottom);
        if (found.length) {
            for (let index = 1; index < found.length; index++) {
                try { found[index].remove(); } catch (error) {}
            }
            alignAnchor(found[0], bottom);
            hideAnchor(found[0]);
            return found[0];
        }
        const entity = dimension.spawnEntity(PC_ANCHOR_TYPE, { x: bottom.x + 0.5, y: bottom.y + 1, z: bottom.z + 0.5 });
        try { entity.nameTag = PC_CHEST_TITLE; } catch (error) {}
        hideAnchor(entity);
        return entity;
    } catch (error) {
        return undefined;
    }
}

function removePcAnchors(dimension, bottom) {
    for (const entity of anchorsAt(dimension, bottom)) {
        try { entity.remove(); } catch (error) {}
    }
}

function bottomBlockOfAnchor(entity) {
    try {
        const { x, y, z } = entity.location;
        const here = entity.dimension.getBlock({ x: Math.floor(x), y: Math.floor(y + 0.01), z: Math.floor(z) });
        if (here?.typeId === TOP_BLOCK_ID) {
            return entity.dimension.getBlock({ x: Math.floor(x), y: Math.floor(y + 0.01) - 1, z: Math.floor(z) });
        }
        return here;
    } catch (error) {
        return undefined;
    }
}

registerFixedAnchor(PC_ANCHOR_TYPE, (player, entity) => {
    if (!player?.isValid || player.typeId !== "minecraft:player") return;
    const block = bottomBlockOfAnchor(entity);
    if (block?.typeId !== BLOCK_ID) {
        try { entity.remove(); } catch (error) {}
        return;
    }
    if (isBattlePlayer(player)) {
        actionBar(player, "cobblemon.pc.inbattle");
        return;
    }
    const key = blockKey(block);
    for (const [playerId, other] of sessions) {
        if (playerId !== player.id && other.chest && other.blockKey === key) {
            actionBar(player, "cobblemon.pc.busy");
            return;
        }
    }
    const session = sessions.get(player.id) || newSession();
    session.dimensionId = block.dimension.id;
    session.location = { ...block.location };
    session.blockKey = key;
    session.remote = false;
    session.chest = true;
    session.formOpen = false;
    sessions.set(player.id, session);
    const dimension = block.dimension;
    const bottom = { ...block.location };
    const attached = attachChestScreen(player, PC_CHEST_KEY, entity, {
        state: { session },
        hold: 1200,
        onRelease: () => system.run(() => {
            try {
                if (dimension.getBlock(bottom)?.typeId === BLOCK_ID) ensurePcAnchor(dimension, bottom);
            } catch (error) {}
        })
    });
    if (!attached) {
        session.chest = false;
        return;
    }
    setScreen(block, true);
    playSound(player, SOUND.on);
});

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    if (event.target?.typeId !== PC_ANCHOR_TYPE) return;
    const player = event.player;
    let formUser = false;
    try { formUser = player.hasTag(MENU_FORM_TAG); } catch (error) {}
    if (!formUser) return;
    event.cancel = true;
    const block = bottomBlockOfAnchor(event.target);
    system.run(() => { if (block?.typeId === BLOCK_ID) openPC(player, block); });
});

function startPcChest(player, session) {
    if (!pcChestMenuOn(player)) return false;
    session.chest = true;
    session.formOpen = false;
    sessions.set(player.id, session);
    if (!openChestScreen(player, PC_CHEST_KEY, { hold: 600, state: { session } })) {
        session.chest = false;
        return false;
    }
    return true;
}

system.runInterval(() => {
    for (const [playerId, session] of [...sessions]) {
        if (!session.chest) continue;
        const player = world.getAllPlayers().find(entry => entry.id === playerId);
        if (player?.isValid && chestScreenActive(player, PC_CHEST_KEY)) continue;
        sessions.delete(playerId);
        setScreen(blockFromSession(session), false);
    }
}, 10);

function openPC(player, block) {
    if (!player?.isValid || block?.typeId !== BLOCK_ID) return;
    ensureTop(block);
    ensurePcAnchor(block.dimension, block.location);
    if (player.hasTag(BATTLE_TAG)) {
        actionBar(player, "cobblemon.pc.inbattle");
        return;
    }
    const session = sessions.get(player.id) || newSession();
    session.dimensionId = block.dimension.id;
    session.location = { ...block.location };
    session.blockKey = blockKey(block);
    session.remote = false;
    session.formOpen = false;
    sessions.set(player.id, session);
    if (startPcChest(player, session)) return;
    session.chest = false;
    playSound(player, SOUND.on);
    showPC(player, session);
}

export function openRemotePC(player) {
    if (!CORE_CONFIG.remotePcEnabled || player?.typeId !== "minecraft:player" || !player.isValid) return false;
    if (player.hasTag(BATTLE_TAG)) {
        actionBar(player, "cobblemon.pc.inbattle");
        return false;
    }
    const session = sessions.get(player.id) || newSession();
    delete session.dimensionId;
    delete session.location;
    delete session.blockKey;
    session.remote = true;
    session.formOpen = false;
    sessions.set(player.id, session);
    if (startPcChest(player, session)) return true;
    session.chest = false;
    playSound(player, SOUND.on);
    showPC(player, session);
    return true;
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== "lota:pc") return;
    openRemotePC(event.sourceEntity);
});

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    if (event.itemStack?.typeId !== BLOCK_ID) return;
    event.cancel = true;
    if (event.isFirstEvent === false) return;

    const offset = FACE_OFFSETS[event.blockFace];
    if (!offset) return;
    const { x, y, z } = event.block.location;
    const location = { x: x + offset.x, y: y + offset.y, z: z + offset.z };
    const player = event.player;
    const dimension = event.block.dimension;
    const slot = player.selectedSlotIndex;
    system.run(() => placePcPair(player, dimension, location, slot));
});

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    if (![BLOCK_ID, TOP_BLOCK_ID].includes(event.block.typeId) || event.isFirstEvent === false) return;
    event.cancel = true;
    const player = event.player;
    const location = {
        ...event.block.location,
        y: event.block.location.y - (event.block.typeId === TOP_BLOCK_ID ? 1 : 0)
    };
    const dimension = event.block.dimension;
    system.run(() => openPC(player, dimension.getBlock(location)));
});

world.afterEvents.playerPlaceBlock.subscribe(event => {
    if (event.block.typeId !== BLOCK_ID) return;
    if (ensureTop(event.block)) return;
    const { x, y, z } = event.block.location;
    try {
        event.block.setType("minecraft:air");
        returnPcItem(event.player, event.block.dimension, { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
    } catch (error) {
        console.warn(`Failed to roll back obstructed PC placement at ${x},${y},${z}: ${error}`);
    }
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    const brokenType = event.brokenBlockPermutation.type.id;
    if (![BLOCK_ID, TOP_BLOCK_ID].includes(brokenType)) return;
    const dimension = event.block.dimension;
    const location = { ...event.block.location };
    const bottomLocation = {
        ...location,
        y: location.y - (brokenType === TOP_BLOCK_ID ? 1 : 0)
    };
    const creative = isCreative(event.player);

    system.run(() => {
        try { removePcAnchors(dimension, bottomLocation); } catch (error) {}
        try {
            if (brokenType === BLOCK_ID) {
                const top = dimension.getBlock({ ...location, y: location.y + 1 });
                if (top?.typeId === TOP_BLOCK_ID) top.setType("minecraft:air");
            } else {
                const bottom = dimension.getBlock(bottomLocation);
                if (bottom?.typeId === BLOCK_ID) {
                    bottom.setType("minecraft:air");
                    if (!creative) {
                        dimension.spawnItem(new ItemStack(BLOCK_ID, 1), {
                            x: bottomLocation.x + 0.5,
                            y: bottomLocation.y + 0.5,
                            z: bottomLocation.z + 0.5
                        });
                    }
                }
            }
        } catch (error) {}
    });

    const brokenKey = `${dimension.id}:${bottomLocation.x},${bottomLocation.y},${bottomLocation.z}`;
    for (const [playerId, session] of sessions) {
        if (session.blockKey === brokenKey) {
            sessions.delete(playerId);
            if (session.chest) closeChestScreen(playerId);
        }
    }
});

world.afterEvents.playerLeave.subscribe(event => {
    const session = sessions.get(event.playerId);
    sessions.delete(event.playerId);
    if (session) setScreen(blockFromSession(session), false);
    if (session?.chest) closeChestScreen(event.playerId);
});
