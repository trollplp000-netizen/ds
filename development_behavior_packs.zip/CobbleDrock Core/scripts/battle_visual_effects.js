import { system } from "@minecraft/server";
import { ORIGINAL_BATTLE_EFFECT_DATA } from "./battle_effect_data.js";
import { pokemonModelVariant } from './pokemon_visual_state.js';

const EFFECT_ANCHOR_PREFIX = "lota:battle_effect_anchor";
const GENERIC_IMPACT_TICK = 24;
const GENERIC_DURATION_TICKS = 66;
const ANCHOR_TAIL_TICKS = 20;
const ANCHOR_SYNC_DELAY_TICKS = 2;
const MOVE_PROJECTILE_TYPE = "lota:battle_move_projectile";
const MOVE_LOCKED_BATTLE_QUIRK_SPECIES = new Set([
    "lota:blastoise",
    "lota:charizard",
    "lota:gyarados",
    "lota:pikachu",
    "lota:porygon",
    "lota:rhydon"
]);
const ENTITY_PROJECTILE_MOVES = Object.freeze({
    ember: Object.freeze({
        launchTick: 25,
        impactTick: 35,
        particles: Object.freeze([
            "lota:ember_projectile_fire",
            "lota:ember_projectile_sparks"
        ])
    })
});

function validEntity(entity) {
    if (!entity) return false;
    try {
        return typeof entity.isValid !== "function" || entity.isValid();
    } catch (error) {
        return false;
    }
}

function setBattleActing(entity, active) {
    if (!validEntity(entity) || !MOVE_LOCKED_BATTLE_QUIRK_SPECIES.has(entity.typeId)) return;
    try { entity.setProperty("lota:battle_acting", active === true); } catch (error) {}
}

function clamp(value, minimum, maximum, fallback = minimum) {
    const number = Number(value);
    return Math.max(minimum, Math.min(maximum, Number.isFinite(number) ? number : fallback));
}

function entityMetrics(entity) {
    let width = 0.8;
    let height = 1;
    try {
        if (typeof entity.getAABB === "function") {
            const extent = entity.getAABB()?.extent;
            if (extent) {
                width = Math.max(Number(extent.x) || 0, Number(extent.z) || 0) * 2 || width;
                height = (Number(extent.y) || 0) * 2 || height;
            }
        }
    } catch (error) {}
    try {
        const headHeight = Number(entity.getHeadLocation()?.y) - Number(entity.location?.y);
        if (Number.isFinite(headHeight) && headHeight > 0) height = Math.max(height, headHeight);
    } catch (error) {}
    let scale = 1;
    try {
        scale = Number(entity.getProperty("lota:scale_factor")) || 1;
    } catch (error) {}
    width = clamp(width, 0.4, 6, 0.8);
    height = clamp(height, 0.5, 10, 1);
    return {
        width,
        height,
        radius: clamp(Math.max(width * 0.6, height * 0.35), 0.5, 3, 0.5),
        scale: clamp(scale, 0.01, 8, 1)
    };
}

function locatorLocation(entity, locator) {
    if (!validEntity(entity)) return undefined;
    const base = entity.location;
    const metrics = entityMetrics(entity);
    const name = String(locator || "middle").toLowerCase();
    let fraction = 0.5;
    if (name === "root") fraction = 0.08;
    else if (name === "top") fraction = 0.95;
    else if (["special", "mouth", "eye", "face"].includes(name)) fraction = 0.75;
    else if (name === "target") fraction = 0.55;
    try {
        if (["special", "mouth", "eye", "face", "top"].includes(name)) {
            const head = entity.getHeadLocation();
            if (head) return { x: Number(head.x), y: Number(head.y), z: Number(head.z) };
        }
    } catch (error) {}
    return {
        x: Number(base.x),
        y: Number(base.y) + metrics.height * fraction,
        z: Number(base.z)
    };
}

function faceLocation(entity, origin, target) {
    if (!validEntity(entity) || !origin || !target) return;
    const dx = Number(target.x) - Number(origin.x);
    const dy = Number(target.y) - Number(origin.y);
    const dz = Number(target.z) - Number(origin.z);
    const horizontal = Math.max(0.001, Math.hypot(dx, dz));
    try {
        entity.setRotation({
            x: -Math.atan2(dy, horizontal) * 180 / Math.PI,
            y: Math.atan2(-dx, dz) * 180 / Math.PI
        });
    } catch (error) {}
}

function interpolateLocation(origin, target, progress) {
    const amount = clamp(progress, 0, 1, 0);
    return {
        x: Number(origin.x) + (Number(target.x) - Number(origin.x)) * amount,
        y: Number(origin.y) + (Number(target.y) - Number(origin.y)) * amount,
        z: Number(origin.z) + (Number(target.z) - Number(origin.z)) * amount
    };
}

function removeEntity(entity) {
    if (!validEntity(entity)) return;
    try { entity.remove(); } catch (error) {}
}

function moveEntity(entity, location) {
    if (!validEntity(entity) || !location) return false;
    try {
        if (typeof entity.tryTeleport === "function") {
            return entity.tryTeleport(location, {
                dimension: entity.dimension,
                keepVelocity: false
            }) !== false;
        }
        entity.teleport(location, {
            dimension: entity.dimension,
            keepVelocity: false
        });
        return true;
    } catch (error) {
        return false;
    }
}

function emitProjectileParticles(projectile, particleIds) {
    if (!validEntity(projectile)) return false;
    let emitted = false;
    for (const particleId of particleIds || []) {
        try {
            projectile.dimension.spawnParticle(String(particleId), projectile.location);
            emitted = true;
        } catch (error) {
            console.warn(`[BattleEffects] Failed to emit ${particleId} from ${projectile.typeId}: ${error}`);
        }
    }
    return emitted;
}

function spawnMovingProjectile(config, owner, counterpart, locator, shouldPlay) {
    if (!config || !validEntity(owner) || !validEntity(counterpart)) return false;
    const origin = locatorLocation(owner, locator);
    const target = locatorLocation(counterpart, "target");
    if (!origin || !target) return false;
    let projectile;
    try {
        projectile = owner.dimension.spawnEntity(MOVE_PROJECTILE_TYPE, origin);
    } catch (error) {
        console.warn(`[BattleEffects] Failed to spawn ${MOVE_PROJECTILE_TYPE}: ${error}`);
        return false;
    }
    faceLocation(projectile, origin, target);
    const travelTicks = Math.max(1, Math.round(Number(config.impactTick) - Number(config.launchTick)));
    let elapsedTicks = 0;
    let intervalId;
    const cleanup = () => {
        if (intervalId !== undefined) system.clearRun(intervalId);
        intervalId = undefined;
        removeEntity(projectile);
    };
    emitProjectileParticles(projectile, config.particles);
    intervalId = system.runInterval(() => {
        if (!validEntity(projectile) || (typeof shouldPlay === "function" && !shouldPlay())) {
            cleanup();
            return;
        }
        elapsedTicks += 1;
        const progress = Math.min(1, elapsedTicks / travelTicks);
        if (!moveEntity(projectile, interpolateLocation(origin, target, progress))) {
            cleanup();
            return;
        }
        if (elapsedTicks < travelTicks) emitProjectileParticles(projectile, config.particles);
        else cleanup();
    }, 1);
    system.runTimeout(() => {
        if (validEntity(projectile)) cleanup();
    }, travelTicks + 2);
    return true;
}

function setAnchorProperty(anchor, identifier, value) {
    try {
        anchor.setProperty(identifier, value);
        return true;
    } catch (error) {
        console.warn(`[BattleEffects] Failed to set ${identifier} on ${anchor?.typeId || "effect anchor"}: ${error}`);
        return false;
    }
}

function spawnEffectAnchor(effect, owner, counterpart, locator, lifetimeTicks, triggerDelayTicks, shouldPlay) {
    if (!validEntity(owner)) return;
    const origin = locatorLocation(owner, locator);
    const target = locatorLocation(counterpart, "target") || origin;
    if (!origin || !target) return;
    const effectNumber = clamp(effect, 1, ORIGINAL_BATTLE_EFFECT_DATA.effectCount, 1);
    const bankSize = clamp(ORIGINAL_BATTLE_EFFECT_DATA.effectBankSize, 1, 64, 16);
    const bank = Math.floor((effectNumber - 1) / bankSize);
    const slot = ((effectNumber - 1) % bankSize) + 1;
    const suffix = String(bank).padStart(2, "0");
    const anchorType = `${EFFECT_ANCHOR_PREFIX}_${suffix}`;
    const effectAnimation = `animation.lota.battle_effect_anchor_${suffix}.fx_${slot}`;
    const triggerDelay = Math.max(0, Math.round(Number(triggerDelayTicks) || 0));
    for (const cue of ORIGINAL_BATTLE_EFFECT_DATA.effectSounds?.[String(effectNumber)] || []) {
        scheduleAtTick(() => {
            if (!validEntity(owner) || (typeof shouldPlay === "function" && !shouldPlay())) return;
            playSoundAtLocation(cue.sound, owner.dimension, origin);
        }, triggerDelay + Math.max(0, Math.round(Number(cue.tick) || 0)));
    }
    let anchor;
    try {
        anchor = owner.dimension.spawnEntity(anchorType, origin);
    } catch (error) {
        console.warn(`[BattleEffects] Failed to spawn ${anchorType}: ${error}`);
        return;
    }
    const metrics = entityMetrics(owner);
    const dx = Number(target.x) - Number(origin.x);
    const dy = Number(target.y) - Number(origin.y);
    const dz = Number(target.z) - Number(origin.z);
    const distance = clamp(Math.hypot(dx, dz), 0, 64, 1);
    const configured = [
        setAnchorProperty(anchor, "lota:target_distance", distance),
        setAnchorProperty(anchor, "lota:target_height_delta", clamp(dy, -32, 32, 0)),
        setAnchorProperty(anchor, "lota:entity_height", metrics.height),
        setAnchorProperty(anchor, "lota:entity_width", metrics.width),
        setAnchorProperty(anchor, "lota:entity_radius", metrics.radius),
        setAnchorProperty(anchor, "lota:entity_scale", metrics.scale)
    ].every(Boolean);
    if (!configured) {
        try { anchor.remove(); } catch (error) {}
        return;
    }
    faceLocation(anchor, origin, target);
    scheduleAtTick(() => {
        if (!validEntity(anchor) || (typeof shouldPlay === "function" && !shouldPlay())) {
            try { anchor.remove(); } catch (error) {}
            return;
        }
        if (!playAnimationOnChannel(effectAnimation, anchor, `effect_${suffix}`, { blendOutTime: 0 })) {
            console.warn(`[BattleEffects] Failed to play ${effectAnimation}`);
        }
    }, triggerDelay);
    system.runTimeout(() => {
        if (!validEntity(anchor)) return;
        try {
            anchor.remove();
        } catch (error) {}
    }, Math.max(ANCHOR_TAIL_TICKS, Number(lifetimeTicks) || 0) + triggerDelay);
}

function playSoundAtLocation(sound, dimension, location) {
    if (!sound || !dimension || !location) return;
    try {
        dimension.playSound(String(sound), location, { volume: 1, pitch: 1 });
    } catch (error) {}
}

function playSound(sound, owner, locator) {
    if (!sound || !validEntity(owner)) return;
    const location = locatorLocation(owner, locator);
    if (!location) return;
    try {
        owner.dimension.playSound(String(sound), location, { volume: 1, pitch: 1 });
    } catch (error) {}
}

function playAnimationOnChannel(animation, actor, channel = "body", options = {}) {
    try {
        actor.playAnimation(animation, {
            controller: `controller.animation.lota.battle_${channel}`,
            blendOutTime: Number.isFinite(Number(options.blendOutTime)) ? Number(options.blendOutTime) : 0.1,
            ...(options.stopExpression ? { stopExpression: String(options.stopExpression) } : {})
        });
        return true;
    } catch (error) {
        return false;
    }
}

function playMoveAnimation(candidates, actor, channel = "body", options = {}) {
    if (!validEntity(actor)) return false;
    const species = String(actor.typeId || "").replace(/^lota:/, "");
    let form = null;
    try {
        const stored = actor.getDynamicProperty('lota:pokemon_data');
        if (stored) form = pokemonModelVariant(JSON.parse(stored));
    } catch (error) {}
    const mappings = form?.animations || ORIGINAL_BATTLE_EFFECT_DATA.pokemonAnimations?.[species];
    for (const candidate of candidates || []) {
        const requested = String(candidate);
        const animation = requested.startsWith("animation.") ? requested : mappings?.[requested];
        if (!animation) continue;
        return playAnimationOnChannel(animation, actor, channel, options);
    }
    if ((candidates || []).some(candidate => String(candidate).toLowerCase() === "cry")) {
        try {
            actor.dimension.playSound(`pokemon.${species}.cry`, actor.location, { volume: 0.8, pitch: 1 });
            return true;
        } catch (error) {}
    }
    return false;
}

function genericTimeline(move) {
    const category = String(move?.category || "status").toLowerCase();
    const type = String(move?.type || "normal").toLowerCase();
    const events = [{
        tick: 0,
        role: "actor",
        hitOnly: false,
        animations: [String(move?.id || "").toLowerCase(), category]
    }];
    if (category !== "status") {
        const effect = ORIGINAL_BATTLE_EFFECT_DATA.genericEffects[type];
        const sound = ORIGINAL_BATTLE_EFFECT_DATA.genericSounds[type];
        if (sound) events.push({ tick: GENERIC_IMPACT_TICK, role: "target", hitOnly: true, sound, locator: "target" });
        if (effect) events.push({ tick: GENERIC_IMPACT_TICK, role: "target", hitOnly: true, effect, locator: "target" });
        if (ORIGINAL_BATTLE_EFFECT_DATA.genericHitEffect) {
            events.push({
                tick: GENERIC_IMPACT_TICK,
                role: "target",
                hitOnly: true,
                effect: ORIGINAL_BATTLE_EFFECT_DATA.genericHitEffect,
                locator: "target"
            });
        }
    }
    return { impactTicks: GENERIC_IMPACT_TICK, durationTicks: GENERIC_DURATION_TICKS, events };
}

function scheduleAtTick(callback, delay) {
    const ticks = Math.max(0, Math.round(Number(delay) || 0));
    if (ticks === 0) callback();
    else system.runTimeout(callback, ticks);
}

export function playOriginalPokemonBattleAnimation(entity, ...candidates) {
    const requested = candidates.flat();
    const faint = requested.some(candidate => String(candidate).toLowerCase() === "faint");
    return playMoveAnimation(requested, entity, "body", faint ? {
        blendOutTime: 0,
        stopExpression: "q.property('lota:in_battle') == 0.0"
    } : {});
}

export function playOriginalBattleStatChangeEffect(entity, amount, isValid = () => true, startDelayTicks = 0) {
    const timeline = ORIGINAL_BATTLE_EFFECT_DATA.misc?.[Number(amount) > 0 ? "boost" : "unboost"];
    if (!timeline || !validEntity(entity)) return Object.freeze({ releaseTicks: 0, durationTicks: 0 });
    const startDelay = Math.max(0, Math.round(Number(startDelayTicks) || 0));
    for (const event of timeline.events || []) {
        const eventTick = Math.max(0, Math.round(Number(event.tick) || 0));
        const preparationTick = event.effect
            ? Math.max(0, eventTick - ANCHOR_SYNC_DELAY_TICKS)
            : eventTick;
        scheduleAtTick(() => {
            if (!isValid()) return;
            if (event.animations) {
                playMoveAnimation(event.animations, entity);
            } else if (event.directAnimation) {
                playMoveAnimation([event.directAnimation], entity, event.animationChannel || "root");
            } else if (event.effect) {
                const triggerDelay = Math.max(ANCHOR_SYNC_DELAY_TICKS, eventTick - preparationTick);
                spawnEffectAnchor(
                    event.effect,
                    entity,
                    entity,
                    event.locator,
                    Number(timeline.durationTicks) - eventTick + ANCHOR_TAIL_TICKS,
                    triggerDelay,
                    isValid
                );
            } else if (event.sound) {
                playSound(event.sound, entity, event.locator);
            }
        }, startDelay + preparationTick);
    }
    return Object.freeze({
        releaseTicks: Math.max(0, Number(timeline.releaseTicks) || 0),
        durationTicks: Math.max(0, Number(timeline.durationTicks) || 0)
    });
}

export function playOriginalBattleMoveEffect({ move, actorEntity, defenderEntity, hit = true, hurt = true, isValid = () => true }) {
    const moveId = String(move?.id || "").toLowerCase();
    const authored = ORIGINAL_BATTLE_EFFECT_DATA.moves[moveId];
    const timeline = authored || genericTimeline(move);
    const projectileConfig = ENTITY_PROJECTILE_MOVES[moveId];
    const impactTicks = Math.max(0, Number(timeline.impactTicks) || 0);
    const durationTicks = Math.max(impactTicks, Number(timeline.durationTicks) || 0);
    setBattleActing(actorEntity, true);
    setBattleActing(defenderEntity, true);
    system.runTimeout(() => {
        setBattleActing(actorEntity, false);
        setBattleActing(defenderEntity, false);
    }, Math.max(1, durationTicks));
    for (const event of timeline.events || []) {
        if (event.hitOnly && !hit) continue;
        if (event.hurtOnly && !hurt) continue;
        const eventTick = Math.max(0, Math.round(Number(event.tick) || 0));
        const isEntityProjectileEvent = Boolean(
            projectileConfig
            && event.effect
            && event.role === "actor"
            && eventTick === projectileConfig.launchTick
        );
        const preparationTick = event.effect && !isEntityProjectileEvent
            ? Math.max(0, eventTick - ANCHOR_SYNC_DELAY_TICKS)
            : eventTick;
        scheduleAtTick(() => {
            if (!isValid()) return;
            const owner = event.role === "target" ? defenderEntity : actorEntity;
            const counterpart = event.role === "target" ? actorEntity : defenderEntity;
            if (event.animations) {
                playMoveAnimation(event.animations, owner);
            } else if (event.directAnimation) {
                playMoveAnimation([event.directAnimation], owner, event.animationChannel || "root");
            } else if (event.effect) {
                if (isEntityProjectileEvent) {
                    spawnMovingProjectile(projectileConfig, owner, counterpart, event.locator, isValid);
                    return;
                }
                const triggerDelay = Math.max(ANCHOR_SYNC_DELAY_TICKS, eventTick - preparationTick);
                spawnEffectAnchor(
                    event.effect,
                    owner,
                    counterpart,
                    event.locator,
                    durationTicks - eventTick + ANCHOR_TAIL_TICKS,
                    triggerDelay,
                    isValid
                );
            } else if (event.sound) {
                playSound(event.sound, owner, event.locator);
            }
        }, preparationTick);
    }
    const releaseTicks = Math.max(impactTicks, Number(timeline.releaseTicks) || 0);
    return Object.freeze({ impactTicks, releaseTicks, durationTicks, authored: Boolean(authored) });
}
