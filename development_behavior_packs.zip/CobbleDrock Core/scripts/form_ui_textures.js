import { SPECIES_DATA, speciesPortraitGlyph } from "./species_registry.js";
import { pokemonModelVariant } from "./pokemon_visual_state.js";

const FORM_UI_TEXTURE_ROOT = "textures/gui/pokemon_form_ui";

function normalizedSpeciesKey(value) {
    const source = typeof value === "string" ? value : value?.species;
    return String(source || "unknown").replace(/^.*:/, "").toLowerCase();
}

export function pokemonFormTextureByDex(value) {
    const dex = Math.floor(Number(value));
    const textureId = Number.isInteger(dex) && dex > 0 && dex <= 1025
        ? String(dex).padStart(3, "0")
        : "000";
    return `${FORM_UI_TEXTURE_ROOT}/${textureId}`;
}

export function regionalFormTexture(pokemonOrSpecies) {
    const source = typeof pokemonOrSpecies === "string"
        ? pokemonOrSpecies
        : (pokemonOrSpecies?.species ?? pokemonOrSpecies?.id);
    const key = String(source || "").replace(/^.*:/, "").toLowerCase();
    return key && speciesPortraitGlyph(key) > 0 ? `${FORM_UI_TEXTURE_ROOT}/${key}` : "";
}

export function pokemonFormTexture(pokemonOrSpecies) {
    const variant = pokemonModelVariant(pokemonOrSpecies);
    if (variant) return `${FORM_UI_TEXTURE_ROOT}/${variant.textureId}`;
    const regional = regionalFormTexture(pokemonOrSpecies);
    if (regional) return regional;
    const directDex = Math.floor(Number(pokemonOrSpecies?.pokedex));
    if (Number.isInteger(directDex) && directDex > 0) {
        return pokemonFormTextureByDex(directDex);
    }
    const data = SPECIES_DATA[normalizedSpeciesKey(pokemonOrSpecies)];
    return pokemonFormTextureByDex(data?.pokedex);
}
