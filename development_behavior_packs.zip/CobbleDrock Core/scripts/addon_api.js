import { ScriptEventSource, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { activeMegaSpecies } from "./mega_evolution.js";
import { SPECIES_REGISTER_REQUEST_EVENT, SPECIES_REGISTER_RESULT_EVENT } from "./species_registry.js";
import { MOVE_REGISTER_REQUEST_EVENT, MOVE_REGISTER_RESULT_EVENT } from "./move_registry.js";
import {
    PC_BOX_COUNT,
    PC_BOX_SIZE,
    loadPartyFromPlayer,
    loadPCFromPlayer,
    loadPokemonFromEntity,
    savePartyToPlayer,
    savePCToPlayer,
    savePokemonToEntity,
    subscribePokemonStorageSaved
} from "./storage.js";

export const ADDON_API_VERSION = 1;
export const ADDON_CAPABILITIES_REQUEST_EVENT = "lota:server_addon_capabilities_request_v1";
export const ADDON_CAPABILITIES_RESULT_EVENT = "lota:server_addon_capabilities_result_v1";
export const POKEMON_DATA_REQUEST_EVENT = "lota:server_pokemon_data_request_v1";
export const POKEMON_DATA_RESULT_EVENT = "lota:server_pokemon_data_result_v1";
export const POKEMON_STORAGE_CHANGED_EVENT = "lota:server_pokemon_storage_changed_v1";
export const POKEMON_ACTION_REGISTER_EVENT = "lota:server_pokemon_action_register_v1";
export const POKEMON_ACTION_REGISTER_RESULT_EVENT = "lota:server_pokemon_action_register_result_v1";
export const POKEMON_ACTION_INVOKED_EVENT = "lota:server_pokemon_action_invoked_v1";

export const MAX_ADDON_METADATA_BYTES = 2048;
export const MAX_ADDON_METADATA_TOTAL_BYTES = 8192;
export const MAX_ADDON_METADATA_PROVIDERS = 16;
export const MAX_ACTIONS_PER_ADDON = 8;
export const MAX_REGISTERED_ACTIONS = 32;
export const MAX_STORAGE_RECORD_BYTES = 30000;

const MAX_INLINE_RESULT_BYTES = 1800;
const MAX_RESULT_CHUNK_BYTES = 700;
const MAX_REQUEST_CHUNKS = 16;
const MAX_REQUEST_CHUNK_BYTES = 700;
const REQUEST_CHUNK_TTL_TICKS = 200;

const PARTY_DIMENSION_IDS = Object.freeze([
    "minecraft:overworld", "minecraft:nether", "minecraft:the_end",
    "overworld", "nether", "the_end",
    "lota:wild_world", "lota:island_world"
]);
const registeredPokemonActions = new Map();
const pendingStorageEvents = new Set();
const pendingRequestChunks = new Map();
let transferSequence = 0;

function parseMessage(message) {
    try {
        const value = JSON.parse(String(message || "{}"));
        return value && typeof value === "object" && !Array.isArray(value) ? value : undefined;
    } catch (error) {
        return undefined;
    }
}

function cleanText(value, maximumLength = 80) {
    return String(value || "").trim().slice(0, maximumLength);
}

function cleanKey(value, maximumLength = 64) {
    const key = cleanText(value, maximumLength).toLowerCase();
    if (["__proto__", "prototype", "constructor"].includes(key)) return "";
    return /^[a-z0-9][a-z0-9_.:-]*$/.test(key) ? key : "";
}

function cleanSpecies(value) {
    return cleanText(value, 96).replace(/^.*:/, "").toLowerCase();
}

function cleanStringList(value, maximumEntries, maximumLength, cleaner = cleanText) {
    if (!Array.isArray(value)) return [];
    return [...new Set(value
        .map(entry => cleaner(entry, maximumLength))
        .filter(Boolean))]
        .slice(0, maximumEntries);
}

function finiteInteger(value, fallback = 0, minimum = -2147483648, maximum = 2147483647) {
    const number = Math.floor(Number(value));
    return Number.isFinite(number) ? Math.max(minimum, Math.min(maximum, number)) : fallback;
}

function utf8ByteLength(value) {
    let bytes = 0;
    for (const character of String(value || "")) {
        const codePoint = character.codePointAt(0);
        bytes += codePoint <= 0x7f ? 1 : codePoint <= 0x7ff ? 2 : codePoint <= 0xffff ? 3 : 4;
    }
    return bytes;
}

function splitByUtf8Bytes(value, maximumBytes) {
    const chunks = [];
    let chunk = "";
    let bytes = 0;
    for (const character of String(value || "")) {
        const characterBytes = utf8ByteLength(character);
        if (chunk && bytes + characterBytes > maximumBytes) {
            chunks.push(chunk);
            chunk = "";
            bytes = 0;
        }
        chunk += character;
        bytes += characterBytes;
    }
    if (chunk || !chunks.length) chunks.push(chunk);
    return chunks;
}

function playerById(playerId) {
    const id = String(playerId || "");
    return id ? world.getAllPlayers().find(player => String(player.id) === id) : undefined;
}

function partyDimensions() {
    const found = new Map();
    for (const dimensionId of PARTY_DIMENSION_IDS) {
        try {
            const dimension = world.getDimension(dimensionId);
            found.set(String(dimension.id), dimension);
        } catch (error) {}
    }
    return [...found.values()];
}

function summonedEntity(playerId, pokemonUuid) {
    for (const dimension of partyDimensions()) {
        for (const entity of dimension.getEntities({ tags: ["lota:party_pokemon"] })) {
            try {
                if (String(entity.getDynamicProperty("lota:party_owner_id") || "") !== String(playerId)) continue;
                if (String(loadPokemonFromEntity(entity)?.uuid || "") === String(pokemonUuid || "")) return entity;
            } catch (error) {}
        }
    }
    return undefined;
}

function cleanStats(stats) {
    const output = {};
    for (const key of ["hp", "attack", "defence", "specialAttack", "specialDefence", "speed"]) {
        output[key] = finiteInteger(stats?.[key], 0, 0, key === "hp" ? 65535 : 65535);
    }
    return output;
}

function cleanSkin(pokemon) {
    const skinIndex = finiteInteger(pokemon?.cosmeticSkin?.skinIndex, 0, 0, 255);
    return {
        providerId: skinIndex ? cleanKey(pokemon?.cosmeticSkin?.providerId) : "",
        skinId: skinIndex ? cleanKey(pokemon?.cosmeticSkin?.skinId) : "",
        skinIndex
    };
}

export function pokemonAddonSnapshot(pokemon, location = {}) {
    if (!pokemon?.uuid) return undefined;
    const species = cleanSpecies(pokemon.species);
    const megaSpecies = cleanSpecies(activeMegaSpecies(pokemon));
    const addonData = pokemon.addonData && typeof pokemon.addonData === "object" && !Array.isArray(pokemon.addonData)
        ? pokemon.addonData
        : {};
    return {
        pokemonUuid: cleanText(pokemon.uuid, 96),
        location: cleanText(location.location || "party", 16).toLowerCase(),
        slot: finiteInteger(location.slot, -1, -1, PC_BOX_SIZE - 1),
        box: location.location === "box" ? finiteInteger(location.box, -1, 0, PC_BOX_COUNT - 1) : -1,
        species,
        runtimeSpecies: megaSpecies || species,
        nickname: cleanText(pokemon.nickname, 96),
        level: finiteInteger(pokemon.level, 1, 1, 100),
        experience: finiteInteger(pokemon.experience, 0, 0),
        gender: cleanText(pokemon.gender, 24),
        nature: cleanText(pokemon.nature, 32),
        mintedNature: cleanText(pokemon.mintedNature, 32),
        ability: cleanText(pokemon.ability, 64),
        moves: (Array.isArray(pokemon.moves) ? pokemon.moves : []).slice(0, 4).map(move => ({
            id: cleanText(typeof move === "string" ? move : move?.id, 64),
            pp: finiteInteger(move?.pp, 0, 0, 999),
            maxPp: finiteInteger(move?.maxPp, 0, 0, 999)
        })).filter(move => move.id),
        heldItem: cleanText(pokemon.heldItem, 96),
        caughtBall: cleanText(pokemon.caughtBall, 48),
        originalTrainer: {
            playerId: cleanText(pokemon.originalTrainer?.uuid, 96),
            name: cleanText(pokemon.originalTrainer?.name, 96),
            type: cleanText(pokemon.originalTrainer?.type, 24)
        },
        currentHp: finiteInteger(pokemon.currentHp, 0, 0, 65535),
        maxHp: finiteInteger(pokemon.maxHp, 1, 1, 65535),
        statusCondition: cleanText(pokemon.statusCondition || "NONE", 24).toUpperCase(),
        friendship: finiteInteger(pokemon.friendship, 0, 0, 255),
        isShiny: pokemon.isShiny === true,
        isMegaEvolved: !!megaSpecies,
        form: cleanText(pokemon.form || "normal", 48),
        aspects: cleanStringList(pokemon.aspects, 16, 48),
        markings: cleanStringList(pokemon.markings, 16, 48),
        ivs: cleanStats(pokemon.ivs),
        evs: cleanStats(pokemon.evs),
        skin: cleanSkin(pokemon),
        addonIds: Object.keys(addonData).map(value => cleanKey(value)).filter(Boolean).slice(0, MAX_ADDON_METADATA_PROVIDERS)
    };
}

function sendSerialized(eventId, serialized, scope) {
    try {
        system.sendScriptEvent(eventId, serialized);
        return true;
    } catch (error) {
        console.warn(`[${scope}] Result event failed: ${error}`);
        return false;
    }
}

function publish(eventId, payload, scope = "AddonAPI") {
    const serialized = JSON.stringify(payload);
    if (utf8ByteLength(serialized) <= MAX_INLINE_RESULT_BYTES) {
        return sendSerialized(eventId, serialized, scope);
    }
    const chunks = splitByUtf8Bytes(serialized, MAX_RESULT_CHUNK_BYTES);
    const transferId = cleanText(payload?.requestId, 128)
        || `${system.currentTick}:${++transferSequence}`;
    let sent = true;
    for (let index = 0; index < chunks.length; index++) {
        sent = sendSerialized(eventId, JSON.stringify({
            version: ADDON_API_VERSION,
            outcome: "chunk",
            transferId,
            index,
            total: chunks.length,
            data: chunks[index]
        }), scope) && sent;
    }
    return sent;
}

function requestEnvelope(request, outcome, detail = "") {
    return {
        version: ADDON_API_VERSION,
        requestId: cleanText(request?.requestId, 128),
        action: cleanText(request?.action, 32).toLowerCase(),
        outcome,
        detail: cleanText(detail, 160)
    };
}

function publishDataResult(request, outcome, detail = "", payload = {}) {
    publish(POKEMON_DATA_RESULT_EVENT, {
        ...requestEnvelope(request, outcome, detail),
        playerId: cleanText(request?.playerId, 96),
        ...payload
    });
}

function selectedPokemon(player, request) {
    const location = cleanText(request?.location || "party", 16).toLowerCase();
    const pokemonUuid = cleanText(request?.pokemonUuid, 96);
    if (location === "party") {
        const container = loadPartyFromPlayer(player);
        const requestedSlot = Math.floor(Number(request?.slot));
        const slot = pokemonUuid
            ? container.findIndex(pokemon => String(pokemon?.uuid || "") === pokemonUuid)
            : requestedSlot;
        const pokemon = Number.isInteger(slot) && slot >= 0 && slot < container.length ? container[slot] : undefined;
        return { location, slot, box: -1, pokemon, container };
    }
    if (location === "box") {
        const box = Math.floor(Number(request?.box));
        if (!Number.isInteger(box) || box < 0 || box >= PC_BOX_COUNT) return undefined;
        const container = loadPCFromPlayer(player, box);
        const requestedSlot = Math.floor(Number(request?.slot));
        const slot = pokemonUuid
            ? container.findIndex(pokemon => String(pokemon?.uuid || "") === pokemonUuid)
            : requestedSlot;
        const pokemon = Number.isInteger(slot) && slot >= 0 && slot < PC_BOX_SIZE ? container[slot] : undefined;
        return { location, slot, box, pokemon, container };
    }
    return undefined;
}

function saveSelectedPokemon(player, selected) {
    const saved = selected.location === "party"
        ? savePartyToPlayer(player, selected.container)
        : savePCToPlayer(player, selected.box, selected.container);
    if (!saved || selected.location !== "party") return saved;
    const entity = summonedEntity(player.id, selected.pokemon.uuid);
    if (entity?.isValid) savePokemonToEntity(entity, selected.pokemon);
    return true;
}

function clonedJsonValue(value) {
    const serialized = JSON.stringify(value);
    if (serialized === undefined) return undefined;
    return { serialized, value: JSON.parse(serialized) };
}

function handleMetadataRequest(player, request, selected) {
    const addonId = cleanKey(request?.addonId);
    if (!addonId) return publishDataResult(request, "rejected", "invalid_addon_id");
    const action = cleanText(request?.action, 32).toLowerCase();
    const stored = selected.pokemon.addonData && typeof selected.pokemon.addonData === "object"
        && !Array.isArray(selected.pokemon.addonData)
        ? { ...selected.pokemon.addonData }
        : {};

    if (action === "metadata_get") {
        const value = Object.prototype.hasOwnProperty.call(stored, addonId)
            ? clonedJsonValue(stored[addonId])?.value ?? null
            : null;
        return publishDataResult(request, "ok", "", {
            pokemon: pokemonAddonSnapshot(selected.pokemon, selected),
            addonId,
            value
        });
    }

    if (action === "metadata_set") {
        const cloned = clonedJsonValue(request?.value);
        if (!cloned || utf8ByteLength(cloned.serialized) > MAX_ADDON_METADATA_BYTES) {
            return publishDataResult(request, "rejected", "metadata_too_large_or_invalid");
        }
        if (!Object.prototype.hasOwnProperty.call(stored, addonId)
            && Object.keys(stored).length >= MAX_ADDON_METADATA_PROVIDERS) {
            return publishDataResult(request, "rejected", "metadata_provider_limit");
        }
        stored[addonId] = cloned.value;
        if (utf8ByteLength(JSON.stringify(stored)) > MAX_ADDON_METADATA_TOTAL_BYTES) {
            return publishDataResult(request, "rejected", "metadata_total_limit");
        }
        selected.pokemon.addonData = stored;
        if (utf8ByteLength(JSON.stringify(selected.container)) > MAX_STORAGE_RECORD_BYTES) {
            return publishDataResult(request, "rejected", "storage_size_limit");
        }
    } else if (action === "metadata_clear") {
        delete stored[addonId];
        if (Object.keys(stored).length) selected.pokemon.addonData = stored;
        else delete selected.pokemon.addonData;
    } else {
        return publishDataResult(request, "rejected", "unknown_action");
    }

    if (!saveSelectedPokemon(player, selected)) return publishDataResult(request, "rejected", "save_failed");
    publishDataResult(request, "updated", "", {
        pokemon: pokemonAddonSnapshot(selected.pokemon, selected),
        addonId,
        value: action === "metadata_set" ? clonedJsonValue(stored[addonId])?.value ?? null : null
    });
}

function receivePokemonDataRequestChunk(chunk) {
    const requestId = cleanText(chunk?.requestId, 128);
    const playerId = cleanText(chunk?.playerId, 96);
    const index = Math.floor(Number(chunk?.index));
    const total = Math.floor(Number(chunk?.total));
    const data = typeof chunk?.data === "string" ? chunk.data : undefined;
    if (Number(chunk?.version) !== ADDON_API_VERSION
        || !requestId
        || !playerId
        || !Number.isInteger(index)
        || !Number.isInteger(total)
        || total < 1
        || total > MAX_REQUEST_CHUNKS
        || index < 0
        || index >= total
        || data === undefined
        || utf8ByteLength(data) > MAX_REQUEST_CHUNK_BYTES) {
        return publishDataResult(chunk, "rejected", "invalid_request_chunk");
    }

    const key = `${playerId}:${requestId}`;
    let pending = pendingRequestChunks.get(key);
    if (!pending) {
        pending = {
            requestId,
            playerId,
            total,
            parts: new Array(total),
            received: 0,
            updatedTick: system.currentTick
        };
        pendingRequestChunks.set(key, pending);
    }
    if (pending.total !== total) {
        pendingRequestChunks.delete(key);
        return publishDataResult(chunk, "rejected", "request_chunk_mismatch");
    }
    if (pending.parts[index] !== undefined) {
        if (pending.parts[index] !== data) {
            pendingRequestChunks.delete(key);
            return publishDataResult(chunk, "rejected", "request_chunk_mismatch");
        }
        pending.updatedTick = system.currentTick;
        return;
    }

    pending.parts[index] = data;
    pending.received++;
    pending.updatedTick = system.currentTick;
    if (pending.received !== pending.total) return;
    pendingRequestChunks.delete(key);

    const request = parseMessage(pending.parts.join(""));
    if (!request
        || cleanText(request.requestId, 128) !== requestId
        || cleanText(request.playerId, 96) !== playerId) {
        return publishDataResult(chunk, "rejected", "request_chunk_mismatch");
    }
    system.run(() => handlePokemonDataRequest(request));
}

function handlePokemonDataRequest(request) {
    if (Number(request?.version) !== ADDON_API_VERSION) {
        return publishDataResult(request, "rejected", "unsupported_version");
    }
    if (!cleanText(request?.requestId, 128)) return publishDataResult(request, "rejected", "missing_request_id");
    const player = playerById(request?.playerId);
    if (!player?.isValid) return publishDataResult(request, "rejected", "player_unavailable");
    const action = cleanText(request?.action, 32).toLowerCase();

    if (action === "party") {
        const party = loadPartyFromPlayer(player);
        return publishDataResult(request, "ok", "", {
            pokemon: party.map((entry, slot) => pokemonAddonSnapshot(entry, { location: "party", slot })).filter(Boolean)
        });
    }
    if (action === "box") {
        const box = Math.floor(Number(request?.box));
        if (!Number.isInteger(box) || box < 0 || box >= PC_BOX_COUNT) {
            return publishDataResult(request, "rejected", "invalid_box");
        }
        return publishDataResult(request, "ok", "", {
            box,
            boxCount: PC_BOX_COUNT,
            boxSize: PC_BOX_SIZE,
            pokemon: loadPCFromPlayer(player, box)
                .map((entry, slot) => pokemonAddonSnapshot(entry, { location: "box", box, slot }))
                .filter(Boolean)
        });
    }
    if (!["get", "metadata_get", "metadata_set", "metadata_clear"].includes(action)) {
        return publishDataResult(request, "rejected", "unknown_action");
    }

    const selected = selectedPokemon(player, request);
    if (!selected?.pokemon) return publishDataResult(request, "rejected", "pokemon_not_found");
    if (action === "get") {
        return publishDataResult(request, "ok", "", {
            pokemon: pokemonAddonSnapshot(selected.pokemon, selected)
        });
    }
    return handleMetadataRequest(player, request, selected);
}

function actionKey(addonId, actionId) {
    return `${addonId}:${actionId}`;
}

function cleanActionRegistration(request) {
    const addonId = cleanKey(request?.addonId);
    const actionId = cleanKey(request?.actionId);
    const label = cleanText(request?.label, 48);
    const translationKey = cleanText(request?.translationKey, 96);
    const icon = cleanText(request?.icon, 160);
    if (!addonId || !actionId || (!label && !translationKey)) return undefined;
    return {
        addonId,
        actionId,
        label,
        translationKey,
        icon,
        species: cleanStringList(request?.species, 64, 96, cleanSpecies),
        forms: cleanStringList(request?.forms, 16, 48, value => cleanText(value, 48).toLowerCase()),
        aspects: cleanStringList(request?.aspects, 16, 48, value => cleanText(value, 48).toLowerCase())
    };
}

function publishRegistrationResult(request, outcome, detail = "", payload = {}) {
    publish(POKEMON_ACTION_REGISTER_RESULT_EVENT, {
        ...requestEnvelope(request, outcome, detail),
        addonId: cleanKey(request?.addonId),
        actionId: cleanKey(request?.actionId),
        ...payload
    });
}

function handleActionRegistration(request) {
    if (Number(request?.version) !== ADDON_API_VERSION) {
        return publishRegistrationResult(request, "rejected", "unsupported_version");
    }
    if (!cleanText(request?.requestId, 128)) {
        return publishRegistrationResult(request, "rejected", "missing_request_id");
    }
    const operation = cleanText(request?.action || "register", 24).toLowerCase();
    const addonId = cleanKey(request?.addonId);
    const actionId = cleanKey(request?.actionId);
    if (operation === "unregister_all") {
        if (!addonId) return publishRegistrationResult(request, "rejected", "invalid_addon_id");
        for (const [key, registration] of registeredPokemonActions) {
            if (registration.addonId === addonId) registeredPokemonActions.delete(key);
        }
        return publishRegistrationResult(request, "updated", "", { registeredCount: registeredPokemonActions.size });
    }
    if (operation === "unregister") {
        if (!addonId || !actionId) return publishRegistrationResult(request, "rejected", "invalid_action_id");
        registeredPokemonActions.delete(actionKey(addonId, actionId));
        return publishRegistrationResult(request, "updated", "", { registeredCount: registeredPokemonActions.size });
    }
    if (operation !== "register") return publishRegistrationResult(request, "rejected", "unknown_action");

    const registration = cleanActionRegistration(request);
    if (!registration) return publishRegistrationResult(request, "rejected", "invalid_registration");
    const key = actionKey(registration.addonId, registration.actionId);
    const isNew = !registeredPokemonActions.has(key);
    const providerCount = [...registeredPokemonActions.values()]
        .filter(entry => entry.addonId === registration.addonId).length;
    if (isNew && providerCount >= MAX_ACTIONS_PER_ADDON) {
        return publishRegistrationResult(request, "rejected", "addon_action_limit");
    }
    if (isNew && registeredPokemonActions.size >= MAX_REGISTERED_ACTIONS) {
        return publishRegistrationResult(request, "rejected", "global_action_limit");
    }
    registeredPokemonActions.set(key, registration);
    publishRegistrationResult(request, "updated", "", {
        registration,
        registeredCount: registeredPokemonActions.size
    });
}

function registrationMatchesPokemon(registration, pokemon) {
    const species = cleanSpecies(pokemon?.species);
    const runtimeSpecies = cleanSpecies(activeMegaSpecies(pokemon)) || species;
    const form = cleanText(pokemon?.form || "normal", 48).toLowerCase();
    const aspects = new Set((Array.isArray(pokemon?.aspects) ? pokemon.aspects : [])
        .map(value => cleanText(value, 48).toLowerCase()));
    if (registration.species.length && !registration.species.includes(species)
        && !registration.species.includes(runtimeSpecies)) return false;
    if (registration.forms.length && !registration.forms.includes(form)) return false;
    return registration.aspects.every(aspect => aspects.has(aspect));
}

export function pokemonAddonActions(pokemon) {
    return [...registeredPokemonActions.values()].filter(registration => registrationMatchesPokemon(registration, pokemon));
}

function actionLabel(registration) {
    return registration.translationKey ? { translate: registration.translationKey } : registration.label;
}

export function showPokemonAddonActions(player, pokemon, entity = undefined) {
    if (!player?.isValid || !pokemon?.uuid) return false;
    const actions = pokemonAddonActions(pokemon);
    if (!actions.length) return false;
    const form = new ActionFormData()
        .title("Add-ons")
        .body(cleanText(pokemon.nickname || pokemon.species || "Pokemon", 96));
    for (const action of actions) {
        if (action.icon) form.button(actionLabel(action), action.icon);
        else form.button(actionLabel(action));
    }
    form.show(player).then(response => {
        if (response.canceled) return;
        const selected = actions[Math.floor(Number(response.selection))];
        if (!selected) return;
        publish(POKEMON_ACTION_INVOKED_EVENT, {
            version: ADDON_API_VERSION,
            addonId: selected.addonId,
            actionId: selected.actionId,
            playerId: String(player.id),
            entityId: entity?.isValid ? String(entity.id) : "",
            pokemon: pokemonAddonSnapshot(pokemon, {
                location: "party",
                slot: loadPartyFromPlayer(player).findIndex(entry => entry?.uuid === pokemon.uuid)
            })
        }, "PokemonActionAPI");
    }).catch(error => console.warn(`[PokemonActionAPI] Action form failed: ${error}`));
    return true;
}

function capabilities() {
    return {
        version: ADDON_API_VERSION,
        core: {
            pokemonData: 1,
            pokemonSpeciesRegistration: 1,
            pokemonMoveRegistration: 1,
            pokemonMetadata: 1,
            pokemonActions: 1,
            pokemonStorageEvents: 1,
            pokemonAppearance: 1,
            pokemonSkin: 1,
            trainerBattle: 1,
            raidBattle: 1,
            hudTransient: 1,
            naturalSpawnZone: 1,
            pokemonSpawn: 2,
            pokemonTrade: 2,
            pokemonGrant: 1,
            partyHeal: 1,
            levelCapSync: 1,
            wildBattleVictory: 1
        },
        events: {
            pokemonDataRequest: POKEMON_DATA_REQUEST_EVENT,
            pokemonSpeciesRegister: SPECIES_REGISTER_REQUEST_EVENT,
            pokemonSpeciesRegisterResult: SPECIES_REGISTER_RESULT_EVENT,
            pokemonMoveRegister: MOVE_REGISTER_REQUEST_EVENT,
            pokemonMoveRegisterResult: MOVE_REGISTER_RESULT_EVENT,
            pokemonDataResult: POKEMON_DATA_RESULT_EVENT,
            pokemonStorageChanged: POKEMON_STORAGE_CHANGED_EVENT,
            pokemonActionRegister: POKEMON_ACTION_REGISTER_EVENT,
            pokemonActionRegisterResult: POKEMON_ACTION_REGISTER_RESULT_EVENT,
            pokemonActionInvoked: POKEMON_ACTION_INVOKED_EVENT,
            pokemonSkinRequest: "lota:server_pokemon_skin_request_v1",
            pokemonSkinResult: "lota:server_pokemon_skin_result_v1",
            pokemonAppearance: "lota:server_pokemon_appearance_v1",
            trainerBattleRequest: "lota:server_trainer_battle_request_v1",
            trainerBattleResult: "lota:server_trainer_battle_result_v1",
            raidBattleRequest: "lota:server_raid_battle_request_v1",
            raidBattleReset: "lota:server_raid_battle_reset_v1",
            raidBattleResult: "lota:server_raid_battle_result_v1",
            raidRewardResult: "lota:server_raid_reward_result_v1",
            hudTransient: "lota:server_hud_transient_v1",
            naturalSpawnZone: "lota:server_natural_spawn_zone_v1",
            pokemonSpawnRequest: "lota:server_pokemon_spawn_request_v2",
            pokemonSpawnResult: "lota:server_pokemon_spawn_result_v2",
            pokemonTradeRequest: "lota:server_pokemon_trade_request_v2",
            pokemonTradeResult: "lota:server_pokemon_trade_result_v2",
            pokemonGrantRequest: "lota:server_pokemon_grant_request_v1",
            pokemonGrantResult: "lota:server_pokemon_grant_result_v1",
            partyHealRequest: "lota:server_party_heal_request_v1",
            partyHealResult: "lota:server_party_heal_result_v1",
            levelCapSync: "lota:server_level_cap_sync_v1",
            wildBattleVictory: "lota:server_wild_battle_victory_v1"
        },
        limits: {
            pcBoxCount: PC_BOX_COUNT,
            pcBoxSize: PC_BOX_SIZE,
            metadataBytesPerAddon: MAX_ADDON_METADATA_BYTES,
            metadataTotalBytes: MAX_ADDON_METADATA_TOTAL_BYTES,
            metadataProvidersPerPokemon: MAX_ADDON_METADATA_PROVIDERS,
            storageRecordBytes: MAX_STORAGE_RECORD_BYTES,
            actionsPerAddon: MAX_ACTIONS_PER_ADDON,
            registeredActions: MAX_REGISTERED_ACTIONS,
            inlineResultBytes: MAX_INLINE_RESULT_BYTES,
            resultChunkBytes: MAX_RESULT_CHUNK_BYTES,
            requestChunks: MAX_REQUEST_CHUNKS,
            requestChunkBytes: MAX_REQUEST_CHUNK_BYTES
        }
    };
}

function handleCapabilitiesRequest(request) {
    const supported = Number(request?.version) === ADDON_API_VERSION;
    publish(ADDON_CAPABILITIES_RESULT_EVENT, {
        version: ADDON_API_VERSION,
        requestId: cleanText(request?.requestId, 128),
        outcome: supported ? "ok" : "unsupported_version",
        requestedVersion: finiteInteger(request?.version, 0, 0, 999),
        capabilities: capabilities()
    });
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.sourceType !== ScriptEventSource.Server) return;
    if (![ADDON_CAPABILITIES_REQUEST_EVENT, POKEMON_DATA_REQUEST_EVENT, POKEMON_ACTION_REGISTER_EVENT]
        .includes(event.id)) return;
    const request = parseMessage(event.message);
    if (!request) return;
    if (event.id === ADDON_CAPABILITIES_REQUEST_EVENT) {
        system.run(() => handleCapabilitiesRequest(request));
        return;
    }
    if (event.id === POKEMON_DATA_REQUEST_EVENT) {
        if (request.transport === "chunk") receivePokemonDataRequestChunk(request);
        else system.run(() => handlePokemonDataRequest(request));
        return;
    }
    if (event.id === POKEMON_ACTION_REGISTER_EVENT) {
        system.run(() => handleActionRegistration(request));
    }
});

subscribePokemonStorageSaved(player => {
    const playerId = String(player?.id || "");
    if (!playerId || pendingStorageEvents.has(playerId)) return;
    pendingStorageEvents.add(playerId);
    system.run(() => {
        pendingStorageEvents.delete(playerId);
        publish(POKEMON_STORAGE_CHANGED_EVENT, {
            version: ADDON_API_VERSION,
            playerId
        }, "PokemonStorageAPI");
    });
});

world.afterEvents.playerLeave.subscribe(event => {
    pendingStorageEvents.delete(event.playerId);
    for (const key of pendingRequestChunks.keys()) {
        if (key.startsWith(`${event.playerId}:`)) pendingRequestChunks.delete(key);
    }
});

system.runInterval(() => {
    for (const [key, pending] of pendingRequestChunks) {
        if (system.currentTick - pending.updatedTick > REQUEST_CHUNK_TTL_TICKS) pendingRequestChunks.delete(key);
    }
}, 100);
