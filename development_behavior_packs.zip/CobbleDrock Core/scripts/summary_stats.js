import { natureMultiplier } from "./battle_math.js";

export const SUMMARY_CHART_STEPS = 8;
export const SUMMARY_STAT_MAXIMUM = 400;
export const SUMMARY_STAT_MODES = Object.freeze(["values", "ivs", "evs", "other"]);

const SUMMARY_TEXTURE_ROOT = "textures/gui/summary";

const STAT_KEYS = Object.freeze([
    "hp",
    "attack",
    "defence",
    "speed",
    "specialDefence",
    "specialAttack"
]);

const NATURE_TEXTURE_KEYS = Object.freeze({
    attack: "attack",
    defence: "defense",
    specialAttack: "special_attack",
    specialDefence: "special_defense",
    speed: "speed"
});

export function summaryChartStep(value, maximum, steps = SUMMARY_CHART_STEPS) {
    const boundedSteps = Math.max(1, Math.floor(Number(steps) || SUMMARY_CHART_STEPS));
    const numericValue = Math.max(0, Number(value) || 0);
    const numericMaximum = Math.max(1, Number(maximum) || 1);
    return Math.max(0, Math.min(boundedSteps, Math.round((numericValue / numericMaximum) * boundedSteps)));
}

export function summaryNatureDirection(pokemon, stat) {
    if (stat === "hp") return "neutral";
    const multiplier = natureMultiplier(pokemon, stat);
    if (multiplier > 1) return "up";
    if (multiplier < 1) return "down";
    return "neutral";
}

export function summaryPolygonSliceTexture(axis, firstStep, secondStep) {
    const boundedAxis = Math.max(0, Math.min(5, Math.floor(Number(axis) || 0)));
    const boundedFirst = Math.max(0, Math.min(SUMMARY_CHART_STEPS, Math.floor(Number(firstStep) || 0)));
    const boundedSecond = Math.max(0, Math.min(SUMMARY_CHART_STEPS, Math.floor(Number(secondStep) || 0)));
    return `${SUMMARY_TEXTURE_ROOT}/summary_stats_slice_${boundedAxis}_${boundedFirst}_${boundedSecond}`;
}

export function summaryNatureTexture(pokemon, direction) {
    const stat = STAT_KEYS.find(key => summaryNatureDirection(pokemon, key) === direction);
    const textureKey = NATURE_TEXTURE_KEYS[stat];
    return textureKey
        ? `${SUMMARY_TEXTURE_ROOT}/summary_stats_nature_${direction}_${textureKey}`
        : `${SUMMARY_TEXTURE_ROOT}/summary_stats_nature_none`;
}

function statButton(valueText, iconPath) {
    return {
        text: String(valueText),
        iconPath
    };
}

function statValue(source, stat, maximum = Number.POSITIVE_INFINITY) {
    return Math.max(0, Math.min(maximum, Math.floor(Number(source?.[stat]) || 0)));
}

function effectiveIv(pokemon, stat) {
    const raw = statValue(pokemon?.ivs, stat, 31);
    const hyperTrained = pokemon?.hyperTrainedIVs?.[stat] === true;
    const effective = hyperTrained ? 31 : raw;
    return { raw, effective, trained: hyperTrained && raw < 31 };
}

function summaryIvButtons(pokemon) {
    const ivs = STAT_KEYS.map(stat => effectiveIv(pokemon, stat));
    const steps = ivs.map(value => summaryChartStep(value.effective, 31));
    return ivs.map(({ raw, effective, trained }, index) => statButton(
        trained ? `${raw} (${effective})` : String(raw),
        summaryPolygonSliceTexture(index, steps[index], steps[(index + 1) % steps.length])
    ));
}

function summaryEvButtons(pokemon) {
    const evs = STAT_KEYS.map(stat => statValue(pokemon?.evs, stat, 252));
    const steps = evs.map(value => summaryChartStep(value, 252));
    return evs.map((value, index) => statButton(
        String(value),
        summaryPolygonSliceTexture(index, steps[index], steps[(index + 1) % steps.length])
    ));
}

function maximumFullness(weight) {
    const numericWeight = Math.max(0, Number(weight) || 0);
    const grassKnotPower = numericWeight <= 21.8 ? 20
        : numericWeight <= 54.9 ? 40
            : numericWeight <= 109.9 ? 60
                : numericWeight <= 219.9 ? 80
                    : numericWeight <= 439.9 ? 100
                        : 120;
    return Math.floor(grassKnotPower / 10 / 2) + 1;
}

function summaryOtherBarTexture(value, maximum) {
    const width = Math.max(0, Math.min(110, Math.round((Math.max(0, Number(value) || 0) / Math.max(1, Number(maximum) || 1)) * 110)));
    return `${SUMMARY_TEXTURE_ROOT}/summary_stats_other_fill_${String(width).padStart(3, "0")}`;
}

function summaryOtherButtons(pokemon, data) {
    const friendship = statValue(pokemon, "friendship", 255);
    const fullnessMaximum = maximumFullness(data?.weight);
    const fullness = statValue({ fullness: pokemon?.currentFullness }, "fullness", fullnessMaximum);
    const friendshipToken = friendship >= 160 ? "FRIEND_HIGH" : "FRIEND_LOW";
    const fullnessRatio = fullness / fullnessMaximum;
    const fullnessToken = fullnessRatio <= 0.33 ? "FULL_LOW" : fullnessRatio <= 0.66 ? "FULL_MID" : "FULL_HIGH";
    const rows = [
        statButton(`${friendship}\n${Math.floor(friendship / 255 * 100)}%\n|OTHER:${friendshipToken}|`, summaryOtherBarTexture(friendship, 255)),
        statButton(`${fullness}\n${Math.floor(fullnessRatio * 100)}%\n|OTHER:${fullnessToken}|`, summaryOtherBarTexture(fullness, fullnessMaximum))
    ];
    while (rows.length < 7) rows.push({ text: "", iconPath: `${SUMMARY_TEXTURE_ROOT}/summary_stats_slice_none` });
    return rows;
}

export function summaryStatButtons(pokemon, stats, mode = SUMMARY_STAT_MODES[0], data = undefined) {
    let rows;
    if (mode === "ivs") rows = summaryIvButtons(pokemon);
    else if (mode === "evs") rows = summaryEvButtons(pokemon);
    else if (mode === "other") rows = summaryOtherButtons(pokemon, data);
    else {
        const values = STAT_KEYS.map(stat => statValue(stats, stat));
        const steps = values.map(value => summaryChartStep(value, SUMMARY_STAT_MAXIMUM));
        rows = STAT_KEYS.map((stat, index) => {
            const value = values[index];
            const valueText = stat === "hp"
                ? `${Math.max(0, Math.floor(Number(pokemon?.currentHp) || 0))} / ${value}`
                : String(value);
            return statButton(valueText, summaryPolygonSliceTexture(index, steps[index], steps[(index + 1) % steps.length]));
        });
    }
    if (rows.length < 7) rows.push({ text: "", iconPath: `${SUMMARY_TEXTURE_ROOT}/summary_stats_slice_none` });
    const showNature = mode === SUMMARY_STAT_MODES[0];
    rows.push({ text: "", iconPath: showNature ? summaryNatureTexture(pokemon, "up") : summaryNatureTexture(pokemon, "none") });
    rows.push({ text: "", iconPath: showNature ? summaryNatureTexture(pokemon, "down") : summaryNatureTexture(pokemon, "none") });
    return rows;
}
