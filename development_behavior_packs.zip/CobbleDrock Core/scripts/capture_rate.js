import { ItemStack } from "@minecraft/server";
import { speciesData, speciesWeight, speciesKey } from "./battle_math.js";

const ULTRA_BEASTS = new Set([
    "nihilego", "buzzwole", "pheromosa", "xurkitree", "celesteela",
    "kartana", "guzzlord", "poipole", "naganadel", "stakataka", "blacephalon"
]);

const MOON_EVOLUTION_FAMILY = new Set([
    "nidoran-f", "nidorina", "nidoqueen", "nidoran-m", "nidorino", "nidoking",
    "clefairy", "cleffa", "clefable", "jigglypuff", "igglybuff", "wigglytuff",
    "skitty", "delcatty", "munna", "musharna"
]);

const SHAKE_RANDOM_BOUND = 65537;
const OUT_OF_BATTLE_MODIFIER = 0.5;
const ENCOUNTERED_SPECIES_PROPERTY = "lota:encountered_species";
const CAPTURED_SPECIES_PROPERTY = "lota:captured_species";

export const CAPTURE_BALLS = Object.freeze({
    master_ball: Object.freeze({
        itemId: "lota:master_ball",
        projectileId: "lota:master_ball_projectile",
        caughtBall: "master_ball",
        name: "Master Ball",
        code: "MASTER",
        modifier: 1,
        guaranteed: true,
        type: 16
    }),
    poke_ball: Object.freeze({
        itemId: "lota:poke_ball",
        projectileId: "lota:poke_ball_projectile",
        caughtBall: "poke_ball",
        name: "Poké Ball",
        code: "P",
        modifier: 1,
        type: 1
    }),
    great_ball: Object.freeze({
        itemId: "lota:great_ball",
        projectileId: "lota:great_ball_projectile",
        caughtBall: "great_ball",
        name: "Great Ball",
        code: "G",
        modifier: 1.5,
        type: 2
    }),
    ultra_ball: Object.freeze({
        itemId: "lota:ultra_ball",
        projectileId: "lota:ultra_ball_projectile",
        caughtBall: "ultra_ball",
        name: "Ultra Ball",
        code: "U",
        modifier: 2,
        type: 3
    }),
    ancient_ultra_ball: Object.freeze({
        itemId: "lota:ancient_ultra_ball",
        projectileId: "lota:ancient_ultra_ball_projectile",
        caughtBall: "ancient_ultra_ball",
        name: "Ancient Ultra Ball",
        code: "ANCIENT_ULTRA",
        modifier: 2,
        type: 15
    }),
    net_ball: Object.freeze({
        itemId: "lota:net_ball",
        projectileId: "lota:net_ball_projectile",
        caughtBall: "net_ball",
        name: "Net Ball",
        code: "NET",
        modifier: 1,
        modifierRule: "net",
        type: 4
    }),
    dive_ball: Object.freeze({
        itemId: "lota:dive_ball",
        projectileId: "lota:dive_ball_projectile",
        caughtBall: "dive_ball",
        name: "Dive Ball",
        code: "DIVE",
        modifier: 1,
        modifierRule: "dive",
        type: 5
    }),
    nest_ball: Object.freeze({
        itemId: "lota:nest_ball",
        projectileId: "lota:nest_ball_projectile",
        caughtBall: "nest_ball",
        name: "Nest Ball",
        code: "NEST",
        modifier: 1,
        modifierRule: "nest",
        type: 6
    }),
    repeat_ball: Object.freeze({
        itemId: "lota:repeat_ball",
        projectileId: "lota:repeat_ball_projectile",
        caughtBall: "repeat_ball",
        name: "Repeat Ball",
        code: "REPEAT",
        modifier: 1,
        modifierRule: "repeat",
        type: 7
    }),
    timer_ball: Object.freeze({
        itemId: "lota:timer_ball",
        projectileId: "lota:timer_ball_projectile",
        caughtBall: "timer_ball",
        name: "Timer Ball",
        code: "TIMER",
        modifier: 1,
        modifierRule: "timer",
        type: 8
    }),
    dusk_ball: Object.freeze({
        itemId: "lota:dusk_ball",
        projectileId: "lota:dusk_ball_projectile",
        caughtBall: "dusk_ball",
        name: "Dusk Ball",
        code: "DUSK",
        modifier: 1,
        modifierRule: "dusk",
        type: 9
    }),
    quick_ball: Object.freeze({
        itemId: "lota:quick_ball",
        projectileId: "lota:quick_ball_projectile",
        caughtBall: "quick_ball",
        name: "Quick Ball",
        code: "QUICK",
        modifier: 1,
        modifierRule: "quick",
        type: 10
    }),
    slate_ball: Object.freeze({
        itemId: "lota:slate_ball",
        projectileId: "lota:slate_ball_projectile",
        caughtBall: "slate_ball",
        name: "Slate Ball",
        code: "SLATE",
        modifier: 1,
        type: 11
    }),
    citrine_ball: Object.freeze({
        itemId: "lota:citrine_ball",
        projectileId: "lota:citrine_ball_projectile",
        caughtBall: "citrine_ball",
        name: "Citrine Ball",
        code: "CITRINE",
        modifier: 1,
        type: 12
    }),
    roseate_ball: Object.freeze({
        itemId: "lota:roseate_ball",
        projectileId: "lota:roseate_ball_projectile",
        caughtBall: "roseate_ball",
        name: "Roseate Ball",
        code: "ROSEATE",
        modifier: 1,
        type: 13
    }),
    fast_ball: Object.freeze({
        itemId: "lota:fast_ball",
        projectileId: "lota:fast_ball_projectile",
        caughtBall: "fast_ball",
        name: "Fast Ball",
        code: "FAST",
        modifier: 1,
        modifierRule: "fast",
        type: 14
    }),
    verdant_ball: Object.freeze({
        itemId: "lota:verdant_ball",
        projectileId: "lota:verdant_ball_projectile",
        caughtBall: "verdant_ball",
        name: "Verdant Ball",
        code: "VERDANT",
        modifier: 1,
        type: 17
    }),
    azure_ball: Object.freeze({
        itemId: "lota:azure_ball",
        projectileId: "lota:azure_ball_projectile",
        caughtBall: "azure_ball",
        name: "Azure Ball",
        code: "AZURE",
        modifier: 1,
        type: 18
    }),
    premier_ball: Object.freeze({
        itemId: "lota:premier_ball",
        projectileId: "lota:premier_ball_projectile",
        caughtBall: "premier_ball",
        name: "Premier Ball",
        code: "PREMIER",
        modifier: 1,
        type: 19
    }),
    safari_ball: Object.freeze({
        itemId: "lota:safari_ball",
        projectileId: "lota:safari_ball_projectile",
        caughtBall: "safari_ball",
        name: "Safari Ball",
        code: "SAFARI",
        modifier: 1.5,
        modifierRule: "safari",
        type: 20
    }),
    level_ball: Object.freeze({
        itemId: "lota:level_ball",
        projectileId: "lota:level_ball_projectile",
        caughtBall: "level_ball",
        name: "Level Ball",
        code: "LEVEL",
        modifier: 1,
        modifierRule: "level",
        type: 21
    }),
    lure_ball: Object.freeze({
        itemId: "lota:lure_ball",
        projectileId: "lota:lure_ball_projectile",
        caughtBall: "lure_ball",
        name: "Lure Ball",
        code: "LURE",
        modifier: 1,
        modifierRule: "lure",
        type: 22
    }),
    heavy_ball: Object.freeze({
        itemId: "lota:heavy_ball",
        projectileId: "lota:heavy_ball_projectile",
        caughtBall: "heavy_ball",
        name: "Heavy Ball",
        code: "HEAVY",
        modifier: 1,
        modifierRule: "heavy",
        type: 23
    }),
    love_ball: Object.freeze({
        itemId: "lota:love_ball",
        projectileId: "lota:love_ball_projectile",
        caughtBall: "love_ball",
        name: "Love Ball",
        code: "LOVE",
        modifier: 1,
        modifierRule: "love",
        type: 24
    }),
    friend_ball: Object.freeze({
        itemId: "lota:friend_ball",
        projectileId: "lota:friend_ball_projectile",
        caughtBall: "friend_ball",
        name: "Friend Ball",
        code: "FRIEND",
        modifier: 1,
        type: 25
    }),
    moon_ball: Object.freeze({
        itemId: "lota:moon_ball",
        projectileId: "lota:moon_ball_projectile",
        caughtBall: "moon_ball",
        name: "Moon Ball",
        code: "MOON",
        modifier: 1,
        modifierRule: "moon",
        type: 26
    }),
    sport_ball: Object.freeze({
        itemId: "lota:sport_ball",
        projectileId: "lota:sport_ball_projectile",
        caughtBall: "sport_ball",
        name: "Sport Ball",
        code: "SPORT",
        modifier: 1.5,
        type: 27
    }),
    park_ball: Object.freeze({
        itemId: "lota:park_ball",
        projectileId: "lota:park_ball_projectile",
        caughtBall: "park_ball",
        name: "Park Ball",
        code: "PARK",
        modifier: 1,
        modifierRule: "park",
        type: 28
    }),
    luxury_ball: Object.freeze({
        itemId: "lota:luxury_ball",
        projectileId: "lota:luxury_ball_projectile",
        caughtBall: "luxury_ball",
        name: "Luxury Ball",
        code: "LUXURY",
        modifier: 1,
        type: 29
    }),
    heal_ball: Object.freeze({
        itemId: "lota:heal_ball",
        projectileId: "lota:heal_ball_projectile",
        caughtBall: "heal_ball",
        name: "Heal Ball",
        code: "HEAL",
        modifier: 1,
        type: 30
    }),
    dream_ball: Object.freeze({
        itemId: "lota:dream_ball",
        projectileId: "lota:dream_ball_projectile",
        caughtBall: "dream_ball",
        name: "Dream Ball",
        code: "DREAM",
        modifier: 1,
        modifierRule: "dream",
        type: 31
    }),
    beast_ball: Object.freeze({
        itemId: "lota:beast_ball",
        projectileId: "lota:beast_ball_projectile",
        caughtBall: "beast_ball",
        name: "Beast Ball",
        code: "BEAST",
        modifier: 1,
        modifierRule: "beast",
        type: 32
    }),
    cherish_ball: Object.freeze({
        itemId: "lota:cherish_ball",
        projectileId: "lota:cherish_ball_projectile",
        caughtBall: "cherish_ball",
        name: "Cherish Ball",
        code: "CHERISH",
        modifier: 1,
        type: 33
    }),
    ancient_poke_ball: Object.freeze({
        itemId: "lota:ancient_poke_ball",
        projectileId: "lota:ancient_poke_ball_projectile",
        caughtBall: "ancient_poke_ball",
        name: "Ancient Poké Ball",
        code: "A_POKE",
        modifier: 1,
        type: 34
    }),
    ancient_citrine_ball: Object.freeze({
        itemId: "lota:ancient_citrine_ball",
        projectileId: "lota:ancient_citrine_ball_projectile",
        caughtBall: "ancient_citrine_ball",
        name: "Ancient Citrine Ball",
        code: "A_CITRINE",
        modifier: 1,
        type: 35
    }),
    ancient_verdant_ball: Object.freeze({
        itemId: "lota:ancient_verdant_ball",
        projectileId: "lota:ancient_verdant_ball_projectile",
        caughtBall: "ancient_verdant_ball",
        name: "Ancient Verdant Ball",
        code: "A_VERDANT",
        modifier: 1,
        type: 36
    }),
    ancient_azure_ball: Object.freeze({
        itemId: "lota:ancient_azure_ball",
        projectileId: "lota:ancient_azure_ball_projectile",
        caughtBall: "ancient_azure_ball",
        name: "Ancient Azure Ball",
        code: "A_AZURE",
        modifier: 1,
        type: 37
    }),
    ancient_roseate_ball: Object.freeze({
        itemId: "lota:ancient_roseate_ball",
        projectileId: "lota:ancient_roseate_ball_projectile",
        caughtBall: "ancient_roseate_ball",
        name: "Ancient Roseate Ball",
        code: "A_ROSEATE",
        modifier: 1,
        type: 38
    }),
    ancient_slate_ball: Object.freeze({
        itemId: "lota:ancient_slate_ball",
        projectileId: "lota:ancient_slate_ball_projectile",
        caughtBall: "ancient_slate_ball",
        name: "Ancient Slate Ball",
        code: "A_SLATE",
        modifier: 1,
        type: 39
    }),
    ancient_great_ball: Object.freeze({
        itemId: "lota:ancient_great_ball",
        projectileId: "lota:ancient_great_ball_projectile",
        caughtBall: "ancient_great_ball",
        name: "Ancient Great Ball",
        code: "A_GREAT",
        modifier: 1.5,
        type: 40
    }),
    ancient_heavy_ball: Object.freeze({
        itemId: "lota:ancient_heavy_ball",
        projectileId: "lota:ancient_heavy_ball_projectile",
        caughtBall: "ancient_heavy_ball",
        name: "Ancient Heavy Ball",
        code: "A_HEAVY",
        modifier: 1,
        type: 41
    }),
    ancient_feather_ball: Object.freeze({
        itemId: "lota:ancient_feather_ball",
        projectileId: "lota:ancient_feather_ball_projectile",
        caughtBall: "ancient_feather_ball",
        name: "Ancient Feather Ball",
        code: "A_FEATHER",
        modifier: 1,
        type: 42
    }),
    ancient_wing_ball: Object.freeze({
        itemId: "lota:ancient_wing_ball",
        projectileId: "lota:ancient_wing_ball_projectile",
        caughtBall: "ancient_wing_ball",
        name: "Ancient Wing Ball",
        code: "A_WING",
        modifier: 1,
        type: 43
    }),
    ancient_jet_ball: Object.freeze({
        itemId: "lota:ancient_jet_ball",
        projectileId: "lota:ancient_jet_ball_projectile",
        caughtBall: "ancient_jet_ball",
        name: "Ancient Jet Ball",
        code: "A_JET",
        modifier: 1,
        type: 44
    }),
    ancient_leaden_ball: Object.freeze({
        itemId: "lota:ancient_leaden_ball",
        projectileId: "lota:ancient_leaden_ball_projectile",
        caughtBall: "ancient_leaden_ball",
        name: "Ancient Leaden Ball",
        code: "A_LEADEN",
        modifier: 1,
        type: 45
    }),
    ancient_gigaton_ball: Object.freeze({
        itemId: "lota:ancient_gigaton_ball",
        projectileId: "lota:ancient_gigaton_ball_projectile",
        caughtBall: "ancient_gigaton_ball",
        name: "Ancient Gigaton Ball",
        code: "A_GIGATON",
        modifier: 1,
        type: 46
    }),
    ancient_ivory_ball: Object.freeze({
        itemId: "lota:ancient_ivory_ball",
        projectileId: "lota:ancient_ivory_ball_projectile",
        caughtBall: "ancient_ivory_ball",
        name: "Ancient Ivory Ball",
        code: "A_IVORY",
        modifier: 1,
        type: 47
    })
});

const BALL_BY_ITEM = new Map(Object.values(CAPTURE_BALLS).map(ball => [ball.itemId, ball]));
const BALL_BY_PROJECTILE = new Map(Object.values(CAPTURE_BALLS).map(ball => [ball.projectileId, ball]));
const BALL_BY_CAUGHT_TYPE = new Map(Object.values(CAPTURE_BALLS).map(ball => [ball.caughtBall, ball]));



export function refundThrownBall(thrower, ball, fallbackLocation) {
    if (!thrower?.isValid || !ball?.itemId) return false;
    try {
        if (String(thrower.getGameMode?.() || "").toLowerCase().includes("creative")) return false;
    } catch (error) {}
    try {
        const container = thrower.getComponent("minecraft:inventory")?.container;
        if (container) {
            try {
                const remainder = container.addItem(new ItemStack(ball.itemId, 1));
                if (!remainder) return true;
                try { thrower.dimension.spawnItem(remainder, thrower.location); } catch (error) {}
                return true;
            } catch (error) {}
        }
    } catch (error) {}
    try {
        const location = (fallbackLocation && Number.isFinite(Number(fallbackLocation?.x)))
            ? fallbackLocation
            : thrower.location;
        thrower.dimension.spawnItem(new ItemStack(ball.itemId, 1), location);
        return true;
    } catch (error) {
        return false;
    }
}

export function captureBallForItem(itemId) {
    return BALL_BY_ITEM.get(String(itemId || ""));
}

export function captureBallForProjectile(projectileId) {
    return BALL_BY_PROJECTILE.get(String(projectileId || ""));
}

export function captureBallCode(caughtBall) {
    return BALL_BY_CAUGHT_TYPE.get(String(caughtBall || "").replace(/^.*:/, ""))?.code || "P";
}

export function captureBallType(caughtBall) {
    return BALL_BY_CAUGHT_TYPE.get(String(caughtBall || "").replace(/^.*:/, ""))?.type || 1;
}

export function applyCaptureBallEffects(pokemon, ball) {
    if (!pokemon || !ball) return false;
    const caughtBall = String(ball.caughtBall || "").replace(/^.*:/, "");
    let changed = false;

    if (caughtBall === "friend_ball") {
        pokemon.friendship = 150;
        changed = true;
    }

    if (caughtBall === "heal_ball") {
        pokemon.currentHp = Math.max(1, Number(pokemon.maxHp) || 1);
        pokemon.statusCondition = "NONE";
        for (const move of pokemon.moves || []) {
            const maximum = Math.max(0, Math.floor(Number(move?.maxPp) || 0));
            if (maximum > 0) move.pp = maximum;
        }
        changed = true;
    }

    return changed;
}

export function captureStatus(statusCondition) {
    const status = String(statusCondition || "NONE").toUpperCase();
    if (["SLEEP", "ASLEEP", "SLP"].includes(status)) {
        return { id: "sleep", label: "Asleep", icon: "💤", multiplier: 2.5 };
    }
    if (["FREEZE", "FROZEN", "FRZ"].includes(status)) {
        return { id: "frozen", label: "Frozen", icon: "❄", multiplier: 2.5 };
    }
    if (["PARALYSIS", "PARALYZED", "PAR"].includes(status)) {
        return { id: "paralysis", label: "Paralysis", icon: "⚡", multiplier: 1.5 };
    }
    if (["BURN", "BURNED", "BRN"].includes(status)) {
        return { id: "burn", label: "Burned", icon: "🔥", multiplier: 1.5 };
    }
    if (["POISON", "POISONED", "PSN"].includes(status)) {
        return { id: "poison", label: "Poison", icon: "☠", multiplier: 1.5 };
    }
    if (["BADLY_POISONED", "POISONBADLY", "TOXIC", "TOX"].includes(status)) {
        return { id: "poisonbadly", label: "Toxic", icon: "☠", multiplier: 1.5 };
    }
    return { id: "none", label: "None", icon: "●", multiplier: 1 };
}

export function lowLevelCaptureBonus(level) {
    const normalizedLevel = Math.max(1, Math.floor(Number(level) || 1));
    if (normalizedLevel >= 13) return 1;
    return Math.max(Math.trunc((36 - 2 * normalizedLevel) / 10), 1);
}

function contextEntityInWater(context) {
    if (context?.isSubmerged !== undefined) return !!context.isSubmerged;
    try {
        return !!context?.targetEntity?.isInWater;
    } catch (error) {
        return false;
    }
}

function contextLightLevel(context) {
    const supplied = Number(context?.lightLevel);
    if (Number.isFinite(supplied)) return Math.max(0, Math.min(15, Math.floor(supplied)));
    try {
        const entity = context?.targetEntity;
        if (!entity?.isValid) return undefined;
        return Math.max(0, Math.min(15, Math.floor(entity.dimension.getLightLevel(entity.location))));
    } catch (error) {
        return undefined;
    }
}

function contextIsNight(context) {
    if (context?.isNight !== undefined) return !!context.isNight;
    const timeOfDay = Number(context?.timeOfDay);
    if (Number.isFinite(timeOfDay)) return timeOfDay >= 13000 && timeOfDay < 23000;
    const lightLevel = contextLightLevel(context);
    return lightLevel !== undefined ? lightLevel <= 7 : undefined;
}

function contextForestOrPlains(context) {
    if (context?.isForestOrPlains !== undefined) return !!context.isForestOrPlains;
    let biome = String(context?.biome || "").toLowerCase();
    if (!biome) {
        try {
            const entity = context?.targetEntity;
            if (entity?.isValid) biome = String(entity.dimension.getBiome(entity.location)?.id || "").toLowerCase();
        } catch (error) {}
    }
    if (biome) return biome.includes("forest") || biome.includes("plains") || biome.includes("grove");
    return undefined;
}

export function captureBallModifier(pokemon, ball, context = {}) {
    const base = Math.max(0, Number(ball?.modifier) || 1);
    const rule = String(ball?.modifierRule || "");
    const level = Math.max(1, Math.floor(Number(pokemon?.level) || 1));
    const turn = Math.max(0, Math.floor(Number(context?.battleTurn) || 0));
    const isUltraBeast = ULTRA_BEASTS.has(speciesKey(pokemon));

    if (isUltraBeast && rule !== "beast") {
        return { multiplier: 0.1, condition: "Ultra Beast (non-Beast Ball)" };
    }

    if (rule === "beast") {
        return { multiplier: isUltraBeast ? 5 : 0.1, condition: isUltraBeast ? "Ultra Beast" : "Not an Ultra Beast" };
    }
    if (rule === "safari") {
        const boosted = !context?.inBattle;
        return { multiplier: boosted ? 1.5 : 1, condition: boosted ? "Outside of battle" : "In battle" };
    }
    if (rule === "level") {
        const leadLevel = Math.floor(Number(context?.leadPokemonLevel ?? context?.leadPokemon?.level));
        if (!Number.isFinite(leadLevel) || leadLevel < 1) {
            return { multiplier: 1, condition: "No lead Pokémon level provided" };
        }
        const ratio = leadLevel / level;
        const mult = ratio >= 4 ? 4 : ratio >= 2 ? 3 : ratio > 1 ? 2 : 1;
        return { multiplier: mult, condition: `Lead Lv${leadLevel} vs target Lv${level}` };
    }
    if (rule === "lure") {
        const boosted = !!context?.isFishing;
        return { multiplier: boosted ? 4 : 1, condition: boosted ? "Hooked via Poké Rod" : "Not fished" };
    }
    if (rule === "heavy") {
        const weight = speciesWeight(pokemon);
        const mult = weight >= 3000 ? 4 : weight >= 2000 ? 2.5 : weight >= 1000 ? 1.5 : 1;
        return { multiplier: mult, condition: `Weight ${weight / 10}kg` };
    }
    if (rule === "love") {
        const lead = context?.leadPokemon || context?.party?.find(member => Number(member?.currentHp) > 0);
        if (!lead?.species || !lead?.gender || !pokemon?.gender) return { multiplier: 1, condition: "No lead Pokémon provided" };
        const sameSpecies = speciesKey(lead.species) === speciesKey(pokemon);
        const oppositeGender = String(lead.gender).toUpperCase() !== String(pokemon.gender).toUpperCase()
            && pokemon.gender !== "GENDERLESS" && lead.gender !== "GENDERLESS";
        if (!oppositeGender) return { multiplier: 1, condition: "Not opposite gender" };
        return sameSpecies
            ? { multiplier: 8, condition: "Opposite gender, same species" }
            : { multiplier: 2.5, condition: "Opposite gender, different species" };
    }
    if (rule === "moon") {
        const night = contextIsNight(context);
        const inFamily = MOON_EVOLUTION_FAMILY.has(speciesKey(pokemon));
        if (!night || !inFamily) return { multiplier: 1, condition: !inFamily ? "Not a Moon Stone family" : "Daytime" };
        const rawPhase = Number(context?.moonPhase);
        if (!Number.isFinite(rawPhase)) return { multiplier: 1, condition: "Moon phase unknown" };
        const phase = Math.max(0, Math.min(7, Math.floor(rawPhase)));
        const distanceFromFull = Math.min(phase, 8 - phase);
        const mult = distanceFromFull <= 0 ? 4 : distanceFromFull === 1 ? 3 : distanceFromFull === 2 ? 2 : 1;
        return { multiplier: mult, condition: `Night, moon phase ${phase}` };
    }
    if (rule === "park") {
        const forestPlains = contextForestOrPlains(context);
        if (forestPlains === undefined) return { multiplier: 1, condition: "Biome unknown" };
        return { multiplier: forestPlains ? 2.5 : 1, condition: forestPlains ? "Forest/Plains biome" : "Other biome" };
    }
    if (rule === "dream") {
        const boosted = captureStatus(pokemon?.statusCondition).id === "sleep";
        return { multiplier: boosted ? 4 : 1, condition: boosted ? "Asleep" : "Awake" };
    }
    if (rule === "net") {
        const types = speciesData(pokemon)?.types || [];
        const boosted = types.includes("bug") || types.includes("water");
        return { multiplier: boosted ? 3 : 1, condition: boosted ? "Bug/Water type bonus" : "Type mismatch" };
    }
    if (rule === "dive") {
        const boosted = contextEntityInWater(context);
        return { multiplier: boosted ? 3.5 : 1, condition: boosted ? "In water" : "Not in water" };
    }
    if (rule === "nest") {
        const boosted = level < 30;
        return {
            multiplier: boosted ? (41 - level) / 10 : 1,
            condition: boosted ? `Target Lv${level}` : "Target Lv30+"
        };
    }
    if (rule === "repeat") {
        const boosted = context?.hasCaughtSpecies !== undefined
            ? !!context.hasCaughtSpecies
            : hasCapturedSpecies(context?.player, pokemon, context?.party);
        return { multiplier: boosted ? 3.5 : 1, condition: boosted ? "Caught before" : "Not caught before" };
    }
    if (rule === "timer") {
        if (!context?.inBattle || turn < 1) return { multiplier: 1, condition: "Out of battle" };
        return {
            multiplier: Math.min(turn * 0.30004883, 4),
            condition: `${turn} turn`
        };
    }
    if (rule === "dusk") {
        const lightLevel = contextLightLevel(context);
        if (lightLevel === 0) return { multiplier: 3.5, condition: "Brightness 0" };
        if (lightLevel !== undefined && lightLevel < 8) return { multiplier: 3, condition: `Brightness ${lightLevel}` };
        return { multiplier: 1, condition: lightLevel === undefined ? "Brightness unknown" : `Brightness ${lightLevel}` };
    }
    if (rule === "quick") {
        const boosted = !!context?.inBattle && turn === 1;
        return { multiplier: boosted ? 5 : 1, condition: boosted ? "First turn" : (context?.inBattle ? `${turn} turn` : "Out of battle") };
    }
    if (rule === "fast") {
        const speed = Math.max(0, Number(speciesData(pokemon)?.baseStats?.speed) || 0);
        return { multiplier: speed >= 100 ? 4 : 1, condition: `Base Speed ${speed}` };
    }
    return { multiplier: base, condition: "" };
}

export function calculateCaptureRate(pokemon, ball, inBattle = true, context = {}) {
    const data = speciesData(pokemon);
    const baseCatchRate = Math.max(1, Math.min(255, Number(data?.catchRate) || 45));
    const maxHp = Math.max(1, Number(pokemon?.maxHp) || 1);
    const currentHp = Math.max(1, Math.min(maxHp, Number(pokemon?.currentHp) || maxHp));
    const status = captureStatus(pokemon?.statusCondition);
    const levelBonus = lowLevelCaptureBonus(pokemon?.level);
    const battleModifier = inBattle ? 1 : OUT_OF_BATTLE_MODIFIER;
    const ballModifier = captureBallModifier(pokemon, ball, { ...context, inBattle });
    const ballMultiplier = ballModifier.multiplier;
    const hpMultiplier = (3 * maxHp - 2 * currentHp) / (3 * maxHp);
    const modifiedRate = baseCatchRate
        * hpMultiplier
        * ballMultiplier
        * status.multiplier
        * levelBonus
        * battleModifier;
    const shakeThreshold = modifiedRate > 0
        ? Math.round(65536 / Math.pow(255 / modifiedRate, 0.1875))
        : 0;
    const guaranteed = ball?.guaranteed === true || shakeThreshold >= SHAKE_RANDOM_BOUND;
    const perShakeChance = Math.max(0, shakeThreshold) / SHAKE_RANDOM_BOUND;
    const percentage = guaranteed ? 100 : Math.pow(perShakeChance, 4) * 100;

    return {
        baseCatchRate,
        maxHp,
        currentHp,
        hpMultiplier,
        status,
        levelBonus,
        battleModifier,
        ballMultiplier,
        ballCondition: ballModifier.condition,
        modifiedRate,
        shakeThreshold,
        guaranteed,
        percentage
    };
}

export function rollCaptureOutcome(calculation, random = Math.random) {
    if (calculation.guaranteed) return { caught: true, shakes: 4 };
    let shakes = 0;
    while (shakes < 4 && Math.floor(random() * SHAKE_RANDOM_BOUND) < calculation.shakeThreshold) shakes++;
    return { caught: shakes === 4, shakes };
}

export function formatCapturePercentage(calculation) {
    if (calculation.guaranteed) return "100.0";
    return Math.min(99.9, Math.max(0, calculation.percentage)).toFixed(1);
}

export function captureRateStateToken(percentage) {
    const normalized = Math.max(0, Math.min(100, Math.round(Number(percentage) || 0)));
    const state = String(normalized).padStart(3, "0");
    const band = normalized >= 75 ? "a" : normalized >= 50 ? "e" : normalized >= 25 ? "6" : "c";
    return `§r§k§r§l§${band}§r${[...state].map(digit => `§${digit}`).join("")}§r`;
}

export function captureSpeciesKey(pokemonOrSpecies) {
    const value = typeof pokemonOrSpecies === "string" ? pokemonOrSpecies : pokemonOrSpecies?.species;
    return String(value || "").replace("cobblemon:", "").replace("lota:", "").toLowerCase();
}

function readSpeciesSet(player, propertyId) {
    try {
        const raw = String(player?.getDynamicProperty(propertyId) || "[]");
        const values = JSON.parse(raw);
        return new Set(Array.isArray(values) ? values.map(captureSpeciesKey).filter(Boolean) : []);
    } catch (error) {
        return new Set();
    }
}

function readEncounteredSpecies(player) {
    return readSpeciesSet(player, ENCOUNTERED_SPECIES_PROPERTY);
}

export function encounteredSpecies(player) {
    return readEncounteredSpecies(player);
}

export function markCaptureEncounter(player, pokemonOrSpecies) {
    const key = captureSpeciesKey(pokemonOrSpecies);
    if (!player || !key) return;
    const encountered = readEncounteredSpecies(player);
    if (encountered.has(key)) return;
    encountered.add(key);
    try {
        player.setDynamicProperty(ENCOUNTERED_SPECIES_PROPERTY, JSON.stringify([...encountered].sort()));
    } catch (error) {}
}

export function hasCaptureEncounter(player, pokemonOrSpecies, party = []) {
    const key = captureSpeciesKey(pokemonOrSpecies);
    if (!key) return false;
    if ((party || []).some(pokemon => captureSpeciesKey(pokemon) === key)) return true;
    return readEncounteredSpecies(player).has(key);
}

export function markSpeciesCaptured(player, pokemonOrSpecies) {
    const key = captureSpeciesKey(pokemonOrSpecies);
    if (!player || !key) return;
    const captured = readSpeciesSet(player, CAPTURED_SPECIES_PROPERTY);
    if (captured.has(key)) return;
    captured.add(key);
    try {
        player.setDynamicProperty(CAPTURED_SPECIES_PROPERTY, JSON.stringify([...captured].sort()));
    } catch (error) {}
}

export function capturedSpecies(player) {
    return readSpeciesSet(player, CAPTURED_SPECIES_PROPERTY);
}

export function hasCapturedSpecies(player, pokemonOrSpecies, party = []) {
    const key = captureSpeciesKey(pokemonOrSpecies);
    if (!key) return false;
    if ((party || []).some(pokemon => captureSpeciesKey(pokemon) === key)) return true;
    return readSpeciesSet(player, CAPTURED_SPECIES_PROPERTY).has(key);
}
