

import { world } from "@minecraft/server";

const CROP_CACHE = new Map();
const MAX_CACHE_ENTRIES = 10000;

function dimKey(dimension) {
    return String(dimension?.id || "minecraft:overworld");
}

function hash32(value, seed) {
    let hash = seed >>> 0;
    const text = String(value);
    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return hash.toString(16).padStart(8, "0");
}

export function coordKey(dimension, location) {
    const x = Math.floor(Number(location?.x) || 0);
    const y = Math.floor(Number(location?.y) || 0);
    const z = Math.floor(Number(location?.z) || 0);
    return `${dimKey(dimension)}:${x},${y},${z}`;
}

function dynamicPropertyKey(dimension, location) {
    const key = coordKey(dimension, location);
    return `bm_${hash32(key, 0x811c9dc5)}${hash32(key, 0x9e3779b9)}`;
}

export function getCropData(dimension, location) {
    if (!dimension || !location) return undefined;
    const key = coordKey(dimension, location);
    if (CROP_CACHE.has(key)) {
        return CROP_CACHE.get(key);
    }

    try {
        const propKey = dynamicPropertyKey(dimension, location);
        const raw = world.getDynamicProperty(propKey);
        if (typeof raw === "string" && raw.length > 0) {
            const data = JSON.parse(raw);
            if (CROP_CACHE.size >= MAX_CACHE_ENTRIES) {
                const firstKey = CROP_CACHE.keys().next().value;
                CROP_CACHE.delete(firstKey);
            }
            CROP_CACHE.set(key, data);
            return data;
        }
    } catch (error) {}

    return undefined;
}

export function setCropData(dimension, location, data) {
    if (!dimension || !location || !data) return;
    const key = coordKey(dimension, location);
    if (!CROP_CACHE.has(key) && CROP_CACHE.size >= MAX_CACHE_ENTRIES) {
        const firstKey = CROP_CACHE.keys().next().value;
        CROP_CACHE.delete(firstKey);
    }
    CROP_CACHE.set(key, data);

    try {
        const propKey = dynamicPropertyKey(dimension, location);
        world.setDynamicProperty(propKey, JSON.stringify(data));
    } catch (error) {}
}

export function deleteCropData(dimension, location) {
    if (!dimension || !location) return;
    const key = coordKey(dimension, location);
    CROP_CACHE.delete(key);

    try {
        const propKey = dynamicPropertyKey(dimension, location);
        world.setDynamicProperty(propKey, undefined);
    } catch (error) {}
}

export function clearCropCache() {
    CROP_CACHE.clear();
}
