export const EXTERNAL_LEVEL_CAP_PROPERTY = "lota:server_level_cap_v1";

export function setExternalLevelCap(player, rawLevelCap) {
    const levelCap = Math.floor(Number(rawLevelCap));
    if (!player?.isValid || !Number.isFinite(levelCap) || levelCap < 1 || levelCap > 100) return false;
    try {
        player.setDynamicProperty(EXTERNAL_LEVEL_CAP_PROPERTY, levelCap);
        return true;
    } catch (error) {
        return false;
    }
}
export function getEffectiveLevelCap(player) {
    try {
        const value = Math.floor(Number(player?.getDynamicProperty(EXTERNAL_LEVEL_CAP_PROPERTY)));
        if (Number.isFinite(value) && value >= 1 && value <= 100) return value;
    } catch (error) {}
    return 100;
}
