const STATUS_PARTICLE_IDS = Object.freeze({
    poison: "lota:battle_status_poisonpurplebubbles",
    toxic: "lota:battle_status_toxicintense",
    burn: "lota:battle_status_orangefireembers",
    paralysis: "lota:battle_status_electricarcs",
    sleep: "lota:battle_status_sleepzzz",
    freeze: "lota:battle_status_iceshards",
    confusion: "lota:battle_status_confusionbirds",
    leechSeed: "lota:battle_status_leechseed",
    partialTrap: "lota:battle_status_partialtrap",
    yawn: "lota:battle_status_yawnbubble"
});

const STATUS_ALIASES = Object.freeze({
    "": "",
    none: "",
    normal: "",
    healthy: "",
    clear: "",
    psn: "poison",
    poison: "poison",
    poisoned: "poison",
    poisoning: "poison",
    tox: "toxic",
    toxic: "toxic",
    toxicpoison: "toxic",
    badlypoisoned: "toxic",
    brn: "burn",
    burn: "burn",
    burned: "burn",
    burning: "burn",
    par: "paralysis",
    para: "paralysis",
    paralysis: "paralysis",
    paralyzed: "paralysis",
    paralysed: "paralysis",
    slp: "sleep",
    sleep: "sleep",
    asleep: "sleep",
    sleeping: "sleep",
    frz: "freeze",
    freeze: "freeze",
    frozen: "freeze",
    freezing: "freeze"
});

const VOLATILE_FIELDS = Object.freeze([
    "confusionTurns",
    "yawnTurns",
    "leechSeed",
    "partialTrapTurns",
    "nightmare",
    "flinch",
    "tauntTurns",
    "disableTurns",
    "encoreTurns"
]);

const DEFAULT_PULSE_TICKS = 4;

function readProperty(object, key) {
    if (!object) return { ok: false, value: undefined };
    try {
        return { ok: true, value: object[key] };
    } catch (error) {
        return { ok: false, value: undefined };
    }
}

function callProperty(object, key, args = []) {
    const member = readProperty(object, key);
    if (!member.ok || typeof member.value !== "function") return { ok: false, value: undefined };
    try {
        return { ok: true, value: member.value.apply(object, args) };
    } catch (error) {
        return { ok: false, value: undefined };
    }
}

function stringValue(value) {
    try {
        return String(value ?? "");
    } catch (error) {
        return "";
    }
}

function invoke(callback, args) {
    if (typeof callback !== "function") return undefined;
    try {
        return callback(...args);
    } catch (error) {
        return undefined;
    }
}

function safeNumber(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

function positiveCounter(state, key) {
    const value = readProperty(state, key);
    if (!value.ok) return 0;
    const number = safeNumber(value.value, 0);
    return number > 0 ? number : 0;
}

function trueFlag(state, key) {
    const value = readProperty(state, key);
    if (!value.ok) return false;
    return value.value === true || value.value === 1 || value.value === "true";
}

function pokemonUuid(pokemon) {
    const value = readProperty(pokemon, "uuid");
    return value.ok ? stringValue(value.value) : "";
}

function cleanStatusToken(value) {
    let token = stringValue(value).trim().toLowerCase();
    token = token.replace(/^(?:cobblemon|lota):/, "");
    token = token.replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, "");
    return token.replace(/[\s_-]+/g, "");
}

export function normalizeBattleStatus(value) {
    const token = cleanStatusToken(value);
    return STATUS_ALIASES[token] || "";
}

export function buildBattleStatusActors(session, accessors = {}) {
    if (!session) return [];
    const activePokemon = accessors.activePokemon;
    const resolveEntity = accessors.resolveBattlePokemonEntity || accessors.resolveEntity;
    const ownPokemon = invoke(activePokemon, [session]);
    const ownEntity = invoke(resolveEntity, [session]);
    if (readProperty(session, "battleType").value === "pvp") {
        return [{ key: "own", pokemon: ownPokemon, entity: ownEntity }];
    }
    const target = readProperty(session, "captureInProgress").value === true
        ? undefined
        : readProperty(session, "target").value;
    return [
        { key: "own", pokemon: ownPokemon, entity: ownEntity },
        { key: "opponent", pokemon: readProperty(session, "wildPokemon").value, entity: target }
    ];
}

function battleStateOf(pokemon) {
    const result = readProperty(pokemon, "battleState");
    if (!result.ok || !result.value || typeof result.value !== "object") return {};
    return result.value;
}

export function readBattleStatus(pokemon) {
    const state = battleStateOf(pokemon);
    const status = readProperty(pokemon, "statusCondition");
    const primary = normalizeBattleStatus(status.ok ? status.value : "");
    return Object.freeze({
        primary,
        confusionTurns: positiveCounter(state, "confusionTurns"),
        yawnTurns: positiveCounter(state, "yawnTurns"),
        leechSeed: trueFlag(state, "leechSeed"),
        partialTrapTurns: positiveCounter(state, "partialTrapTurns"),
        nightmare: trueFlag(state, "nightmare"),
        flinch: trueFlag(state, "flinch"),
        tauntTurns: positiveCounter(state, "tauntTurns"),
        disableTurns: positiveCounter(state, "disableTurns"),
        encoreTurns: positiveCounter(state, "encoreTurns")
    });
}

export function battleStatusSignature(pokemon) {
    const status = readBattleStatus(pokemon);
    return [
        status.primary,
        status.confusionTurns,
        status.yawnTurns,
        status.leechSeed ? 1 : 0,
        status.partialTrapTurns,
        status.nightmare ? 1 : 0
    ].join("|");
}

function visualDescriptor(key) {
    const particleId = STATUS_PARTICLE_IDS[key];
    if (!particleId) return undefined;
    return Object.freeze({
        key,
        particleId,
        id: particleId
    });
}

const STATUS_VISUALS = Object.freeze(Object.fromEntries(
    Object.keys(STATUS_PARTICLE_IDS).map(key => [key, visualDescriptor(key)])
));

function addVisual(visuals, key) {
    const particleId = STATUS_PARTICLE_IDS[key];
    if (!particleId || visuals.some(visual => visual.particleId === particleId)) return;
    const descriptor = STATUS_VISUALS[key];
    if (descriptor) visuals.push(descriptor);
}

function selectBattleStatusVisualsFromStatus(status) {
    const visuals = [];
    if (status.primary) addVisual(visuals, status.primary, "primary");
    if (status.confusionTurns > 0) addVisual(visuals, "confusion", "confusion");
    if (status.yawnTurns > 0) addVisual(visuals, "yawn", "yawn");
    if (status.leechSeed) addVisual(visuals, "leechSeed", "leechSeed");
    if (status.partialTrapTurns > 0) addVisual(visuals, "partialTrap", "partialTrap");
    if (status.nightmare && status.primary === "sleep") addVisual(visuals, "sleep", "nightmare");
    return visuals;
}

export function selectBattleStatusVisuals(pokemon) {
    return selectBattleStatusVisualsFromStatus(readBattleStatus(pokemon));
}

export function battleStatusParticleIds(pokemon) {
    return selectBattleStatusVisuals(pokemon).map(visual => visual.particleId);
}

function battleStatusSignatureFromStatus(status) {
    return [
        status.primary,
        status.confusionTurns,
        status.yawnTurns,
        status.leechSeed ? 1 : 0,
        status.partialTrapTurns,
        status.nightmare ? 1 : 0
    ].join("|");
}

function finiteLocation(location) {
    if (!location || typeof location !== "object") return undefined;
    const x = safeNumber(location.x, Number.NaN);
    const y = safeNumber(location.y, Number.NaN);
    const z = safeNumber(location.z, Number.NaN);
    if (![x, y, z].every(Number.isFinite)) return undefined;
    return { x, y, z };
}

export function isBattleStatusEntityValid(entity) {
    const value = readProperty(entity, "isValid");
    if (!value.ok || !entity) return false;
    try {
        return typeof value.value === "function"
            ? !!value.value.call(entity)
            : !!value.value;
    } catch (error) {
        return false;
    }
}

export function battleStatusEntityLocation(entity) {
    if (!isBattleStatusEntityValid(entity)) return undefined;
    const head = callProperty(entity, "getHeadLocation");
    const headLocation = finiteLocation(head.value);
    if (head.ok && headLocation) return headLocation;

    const rawLocation = readProperty(entity, "location");
    const location = finiteLocation(rawLocation.value);
    if (!rawLocation.ok || !location) return undefined;
    return {
        x: location.x,
        y: location.y + 0.8,
        z: location.z
    };
}

export function emitBattleStatusParticle(entity, particleId, location = battleStatusEntityLocation(entity)) {
    if (!isBattleStatusEntityValid(entity) || !particleId || !location) return false;
    const dimension = readProperty(entity, "dimension");
    if (!dimension.ok || !dimension.value) return false;
    const spawnParticle = readProperty(dimension.value, "spawnParticle");
    if (!spawnParticle.ok || typeof spawnParticle.value !== "function") return false;
    try {
        spawnParticle.value.call(dimension.value, particleId, location);
        return true;
    } catch (error) {
        return false;
    }
}

function entityId(entity) {
    const value = readProperty(entity, "id");
    return value.ok ? stringValue(value.value) : "";
}

function entityDimension(entity) {
    const value = readProperty(entity, "dimension");
    if (!value.ok || !value.value) return { value: undefined, id: "" };
    const id = readProperty(value.value, "id");
    return {
        value: value.value,
        id: id.ok ? stringValue(id.value) : ""
    };
}

function sessionKey(session) {
    if (session === undefined || session === null) return undefined;
    if (typeof session !== "object") return stringValue(session);
    for (const key of ["playerId", "id", "sessionId"]) {
        const value = readProperty(session, key);
        if (value.ok && value.value !== undefined && value.value !== null && stringValue(value.value)) {
            return stringValue(value.value);
        }
    }
    return session;
}

function actorRecord(actor, index) {
    if (!actor) return undefined;
    const entityResult = readProperty(actor, "entity");
    const pokemonResult = readProperty(actor, "pokemon");
    const entity = entityResult.ok && entityResult.value !== undefined ? entityResult.value : actor;
    const pokemon = pokemonResult.ok && pokemonResult.value !== undefined
        ? pokemonResult.value
        : undefined;
    const keyResult = readProperty(actor, "key");
    const roleResult = readProperty(actor, "role");
    const explicitKey = keyResult.ok ? keyResult.value : roleResult.value;
    const id = entityId(entity);
    const key = stringValue(explicitKey || id || `actor:${index}`);
    return { key, entity, pokemon };
}

function actorIsFainted(pokemon) {
    const hp = readProperty(pokemon, "currentHp");
    if (!hp.ok) return true;
    if (hp.value === undefined || hp.value === null || hp.value === "") return false;
    return safeNumber(hp.value, 0) <= 0;
}

function emitForActor(emitter, actor, visuals, sessionId) {
    const location = battleStatusEntityLocation(actor.entity);
    if (!location) return [];
    const emitted = [];
    for (const visual of visuals) {
        try {
            const result = emitter(actor.entity, visual.particleId, location, {
                sessionId,
                actorKey: actor.key,
                visual,
                location
            });
            if (result === false) continue;
            emitted.push({
                sessionId,
                actorKey: actor.key,
                entityId: entityId(actor.entity),
                particleId: visual.particleId,
                visual,
                location
            });
        } catch (error) {
        }
    }
    return emitted;
}

function sameDimension(previous, current) {
    if (previous.dimension === current.dimension) return true;
    return !!previous.dimensionId && previous.dimensionId === current.dimensionId;
}

function normalizeTick(tick) {
    const number = Number(tick);
    return Number.isFinite(number) ? number : 0;
}

export function createBattleStatusVisuals(options = {}) {
    const pulseTicks = Math.max(1, Math.floor(Number(options.pulseTicks) || DEFAULT_PULSE_TICKS));
    const emitter = typeof options.emit === "function" ? options.emit : emitBattleStatusParticle;
    const cache = new Map();

    function clearSession(session) {
        const key = sessionKey(session);
        if (key !== undefined) cache.delete(key);
    }

    function clearActor(session, actorKey) {
        const key = sessionKey(session);
        const actorMap = key === undefined ? undefined : cache.get(key);
        if (!actorMap) return;
        actorMap.delete(stringValue(actorKey));
        if (actorMap.size === 0) cache.delete(key);
    }

    function syncSession(session, actors = [], tick = 0, syncOptions = {}) {
        const key = sessionKey(session);
        if (key === undefined) return [];
        if (syncOptions.active === false || syncOptions.ended === true) {
            cache.delete(key);
            return [];
        }

        const actorMap = cache.get(key) || new Map();
        const seen = new Set();
        const now = normalizeTick(tick);
        const emitted = [];

        for (let index = 0; index < (Array.isArray(actors) ? actors.length : 0); index++) {
            const actor = actorRecord(actors[index], index);
            if (!actor) continue;
            seen.add(actor.key);
            const previous = actorMap.get(actor.key);
            const validEntity = isBattleStatusEntityValid(actor.entity);
            const fainted = actor.pokemon ? actorIsFainted(actor.pokemon) : true;
            const status = actor.pokemon ? readBattleStatus(actor.pokemon) : undefined;
            const visuals = status && validEntity && !fainted
                ? selectBattleStatusVisualsFromStatus(status)
                : [];
            const signature = status ? battleStatusSignatureFromStatus(status) : "";
            if (!actor.pokemon || !validEntity || fainted || visuals.length === 0) {
                actorMap.delete(actor.key);
                continue;
            }

            const dimension = entityDimension(actor.entity);
            const currentEntityId = entityId(actor.entity);
            const currentUuid = pokemonUuid(actor.pokemon);
            const changed = !previous
                || previous.entity !== actor.entity
                || previous.entityId !== currentEntityId
                || previous.pokemonUuid !== currentUuid
                || !sameDimension(previous, { dimension: dimension.value, dimensionId: dimension.id })
                || previous.statusSignature !== signature;
            const due = !previous
                || changed
                || !Number.isFinite(Number(previous.lastPulse))
                || now < Number(previous.lastPulse)
                || now - Number(previous.lastPulse) >= pulseTicks;

            const entry = {
                entity: actor.entity,
                entityId: currentEntityId,
                pokemonUuid: currentUuid,
                dimension: dimension.value,
                dimensionId: dimension.id,
                statusSignature: signature,
                lastPulse: due ? now : previous.lastPulse
            };
            actorMap.set(actor.key, entry);
            if (due) emitted.push(...emitForActor(emitter, actor, visuals, key));
        }

        for (const actorKey of actorMap.keys()) {
            if (!seen.has(actorKey)) actorMap.delete(actorKey);
        }
        if (actorMap.size === 0) cache.delete(key);
        else cache.set(key, actorMap);
        return emitted;
    }

    return Object.freeze({
        cache,
        sessions: cache,
        pulseTicks,
        syncSession,
        sync: syncSession,
        clearSession,
        clear: clearSession,
        clearActor
    });
}

export { STATUS_PARTICLE_IDS, VOLATILE_FIELDS };

