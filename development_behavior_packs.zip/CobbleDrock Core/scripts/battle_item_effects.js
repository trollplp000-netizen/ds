import { battleState, resetBattleState, statStage } from "./battle_effects.js";
import {
    applyFriendshipBerry,
    applyOranBerry,
    applySitrusBerry,
    applyFlavorPortionBerry,
    applyStatusCureBerry,
    applyPpRestoreBerry,
    canUseFriendshipBerry,
    canUseHpBerry,
    canCureStatus,
    canRestorePp
} from "./pokemon_item_effects.js";

const MAX_FRIENDSHIP = 255;
const GUARD_SPEC_TURNS = 5;

function pokemonName(pokemon) {
    return String(pokemon?.nickname || pokemon?.species || "Pokemon")
        .replace(/^.*:/, "")
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, character => character.toUpperCase());
}

function livingPokemon(pokemon) {
    return Number(pokemon?.currentHp) > 0;
}

function faintedPokemon(pokemon) {
    return !!pokemon && Number(pokemon.currentHp) <= 0;
}

function damagedLivingPokemon(pokemon) {
    return livingPokemon(pokemon) && Number(pokemon.currentHp) < Number(pokemon.maxHp);
}

function cleanStatus(value) {
    const status = String(value || "NONE").toLowerCase().replace(/[^a-z]/g, "");
    return status === "none" ? "" : status;
}

function hasPersistentStatus(pokemon, accepted = undefined) {
    const status = cleanStatus(pokemon?.statusCondition);
    if (!status) return false;
    if (!accepted) return true;
    return accepted.some(values => values.includes(status));
}

function missingPpMoves(pokemon) {
    return (pokemon?.moves || []).filter(move => Number(move?.pp) < Number(move?.maxPp));
}

function raiseFriendship(pokemon, amount) {
    const multiplier = amount > 0 && String(pokemon?.caughtBall || "").replace(/^.*:/, "") === "luxury_ball" ? 2 : 1;
    pokemon.friendship = Math.max(0, Math.min(MAX_FRIENDSHIP, Math.floor(Number(pokemon.friendship) || 0) + amount * multiplier));
}

function healPokemon(pokemon, amount) {
    const before = Math.max(0, Number(pokemon.currentHp) || 0);
    const maximum = Math.max(1, Number(pokemon.maxHp) || 1);
    pokemon.currentHp = Math.min(maximum, before + Math.max(0, Math.floor(Number(amount) || 0)));
    return Math.max(0, pokemon.currentHp - before);
}

function fixedHealItem(amount, options = {}) {
    return Object.freeze({
        canUse: damagedLivingPokemon,
        returnItem: options.returnItem,
        friendship: Number(options.friendship) || 0,
        apply: pokemon => {
            const healed = healPokemon(pokemon, amount);
            return [`${pokemonName(pokemon)} regained ${healed} HP!`];
        }
    });
}

function fullHealItem(options = {}) {
    return Object.freeze({
        canUse: damagedLivingPokemon,
        returnItem: options.returnItem,
        apply: pokemon => {
            const healed = healPokemon(pokemon, Number(pokemon.maxHp) || 1);
            if (options.cureStatus) {
                pokemon.statusCondition = "NONE";
                delete battleState(pokemon).confusionTurns;
            }
            return [`${pokemonName(pokemon)} regained ${healed} HP!`];
        }
    });
}

function reviveItem(ratio, options = {}) {
    return Object.freeze({
        canUse: faintedPokemon,
        friendship: Number(options.friendship) || 0,
        apply: pokemon => {
            const maximum = Math.max(1, Math.floor(Number(pokemon.maxHp) || 1));
            pokemon.currentHp = Math.max(1, options.ceil ? Math.ceil(maximum * ratio) : Math.floor(maximum * ratio));
            pokemon.statusCondition = "NONE";
            resetBattleState(pokemon);
            return [`${pokemonName(pokemon)} was revived!`];
        }
    });
}

function sharedBerryItem(canUse, apply) {
    return Object.freeze({
        canUse,
        apply: pokemon => {
            const result = apply(pokemon);
            if (!result || !result.success) return ["But it failed!"];
            return Array.isArray(result.messages) ? result.messages : [];
        }
    });
}

function sharedStatusCureBerryItem(acceptedGroups, options = {}) {
    const groups = acceptedGroups === "all" ? "all" : acceptedGroups;
    return sharedBerryItem(
        pokemon => canCureStatus(pokemon, groups, options),
        pokemon => applyStatusCureBerry(pokemon, groups, options)
    );
}

function sharedPortionBerryItem(dislikedStat) {
    return sharedBerryItem(
        pokemon => canUseHpBerry(pokemon),
        pokemon => applyFlavorPortionBerry(pokemon, dislikedStat)
    );
}

function sharedPpBerryItem() {
    return Object.freeze({
        canUse: pokemon => canRestorePp(pokemon),
        canUseMove: move => !!move && Number(move.pp) < Number(move.maxPp),
        requiresMove: true,
        apply: (pokemon, action) => {
            const result = applyPpRestoreBerry(pokemon, Math.floor(Number(action?.moveIndex)), 10);
            if (!result || !result.success) return ["But it failed!"];
            return result.messages;
        }
    });
}

const STATUS_GROUPS = Object.freeze({
    poison: ["psn", "poison", "poisoned", "tox", "toxic", "badlypoisoned"],
    sleep: ["slp", "sleep", "asleep"],
    burn: ["brn", "burn", "burned"],
    frozen: ["frz", "freeze", "frozen"],
    paralysis: ["par", "paralysis", "paralyzed"]
});

function statusCureItem(groups, options = {}) {
    const accepted = groups === "all" ? undefined : groups.map(group => STATUS_GROUPS[group]);
    const canCure = pokemon => !!(livingPokemon(pokemon) && (
        hasPersistentStatus(pokemon, accepted)
        || (options.confusion && Number(pokemon?.battleState?.confusionTurns) > 0)
        || (options.infatuation && (pokemon?.battleState?.infatuated === true || Number(pokemon?.battleState?.infatuationTurns) > 0))
    ));
    return Object.freeze({
        canUse: canCure,
        friendship: Number(options.friendship) || 0,
        apply: pokemon => {
            if (hasPersistentStatus(pokemon, accepted)) pokemon.statusCondition = "NONE";
            const state = battleState(pokemon);
            if (options.confusion) delete state.confusionTurns;
            if (options.infatuation) {
                delete state.infatuated;
                delete state.infatuationTurns;
            }
            return [`${pokemonName(pokemon)} was cured!`];
        }
    });
}

function statItem(stat, label) {
    return Object.freeze({
        canUse: livingPokemon,
        friendship: 1,
        apply: pokemon => {
            const state = battleState(pokemon);
            const before = statStage(pokemon, stat);
            const after = Math.min(6, before + 2);
            state.stages[stat] = after;
            return after > before
                ? [`${pokemonName(pokemon)}'s ${label} sharply rose!`]
                : [`${pokemonName(pokemon)}'s ${label} won't go any higher!`];
        }
    });
}

function elixirItem(maximum) {
    return Object.freeze({
        canUse: pokemon => livingPokemon(pokemon) && missingPpMoves(pokemon).length > 0,
        returnItem: "minecraft:glass_bottle",
        apply: pokemon => {
            for (const move of missingPpMoves(pokemon)) {
                move.pp = maximum ? move.maxPp : Math.min(Number(move.maxPp), Number(move.pp) + 10);
            }
            return [`${pokemonName(pokemon)}'s moves had their PP restored!`];
        }
    });
}

function etherItem(maximum, options = {}) {
    return Object.freeze({
        canUse: pokemon => livingPokemon(pokemon) && missingPpMoves(pokemon).length > 0,
        canUseMove: move => !!move && Number(move.pp) < Number(move.maxPp),
        requiresMove: true,
        returnItem: options.returnItem,
        apply: (pokemon, action) => {
            const move = pokemon.moves?.[Math.floor(Number(action?.moveIndex))];
            if (!move || Number(move.pp) >= Number(move.maxPp)) return ["But it failed!"];
            move.pp = maximum ? move.maxPp : Math.min(Number(move.maxPp), Number(move.pp) + 10);
            return [`${String(move.name || move.id || "The move")} had its PP restored!`];
        }
    });
}

export const BATTLE_ITEMS = Object.freeze({
    "lota:potion": fixedHealItem(20, { returnItem: "minecraft:glass_bottle" }),
    "lota:super_potion": fixedHealItem(60, { returnItem: "minecraft:glass_bottle" }),
    "lota:hyper_potion": fixedHealItem(120, { returnItem: "minecraft:glass_bottle" }),
    "lota:max_potion": fullHealItem({ returnItem: "minecraft:glass_bottle" }),
    "lota:full_restore": fullHealItem({ returnItem: "minecraft:glass_bottle", cureStatus: true }),
    "lota:berry_juice": fixedHealItem(20, { returnItem: "minecraft:bowl" }),
    "lota:energy_root": fixedHealItem(80, { friendship: -10 }),
    "lota:remedy": fixedHealItem(20, { friendship: -5 }),
    "lota:fine_remedy": fixedHealItem(60, { friendship: -5 }),
    "lota:superb_remedy": fixedHealItem(120, { friendship: -5 }),
    "lota:revive": reviveItem(0.5),
    "lota:max_revive": reviveItem(1),
    "lota:revival_herb": reviveItem(0.25, { friendship: -15 }),

    "lota:full_heal": statusCureItem("all"),
    "lota:heal_powder": statusCureItem("all", { friendship: -5 }),
    "lota:antidote": statusCureItem(["poison"]),
    "lota:awakening": statusCureItem(["sleep"]),
    "lota:burn_heal": statusCureItem(["burn"]),
    "lota:ice_heal": statusCureItem(["frozen"]),
    "lota:paralyze_heal": statusCureItem(["paralysis"]),

    "lota:ether": etherItem(false, { returnItem: "minecraft:glass_bottle" }),
    "lota:max_ether": etherItem(true, { returnItem: "minecraft:glass_bottle" }),
    "lota:elixir": elixirItem(false),
    "lota:max_elixir": elixirItem(true),

    "lota:x_attack": statItem("atk", "Attack"),
    "lota:x_defence": statItem("def", "Defense"),
    "lota:x_special_attack": statItem("spa", "Sp. Atk"),
    "lota:x_special_defence": statItem("spd", "Sp. Def"),
    "lota:x_speed": statItem("spe", "Speed"),
    "lota:x_accuracy": statItem("accuracy", "accuracy"),
    "lota:dire_hit": Object.freeze({
        canUse: livingPokemon,
        friendship: 1,
        apply: pokemon => {
            const state = battleState(pokemon);
            if (state.focusEnergy) return ["But it failed!"];
            state.focusEnergy = true;
            return [`${pokemonName(pokemon)} is getting pumped!`];
        }
    }),
    "lota:guard_spec": Object.freeze({
        canUse: livingPokemon,
        friendship: 1,
        apply: pokemon => {
            const state = battleState(pokemon);
            if (Number(state.guardSpecTurns) > 0) return ["But it failed!"];
            state.guardSpecTurns = GUARD_SPEC_TURNS;
            return [`${pokemonName(pokemon)} became shrouded in mist!`];
        }
    }),
    "lota:moomoo_milk": Object.freeze({
        canUse: livingPokemon,
        returnItem: "minecraft:glass_bottle",
        apply: pokemon => {
            battleState(pokemon).stages = {};
            return [`${pokemonName(pokemon)}'s stat changes were removed!`];
        }
    }),

    "lota:oran_berry": sharedBerryItem(pokemon => canUseHpBerry(pokemon), pokemon => applyOranBerry(pokemon)),
    "lota:sitrus_berry": sharedBerryItem(pokemon => canUseHpBerry(pokemon), pokemon => applySitrusBerry(pokemon)),
    "lota:figy_berry": sharedPortionBerryItem("attack"),
    "lota:wiki_berry": sharedPortionBerryItem("specialAttack"),
    "lota:mago_berry": sharedPortionBerryItem("speed"),
    "lota:aguav_berry": sharedPortionBerryItem("specialDefence"),
    "lota:iapapa_berry": sharedPortionBerryItem("defence"),
    "lota:cheri_berry": sharedStatusCureBerryItem(["paralysis"]),
    "lota:chesto_berry": sharedStatusCureBerryItem(["sleep"]),
    "lota:pecha_berry": sharedStatusCureBerryItem(["poison"]),
    "lota:rawst_berry": sharedStatusCureBerryItem(["burn"]),
    "lota:aspear_berry": sharedStatusCureBerryItem(["frozen"]),
    "lota:persim_berry": sharedStatusCureBerryItem([], { confusion: true }),
    "lota:lum_berry": sharedStatusCureBerryItem("all", { confusion: true }),
    "lota:eggant_berry": sharedStatusCureBerryItem([], { infatuation: true }),
    "lota:leppa_berry": sharedPpBerryItem(),
    "lota:hopo_berry": sharedPpBerryItem(),
    "lota:berry_juice": fixedHealItem(20),
    "lota:pomeg_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "pomeg_berry"), p => applyFriendshipBerry(p, "pomeg_berry")),
    "lota:kelpsy_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "kelpsy_berry"), p => applyFriendshipBerry(p, "kelpsy_berry")),
    "lota:qualot_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "qualot_berry"), p => applyFriendshipBerry(p, "qualot_berry")),
    "lota:hondew_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "hondew_berry"), p => applyFriendshipBerry(p, "hondew_berry")),
    "lota:grepa_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "grepa_berry"), p => applyFriendshipBerry(p, "grepa_berry")),
    "lota:tamato_berry": sharedBerryItem(p => canUseFriendshipBerry(p, "tamato_berry"), p => applyFriendshipBerry(p, "tamato_berry"))
});

export function applyBattleItemEffect(itemId, pokemon, action = undefined) {
    const item = BATTLE_ITEMS[itemId];
    if (!item || !pokemon || !item.canUse(pokemon)) return undefined;
    if (item.requiresMove) {
        const move = pokemon.moves?.[Math.floor(Number(action?.moveIndex))];
        if (!item.canUseMove(move)) return undefined;
    }
    if (item.friendship) raiseFriendship(pokemon, item.friendship);
    const messages = item.apply(pokemon, action);
    return {
        itemId,
        messages: Array.isArray(messages) ? messages : [],
        pokemon,
        returnItem: item.returnItem || ""
    };
}

export function guardSpecActive(pokemon) {
    return Number(pokemon?.battleState?.guardSpecTurns) > 0;
}

export function advanceBattleItemVolatiles(pokemon) {
    if (!pokemon?.battleState) return [];
    const state = battleState(pokemon);
    const guardSpecTurns = Math.floor(Number(state.guardSpecTurns));
    if (!Number.isFinite(guardSpecTurns) || guardSpecTurns <= 0) return [];
    state.guardSpecTurns = Math.max(0, guardSpecTurns - 1);
    if (state.guardSpecTurns > 0) return [];
    delete state.guardSpecTurns;
    return ["The mist surrounding the Pokemon faded!"];
}

export const BATTLE_ITEM_RULES = Object.freeze({
    guardSpecTurns: GUARD_SPEC_TURNS,
    statBoostStages: 2,
    maxFriendship: MAX_FRIENDSHIP
});
