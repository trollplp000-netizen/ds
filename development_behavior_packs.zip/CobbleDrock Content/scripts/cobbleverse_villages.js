import { system, world } from "@minecraft/server";
import {
    VILLAGE_STRUCTURE_PARTS,
    VILLAGE_STRUCTURE_SIZES
} from "./cobbleverse_village_structure_data.js";
import { VILLAGE_TYPES } from "./cobbleverse_village_data.js";
import {
    buildVillagePlan,
    chooseVillageType,
    villageHash,
    villagePropertyId,
    villageRegionForBlock
} from "./cobbleverse_village_rules.js";

const WORLD_SEED_FALLBACK = 31415926;
const WATER_COLUMN_BLOCKS = new Set([
    "minecraft:water",
    "minecraft:seagrass",
    "minecraft:tall_seagrass",
    "minecraft:kelp",
    "minecraft:kelp_plant"
]);
const MAX_WATER_COLUMN_HEIGHT = 96;

const GROUND_BLOCKS = new Set([
    "minecraft:grass_block",
    "minecraft:dirt",
    "minecraft:coarse_dirt",
    "minecraft:podzol",
    "minecraft:mycelium",
    "minecraft:stone",
    "minecraft:sand",
    "minecraft:red_sand",
    "minecraft:snow",
    "minecraft:snow_layer",
    "minecraft:gravel",
    "minecraft:clay",
    "minecraft:mud",
    "minecraft:dirt_with_roots"
]);

function worldSeed() {
    try {
        const value = world.getDynamicProperty("lota:village_seed");
        if (Number.isFinite(Number(value))) return Number(value);
        const generated = villageHash(Date.now(), Math.random() * 0x7fffffff, WORLD_SEED_FALLBACK);
        world.setDynamicProperty("lota:village_seed", generated);
        return generated;
    } catch (error) {
        return WORLD_SEED_FALLBACK;
    }
}

function getWaterSurface(dimension, x, startY, z) {
    let surface;
    for (let rise = 0; rise < MAX_WATER_COLUMN_HEIGHT; rise++) {
        const block = dimension.getBlock({ x, y: startY + rise, z });
        if (!block) break;
        if (WATER_COLUMN_BLOCKS.has(block.typeId)) {
            surface = block;
            continue;
        }
        if (block.typeId === "minecraft:lava") return undefined;
        break;
    }
    return surface;
}

function writePlan(plan) {
    try {
        world.setDynamicProperty(
            villagePropertyId(plan.regionX, plan.regionZ),
            JSON.stringify(plan)
        );
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockVillage] Failed to save ${plan.id}: ${error}`);
        return false;
    }
}

function getTopSurface(dimension, x, z) {
    const blockX = Math.floor(x);
    const blockZ = Math.floor(z);
    try {
        const top = dimension.getTopmostBlock({ x: blockX, z: blockZ });
        if (!top) return undefined;
        let block = top;
        for (let depth = 0; depth < 12 && block; depth++) {
            if (WATER_COLUMN_BLOCKS.has(block.typeId)) {
                const waterSurface = getWaterSurface(
                    dimension,
                    blockX,
                    block.location.y,
                    blockZ
                );
                if (!waterSurface) return undefined;
                return {
                    x: blockX,
                    y: waterSurface.location.y,
                    z: blockZ,
                    block: waterSurface,
                    liquid: true
                };
            }
            if (GROUND_BLOCKS.has(block.typeId)) {
                const waterSurface = getWaterSurface(
                    dimension,
                    blockX,
                    block.location.y + 1,
                    blockZ
                );
                if (waterSurface) {
                    return {
                        x: blockX,
                        y: waterSurface.location.y,
                        z: blockZ,
                        block: waterSurface,
                        liquid: true
                    };
                }
                return { x: blockX, y: block.location.y, z: blockZ, block };
            }
            if (block.typeId === "minecraft:lava") return undefined;
            block = dimension.getBlock({ x: blockX, y: block.location.y - 1, z: blockZ });
        }
    } catch (error) {}
    return undefined;
}

function biomeAt(dimension, surface) {
    try {
        return dimension.getBiome({
            x: surface.x,
            y: surface.y + 1,
            z: surface.z
        });
    } catch (error) {
        return "";
    }
}

function structureOrigin(plan, piece, surface) {
    const size = VILLAGE_STRUCTURE_SIZES[piece.structure] || [1, 1, 1];
    return {
        x: Math.floor(plan.x + piece.dx - size[0] / 2),
        y: surface.y,
        z: Math.floor(plan.z + piece.dz - size[2] / 2)
    };
}

function makePath(dimension, from, to) {
    const distance = Math.max(Math.abs(to.x - from.x), Math.abs(to.z - from.z));
    if (distance <= 1) return;
    for (let step = 0; step <= distance; step += 2) {
        const ratio = step / distance;
        const x = Math.round(from.x + (to.x - from.x) * ratio);
        const z = Math.round(from.z + (to.z - from.z) * ratio);
        const surface = getTopSurface(dimension, x, z);
        if (!surface) continue;
        try {
            const block = dimension.getBlock(surface);
            if (block && GROUND_BLOCKS.has(block.typeId)) block.setType("minecraft:grass_path");
        } catch (error) {}
    }
}

function placePiece(dimension, plan, piece) {
    const center = { x: plan.x + piece.dx, z: plan.z + piece.dz };
    const surface = getTopSurface(dimension, center.x, center.z);
    if (!surface) return false;
    const origin = structureOrigin(plan, piece, surface);
    try {
        const parts = VILLAGE_STRUCTURE_PARTS[piece.structure] || [{
            id: `lota:villages/${piece.structure}`,
            offset: [0, 0, 0]
        }];
        for (const part of parts) {
            world.structureManager.place(
                part.id,
                dimension,
                {
                    x: origin.x + part.offset[0],
                    y: origin.y + part.offset[1],
                    z: origin.z + part.offset[2]
                },
                {
                    includeBlocks: true,
                    includeEntities: false,
                    waterlogged: false
                }
            );
        }
        piece.placed = true;
        piece.y = surface.y;
        makePath(dimension, { x: plan.x, z: plan.z }, center);
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockVillage] Failed to place ${piece.structure}: ${error}`);
        return false;
    }
}

function placeAllPieces(dimension, plan) {
    let placed = 0;
    for (const piece of plan.pieces || []) {
        if (piece.placed || !placePiece(dimension, plan, piece)) continue;
        placed++;
    }
    writePlan(plan);
    return placed;
}

function planAtLocation(dimension, location, requested = "") {
    const seed = worldSeed();
    const region = villageRegionForBlock(location.x, location.z);
    const surface = getTopSurface(dimension, location.x, location.z);
    if (!surface) return undefined;
    const exactType = VILLAGE_TYPES.find(entry => entry.id === requested);
    const themeTypes = VILLAGE_TYPES.filter(entry => entry.theme === requested);
    const type = exactType
        || (themeTypes.length
            ? themeTypes[villageHash(region.x, region.z, seed) % themeTypes.length]
            : chooseVillageType(biomeAt(dimension, surface), region.x, region.z, seed));
    if (!type) return undefined;
    return buildVillagePlan({
        regionX: region.x,
        regionZ: region.z,
        chunkX: Math.floor(location.x / 16),
        chunkZ: Math.floor(location.z / 16),
        x: Math.floor(location.x),
        z: Math.floor(location.z)
    }, type, seed);
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== "lota:village" || event.sourceEntity?.typeId !== "minecraft:player") return;
    const player = event.sourceEntity;
    const requested = String(event.message || "").trim().toLowerCase();
    const plan = planAtLocation(player.dimension, player.location, requested);
    if (!plan) {
        player.sendMessage({ translate: "lota.message.village.unavailable" });
        return;
    }
    writePlan(plan);
    const placed = placeAllPieces(player.dimension, plan);
    player.sendMessage({ rawtext: [
        { translate: "lota.message.village.placed_prefix" },
        { text: ` ${plan.type}` },
        { translate: "lota.message.village.placed_suffix" },
        { text: `${placed}/${plan.pieces.length})§r` }
    ] });
});
