import { ScriptEventSource, system, world } from "@minecraft/server";
import { trainerRequestMessages } from "./core_bridge_transport.js";

const API_VERSION = 1;
const POKEMON_SPAWN_API_VERSION = 2;
const TRAINER_REQUEST_EVENT = "lota:server_trainer_battle_request_v1";
const TRAINER_RESULT_EVENT = "lota:server_trainer_battle_result_v1";
const HUD_REQUEST_EVENT = "lota:server_hud_transient_v1";
const NATURAL_SPAWN_ZONE_EVENT = "lota:server_natural_spawn_zone_v1";
const POKEMON_SPAWN_REQUEST_EVENT = "lota:server_pokemon_spawn_request_v2";
const POKEMON_SPAWN_RESULT_EVENT = "lota:server_pokemon_spawn_result_v2";
const POKEMON_GRANT_API_VERSION = 1;
const POKEMON_GRANT_REQUEST_EVENT = "lota:server_pokemon_grant_request_v1";
const POKEMON_GRANT_RESULT_EVENT = "lota:server_pokemon_grant_result_v1";
const RAID_REQUEST_EVENT = "lota:server_raid_battle_request_v1";
const RAID_RESET_EVENT = "lota:server_raid_battle_reset_v1";
const RAID_RESULT_EVENT = "lota:server_raid_battle_result_v1";
const RAID_REWARD_RESULT_EVENT = "lota:server_raid_reward_result_v1";
const PARTY_HUD_REFRESH_EVENT = "lota:server_party_hud_refresh_v1";
const LEVEL_CAP_SYNC_EVENT = "lota:server_level_cap_sync_v1";
const trainerResultListeners = new Set();
const pokemonSpawnResultListeners = new Set();
const pokemonGrantResultListeners = new Set();
const raidResultListeners = new Set();
const raidRewardResultListeners = new Set();
const hudTokens = new Map();
let requestSequence = 0;

function send(eventId, payload) {
    try {
        system.sendScriptEvent(eventId, JSON.stringify(payload));
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockContent] Core event '${eventId}' failed: ${error}`);
        return false;
    }
}

export function requestCoreTrainerBattle(player, trainerEntity, options) {
    if (!player?.isValid || !trainerEntity?.isValid) return undefined;
    const requestId = `cobbledrock:${system.currentTick}:${++requestSequence}:${player.id}`;
    const request = {
        ...options,
        version: API_VERSION,
        requestId,
        playerId: String(player.id),
        trainerEntityId: trainerEntity.id
    };
    let messages;
    try { messages = trainerRequestMessages(request); }
    catch (error) {
        console.warn(`[CobbleDrockContent] Trainer request framing failed: ${error}`);
        return undefined;
    }
    for (const message of messages) {
        try { system.sendScriptEvent(TRAINER_REQUEST_EVENT, message); }
        catch (error) {
            console.warn(`[CobbleDrockContent] Trainer request event failed: ${error}`);
            return undefined;
        }
    }
    return requestId;
}

export function syncCoreLevelCap(player, levelCap) {
    if (!player?.isValid) return false;
    const normalized = Math.max(1, Math.min(100, Math.floor(Number(levelCap) || 100)));
    return send(LEVEL_CAP_SYNC_EVENT, {
        version: API_VERSION,
        playerId: String(player.id),
        levelCap: normalized
    });
}

export function subscribeCoreTrainerResult(listener) {
    trainerResultListeners.add(listener);
    return () => trainerResultListeners.delete(listener);
}

export function setCoreHudTransient(player, key, token) {
    if (!player?.isValid) return;
    const cacheKey = `${player.id}:${key}`;
    if (hudTokens.get(cacheKey) === token) return;
    if (send(HUD_REQUEST_EVENT, {
        version: API_VERSION,
        action: "set",
        playerId: player.id,
        key,
        token
    })) hudTokens.set(cacheKey, token);
}

export function clearCoreHudTransient(player, key) {
    if (!player?.isValid) return;
    hudTokens.delete(`${player.id}:${key}`);
    send(HUD_REQUEST_EVENT, {
        version: API_VERSION,
        action: "clear",
        playerId: player.id,
        key
    });
}

export function registerCoreNaturalSpawnZone(zoneId, dimensionId, min, max, cleanupExisting = false) {
    return send(NATURAL_SPAWN_ZONE_EVENT, {
        version: API_VERSION,
        action: "upsert",
        zoneId,
        dimensionId,
        min,
        max,
        cleanupExisting
    });
}

export function removeCoreNaturalSpawnZone(zoneId) {
    return send(NATURAL_SPAWN_ZONE_EVENT, {
        version: API_VERSION,
        action: "remove",
        zoneId
    });
}

export function requestCorePokemonSpawn(player, options) {
    if (!player?.isValid || !options || typeof options !== "object") return undefined;
    const requestId = `cobbledrock-spawn:${system.currentTick}:${++requestSequence}:${player.id}`;
    return send(POKEMON_SPAWN_REQUEST_EVENT, {
        ...options,
        version: POKEMON_SPAWN_API_VERSION,
        requestId,
        playerId: String(player.id),
        dimensionId: String(player.dimension.id)
    }) ? requestId : undefined;
}

export function subscribeCorePokemonSpawnResult(listener) {
    pokemonSpawnResultListeners.add(listener);
    return () => pokemonSpawnResultListeners.delete(listener);
}

export function requestCorePokemonGrant(player, options) {
    if (!player?.isValid || !options || typeof options !== "object") return undefined;
    const requestId = `cobbledrock-grant:${system.currentTick}:${++requestSequence}:${player.id}`;
    return send(POKEMON_GRANT_REQUEST_EVENT, {
        ...options,
        version: POKEMON_GRANT_API_VERSION,
        requestId,
        playerId: String(player.id)
    }) ? requestId : undefined;
}

export function subscribeCorePokemonGrantResult(listener) {
    pokemonGrantResultListeners.add(listener);
    return () => pokemonGrantResultListeners.delete(listener);
}

export function requestCoreRaidBattle(anchorEntity, options) {
    if (!anchorEntity?.isValid || !options || typeof options !== "object") return undefined;
    const requestId = `cobbledrock-raid:${system.currentTick}:${++requestSequence}`;
    return send(RAID_REQUEST_EVENT, {
        ...options,
        version: API_VERSION,
        requestId,
        anchorEntityId: String(anchorEntity.id)
    }) ? requestId : undefined;
}

export function resetCoreRaidBattle(playerId, raidId = "", detail = "raid_replaced") {
    const normalizedPlayerId = String(playerId || "");
    if (!normalizedPlayerId) return false;
    return send(RAID_RESET_EVENT, {
        version: API_VERSION,
        playerId: normalizedPlayerId,
        raidId: String(raidId || ""),
        detail: String(detail || "raid_replaced")
    });
}

export function refreshCorePartyHud(player) {
    if (!player?.isValid) return false;
    return send(PARTY_HUD_REFRESH_EVENT, {
        version: API_VERSION,
        playerId: String(player.id)
    });
}

export function subscribeCoreRaidResult(listener) {
    raidResultListeners.add(listener);
    return () => raidResultListeners.delete(listener);
}

export function subscribeCoreRaidRewardResult(listener) {
    raidRewardResultListeners.add(listener);
    return () => raidRewardResultListeners.delete(listener);
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (![TRAINER_RESULT_EVENT, POKEMON_SPAWN_RESULT_EVENT, POKEMON_GRANT_RESULT_EVENT,
        RAID_RESULT_EVENT, RAID_REWARD_RESULT_EVENT].includes(event.id)
        || event.sourceType !== ScriptEventSource.Server) return;
    let result;
    try { result = JSON.parse(String(event.message || "{}")); }
    catch (error) { return; }
    const expectedVersion = event.id === POKEMON_SPAWN_RESULT_EVENT
        ? POKEMON_SPAWN_API_VERSION
        : event.id === POKEMON_GRANT_RESULT_EVENT
            ? POKEMON_GRANT_API_VERSION
            : API_VERSION;
    if (Number(result?.version) !== expectedVersion) return;
    const listeners = event.id === TRAINER_RESULT_EVENT
        ? trainerResultListeners
        : event.id === POKEMON_SPAWN_RESULT_EVENT
            ? pokemonSpawnResultListeners
            : event.id === POKEMON_GRANT_RESULT_EVENT
                ? pokemonGrantResultListeners
                : event.id === RAID_RESULT_EVENT
                    ? raidResultListeners
                    : raidRewardResultListeners;
    for (const listener of listeners) {
        try { listener(result); }
        catch (error) { console.warn(`[CobbleDrockContent] Core result listener failed: ${error}`); }
    }
});

world.afterEvents.playerLeave.subscribe(event => {
    for (const key of hudTokens.keys()) {
        if (key.startsWith(`${event.playerId}:`)) hudTokens.delete(key);
    }
});
