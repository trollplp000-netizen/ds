export const GYM_FIRST_CLEAR_REWARDS = Object.freeze([
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:hard_stone", amount: 1 }),
            Object.freeze({ typeId: "lota:great_ball", amount: 4 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:mystic_water", amount: 1 }),
            Object.freeze({ typeId: "lota:net_ball", amount: 4 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:thunder_stone", amount: 1 }),
            Object.freeze({ typeId: "lota:quick_ball", amount: 3 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:black_belt", amount: 1 }),
            Object.freeze({ typeId: "lota:timer_ball", amount: 3 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:charcoal_stick", amount: 1 }),
            Object.freeze({ typeId: "lota:repeat_ball", amount: 3 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:metal_coat", amount: 1 }),
            Object.freeze({ typeId: "lota:ultra_ball", amount: 3 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:miracle_seed", amount: 1 }),
            Object.freeze({ typeId: "lota:nest_ball", amount: 4 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:sharp_beak", amount: 1 }),
            Object.freeze({ typeId: "lota:fast_ball", amount: 3 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:spell_tag", amount: 1 }),
            Object.freeze({ typeId: "lota:dusk_ball", amount: 5 })
        ])
    }),
    Object.freeze({
        items: Object.freeze([
            Object.freeze({ typeId: "lota:soft_sand", amount: 1 }),
            Object.freeze({ typeId: "lota:master_ball", amount: 1 })
        ]),
        pokemon: Object.freeze({
            species: "mew",
            level: 50,
            caughtBall: "master_ball",
            minPerfectIvs: 3
        })
    })
]);
