import { MolangVariableMap, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    refreshCorePartyHud,
    requestCoreRaidBattle,
    resetCoreRaidBattle,
    subscribeCoreRaidResult
} from "./core_bridge.js";
import {
    RAID_DEN_BLOCK_ID,
    RAID_DEN_MAX_CLEARS,
    RAID_DEN_MAX_PLAYERS,
    RAID_DEN_TYPES,
    raidDenCycle,
    raidDenHash,
    raidDenProfile,
    raidDenPropertyId
} from "./raid_den_rules.js";

const OVERWORLD = "minecraft:overworld";
const RAID_DIMENSION = "lota:raid_arena";
const WORLD_SEED_PROPERTY = "lota:raid_den_seed";
const RETURN_PROPERTY = "lota:raid_return_v1";
const RAID_BOSS_TAG = "lota:content_raid_boss";
const LEGACY_RAID_BEAM_ENTITY = "lota:raid_den_beam";
const RAID_BEAM_PARTICLE = "lota:raid_den_beam";
const ARENA_STRUCTURE = "lota:raid_den/basic";
const ARENA_CLEAR_STRUCTURE = "lota:raid_den/clear";
const ARENA_BASE = Object.freeze({ x: 0, y: 96, z: 0 });
const ARENA_SPACING = 256;
const ARENA_REGION_LIMIT = 64;
const ARENA_SIZE = Object.freeze({ x: 46, y: 23, z: 48 });
const ARENA_OFFSET = Object.freeze({ x: -24, y: -3, z: -29 });
const ARENA_SHELL_PROBES = Object.freeze([
    Object.freeze({ x: 0, y: 0, z: 0 }),
    Object.freeze({ x: 45, y: 0, z: 47 }),
    Object.freeze({ x: 0, y: 22, z: 47 }),
    Object.freeze({ x: 45, y: 22, z: 0 }),
    Object.freeze({ x: 24, y: 22, z: 24 })
]);
const PLAYER_OFFSETS = Object.freeze([
    Object.freeze({ x: 0.5, y: 0, z: -0.5 }),
    Object.freeze({ x: -1.5, y: 0, z: 1.5 }),
    Object.freeze({ x: 2.5, y: 0, z: 1.5 }),
    Object.freeze({ x: 0.5, y: 0, z: 3.5 })
]);
const BOSS_OFFSET = Object.freeze({ x: 0.5, y: 0, z: -14.5 });
const EXIT_CRYSTAL_OFFSET = Object.freeze({ x: 0, y: 0, z: 2 });
const ARENA_TIMEOUT_TICKS = 20 * 120;
const RAID_BOSS_TRIGGER_DISTANCE = 8;
const RAID_BEAM_VIEW_DISTANCE = 256;
const RAID_BEAM_COLORS = Object.freeze({
    none: 4079166,
    normal: 16383998,
    fighting: 16742955,
    flying: 11390705,
    poison: 6109847,
    ground: 10446848,
    rock: 11889741,
    bug: 8107086,
    ghost: 4398799,
    steel: 8559783,
    fire: 13842747,
    water: 4805581,
    grass: 3007286,
    electric: 15251206,
    psychic: 11608720,
    ice: 9362175,
    dragon: 1069463,
    dark: 657930,
    fairy: 14111371,
    stellar: 16383998
});
const legacyBeamCleanup = new Set();
const denSparkleTicks = new Map();
const arenaRaids = new Map();
const bossRaids = new Map();
const exitCrystals = new Map();
const pendingRaids = new Map();
const pendingJoinRequests = new Set();
const playerArenaRaids = new Map();
const playerArenaEntities = new Map();
const occupiedArenaRegions = new Set();
const enteringPlayers = new Set();

function playerById(playerId) {
    const id = String(playerId || "");
    return id ? world.getAllPlayers().find(player => String(player.id) === id) : undefined;
}

function distanceSquared(first, second) {
    const dx = Number(first.x) - Number(second.x);
    const dy = Number(first.y) - Number(second.y);
    const dz = Number(first.z) - Number(second.z);
    return dx * dx + dy * dy + dz * dz;
}

function add(first, second) {
    return {
        x: Number(first.x) + Number(second.x),
        y: Number(first.y) + Number(second.y),
        z: Number(first.z) + Number(second.z)
    };
}

function nextTick() {
    return new Promise(resolve => system.run(resolve));
}

function denKey(state) {
    return `${OVERWORLD}:${state.chunkX}:${state.chunkZ}`;
}

function blockKey(dimensionId, location) {
    return `${dimensionId}:${Math.floor(location.x)}:${Math.floor(location.y)}:${Math.floor(location.z)}`;
}

function currentAbsoluteTime() {
    try {
        const value = world.getAbsoluteTime();
        if (Number.isFinite(Number(value))) return Number(value);
    } catch (error) {}
    return system.currentTick;
}

function currentCycle() {
    return raidDenCycle(currentAbsoluteTime());
}

function raidWorldSeed() {
    try {
        const stored = world.getDynamicProperty(WORLD_SEED_PROPERTY);
        if (Number.isFinite(Number(stored))) return Number(stored);
        const generated = raidDenHash(Date.now(), Math.random() * 0x7fffffff, 0x44454e53);
        world.setDynamicProperty(WORLD_SEED_PROPERTY, generated);
        return generated;
    } catch (error) {
        return 0x434f4242;
    }
}

function readState(chunkX, chunkZ) {
    try {
        const raw = world.getDynamicProperty(raidDenPropertyId(chunkX, chunkZ));
        if (typeof raw !== "string") return undefined;
        const state = JSON.parse(raw);
        if (Number(state?.version) !== 1 || !Number.isInteger(state?.x)
            || !Number.isInteger(state?.y) || !Number.isInteger(state?.z)) return undefined;
        return state;
    } catch (error) {
        return undefined;
    }
}

function writeState(state) {
    try {
        world.setDynamicProperty(raidDenPropertyId(state.chunkX, state.chunkZ), JSON.stringify(state));
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockRaidDens] Failed to save den ${state.chunkX}:${state.chunkZ}: ${error}`);
        return false;
    }
}

function deleteState(state) {
    try {
        world.setDynamicProperty(raidDenPropertyId(state.chunkX, state.chunkZ), undefined);
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockRaidDens] Failed to delete den ${state.chunkX}:${state.chunkZ}: ${error}`);
        return false;
    }
}

function refreshState(state) {
    const cycle = currentCycle();
    if (Number(state.cycle) !== cycle) {
        state.cycle = cycle;
        state.clears = 0;
        state.clearedPlayers = [];
        writeState(state);
    }
    if (!Array.isArray(state.clearedPlayers)) state.clearedPlayers = [];
    return { state, cycle, profile: raidDenProfile(state, raidWorldSeed(), cycle) };
}

function denIsActive(state) {
    return Math.max(0, Number(state?.clears) || 0) < RAID_DEN_MAX_CLEARS;
}

function playerClearedDen(state, playerId) {
    return Array.isArray(state?.clearedPlayers) && state.clearedPlayers.includes(String(playerId || ""));
}

function blockAtState(state) {
    try { return world.getDimension(OVERWORLD).getBlock({ x: state.x, y: state.y, z: state.z }); }
    catch (error) { return undefined; }
}

function removeLegacyDenBeam(key, state = undefined) {
    legacyBeamCleanup.add(key);
    if (!state) return;
    const location = { x: state.x + 0.5, y: state.y + 0.05, z: state.z + 0.5 };
    try {
        for (const entity of world.getDimension(OVERWORLD).getEntities({
            type: LEGACY_RAID_BEAM_ENTITY,
            location,
            maxDistance: 1.5
        })) {
            entity.remove();
        }
    } catch (error) {}
}

function beamVariables(state, profile) {
    const packed = RAID_BEAM_COLORS[String(profile?.boss?.raidType || "normal").toLowerCase()]
        ?? RAID_BEAM_COLORS.normal;
    const variables = new MolangVariableMap();
    const beamHeight = Math.max(32, 512 - (Number(state.y) + 0.15));
    variables.setFloat("variable.raid_beam_half_height", beamHeight * 0.5);
    variables.setFloat("variable.raid_beam_width", 0.6);
    variables.setFloat("variable.raid_r", ((packed >> 16) & 255) / 255);
    variables.setFloat("variable.raid_g", ((packed >> 8) & 255) / 255);
    variables.setFloat("variable.raid_b", (packed & 255) / 255);
    variables.setFloat("variable.raid_alpha", Math.max(1, Math.min(7, Number(profile?.tier) || 1)) * 32 / 255);
    return variables;
}

function refreshDenBeam(block, state, profile) {
    const key = denKey(state);
    if (!legacyBeamCleanup.has(key)) removeLegacyDenBeam(key, state);
    if (!denIsActive(state)) return;
    const dimension = block.dimension;
    const location = { x: state.x + 0.5, y: state.y + 0.15, z: state.z + 0.5 };
    if (!dimension.getPlayers({ location, maxDistance: RAID_BEAM_VIEW_DISTANCE }).length) return;
    const variables = beamVariables(state, profile);
    try { dimension.spawnParticle(RAID_BEAM_PARTICLE, location, variables); } catch (error) {}
}

function refreshDenSparkle(block, state) {
    const key = denKey(state);
    const location = { x: state.x + 0.5, y: state.y + 0.05, z: state.z + 0.5 };
    if (!denIsActive(state) || !block.dimension.getPlayers({ location, maxDistance: 64 }).length) {
        denSparkleTicks.delete(key);
        return;
    }
    const lastSparkle = denSparkleTicks.get(key) || 0;
    if (system.currentTick - lastSparkle < 56) return;
    try { block.dimension.spawnParticle("lota:raid_den_sparkle", location); } catch (error) {}
    denSparkleTicks.set(key, system.currentTick);
}

function syncCrystal(state, profile, loadedBlock = undefined) {
    const block = loadedBlock || blockAtState(state);
    if (block?.typeId !== RAID_DEN_BLOCK_ID) return false;
    try {
        const absoluteIndex = RAID_DEN_TYPES.indexOf(profile.boss.raidType);
        if (absoluteIndex < 0) return false;
        const high = absoluteIndex >= 16;
        const index = high ? absoluteIndex - 16 : absoluteIndex;
        const active = denIsActive(state);
        if (Number(block.permutation.getState("lota:raid_type_index")) !== index
            || (block.permutation.getState("lota:raid_type_high") === true) !== high
            || (block.permutation.getState("lota:raid_active") === true) !== active) {
            block.setPermutation(block.permutation
                .withState("lota:raid_type_index", index)
                .withState("lota:raid_type_high", high)
                .withState("lota:raid_active", active));
        }
        return true;
    } catch (error) {
        return false;
    }
}

function ensureDenState(block) {
    if (block?.typeId !== RAID_DEN_BLOCK_ID || block.dimension?.id !== OVERWORLD) return undefined;
    const location = block.location;
    const chunkX = Math.floor(location.x / 16);
    const chunkZ = Math.floor(location.z / 16);
    const stored = readState(chunkX, chunkZ);
    if (stored) {
        if (stored.x === location.x && stored.y === location.y && stored.z === location.z) return stored;
        if (blockAtState(stored)?.typeId === RAID_DEN_BLOCK_ID) return undefined;
        deleteState(stored);
    }
    const state = {
        version: 1,
        chunkX,
        chunkZ,
        x: location.x,
        y: location.y,
        z: location.z,
        cycle: currentCycle(),
        clears: 0,
        clearedPlayers: []
    };
    if (!writeState(state)) return undefined;
    return state;
}

function speciesName(species) {
    return String(species || "Unknown").replace(/_/g, " ").replace(/\b\w/g, letter => letter.toUpperCase());
}

function arenaCoordinate(index) {
    if (index === 0) return { ...ARENA_BASE };
    const ring = Math.ceil((Math.sqrt(index + 1) - 1) / 2);
    const side = 2 * ring;
    const start = (2 * ring - 1) * (2 * ring - 1);
    const offset = index - start;
    let x;
    let z;
    if (offset < side) {
        x = ring;
        z = -ring + offset;
    } else if (offset < 2 * side) {
        x = ring - (offset - side);
        z = ring;
    } else if (offset < 3 * side) {
        x = -ring;
        z = ring - (offset - 2 * side);
    } else {
        x = -ring + (offset - 3 * side);
        z = -ring;
    }
    return {
        x: ARENA_BASE.x + x * ARENA_SPACING,
        y: ARENA_BASE.y,
        z: ARENA_BASE.z + z * ARENA_SPACING
    };
}

function allocateArenaRegion() {
    for (let index = 0; index < ARENA_REGION_LIMIT; index++) {
        if (occupiedArenaRegions.has(index)) continue;
        occupiedArenaRegions.add(index);
        return index;
    }
    return -1;
}

function arenaBounds(center) {
    const from = add(center, ARENA_OFFSET);
    return {
        from,
        to: {
            x: from.x + ARENA_SIZE.x - 1,
            y: from.y + ARENA_SIZE.y - 1,
            z: from.z + ARENA_SIZE.z - 1
        }
    };
}

function removeArenaBosses(session) {
    try {
        for (const entity of session.dimension.getEntities({
            tags: [RAID_BOSS_TAG],
            location: session.center,
            maxDistance: 96
        })) {
            try { entity.remove(); } catch (error) {}
        }
    } catch (error) {}
    session.boss = undefined;
}

function arenaEntities(session) {
    try {
        return session.dimension.getEntities({
            location: session.center,
            maxDistance: 96
        });
    } catch (error) {
        return [];
    }
}

function arenaEntityOwnerId(entity) {
    try {
        const ownerId = String(entity.getDynamicProperty("lota:party_owner_id") || "");
        if (ownerId) return ownerId;
    } catch (error) {}
    try {
        const owner = entity.getComponent("minecraft:projectile")?.owner;
        if (owner?.typeId === "minecraft:player") return String(owner.id);
    } catch (error) {}
    return "";
}

function removePlayerArenaEntities(session, playerId) {
    const ownerId = String(playerId || "");
    if (!ownerId) return;
    for (const entity of arenaEntities(session)) {
        if (entity.typeId === "minecraft:player" || arenaEntityOwnerId(entity) !== ownerId) continue;
        try { entity.remove(); } catch (error) {}
    }
}

function purgeArenaEntities(session) {
    for (const entity of arenaEntities(session)) {
        if (entity.typeId === "minecraft:player") continue;
        try { entity.remove(); } catch (error) {}
    }
    session.boss = undefined;
}

function clearArenaRegion(session) {
    world.structureManager.place(ARENA_CLEAR_STRUCTURE, session.dimension, arenaBounds(session.center).from, {
        includeBlocks: true,
        includeEntities: false,
        waterlogged: false
    });
}

function resetArenaRegion(session) {
    purgeArenaEntities(session);
    clearArenaRegion(session);
}

function arenaPlayerPosition(session, participantNumber = session.participants.size) {
    const index = Math.max(0, Math.min(PLAYER_OFFSETS.length - 1, Number(participantNumber) - 1));
    return add(session.center, PLAYER_OFFSETS[index]);
}

function isOpenArenaBlock(block) {
    const typeId = String(block?.typeId || "");
    return typeId === "minecraft:air" || typeId.startsWith("minecraft:light_block");
}

function hasSafeArenaSpawn(session, position) {
    const blockLocation = {
        x: Math.floor(position.x),
        y: Math.floor(position.y),
        z: Math.floor(position.z)
    };
    try {
        const floor = session.dimension.getBlock({ ...blockLocation, y: blockLocation.y - 1 });
        const feet = session.dimension.getBlock(blockLocation);
        const head = session.dimension.getBlock({ ...blockLocation, y: blockLocation.y + 1 });
        return floor?.typeId === "minecraft:deepslate"
            && isOpenArenaBlock(feet)
            && isOpenArenaBlock(head);
    } catch (error) {
        return false;
    }
}

function arenaStructureIsReady(session, bounds) {
    const safeSpawns = PLAYER_OFFSETS.every((unused, index) => hasSafeArenaSpawn(
        session,
        arenaPlayerPosition(session, index + 1)
    ));
    if (!safeSpawns) return false;
    try {
        return ARENA_SHELL_PROBES.every(offset =>
            session.dimension.getBlock(add(bounds.from, offset))?.typeId === "minecraft:bedrock"
        );
    } catch (error) {
        return false;
    }
}

async function placeArenaStructure(session, bounds) {
    await nextTick();
    for (let attempt = 0; attempt < 2; attempt++) {
        world.structureManager.place(ARENA_STRUCTURE, session.dimension, bounds.from, {
            includeBlocks: true,
            includeEntities: false,
            waterlogged: false
        });
        await nextTick();
        if (arenaStructureIsReady(session, bounds)) return;
    }
    throw new Error("raid arena floor did not load");
}

function raidBossScale(entity) {
    let width = 1;
    let height = 1;
    try {
        const collision = entity.getComponent("minecraft:collision_box");
        width = Math.max(0.1, Number(collision?.width) || width);
        height = Math.max(0.1, Number(collision?.height) || height);
    } catch (error) {}
    return Math.max(1, Math.min(6, 10 / Math.max(height, width / 1.5)));
}

function applyRaidBossPresentation(session, boss) {
    if (!boss?.isValid || session.cleaned) return;
    try { boss.setProperty("lota:scale_factor", raidBossScale(boss)); } catch (error) {}
    if (Number.isInteger(session.profile.boss.formIndex) && session.profile.boss.formIndex > 0) {
        try { boss.setProperty("lota:form_index", session.profile.boss.formIndex); } catch (error) {}
    }
    try { boss.setProperty("lota:in_battle", true); } catch (error) {}
    try { boss.triggerEvent("lota:enter_battle_focus"); } catch (error) {}
    lockRaidBoss(session);
    boss.nameTag = `§d${"★".repeat(session.profile.tier)} ${speciesName(session.profile.boss.species)}§r`;
}

function ensureRaidBoss(session) {
    if (!session || session.cleaned) return undefined;
    if (session.boss?.isValid) {
        applyRaidBossPresentation(session, session.boss);
        return session.boss;
    }
    if (session.boss) bossRaids.delete(String(session.boss.id));
    let boss;
    try {
        boss = session.dimension.spawnEntity(
            `lota:${session.profile.boss.species}`,
            add(session.center, BOSS_OFFSET)
        );
        boss.addTag(RAID_BOSS_TAG);
        boss.setDynamicProperty("lota:raid_den_key", session.key);
        session.boss = boss;
        bossRaids.set(String(boss.id), session);
        applyRaidBossPresentation(session, boss);
        system.runTimeout(() => applyRaidBossPresentation(session, boss), 2);
        return boss;
    } catch (error) {
        try { boss?.remove(); } catch (cleanupError) {}
        session.boss = undefined;
        console.warn(`[CobbleDrockRaidDens] Raid boss spawn failed: ${error}`);
        return undefined;
    }
}

function lockRaidBoss(session) {
    const boss = session?.boss;
    if (!boss?.isValid || session.cleaned) return;
    const anchor = add(session.center, BOSS_OFFSET);
    try { boss.getComponent("minecraft:movement")?.setCurrentValue(0); } catch (error) {}
    try { boss.clearVelocity(); } catch (error) {}
    try {
        if (distanceSquared(boss.location, anchor) > 0.04) {
            boss.teleport(anchor, {
                dimension: session.dimension,
                rotation: { x: 0, y: 0 },
                keepVelocity: false
            });
        } else {
            boss.setRotation({ x: 0, y: 0 });
        }
    } catch (error) {}
}

function saveReturnLocation(player) {
    let rotation = { x: 0, y: 0 };
    try { rotation = player.getRotation(); } catch (error) {}
    const home = {
        dimensionId: player.dimension.id,
        location: { ...player.location },
        rotation: { x: Number(rotation.x) || 0, y: Number(rotation.y) || 0 }
    };
    try { player.setDynamicProperty(RETURN_PROPERTY, JSON.stringify(home)); } catch (error) {}
    return home;
}

function readReturnLocation(player) {
    try {
        const raw = player.getDynamicProperty(RETURN_PROPERTY);
        if (typeof raw !== "string") return undefined;
        const home = JSON.parse(raw);
        if (!home?.dimensionId || !Number.isFinite(Number(home?.location?.x))
            || !Number.isFinite(Number(home?.location?.y)) || !Number.isFinite(Number(home?.location?.z))) return undefined;
        return home;
    } catch (error) {
        return undefined;
    }
}

function clearReturnLocation(player) {
    try { player.setDynamicProperty(RETURN_PROPERTY, undefined); } catch (error) {}
}

function restorePlayer(player, fallbackHome = undefined) {
    if (!player?.isValid) return;
    const home = readReturnLocation(player) || fallbackHome;
    if (!home) return;
    try {
        player.teleport(home.location, {
            dimension: world.getDimension(home.dimensionId),
            rotation: home.rotation || { x: 0, y: 0 },
            checkForBlocks: false
        });
        clearReturnLocation(player);
        refreshCorePartyHud(player);
    } catch (error) {
        console.warn(`[CobbleDrockRaidDens] Failed to return ${player.name}: ${error}`);
    }
}

function insideArena(session, location) {
    const bounds = arenaBounds(session.center);
    return location.x >= bounds.from.x && location.x <= bounds.to.x + 1
        && location.y >= bounds.from.y - 1 && location.y <= bounds.to.y + 1
        && location.z >= bounds.from.z && location.z <= bounds.to.z + 1;
}

function returnUnauthorizedArenaPlayer(player) {
    if (readReturnLocation(player)) {
        restorePlayer(player);
        return;
    }
    try {
        player.teleport(world.getDefaultSpawnLocation(), {
            dimension: world.getDimension(OVERWORLD),
            checkForBlocks: false
        });
        refreshCorePartyHud(player);
    } catch (error) {}
}

function enforceArenaConfinement() {
    const stabilizedSessions = new Set();
    for (const [playerId, session] of playerArenaRaids) {
        const player = playerArenaEntities.get(playerId);
        if (!player?.isValid) continue;
        if (!session || session.cleaned) {
            playerArenaRaids.delete(playerId);
            if (player.dimension?.id === RAID_DIMENSION) returnUnauthorizedArenaPlayer(player);
            continue;
        }
        if (!stabilizedSessions.has(session)) {
            stabilizedSessions.add(session);
            ensureRaidBoss(session);
            lockRaidBoss(session);
        }
        if (player.dimension?.id === RAID_DIMENSION && insideArena(session, player.location)) continue;
        const position = arenaPlayerPosition(session, 1);
        if (!hasSafeArenaSpawn(session, position)) {
            cleanupArena(session, true);
            continue;
        }
        try {
            player.teleport(position, {
                dimension: session.dimension,
                rotation: { x: 0, y: 180 },
                checkForBlocks: false
            });
        } catch (error) {}
    }
}

function removePendingRaidRequests(session, playerId = "") {
    for (const [requestId, pending] of pendingRaids) {
        if (pending.session !== session || (playerId && pending.playerId !== playerId)) continue;
        pendingRaids.delete(requestId);
    }
}

function detachParticipant(session, playerId) {
    removePlayerArenaEntities(session, playerId);
    session.participants.delete(playerId);
    session.battling.delete(playerId);
    session.startingPlayers.delete(playerId);
    session.homes.delete(playerId);
    pendingJoinRequests.delete(`${session.key}:${playerId}`);
    removePendingRaidRequests(session, playerId);
    if (playerArenaRaids.get(playerId) === session) playerArenaRaids.delete(playerId);
    playerArenaEntities.delete(playerId);
}

function leaveArena(player, session) {
    if (!player?.isValid || !session || session.cleaned) return;
    if (!session.participants.has(player.id)) return;
    const home = session.homes.get(player.id);
    if (session.battling.has(player.id) || session.startingPlayers.has(player.id)) {
        resetCoreRaidBattle(player.id, session.raidId, "participant_left");
    }
    detachParticipant(session, player.id);
    restorePlayer(player, home);
    if (!session.participants.size) cleanupArena(session, false);
}

function addParticipant(session, player) {
    if (session.participants.has(player.id)) return true;
    const previous = playerArenaRaids.get(player.id);
    if (previous && previous !== session) {
        if (previous.raidId) resetCoreRaidBattle(player.id, previous.raidId, "raid_replaced");
        detachParticipant(previous, player.id);
        if (!previous.participants.size) cleanupArena(previous, false);
    }
    if (session.participants.size >= RAID_DEN_MAX_PLAYERS[session.profile.tier]) {
        player.sendMessage("§cThis raid is full.§r");
        return false;
    }
    session.participants.set(player.id, true);
    session.homes.set(player.id, saveReturnLocation(player));
    playerArenaRaids.set(player.id, session);
    playerArenaEntities.set(player.id, player);
    return true;
}

function teleportIntoArena(session, player) {
    const position = arenaPlayerPosition(session);
    if (!hasSafeArenaSpawn(session, position)) {
        console.warn(`[CobbleDrockRaidDens] Refusing unsafe arena teleport for ${player.name}.`);
        player.sendMessage("§cThe raid arena floor is not ready. Try entering again.§r");
        return false;
    }
    try {
        player.teleport(position, {
            dimension: session.dimension,
            rotation: { x: 0, y: 180 },
            checkForBlocks: false
        });
        if (!ensureRaidBoss(session)) {
            player.sendMessage("§cThe raid boss could not be summoned. Try entering again.§r");
            return false;
        }
        refreshCorePartyHud(player);
        player.sendMessage(`§dA mighty ${speciesName(session.profile.boss.species)} appeared! Interact with the boss to begin the raid, or use the crystal behind you to leave.§r`);
        try { player.onScreenDisplay.setActionBar("§eEntrance crystal: Leave raid§r"); } catch (error) {}
        return true;
    } catch (error) {
        player.sendMessage("§cThe raid arena could not be entered.§r");
        return false;
    }
}

function requestRaidJoin(session, player) {
    if (!session || session.cleaned || !player?.isValid) return;
    if (session.phase === "resolved") {
        player.sendMessage("§eThis raid has already ended.§r");
        return;
    }
    if (session.participants.has(player.id)) {
        teleportIntoArena(session, player);
        return;
    }
    const host = playerById(session.hostId);
    if (!host?.isValid) {
        player.sendMessage("§eThe raid host is unavailable.§r");
        return;
    }
    const joinKey = `${session.key}:${player.id}`;
    if (pendingJoinRequests.has(joinKey)) {
        player.sendMessage("§eYour join request is already pending.§r");
        return;
    }
    pendingJoinRequests.add(joinKey);
    player.sendMessage(`§eJoin request sent to ${host.name}.§r`);
    new ActionFormData()
        .title("Raid Join Request")
        .body(`${player.name} wants to join your ${session.profile.tier}-star ${speciesName(session.profile.boss.species)} raid.`)
        .button("Accept")
        .button("Decline")
        .show(host)
        .then(response => {
            pendingJoinRequests.delete(joinKey);
            if (session.cleaned || !player.isValid || !session.participants.has(host.id)
                || session.hostId !== host.id || session.phase === "resolved") return;
            if (response.canceled || response.selection !== 0) {
                player.sendMessage(`§c${host.name} declined your raid join request.§r`);
                return;
            }
            if (!addParticipant(session, player)) return;
            if (teleportIntoArena(session, player)) {
                host.sendMessage(`§a${player.name} joined the raid.§r`);
                return;
            }
            const home = session.homes.get(player.id);
            detachParticipant(session, player.id);
            restorePlayer(player, home);
            if (!session.participants.size) cleanupArena(session, false);
        })
        .catch(error => {
            pendingJoinRequests.delete(joinKey);
            console.warn(`[CobbleDrockRaidDens] Join request form failed: ${error}`);
        });
}

async function initializeArena(session) {
    const bounds = arenaBounds(session.center);
    const options = { dimension: session.dimension, from: bounds.from, to: bounds.to };
    const manager = world.tickingAreaManager;
    if (!manager.hasCapacity(options)) throw new Error("no temporary ticking-area capacity");
    await manager.createTickingArea(session.areaId, options);
    session.tickingArea = true;
    resetArenaRegion(session);
    await placeArenaStructure(session, bounds);
    session.exitLocation = add(session.center, EXIT_CRYSTAL_OFFSET);
    const exitBlock = session.dimension.getBlock(session.exitLocation);
    if (!exitBlock) throw new Error("raid exit crystal location unavailable");
    exitBlock.setType(RAID_DEN_BLOCK_ID);
    exitBlock.setPermutation(exitBlock.permutation
        .withState("lota:raid_type_index", 12)
        .withState("lota:raid_type_high", false)
        .withState("lota:raid_active", false));
    exitCrystals.set(blockKey(RAID_DIMENSION, session.exitLocation), session);
    session.phase = "ready";
    if (!ensureRaidBoss(session)) throw new Error("raid boss could not be spawned");
}

async function enterRaidArena(player, state) {
    if (!player?.isValid || enteringPlayers.has(player.id)) return;
    enteringPlayers.add(player.id);
    try {
        const refreshed = refreshState(state);
        state = refreshed.state;
        const profile = refreshed.profile;
        syncCrystal(state, profile);
        if (Number(state.clears) >= RAID_DEN_MAX_CLEARS) {
            player.sendMessage("§7This den is dormant until its next reset.§r");
            return;
        }
        if (playerClearedDen(state, player.id)) {
            player.sendMessage("§7You already cleared this den. It will be available to you after its next reset.§r");
            return;
        }
        const key = denKey(state);
        let session = arenaRaids.get(key);
        let created = false;
        if (session && (session.cycle !== state.cycle || session.cleaned)) {
            await cleanupArena(session, true);
            session = undefined;
        }
        if (session?.phase === "creating") {
            player.sendMessage("§eThe raid arena is still forming. Try the crystal again in a moment.§r");
            return;
        }
        if (session?.phase === "resolved") {
            player.sendMessage("§eThis raid has ended. Wait for the raiders to leave.§r");
            return;
        }
        if (!session) {
            const regionIndex = allocateArenaRegion();
            if (regionIndex < 0) {
                player.sendMessage("§cAll raid arenas are currently occupied.§r");
                return;
            }
            session = {
                key,
                state,
                cycle: state.cycle,
                profile,
                hostId: player.id,
                participants: new Map(),
                battling: new Set(),
                startingPlayers: new Set(),
                homes: new Map(),
                raidId: `content-den:${state.chunkX}:${state.chunkZ}:${state.cycle}`,
                regionIndex,
                center: arenaCoordinate(regionIndex),
                dimension: world.getDimension(RAID_DIMENSION),
                areaId: `cv_raid_${regionIndex}`,
                tickingArea: false,
                phase: "creating",
                cleaned: false
            };
            created = true;
            arenaRaids.set(key, session);
            system.runTimeout(() => {
                if (!session.cleaned && session.phase === "creating") cleanupArena(session, false);
            }, ARENA_TIMEOUT_TICKS);
            try { await initializeArena(session); }
            catch (error) {
                console.warn(`[CobbleDrockRaidDens] Arena creation failed: ${error}`);
                await cleanupArena(session, false);
                player.sendMessage("§cThe raid arena could not be created.§r");
                return;
            }
        }
        if (!created) {
            requestRaidJoin(session, player);
            return;
        }
        if (!addParticipant(session, player)) return;
        if (!teleportIntoArena(session, player)) {
            const home = session.homes.get(player.id);
            detachParticipant(session, player.id);
            restorePlayer(player, home);
            if (!session.participants.size) await cleanupArena(session, false);
        }
    } finally {
        enteringPlayers.delete(player.id);
    }
}

function startArenaBattle(player, session) {
    if (!player?.isValid || !session || !["ready", "battle"].includes(session.phase)) return;
    if (!ensureRaidBoss(session)) {
        player.sendMessage("§cThe raid boss could not be summoned. Try entering again.§r");
        return;
    }
    if (!session.participants.has(player.id)) return;
    if (session.battling.has(player.id) || session.startingPlayers.has(player.id)) {
        player.sendMessage("§eYou are already fighting this raid boss.§r");
        return;
    }
    const bossLocation = add(session.center, BOSS_OFFSET);
    if (player.dimension?.id !== RAID_DIMENSION || distanceSquared(player.location, bossLocation) > 96 * 96) return;
    lockRaidBoss(session);
    session.startingPlayers.add(player.id);
    const profile = session.profile;
    const bossAspects = [...(profile.boss.aspects || []), ...(profile.boss.bossAspects || [])];
    const requestId = requestCoreRaidBattle(session.boss, {
        raidId: session.raidId,
        raidName: `${profile.tier}-Star ${speciesName(profile.boss.species)} Raid`,
        tier: profile.tier,
        boss: {
            species: profile.boss.species,
            ...(profile.boss.moves ? { moves: [...profile.boss.moves] } : {}),
            ...(bossAspects.length ? { aspects: bossAspects } : {}),
            ...(profile.boss.ability ? { ability: profile.boss.ability } : {}),
            ...(profile.boss.gender ? { gender: profile.boss.gender } : {})
        },
        reward: {
            species: profile.boss.species,
            raidType: profile.boss.raidType,
            ...(profile.boss.moves ? { moves: [...profile.boss.moves] } : {}),
            ...(profile.boss.aspects?.length ? { aspects: [...profile.boss.aspects] } : {}),
            ...(profile.boss.ability ? { ability: profile.boss.ability } : {}),
            ...(profile.boss.gender ? { gender: profile.boss.gender } : {})
        },
        cameraSideScale: 0,
        participants: [{ playerId: player.id }]
    });
    if (!requestId) {
        session.startingPlayers.delete(player.id);
        player.sendMessage("§cThe Core raid service did not accept the request.§r");
        return;
    }
    pendingRaids.set(requestId, { session, playerId: player.id });
    player.sendMessage(`§dYour ${profile.tier}-star raid battle is starting!§r`);
}

async function cleanupArena(session, restoreParticipants) {
    if (!session || session.cleaned) return;
    session.cleaned = true;
    arenaRaids.delete(session.key);
    removePendingRaidRequests(session);
    for (const joinKey of pendingJoinRequests) {
        if (joinKey.startsWith(`${session.key}:`)) pendingJoinRequests.delete(joinKey);
    }
    for (const playerId of session.participants.keys()) {
        pendingJoinRequests.delete(`${session.key}:${playerId}`);
        if (session.battling.has(playerId) || session.startingPlayers.has(playerId)) {
            resetCoreRaidBattle(playerId, session.raidId, "arena_closed");
        }
    }
    if (session.boss) bossRaids.delete(String(session.boss.id));
    if (session.exitLocation) exitCrystals.delete(blockKey(RAID_DIMENSION, session.exitLocation));
    occupiedArenaRegions.delete(session.regionIndex);
    purgeArenaEntities(session);
    for (const [playerId, home] of session.homes) {
        if (playerArenaRaids.get(playerId) !== session) continue;
        playerArenaRaids.delete(playerId);
        const player = playerArenaEntities.get(playerId) || playerById(playerId);
        playerArenaEntities.delete(playerId);
        if (restoreParticipants) restorePlayer(player, home);
    }
    session.participants.clear();
    session.battling.clear();
    session.startingPlayers.clear();
    session.homes.clear();
    if (session.tickingArea) {
        try {
            clearArenaRegion(session);
            await nextTick();
        } catch (error) {
            console.warn(`[CobbleDrockRaidDens] Arena cleanup failed: ${error}`);
        }
        try { world.tickingAreaManager.removeTickingArea(session.areaId); } catch (error) {}
    }
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry, dimensionRegistry }) => {
    dimensionRegistry.registerCustomDimension(RAID_DIMENSION);
    blockComponentRegistry.registerCustomComponent("lota:raid_den_runtime", {
        onTick({ block }) {
            try {
                const state = ensureDenState(block);
                if (!state) return;
                const refreshed = refreshState(state);
                syncCrystal(refreshed.state, refreshed.profile, block);
                refreshDenBeam(block, refreshed.state, refreshed.profile);
                refreshDenSparkle(block, refreshed.state);
            } catch (error) {
                console.warn(`[CobbleDrockRaidDens] Crystal tick failed: ${error}`);
            }
        },
        onPlayerInteract({ block, player }) {
            if (!player?.isValid) return;
            if (block.dimension?.id === RAID_DIMENSION) {
                const session = exitCrystals.get(blockKey(RAID_DIMENSION, block.location));
                if (session) system.run(() => leaveArena(player, session));
                return;
            }
            const state = ensureDenState(block);
            if (!state) {
                player.sendMessage("§7This crystal is dormant.§r");
                return;
            }
            system.run(() => enterRaidArena(player, state));
        }
    });
});

function cancelRaidArenaBlockBreak(event) {
    if (event.block?.dimension?.id === RAID_DIMENSION) event.cancel = true;
}

function cancelRaidArenaBlockInteraction(event) {
    if (event.block?.dimension?.id !== RAID_DIMENSION) return;
    if (event.block.typeId === RAID_DEN_BLOCK_ID) return;
    event.cancel = true;
}

function removeRaidArenaPlacedBlock(event) {
    if (event.block?.dimension?.id !== RAID_DIMENSION) return;
    system.run(() => {
        try { event.block.setType("minecraft:air"); } catch (error) {}
    });
}

world.beforeEvents.playerBreakBlock.subscribe(cancelRaidArenaBlockBreak);
world.beforeEvents.playerInteractWithBlock.subscribe(cancelRaidArenaBlockInteraction);
world.afterEvents.playerPlaceBlock.subscribe(removeRaidArenaPlacedBlock);

function cleanupDestroyedDen(location) {
    const state = readState(Math.floor(location.x / 16), Math.floor(location.z / 16));
    if (!state || state.x !== location.x || state.y !== location.y || state.z !== location.z) return;
    const key = denKey(state);
    deleteState(state);
    denSparkleTicks.delete(key);
    removeLegacyDenBeam(key, state);
    const session = arenaRaids.get(key);
    if (session) system.run(() => cleanupArena(session, true));
}

world.afterEvents.playerBreakBlock.subscribe(event => {
    if (event.block?.dimension?.id !== OVERWORLD
        || event.brokenBlockPermutation?.type?.id !== RAID_DEN_BLOCK_ID) return;
    cleanupDestroyedDen(event.block.location);
});

world.afterEvents.explosion.subscribe(event => {
    if (event.dimension?.id !== OVERWORLD) return;
    for (const block of event.getImpactedBlocks()) cleanupDestroyedDen(block.location);
});

world.afterEvents.playerInteractWithEntity.subscribe(event => {
    const boss = event.target;
    if (!boss?.isValid || !boss.hasTag(RAID_BOSS_TAG)) return;
    const session = bossRaids.get(String(boss.id));
    if (!session) return;
    system.run(() => startArenaBattle(event.player, session));
});

world.afterEvents.playerDimensionChange.subscribe(event => {
    system.run(() => {
        const player = event.player;
        if (!player?.isValid || player.dimension?.id !== RAID_DIMENSION) return;
        if (!playerArenaRaids.has(player.id)) returnUnauthorizedArenaPlayer(player);
    });
});

function startRaidNearPartyBall(projectile) {
    if (!projectile?.isValid) return;
    try {
        if (!projectile.hasTag("lota:party_summon_ball")) return;
    } catch (error) {
        return;
    }
    let player;
    try { player = projectile.getComponent("minecraft:projectile")?.owner; } catch (error) {}
    if (player?.typeId !== "minecraft:player" || player.dimension?.id !== RAID_DIMENSION) return;
    const session = playerArenaRaids.get(player.id);
    if (!session?.boss?.isValid || session.cleaned) return;
    if (distanceSquared(projectile.location, session.boss.location) > RAID_BOSS_TRIGGER_DISTANCE ** 2) return;
    lockRaidBoss(session);
    for (const delay of [1, 2, 4]) system.runTimeout(() => lockRaidBoss(session), delay);
    system.run(() => startArenaBattle(player, session));
}

world.afterEvents.projectileHitBlock.subscribe(event => startRaidNearPartyBall(event.projectile));
world.afterEvents.projectileHitEntity.subscribe(event => startRaidNearPartyBall(event.projectile));

subscribeCoreRaidResult(result => {
    const requestId = String(result?.requestId || "");
    const pending = pendingRaids.get(requestId);
    const session = pending?.session || [...arenaRaids.values()]
        .find(value => value.raidId === String(result?.raidId || ""));
    if (!session || session.cleaned) return;
    if (result.outcome === "started") {
        if (!pending) return;
        pendingRaids.delete(requestId);
        session.startingPlayers.delete(pending.playerId);
        session.battling.add(pending.playerId);
        session.phase = "battle";
        applyRaidBossPresentation(session, session.boss);
        return;
    }
    if (["rejected", "cancelled"].includes(result.outcome) && pending) {
        pendingRaids.delete(requestId);
        session.startingPlayers.delete(pending.playerId);
        const player = playerById(pending.playerId);
        if (player?.isValid) {
            const detail = String(result.detail || (result.outcome === "cancelled" ? "request cancelled" : "request rejected"));
            player.sendMessage(`§cThe raid battle could not start: ${detail}§r`);
        }
        if (!session.battling.size && !session.startingPlayers.size) session.phase = "ready";
        return;
    }
    if (!["victory", "loss"].includes(result.outcome) || session.phase === "resolved") return;
    session.phase = "resolved";
    session.outcome = result.outcome;
    removePendingRaidRequests(session);
    session.startingPlayers.clear();
    session.battling.clear();
    if (session.boss) bossRaids.delete(String(session.boss.id));
    system.runTimeout(() => {
        if (!session.cleaned) removeArenaBosses(session);
    }, 60);
    if (result.outcome === "victory") {
        const state = readState(session.state.chunkX, session.state.chunkZ);
        if (state && Number(state.cycle) === Number(session.cycle)) {
            state.clears = Math.min(RAID_DEN_MAX_CLEARS, Math.max(0, Number(state.clears) || 0) + 1);
            const clearedPlayers = new Set(Array.isArray(state.clearedPlayers) ? state.clearedPlayers : []);
            for (const playerId of session.participants.keys()) clearedPlayers.add(String(playerId));
            state.clearedPlayers = [...clearedPlayers];
            writeState(state);
            const refreshed = refreshState(state);
            syncCrystal(refreshed.state, refreshed.profile);
        }
    }
    const message = result.outcome === "victory"
        ? "§aRaid cleared! Choose Catch or Pass when the reward window opens, then use the entrance crystal to return.§r"
        : "§cThe raid was lost. Use the entrance crystal to return.§r";
    for (const playerId of session.participants.keys()) {
        const player = playerById(playerId);
        if (player?.isValid) player.sendMessage(message);
    }
});

world.afterEvents.playerLeave.subscribe(event => {
    for (const session of arenaRaids.values()) {
        if (!session.participants.has(event.playerId)) continue;
        if (session.battling.has(event.playerId) || session.startingPlayers.has(event.playerId)) {
            resetCoreRaidBattle(event.playerId, session.raidId, "participant_disconnected");
        }
        detachParticipant(session, event.playerId);
        if (!session.participants.size) cleanupArena(session, false);
    }
});

world.afterEvents.playerSpawn.subscribe(event => {
    if (!event.initialSpawn) return;
    system.run(() => {
        if (readReturnLocation(event.player)) restorePlayer(event.player);
    });
});

system.runTimeout(() => {
    for (let index = 0; index < ARENA_REGION_LIMIT; index++) {
        try { world.tickingAreaManager.removeTickingArea(`cv_raid_${index}`); } catch (error) {}
    }
    for (const player of world.getAllPlayers()) {
        if (readReturnLocation(player)) restorePlayer(player);
        else if (player.dimension?.id === RAID_DIMENSION) returnUnauthorizedArenaPlayer(player);
    }
}, 20);

system.runInterval(enforceArenaConfinement, 20);
