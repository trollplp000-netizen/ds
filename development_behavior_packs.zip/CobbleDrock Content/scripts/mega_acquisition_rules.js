const PICKAXES = new Set(["wooden", "stone", "iron", "golden", "diamond", "netherite"]
    .map(tier => `minecraft:${tier}_pickaxe`));
const DIAMOND_PICKAXES = new Set(["minecraft:diamond_pickaxe", "minecraft:netherite_pickaxe"]);
const METEOR_STONES = new Set(["dawn", "dusk", "fire", "ice", "leaf", "moon", "shiny", "sun", "thunder", "water"]);

export function megaSiteHarvest(blockId, toolId, enchantments = {}, random = Math.random) {
    const id = String(blockId || "").replace(/^lota:/, "");
    if (!String(blockId || "").startsWith("lota:") || !PICKAXES.has(toolId)) return undefined;
    const silk = Number(enchantments.silkTouch) > 0;
    let item;
    let experience = 0;
    let amount = 1;
    let hint = "";
    if (id === "keystone_ore" || id === "mega_stone_crystal") {
        if (!DIAMOND_PICKAXES.has(toolId)) return undefined;
        item = id === "keystone_ore" ? "lota:keystone" : "lota:mega_stone";
        if (!silk) {
            experience = id === "keystone_ore" ? 6 + Math.floor(random() * 4) : 0;
            hint = id === "keystone_ore" ? "message.cobbledrock.mega.keystone" : "message.cobbledrock.mega.raw_stone";
        }
    } else if (id === "mega_meteorid_block" || id === "mega_meteorid_radiated_block") {
        item = blockId;
    } else {
        const type = /^mega_meteorid_([a-z]+)_ore$/.exec(id)?.[1];
        if (!METEOR_STONES.has(type)) return undefined;
        item = `lota:${type}_stone`;
        if (!silk) {
            const fortune = Math.max(0, Math.min(3, Math.floor(Number(enchantments.fortune) || 0)));
            if (fortune > 0) amount = Math.max(0, Math.floor(random() * (fortune + 2)) - 1) + 1;
            experience = 3 + Math.floor(random() * 4);
        }
    }
    return { item: silk ? blockId : item, amount, experience, hint };
}
