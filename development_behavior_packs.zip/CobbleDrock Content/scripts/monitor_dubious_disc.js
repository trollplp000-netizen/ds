import { system, world, EntityComponentTypes, BlockPermutation } from "@minecraft/server";
import { requestCorePokemonSpawn } from "./core_bridge.js";
import { fossilMachineKey } from "./fossil_core_adapter.js";

const MONITOR_ID = "fm:monitor";
const DISC_ITEM_ID = "lota:dubious_disc";
const STAGE_STATE = "fm:disc_stage";
const OTHER_STAGE_STATE = "fm:up_stage";

const STAGE_IDLE = 0;
const STAGE_SCANNING = 1;
const STAGE_DONE = 2;

const DISC_FRAME_COUNT = 10;
const DISC_TICKS_PER_FRAME = 6;
const SCAN_DURATION_TICKS = DISC_FRAME_COUNT * DISC_TICKS_PER_FRAME;

const SPAWN_LEVEL = 15;

const SCULK_RADIUS = 4;

const SCULK_VEIN_DOWN_BIT = 0x1;

const SCULK_GROUND_BLOCKS = new Set([
    "minecraft:grass_block",
    "minecraft:dirt",
    "minecraft:coarse_dirt",
    "minecraft:podzol",
    "minecraft:mycelium",
    "minecraft:sand",
    "minecraft:red_sand",
    "minecraft:gravel",
    "minecraft:stone",
    "minecraft:andesite",
    "minecraft:diorite",
    "minecraft:granite",
    "minecraft:deepslate",
    "minecraft:tuff",
    "minecraft:calcite",
    "minecraft:moss_block",
    "minecraft:mud",
    "minecraft:clay",
    "minecraft:farmland",
    "minecraft:grass_path"
]);

const FACING_OFFSETS = {
    north: { x: 0, z: -1 },
    south: { x: 0, z: 1 },
    east: { x: 1, z: 0 },
    west: { x: -1, z: 0 }
};

function isLinkedToFossilMachine(block) {
    try {
        const key = fossilMachineKey("monitor_", block.dimension, block.location);
        return world.getDynamicProperty(key) != null;
    } catch (error) {
        return false;
    }
}

function stageOf(block) {
    try { return Number(block.permutation.getState(STAGE_STATE)) || 0; }
    catch (error) { return 0; }
}

function otherStageOf(block) {
    try { return Number(block.permutation.getState(OTHER_STAGE_STATE)) || 0; }
    catch (error) { return 0; }
}

function setStage(block, stage) {
    try { block.setPermutation(block.permutation.withState(STAGE_STATE, stage)); }
    catch (error) {}
}

function frontOffsetFromPlayer(block, player) {
    const centerX = block.location.x + 0.5;
    const centerZ = block.location.z + 0.5;
    const dx = player.location.x - centerX;
    const dz = player.location.z - centerZ;
    if (Math.abs(dx) < 0.001 && Math.abs(dz) < 0.001) return FACING_OFFSETS.south;
    return Math.abs(dx) >= Math.abs(dz)
        ? { x: dx > 0 ? 1 : -1, z: 0 }
        : { x: 0, z: dz > 0 ? 1 : -1 };
}

function spawnLocationFromOffset(block, offset) {
    const loc = block.location;
    return { x: loc.x + offset.x + 0.5, y: loc.y, z: loc.z + offset.z + 0.5 };
}

function stopMonitorSound(dimension, soundId) {
    try { dimension.runCommand(`stopsound @a ${soundId}`); } catch (error) {}
}

function findGroundLocation(dimension, x, baseY, z) {
    for (let dy = 2; dy >= -4; dy--) {
        const y = baseY + dy;
        let block;
        try { block = dimension.getBlock({ x, y, z }); }
        catch (error) { continue; }
        if (!block?.isValid || block.isAir || block.isLiquid) continue;
        return { x, y, z, typeId: block.typeId };
    }
    return undefined;
}

function spreadSculkPatch(dimensionId, center) {
    let dimension;
    try { dimension = world.getDimension(dimensionId); }
    catch (error) { return; }

    for (let dx = -SCULK_RADIUS; dx <= SCULK_RADIUS; dx++) {
        for (let dz = -SCULK_RADIUS; dz <= SCULK_RADIUS; dz++) {
            const dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > SCULK_RADIUS) continue;

            const edgeChance = 1 - dist / (SCULK_RADIUS + 1);
            if (Math.random() > edgeChance + 0.2) continue;

            const x = Math.floor(center.x) + dx;
            const z = Math.floor(center.z) + dz;
            const ground = findGroundLocation(dimension, x, Math.floor(center.y), z);
            if (!ground || !SCULK_GROUND_BLOCKS.has(ground.typeId)) continue;

            const delayTicks = Math.round(dist * 3) + Math.floor(Math.random() * 4);
            system.runTimeout(() => {
                let dim;
                try { dim = world.getDimension(dimensionId); }
                catch (error) { return; }
                const groundBlock = dim.getBlock({ x: ground.x, y: ground.y, z: ground.z });
                if (!groundBlock?.isValid || !SCULK_GROUND_BLOCKS.has(groundBlock.typeId)) return;
                const veinBlock = dim.getBlock({ x: ground.x, y: ground.y + 1, z: ground.z });
                if (!veinBlock?.isValid || !veinBlock.isAir) return;
                try {
                    veinBlock.setPermutation(
                        BlockPermutation.resolve("minecraft:sculk_vein", { multi_face_direction_bits: SCULK_VEIN_DOWN_BIT })
                    );
                } catch (error) {}
            }, delayTicks);
        }
    }
}

function finishDiscUse(dimensionId, location, offset) {
    let dimension;
    try { dimension = world.getDimension(dimensionId); }
    catch (error) { return; }
    const block = dimension.getBlock(location);
    if (!block?.isValid || block.typeId !== MONITOR_ID) return;
    if (stageOf(block) !== STAGE_SCANNING) return;

    const spawnLocation = spawnLocationFromOffset(block, offset || FACING_OFFSETS.south);

    const player = block.dimension.getPlayers({ location: spawnLocation, maxDistance: 24 })[0];
    if (player) {
        requestCorePokemonSpawn(player, {
            species: "porygonz",
            level: SPAWN_LEVEL,
            location: spawnLocation,
            duplicateRadius: 0
        });
    }

    stopMonitorSound(block.dimension, "fm:monitor_dubious_loop");
    stopMonitorSound(block.dimension, "fm:monitor_upgrade_insert");
    try { block.dimension.playSound("pokemon.porygonz.cry", spawnLocation); } catch (error) {}
    try { block.dimension.playSound("fm:monitor_porygon_spawn", block.location); } catch (error) {}

    try { block.dimension.spawnParticle("minecraft:huge_explosion_emitter", spawnLocation); }
    catch (error) {}

    spreadSculkPatch(dimensionId, spawnLocation);

    setStage(block, STAGE_DONE);
    try {
        const loc = block.location;
        block.dimension.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} air destroy`);
    } catch (error) {}
}

function consumeDiscItem(player) {
    try {
        const container = player.getComponent(EntityComponentTypes.Inventory)?.container;
        const item = container?.getItem(player.selectedSlotIndex);
        if (!item || item.typeId !== DISC_ITEM_ID) return false;
        if (item.amount <= 1) container.setItem(player.selectedSlotIndex, undefined);
        else {
            item.amount -= 1;
            container.setItem(player.selectedSlotIndex, item);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function onPlayerInteract(event) {
    const block = event.block;
    const player = event.player;
    if (!block || block.typeId !== MONITOR_ID || !player) return;
    if (stageOf(block) !== STAGE_IDLE) return;
    if (otherStageOf(block) !== STAGE_IDLE) return;
    if (isLinkedToFossilMachine(block)) return;
    if (!consumeDiscItem(player)) return;

    setStage(block, STAGE_SCANNING);
    try { block.dimension.playSound("fm:monitor_upgrade_insert", block.location); } catch (error) {}
    try { block.dimension.playSound("fm:monitor_dubious_loop", block.location); } catch (error) {}

    const dimensionId = block.dimension.id;
    const location = { x: block.location.x, y: block.location.y, z: block.location.z };
    const offset = frontOffsetFromPlayer(block, player);
    system.runTimeout(() => finishDiscUse(dimensionId, location, offset), SCAN_DURATION_TICKS);
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(MONITOR_ID + "_dubious_disc", {
        onPlayerInteract
    });
});
