import { BlockPermutation, system, world } from "@minecraft/server";

const PLACE_EVENT_ID = "lota:test_groudon_volcano_assembly_v1";
const PARTS = Object.freeze([
    Object.freeze({
        id: "lota:groudon1",
        offset: Object.freeze({ x: 0, y: 0, z: 0 }),
        size: Object.freeze({ x: 64, y: 230, z: 64 })
    }),
    Object.freeze({
        id: "lota:groudon2",
        offset: Object.freeze({ x: -64, y: 0, z: 0 }),
        size: Object.freeze({ x: 64, y: 70, z: 64 })
    }),
    Object.freeze({
        id: "lota:groudon3",
        offset: Object.freeze({ x: -64, y: 0, z: 64 }),
        size: Object.freeze({ x: 64, y: 70, z: 64 })
    }),
    Object.freeze({
        id: "lota:groudon4",
        offset: Object.freeze({ x: -11, y: 0, z: 64 }),
        size: Object.freeze({ x: 64, y: 70, z: 64 })
    })
]);
const AUTHORING_MARKERS = Object.freeze([
    Object.freeze({ x: 54, y: 1, z: 0 }),
    Object.freeze({ x: -64, y: 1, z: 0 })
]);
const BUILD_BOUNDS = Object.freeze({
    min: Object.freeze({ x: -64, y: 0, z: 0 }),
    max: Object.freeze({ x: 63, y: 229, z: 127 })
});
const activeDimensions = new Set();
let tickingAreaSequence = 0;

function nextTick() {
    return new Promise(resolve => system.run(resolve));
}

function add(origin, offset) {
    return {
        x: origin.x + offset.x,
        y: origin.y + offset.y,
        z: origin.z + offset.z
    };
}

function placementOrigin(player) {
    return {
        x: Math.floor(player.location.x),
        y: Math.floor(player.location.y) - 1,
        z: Math.floor(player.location.z)
    };
}

function boundsFitDimension(dimension, origin) {
    const range = dimension.heightRange || { min: -64, max: 320 };
    return origin.y + BUILD_BOUNDS.min.y >= range.min
        && origin.y + BUILD_BOUNDS.max.y < range.max;
}

function tickingAreaOptions(dimension, origin, part) {
    const from = add(origin, part.offset);
    return {
        dimension,
        from,
        to: {
            x: from.x + part.size.x - 1,
            y: from.y + part.size.y - 1,
            z: from.z + part.size.z - 1
        }
    };
}

async function placePart(player, dimension, origin, part, index) {
    const areaId = `cv_groudon_test_${++tickingAreaSequence}`;
    const options = tickingAreaOptions(dimension, origin, part);
    const manager = world.tickingAreaManager;
    if (!manager.hasCapacity(options)) {
        throw new Error(`not enough temporary ticking-area capacity for part ${index + 1}`);
    }

    player.sendMessage(`§7[TEST] Loading and placing part ${index + 1}/${PARTS.length}...`);
    await manager.createTickingArea(areaId, options);
    try {
        world.structureManager.place(part.id, dimension, options.from, {
            includeBlocks: true,
            includeEntities: false,
            waterlogged: false
        });
        await nextTick();
        await nextTick();
    } finally {
        try { manager.removeTickingArea(areaId); }
        catch (error) {}
    }
}

async function runAssemblyTest(player) {
    if (!player?.isValid) return;
    const dimension = player.dimension;
    if (activeDimensions.has(dimension.id)) {
        player.sendMessage("§e[TEST] A Groudon volcano assembly test is already running in this dimension.");
        return;
    }

    const origin = placementOrigin(player);
    if (!boundsFitDimension(dimension, origin)) {
        player.sendMessage(
            `§c[TEST] Base Y ${origin.y} cannot fit the 230-block-tall part. Use Y 90 or lower in the Overworld.`
        );
        return;
    }

    activeDimensions.add(dimension.id);
    player.sendMessage(
        `§e[TEST] Groudon volcano base: ${origin.x}, ${origin.y}, ${origin.z}. Do not leave the world until all four parts finish.`
    );
    try {
        for (let index = 0; index < PARTS.length; index += 1) {
            await placePart(player, dimension, origin, PARTS[index], index);
        }

        const air = BlockPermutation.resolve("minecraft:air");
        for (const marker of AUTHORING_MARKERS) {
            dimension.getBlock(add(origin, marker))?.setPermutation(air);
        }
        player.sendMessage(
            "§a[TEST] Four-part Groudon volcano assembly complete. No natural generation, Groudon spawn, or loot was added."
        );
        console.log(
            `[GroudonVolcanoTest] Assembly completed at ${dimension.id} ${origin.x},${origin.y},${origin.z}.`
        );
    } catch (error) {
        console.error(`[GroudonVolcanoTest] Assembly failed: ${error}`);
        if (player.isValid) {
            player.sendMessage(`§c[TEST] Assembly stopped: ${error}. Earlier completed parts were left in place.`);
        }
    } finally {
        activeDimensions.delete(dimension.id);
    }
}

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== PLACE_EVENT_ID || event.sourceEntity?.typeId !== "minecraft:player") return;
    const player = event.sourceEntity;
    system.run(() => runAssemblyTest(player));
});
