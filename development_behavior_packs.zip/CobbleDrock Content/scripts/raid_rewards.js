import { ItemStack, system, world } from "@minecraft/server";
import { subscribeCoreRaidRewardResult } from "./core_bridge.js";

const RAID_POUCH_ID = "lota:raid_pouch";
const RAID_TIER_PROPERTY = "lota:raid_tier";
const RAID_TYPE_PROPERTY = "lota:raid_type";
const RAID_ENERGY_PROPERTY = "lota:raid_energy";
const REQUIRED_RAID_ENERGY = 100;
const RAID_SHARD_IDS = new Set(["lota:raid_shard", "lota:raid_shard_50", "lota:raid_shard_100"]);
const openingPlayers = new Set();

const APRICORNS = Object.freeze([
    "red_apricorn", "yellow_apricorn", "green_apricorn", "blue_apricorn",
    "pink_apricorn", "white_apricorn", "black_apricorn"
]);
const APRICORN_SEEDS = Object.freeze(APRICORNS.map(value => `${value}_seed`));
const MINT_COLORS = Object.freeze(["red", "blue", "cyan", "green", "pink", "white"]);
const MINT_LEAVES = Object.freeze(MINT_COLORS.map(value => `${value}_mint_leaf`));
const MINT_SEEDS = Object.freeze(MINT_COLORS.map(value => `${value}_mint_seeds`));
const FEATHERS = Object.freeze(["health", "muscle", "resist", "clever", "genius", "swift"].map(value => `${value}_feather`));
const MOCHI = Object.freeze(["health", "muscle", "resist", "clever", "genius", "swift"].map(value => `${value}_mochi`));
const POSITIVE_CANDIES = Object.freeze(["health", "mighty", "tough", "smart", "courage", "quick"].map(value => `${value}_candy`));
const NEGATIVE_CANDIES = Object.freeze(["sickly", "weak", "brittle", "numb", "coward", "slow"].map(value => `${value}_candy`));
const RAID_CHEERS = Object.freeze(["raid_cheer_attack", "raid_cheer_defense", "raid_cheer_heal"]);
const RAID_TYPES = new Set([
    "bug", "dark", "dragon", "electric", "fairy", "fighting", "fire", "flying",
    "ghost", "grass", "ground", "ice", "normal", "poison", "psychic", "rock", "steel", "water"
]);

const lota = (id, weight = 1, minimum = 1, maximum = minimum) =>
    Object.freeze({ id: `lota:${id}`, weight, minimum, maximum });
const vanilla = (id, weight = 1, minimum = 1, maximum = minimum) =>
    Object.freeze({ id: `minecraft:${id}`, weight, minimum, maximum });
const gem = (weight, minimum = 1, maximum = minimum) =>
    Object.freeze({ id: "$raid_gem", weight, minimum, maximum });
const many = (ids, weight, minimum, maximum) => ids.map(id => lota(id, weight, minimum, maximum));

const RAID_LOOT_POOLS = Object.freeze({
    1: Object.freeze({
        rolls: [2, 4],
        entries: Object.freeze([
            ...many(APRICORNS, 5, 2, 4),
            lota("medicinal_leek", 10, 1, 2),
            lota("vivichoke_seeds", 5, 2, 4),
            vanilla("iron_nugget", 10, 1, 4)
        ])
    }),
    2: Object.freeze({
        rolls: [3, 6],
        entries: Object.freeze([
            ...many(APRICORNS, 5, 2, 4),
            vanilla("iron_nugget", 10, 2, 6),
            vanilla("gold_nugget", 5, 1, 3),
            vanilla("copper_ingot", 2, 1, 2),
            ...many(APRICORN_SEEDS, 2, 1, 1),
            lota("exp_candy_xs", 10, 2, 6),
            lota("exp_candy_s", 5, 1, 3)
        ])
    }),
    3: Object.freeze({
        rolls: [3, 6],
        entries: Object.freeze([
            vanilla("iron_ingot", 10, 1, 2),
            vanilla("copper_ingot", 10, 1, 2),
            vanilla("gold_ingot", 5),
            lota("exp_candy_s", 10, 2, 6),
            lota("exp_candy_m", 5, 1, 3),
            ...many(FEATHERS, 5, 1, 2),
            ...many(MOCHI, 5, 1, 2),
            ...many(MINT_LEAVES, 2, 1, 2),
            gem(5),
            ...many(RAID_CHEERS, 2, 1, 1)
        ])
    }),
    4: Object.freeze({
        rolls: [4, 6],
        entries: Object.freeze([
            vanilla("iron_ingot", 5, 2, 4),
            vanilla("copper_ingot", 5, 2, 4),
            vanilla("gold_ingot", 2, 1, 2),
            vanilla("diamond", 2),
            lota("exp_candy_m", 10, 2, 6),
            lota("exp_candy_l", 5, 2, 4),
            ...many(FEATHERS, 10, 1, 3),
            ...many(MOCHI, 10, 1, 3),
            ...many(MINT_LEAVES, 5, 2, 4),
            ...many(MINT_SEEDS, 2, 1, 1),
            lota("ability_capsule"),
            gem(10),
            ...many(RAID_CHEERS, 5, 1, 1),
            ...many(POSITIVE_CANDIES, 2, 1, 1),
            ...many(NEGATIVE_CANDIES, 1, 1, 1)
        ])
    }),
    5: Object.freeze({
        rolls: [4, 8],
        entries: Object.freeze([
            vanilla("iron_ingot", 2, 4, 8),
            vanilla("copper_ingot", 2, 4, 8),
            vanilla("gold_ingot", 2, 4, 6),
            vanilla("diamond", 5, 1, 4),
            lota("exp_candy_l", 10, 2, 6),
            lota("exp_candy_xl", 5, 2, 4),
            lota("rare_candy", 5, 1, 2),
            ...many(MOCHI, 5, 2, 4),
            ...many(MINT_LEAVES, 5, 2, 4),
            ...many(MINT_SEEDS, 5, 1, 1),
            lota("ability_capsule", 5),
            gem(10),
            ...many(RAID_CHEERS, 5, 1, 3),
            ...many(POSITIVE_CANDIES, 2, 1, 2),
            ...many(NEGATIVE_CANDIES, 1, 1, 2),
            lota("raid_shard")
        ])
    }),
    6: Object.freeze({
        rolls: [6, 8],
        entries: Object.freeze([
            vanilla("iron_ingot", 2, 4, 8),
            vanilla("copper_ingot", 2, 4, 8),
            vanilla("gold_ingot", 2, 4, 8),
            vanilla("diamond", 10, 3, 4),
            lota("exp_candy_l", 10, 4, 6),
            lota("exp_candy_xl", 10, 2, 4),
            lota("rare_candy", 5, 1, 2),
            ...many(MOCHI, 5, 2, 4),
            ...many(MINT_LEAVES, 5, 2, 4),
            ...many(MINT_SEEDS, 5, 1, 1),
            lota("ability_capsule", 10),
            lota("ability_patch", 2),
            gem(10),
            ...many(RAID_CHEERS, 5, 2, 3),
            ...many(POSITIVE_CANDIES, 5, 2, 4),
            ...many(NEGATIVE_CANDIES, 2, 2, 4),
            lota("raid_shard", 2)
        ])
    }),
    7: Object.freeze({
        rolls: [8, 10],
        entries: Object.freeze([
            vanilla("iron_ingot", 1, 4, 8),
            vanilla("copper_ingot", 1, 4, 8),
            vanilla("gold_ingot", 1, 4, 8),
            vanilla("diamond", 10, 4, 6),
            vanilla("netherite_scrap", 2, 1, 2),
            lota("exp_candy_l", 5, 4, 8),
            lota("exp_candy_xl", 10, 4, 6),
            lota("rare_candy", 5, 1, 4),
            ...many(MOCHI, 5, 3, 6),
            ...many(MINT_LEAVES, 2, 2, 4),
            lota("red_mint_seeds", 5),
            ...many(MINT_SEEDS.filter(value => value !== "red_mint_seeds"), 2, 1, 1),
            lota("ability_capsule", 10),
            lota("ability_patch", 5),
            gem(10, 2, 2),
            ...many(RAID_CHEERS, 5, 3, 4),
            ...many(POSITIVE_CANDIES, 5, 4, 8),
            ...many(NEGATIVE_CANDIES, 2, 4, 8),
            lota("raid_shard", 5)
        ])
    })
});

function playerById(playerId) {
    const id = String(playerId || "");
    return id ? world.getAllPlayers().find(player => String(player.id) === id) : undefined;
}

function randomInteger(minimum, maximum) {
    const min = Math.ceil(Number(minimum) || 0);
    const max = Math.max(min, Math.floor(Number(maximum) || min));
    return min + Math.floor(Math.random() * (max - min + 1));
}

function selectWeighted(entries) {
    const total = entries.reduce((sum, entry) => sum + Math.max(1, Number(entry.weight) || 1), 0);
    let roll = Math.random() * total;
    for (const entry of entries) {
        roll -= Math.max(1, Number(entry.weight) || 1);
        if (roll < 0) return entry;
    }
    return entries[entries.length - 1];
}

function resolvedItemId(entry, raidType) {
    if (entry.id !== "$raid_gem") return entry.id;
    return `lota:${RAID_TYPES.has(raidType) ? raidType : "normal"}_gem`;
}

function giveItem(player, itemStack) {
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) {
            player.dimension.spawnItem(itemStack, player.location);
            return true;
        }
        const remainder = container.addItem(itemStack);
        if (!remainder) return true;
        player.dimension.spawnItem(remainder, player.location);
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockRaidRewards] Failed to give ${itemStack?.typeId || "item"}: ${error}`);
        return false;
    }
}

function raidShardEnergy(itemStack) {
    const stored = Math.floor(Number(itemStack?.getDynamicProperty(RAID_ENERGY_PROPERTY)));
    if (Number.isFinite(stored)) return Math.max(0, Math.min(REQUIRED_RAID_ENERGY, stored));
    if (itemStack?.typeId === "lota:raid_shard_100") return 100;
    if (itemStack?.typeId === "lota:raid_shard_50") return 50;
    return 0;
}

function createRaidShard(energy = 0) {
    const normalized = Math.max(0, Math.min(REQUIRED_RAID_ENERGY, Math.floor(Number(energy) || 0)));
    const itemId = normalized >= 100
        ? "lota:raid_shard_100"
        : normalized >= 50 ? "lota:raid_shard_50" : "lota:raid_shard";
    const shard = new ItemStack(itemId, 1);
    shard.setDynamicProperty(RAID_ENERGY_PROPERTY, normalized);
    shard.setLore([`§7Raid Energy: §d${normalized}§7/${REQUIRED_RAID_ENERGY}§r`]);
    return shard;
}

function chargeRaidShard(player, amount) {
    const gained = Math.max(0, Math.floor(Number(amount) || 0));
    if (!gained) return false;
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        if (!container) return false;
        for (let slot = 0; slot < container.size; slot++) {
            const stack = container.getItem(slot);
            if (!RAID_SHARD_IDS.has(stack?.typeId)) continue;
            const previous = raidShardEnergy(stack);
            if (previous >= REQUIRED_RAID_ENERGY) continue;
            const next = Math.min(REQUIRED_RAID_ENERGY, previous + gained);
            container.setItem(slot, createRaidShard(next));
            player.sendMessage(`§dRaid Shard charged: ${previous} → ${next}/${REQUIRED_RAID_ENERGY}§r`);
            return true;
        }
    } catch (error) {
        console.warn(`[CobbleDrockRaidRewards] Failed to charge Raid Shard: ${error}`);
    }
    return false;
}

function useRaidShard(player, itemStack) {
    if (!player?.isValid || !RAID_SHARD_IDS.has(itemStack?.typeId)) return;
    const energy = raidShardEnergy(itemStack);
    if (energy < REQUIRED_RAID_ENERGY) {
        player.sendMessage(`§eThe Raid Shard needs ${REQUIRED_RAID_ENERGY - energy} more energy.§r`);
        return;
    }
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const slot = player.selectedSlotIndex;
        const held = container?.getItem(slot);
        if (!container || !RAID_SHARD_IDS.has(held?.typeId) || raidShardEnergy(held) < REQUIRED_RAID_ENERGY) return;
        container.setItem(slot, new ItemStack("lota:raid_den_crystal", 1));
        try { player.dimension.playSound("random.orb", player.location, { volume: 0.8, pitch: 0.8 }); } catch (error) {}
        player.sendMessage("§aThe charged Raid Shard became a Raid Den Crystal.§r");
    } catch (error) {
        console.warn(`[CobbleDrockRaidRewards] Failed to convert Raid Shard: ${error}`);
    }
}

function createRaidPouch(tier, raidType) {
    const normalizedTier = Math.max(1, Math.min(7, Math.floor(Number(tier) || 1)));
    const type = String(raidType || "").toLowerCase();
    const normalizedType = RAID_TYPES.has(type) ? type : "normal";
    const pouch = new ItemStack(RAID_POUCH_ID, 1);
    pouch.setDynamicProperties({
        [RAID_TIER_PROPERTY]: normalizedTier,
        [RAID_TYPE_PROPERTY]: normalizedType
    });
    pouch.setLore([`§7Regular | §e${"★".repeat(normalizedTier)}§r`]);
    return pouch;
}

function grantRaidPouch(player, tier, raidType) {
    if (!player?.isValid) return false;
    const granted = giveItem(player, createRaidPouch(tier, raidType));
    if (granted) player.sendMessage("§dYou received a Raid Pouch. Use it to collect your raid loot.§r");
    return granted;
}

function consumeHeldPouch(player, tier, raidType) {
    try {
        const container = player.getComponent("minecraft:inventory")?.container;
        const slot = player.selectedSlotIndex;
        if (!container || !Number.isInteger(slot)) return false;
        const held = container.getItem(slot);
        if (held?.typeId !== RAID_POUCH_ID) return false;
        if (Math.floor(Number(held.getDynamicProperty(RAID_TIER_PROPERTY))) !== tier) return false;
        if (String(held.getDynamicProperty(RAID_TYPE_PROPERTY) || "normal").toLowerCase() !== raidType) return false;
        container.setItem(slot, undefined);
        return true;
    } catch (error) {
        return false;
    }
}

function openRaidPouch(player, itemStack) {
    if (!player?.isValid || openingPlayers.has(player.id) || itemStack?.typeId !== RAID_POUCH_ID) return;
    const tier = Math.floor(Number(itemStack.getDynamicProperty(RAID_TIER_PROPERTY)));
    const raidType = String(itemStack.getDynamicProperty(RAID_TYPE_PROPERTY) || "normal").toLowerCase();
    const pool = RAID_LOOT_POOLS[tier];
    if (!pool) {
        player.sendMessage("§cThis Raid Pouch has invalid reward data.§r");
        return;
    }
    openingPlayers.add(player.id);
    try {
        const rewards = [];
        const rolls = randomInteger(pool.rolls[0], pool.rolls[1]);
        for (let index = 0; index < rolls; index++) {
            const entry = selectWeighted(pool.entries);
            const itemId = resolvedItemId(entry, raidType);
            rewards.push(itemId === "lota:raid_shard"
                ? createRaidShard(0)
                : new ItemStack(itemId, randomInteger(entry.minimum, entry.maximum)));
        }
        if (!consumeHeldPouch(player, tier, raidType)) return;
        for (const reward of rewards) giveItem(player, reward);
        try { player.dimension.playSound("random.levelup", player.location, { volume: 0.5, pitch: 0.8 }); }
        catch (error) {}
        player.sendMessage(`§aRaid Pouch opened: ${rewards.length} reward rolls.§r`);
    } catch (error) {
        console.warn(`[CobbleDrockRaidRewards] Pouch opening failed: ${error}`);
        player.sendMessage("§cThe Raid Pouch could not be opened.§r");
    } finally {
        openingPlayers.delete(player.id);
    }
}

system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent("lota:raid_pouch", {
        onUse({ source, itemStack }) {
            if (source?.typeId !== "minecraft:player" || !itemStack) return;
            system.run(() => openRaidPouch(source, itemStack));
        }
    });
    itemComponentRegistry.registerCustomComponent("lota:raid_shard", {
        onUse({ source, itemStack }) {
            if (source?.typeId !== "minecraft:player" || !itemStack) return;
            system.run(() => useRaidShard(source, itemStack));
        }
    });
});

subscribeCoreRaidRewardResult(result => {
    if (!String(result?.raidId || "").startsWith("content-den:")) return;
    if (!["caught", "passed"].includes(String(result?.outcome || ""))) return;
    const player = playerById(result.playerId);
    if (!player?.isValid) return;
    chargeRaidShard(player, result.energy);
    grantRaidPouch(player, result.tier, result.raidType);
});

world.afterEvents.playerLeave.subscribe(event => openingPlayers.delete(event.playerId));
