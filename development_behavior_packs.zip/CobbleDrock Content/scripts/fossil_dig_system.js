import { world, system } from "@minecraft/server";

const SUSPICIOUS_BLOCKS = ["minecraft:suspicious_sand", "minecraft:suspicious_gravel"];

const WATCH_TIMEOUT_TICKS = 30;

function isFossil(itemId) {
    return !!itemId && itemId.startsWith("fm:");
}

const watched = new Map();

world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    try {
        const { itemStack, block } = ev;
        if (!itemStack || itemStack.typeId !== "minecraft:brush") return;
        if (!SUSPICIOUS_BLOCKS.includes(block.typeId)) return;

        const key = block.dimension.id + "," + block.location.x + "," + block.location.y + "," + block.location.z;
        watched.set(key, {
            lastBrushTick: system.currentTick,
            dimensionId: block.dimension.id,
            loc: { x: block.location.x, y: block.location.y, z: block.location.z },
            player: ev.player
        });
    } catch {}
});

system.runInterval(() => {
    if (watched.size === 0) return;
    const now = system.currentTick;

    for (const [key, data] of watched) {
        try {
            const dim = world.getDimension(data.dimensionId);
            const block = dim.getBlock(data.loc);

            const stillSuspicious = block && SUSPICIOUS_BLOCKS.includes(block.typeId);
            const timedOut = (now - data.lastBrushTick) > WATCH_TIMEOUT_TICKS;

            if (stillSuspicious && !timedOut) continue;


            watched.delete(key);
            if (!stillSuspicious) {

                reportResult(dim, data.loc, data.player);
            }
        } catch {
            watched.delete(key);
        }
    }
}, 5);

function reportResult(dimension, loc, player) {
    try {
        const items = dimension.getEntities({
            location: { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 },
            maxDistance: 1.5,
            type: "minecraft:item"
        });


        let foundId;
        for (const itemEntity of items) {
            try {
                const comp = itemEntity.getComponent("minecraft:item");
                const id = comp?.itemStack?.typeId;
                if (id) { foundId = id; break; }
            } catch {}
        }

        if (!player?.isValid) return;

        if (foundId === "fm:mew_dna") {
            player.sendMessage({ translate: "message.cobbledrock.fossil.dna_found" });
        } else if (isFossil(foundId)) {
            player.sendMessage({ translate: "message.cobbledrock.fossil.found" });
        } else if (foundId) {
            player.sendMessage({ translate: "message.cobbledrock.fossil.other_found" });
        } else {
            player.sendMessage({ translate: "message.cobbledrock.fossil.nothing_found" });
        }
    } catch {}
}
