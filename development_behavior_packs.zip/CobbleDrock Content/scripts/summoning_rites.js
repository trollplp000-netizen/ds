import { BlockPermutation, EasingType, ItemStack, system, world } from "@minecraft/server";
import {
    requestCorePokemonSpawn,
    subscribeCorePokemonSpawnResult
} from "./core_bridge.js";

const ALTAR_ID = "lota:legendary_ritual_altar";
const PEDESTAL_ID = "lota:ritual_offering_pedestal";
const RITUAL_KIND_STATE = "lota:ritual_kind";
const SLOT_STATE = "lota:offering_slot";
const COUNT_HIGH_STATE = "lota:offering_count_high";
const COUNT_LOW_STATE = "lota:offering_count_low";
const ALTAR_STAGE_STATE = "lota:ritual_stage";
const SEARCH_RADIUS = 12;
const SEARCH_VERTICAL = 4;
const INTERACTION_DEBOUNCE_TICKS = 4;
const REQUEST_TIMEOUT_TICKS = 200;
const RITUAL_START_DELAY_TICKS = 12;
const SUMMON_HEIGHT = 5.5;
const RETIRED_RITUAL_KINDS = new Set([1, 2, 3]);

const RITUALS = Object.freeze({
    4: Object.freeze({
        id: "regirock",
        species: "regirock",
        catalystId: "lota:tectonic_sigil",
        catalystKey: "item.lota.tectonic_sigil",
        level: 70,
        offerings: Object.freeze({
            1: Object.freeze({ itemId: "minecraft:cobblestone", itemKey: "lota.ritual.item.cobblestone", required: 32 }),
            2: Object.freeze({ itemId: "minecraft:red_sand", itemKey: "lota.ritual.item.red_sand", required: 16 }),
            3: Object.freeze({ itemId: "minecraft:obsidian", itemKey: "lota.ritual.item.obsidian", required: 8 })
        }),
        sounds: Object.freeze({ seal: "dig.stone", charge: "mob.iron_golem.hit", gate: "beacon.power", reveal: "random.explode", impact: "lota.cobblemon.impact.rock", cry: "pokemon.regirock.ambient" }),
        successKey: "lota.message.ritual.spawned.regirock",
        titleKey: "lota.message.ritual.title.regirock",
        subtitleKey: "lota.message.ritual.subtitle.regirock"
    }),
    5: Object.freeze({
        id: "regice",
        species: "regice",
        catalystId: "lota:aurora_sigil",
        catalystKey: "item.lota.aurora_sigil",
        level: 70,
        offerings: Object.freeze({
            1: Object.freeze({ itemId: "minecraft:packed_ice", itemKey: "lota.ritual.item.packed_ice", required: 32 }),
            2: Object.freeze({ itemId: "minecraft:snowball", itemKey: "lota.ritual.item.snowball", required: 16 }),
            3: Object.freeze({ itemId: "minecraft:amethyst_shard", itemKey: "lota.ritual.item.amethyst_shard", required: 8 })
        }),
        sounds: Object.freeze({ seal: "random.glass", charge: "chime.amethyst_block", gate: "beacon.power", reveal: "mob.evocation_illager.cast_spell", impact: "lota.cobblemon.impact.ice", cry: "pokemon.regice.ambient" }),
        successKey: "lota.message.ritual.spawned.regice",
        titleKey: "lota.message.ritual.title.regice",
        subtitleKey: "lota.message.ritual.subtitle.regice"
    }),
    6: Object.freeze({
        id: "registeel",
        species: "registeel",
        catalystId: "lota:alloy_sigil",
        catalystKey: "item.lota.alloy_sigil",
        level: 70,
        offerings: Object.freeze({
            1: Object.freeze({ itemId: "minecraft:iron_ingot", itemKey: "lota.ritual.item.iron_ingot", required: 24 }),
            2: Object.freeze({ itemId: "minecraft:copper_ingot", itemKey: "lota.ritual.item.copper_ingot", required: 24 }),
            3: Object.freeze({ itemId: "minecraft:redstone", itemKey: "lota.ritual.item.redstone", required: 16 })
        }),
        sounds: Object.freeze({ seal: "mob.iron_golem.hit", charge: "random.anvil_land", gate: "beacon.power", reveal: "random.anvil_land", impact: "lota.cobblemon.impact.steel", cry: "pokemon.registeel.ambient" }),
        successKey: "lota.message.ritual.spawned.registeel",
        titleKey: "lota.message.ritual.title.registeel",
        subtitleKey: "lota.message.ritual.subtitle.registeel"
    })
});

const RITUAL_PEDESTAL_OFFSETS = Object.freeze({
    4: Object.freeze([[-9, -1, 0], [0, -1, -9], [9, -1, 0]]),
    5: Object.freeze([[-9, -1, 0], [0, -1, -9], [9, -1, 0]]),
    6: Object.freeze([[-9, -1, 0], [0, -1, -9], [9, -1, 0]])
});
const RITUAL_PEDESTAL_DIRECTIONS = Object.freeze(["east", "south", "west"]);
const LEGACY_RITUAL_PEDESTAL_OFFSETS = Object.freeze([
    [0, -3, -8],
    [-7, -3, 5],
    [7, -3, 5]
]);
const RITUAL_DAIS_BLOCKS = Object.freeze({
    4: Object.freeze({ lower: "minecraft:stone_bricks", upper: "minecraft:red_sandstone", light: "minecraft:ochre_froglight" }),
    5: Object.freeze({ lower: "minecraft:prismarine_bricks", upper: "minecraft:blue_ice", light: "minecraft:sea_lantern" }),
    6: Object.freeze({ lower: "minecraft:deepslate_bricks", upper: "minecraft:cut_copper", light: "minecraft:redstone_lamp" })
});
const RITUAL_ENTRANCE_BLOCKS = Object.freeze({
    4: Object.freeze({ foundation: "minecraft:smooth_sandstone", floor: "minecraft:cut_sandstone", accent: "minecraft:red_sandstone" }),
    5: Object.freeze({ foundation: "minecraft:snow", floor: "minecraft:packed_ice", accent: "minecraft:blue_ice" }),
    6: Object.freeze({ foundation: "minecraft:deepslate_tiles", floor: "minecraft:polished_deepslate", accent: "minecraft:cut_copper" })
});
const RITUAL_CAMERA_OFFSETS = Object.freeze({
    4: Object.freeze([[8, 4.5, 10], [0, 4.25, 11], [-8, 4.5, 10]]),
    5: Object.freeze([[8, 4.5, 10], [0, 4.25, 11], [-8, 4.5, 10]]),
    6: Object.freeze([[8, 4.5, 10], [0, 4.25, 11], [-8, 4.5, 10]])
});
const REGICE_MELTING_ICE_COLUMNS = Object.freeze([
    [19, 11, 1],
    [0, 22, 3],
    [-19, 11, 1],
    [-19, -11, 3],
    [0, -22, 1],
    [19, -11, 3]
]);
const MELTING_ICE_BLOCK_IDS = new Set([
    "minecraft:ice",
    "minecraft:frosted_ice",
    "minecraft:water",
    "minecraft:flowing_water"
]);
const BROKEN_RITUAL_BLOCK_IDS = new Set([
    "minecraft:unknown",
    "minecraft:info_update",
    "minecraft:info_update2"
]);

const pendingBySite = new Map();
const pendingByRequest = new Map();
const lastInteraction = new Map();

function stateNumber(permutation, stateName) {
    return Math.max(0, Math.trunc(Number(permutation?.getState(stateName)) || 0));
}

function offeringCount(permutation) {
    return stateNumber(permutation, COUNT_HIGH_STATE) * 16
        + stateNumber(permutation, COUNT_LOW_STATE);
}

function ritualFor(permutation) {
    return RITUALS[stateNumber(permutation, RITUAL_KIND_STATE)];
}

function blockKey(block) {
    const { x, y, z } = block.location;
    return `${block.dimension.id}:${x}:${y}:${z}`;
}

function safeBlock(dimension, location) {
    try { return dimension.getBlock(location); }
    catch (error) { return undefined; }
}

function translated(key) {
    return { translate: key };
}

function showActionbar(player, rawtext) {
    try { player.onScreenDisplay.setActionBar({ rawtext }); }
    catch (error) {}
}

function showKey(player, key) {
    showActionbar(player, [translated(key)]);
}

function showOfferingProgress(player, offering, count) {
    showActionbar(player, [
        translated(offering.itemKey),
        { text: ` §7${count}/${offering.required}§r` }
    ]);
}

function heldSlot(player) {
    const container = player.getComponent("minecraft:inventory")?.container;
    const slot = Math.max(0, Math.trunc(Number(player.selectedSlotIndex) || 0));
    return { container, slot, stack: container?.getItem(slot) };
}

function consumeHeldAmount(player, expectedItemId, requestedAmount) {
    const { container, slot, stack } = heldSlot(player);
    if (!container || stack?.typeId !== expectedItemId) return 0;
    const consumed = Math.max(0, Math.min(stack.amount, Math.trunc(requestedAmount)));
    if (!consumed) return 0;
    if (stack.amount <= consumed) container.setItem(slot, undefined);
    else {
        stack.amount -= consumed;
        container.setItem(slot, stack);
    }
    return consumed;
}

function giveOrDrop(player, itemId, amount, location = player.location) {
    let remaining = Math.max(0, Math.trunc(amount));
    while (remaining > 0) {
        const item = new ItemStack(itemId, Math.min(64, remaining));
        remaining -= item.amount;
        try {
            const remainder = player.getComponent("minecraft:inventory")?.container?.addItem(item);
            if (remainder) player.dimension.spawnItem(remainder, location);
        } catch (error) {
            try { player.dimension.spawnItem(item, location); }
            catch (dropError) {}
        }
    }
}

function setState(block, stateName, value) {
    block.setPermutation(block.permutation.withState(stateName, value));
}

function setOfferingCount(block, count) {
    const safeCount = Math.max(0, Math.min(32, Math.trunc(Number(count) || 0)));
    block.setPermutation(block.permutation
        .withState(COUNT_HIGH_STATE, Math.floor(safeCount / 16))
        .withState(COUNT_LOW_STATE, safeCount % 16));
}

function safeSound(dimension, soundId, location, options = undefined) {
    try { dimension.playSound(soundId, location, options); }
    catch (error) {}
}

function particle(site, role, location) {
    try { site.dimension.spawnParticle(`lota:${site.ritual.id}_ritual_${role}`, location); }
    catch (error) {}
}

function vanillaParticle(site, effectId, location) {
    try { site.dimension.spawnParticle(effectId, location); }
    catch (error) {}
}

function centerOf(block, height = 0.5) {
    return {
        x: block.location.x + 0.5,
        y: block.location.y + height,
        z: block.location.z + 0.5
    };
}

function distanceSquared(left, right) {
    const dx = left.x - right.x;
    const dy = left.y - right.y;
    const dz = left.z - right.z;
    return dx * dx + dy * dy + dz * dz;
}

function blocksAround(origin, blockType, ritualKind) {
    const found = [];
    const dimension = origin.dimension;
    const base = origin.location;
    for (let y = base.y - SEARCH_VERTICAL; y <= base.y + SEARCH_VERTICAL; y += 1) {
        for (let x = base.x - SEARCH_RADIUS; x <= base.x + SEARCH_RADIUS; x += 1) {
            for (let z = base.z - SEARCH_RADIUS; z <= base.z + SEARCH_RADIUS; z += 1) {
                let block;
                try { block = dimension.getBlock({ x, y, z }); }
                catch (error) { continue; }
                if (!block || block.typeId !== blockType) continue;
                if (stateNumber(block.permutation, RITUAL_KIND_STATE) !== ritualKind) continue;
                found.push(block);
            }
        }
    }
    return found;
}

function findPedestals(altar, ritualKind) {
    const bySlot = new Map();
    for (const block of blocksAround(altar, PEDESTAL_ID, ritualKind)) {
        const slot = stateNumber(block.permutation, SLOT_STATE);
        if (!RITUALS[ritualKind]?.offerings[slot]) continue;
        const previous = bySlot.get(slot);
        if (!previous || distanceSquared(block.location, altar.location) < distanceSquared(previous.location, altar.location)) {
            bySlot.set(slot, block);
        }
    }
    return bySlot;
}

function rotatedOffset([x, y, z], turns) {
    let rotatedX = x;
    let rotatedZ = z;
    for (let turn = 0; turn < turns; turn += 1) {
        [rotatedX, rotatedZ] = [-rotatedZ, rotatedX];
    }
    return [rotatedX, y, rotatedZ];
}

function ritualLayoutMatch(altar, ritualKind) {
    const ritual = RITUALS[ritualKind];
    const offsets = RITUAL_PEDESTAL_OFFSETS[ritualKind];
    if (!ritual || !offsets) return undefined;
    const candidates = [];
    for (let turns = 0; turns < 4; turns += 1) {
        const targets = offsets.map((offset, index) => {
            const [x, y, z] = rotatedOffset(offset, turns);
            let block;
            try {
                block = altar.dimension.getBlock({
                    x: altar.location.x + x,
                    y: altar.location.y + y,
                    z: altar.location.z + z
                });
            } catch (error) {}
            const slot = index + 1;
            const linked = block?.typeId === PEDESTAL_ID
                && stateNumber(block.permutation, RITUAL_KIND_STATE) === ritualKind
                && stateNumber(block.permutation, SLOT_STATE) === slot;
            return { block, slot, linked, broken: BROKEN_RITUAL_BLOCK_IDS.has(block?.typeId) };
        });
        if (targets.some(target => !target.linked && !target.broken)) continue;
        candidates.push({
            targets,
            turns,
            score: targets.reduce((sum, target) => sum + (target.linked ? 2 : 1), 0)
        });
    }
    candidates.sort((left, right) => right.score - left.score);
    return candidates[0];
}

function repairMissingPedestals(altar, ritualKind) {
    const match = ritualLayoutMatch(altar, ritualKind);
    if (!match) return 0;
    const direction = altar.permutation.getState("minecraft:cardinal_direction") || "north";
    let repaired = 0;
    for (const target of match.targets) {
        if (!target.broken) continue;
        try {
            target.block.setPermutation(BlockPermutation.resolve(PEDESTAL_ID, {
                "minecraft:cardinal_direction": direction,
                [RITUAL_KIND_STATE]: ritualKind,
                [SLOT_STATE]: target.slot,
                [COUNT_HIGH_STATE]: 0,
                [COUNT_LOW_STATE]: 0
            }));
            repaired += 1;
        } catch (error) {}
    }
    return repaired;
}

function rotatedDirection(direction, turns) {
    const directions = ["north", "east", "south", "west"];
    const index = directions.indexOf(direction);
    return directions[(index + turns) % directions.length];
}

function faceRitualPedestalsTowardAltar(altar, ritualKind) {
    const match = ritualLayoutMatch(altar, ritualKind);
    if (!match) return 0;
    let changed = 0;
    for (let index = 0; index < match.targets.length; index += 1) {
        const block = match.targets[index].block;
        if (block?.typeId !== PEDESTAL_ID) continue;
        const direction = rotatedDirection(RITUAL_PEDESTAL_DIRECTIONS[index], match.turns);
        if (block.permutation.getState("minecraft:cardinal_direction") === direction) continue;
        try {
            block.setPermutation(block.permutation.withState("minecraft:cardinal_direction", direction));
            changed += 1;
        } catch (error) {}
    }
    return changed;
}

function repairRegiceMeltingIce(altar) {
    const ritualKind = stateNumber(altar?.permutation, RITUAL_KIND_STATE);
    if (ritualKind !== 5) return 0;
    const turns = ritualLayoutMatch(altar, ritualKind)?.turns || 0;
    const packedIce = BlockPermutation.resolve("minecraft:packed_ice");
    let repaired = 0;
    for (const [offsetX, offsetZ, topY] of REGICE_MELTING_ICE_COLUMNS) {
        for (let offsetY = -5; offsetY <= topY; offsetY += 1) {
            const [x, y, z] = rotatedOffset([offsetX, offsetY, offsetZ], turns);
            const block = safeBlock(altar.dimension, {
                x: altar.location.x + x,
                y: altar.location.y + y,
                z: altar.location.z + z
            });
            if (!MELTING_ICE_BLOCK_IDS.has(block?.typeId)) continue;
            try {
                block.setPermutation(packedIce);
                repaired += 1;
            } catch (error) {}
        }
    }
    return repaired;
}

function repairRitualEntranceStairs(altar, ritualKind) {
    const palette = RITUAL_ENTRANCE_BLOCKS[ritualKind];
    if (!palette) return 0;
    const turns = ritualLayoutMatch(altar, ritualKind)?.turns || 0;
    const air = BlockPermutation.resolve("minecraft:air");
    const foundation = BlockPermutation.resolve(palette.foundation);
    let repaired = 0;
    for (let offsetZ = 17; offsetZ <= 24; offsetZ += 1) {
        const topY = -4 - Math.floor((offsetZ - 16) / 2);
        const surface = BlockPermutation.resolve(offsetZ % 2 ? palette.floor : palette.accent);
        for (let offsetX = -3; offsetX <= 3; offsetX += 1) {
            for (let offsetY = -8; offsetY <= topY; offsetY += 1) {
                const [x, y, z] = rotatedOffset([offsetX, offsetY, offsetZ], turns);
                const block = safeBlock(altar.dimension, {
                    x: altar.location.x + x,
                    y: altar.location.y + y,
                    z: altar.location.z + z
                });
                if (!block) continue;
                try {
                    block.setPermutation(offsetY === topY ? surface : foundation);
                    repaired += 1;
                } catch (error) {}
            }
            for (let offsetY = topY + 1; offsetY <= -4; offsetY += 1) {
                const [x, y, z] = rotatedOffset([offsetX, offsetY, offsetZ], turns);
                const block = safeBlock(altar.dimension, {
                    x: altar.location.x + x,
                    y: altar.location.y + y,
                    z: altar.location.z + z
                });
                if (!block || block.typeId === "minecraft:air") continue;
                try {
                    block.setPermutation(air);
                    repaired += 1;
                } catch (error) {}
            }
        }
    }
    return repaired;
}

function migrateLegacyRitualPedestals(altar, ritualKind) {
    const palette = RITUAL_DAIS_BLOCKS[ritualKind];
    const targetOffsets = RITUAL_PEDESTAL_OFFSETS[ritualKind];
    if (!palette || !targetOffsets) return 0;
    for (let turns = 0; turns < 4; turns += 1) {
        const sources = LEGACY_RITUAL_PEDESTAL_OFFSETS.map((offset, index) => {
            const [x, y, z] = rotatedOffset(offset, turns);
            const block = safeBlock(altar.dimension, {
                x: altar.location.x + x,
                y: altar.location.y + y,
                z: altar.location.z + z
            });
            const slot = index + 1;
            return {
                block,
                slot,
                linked: block?.typeId === PEDESTAL_ID
                    && stateNumber(block.permutation, RITUAL_KIND_STATE) === ritualKind
                    && stateNumber(block.permutation, SLOT_STATE) === slot
            };
        });
        if (!sources.every(source => source.linked)) continue;
        const targets = targetOffsets.map(offset => {
            const [x, y, z] = rotatedOffset(offset, turns);
            return {
                x: altar.location.x + x,
                y: altar.location.y + y,
                z: altar.location.z + z
            };
        });
        const targetBlocks = targets.map(location => safeBlock(altar.dimension, location));
        if (targetBlocks.some((block, index) => {
            return block?.typeId === PEDESTAL_ID
                && stateNumber(block.permutation, SLOT_STATE) === index + 1;
        })) return 0;
        if (targetBlocks.some(block => !block)) continue;

        for (const location of targets) {
            const directionX = Math.sign(location.x - altar.location.x);
            const directionZ = Math.sign(location.z - altar.location.z);
            for (let step = 4; step <= 7; step += 1) {
                safeBlock(altar.dimension, {
                    x: altar.location.x + directionX * step,
                    y: location.y - 2,
                    z: altar.location.z + directionZ * step
                })?.setPermutation(BlockPermutation.resolve(palette.light));
            }
            for (let dx = -2; dx <= 2; dx += 1) {
                for (let dz = -2; dz <= 2; dz += 1) {
                    const distance = Math.hypot(dx, dz);
                    if (distance <= 2.3) {
                        safeBlock(altar.dimension, { x: location.x + dx, y: location.y - 2, z: location.z + dz })
                            ?.setPermutation(BlockPermutation.resolve(palette.lower));
                    }
                    if (distance <= 1.5) {
                        safeBlock(altar.dimension, { x: location.x + dx, y: location.y - 1, z: location.z + dz })
                            ?.setPermutation(BlockPermutation.resolve(palette.upper));
                    }
                }
            }
            for (const [dx, dz] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) {
                safeBlock(altar.dimension, { x: location.x + dx, y: location.y - 1, z: location.z + dz })
                    ?.setPermutation(BlockPermutation.resolve(palette.light));
            }
        }
        for (let index = 0; index < targets.length; index += 1) {
            targetBlocks[index].setPermutation(sources[index].block.permutation);
            sources[index].block.setPermutation(BlockPermutation.resolve(palette.upper));
        }
        return targets.length;
    }
    return 0;
}

function removeRetiredRitualSite(altar, ritualKind) {
    const air = BlockPermutation.resolve("minecraft:air");
    for (const pedestal of blocksAround(altar, PEDESTAL_ID, ritualKind)) {
        try { pedestal.setPermutation(air); }
        catch (error) {}
    }
    try { altar.setPermutation(air); }
    catch (error) {}
}

function findAltar(pedestal, ritualKind) {
    let closest;
    for (const block of blocksAround(pedestal, ALTAR_ID, ritualKind)) {
        if (!closest || distanceSquared(block.location, pedestal.location) < distanceSquared(closest.location, pedestal.location)) {
            closest = block;
        }
    }
    return closest;
}

function ritualProgress(altar, ritualKind) {
    const ritual = RITUALS[ritualKind];
    const pedestals = findPedestals(altar, ritualKind);
    const entries = [];
    for (const slot of [1, 2, 3]) {
        const offering = ritual?.offerings[slot];
        const block = pedestals.get(slot);
        const count = block ? offeringCount(block.permutation) : 0;
        const required = offering?.required || 0;
        entries.push({ slot, offering, block, count, required, complete: Boolean(
            offering && block && required === offering.required && count >= offering.required
        ) });
    }
    return {
        entries,
        completeCount: entries.filter(entry => entry.complete).length,
        complete: entries.every(entry => entry.complete)
    };
}

function debounce(player, block) {
    const key = `${player.id}:${blockKey(block)}`;
    const previousTick = lastInteraction.get(key) ?? -100;
    if (system.currentTick - previousTick < INTERACTION_DEBOUNCE_TICKS) return false;
    lastInteraction.set(key, system.currentTick);
    return true;
}

function validatePedestal(block) {
    if (!block || block.typeId !== PEDESTAL_ID) return undefined;
    const ritualKind = stateNumber(block.permutation, RITUAL_KIND_STATE);
    const slot = stateNumber(block.permutation, SLOT_STATE);
    const offering = RITUALS[ritualKind]?.offerings[slot];
    if (!offering) return undefined;
    return { ritualKind, ritual: RITUALS[ritualKind], slot, offering };
}

function showAltarStatus(player, altar, ritualKind) {
    const ritual = RITUALS[ritualKind];
    const progress = ritualProgress(altar, ritualKind);
    const catalystPlaced = stateNumber(altar.permutation, ALTAR_STAGE_STATE) > 0;
    showActionbar(player, [
        translated("lota.message.ritual.status"),
        { text: ` §f${progress.completeCount}/3§r §8· §r` },
        translated(catalystPlaced ? "lota.message.ritual.catalyst_ready" : "lota.message.ritual.catalyst_needed"),
        translated(ritual.catalystKey)
    ]);
}

function interactWithOfferingPedestal({ block, player }) {
    if (!player?.isValid || !debounce(player, block)) return;
    const ritualKind = stateNumber(block.permutation, RITUAL_KIND_STATE);
    if (RETIRED_RITUAL_KINDS.has(ritualKind)) {
        const altar = findAltar(block, ritualKind);
        if (altar) removeRetiredRitualSite(altar, ritualKind);
        else {
            try { block.setPermutation(BlockPermutation.resolve("minecraft:air")); }
            catch (error) {}
        }
        return;
    }
    const legacySlot = stateNumber(block.permutation, SLOT_STATE);
    const linkedAltar = findAltar(block, ritualKind);
    if (linkedAltar) {
        try { migrateLegacyRitualPedestals(linkedAltar, ritualKind); }
        catch (error) {}
        repairRegiceMeltingIce(linkedAltar);
        repairRitualEntranceStairs(linkedAltar, ritualKind);
        faceRitualPedestalsTowardAltar(linkedAltar, ritualKind);
        block = findPedestals(linkedAltar, ritualKind).get(legacySlot) || block;
    }
    const link = validatePedestal(block);
    if (!link) {
        showKey(player, "lota.message.ritual.unlinked");
        return;
    }
    const key = blockKey(block);
    for (const site of pendingBySite.values()) {
        if (site.pedestalKeys.has(key)) {
            showKey(player, "lota.message.ritual.busy");
            return;
        }
    }
    const count = offeringCount(block.permutation);
    const { stack } = heldSlot(player);
    if (player.isSneaking && count > 0) {
        try { setOfferingCount(block, 0); }
        catch (error) { return; }
        giveOrDrop(player, link.offering.itemId, count, centerOf(block, 1));
        safeSound(block.dimension, "random.pop", centerOf(block, 1), { volume: 0.7, pitch: 1.2 });
        showOfferingProgress(player, link.offering, 0);
        return;
    }
    if (count >= link.offering.required) {
        showOfferingProgress(player, link.offering, count);
        return;
    }
    if (stack?.typeId !== link.offering.itemId) {
        showOfferingProgress(player, link.offering, count);
        return;
    }
    const deposited = consumeHeldAmount(player, link.offering.itemId, link.offering.required - count);
    if (!deposited) return;
    const nextCount = count + deposited;
    try { setOfferingCount(block, nextCount); }
    catch (error) {
        giveOrDrop(player, link.offering.itemId, deposited, centerOf(block, 1));
        return;
    }
    const completed = nextCount >= link.offering.required;
    safeSound(block.dimension, completed ? "beacon.activate" : "random.orb", centerOf(block, 1), {
        volume: completed ? 0.95 : 0.65,
        pitch: completed ? 1.15 : 1.4
    });
    showOfferingProgress(player, link.offering, nextCount);
    if (!completed) return;
    const altar = findAltar(block, link.ritualKind);
    if (altar && stateNumber(altar.permutation, ALTAR_STAGE_STATE) === 1) {
        tryStartRitual(player, altar, link.ritualKind);
    }
}

function validAltar(site, expectedStage = undefined) {
    try {
        const block = site.dimension.getBlock(site.location);
        if (!block || block.typeId !== ALTAR_ID) return undefined;
        if (stateNumber(block.permutation, RITUAL_KIND_STATE) !== site.kind) return undefined;
        if (expectedStage !== undefined && stateNumber(block.permutation, ALTAR_STAGE_STATE) !== expectedStage) return undefined;
        return block;
    } catch (error) {
        return undefined;
    }
}

function isPending(site) {
    return pendingBySite.get(site.key) === site;
}

function clearCamera(site) {
    if (!site.cameraActive) return;
    site.cameraActive = false;
    try { if (site.player?.isValid) site.player.camera.clear(); }
    catch (error) {}
}

function passable(block) {
    return !block || block.typeId === "minecraft:air"
        || block.typeId === "minecraft:cave_air"
        || block.typeId === "minecraft:void_air"
        || block.typeId.includes("water");
}

function cameraPositionClear(site, location) {
    const samples = [
        [0, 0, 0], [0, 0.45, 0],
        [0.35, 0, 0], [-0.35, 0, 0],
        [0, 0, 0.35], [0, 0, -0.35]
    ];
    for (const [x, y, z] of samples) {
        try {
            if (!passable(site.dimension.getBlock({
                x: Math.floor(location.x + x),
                y: Math.floor(location.y + y),
                z: Math.floor(location.z + z)
            }))) return false;
        } catch (error) {
            return false;
        }
    }
    return true;
}

function cameraViewClear(site, from, to) {
    for (let step = 1; step <= 12; step += 1) {
        const progress = step / 15;
        try {
            if (!passable(site.dimension.getBlock({
                x: Math.floor(from.x + (to.x - from.x) * progress),
                y: Math.floor(from.y + (to.y - from.y) * progress),
                z: Math.floor(from.z + (to.z - from.z) * progress)
            }))) return false;
        } catch (error) {
            return false;
        }
    }
    return true;
}

function setRitualCamera(site) {
    const player = site.player;
    if (!player?.isValid) return;
    const focus = {
        x: site.location.x + 0.5,
        y: site.location.y + 3,
        z: site.location.z + 0.5
    };
    const offsets = RITUAL_CAMERA_OFFSETS[site.kind] || [[0, 3, 6]];
    const candidates = offsets.map(offset => {
        const [x, y, z] = rotatedOffset(offset, site.layoutTurns || 0);
        return {
            x: site.location.x + 0.5 + x,
            y: site.location.y + y,
            z: site.location.z + 0.5 + z
        };
    });
    let cameraLocation;
    for (const candidate of candidates) {
        if (!cameraPositionClear(site, candidate) || !cameraViewClear(site, candidate, focus)) continue;
        cameraLocation = candidate;
        break;
    }
    cameraLocation ||= {
        x: player.location.x,
        y: player.location.y + 1.6,
        z: player.location.z
    };
    try {
        player.camera.setCamera("minecraft:free", {
            location: cameraLocation,
            facingLocation: focus,
            easeOptions: { easeTime: 0.5, easeType: EasingType.InOutSine }
        });
        site.cameraActive = true;
        system.runTimeout(() => clearCamera(site), 96);
    } catch (error) {}
}

function particleLine(site, role, from, to, count) {
    for (let index = 0; index <= count; index += 1) {
        const progress = index / Math.max(1, count);
        particle(site, role, {
            x: from.x + (to.x - from.x) * progress,
            y: from.y + (to.y - from.y) * progress,
            z: from.z + (to.z - from.z) * progress
        });
    }
}

function themeGlyph(site, stage, center) {
    const id = site.ritual.id;
    const sides = id === "regirock" ? 6 : id === "regice" ? 8 : 10;
    const radius = 2.25 + stage * 0.42;
    const points = Array.from({ length: sides }, (_, index) => ({
        x: center.x + Math.cos(index * Math.PI * 2 / sides + stage * 0.1) * radius,
        y: center.y + (index % 2) * 0.09,
        z: center.z + Math.sin(index * Math.PI * 2 / sides + stage * 0.1) * radius
    }));
    for (let index = 0; index < points.length; index += 1) {
        particleLine(site, "detail", points[index], points[(index + 1) % points.length], 4);
        particle(site, "motif", points[index]);
    }
}

function convergenceStage(site, stage) {
    if (!isPending(site) || !validAltar(site, 2)) return;
    const center = {
        x: site.location.x + 0.5,
        y: site.location.y + 0.18,
        z: site.location.z + 0.5
    };
    if (stage === 0) {
        particle(site, "rune", center);
        safeSound(site.dimension, site.ritual.sounds.seal, center, { volume: 1.1, pitch: 0.72 });
    }
    for (const pedestal of site.pedestals) {
        const from = centerOf(pedestal, 1.05);
        particle(site, "core", from);
        particleLine(site, stage % 2 ? "detail" : "beam", from, {
            x: center.x,
            y: center.y + 0.42,
            z: center.z
        }, 7 + stage * 2);
    }
    themeGlyph(site, stage, center);
    particle(site, "core", { ...center, y: center.y + 0.52 + stage * 0.22 });
    safeSound(site.dimension, site.ritual.sounds.charge, center, {
        volume: 0.75 + stage * 0.12,
        pitch: 0.68 + stage * 0.12
    });
}

function openGate(site) {
    if (!isPending(site) || !validAltar(site, 2)) return;
    const start = {
        x: site.location.x + 0.5,
        y: site.location.y + 1,
        z: site.location.z + 0.5
    };
    const focus = { ...start, y: site.location.y + SUMMON_HEIGHT };
    particleLine(site, "beam", start, focus, 16);
    particle(site, "halo", focus);
    particle(site, "core", focus);
    for (let arc = 0; arc < 16; arc += 1) {
        const angle = arc * Math.PI * 2 / 16;
        particle(site, arc % 4 === 0 ? "motif" : "detail", {
            x: focus.x + Math.cos(angle) * 2.6,
            y: focus.y + Math.sin(angle) * 2.6,
            z: focus.z + (arc % 2 ? 0.08 : -0.08)
        });
    }
    safeSound(site.dimension, site.ritual.sounds.gate, focus, { volume: 1.6, pitch: 0.82 });
}

function revealBurst(site) {
    const focus = {
        x: site.location.x + 0.5,
        y: site.location.y + SUMMON_HEIGHT,
        z: site.location.z + 0.5
    };
    particle(site, "halo", focus);
    particle(site, "shockwave", focus);
    for (let ray = 0; ray < 28; ray += 1) {
        const yaw = ray * Math.PI * 2 / 28;
        const pitch = ((ray % 9) - 4) * 0.11;
        const length = 3.4 + (ray % 5) * 0.5;
        const end = {
            x: focus.x + Math.cos(yaw) * Math.cos(pitch) * length,
            y: focus.y + Math.sin(pitch) * length,
            z: focus.z + Math.sin(yaw) * Math.cos(pitch) * length
        };
        particleLine(site, ray % 4 === 0 ? "motif" : "detail", focus, end, 4);
        if (ray % 4 === 0) vanillaParticle(site, "minecraft:endrod", end);
    }
    summonClimax(site, focus);
}

function summonClimax(site, focus) {
    safeSound(site.dimension, "random.explode", focus, { volume: 2.35, pitch: 0.54 });
    safeSound(site.dimension, "beacon.power", focus, { volume: 2, pitch: 0.48 });
    safeSound(site.dimension, site.ritual.sounds.impact, focus, { volume: 2.2, pitch: 0.68 });
    safeSound(site.dimension, site.ritual.sounds.reveal, focus, { volume: 2.05, pitch: 0.86 });
    system.runTimeout(() => {
        safeSound(site.dimension, site.ritual.sounds.impact, focus, { volume: 1.55, pitch: 1.02 });
        safeSound(site.dimension, site.ritual.sounds.cry, focus, { volume: 2.25, pitch: 0.92 });
    }, 3);
    system.runTimeout(() => {
        safeSound(site.dimension, "beacon.activate", focus, { volume: 1.65, pitch: 0.58 });
    }, 7);
}

function clearPending(site) {
    clearCamera(site);
    pendingBySite.delete(site.key);
    if (site.requestId) pendingByRequest.delete(site.requestId);
}

function refundCatalyst(site) {
    if (!site.catalystActive) return;
    site.catalystActive = false;
    const altar = validAltar(site);
    if (altar) {
        try { setState(altar, ALTAR_STAGE_STATE, 0); }
        catch (error) {}
    }
    const location = {
        x: site.location.x + 0.5,
        y: site.location.y + 1,
        z: site.location.z + 0.5
    };
    if (site.player?.isValid) giveOrDrop(site.player, site.ritual.catalystId, 1, location);
    else {
        try { site.dimension.spawnItem(new ItemStack(site.ritual.catalystId, 1), location); }
        catch (error) {}
    }
}

function failRitual(site) {
    refundCatalyst(site);
    clearPending(site);
    if (site.player?.isValid) showKey(site.player, "lota.message.ritual.failed");
}

function requestSpawn(site) {
    if (!isPending(site)) return;
    const altar = validAltar(site, 2);
    if (!altar || !site.player?.isValid || site.player.dimension.id !== site.dimension.id) {
        failRitual(site);
        return;
    }
    const progress = ritualProgress(altar, site.kind);
    if (!progress.complete) {
        failRitual(site);
        return;
    }
    const requestId = requestCorePokemonSpawn(site.player, {
        species: site.ritual.species,
        level: site.ritual.level,
        location: {
            x: site.location.x + 0.5,
            y: site.location.y + SUMMON_HEIGHT,
            z: site.location.z + 0.5
        },
        duplicateRadius: 64,
        minPerfectIvs: 3,
        aspects: ["legendary"]
    });
    if (!requestId) {
        failRitual(site);
        return;
    }
    site.requestId = requestId;
    pendingByRequest.set(requestId, site);
    system.runTimeout(() => {
        if (pendingByRequest.get(requestId) === site) failRitual(site);
    }, REQUEST_TIMEOUT_TICKS);
}

function beginRitual(site) {
    if (!isPending(site) || !validAltar(site, 2) || !site.player?.isValid) {
        failRitual(site);
        return;
    }
    try {
        site.player.onScreenDisplay.setTitle(translated(site.ritual.titleKey), {
            subtitle: translated(site.ritual.subtitleKey),
            fadeInDuration: 5,
            stayDuration: 34,
            fadeOutDuration: 12
        });
    } catch (error) {}
    setRitualCamera(site);
    for (let stage = 0; stage < 4; stage += 1) {
        system.runTimeout(() => convergenceStage(site, stage), stage * 8);
    }
    system.runTimeout(() => openGate(site), 34);
    system.runTimeout(() => openGate(site), 44);
    system.runTimeout(() => requestSpawn(site), 58);
}

function tryStartRitual(player, altar, ritualKind) {
    const ritual = RITUALS[ritualKind];
    if (!ritual || stateNumber(altar.permutation, ALTAR_STAGE_STATE) !== 1) return false;
    const key = blockKey(altar);
    if (pendingBySite.has(key)) {
        showKey(player, "lota.message.ritual.busy");
        return false;
    }
    const progress = ritualProgress(altar, ritualKind);
    if (!progress.complete) {
        showAltarStatus(player, altar, ritualKind);
        return false;
    }
    try { setState(altar, ALTAR_STAGE_STATE, 2); }
    catch (error) { return false; }
    const layoutMatch = ritualLayoutMatch(altar, ritualKind);
    const site = {
        key,
        kind: ritualKind,
        ritual,
        player,
        dimension: altar.dimension,
        location: { ...altar.location },
        layoutTurns: layoutMatch?.turns || 0,
        pedestals: progress.entries.map(entry => entry.block),
        pedestalKeys: new Set(progress.entries.map(entry => blockKey(entry.block))),
        catalystActive: true,
        cameraActive: false,
        requestId: undefined
    };
    pendingBySite.set(key, site);
    showKey(player, "lota.message.ritual.started");
    system.runTimeout(() => beginRitual(site), RITUAL_START_DELAY_TICKS);
    return true;
}

function interactWithRitualAltar({ block, player }) {
    if (!player?.isValid || !debounce(player, block)) return;
    const ritualKind = stateNumber(block.permutation, RITUAL_KIND_STATE);
    if (RETIRED_RITUAL_KINDS.has(ritualKind)) {
        removeRetiredRitualSite(block, ritualKind);
        return;
    }
    const ritual = RITUALS[ritualKind];
    if (!ritual) {
        showKey(player, "lota.message.ritual.unlinked");
        return;
    }
    try { migrateLegacyRitualPedestals(block, ritualKind); }
    catch (error) {}
    repairMissingPedestals(block, ritualKind);
    repairRegiceMeltingIce(block);
    repairRitualEntranceStairs(block, ritualKind);
    faceRitualPedestalsTowardAltar(block, ritualKind);
    const key = blockKey(block);
    if (pendingBySite.has(key) || stateNumber(block.permutation, ALTAR_STAGE_STATE) === 2) {
        showKey(player, "lota.message.ritual.busy");
        return;
    }
    const stage = stateNumber(block.permutation, ALTAR_STAGE_STATE);
    const { stack } = heldSlot(player);
    if (stage === 1) {
        if (player.isSneaking) {
            try { setState(block, ALTAR_STAGE_STATE, 0); }
            catch (error) { return; }
            giveOrDrop(player, ritual.catalystId, 1, centerOf(block, 1));
            safeSound(block.dimension, "random.pop", centerOf(block, 1), { volume: 0.7, pitch: 1.2 });
            showKey(player, "lota.message.ritual.catalyst_withdrawn");
            return;
        }
        if (!tryStartRitual(player, block, ritualKind)) showAltarStatus(player, block, ritualKind);
        return;
    }
    if (stack?.typeId !== ritual.catalystId) {
        if (stack) {
            showActionbar(player, [
                translated("lota.message.ritual.wrong_catalyst"),
                translated(ritual.catalystKey)
            ]);
        } else showAltarStatus(player, block, ritualKind);
        return;
    }
    if (!consumeHeldAmount(player, ritual.catalystId, 1)) return;
    try { setState(block, ALTAR_STAGE_STATE, 1); }
    catch (error) {
        giveOrDrop(player, ritual.catalystId, 1, centerOf(block, 1));
        return;
    }
    safeSound(block.dimension, "beacon.activate", centerOf(block, 1), { volume: 1, pitch: 0.82 });
    showKey(player, "lota.message.ritual.catalyst_placed");
    if (!tryStartRitual(player, block, ritualKind)) showAltarStatus(player, block, ritualKind);
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(
        "lota:ritual_offering_pedestal_component",
        { onPlayerInteract: interactWithOfferingPedestal }
    );
    blockComponentRegistry.registerCustomComponent(
        "lota:legendary_ritual_altar_component",
        { onPlayerInteract: interactWithRitualAltar }
    );
});

subscribeCorePokemonSpawnResult(result => {
    const requestId = String(result?.requestId || "");
    const site = pendingByRequest.get(requestId);
    if (!site) return;
    if (result.outcome !== "spawned") {
        failRitual(site);
        return;
    }
    site.catalystActive = false;
    const altar = validAltar(site);
    if (altar) {
        try { setState(altar, ALTAR_STAGE_STATE, 0); }
        catch (error) {}
    }
    for (const pedestal of site.pedestals) {
        try {
            const current = pedestal.dimension.getBlock(pedestal.location);
            if (current?.typeId === PEDESTAL_ID) setOfferingCount(current, 0);
        } catch (error) {}
    }
    clearPending(site);
    revealBurst(site);
    if (site.player?.isValid) showKey(site.player, site.ritual.successKey);
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    const permutation = event.brokenBlockPermutation;
    const typeId = permutation.type.id;
    if (typeId !== ALTAR_ID && typeId !== PEDESTAL_ID) return;
    const location = {
        x: event.block.location.x + 0.5,
        y: event.block.location.y + 0.8,
        z: event.block.location.z + 0.5
    };
    const key = `${event.block.dimension.id}:${event.block.location.x}:${event.block.location.y}:${event.block.location.z}`;
    if (typeId === PEDESTAL_ID) {
        const ritualKind = stateNumber(permutation, RITUAL_KIND_STATE);
        const slot = stateNumber(permutation, SLOT_STATE);
        const count = offeringCount(permutation);
        const itemId = RITUALS[ritualKind]?.offerings[slot]?.itemId;
        if (itemId && count > 0) {
            try { event.block.dimension.spawnItem(new ItemStack(itemId, count), location); }
            catch (error) {}
        }
        for (const site of pendingBySite.values()) {
            if (!site.pedestalKeys.has(key)) continue;
            failRitual(site);
            break;
        }
        return;
    }
    const ritualKind = stateNumber(permutation, RITUAL_KIND_STATE);
    const ritual = RITUALS[ritualKind];
    const stage = stateNumber(permutation, ALTAR_STAGE_STATE);
    const site = pendingBySite.get(key);
    if (site) {
        site.catalystActive = false;
        clearPending(site);
    }
    if (ritual && stage > 0) {
        try { event.block.dimension.spawnItem(new ItemStack(ritual.catalystId, 1), location); }
        catch (error) {}
    }
});

world.afterEvents.playerLeave.subscribe(event => {
    for (const key of lastInteraction.keys()) {
        if (key.startsWith(`${event.playerId}:`)) lastInteraction.delete(key);
    }
});
