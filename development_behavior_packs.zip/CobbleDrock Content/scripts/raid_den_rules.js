import { RAID_DEN_UPSTREAM_BOSS_POOLS } from "./raid_den_boss_data.js";

export const RAID_DEN_BLOCK_ID = "lota:raid_den_crystal";
export const RAID_DEN_TYPES = Object.freeze([
    "bug", "dark", "dragon", "electric", "fairy", "fighting",
    "fire", "flying", "ghost", "grass", "ground", "ice",
    "normal", "poison", "psychic", "rock", "steel", "water"
]);
export const RAID_DEN_SPAWN_RATE = 480;
export const RAID_DEN_RESET_TICKS = 7_200 * 20;
export const RAID_DEN_MAX_CLEARS = 3;
export const RAID_DEN_TIER_WEIGHTS = Object.freeze([10, 16, 20, 24, 22, 6, 2]);
export const RAID_DEN_MAX_PLAYERS = Object.freeze([0, 1, 2, 3, 4, 4, 4, 4]);

const entry = (species, raidType, moves = undefined) => Object.freeze({
    species,
    raidType,
    weight: 1,
    ...(moves ? { moves: Object.freeze(moves) } : {})
});

export const RAID_DEN_BOSS_POOLS = Object.freeze({
    1: RAID_DEN_UPSTREAM_BOSS_POOLS[1],
    2: RAID_DEN_UPSTREAM_BOSS_POOLS[2],
    3: RAID_DEN_UPSTREAM_BOSS_POOLS[3],
    4: RAID_DEN_UPSTREAM_BOSS_POOLS[4],
    5: RAID_DEN_UPSTREAM_BOSS_POOLS[5],
    6: Object.freeze([
        entry("dragonite", "dragon", ["outrage", "dragonrush", "aquatail", "slam"]),
        entry("salamence", "dragon", ["doubleedge", "flamethrower", "zenheadbutt", "dragonclaw"]),
        entry("garchomp", "dragon", ["takedown", "dig", "dragonclaw", "slash"]),
        entry("hydreigon", "dark", ["outrage", "dragonrush", "hypervoice", "bodyslam"]),
        entry("goodra", "dragon", ["powerwhip", "muddywater", "bodyslam", "dragonbreath"]),
        entry("haxorus", "dragon", ["gigaimpact", "outrage", "dragonpulse", "dualchop"]),
        entry("tyranitar", "rock", ["gigaimpact", "hyperbeam", "thrash", "stoneedge"]),
        entry("metagross", "steel", ["meteormash", "psychic", "takedown", "pursuit"])
    ]),
    7: Object.freeze([
        entry("articuno", "ice"),
        entry("zapdos", "electric"),
        entry("moltres", "fire"),
        entry("mewtwo", "psychic"),
        entry("lugia", "psychic"),
        entry("hooh", "fire"),
        entry("rayquaza", "dragon"),
        entry("xerneas", "fairy")
    ])
});

export function raidDenHash(...values) {
    let hash = 0x811c9dc5;
    for (const value of values) {
        let number = Math.trunc(Number(value) || 0);
        for (let byte = 0; byte < 4; byte++) {
            hash ^= number & 0xff;
            hash = Math.imul(hash, 0x01000193);
            number >>= 8;
        }
    }
    hash ^= hash >>> 16;
    hash = Math.imul(hash, 0x7feb352d);
    hash ^= hash >>> 15;
    hash = Math.imul(hash, 0x846ca68b);
    return (hash ^ (hash >>> 16)) >>> 0;
}

export function raidDenCycle(absoluteTime) {
    return Math.max(0, Math.floor((Number(absoluteTime) || 0) / RAID_DEN_RESET_TICKS));
}

export function raidDenTier(chunkX, chunkZ, worldSeed, cycle) {
    const total = RAID_DEN_TIER_WEIGHTS.reduce((sum, value) => sum + value, 0);
    let roll = raidDenHash(worldSeed, chunkX, chunkZ, cycle, 3) % total;
    for (let index = 0; index < RAID_DEN_TIER_WEIGHTS.length; index++) {
        roll -= RAID_DEN_TIER_WEIGHTS[index];
        if (roll < 0) return index + 1;
    }
    return 1;
}

export function raidDenBoss(chunkX, chunkZ, worldSeed, cycle, tier) {
    const pool = RAID_DEN_BOSS_POOLS[tier] || RAID_DEN_BOSS_POOLS[1];
    const totalWeight = pool.reduce((sum, boss) => sum + Math.max(1, Number(boss.weight) || 1), 0);
    let roll = raidDenHash(worldSeed, chunkX, chunkZ, cycle, 4) % totalWeight;
    for (const boss of pool) {
        roll -= Math.max(1, Number(boss.weight) || 1);
        if (roll < 0) return boss;
    }
    return pool[pool.length - 1];
}

export function raidDenProfile(state, worldSeed, cycle) {
    const tier = raidDenTier(state.chunkX, state.chunkZ, worldSeed, cycle);
    return { tier, boss: raidDenBoss(state.chunkX, state.chunkZ, worldSeed, cycle, tier) };
}

export function raidDenPropertyId(chunkX, chunkZ) {
    return `lota:raid_den:${chunkX}:${chunkZ}`;
}
