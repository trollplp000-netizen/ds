const JAVA_RANDOM_MULTIPLIER = 0x5deece66dn;
const JAVA_RANDOM_ADDEND = 0xbn;
const JAVA_RANDOM_MASK = (1n << 48n) - 1n;
const STRUCTURE_REGION_X_MULTIPLIER = 341873128712n;
const STRUCTURE_REGION_Z_MULTIPLIER = 132897987541n;

export const GYM_BATTLE_CAMERA_SIDE_SCALE = 1;

export const GYM_NATIVE_PLACEMENTS = Object.freeze([
    Object.freeze({ spacing: 40, separation: 19, salt: 1197, spreadType: "linear", biomeTags: Object.freeze(["plains", "meadow"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 2197, spreadType: "triangular", biomeTags: Object.freeze(["beach", "swamp", "mangrove_swamp"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 3017, spreadType: "linear", biomeTags: Object.freeze(["savanna"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 3517, spreadType: "linear", biomeTags: Object.freeze(["meadow", "taiga"]) }),
    Object.freeze({ spacing: 25, separation: 10, salt: 7137, spreadType: "linear", biomeTags: Object.freeze(["desert", "mesa"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 5217, spreadType: "linear", biomeTags: Object.freeze(["mesa", "savanna"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 4117, spreadType: "linear", biomeTags: Object.freeze(["flower_forest"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 6117, spreadType: "linear", biomeTags: Object.freeze(["meadow", "taiga"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 7217, spreadType: "linear", biomeTags: Object.freeze(["roofed", "swamp"]) }),
    Object.freeze({ spacing: 40, separation: 19, salt: 8457, spreadType: "linear", biomeTags: Object.freeze(["desert", "mesa"]) })
]);

export const GYM_BATTLE_LAYOUTS = Object.freeze([
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([5, 2, 9]), leaderMarker: Object.freeze([21, 2, 9]) }),
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([9, 3, 21]), leaderMarker: Object.freeze([9, 3, 5]) }),
    Object.freeze({ markerBlock: "minecraft:smooth_stone", playerMarker: Object.freeze([9, 2, 6]), leaderMarker: Object.freeze([9, 2, 20]), pokemonInsetBonus: 1 }),
    Object.freeze({ markerBlock: "minecraft:smooth_stone", playerMarker: Object.freeze([9, 1, 19]), leaderMarker: Object.freeze([9, 1, 7]) }),
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([5, 2, 9]), leaderMarker: Object.freeze([21, 2, 9]) }),
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([9, 2, 5]), leaderMarker: Object.freeze([9, 2, 21]) }),
    Object.freeze({ markerBlock: "minecraft:smooth_stone", playerMarker: Object.freeze([9, 1, 19]), leaderMarker: Object.freeze([9, 1, 7]) }),
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([20, 3, 9]), leaderMarker: Object.freeze([6, 3, 9]) }),
    Object.freeze({ markerBlock: "minecraft:smooth_stone", playerMarker: Object.freeze([20, 2, 9]), leaderMarker: Object.freeze([6, 2, 9]) }),
    Object.freeze({ markerBlock: "minecraft:polished_andesite", playerMarker: Object.freeze([10, 11, 19]), leaderMarker: Object.freeze([10, 11, 7]) })
]);

export function gymBattleLineLocations(leaderLocation, playerLocation, insetBonus = 0) {
    const dx = Number(leaderLocation?.x) - Number(playerLocation?.x);
    const dz = Number(leaderLocation?.z) - Number(playerLocation?.z);
    const distance = Math.hypot(dx, dz);
    if (![dx, dz, distance].every(Number.isFinite) || distance < 1) return undefined;
    const towardLeader = { x: dx / distance, z: dz / distance };
    const inset = Math.min(distance / 2 - 0.5, Math.min(4, distance * 0.28) + Math.max(0, Number(insetBonus) || 0));
    const heightDifference = Number(leaderLocation.y) - Number(playerLocation.y);
    const heightStep = Number.isFinite(heightDifference) ? heightDifference * inset / distance : 0;
    return {
        playerLocation: { ...playerLocation },
        playerPokemonLocation: {
            x: playerLocation.x + towardLeader.x * inset,
            y: playerLocation.y + heightStep,
            z: playerLocation.z + towardLeader.z * inset
        },
        opponentLocation: {
            x: leaderLocation.x - towardLeader.x * inset,
            y: leaderLocation.y - heightStep,
            z: leaderLocation.z - towardLeader.z * inset
        }
    };
}

function javaRandom(seed) {
    let state = (BigInt(seed) ^ JAVA_RANDOM_MULTIPLIER) & JAVA_RANDOM_MASK;
    const next = bits => {
        state = (state * JAVA_RANDOM_MULTIPLIER + JAVA_RANDOM_ADDEND) & JAVA_RANDOM_MASK;
        return Number(state >> (48n - BigInt(bits)));
    };
    return {
        nextInt(bound) {
            if (!Number.isInteger(bound) || bound <= 0) throw new RangeError("bound must be a positive integer");
            if ((bound & -bound) === bound) return Number((BigInt(bound) * BigInt(next(31))) >> 31n);
            while (true) {
                const bits = next(31);
                const value = bits % bound;
                if (bits - value + bound - 1 <= 0x7fffffff) return value;
            }
        }
    };
}

function spreadOffset(random, range, spreadType) {
    if (spreadType === "triangular") {
        return Math.floor((random.nextInt(range) + random.nextInt(range)) / 2);
    }
    return random.nextInt(range);
}

export function randomSpreadCandidate(worldSeed, regionX, regionZ, placement) {
    const spacing = Number(placement?.spacing);
    const separation = Number(placement?.separation);
    const range = spacing - separation;
    if (!Number.isInteger(spacing) || !Number.isInteger(separation) || range <= 0) {
        throw new RangeError("invalid random_spread spacing or separation");
    }
    const seed = BigInt(String(worldSeed))
        + BigInt(regionX) * STRUCTURE_REGION_X_MULTIPLIER
        + BigInt(regionZ) * STRUCTURE_REGION_Z_MULTIPLIER
        + BigInt(placement.salt);
    const random = javaRandom(seed);
    const chunkX = regionX * spacing + spreadOffset(random, range, placement.spreadType);
    const chunkZ = regionZ * spacing + spreadOffset(random, range, placement.spreadType);
    return {
        regionX,
        regionZ,
        chunkX,
        chunkZ,
        x: chunkX * 16,
        z: chunkZ * 16
    };
}

export function randomSpreadCandidatesNear(worldSeed, origin, placement, regionRadius = 16) {
    const spacing = Number(placement?.spacing);
    const radius = Math.max(0, Math.floor(Number(regionRadius) || 0));
    const originX = Number(origin?.x);
    const originZ = Number(origin?.z);
    if (![spacing, originX, originZ].every(Number.isFinite) || spacing <= 0) return [];
    const centerRegionX = Math.floor(originX / (spacing * 16));
    const centerRegionZ = Math.floor(originZ / (spacing * 16));
    const candidates = [];
    for (let regionX = centerRegionX - radius; regionX <= centerRegionX + radius; regionX++) {
        for (let regionZ = centerRegionZ - radius; regionZ <= centerRegionZ + radius; regionZ++) {
            const candidate = randomSpreadCandidate(worldSeed, regionX, regionZ, placement);
            const targetX = candidate.x + 8;
            const targetZ = candidate.z + 8;
            candidate.distanceSquared = (targetX - originX) ** 2 + (targetZ - originZ) ** 2;
            candidates.push(candidate);
        }
    }
    candidates.sort((first, second) => first.distanceSquared - second.distanceSquared
        || first.regionX - second.regionX
        || first.regionZ - second.regionZ);
    return candidates;
}

export function candidateBiomeMatchesStart(candidate, found, tolerance = 4) {
    const centerX = Number(candidate?.x) + 8;
    const centerZ = Number(candidate?.z) + 8;
    const foundX = Number(found?.x);
    const foundZ = Number(found?.z);
    const maximumOffset = Math.max(0, Number(tolerance) || 0);
    return [centerX, centerZ, foundX, foundZ].every(Number.isFinite)
        && Math.abs(foundX - centerX) <= maximumOffset
        && Math.abs(foundZ - centerZ) <= maximumOffset;
}
