import { EasingType, ItemStack, system, world } from "@minecraft/server";
import {
    requestCorePokemonSpawn,
    subscribeCorePokemonSpawnResult
} from "./core_bridge.js";

const PEDESTAL_ID = "lota:offering_pedestal";
const RITUAL_KIND_STATE = "lota:ritual_kind";
const OFFERING_STATE = "lota:offering";
const INTERACTION_DEBOUNCE_TICKS = 4;
const RITUAL_START_DELAY_TICKS = 20;
const REQUEST_TIMEOUT_TICKS = 200;
const REVEAL_HEIGHT = 46.5;
const PLAYER_REVEAL_OFFSET = Object.freeze({ x: 0.5, y: 45, z: 8.5 });
const CAMERA_OFFSET = Object.freeze({ x: 14.5, y: 7.8, z: 10.5 });
const CAMERA_SAFETY_TICKS = 80;

const RITUALS = Object.freeze({
    1: Object.freeze({
        id: "articuno",
        species: "articuno",
        itemId: "lota:glacier_feather",
        itemKey: "item.lota.glacier_feather",
        offeringState: 1,
        vfx: Object.freeze({
            rune: "lota:articuno_ritual_rune",
            motif: "lota:articuno_ritual_motif",
            detail: "lota:articuno_ritual_detail",
            core: "lota:articuno_ritual_core",
            beam: "lota:articuno_ritual_beam",
            halo: "lota:articuno_ritual_halo",
            shockwave: "lota:articuno_ritual_shockwave",
            accent: "minecraft:snowflake_particle"
        }),
        sealSound: "random.glass",
        chargeSound: "mob.evocation_illager.cast_spell",
        gateSound: "beacon.power",
        revealSound: "mob.evocation_illager.cast_spell",
        impactSound: "lota.cobblemon.impact.ice",
        successKey: "lota.message.offering.spawned.articuno"
    }),
    2: Object.freeze({
        id: "zapdos",
        species: "zapdos",
        itemId: "lota:thunder_feather",
        itemKey: "item.lota.thunder_feather",
        offeringState: 2,
        vfx: Object.freeze({
            rune: "lota:zapdos_ritual_rune",
            motif: "lota:zapdos_ritual_motif",
            detail: "lota:zapdos_ritual_detail",
            core: "lota:zapdos_ritual_core",
            beam: "lota:zapdos_ritual_beam",
            halo: "lota:zapdos_ritual_halo",
            shockwave: "lota:zapdos_ritual_shockwave",
            accent: "minecraft:electric_spark_particle"
        }),
        sealSound: "random.orb",
        chargeSound: "random.orb",
        gateSound: "ambient.weather.thunder",
        revealSound: "ambient.weather.thunder",
        impactSound: "lota.cobblemon.impact.electric",
        successKey: "lota.message.offering.spawned.zapdos"
    }),
    3: Object.freeze({
        id: "moltres",
        species: "moltres",
        itemId: "lota:ember_feather",
        itemKey: "item.lota.ember_feather",
        offeringState: 3,
        vfx: Object.freeze({
            rune: "lota:moltres_ritual_rune",
            motif: "lota:moltres_ritual_motif",
            detail: "lota:moltres_ritual_detail",
            core: "lota:moltres_ritual_core",
            beam: "lota:moltres_ritual_beam",
            halo: "lota:moltres_ritual_halo",
            shockwave: "lota:moltres_ritual_shockwave",
            accent: "minecraft:basic_flame_particle"
        }),
        sealSound: "fire.ignite",
        chargeSound: "fire.ignite",
        gateSound: "mob.blaze.shoot",
        revealSound: "fire.ignite",
        impactSound: "lota.cobblemon.impact.fire",
        successKey: "lota.message.offering.spawned.moltres"
    })
});

const OFFERING_ITEMS = Object.freeze({
    1: "lota:glacier_feather",
    2: "lota:thunder_feather",
    3: "lota:ember_feather"
});

const pendingBySite = new Map();
const pendingByRequest = new Map();
const lastInteraction = new Map();

function stateNumber(permutation, stateName) {
    return Math.max(0, Math.trunc(Number(permutation?.getState(stateName)) || 0));
}

function ritualFor(permutation) {
    return RITUALS[stateNumber(permutation, RITUAL_KIND_STATE)];
}

function siteKey(block) {
    const { x, y, z } = block.location;
    return `${block.dimension.id}:${x}:${y}:${z}`;
}

function translated(key) {
    return { translate: key };
}

function showActionbar(player, rawtext) {
    try { player.onScreenDisplay.setActionBar({ rawtext }); }
    catch (error) {}
}

function showItemStatus(player, prefixKey, ritual, suffixKey = undefined) {
    const rawtext = [translated(prefixKey), translated(ritual.itemKey)];
    if (suffixKey) rawtext.push(translated(suffixKey));
    showActionbar(player, rawtext);
}

function showKey(player, key) {
    showActionbar(player, [translated(key)]);
}

function heldSlot(player) {
    const container = player.getComponent("minecraft:inventory")?.container;
    const slot = Math.max(0, Math.trunc(Number(player.selectedSlotIndex) || 0));
    return { container, slot, stack: container?.getItem(slot) };
}

function consumeHeld(player, expectedItemId) {
    const { container, slot, stack } = heldSlot(player);
    if (!container || stack?.typeId !== expectedItemId) return false;
    if (stack.amount <= 1) container.setItem(slot, undefined);
    else {
        stack.amount -= 1;
        container.setItem(slot, stack);
    }
    return true;
}

function giveOrDrop(player, itemId, location = player.location) {
    const item = new ItemStack(itemId, 1);
    try {
        const remainder = player.getComponent("minecraft:inventory")?.container?.addItem(item);
        if (!remainder) return;
        player.dimension.spawnItem(remainder, location);
    } catch (error) {
        try { player.dimension.spawnItem(item, location); }
        catch (dropError) {}
    }
}

function setOffering(block, value) {
    block.setPermutation(block.permutation.withState(OFFERING_STATE, value));
}

function safeSound(dimension, soundId, location, options = undefined) {
    try { dimension.playSound(soundId, location, options); }
    catch (error) {}
}

function validPedestal(site, expectedOffering = undefined) {
    try {
        const block = site.dimension.getBlock(site.location);
        if (!block || block.typeId !== PEDESTAL_ID) return undefined;
        if (expectedOffering !== undefined
            && stateNumber(block.permutation, OFFERING_STATE) !== expectedOffering) return undefined;
        if (stateNumber(block.permutation, RITUAL_KIND_STATE) !== site.kind) return undefined;
        return block;
    } catch (error) {
        return undefined;
    }
}

function isPending(site) {
    return pendingBySite.get(site.key) === site;
}

function particle(site, effectId, location) {
    try { site.dimension.spawnParticle(effectId, location); }
    catch (error) {}
}

function ritualParticle(site, role, location) {
    particle(site, site.ritual.vfx[role], location);
}

function centerAt(site, height) {
    return {
        x: site.location.x + 0.5,
        y: site.location.y + height,
        z: site.location.z + 0.5
    };
}

function particleLine(site, effectId, from, to, count) {
    for (let index = 0; index <= count; index += 1) {
        const progress = index / count;
        particle(site, effectId, {
            x: from.x + (to.x - from.x) * progress,
            y: from.y + (to.y - from.y) * progress,
            z: from.z + (to.z - from.z) * progress
        });
    }
}

function particleCurve(site, effectId, count, pointAt) {
    for (let index = 0; index <= count; index += 1) {
        particle(site, effectId, pointAt(index / count, index));
    }
}

function articunoSealTrace(site, stage, center) {
    const reach = 2.8 + stage * 1.55;
    for (let ray = 0; ray < 6; ray += 1) {
        const angle = ray * Math.PI / 3 + stage * 0.018;
        const steps = 4 + stage * 2;
        for (let step = 1; step <= steps; step += 1) {
            const distance = reach * step / steps;
            ritualParticle(site, "detail", {
                x: center.x + Math.cos(angle) * distance,
                y: center.y + 0.025,
                z: center.z + Math.sin(angle) * distance
            });
        }
        ritualParticle(site, "motif", {
            x: center.x + Math.cos(angle) * reach,
            y: center.y + 0.14,
            z: center.z + Math.sin(angle) * reach
        });
    }
    const auroraRadius = 1.6 + stage * 0.55;
    particleCurve(site, site.ritual.vfx.detail, 12, progress => {
        const angle = progress * Math.PI * 2 + stage * 0.8;
        return {
            x: center.x + Math.cos(angle) * auroraRadius,
            y: center.y + 0.25 + progress * (0.6 + stage * 0.18),
            z: center.z + Math.sin(angle) * auroraRadius
        };
    });
}

function zapdosSealTrace(site, stage, center) {
    const angles = [0.12, 0.83, 1.71, 2.46, 3.36, 4.24, 5.31];
    for (let branch = 0; branch < angles.length; branch += 1) {
        const angle = angles[branch];
        const reach = 2.6 + stage * 1.58 + (branch % 3) * 0.22;
        const steps = 5 + stage * 2 + branch % 2;
        for (let step = 1; step <= steps; step += 1) {
            const progress = step / steps;
            const kink = Math.sin(step * 2.7 + branch * 1.4) * (0.15 + progress * 0.34);
            ritualParticle(site, "detail", {
                x: center.x + Math.cos(angle) * reach * progress - Math.sin(angle) * kink,
                y: center.y + (step % 2) * 0.05,
                z: center.z + Math.sin(angle) * reach * progress + Math.cos(angle) * kink
            });
        }
        if (branch % 2 === stage % 2) ritualParticle(site, "motif", {
            x: center.x + Math.cos(angle) * reach,
            y: center.y + 0.12,
            z: center.z + Math.sin(angle) * reach
        });
    }
}

function moltresSealTrace(site, stage, center) {
    for (let talon = 0; talon < 3; talon += 1) {
        const baseAngle = talon * Math.PI * 2 / 3 + stage * 0.11;
        const reach = 3 + stage * 1.5;
        particleCurve(site, site.ritual.vfx.detail, 10 + stage * 2, progress => {
            const angle = baseAngle + progress * (1.18 + talon * 0.07);
            const radius = 0.65 + reach * progress;
            return {
                x: center.x + Math.cos(angle) * radius,
                y: center.y + Math.sin(progress * Math.PI) * (0.18 + stage * 0.05),
                z: center.z + Math.sin(angle) * radius
            };
        });
        const tipAngle = baseAngle + 1.18 + talon * 0.07;
        ritualParticle(site, "motif", {
            x: center.x + Math.cos(tipAngle) * (reach + 0.65),
            y: center.y + 0.15,
            z: center.z + Math.sin(tipAngle) * (reach + 0.65)
        });
    }
}

function altarInscription(site, stage) {
    if (!isPending(site) || !validPedestal(site, site.ritual.offeringState)) return;
    const center = centerAt(site, 0.05);
    if (stage === 0) {
        ritualParticle(site, "rune", center);
        safeSound(site.dimension, site.ritual.sealSound, center, { volume: 1.05, pitch: 0.72 });
    }
    if (site.ritual.id === "articuno") articunoSealTrace(site, stage, center);
    else if (site.ritual.id === "zapdos") zapdosSealTrace(site, stage, center);
    else moltresSealTrace(site, stage, center);
    if (stage === 3) {
        ritualParticle(site, "shockwave", center);
        safeSound(site.dimension, "beacon.activate", center, { volume: 1.3, pitch: 0.58 });
    }
}

function ascentBeam(site, stage) {
    if (!isPending(site) || !validPedestal(site, site.ritual.offeringState)) return;
    const start = centerAt(site, 0.92);
    const focus = centerAt(site, REVEAL_HEIGHT);
    const fractions = [0.32, 0.58, 0.82, 1];
    const beamHeight = (focus.y - start.y) * fractions[stage];
    const segmentCount = Math.ceil(beamHeight / 2.15);
    for (let segment = 0; segment <= segmentCount; segment += 1) {
        const progress = segment / Math.max(1, segmentCount);
        const y = start.y + beamHeight * progress;
        const jitterAngle = segment * 2.17 + stage * 0.8;
        ritualParticle(site, "beam", {
            x: start.x + Math.cos(jitterAngle) * 0.055,
            y,
            z: start.z + Math.sin(jitterAngle) * 0.055
        });
        if (segment % 2 === stage % 2) {
            ritualParticle(site, "detail", {
                x: start.x + Math.cos(jitterAngle) * 0.34,
                y: y + 0.16,
                z: start.z + Math.sin(jitterAngle) * 0.34
            });
        }
    }
    const beamHead = { x: focus.x, y: start.y + beamHeight, z: focus.z };
    ritualParticle(site, "core", beamHead);
    for (let arc = 0; arc < 5; arc += 1) {
        const angle = arc * Math.PI * 2 / 5 + stage * 0.4;
        ritualParticle(site, arc % 2 ? "detail" : "motif", {
            x: beamHead.x + Math.cos(angle) * (0.45 + stage * 0.12),
            y: beamHead.y + (arc % 3 - 1) * 0.28,
            z: beamHead.z + Math.sin(angle) * (0.45 + stage * 0.12)
        });
    }
    safeSound(site.dimension, site.ritual.chargeSound, beamHead, {
        volume: 0.74 + stage * 0.14,
        pitch: 0.58 + stage * 0.12
    });
    if (stage === 3) {
        safeSound(site.dimension, "beacon.power", focus, { volume: 1.45, pitch: 0.72 });
    }
}

function openUpperGate(site) {
    if (!isPending(site) || !validPedestal(site, site.ritual.offeringState)) return;
    ascentBeam(site, 3);
    const focus = centerAt(site, REVEAL_HEIGHT);
    ritualParticle(site, "halo", focus);
    for (let pulse = 0; pulse < 3; pulse += 1) ritualParticle(site, "core", {
        x: focus.x + (pulse - 1) * 0.11,
        y: focus.y + pulse * 0.13,
        z: focus.z
    });
    for (let arc = 0; arc < 12; arc += 1) {
        const angle = arc * Math.PI * 2 / 12;
        ritualParticle(site, arc % 3 === 0 ? "motif" : "detail", {
            x: focus.x + Math.cos(angle) * 2.45,
            y: focus.y + Math.sin(angle) * 2.45,
            z: focus.z + (arc % 2 ? 0.08 : -0.08)
        });
    }
    safeSound(site.dimension, site.ritual.gateSound, focus, { volume: 1.55, pitch: 0.92 });
}

function passableBlock(block) {
    return !block || block.typeId === "minecraft:air"
        || block.typeId === "minecraft:cave_air"
        || block.typeId === "minecraft:void_air";
}

function upperGalleryDestination(site) {
    const blockLocation = {
        x: site.location.x,
        y: site.location.y + PLAYER_REVEAL_OFFSET.y,
        z: site.location.z + Math.floor(PLAYER_REVEAL_OFFSET.z)
    };
    try {
        const below = site.dimension.getBlock({ ...blockLocation, y: blockLocation.y - 1 });
        const feet = site.dimension.getBlock(blockLocation);
        const head = site.dimension.getBlock({ ...blockLocation, y: blockLocation.y + 1 });
        if (passableBlock(below) || !passableBlock(feet) || !passableBlock(head)) return undefined;
    } catch (error) {
        return undefined;
    }
    return {
        x: site.location.x + PLAYER_REVEAL_OFFSET.x,
        y: site.location.y + PLAYER_REVEAL_OFFSET.y,
        z: site.location.z + PLAYER_REVEAL_OFFSET.z
    };
}

function clearRitualCamera(site) {
    if (!site.cameraActive) return;
    site.cameraActive = false;
    try { if (site.player?.isValid) site.player.camera.clear(); }
    catch (error) {}
}

function setRitualCamera(site) {
    const player = site.player;
    if (!player?.isValid) return false;
    const focus = centerAt(site, 4.2);
    try {
        player.camera.setCamera("minecraft:free", {
            location: {
                x: site.location.x + CAMERA_OFFSET.x,
                y: site.location.y + CAMERA_OFFSET.y,
                z: site.location.z + CAMERA_OFFSET.z
            },
            facingLocation: focus,
            easeOptions: { easeTime: 0.35, easeType: EasingType.InOutSine }
        });
        site.cameraActive = true;
        system.runTimeout(() => clearRitualCamera(site), CAMERA_SAFETY_TICKS);
        return true;
    } catch (error) {
        return false;
    }
}

function teleportPlayerToUpperGallery(site) {
    if (!isPending(site) || !validPedestal(site, site.ritual.offeringState)) return;
    const player = site.player;
    const destination = upperGalleryDestination(site);
    if (!player?.isValid || player.dimension.id !== site.dimension.id || !destination) {
        failRitual(site);
        return;
    }
    const options = {
        dimension: site.dimension,
        keepVelocity: false,
        facingLocation: centerAt(site, REVEAL_HEIGHT)
    };
    let teleported = false;
    try {
        if (typeof player.tryTeleport === "function") {
            teleported = player.tryTeleport(destination, options) !== false;
        } else {
            player.teleport(destination, options);
            teleported = true;
        }
    } catch (error) {}
    if (!teleported) {
        failRitual(site);
        return;
    }
    clearRitualCamera(site);
    safeSound(site.dimension, "random.orb", destination, {
        volume: 1.1,
        pitch: 1.28
    });
}

function revealBurst(site) {
    const focus = centerAt(site, REVEAL_HEIGHT);
    ritualParticle(site, "halo", focus);
    ritualParticle(site, "halo", { x: focus.x, y: focus.y + 0.18, z: focus.z });
    for (let pulse = 0; pulse < 6; pulse += 1) ritualParticle(site, "core", {
        x: focus.x + (pulse % 3 - 1) * 0.12,
        y: focus.y + Math.floor(pulse / 3) * 0.16,
        z: focus.z + (pulse % 2 ? 0.1 : -0.1)
    });
    for (let ray = 0; ray < 24; ray += 1) {
        const yaw = Math.PI * 2 * ray / 24 + (ray % 4) * 0.055;
        const pitch = ((ray % 9) - 4) * 0.105;
        const length = 3.4 + (ray % 6) * 0.46;
        for (let step = 1; step <= 4; step += 1) {
            const progress = step / 4;
            ritualParticle(site, step === 4 && ray % 4 === 0 ? "motif" : "detail", {
                x: focus.x + Math.cos(yaw) * Math.cos(pitch) * length * progress,
                y: focus.y + Math.sin(pitch) * length * progress,
                z: focus.z + Math.sin(yaw) * Math.cos(pitch) * length * progress
            });
        }
        if (ray % 3 === 0) particle(site, site.ritual.vfx.accent, {
            x: focus.x + Math.cos(yaw) * length,
            y: focus.y + Math.sin(pitch) * length,
            z: focus.z + Math.sin(yaw) * length
        });
    }
    summonClimax(site, focus);
}

function summonClimax(site, focus) {
    safeSound(site.dimension, "random.explode", focus, { volume: 2.35, pitch: 0.56 });
    safeSound(site.dimension, "beacon.power", focus, { volume: 2, pitch: 0.5 });
    safeSound(site.dimension, site.ritual.impactSound, focus, { volume: 2.2, pitch: 0.72 });
    safeSound(site.dimension, site.ritual.revealSound, focus, { volume: 2.1, pitch: 0.88 });
    system.runTimeout(() => {
        safeSound(site.dimension, "beacon.activate", focus, { volume: 1.75, pitch: 0.62 });
        safeSound(site.dimension, site.ritual.impactSound, focus, { volume: 1.55, pitch: 1.04 });
    }, 3);
}

function clearPending(site) {
    clearRitualCamera(site);
    pendingBySite.delete(site.key);
    if (site.requestId) pendingByRequest.delete(site.requestId);
}

function refundSiteOffering(site) {
    if (!site.offeringActive) return;
    const block = validPedestal(site);
    if (block && stateNumber(block.permutation, OFFERING_STATE) === site.ritual.offeringState) {
        try { setOffering(block, 0); }
        catch (error) {}
    }
    const location = centerAt(site, 0.9);
    if (site.player?.isValid) giveOrDrop(site.player, site.ritual.itemId, location);
    else {
        try { site.dimension.spawnItem(new ItemStack(site.ritual.itemId, 1), location); }
        catch (error) {}
    }
    site.offeringActive = false;
}

function failRitual(site) {
    refundSiteOffering(site);
    clearPending(site);
    if (site.player?.isValid) showKey(site.player, "lota.message.offering.failed");
}

function requestSpawn(site) {
    if (!isPending(site)) return;
    const block = validPedestal(site, site.ritual.offeringState);
    const player = site.player;
    if (!block || !player?.isValid || player.dimension.id !== site.dimension.id) {
        failRitual(site);
        return;
    }
    const dx = player.location.x - (site.location.x + 0.5);
    const dy = player.location.y - (site.location.y + 0.5);
    const dz = player.location.z - (site.location.z + 0.5);
    if ((dx * dx + dy * dy + dz * dz) > 80 * 80) {
        failRitual(site);
        return;
    }
    try { setOffering(block, 0); }
    catch (error) {
        failRitual(site);
        return;
    }
    const requestId = requestCorePokemonSpawn(player, {
        species: site.ritual.species,
        level: 50,
        location: {
            x: site.location.x + 0.5,
            y: site.location.y + REVEAL_HEIGHT,
            z: site.location.z + 0.5
        },
        duplicateRadius: 64,
        minPerfectIvs: 3,
        aspects: ["legendary"]
    });
    if (!requestId) {
        failRitual(site);
        return;
    }
    site.requestId = requestId;
    pendingByRequest.set(requestId, site);
    system.runTimeout(() => {
        if (pendingByRequest.get(requestId) === site) failRitual(site);
    }, REQUEST_TIMEOUT_TICKS);
}

function beginRitual(site) {
    if (!isPending(site)) return;
    const block = validPedestal(site, site.ritual.offeringState);
    const player = site.player;
    if (!block || !player?.isValid || player.dimension.id !== site.dimension.id) {
        failRitual(site);
        return;
    }
    showKey(player, "lota.message.offering.started");
    try {
        player.onScreenDisplay.setTitle(translated("lota.message.offering.start_title"), {
            subtitle: translated("lota.message.offering.start_subtitle"),
            fadeInDuration: 4,
            stayDuration: 26,
            fadeOutDuration: 10
        });
    } catch (error) {}
    safeSound(block.dimension, "beacon.activate", block.center(), { volume: 1.15, pitch: 0.55 });
    safeSound(block.dimension, "random.orb", block.center(), { volume: 0.85, pitch: 0.42 });
    setRitualCamera(site);
    for (let stage = 0; stage < 4; stage += 1) {
        system.runTimeout(() => altarInscription(site, stage), stage * 5);
        system.runTimeout(() => ascentBeam(site, stage), 10 + stage * 8);
    }
    system.runTimeout(() => openUpperGate(site), 39);
    system.runTimeout(() => teleportPlayerToUpperGallery(site), 46);
    system.runTimeout(() => openUpperGate(site), 50);
    system.runTimeout(() => openUpperGate(site), 56);
    system.runTimeout(() => requestSpawn(site), 62);
}

function startRitual(player, block, ritual) {
    const key = siteKey(block);
    if (pendingBySite.has(key)) {
        showKey(player, "lota.message.offering.busy");
        return;
    }
    const site = {
        key,
        kind: stateNumber(block.permutation, RITUAL_KIND_STATE),
        ritual,
        player,
        dimension: block.dimension,
        location: { ...block.location },
        requestId: undefined,
        offeringActive: true,
        cameraActive: false
    };
    pendingBySite.set(key, site);
    system.runTimeout(() => beginRitual(site), RITUAL_START_DELAY_TICKS);
}

function interactWithPedestal({ block, player }) {
    if (!block || block.typeId !== PEDESTAL_ID || !player?.isValid) return;
    const ritual = ritualFor(block.permutation);
    if (!ritual) {
        showKey(player, "lota.message.offering.unlinked");
        return;
    }
    const key = siteKey(block);
    const debounceKey = `${player.id}:${key}`;
    const previousTick = lastInteraction.get(debounceKey) ?? -100;
    if (system.currentTick - previousTick < INTERACTION_DEBOUNCE_TICKS) return;
    lastInteraction.set(debounceKey, system.currentTick);
    if (pendingBySite.has(key)) {
        showKey(player, "lota.message.offering.busy");
        return;
    }

    const offering = stateNumber(block.permutation, OFFERING_STATE);
    const { stack } = heldSlot(player);
    if (offering === 0) {
        if (stack?.typeId !== ritual.itemId) {
            showItemStatus(
                player,
                stack ? "lota.message.offering.wrong" : "lota.message.offering.required",
                ritual,
                stack ? undefined : "lota.message.offering.place_hint"
            );
            return;
        }
        if (!consumeHeld(player, ritual.itemId)) return;
        try { setOffering(block, ritual.offeringState); }
        catch (error) {
            giveOrDrop(player, ritual.itemId, block.center());
            return;
        }
        safeSound(block.dimension, "random.orb", block.center(), { volume: 0.8, pitch: 1.35 });
        showItemStatus(player, "lota.message.offering.placed", ritual);
        startRitual(player, block, ritual);
        return;
    }

    if (offering !== ritual.offeringState) {
        showItemStatus(player, "lota.message.offering.wrong", ritual);
        return;
    }
    if (player.isSneaking) {
        try { setOffering(block, 0); }
        catch (error) { return; }
        giveOrDrop(player, ritual.itemId, block.center());
        safeSound(block.dimension, "random.pop", block.center(), { volume: 0.65, pitch: 1.2 });
        showKey(player, "lota.message.offering.retrieved");
        return;
    }
    if (stack) {
        showKey(player, "lota.message.offering.occupied");
        return;
    }
    startRitual(player, block, ritual);
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(
        "lota:offering_pedestal_component",
        { onPlayerInteract: interactWithPedestal }
    );
});

subscribeCorePokemonSpawnResult(result => {
    const requestId = String(result?.requestId || "");
    const site = pendingByRequest.get(requestId);
    if (!site) return;
    if (result.outcome !== "spawned") {
        failRitual(site);
        return;
    }
    site.offeringActive = false;
    clearPending(site);
    const block = validPedestal(site);
    if (block && stateNumber(block.permutation, OFFERING_STATE) !== 0) {
        try { setOffering(block, 0); }
        catch (error) {}
    }
    revealBurst(site);
    if (site.player?.isValid) showKey(site.player, site.ritual.successKey);
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    const permutation = event.brokenBlockPermutation;
    if (permutation.type.id !== PEDESTAL_ID) return;
    const offering = stateNumber(permutation, OFFERING_STATE);
    let itemId = OFFERING_ITEMS[offering];
    const key = `${event.block.dimension.id}:${event.block.location.x}:${event.block.location.y}:${event.block.location.z}`;
    const pending = pendingBySite.get(key);
    if (pending) {
        if (!itemId && pending.offeringActive) itemId = pending.ritual.itemId;
        pending.offeringActive = false;
        clearPending(pending);
    }
    if (!itemId) return;
    try {
        event.block.dimension.spawnItem(new ItemStack(itemId, 1), {
            x: event.block.location.x + 0.5,
            y: event.block.location.y + 0.75,
            z: event.block.location.z + 0.5
        });
    } catch (error) {}
});

world.afterEvents.playerLeave.subscribe(event => {
    for (const key of lastInteraction.keys()) {
        if (key.startsWith(`${event.playerId}:`)) lastInteraction.delete(key);
    }
});
