import { system, world, EntityComponentTypes } from "@minecraft/server";
import { requestCorePokemonSpawn } from "./core_bridge.js";
import { fossilMachineKey } from "./fossil_core_adapter.js";

const MONITOR_ID = "fm:monitor";
const UPGRADE_ITEM_ID = "lota:upgrade";
const STAGE_STATE = "fm:up_stage";

const STAGE_IDLE = 0;
const STAGE_SCANNING = 1;
const STAGE_DONE = 2;

const SCAN_DURATION_TICKS = 36 * 2;

const PORYGON2_CHANCE = 0.2;
const SPAWN_LEVEL = 15;

const FACING_OFFSETS = {
    north: { x: 0, z: -1 },
    south: { x: 0, z: 1 },
    east: { x: 1, z: 0 },
    west: { x: -1, z: 0 }
};

function isLinkedToFossilMachine(block) {
    try {
        const key = fossilMachineKey("monitor_", block.dimension, block.location);
        return world.getDynamicProperty(key) != null;
    } catch (error) {
        return false;
    }
}

function stageOf(block) {
    try { return Number(block.permutation.getState(STAGE_STATE)) || 0; }
    catch (error) { return 0; }
}

function discStageOf(block) {
    try { return Number(block.permutation.getState("fm:disc_stage")) || 0; }
    catch (error) { return 0; }
}

function setStage(block, stage) {
    try { block.setPermutation(block.permutation.withState(STAGE_STATE, stage)); }
    catch (error) {}
}

function frontOffsetFromPlayer(block, player) {
    const centerX = block.location.x + 0.5;
    const centerZ = block.location.z + 0.5;
    const dx = player.location.x - centerX;
    const dz = player.location.z - centerZ;
    if (Math.abs(dx) < 0.001 && Math.abs(dz) < 0.001) return FACING_OFFSETS.south;
    return Math.abs(dx) >= Math.abs(dz)
        ? { x: dx > 0 ? 1 : -1, z: 0 }
        : { x: 0, z: dz > 0 ? 1 : -1 };
}

function spawnLocationFromOffset(block, offset) {
    const loc = block.location;
    return { x: loc.x + offset.x + 0.5, y: loc.y, z: loc.z + offset.z + 0.5 };
}

function stopMonitorSound(dimension, soundId) {
    try { dimension.runCommand(`stopsound @a ${soundId}`); } catch (error) {}
}

function finishUpgrade(dimensionId, location, offset) {
    let dimension;
    try { dimension = world.getDimension(dimensionId); }
    catch (error) { return; }
    const block = dimension.getBlock(location);
    if (!block?.isValid || block.typeId !== MONITOR_ID) return;
    if (stageOf(block) !== STAGE_SCANNING) return;

    const spawnLocation = spawnLocationFromOffset(block, offset || FACING_OFFSETS.south);
    const species = Math.random() < PORYGON2_CHANCE ? "porygon2" : "porygon";

    const player = block.dimension.getPlayers({ location: spawnLocation, maxDistance: 24 })[0];
    if (player) {
        requestCorePokemonSpawn(player, {
            species,
            level: SPAWN_LEVEL,
            location: spawnLocation,
            duplicateRadius: 0
        });
    }

    stopMonitorSound(block.dimension, "fm:monitor_upgrade_loop");
    stopMonitorSound(block.dimension, "fm:monitor_upgrade_insert");
    try { block.dimension.playSound("fm:monitor_porygon_spawn", block.location); } catch (error) {}
    setStage(block, STAGE_DONE);
}

function consumeUpgradeItem(player) {
    try {
        const container = player.getComponent(EntityComponentTypes.Inventory)?.container;
        const item = container?.getItem(player.selectedSlotIndex);
        if (!item || item.typeId !== UPGRADE_ITEM_ID) return false;
        if (item.amount <= 1) container.setItem(player.selectedSlotIndex, undefined);
        else {
            item.amount -= 1;
            container.setItem(player.selectedSlotIndex, item);
        }
        return true;
    } catch (error) {
        return false;
    }
}

function onPlayerInteract(event) {
    const block = event.block;
    const player = event.player;
    if (!block || block.typeId !== MONITOR_ID || !player) return;
    if (stageOf(block) !== STAGE_IDLE) return;
    if (discStageOf(block) !== 0) return;
    if (isLinkedToFossilMachine(block)) return;
    if (!consumeUpgradeItem(player)) return;

    setStage(block, STAGE_SCANNING);
    try { block.dimension.playSound("fm:monitor_upgrade_insert", block.location); } catch (error) {}
    try { block.dimension.playSound("fm:monitor_upgrade_loop", block.location); } catch (error) {}

    const dimensionId = block.dimension.id;
    const location = { x: block.location.x, y: block.location.y, z: block.location.z };
    const offset = frontOffsetFromPlayer(block, player);
    system.runTimeout(() => finishUpgrade(dimensionId, location, offset), SCAN_DURATION_TICKS);
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(MONITOR_ID + "_upgrade", {
        onPlayerInteract
    });
});
