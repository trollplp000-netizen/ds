import { world, system, BlockPermutation, ItemStack } from "@minecraft/server"
import { requestCorePokemonGrant, subscribeCorePokemonGrantResult } from './core_bridge.js'
import { isFossilBall, returnFossilItem } from './fossil_core_adapter.js'

const eggSpawn = [
    10, 13, 16, 19, 21, 23, 25, 27, 29, 32, 37, 43, 46, 48, 50, 52, 54, 56, 69, 74,
    98, 104, 109, 114, 118, 113, 137, 161, 163, 165, 167, 170, 172, 173, 174, 175,
    177, 179, 187, 191, 194, 206, 209, 211, 213, 222, 223, 228, 236, 238, 239, 240,
    261, 263, 270, 273, 276, 278, 283, 290, 293, 298, 313, 314, 325, 327, 339, 341,
    352, 353, 360, 363, 366, 370, 396, 399, 401, 406, 420, 433, 438, 439, 440,
    441, 446, 447, 451, 456, 458, 459, 504, 506, 509, 519, 522, 524, 540, 546, 548,
    595, 602, 613, 616, 661, 664, 677, 682, 684, 702, 710, 712, 731, 734, 742, 751,
    753, 755, 757, 759, 848,
]

const EGG_DEX_TO_SPECIES = {
    10: 'caterpie', 13: 'weedle', 16: 'pidgey', 19: 'rattata', 21: 'spearow',
    23: 'ekans', 25: 'pikachu', 27: 'sandshrew', 29: 'nidoranf', 32: 'nidoranm',
    37: 'vulpix', 43: 'oddish', 46: 'paras', 48: 'venonat', 50: 'diglett',
    52: 'meowth', 54: 'psyduck', 56: 'mankey', 69: 'bellsprout', 74: 'geodude',
    98: 'krabby', 104: 'cubone', 109: 'koffing', 114: 'tangela', 118: 'goldeen',
    113: 'chansey', 137: 'porygon', 161: 'sentret', 163: 'hoothoot', 165: 'ledyba',
    167: 'spinarak', 170: 'chinchou', 172: 'pichu', 173: 'cleffa', 174: 'igglybuff',
    175: 'togepi', 177: 'natu', 179: 'mareep', 187: 'hoppip', 191: 'sunkern',
    194: 'wooper', 206: 'dunsparce', 209: 'snubbull', 211: 'qwilfish', 213: 'shuckle',
    222: 'corsola', 223: 'remoraid', 228: 'houndour', 236: 'tyrogue', 238: 'smoochum',
    239: 'elekid', 240: 'magby', 261: 'poochyena', 263: 'zigzagoon', 270: 'lotad',
    273: 'seedot', 276: 'taillow', 278: 'wingull', 283: 'surskit', 290: 'nincada',
    293: 'whismur', 298: 'azurill', 313: 'volbeat', 314: 'illumise', 325: 'spoink',
    327: 'spinda', 339: 'barboach', 341: 'corphish', 352: 'kecleon',
    353: 'shuppet', 360: 'wynaut', 363: 'spheal', 366: 'clamperl', 370: 'luvdisc',
    396: 'starly', 399: 'bidoof', 401: 'kricketot', 406: 'budew', 420: 'cherubi',
    433: 'chingling', 438: 'bonsly', 439: 'mimejr', 440: 'happiny', 441: 'chatot',
    446: 'munchlax', 447: 'riolu', 451: 'skorupi', 456: 'finneon', 458: 'mantyke',
    459: 'snover', 504: 'patrat', 506: 'lillipup', 509: 'purrloin', 519: 'pidove',
    522: 'blitzle', 524: 'roggenrola', 540: 'sewaddle', 546: 'cottonee', 548: 'petilil',
    595: 'joltik', 602: 'tynamo', 613: 'cubchoo', 616: 'shelmet', 661: 'fletchling',
    664: 'scatterbug', 677: 'espurr', 682: 'spritzee', 684: 'swirlix', 702: 'dedenne',
    710: 'pumpkaboo', 712: 'bergmite', 731: 'pikipek', 734: 'yungoos', 742: 'cutiefly',
    751: 'dewpider', 753: 'fomantis', 755: 'morelull', 757: 'salandit', 759: 'stufful',
    848: 'toxel',
}

const EGG_HATCH_LEVEL = 5
const pendingClaims = new Set()
const pendingGrants = new Map()

world.afterEvents.playerPlaceBlock.subscribe(({ block, player }) => {
    if (!ehIncubadora(block.typeId)) return
    const view = player.getViewDirection()
    let facing
    if (Math.abs(view.x) > Math.abs(view.z)) {
        facing = view.x > 0 ? 'north' : 'south'
    } else {
        facing = view.z > 0 ? 'west' : 'east'
    }
    block.setPermutation(BlockPermutation.resolve(block.typeId, { 'lk:facing': facing }))
})


const incubadoraConfig = {
    'lk:incubadora': { nome: 'incubadora básica', totalTicks: 3600 },
}
function ehIncubadora(typeId) {
    return typeId in incubadoraConfig
}

function posKeyIncubadora(dimension, loc) {
    const dimensionKey = dimension.id === 'minecraft:overworld' ? 'o'
        : dimension.id === 'minecraft:nether' ? 'n' : 'e'
    return `lk:incubadora_${dimensionKey}_${Math.floor(loc.x)}_${Math.floor(loc.y)}_${Math.floor(loc.z)}`
}

function eggIdDeBreedingDoItem(itemStack) {
    if (!itemStack) return undefined
    let lore
    try { lore = itemStack.getLore() } catch { return undefined }
    if (!lore || lore.length < 2) return undefined
    const id = parseInt(lore[1], 10)
    return Number.isFinite(id) ? id : undefined
}

function dadosOvoBreedingDoItem(itemStack) {
    if (!itemStack) return null
    let lore
    try { lore = itemStack.getLore() } catch { return null }
    if (!lore || lore.length < 5) return null

    let linhaJson = lore[lore.length - 1]
    const idx = linhaJson.indexOf('{')
    if (idx === -1) return null
    linhaJson = linhaJson.slice(idx)

    try {
        const dados = JSON.parse(linhaJson)
        if (dados && Number.isFinite(dados.species)) return dados
        return null
    } catch { return null }
}

function criarItemOvoDevolucao(key) {
    const item = new ItemStack('hiro:pokemon_egg', 1)
    try {
        const nome = world.getDynamicProperty(`${key}_nome`)
        if (nome) item.nameTag = nome
    } catch { }
    try {
        const loreRaw = world.getDynamicProperty(`${key}_lore`)
        if (loreRaw) {
            const lore = JSON.parse(loreRaw)
            if (Array.isArray(lore) && lore.length > 0) item.setLore(lore)
        }
    } catch { }
    return item
}

function limparDadosIncubadora(key) {
    world.setDynamicProperty(key, undefined)
    world.setDynamicProperty(`${key}_especie`, undefined)
    world.setDynamicProperty(`${key}_pronto`, undefined)
    world.setDynamicProperty(`${key}_owner`, undefined)
    world.setDynamicProperty(`${key}_nome`, undefined)
    world.setDynamicProperty(`${key}_lore`, undefined)
}


function nomeTickingArea(key) {
    return key.replace(/[^A-Za-z0-9_]/g, '_')
}

function adicionarTickingArea(dimension, loc, key) {
    const x = Math.floor(loc.x), y = Math.floor(loc.y), z = Math.floor(loc.z)
    try {
        dimension.runCommand(`tickingarea add ${x} ${y} ${z} ${x} ${y} ${z} ${nomeTickingArea(key)}`)
    } catch { }
}

function removerTickingArea(dimension, key) {
    try {
        dimension.runCommand(`tickingarea remove ${nomeTickingArea(key)}`)
    } catch { }
}

function carregarIncubadorasAtivas() {
    const raw = world.getDynamicProperty('lk:incubadoras_ativas')
    if (!raw) return {}
    try { return JSON.parse(raw) } catch { return {} }
}

function salvarIncubadorasAtivas(mapa) {
    world.setDynamicProperty('lk:incubadoras_ativas', JSON.stringify(mapa))
}

function registrarIncubadoraAtiva(dimension, loc, key, typeId) {
    const mapa = carregarIncubadorasAtivas()
    mapa[key] = { x: loc.x, y: loc.y, z: loc.z, typeId, dimensionId: dimension.id }
    salvarIncubadorasAtivas(mapa)
    adicionarTickingArea(dimension, loc, key)
}

function removerIncubadoraAtiva(dimension, key) {
    const mapa = carregarIncubadorasAtivas()
    if (key in mapa) {
        delete mapa[key]
        salvarIncubadorasAtivas(mapa)
    }
    removerTickingArea(dimension, key)
}

function jogadorPerto(dimension, loc, raio = 24) {
    for (const p of world.getAllPlayers()) {
        if (p.dimension.id !== dimension.id) continue
        const d = Math.hypot(p.location.x - loc.x, p.location.y - loc.y, p.location.z - loc.z)
        if (d <= raio) return p
    }
    return null
}

const lastWarnTick = new Map()
function avisarPrecisaIncubadora(player) {
    const agora = system.currentTick
    const ultimo = lastWarnTick.get(player.id) ?? -999
    if (agora - ultimo < 40) return
    lastWarnTick.set(player.id, agora)
    player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.need_incubator' })
}

function getOvoDisplay(dimension, key) {
    return dimension.getEntities({ type: 'lk:incubadora_egg_display' }).find(e => e.getDynamicProperty('lk:posKey') === key)
}

function removerOvoDisplay(dimension, key) {
    const ovo = getOvoDisplay(dimension, key)
    if (ovo) ovo.triggerEvent('lk:instant_death')
}

function atualizarEstadoOvo(dimension, key, totalElapsedTicks, totalTicksDoTipo) {
    const ovo = getOvoDisplay(dimension, key)
    if (!ovo) return
    const metade = totalTicksDoTipo / 2
    let estagio = 0
    if (totalElapsedTicks >= totalTicksDoTipo) estagio = 2
    else if (totalElapsedTicks >= metade) estagio = 1
    if (ovo.getProperty('lk:egg_stage') !== estagio) {
        ovo.setProperty('lk:egg_stage', estagio)
    }
    const faltam = totalTicksDoTipo - totalElapsedTicks
    const pertoDeChocar = faltam <= 1200
    if (ovo.getProperty('lk:egg_near_hatch') !== pertoDeChocar) {
        ovo.setProperty('lk:egg_near_hatch', pertoDeChocar)
    }
}

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, itemStack, block } = event
    if (itemStack?.typeId !== 'hiro:pokemon_egg') return
    if (!ehIncubadora(block.typeId)) {
        system.run(() => avisarPrecisaIncubadora(player))
        return
    }
    event.cancel = true
    system.run(() => {
        if (!ehIncubadora(block.typeId) || block.permutation.getState('lk:loaded')) return
        const inventory = player.getComponent('minecraft:inventory')?.container
        const slot = player.selectedSlotIndex
        const egg = inventory?.getItem(slot)
        if (egg?.typeId !== 'hiro:pokemon_egg') return
        if (eggIdDeBreedingDoItem(egg) !== undefined || dadosOvoBreedingDoItem(egg)) {
            player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.breeding_unavailable' })
            return
        }
        const key = posKeyIncubadora(block.dimension, block.location)
        let display
        try {
            display = block.dimension.spawnEntity('lk:incubadora_egg_display', {
                x: block.location.x + 0.5, y: block.location.y, z: block.location.z + 0.5
            })
            const facingParaYaw = { north: 90, south: 270, east: 180, west: 0 }
            display.setRotation({ x: 0, y: facingParaYaw[block.permutation.getState('lk:facing')] ?? 0 })
            display.setDynamicProperty('lk:posKey', key)
            world.setDynamicProperty(key, 0)
            world.setDynamicProperty(`${key}_owner`, player.name)
            world.setDynamicProperty(`${key}_nome`, egg.nameTag ?? '')
            world.setDynamicProperty(`${key}_lore`, JSON.stringify(egg.getLore() ?? []))
            world.setDynamicProperty(`${key}_especie`, undefined)
            world.setDynamicProperty(`${key}_pronto`, undefined)
            block.setPermutation(block.permutation.withState('lk:loaded', true).withState('lk:pronto', false))
            registrarIncubadoraAtiva(block.dimension, block.location, key, block.typeId)
            if (egg.amount === 1) inventory.setItem(slot, undefined)
            else { egg.amount -= 1; inventory.setItem(slot, egg) }
        } catch (error) {
            try { display?.remove() } catch { }
            try { block.setPermutation(block.permutation.withState('lk:loaded', false).withState('lk:pronto', false)) } catch { }
            limparDadosIncubadora(key)
            removerIncubadoraAtiva(block.dimension, key)
            console.warn(`[CobbleDrockContent] Incubator insertion failed: ${error}`)
        }
    })
})

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { block } = event
    if (!ehIncubadora(block.typeId)) return

    event.cancel = true
    const dimension = block.dimension
    const location = { x: block.location.x, y: block.location.y, z: block.location.z }
    const tipoIncubadora = block.typeId
    const estavaCarregada = block.permutation.getState('lk:loaded')
    const key = posKeyIncubadora(dimension, location)
    if (pendingClaims.has(key)) {
        system.run(() => event.player?.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.collecting' }))
        return
    }

    system.run(() => {
        if (estavaCarregada) {
            removerOvoDisplay(dimension, key)
            const itemDevolvido = criarItemOvoDevolucao(key)
            limparDadosIncubadora(key)
            dimension.spawnItem(itemDevolvido, {
                x: location.x + 0.5, y: location.y + 0.5, z: location.z + 0.5
            })
        }
        removerIncubadoraAtiva(dimension, key)

        block.setPermutation(BlockPermutation.resolve('minecraft:air'))

        const itemIncubadora = new ItemStack(tipoIncubadora, 1)
        dimension.spawnItem(itemIncubadora, {
            x: location.x + 0.5, y: location.y + 0.5, z: location.z + 0.5
        })
    })
})

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { player, itemStack, block } = event
    if (!ehIncubadora(block.typeId)) return
    if (!itemStack || !isFossilBall(itemStack.typeId)) return

    const key = posKeyIncubadora(block.dimension, block.location)
    if (!block.permutation.getState('lk:loaded') || world.getDynamicProperty(`${key}_pronto`) !== true) return

    event.cancel = true

    const dono = world.getDynamicProperty(`${key}_owner`)
    if (dono && dono !== player.name) {
        system.run(() => {
            player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.owner_only', with: [dono] })
        })
        return
    }

    const especie = world.getDynamicProperty(`${key}_especie`)
    const ballTypeId = itemStack.typeId

    system.run(() => {
        if (pendingClaims.has(key) || !ehIncubadora(block.typeId)
            || !block.permutation.getState('lk:loaded')
            || world.getDynamicProperty(`${key}_pronto`) !== true) return
        const species = EGG_DEX_TO_SPECIES[especie]
        if (!species) {
            player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.species_unavailable' })
            return
        }
        const inv = player.getComponent('minecraft:inventory')?.container
        const slot = player.selectedSlotIndex
        const ball = inv?.getItem(slot)
        if (ball?.typeId !== ballTypeId) return
        const reservedBall = new ItemStack(ballTypeId, 1)
        if (ball.amount === 1) inv.setItem(slot, undefined)
        else { ball.amount -= 1; inv.setItem(slot, ball) }
        pendingClaims.add(key)
        const requestId = requestCorePokemonGrant(player, {
            species, level: EGG_HATCH_LEVEL, caughtBall: ballTypeId.split(':')[1], minPerfectIvs: 0
        })
        if (!requestId) {
            pendingClaims.delete(key)
            returnFossilItem(player, reservedBall)
            player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.grant_failed' })
            return
        }
        pendingGrants.set(requestId, { player, block, key, reservedBall })
    })
})

subscribeCorePokemonGrantResult(result => {
    const transaction = pendingGrants.get(result.requestId)
    if (!transaction || String(result.playerId) !== String(transaction.player.id)) return
    pendingGrants.delete(result.requestId)
    const { player, block, key, reservedBall } = transaction
    try {
        if (result.outcome !== 'granted') {
            if (player.isValid) {
                returnFossilItem(player, reservedBall)
                player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.grant_failed' })
            } else block.dimension.spawnItem(reservedBall, block.location)
            return
        }
        try {
            if (ehIncubadora(block.typeId)) {
                block.setPermutation(block.permutation.withState('lk:loaded', false).withState('lk:pronto', false))
            }
        } catch { }
        limparDadosIncubadora(key)
        try { removerOvoDisplay(block.dimension, key) } catch { }
        try { block.dimension.playSound('fm:fossil_machine_retrieve_pokemon', block.location) } catch { }
        if (player.isValid) player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.received' })
    } finally {
        pendingClaims.delete(key)
    }
})

system.runInterval(() => {
    const mapa = carregarIncubadorasAtivas()
    let mudou = false

    for (const key in mapa) {
        const info = mapa[key]
        let dimension
        try {
            dimension = world.getDimension(info.dimensionId)
        } catch {
            continue
        }

        const loc = { x: info.x, y: info.y, z: info.z }
        const b = dimension.getBlock(loc)

        if (!b) continue
        if (!ehIncubadora(b.typeId) || !b.permutation.getState('lk:loaded')) {
            delete mapa[key]
            mudou = true
            removerTickingArea(dimension, key)
            continue
        }

        const totalTicks = incubadoraConfig[b.typeId].totalTicks

        let ticks = world.getDynamicProperty(key) ?? 0
        ticks += 20

        atualizarEstadoOvo(b.dimension, key, ticks, totalTicks)

        if (ticks < totalTicks) {
            world.setDynamicProperty(key, ticks)
            continue
        }

        if (world.getDynamicProperty(`${key}_pronto`) !== true) {
            let especie = world.getDynamicProperty(`${key}_especie`)
            if (especie === undefined || especie === null) {
                const select = Math.floor(Math.random() * eggSpawn.length)
                especie = eggSpawn[select]
                world.setDynamicProperty(`${key}_especie`, especie)
            }
            world.setDynamicProperty(`${key}_pronto`, true)
            b.setPermutation(b.permutation.withState('lk:pronto', true))

            const ovo = getOvoDisplay(b.dimension, key)
            if (ovo) ovo.nameTag = ''

            const player = jogadorPerto(b.dimension, b.location)
            if (player) player.onScreenDisplay.setActionBar({ translate: 'message.cobbledrock.egg.ready' })
        }

        world.setDynamicProperty(key, 0)
        delete mapa[key]
        mudou = true
        removerTickingArea(b.dimension, key)
    }

    if (mudou) salvarIncubadorasAtivas(mapa)
}, 20)
