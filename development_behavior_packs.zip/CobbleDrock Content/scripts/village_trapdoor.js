import { ItemStack, system, world } from "@minecraft/server";

const TRAPDOOR_ITEMS = Object.freeze([
    "minecraft:acacia_trapdoor",
    "minecraft:bamboo_trapdoor",
    "minecraft:birch_trapdoor",
    "minecraft:cherry_trapdoor",
    "minecraft:dark_oak_trapdoor",
    "minecraft:iron_trapdoor",
    "minecraft:jungle_trapdoor",
    "minecraft:mangrove_trapdoor",
    "minecraft:oxidized_copper_trapdoor",
    "minecraft:spruce_trapdoor",
    "minecraft:trapdoor",
    "minecraft:warped_trapdoor",
    "minecraft:waxed_copper_trapdoor",
    "minecraft:waxed_exposed_copper_trapdoor"
]);

const TRAPDOOR_SOUNDS = Object.freeze([
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.bamboo_wood_trapdoor", "close.bamboo_wood_trapdoor"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.cherry_wood_trapdoor", "close.cherry_wood_trapdoor"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.iron_trapdoor", "close.iron_trapdoor"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open_trapdoor.copper", "open_trapdoor.copper"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.wooden_trapdoor", "close.wooden_trapdoor"],
    ["open.nether_wood_trapdoor", "close.nether_wood_trapdoor"],
    ["open_trapdoor.copper", "open_trapdoor.copper"],
    ["open_trapdoor.copper", "open_trapdoor.copper"]
]);

function trapdoorKind(permutation) {
    return Math.max(0, Math.min(
        TRAPDOOR_ITEMS.length - 1,
        Math.trunc(Number(permutation?.getState("lota:trapdoor_kind")) || 0)
    ));
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent(
        "lota:village_trapdoor_component",
        {
            onPlayerInteract({ block, dimension }) {
                try {
                    if (!block || block.typeId !== "lota:village_trapdoor") return;
                    const kind = trapdoorKind(block.permutation);
                    if (kind === 5) return;
                    const open = block.permutation.getState("lota:open") === true;
                    block.setPermutation(block.permutation.withState("lota:open", !open));
                    const sound = TRAPDOOR_SOUNDS[kind][open ? 1 : 0];
                    dimension.playSound(sound, block.center());
                } catch (error) {
                    console.warn(`[CobbleDrockVillage] Trapdoor toggle failed: ${error}`);
                }
            }
        }
    );
    blockComponentRegistry.registerCustomComponent(
        "lota:village_iron_trapdoor_tick_component",
        {
            onTick({ block, dimension }) {
                try {
                    if (!block || block.typeId !== "lota:village_trapdoor") return;
                    if (trapdoorKind(block.permutation) !== 5) return;
                    const powered = Number(block.getRedstonePower?.() || 0) > 0;
                    const armed = block.permutation.getState("lota:redstone_armed") === true;
                    const open = block.permutation.getState("lota:open") === true;

                    if (!powered && !armed) return;
                    if (powered === armed && powered === open) return;
                    const nextOpen = powered;
                    let next = block.permutation.withState("lota:redstone_armed", powered);
                    if (nextOpen !== open) {
                        next = next.withState("lota:open", nextOpen);
                        dimension.playSound(
                            nextOpen ? "open.iron_trapdoor" : "close.iron_trapdoor",
                            block.center()
                        );
                    }
                    block.setPermutation(next);
                } catch (error) {
                    console.warn(`[CobbleDrockVillage] Iron trapdoor redstone update failed: ${error}`);
                }
            }
        }
    );
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    const permutation = event.brokenBlockPermutation;
    if (permutation.type.id !== "lota:village_trapdoor") return;
    let creative = false;
    try {
        creative = String(event.player?.getGameMode?.() || "").toLowerCase().includes("creative");
    } catch (error) {}
    if (creative) return;

    const itemId = TRAPDOOR_ITEMS[trapdoorKind(permutation)];
    try {
        event.block.dimension.spawnItem(new ItemStack(itemId, 1), {
            x: event.block.location.x + 0.5,
            y: event.block.location.y + 0.5,
            z: event.block.location.z + 0.5
        });
    } catch (error) {
        console.warn(`[CobbleDrockVillage] Trapdoor drop failed: ${error}`);
    }
});
