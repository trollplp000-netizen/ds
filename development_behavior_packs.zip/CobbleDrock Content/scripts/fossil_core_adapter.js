import { ItemStack, world } from "@minecraft/server";
import { requestCorePokemonGrant, subscribeCorePokemonGrantResult } from "./core_bridge.js";

const SPECIES = Object.freeze({
    138: "omanyte", 140: "kabuto", 142: "aerodactyl", 345: "lileep",
    347: "anorith", 408: "cranidos", 410: "shieldon", 564: "tirtouga",
    566: "archen", 696: "tyrunt", 698: "amaura", 880: "dracozolt",
    881: "arctozolt", 882: "dracovish", 883: "arctovish", 649: "genesect",
    150: "mewtwo", 132: "ditto", 772: "typenull"
});
const pending = new Map();
const tankClaims = new Set();

export function fossilMachineKey(prefix, dimension, location) {
    return `cobbledrock:fm:v1:${dimension.id}:${prefix}:${location.x},${location.y},${location.z}`;
}

export function returnFossilItem(player, item) {
    const inventory = player.getComponent("minecraft:inventory")?.container;
    const remainder = inventory?.addItem(item) ?? (inventory ? undefined : item);
    if (remainder) player.dimension.spawnItem(remainder, player.location);
}

export function isFossilBall(identifier) {
    return /^lota:(poke|great|ultra|master|beast|cherish|dive|dream|dusk|fast|friend|heal|heavy|level|love|lure|luxury|moon|nest|net|park|premier|quick|repeat|safari|sport|strange|timer)_ball$/.test(identifier ?? "");
}

export function collectFossilPokemon(event, data) {
    const { block, player, dimension } = event;
    if (!data.pokemon || !SPECIES[data.pokemon]) return;
    const parts = block.getParts();
    const keys = parts.map(part => fossilMachineKey("tank_", dimension, part.location));
    if (keys.some(key => tankClaims.has(key))) return;
    const inventory = player.getComponent("minecraft:inventory")?.container;
    const slot = player.selectedSlotIndex;
    const ball = inventory?.getItem(slot);
    if (!isFossilBall(ball?.typeId)) return;
    const reserved = new ItemStack(ball.typeId, 1);
    if (ball.amount === 1) inventory.setItem(slot, undefined);
    else { ball.amount -= 1; inventory.setItem(slot, ball); }
    for (const key of keys) tankClaims.add(key);
    const requestId = requestCorePokemonGrant(player, {
        species: SPECIES[data.pokemon], level: 15,
        caughtBall: reserved.typeId.split(":")[1], minPerfectIvs: 0
    });
    if (!requestId) {
        for (const key of keys) tankClaims.delete(key);
        returnFossilItem(player, reserved);
        return;
    }
    pending.set(requestId, { player, reserved, parts, keys, dimension });
}

subscribeCorePokemonGrantResult(result => {
    const transaction = pending.get(result.requestId);
    if (!transaction || String(result.playerId) !== String(transaction.player.id)) return;
    pending.delete(result.requestId);
    const { player, reserved, parts, keys, dimension } = transaction;
    try {
        if (result.outcome !== "granted") {
            if (player.isValid) {
                returnFossilItem(player, reserved);
                player.sendMessage({ translate: "message.cobbledrock.fossil.grant_failed" });
            } else dimension.spawnItem(reserved, parts[0].location);
            return;
        }
        for (let index = 0; index < parts.length; index++) {
            const part = parts[index];
            world.setDynamicProperty(keys[index], undefined);
            if (part.typeId === "fm:restoration_tank") {
                part.setPermutation(part.permutation.withState("fm:organic_level", 0));
            }
        }
        for (const entity of dimension.getEntities({ type: "fm:fossil_fetu_display" })) {
            if (keys.includes(entity.nameTag)) entity.remove();
        }
        dimension.playSound("fm:fossil_machine_retrieve_pokemon", parts[0].location);
    } finally { for (const key of keys) tankClaims.delete(key); }
});

export function showFossilMonitor(player, token) {
    if (token === "fm.ui.monitorX") return;
    let text;
    if (token.startsWith("fm.ui.monitor_on")) {
        text = { translate: "message.cobbledrock.fossil.monitor_running", with: [token.split("§z")[1] ?? ""] };
    } else text = { translate: token === "fm.ui.monitor_finish"
        ? "message.cobbledrock.fossil.monitor_ready" : "message.cobbledrock.fossil.monitor_idle" };
    player.onScreenDisplay.setActionBar(text);
}
