export const SCRIPT_EVENT_MESSAGE_LIMIT = 2048;
export const TRAINER_REQUEST_CHUNK_SIZE = 1200;
export const TRAINER_REQUEST_MAX_CHUNKS = 32;

export function trainerRequestMessages(request) {
    const serialized = JSON.stringify(request);
    const total = Math.max(1, Math.ceil(serialized.length / TRAINER_REQUEST_CHUNK_SIZE));
    if (total > TRAINER_REQUEST_MAX_CHUNKS) {
        throw new Error(`Trainer request requires ${total} ScriptEvent chunks.`);
    }

    const requestId = String(request?.requestId || "");
    const playerId = String(request?.playerId || "");
    const messages = [];
    for (let index = 0; index < total; index++) {
        const message = JSON.stringify({
            version: Number(request?.version),
            requestId,
            playerId,
            index,
            total,
            data: serialized.slice(
                index * TRAINER_REQUEST_CHUNK_SIZE,
                (index + 1) * TRAINER_REQUEST_CHUNK_SIZE
            )
        });
        if (message.length > SCRIPT_EVENT_MESSAGE_LIMIT) {
            throw new Error(`Trainer request chunk is ${message.length} characters.`);
        }
        messages.push(message);
    }
    return messages;
}
