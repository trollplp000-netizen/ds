import { ItemStack, world } from "@minecraft/server";
import { megaSiteHarvest } from "./mega_acquisition_rules.js";

function enchantmentLevel(tool, id) {
    try { return tool?.getComponent("minecraft:enchantable")?.getEnchantment(id)?.level || 0; }
    catch { return 0; }
}

world.afterEvents.playerBreakBlock.subscribe(event => {
    const player = event.player;
    if (String(player.getGameMode()).toLowerCase() === "creative") return;
    const tool = event.itemStackBeforeBreak;
    const result = megaSiteHarvest(event.brokenBlockPermutation?.type?.id, tool?.typeId, {
        silkTouch: enchantmentLevel(tool, "silk_touch"),
        fortune: enchantmentLevel(tool, "fortune")
    });
    if (!result) return;
    const { x, y, z } = event.block.location;
    try {
        player.dimension.spawnItem(new ItemStack(result.item, result.amount), { x: x + 0.5, y: y + 0.25, z: z + 0.5 });
        if (result.experience) player.addExperience(result.experience);
        if (result.hint) player.sendMessage({ translate: result.hint });
    } catch (error) {
        console.warn(`[Mega acquisition] Could not deliver ${result.item}: ${error}`);
    }
});
