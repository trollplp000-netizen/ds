export const VILLAGE_TYPES = Object.freeze([
    { id: "default_small", theme: "default", size: "small", weight: 6 },
    { id: "default_mid", theme: "default", size: "mid", weight: 4 },
    { id: "default_large", theme: "default", size: "large", weight: 2 },
    { id: "dark_small", theme: "dark", size: "small", weight: 6 },
    { id: "dark_mid", theme: "dark", size: "mid", weight: 4 },
    { id: "fighting_small", theme: "fighting", size: "small", weight: 6 },
    { id: "fighting_mid", theme: "fighting", size: "mid", weight: 4 },
    { id: "fighting_large", theme: "fighting", size: "large", weight: 2 }
]);

export const VILLAGE_CENTERS = Object.freeze({
    default: Object.freeze({
        small: ["default/centers/center_small_battlepad_road"],
        mid: [
            "default/centers/center_battlepad",
            "default/centers/center_the_lodge_path",
            "default/centers/center_the_academy"
        ],
        large: ["default/centers/center_department_store"]
    }),
    dark: Object.freeze({
        small: ["dark/centers/center_village_road_dark"],
        mid: [
            "dark/centers/center_the_farmers_market_dark",
            "dark/centers/center_the_marshlight_tavern"
        ]
    }),
    fighting: Object.freeze({
        small: [
            "fighting/centers/center_small_village_fighting",
            "fighting/centers/center_village_road_fighting"
        ],
        mid: [
            "fighting/centers/center_the_farmers_market_fighting",
            "fighting/centers/center_small_village_fighting"
        ],
        large: ["fighting/centers/center-wyrms-rest"]
    })
});

export const VILLAGE_HOUSES = Object.freeze({
    default: Object.freeze([
        "default/structures/berrybush_bungalow",
        "default/structures/blossom_balcony",
        "default/structures/fern_and_flower_cottage",
        "default/structures/honeycomb_haven_apiary",
        "default/structures/mossy_meadow_home",
        "default/structures/oakstone_hearth",
        "default/structures/pebble_roof_manor",
        "default/structures/ravenspire_manor",
        "default/structures/snug_spruce_retreat",
        "default/structures/sunflower_shack",
        "default/structures/terracreek_haven",
        "default/structures/the_chimney_loft",
        "default/structures/the_clover_cottage",
        "default/structures/the_cozy_cranny",
        "default/structures/the_ivyclad_cottage",
        "default/structures/the_lanturn_lodge",
        "default/structures/the_miners_den",
        "default/structures/the_summer_cottage",
        "default/structures/winding_willow_house"
    ]),
    dark: Object.freeze([
        "dark/structures/dark_frogs_hollow",
        "dark/structures/dark_hollows_nest",
        "dark/structures/dark_spruce_retreat",
        "dark/structures/miners_deep",
        "dark/structures/ravenspire_manor",
        "dark/structures/terror_creek_haven",
        "dark/structures/the_chimney_loft_dark",
        "dark/structures/the_ginning_widow",
        "dark/structures/the_wyrm_and_the_wisp"
    ]),
    fighting: Object.freeze([
        "fighting/structures/berrybush_bungalow",
        "fighting/structures/runebrick_roost",
        "fighting/structures/snug_spruce_retreat-plains",
        "fighting/structures/stonethread_dwelling",
        "fighting/structures/terracreek_haven-plains",
        "fighting/structures/the_chimney_loft-plains",
        "fighting/structures/the_daisy_barrow-plains",
        "fighting/structures/the_miners_den-plains",
        "fighting/structures/the_moonlight_hollow_retreat",
        "fighting/structures/the_oak_and_thistle_cottage",
        "fighting/structures/the_summer_cottage-plains",
        "fighting/structures/thistlewood_nook"
    ])
});

export const VILLAGE_ONE_OFFS = Object.freeze({
    default: Object.freeze([
        "default/one_off/pokecenter",
        "default/one_off/structure_pokemart",
        "default/one_off/small_battlepad",
        "default/one_off/the_lodge"
    ]),
    dark: Object.freeze([
        "dark/one_off/one_off_haunted_church",
        "dark/one_off/one_off_small_battlepad_dark",
        "dark/one_off/one_off_the_crypt"
    ]),
    fighting: Object.freeze([
        "fighting/one_off/one_off_small_battlepad_fighting"
    ])
});

export const VILLAGE_LAYOUTS = Object.freeze({
    small: Object.freeze([
        [-36, -36], [10, -36], [-36, 10], [10, 10]
    ]),
    mid: Object.freeze([
        [-58, -58], [-14, -58], [30, -58],
        [-58, -14], [30, -14],
        [-58, 30], [-14, 30], [30, 30]
    ]),
    large: Object.freeze([
        [-78, -78], [-34, -78], [10, -78], [54, -78],
        [-78, -34], [54, -34],
        [-78, 10], [54, 10],
        [-78, 54], [-34, 54], [10, 54], [54, 54]
    ])
});
