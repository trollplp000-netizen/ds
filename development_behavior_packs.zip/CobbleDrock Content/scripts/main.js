import "./cobbleverse_villages.js";
import "./summoning_rites.js";
import "./offering_pedestal.js";
import "./village_trapdoor.js";
import "./gym_system.js";
import "./mega_acquisition.js";
import "./raid_dens.js";
import "./raid_rewards.js";

import "./fossil_machine_core.js";
import "./fossil_dig_system.js";
import "./egg_journey.js";
import "./monitor_upgrade.js";
import "./monitor_dubious_disc.js";
