import { fossilMachineKey, isFossilBall, collectFossilPokemon, returnFossilItem, showFossilMonitor } from "./fossil_core_adapter.js";

import { world, system, EntityComponentTypes, ItemStack, CommandPermissionLevel, CustomCommandParamType } from "@minecraft/server";

import { ACCEPT_ITEMS, ORGANIC_ITEMS, POKEMON_FETU, RECIPEBOOK, getRecipeResult } from "./fossil_config.js";

function fossilRecipes(machineValue1) {
    const machineValue2 = machineValue1?.filter(machineValue3 => null != machineValue3 || null != machineValue3).map(machineValue4 => machineValue4.split(":")[1]);
    if (0 == machineValue2.length) return null;
    const machineValue5 = machineValue2.sort().join(",");
    return getRecipeResult(machineValue5) || null;
}

function fm_findNearbyBlocks(dim, cx, cy, cz, radius, typeId) {
    const found = [];
    for (let dx = -radius; dx <= radius; dx++) for (let dy = -radius; dy <= radius; dy++) for (let dz = -radius; dz <= radius; dz++) {
        let block;
        try {
            block = dim.getBlock({
                x: cx + dx,
                y: cy + dy,
                z: cz + dz
            });
        } catch (e) {
            continue;
        }
        block && block.typeId === typeId && found.push(block);
    }
    return found;
}

function fm_unlockBlock(block) {
    try {
        if (!block.permutation.getState("fm:locked")) return block.setPermutation(block.permutation.withState("fm:locked", !0)),
        !0;
    } catch (e) {}
    return !1;
}

function fm_stopActiveSound(dimension) {
    for (const player of dimension.getPlayers()) {
        try {
            player.runCommand("stopsound @s fm:fossil_machine_active_loop");
        } catch (error) {
            console.warn(`[CobbleDrock] Could not stop fossil machine sound: ${error}`);
        }
    }
}

function fm_linkNear(dim, cx, cy, cz, radius) {
    let touched = 0, analyzersFound = 0, tanksFound = 0;
    for (const block of fm_findNearbyBlocks(dim, cx, cy, cz, radius, "fm:fossil_analyzer")) analyzersFound++,
    fm_unlockBlock(block) && touched++;
    for (const block of fm_findNearbyBlocks(dim, cx, cy, cz, radius, "fm:restoration_tank")) {
        tanksFound++;
        let parts = [ block ];
        try {
            "function" == typeof block.getParts && (parts = block.getParts());
        } catch (e) {}
        for (const part of parts) fm_unlockBlock(part) && touched++;
    }
    return {
        touched: touched,
        analyzersFound: analyzersFound,
        tanksFound: tanksFound
    };
}

system.beforeEvents.startup.subscribe(machineValue6 => {
    const machineValue7 = "fm:fossil_fetu_display", machineValue8 = "fm:fossil_analyzer_displayitem", machineValue9 = "fm:fossil_machine_active_loop", machineValue10 = {
        name: "minutes"
    };
    machineValue10.type = CustomCommandParamType.Integer;
    const machineValue11 = {
        name: "fm:fossiltime",
        description: "Altera o tempo necessário para a Máquina de Fósseis reviver um fóssil"
    };
    machineValue11.permissionLevel = CommandPermissionLevel.GameDirectors, machineValue11.mandatoryParameters = [ machineValue10 ],
    machineValue6.customCommandRegistry.registerCommand(machineValue11, ({sourceEntity: machineValue12}, machineValue13) => {
        {
            const machineValue14 = 1200 * machineValue13;
            world.setDynamicProperty("fossiltime", machineValue14), machineValue12 && system.run(() => {
                machineValue12.runCommand('tellraw @s {"rawtext":[{"text":"Tempo de duração da máquina foi definido para §e' + machineValue13 + 'm§a"}]}');
            });
        }
    }), machineValue6.blockComponentRegistry.registerCustomComponent(machineValue8, {
        onBreak: machineValue15 => {
            var machineValue16;
            {
                const machineValue17 = machineValue15.block.location, machineValue18 = fossilMachineKey("fossil_", machineValue15.block.dimension, {
                    x: machineValue17.x,
                    y: machineValue17.y,
                    z: machineValue17.z
                }), machineValue19 = {};
                machineValue19.type = machineValue8;
                const machineValue20 = machineValue15.dimension.getEntities(machineValue19).find(machineValue21 => machineValue21.nameTag == machineValue18);
                if (!machineValue20) return;
                const machineValue22 = new ItemStack(machineValue20.getDynamicProperty("itemEquipped"));
                if (machineValue20.dimension.spawnItem(machineValue22, {
                    x: machineValue17.x + .5,
                    y: machineValue17.y,
                    z: machineValue17.z + .5
                }), machineValue20.getDynamicProperty("itemEquipped2")) {
                    const machineValue23 = new ItemStack(machineValue20.getDynamicProperty("itemEquipped2"));
                    machineValue20.dimension.spawnItem(machineValue23, {
                        x: machineValue17.x + .5,
                        y: machineValue17.y,
                        z: (machineValue16 = machineValue17.z, machineValue16 + .5)
                    });
                }
                machineValue20.remove();
            }
        },
        onPlayerInteract: machineValue24 => {
            {
                const machineValue25 = machineValue24.block.permutation.getState("fm:locked");
                if (machineValue24.block.permutation.getState("fm:scanning") || !machineValue25) return;
                const machineValue26 = machineValue24.block?.above();
                if (2 == machineValue26.permutation.getState("fm:stats")) return;
                const machineValue27 = machineValue24.block.location, machineValue28 = fossilMachineKey("fossil_", machineValue24.block.dimension, {
                    x: machineValue27.x,
                    y: machineValue27.y,
                    z: machineValue27.z
                }), machineValue29 = {};
                machineValue29.type = machineValue8;
                let machineValue30 = machineValue24.dimension.getEntities(machineValue29).find(machineValue31 => machineValue31.nameTag == machineValue28);
                const machineValue32 = machineValue24.player.getComponent(EntityComponentTypes.Inventory).container, machineValue33 = machineValue32.getItem(machineValue24.player.selectedSlotIndex);
                if (!machineValue30?.getDynamicProperty("itemEquipped") && ACCEPT_ITEMS.includes(machineValue33?.typeId.split(":")[1])) {
                    if (1 == machineValue33.amount ? machineValue32.setItem(machineValue24.player.selectedSlotIndex, void 0) : (machineValue33.amount -= 1,
                    machineValue32.setItem(machineValue24.player.selectedSlotIndex, machineValue33)),
                    !machineValue30) {
                        const machineValue34 = machineValue24.dimension.spawnEntity(machineValue8, {
                            x: machineValue27.x + .5,
                            y: machineValue27.y,
                            z: machineValue27.z + .5
                        });
                        machineValue34.nameTag = machineValue28, machineValue30 = machineValue34;
                    }
                    machineValue24.dimension.playSound("fm:fossil_machine_insert", machineValue27),
                    machineValue30.setDynamicProperty("itemEquipped", machineValue33?.typeId), machineValue30.runCommand("replaceitem entity @s slot.weapon.mainhand 0 " + machineValue33?.typeId);
                } else if (machineValue30?.getDynamicProperty("itemEquipped") && !machineValue30?.getDynamicProperty("itemEquipped2") && ACCEPT_ITEMS.includes(machineValue33?.typeId.split(":")[1])) 1 == machineValue33.amount ? machineValue32.setItem(machineValue24.player.selectedSlotIndex, void 0) : (machineValue33.amount -= 1,
                machineValue32.setItem(machineValue24.player.selectedSlotIndex, machineValue33)),
                machineValue24.dimension.playSound("fm:fossil_machine_insert", machineValue27),
                machineValue30.setDynamicProperty("itemEquipped2", machineValue33?.typeId), machineValue30.runCommand("replaceitem entity @s slot.weapon.offhand 0 " + machineValue33?.typeId); else {
                    if (!machineValue30) return;
                    if (machineValue24.dimension.playSound("fm:fossil_machine_retrieve", machineValue27),
                    machineValue30?.getDynamicProperty("itemEquipped2")) {
                        const machineValue35 = new ItemStack(machineValue30.getDynamicProperty("itemEquipped2"));
                        machineValue30.runCommand("replaceitem entity @s slot.weapon.offhand 0 minecraft:air"),
                        machineValue30.setDynamicProperty("itemEquipped2", void 0), returnFossilItem(machineValue24.player, machineValue35);
                    } else {
                        const machineValue36 = new ItemStack(machineValue30?.getDynamicProperty("itemEquipped"));
                        machineValue30.runCommand("replaceitem entity @s slot.weapon.mainhand 0 minecraft:air"),
                        machineValue30.setDynamicProperty("itemEquipped", void 0), returnFossilItem(machineValue24.player, machineValue36),
                        machineValue30.remove();
                    }
                }
            }
        }
    }), machineValue6.blockComponentRegistry.registerCustomComponent("fm:restoration_tank", {
        onPlayerInteract: machineValue37 => {
            {
                if (!machineValue37.block.permutation.getState("fm:locked")) return;
                const machineValue39 = machineValue37.block.location, machineValue40 = fossilMachineKey("tank_", machineValue37.block.dimension, {
                    x: machineValue39.x,
                    y: machineValue39.y,
                    z: machineValue39.z
                }), machineValue41 = JSON.parse(world.getDynamicProperty(machineValue40) ?? '{ "level": 1, "pokemon": null }'), machineValue42 = machineValue37.player.getComponent(EntityComponentTypes.Inventory).container, machineValue43 = machineValue42.getItem(machineValue37.player.selectedSlotIndex);
                if (isFossilBall(machineValue43?.typeId)) return void collectFossilPokemon(machineValue37, machineValue41);
                if (ORGANIC_ITEMS.includes(machineValue43?.typeId.split(":")[1])) {
                    const machineValue44 = machineValue37.block.getParts();
                    let machineValue45 = machineValue37.block.permutation.getState("fm:organic_level");
                    if (8 != machineValue45) {
                        let machineValue46 = 1;
                        const machineValue47 = machineValue43?.typeId.split(":")[1];
                        "max_revive" === machineValue47 ? machineValue46 = 32 : "revive" === machineValue47 ? machineValue46 = 16 : machineValue47.includes("coral") && (machineValue46 = 8),
                        1 == machineValue43.amount ? machineValue42.setItem(machineValue37.player.selectedSlotIndex, void 0) : (machineValue43.amount -= 1,
                        machineValue42.setItem(machineValue37.player.selectedSlotIndex, machineValue43)),
                        machineValue37.dimension.playSound("fm:fossil_machine_filling", machineValue39),
                        machineValue41.level += machineValue46, machineValue41.level > 64 && (machineValue41.level = 64),
                        machineValue41.level >= 64 && machineValue37.dimension.playSound("fm:fossil_machine_full", machineValue39);
                        const machineValue48 = Math.min(8, Math.floor(machineValue41.level / 8));
                        machineValue44.forEach(machineValue49 => {
                            {
                                const machineValue50 = machineValue49.permutation;
                                machineValue48 !== machineValue45 && machineValue49.setPermutation(machineValue50.withState("fm:organic_level", machineValue48));
                                const machineValue51 = machineValue49.location, machineValue52 = fossilMachineKey("tank_", machineValue49.dimension, {
                                    x: machineValue51.x,
                                    y: machineValue51.y,
                                    z: machineValue51.z
                                });
                                world.setDynamicProperty(machineValue52, JSON.stringify(machineValue41));
                            }
                        });
                    }
                }
            }
        },
        onBreak: machineValue55 => {
            {
                const machineValue56 = machineValue55.block.location, machineValue57 = fossilMachineKey("fossil_", machineValue55.block.dimension, {
                    x: machineValue56.x,
                    y: machineValue56.y,
                    z: machineValue56.z
                }), machineValue58 = {};
                machineValue58.type = machineValue7;
                const machineValue59 = machineValue55.dimension.getEntities(machineValue58).find(machineValue60 => machineValue60.nameTag == machineValue57);
                machineValue59 && machineValue59.remove();
                const machineValue61 = machineValue55.brokenBlockPermutation.getState("minecraft:multi_block_part");
                world.setDynamicProperty(fossilMachineKey("tank_", machineValue55.block.dimension, {
                    x: machineValue56.x,
                    y: machineValue56.y,
                    z: machineValue56.z
                }), void 0), world.setDynamicProperty(fossilMachineKey("tank_", machineValue55.block.dimension, {
                    x: machineValue56.x,
                    y: machineValue56.y + (1 == machineValue61 ? -1 : 1),
                    z: machineValue56.z
                }), void 0);
            }
        }
    }), machineValue6.blockComponentRegistry.registerCustomComponent("fm:monitor", {
        onTick: machineValue62 => {
            {
                const machineValue63 = machineValue62.block, machineValue64 = fossilMachineKey("monitor_", machineValue63.dimension, {
                    x: machineValue63.location.x,
                    y: machineValue63.location.y,
                    z: machineValue63.location.z
                }), machineValue65 = world.getDynamicProperty(machineValue64), machineValue66 = machineValue65 ? JSON.parse(machineValue65) : null, machineValue67 = machineValue63.permutation.getState("minecraft:facing_direction");
                if (!machineValue66) {
                    const machineValue68 = {
                        north: [ machineValue63?.west(), machineValue63?.east() ],
                        south: [ machineValue63?.east(), machineValue63?.west() ],
                        east: [ machineValue63?.north(), machineValue63?.south() ],
                        west: [ machineValue63?.south(), machineValue63?.north() ]
                    }, machineValue69 = machineValue68[machineValue67]?.find(machineValue70 => "fm:restoration_tank" == machineValue70.typeId && machineValue70.permutation.getState("minecraft:cardinal_direction") == machineValue67 && 1 == machineValue70.permutation.getState("minecraft:multi_block_part")), machineValue71 = machineValue63?.below();
                    if (!machineValue69 || !machineValue71) return;
                    if ("fm:fossil_analyzer" != machineValue71?.typeId) return;
                    if (machineValue71?.permutation.getState("minecraft:facing_direction") != machineValue67) return;
                    machineValue63.dimension.playSound("fm:fossil_machine_assemble", machineValue63.location);
                    const machineValue72 = {};
                    return machineValue72.restoration_tank = machineValue69.location, machineValue72.fossil_analyzer = machineValue71.location,
                    machineValue72.time = 1, machineValue72.pokemon = null, void world.setDynamicProperty(machineValue64, JSON.stringify(machineValue72));
                }
                const machineValue73 = machineValue63.dimension.getBlock(machineValue66.restoration_tank), machineValue74 = machineValue63.dimension.getBlock(machineValue66.fossil_analyzer);
                if (!machineValue73 || !machineValue74 || "fm:restoration_tank" != machineValue73.typeId || "fm:fossil_analyzer" != machineValue74.typeId) {
                    world.setDynamicProperty(machineValue64, void 0), machineValue63.setPermutation(machineValue63.permutation.withState("fm:stats", 0)),
                    machineValue63.setPermutation(machineValue63.permutation.withState("fm:progress", 0)),
                    machineValue63.dimension.playSound("fm:fossil_machine_unprotected", machineValue63.location),
                    fm_stopActiveSound(machineValue63.dimension);
                    try {
                        {
                            const machineValue75 = fossilMachineKey("tank_", machineValue73.dimension, {
                                x: machineValue73.location.x,
                                y: machineValue73.location.y,
                                z: machineValue73.location.z
                            }), machineValue76 = {
                                type: "fm:fossil_fetu_display"
                            }, machineValue77 = machineValue62.dimension.getEntities(machineValue76).find(machineValue78 => machineValue78.nameTag == machineValue75);
                            machineValue77 && machineValue77.remove(), machineValue73?.getParts()?.forEach(machineValue79 => {
                                {
                                    machineValue79.setPermutation(machineValue79.permutation.withState("fm:locked", !1)),
                                    machineValue79.setPermutation(machineValue79.permutation.withState("fm:organic_level", 0)),
                                    machineValue79.setPermutation(machineValue79.permutation.withState("fm:active", !1));
                                    const machineValue80 = fossilMachineKey("tank_", machineValue79.dimension, {
                                        x: machineValue79.location.x,
                                        y: machineValue79.location.y,
                                        z: machineValue79.location.z
                                    });
                                    world.setDynamicProperty(machineValue80, void 0);
                                }
                            });
                        }
                    } catch {}
                    try {
                        {
                            machineValue74.setPermutation(machineValue74.permutation.withState("fm:locked", !1)),
                            machineValue74.setPermutation(machineValue74.permutation.withState("fm:scanning", !1));
                            const machineValue81 = machineValue74.location, machineValue82 = {};
                            machineValue82.type = machineValue8;
                            const machineValue83 = machineValue62.dimension.getEntities(machineValue82).find(machineValue84 => machineValue84.nameTag == fossilMachineKey("fossil_", machineValue74.dimension, {
                                x: machineValue81.x,
                                y: machineValue81.y,
                                z: machineValue81.z
                            }));
                            if (machineValue83) {
                                const machineValue85 = new ItemStack(machineValue83.getDynamicProperty("itemEquipped"));
                                if (machineValue83.dimension.spawnItem(machineValue85, {
                                    x: (machineValue86 = machineValue81.x, machineValue86 + .5),
                                    y: (machineValue87 = machineValue81.y, machineValue87 + .5),
                                    z: machineValue81.z + .5
                                }), machineValue83.getDynamicProperty("itemEquipped2")) {
                                    const machineValue88 = new ItemStack(machineValue83.getDynamicProperty("itemEquipped2"));
                                    machineValue83.dimension.spawnItem(machineValue88, {
                                        x: machineValue81.x + .5,
                                        y: machineValue81.y + .5,
                                        z: machineValue81.z + .5
                                    });
                                }
                                machineValue83.remove();
                            }
                        }
                    } catch {}
                    return;
                }
                machineValue73?.getParts()?.forEach(machineValue89 => {
                    machineValue89.setPermutation(machineValue89.permutation.withState("fm:locked", !0));
                }), machineValue74.setPermutation(machineValue74.permutation.withState("fm:locked", !0));
                const machineValue90 = machineValue73.permutation.getState("fm:organic_level"), machineValue91 = fossilMachineKey("fossil_", machineValue63.dimension, {
                    x: machineValue66.fossil_analyzer.x,
                    y: machineValue66.fossil_analyzer.y,
                    z: machineValue66.fossil_analyzer.z
                }), machineValue92 = {
                    type: "fm:fossil_analyzer_displayitem"
                }, machineValue93 = machineValue63.dimension.getEntities(machineValue92).find(machineValue94 => machineValue94.nameTag == machineValue91), machineValue95 = fossilRecipes([ machineValue93?.getDynamicProperty("itemEquipped"), machineValue93?.getDynamicProperty("itemEquipped2") ]), machineValue96 = machineValue63.permutation.getState("fm:stats");
                if (0 == machineValue96 && machineValue95 && 8 == machineValue90 && (machineValue66.pokemon = machineValue66.pokemon ?? machineValue95,
                world.setDynamicProperty(machineValue64, JSON.stringify(machineValue66)), machineValue63.setPermutation(machineValue63.permutation.withState("fm:stats", 1)),
                machineValue74.setPermutation(machineValue74.permutation.withState("fm:scanning", !0)),
                machineValue74.setPermutation(machineValue74.permutation.withState("fm:locked", !0)),
                machineValue73.getParts().forEach(machineValue97 => {
                    machineValue97.setPermutation(machineValue97.permutation.withState("fm:locked", !0)),
                    machineValue97.setPermutation(machineValue97.permutation.withState("fm:active", !0));
                }), machineValue63.dimension.playSound("fm:fossil_machine_activate", machineValue63.location),
                machineValue63.dimension.playSound(machineValue9, machineValue63.location)), 1 == machineValue96) {
                    const machineValue98 = machineValue63.permutation.getState("fm:progress"), machineValue99 = world.getDynamicProperty("fossiltime"), machineValue100 = fossilMachineKey("tank_", machineValue73.dimension, {
                        x: machineValue73.location.x,
                        y: machineValue73.location.y,
                        z: machineValue73.location.z
                    }), machineValue101 = {};
                    machineValue101.type = machineValue7;
                    let machineValue102 = machineValue63.dimension.getEntities(machineValue101).find(machineValue103 => machineValue103.nameTag == machineValue100);
                    if (!machineValue93 && (machineValue63.dimension.playSound("fm:fossil_machine_unprotected", machineValue63.location),
                    fm_stopActiveSound(machineValue63.dimension), machineValue63.setPermutation(machineValue63.permutation.withState("fm:stats", 0)),
                    machineValue63.setPermutation(machineValue63.permutation.withState("fm:progress", 0)),
                    machineValue74.setPermutation(machineValue74.permutation.withState("fm:scanning", !1)),
                    machineValue73.getParts().forEach(machineValue104 => {
                        machineValue104.setPermutation(machineValue104.permutation.withState("fm:active", !1));
                    })), !machineValue102) {
                        const machineValue105 = {
                            south: 180,
                            east: 90,
                            west: 270,
                            north: 0
                        }, machineValue106 = machineValue63.dimension.spawnEntity(machineValue7, {
                            x: machineValue73.location.x + .5,
                            y: machineValue73.location.y,
                            z: machineValue73.location.z + .5
                        }, {
                            initialRotation: machineValue105[machineValue63.permutation.getState("minecraft:facing_direction")]
                        });
                        machineValue106.nameTag = machineValue100, machineValue106.setProperty("fm:pokemon", POKEMON_FETU[machineValue66.pokemon]),
                        machineValue102 = machineValue106;
                    }
                    const machineValue107 = machineValue102.getProperty("fm:age");
                    if (machineValue102.setProperty("fm:age", Math.min(3, Math.floor(machineValue66.time / (machineValue99 / 4)))),
                    machineValue107 >= 3 ? machineValue102.teleport({
                        x: machineValue73.location.x + .5,
                        y: (machineValue108 = machineValue73.location.y, machineValue108 - .5),
                        z: (machineValue109 = machineValue73.location.z, machineValue109 + .5)
                    }) : machineValue102.teleport({
                        x: machineValue73.location.x + .5,
                        y: machineValue73.location.y,
                        z: (machineValue110 = machineValue73.location.z, machineValue110 + .5)
                    }), 8 == machineValue98) return fm_stopActiveSound(machineValue63.dimension),
                    machineValue63.dimension.playSound("fm:fossil_machine_finished", machineValue63.location),
                    machineValue74.setPermutation(machineValue74.permutation.withState("fm:scanning", !1)),
                    machineValue93.remove(), machineValue63.setPermutation(machineValue63.permutation.withState("fm:stats", 2)),
                    void machineValue73.getParts().forEach(machineValue111 => {
                        {
                            const machineValue112 = fossilMachineKey("tank_", machineValue111.dimension, {
                                x: machineValue111.location.x,
                                y: machineValue111.location.y,
                                z: machineValue111.location.z
                            }), machineValue113 = JSON.parse(world.getDynamicProperty(machineValue112));
                            machineValue113.pokemon = machineValue66.pokemon, world.setDynamicProperty(machineValue112, JSON.stringify(machineValue113)),
                            machineValue111.setPermutation(machineValue111.permutation.withState("fm:active", !1));
                        }
                    });
                    machineValue66.time % 150 == 0 && machineValue63.dimension.playSound(machineValue9, machineValue63.location),
                    machineValue63.setPermutation(machineValue63.permutation.withState("fm:progress", Math.floor(machineValue66.time / (machineValue99 / 8)))),
                    machineValue66.time += 1, world.setDynamicProperty(machineValue64, JSON.stringify(machineValue66));
                }
                2 == machineValue96 && machineValue90 < 8 && (world.setDynamicProperty(machineValue64, void 0),
                machineValue63.setPermutation(machineValue63.permutation.withState("fm:progress", 0)),
                machineValue63.setPermutation(machineValue63.permutation.withState("fm:stats", 0)));
            }
            var machineValue110, machineValue109, machineValue108, machineValue87, machineValue86;
        },
        onBreak: machineValue114 => {
            const machineValue115 = machineValue114.block, machineValue116 = fossilMachineKey("monitor_", machineValue115.dimension, {
                x: machineValue115.location.x,
                y: machineValue115.location.y,
                z: machineValue115.location.z
            }), machineValue117 = world.getDynamicProperty(machineValue116), machineValue118 = machineValue117 ? JSON.parse(machineValue117) : null;
            if (!machineValue118) return;
            const machineValue119 = machineValue115.dimension.getBlock(machineValue118.restoration_tank), machineValue120 = machineValue115.dimension.getBlock(machineValue118.fossil_analyzer);
            if (world.setDynamicProperty(machineValue116, void 0), machineValue115.dimension.playSound("fm:fossil_machine_unprotected", machineValue115.location),
            fm_stopActiveSound(machineValue115.dimension), machineValue119 && "fm:restoration_tank" == machineValue119.typeId) {
                const machineValue121 = fossilMachineKey("tank_", machineValue119.dimension, {
                    x: machineValue119.location.x,
                    y: machineValue119.location.y,
                    z: machineValue119.location.z
                }), machineValue122 = {};
                machineValue122.type = machineValue7;
                const machineValue123 = machineValue114.dimension.getEntities(machineValue122).find(machineValue124 => machineValue124.nameTag == machineValue121);
                machineValue123 && machineValue123.remove(), machineValue119.getParts().forEach(machineValue125 => {
                    {
                        machineValue125.setPermutation(machineValue125.permutation.withState("fm:locked", !1)),
                        machineValue125.setPermutation(machineValue125.permutation.withState("fm:organic_level", 0)),
                        machineValue125.setPermutation(machineValue125.permutation.withState("fm:active", !1));
                        const machineValue126 = fossilMachineKey("tank_", machineValue125.dimension, {
                            x: machineValue125.location.x,
                            y: machineValue125.location.y,
                            z: machineValue125.location.z
                        });
                        world.setDynamicProperty(machineValue126, void 0);
                    }
                });
            }
            if (machineValue120 && "fm:fossil_analyzer" == machineValue120.typeId) {
                machineValue120.setPermutation(machineValue120.permutation.withState("fm:locked", !1)),
                machineValue120.setPermutation(machineValue120.permutation.withState("fm:scanning", !1));
                const machineValue127 = machineValue120.location, machineValue128 = {
                    type: "fm:fossil_analyzer_displayitem"
                }, machineValue129 = machineValue114.dimension.getEntities(machineValue128).find(machineValue130 => machineValue130.nameTag == fossilMachineKey("fossil_", machineValue120.dimension, {
                    x: machineValue127.x,
                    y: machineValue127.y,
                    z: machineValue127.z
                }));
                if (machineValue129) {
                    const machineValue131 = new ItemStack(machineValue129.getDynamicProperty("itemEquipped"));
                    if (machineValue129.dimension.spawnItem(machineValue131, {
                        x: machineValue127.x + .5,
                        y: machineValue127.y + .5,
                        z: (machineValue132 = machineValue127.z, machineValue132 + .5)
                    }), machineValue129.getDynamicProperty("itemEquipped2")) {
                        const machineValue133 = new ItemStack(machineValue129.getDynamicProperty("itemEquipped2"));
                        machineValue129.dimension.spawnItem(machineValue133, {
                            x: machineValue127.x + .5,
                            y: machineValue127.y + .5,
                            z: machineValue127.z + .5
                        });
                    }
                    machineValue129.remove();
                }
            }
            var machineValue132;
        }
    });
}), system.runInterval(() => {
    for (const machineValue134 of world.getAllPlayers()) {
        const machineValue135 = machineValue134.getDynamicProperty("uimonitor") ?? "fm.ui.monitor§zX", machineValue136 = {
            maxDistance: 4
        }, machineValue137 = machineValue134.getBlockFromViewDirection(machineValue136)?.block;
        if (!machineValue137 || "fm:monitor" != machineValue137.typeId) {
            "fm.ui.monitorX" != machineValue135 && (showFossilMonitor(machineValue134, "fm.ui.monitorX"),
            machineValue134.setDynamicProperty("uimonitor", "fm.ui.monitorX"));
            continue;
        }
        const machineValue138 = machineValue137.permutation.getState("fm:stats");
        if (0 == machineValue138) {
            const machineValue139 = "fm.ui.monitor_off";
            machineValue135 != machineValue139 && (showFossilMonitor(machineValue134, machineValue139),
            machineValue134.setDynamicProperty("uimonitor", machineValue139));
        }
        if (1 == machineValue138) {
            const machineValue140 = fossilMachineKey("monitor_", machineValue137.dimension, {
                x: machineValue137.location.x,
                y: machineValue137.location.y,
                z: machineValue137.location.z
            }), machineValue141 = JSON.parse(world.getDynamicProperty(machineValue140)), machineValue142 = (world.getDynamicProperty("fossiltime") - machineValue141.time) / 20, machineValue143 = "fm.ui.monitor_on§z" + Math.floor(machineValue142 / 60).toString().padStart(2, "0") + ":" + (Math.floor(machineValue142) % 60).toString().padStart(2, "0");
            machineValue135 != machineValue143 && (showFossilMonitor(machineValue134, machineValue143),
            machineValue134.setDynamicProperty("uimonitor", machineValue143));
        }
        if (2 == machineValue138) {
            const machineValue144 = "fm.ui.monitor_finish";
            machineValue135 != machineValue144 && (showFossilMonitor(machineValue134, machineValue144),
            machineValue134.setDynamicProperty("uimonitor", machineValue144));
        }
    }
}), world.afterEvents.worldLoad.subscribe(() => {
    !world.getDynamicProperty("fossiltime") && world.setDynamicProperty("fossiltime", 14400);
}), system.beforeEvents.startup.subscribe(_fmAutoInit => {
    _fmAutoInit.blockComponentRegistry.registerCustomComponent("fm:auto_link", {
        onPlace: e => {
            try {
                const loc = e.block.location;
                system.run(() => {
                    fm_linkNear(e.dimension, loc.x, loc.y, loc.z, 5);
                });
            } catch (err) {}
        }
    });
}), system.beforeEvents.startup.subscribe(_fmPatchInit => {
    _fmPatchInit.customCommandRegistry.registerCommand({
        name: "fm:link",
        description: "Conecta manualmente o Fossil Analyzer e o Restoration Tank próximos (raio de 5 blocos)",
        permissionLevel: CommandPermissionLevel.Any,
        cheatsRequired: !1
    }, origin => {
        const player = origin.sourceEntity;
        if (!player) return;
        let dim, center;
        try {
            dim = player.dimension, center = player.location;
        } catch (e) {
            return void player.sendMessage("§c[Fossil Machine] Erro: " + e);
        }
        const cx = Math.floor(center.x), cy = Math.floor(center.y), cz = Math.floor(center.z);
        system.run(() => {
            const r = fm_linkNear(dim, cx, cy, cz, 5);
            0 !== r.analyzersFound || 0 !== r.tanksFound ? player.sendMessage("§a[Fossil Machine] §fEncontrados " + r.analyzersFound + " analyzer(s) e " + r.tanksFound + " tank(s). " + r.touched + " bloco(s) destravado(s) agora.") : player.sendMessage("§c[Fossil Machine] Nenhum Fossil Analyzer ou Restoration Tank encontrado num raio de 5 blocos.");
        });
    });
}), system.beforeEvents.startup.subscribe(_fmScanInit => {
    _fmScanInit.customCommandRegistry.registerCommand({
        name: "fm:scan",
        description: "Calcula qual Pokémon vai nascer a partir do(s) fóssil(is) já inseridos no Fossil Analyzer e grava no Restoration Tank vinculado (raio de 5 blocos)",
        permissionLevel: CommandPermissionLevel.GameDirectors,
        cheatsRequired: !1
    }, origin => {
        const player = origin.sourceEntity;
        if (!player) return;
        let dim, center;
        try {
            dim = player.dimension, center = player.location;
        } catch (e) {
            return void player.sendMessage("§c[Fossil Machine] Erro: " + e);
        }
        const cx = Math.floor(center.x), cy = Math.floor(center.y), cz = Math.floor(center.z);
        system.run(() => {
            let entities = [];
            try {
                entities = dim.getEntities({
                    type: "fm:fossil_analyzer_displayitem",
                    location: {
                        x: cx,
                        y: cy,
                        z: cz
                    },
                    maxDistance: 5
                });
            } catch (e) {
                return void player.sendMessage("§c[Fossil Machine] Erro buscando fósseis inseridos: " + e);
            }
            if (0 === entities.length) return void player.sendMessage("§c[Fossil Machine] Nenhum fóssil inserido encontrado por perto. Insira o fóssil no analyzer primeiro.");
            const items = [];
            for (const ent of entities) {
                let eq;
                try {
                    eq = ent.getDynamicProperty("itemEquipped");
                } catch (e) {}
                eq && items.push(eq);
            }
            if (0 === items.length) return void player.sendMessage("§c[Fossil Machine] As entidades encontradas não têm fóssil equipado.");
            let dexId;
            try {
                dexId = fossilRecipes(items);
            } catch (e) {
                return void player.sendMessage("§c[Fossil Machine] Erro calculando receita: " + e);
            }
            if (!dexId) return void player.sendMessage("§c[Fossil Machine] Combinação não corresponde a nenhuma receita conhecida: " + items.join(", "));
            let tanksTouched = 0;
            const tankBlocks = fm_findNearbyBlocks(dim, cx, cy, cz, 5, "fm:restoration_tank");
            for (const block of tankBlocks) {
                let parts = [ block ];
                try {
                    "function" == typeof block.getParts && (parts = block.getParts());
                } catch (e) {}
                for (const part of parts) {
                    const key = fossilMachineKey("tank_", part.dimension, {
                        x: part.location.x,
                        y: part.location.y,
                        z: part.location.z
                    });
                    let data = {
                        level: 1,
                        pokemon: null
                    };
                    try {
                        const raw = world.getDynamicProperty(key);
                        raw && (data = JSON.parse(raw));
                    } catch (e) {}
                    data.pokemon = data.pokemon ?? dexId;
                    try {
                        world.setDynamicProperty(key, JSON.stringify(data)), tanksTouched++;
                    } catch (e) {
                        player.sendMessage("§c[Fossil Machine] Erro gravando no tank: " + e);
                    }
                }
            }
            0 !== tanksTouched ? player.sendMessage("§a[Fossil Machine] §fFóssil(is) reconhecido(s): " + items.join(", ") + " -> Pokémon dex #" + dexId + ". " + tanksTouched + " parte(s) de tanque atualizada(s).") : player.sendMessage("§c[Fossil Machine] Nenhum Restoration Tank encontrado por perto pra gravar o resultado.");
        });
    });
});
