import { BiomeTypes, ItemLockMode, ItemStack, LocationWaypoint, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import {
    requestCorePokemonGrant,
    requestCoreTrainerBattle,
    syncCoreLevelCap,
    subscribeCorePokemonGrantResult,
    subscribeCoreTrainerResult
} from "./core_bridge.js";
import { GYM_FIRST_CLEAR_REWARDS } from "./gym_rewards.js";
import {
    candidateBiomeMatchesStart,
    GYM_BATTLE_CAMERA_SIDE_SCALE,
    GYM_BATTLE_LAYOUTS,
    GYM_NATIVE_PLACEMENTS,
    gymBattleLineLocations,
    randomSpreadCandidatesNear
} from "./gym_native_locator.js";

const BADGE_CASE_ITEM = "lota:gym_badge_case";
const BADGE_FORM_BUSY_RETRIES = 5;
const BADGE_FORM_RETRY_DELAY_TICKS = 2;
const LEADER_ENTITY = "lota:gym_leader";
const BADGE_MASK_PROPERTY = "lota:gym_badge_mask_v1";
const BADGE_CASE_MASK_PROPERTY = "lota:gym_badge_case_mask_v1";
const BADGE_CASE_MASK_SYNC_PROPERTY = "lota:badge_case_mask";
const BADGE_ITEM_PREFIX = "lota:badge_";
const BADGE_SLOT_BUTTON_OFFSET = 1;
const LEVEL_CAP_PROPERTY = "lota:server_level_cap_v1";
const GYM_LOCATION_PROPERTY_PREFIX = "lota:gym_locations_v1_";
const GYM_ASSIGNMENT_PROPERTY = "lota:gym_assignment_v5";
const GYM_MEW_REWARD_STATE_PROPERTY = "lota:gym_mew_reward_state_v1";
const TEST_GYM_CLEAR_EVENT = "lota:test_gym_clear_v1";
const MAX_SAVED_LOCATIONS_PER_GYM = 256;
const LEADER_POSITIONED_TAG = "lota:gym_positioned_v1";
const GYM_ASSIGNMENT_REGION_RADIUS = 16;
const GYM_ASSIGNMENT_SEARCHES_PER_TICK = 4;
const GYM_ASSIGNMENT_REFINEMENT_DISTANCE = 96;
const GYM_ASSIGNMENT_MAX_VERIFICATIONS = 16;
const GYM_VERIFICATION_CHUNK_RADIUS = 2;
const GYM_VERIFICATION_POLL_TICKS = 4;
const GYM_VERIFICATION_TIMEOUT_TICKS = 40;
const GYM_BIOME_SEARCH_BOUNDING_PRESETS = Object.freeze([
    Object.freeze({ x: 64, y: 384, z: 64 }),
    Object.freeze({ x: 64, y: 256, z: 64 }),
    Object.freeze({ x: 64, y: 128, z: 64 }),
    Object.freeze({ x: 64, y: 64, z: 64 }),
    Object.freeze({ x: 128, y: 384, z: 128 }),
    Object.freeze({ x: 128, y: 256, z: 128 }),
    Object.freeze({ x: 128, y: 128, z: 128 }),
    Object.freeze({ x: 256, y: 384, z: 256 }),
    Object.freeze({ x: 256, y: 256, z: 256 })
]);

const PERFECT_IVS = Object.freeze({
    hp: 31,
    attack: 31,
    defence: 31,
    specialAttack: 31,
    specialDefence: 31,
    speed: 31
});

const RCT_LEADER_AI = Object.freeze({
    difficulty: "rct",
    moveBias: 1,
    switchBias: 0.85,
    statMoveBias: 1,
    maxSelectMargin: 0.03
});

function gymPokemon(species, level, moves, nature, ability, evs) {
    return Object.freeze({ species, level, moves: Object.freeze(moves), nature, ability, ivs: PERFECT_IVS, evs: Object.freeze(evs) });
}

const GYMS = [
    {
        type: "Stone", leader: "Brock", badge: "stone",
        party: [
            gymPokemon("geodude", 16, ["stealthrock", "bulldoze", "rocktomb", "protect"], "impish", "sturdy", { hp: 100, defence: 60 }),
            gymPokemon("bonsly", 17, ["rockslide", "lowkick", "suckerpunch", "protect"], "impish", "sturdy", { hp: 252, defence: 252 }),
            gymPokemon("cranidos", 18, ["rockslide", "bulldoze", "zenheadbutt", "screech"], "jolly", "moldbreaker", { attack: 252, speed: 252 }),
            gymPokemon("onix", 20, ["rockslide", "bulldoze", "screech", "bind"], "impish", "sturdy", { hp: 100, defence: 100 })
        ]
    },
    {
        type: "Water", leader: "Misty", badge: "water",
        party: [
            gymPokemon("horsea", 16, ["raindance", "waterpulse", "icebeam", "flashcannon"], "modest", "sniper", { specialAttack: 252, speed: 252 }),
            gymPokemon("staryu", 17, ["waterpulse", "psybeam", "thunderwave", "recover"], "timid", "naturalcure", { specialAttack: 100, speed: 100 }),
            gymPokemon("psyduck", 18, ["waterpulse", "confusion", "hypnosis", "disable"], "timid", "cloudnine", { specialAttack: 252, speed: 252 }),
            gymPokemon("starmie", 20, ["surf", "psyshock", "icebeam", "recover"], "timid", "analytic", { specialAttack: 160, speed: 100 })
        ]
    },
    {
        type: "Electric", leader: "Lt. Surge", badge: "electric",
        party: [
            gymPokemon("pikachu", 34, ["thunderwave", "electroball", "irontail", "quickattack"], "hasty", "static", { attack: 100, specialAttack: 100, speed: 252 }),
            gymPokemon("magneton", 36, ["thunderbolt", "flashcannon", "voltswitch", "thunderwave"], "modest", "sturdy", { hp: 100, specialAttack: 252, speed: 100 }),
            gymPokemon("electabuzz", 38, ["thunderpunch", "icepunch", "firepunch", "psychic"], "hasty", "static", { attack: 100, specialAttack: 156, speed: 252 }),
            gymPokemon("raichu", 40, ["thunderbolt", "psyshock", "focusblast", "nastyplot"], "timid", "static", { specialAttack: 252, speed: 252 })
        ]
    },
    {
        type: "Fighter", leader: "Brawly", badge: "fighter",
        party: [
            gymPokemon("machoke", 34, ["bulkup", "brickbreak", "knockoff", "rockslide"], "adamant", "noguard", { hp: 160, attack: 252, specialDefence: 96 }),
            gymPokemon("breloom", 36, ["spore", "machpunch", "seedbomb", "rocktomb"], "jolly", "technician", { attack: 252, speed: 252 }),
            gymPokemon("toxicroak", 38, ["swordsdance", "drainpunch", "poisonjab", "suckerpunch"], "jolly", "dryskin", { attack: 252, speed: 252 }),
            gymPokemon("hariyama", 40, ["fakeout", "closecombat", "knockoff", "bulletpunch"], "adamant", "guts", { hp: 252, attack: 252 })
        ]
    },
    {
        type: "Fire", leader: "Blaine", badge: "fire",
        party: [
            gymPokemon("ninetales", 52, ["willowisp", "flamethrower", "energyball", "extrasensory"], "timid", "flashfire", { specialAttack: 252, speed: 252 }),
            gymPokemon("torkoal", 54, ["sunnyday", "lavaplume", "bodypress", "earthpower"], "bold", "drought", { hp: 252, defence: 252 }),
            gymPokemon("magmar", 57, ["flamethrower", "thunderpunch", "psychic", "confuseray"], "hasty", "flamebody", { attack: 100, specialAttack: 252, speed: 156 }),
            gymPokemon("arcanine", 60, ["flareblitz", "closecombat", "wildcharge", "extremespeed"], "jolly", "intimidate", { attack: 252, speed: 252 })
        ]
    },
    {
        type: "Metal", leader: "Jasmine", badge: "metal",
        party: [
            gymPokemon("skarmory", 52, ["stealthrock", "ironhead", "aerialace", "roost"], "impish", "sturdy", { hp: 252, defence: 252 }),
            gymPokemon("bronzong", 54, ["reflect", "lightscreen", "psychic", "ironhead"], "sassy", "levitate", { hp: 252, defence: 128, specialDefence: 128 }),
            gymPokemon("magneton", 57, ["thunderwave", "thunderbolt", "flashcannon", "voltswitch"], "modest", "sturdy", { hp: 100, specialAttack: 252, speed: 156 }),
            gymPokemon("steelix", 60, ["bodypress", "earthquake", "icefang", "stoneedge"], "brave", "sturdy", { hp: 252, attack: 100, defence: 156 })
        ]
    },
    {
        type: "Grass", leader: "Erika", badge: "grass",
        party: [
            gymPokemon("roserade", 72, ["toxicspikes", "gigadrain", "sludgebomb", "dazzlinggleam"], "timid", "naturalcure", { specialAttack: 252, speed: 252 }),
            gymPokemon("victreebel", 75, ["sleeppowder", "gigadrain", "poisonjab", "suckerpunch"], "hasty", "chlorophyll", { attack: 100, specialAttack: 252, speed: 156 }),
            gymPokemon("tangrowth", 78, ["sleeppowder", "gigadrain", "knockoff", "ancientpower"], "bold", "regenerator", { hp: 252, defence: 252 }),
            gymPokemon("vileplume", 80, ["toxic", "gigadrain", "moonblast", "moonlight"], "calm", "effectspore", { hp: 252, specialAttack: 100, specialDefence: 156 })
        ]
    },
    {
        type: "Flying", leader: "Falkner", badge: "flying",
        party: [
            gymPokemon("noctowl", 72, ["hypnosis", "airslash", "psychic", "roost"], "calm", "tintedlens", { hp: 252, specialAttack: 100, specialDefence: 156 }),
            gymPokemon("altaria", 75, ["dragondance", "aerialace", "dragonclaw", "roost"], "jolly", "naturalcure", { attack: 252, speed: 252 }),
            gymPokemon("gliscor", 78, ["swordsdance", "earthquake", "aerialace", "roost"], "jolly", "hypercutter", { attack: 252, speed: 252 }),
            gymPokemon("pidgeot", 80, ["tailwind", "hurricane", "heatwave", "roost"], "timid", "tangledfeet", { specialAttack: 252, speed: 252 })
        ]
    },
    {
        type: "Ghost", leader: "Morty", badge: "ghost",
        party: [
            gymPokemon("mismagius", 90, ["nastyplot", "shadowball", "mysticalfire", "dazzlinggleam"], "timid", "levitate", { specialAttack: 252, speed: 252 }),
            gymPokemon("chandelure", 93, ["willowisp", "shadowball", "flamethrower", "energyball"], "timid", "flashfire", { specialAttack: 252, speed: 252 }),
            gymPokemon("dusknoir", 96, ["willowisp", "shadowpunch", "earthquake", "rest"], "careful", "pressure", { hp: 252, attack: 100, specialDefence: 156 }),
            gymPokemon("gengar", 100, ["sludgebomb", "shadowball", "focusblast", "destinybond"], "timid", "cursedbody", { specialAttack: 252, speed: 252 })
        ]
    },
    {
        type: "Ground", leader: "Giovanni", badge: "ground",
        party: [
            gymPokemon("nidoking", 90, ["toxicspikes", "earthpower", "sludgewave", "icebeam"], "timid", "sheerforce", { specialAttack: 252, speed: 252 }),
            gymPokemon("nidoqueen", 93, ["toxic", "earthpower", "sludgebomb", "icebeam"], "bold", "sheerforce", { hp: 252, defence: 156, specialAttack: 100 }),
            gymPokemon("rhyperior", 96, ["earthquake", "stoneedge", "megahorn", "thunderfang"], "adamant", "solidrock", { hp: 252, attack: 252 }),
            gymPokemon("excadrill", 98, ["swordsdance", "earthquake", "ironhead", "rockslide"], "jolly", "sandrush", { attack: 252, speed: 252 }),
            gymPokemon("garchomp", 100, ["swordsdance", "earthquake", "dragonclaw", "stoneedge"], "jolly", "roughskin", { attack: 252, speed: 252 })
        ]
    }
];

const LEGACY_LEADER_MARKERS = [
    { typeId: "minecraft:polished_andesite", horizontalDistance: 8, yOffset: 1 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: 8, yOffset: 1 },
    { typeId: "minecraft:smooth_stone", horizontalDistance: 7, yOffset: 1 },
    { typeId: "minecraft:smooth_stone", horizontalDistance: 6, yOffset: -1 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: 8, yOffset: 1 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: 8, yOffset: 1 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: Math.sqrt(68), yOffset: 12 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: 7, yOffset: 2 },
    { typeId: "minecraft:smooth_stone", horizontalDistance: Math.sqrt(80), yOffset: 1 },
    { typeId: "minecraft:polished_andesite", horizontalDistance: Math.sqrt(37), yOffset: 9 }
];

const activeWaypoints = new Map();
const pendingBattles = new Map();
const pendingMewRewards = new Map();
const interactionCooldowns = new Map();
const activeBadgeFormRequests = new Map();
let nextBadgeRequestToken = 1;
const BADGE_CASE_HOLD_TICKS = 8;
const badgeCaseHolds = new Map();
const badgeCaseLastPress = new Map();
const badgeCaseSneaking = new Map();
const gymLocationCache = Array.from({ length: GYMS.length }, () => undefined);
const syncedLevelCaps = new Map();
const assignmentSearches = new Map();
const placementBiomeIds = new Map();
let supportedBiomeSearchBounds;
let biomeSearchBoundsResolved = false;
let gymVerificationSequence = 0;

const BIOME_ID_FALLBACKS = Object.freeze({
    plains: Object.freeze(["minecraft:plains", "minecraft:sunflower_plains"]),
    meadow: Object.freeze(["minecraft:meadow"]),
    beach: Object.freeze(["minecraft:beach", "minecraft:stone_beach", "minecraft:cold_beach"]),
    swamp: Object.freeze(["minecraft:swampland", "minecraft:swamp", "minecraft:mangrove_swamp"]),
    mangrove_swamp: Object.freeze(["minecraft:mangrove_swamp"]),
    savanna: Object.freeze(["minecraft:savanna", "minecraft:savanna_plateau", "minecraft:savanna_mutated", "minecraft:savanna_plateau_mutated"]),
    taiga: Object.freeze(["minecraft:taiga", "minecraft:taiga_hills", "minecraft:mega_taiga", "minecraft:mega_taiga_hills"]),
    desert: Object.freeze(["minecraft:desert", "minecraft:desert_hills", "minecraft:desert_mutated"]),
    mesa: Object.freeze(["minecraft:mesa", "minecraft:mesa_bryce", "minecraft:mesa_plateau", "minecraft:mesa_plateau_stone", "minecraft:badlands", "minecraft:eroded_badlands", "minecraft:wooded_badlands"]),
    roofed: Object.freeze(["minecraft:roofed_forest", "minecraft:roofed_forest_mutated", "minecraft:dark_forest"]),
    flower_forest: Object.freeze(["minecraft:flower_forest"])
});

function integerProperty(holder, key, fallback = 0) {
    const value = Number(holder.getDynamicProperty(key));
    return Number.isFinite(value) ? Math.floor(value) : fallback;
}

function badgeMask(player) {
    return Math.max(0, integerProperty(player, BADGE_MASK_PROPERTY, 0)) & 0x3ff;
}

function badgeCount(mask) {
    let value = mask & 0x3ff;
    let count = 0;
    while (value) {
        count += value & 1;
        value >>>= 1;
    }
    return count;
}

function levelCapForMask(mask) {
    return Math.min(100, 20 + Math.floor(badgeCount(mask) / 2) * 20);
}

function syncLevelCap(player) {
    const cap = levelCapForMask(badgeMask(player));
    if (Number(player.getDynamicProperty(LEVEL_CAP_PROPERTY)) !== cap) {
        player.setDynamicProperty(LEVEL_CAP_PROPERTY, cap);
    }
    if (syncedLevelCaps.get(player.id) !== cap && syncCoreLevelCap(player, cap)) {
        syncedLevelCaps.set(player.id, cap);
    }
    return cap;
}

function gymRawMessage(key, withArgs = []) {
    const rawtext = [{
        translate: key
    }];
    if (withArgs.length) {
        rawtext[0].with = withArgs.map(val => (typeof val === "object" && val !== null ? val : String(val)));
    }
    return { rawtext };
}

function send(player, message) {
    try { player.sendMessage(message); } catch (error) {}
}

function playGymClearSound(player) {
    try { player.playSound("random.levelup", { volume: 1, pitch: 1 }); } catch (error) {}
    system.runTimeout(() => {
        if (!player?.isValid) return;
        try { player.playSound("random.orb", { volume: 0.9, pitch: 1.35 }); } catch (error) {}
    }, 7);
}

function giveOrDrop(player, typeId) {
    try {
        const stack = new ItemStack(typeId, 1);
        if (typeId === BADGE_CASE_ITEM || badgeIndexForItem(typeId) >= 0) {
            stack.keepOnDeath = true;
            stack.lockMode = ItemLockMode.inventory;
        }
        const container = player.getComponent("minecraft:inventory")?.container;
        const remainder = container ? container.addItem(stack) : stack;
        if (remainder) player.dimension.spawnItem(remainder, player.location);
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not give '${typeId}': ${error}`);
        return false;
    }
}

function ensureBadgeCase(player) {
    const container = player.getComponent("minecraft:inventory")?.container;
    if (container) {
        for (let slot = 0; slot < container.size; slot++) {
            const stack = container.getItem(slot);
            if (stack?.typeId !== BADGE_CASE_ITEM) continue;
            return;
        }
    }
    giveOrDrop(player, BADGE_CASE_ITEM);
}

function badgeItemId(index) {
    return `${BADGE_ITEM_PREFIX}${GYMS[index].badge}`;
}

function badgeIndexForItem(typeId) {
    if (typeof typeId !== "string" || !typeId.startsWith(BADGE_ITEM_PREFIX)) return -1;
    return GYMS.findIndex(gym => `${BADGE_ITEM_PREFIX}${gym.badge}` === typeId);
}

function badgeMessage(key, index) {
    return {
        rawtext: [{
            translate: key,
            with: { rawtext: [{ translate: `item.lota.badge_${GYMS[index].badge}` }] }
        }]
    };
}

function syncCaseMaskProperty(player, mask) {
    const value = mask & 0x3ff;
    try {
        if (player?.isValid && player.getProperty(BADGE_CASE_MASK_SYNC_PROPERTY) !== value) {
            player.setProperty(BADGE_CASE_MASK_SYNC_PROPERTY, value);
        }
    } catch (error) {}
}

function caseBadgeMask(player) {
    const earned = badgeMask(player);
    const raw = player.getDynamicProperty(BADGE_CASE_MASK_PROPERTY);
    if (raw === undefined) {
        player.setDynamicProperty(BADGE_CASE_MASK_PROPERTY, earned);
        syncCaseMaskProperty(player, earned);
        return earned;
    }
    const stored = Number(raw);
    const mask = (Number.isFinite(stored) ? Math.floor(stored) & 0x3ff : 0) & earned;
    syncCaseMaskProperty(player, mask);
    return mask;
}

function setCaseBadgeMask(player, mask) {
    player.setDynamicProperty(BADGE_CASE_MASK_PROPERTY, mask & 0x3ff);
    syncCaseMaskProperty(player, mask & badgeMask(player));
}

function playerContainer(player) {
    try { return player.getComponent("minecraft:inventory")?.container; }
    catch (error) { return undefined; }
}

function carriedBadgeMask(player) {
    const container = playerContainer(player);
    let mask = 0;
    if (!container) return mask;
    for (let slot = 0; slot < container.size; slot++) {
        const index = badgeIndexForItem(container.getItem(slot)?.typeId);
        if (index >= 0) mask |= 1 << index;
    }
    return mask;
}

function takeBadgeItem(player, index) {
    const container = playerContainer(player);
    if (!container) return false;
    const typeId = badgeItemId(index);
    for (let slot = 0; slot < container.size; slot++) {
        const stack = container.getItem(slot);
        if (stack?.typeId !== typeId) continue;
        if (stack.amount > 1) {
            stack.amount -= 1;
            container.setItem(slot, stack);
        } else {
            container.setItem(slot, undefined);
        }
        return true;
    }
    return false;
}

function equipBadge(player, index) {
    const bit = 1 << index;
    if ((badgeMask(player) & bit) === 0) {
        send(player, badgeMessage("message.cobbledrock.gym.badge_not_earned", index));
        return false;
    }
    const equipped = caseBadgeMask(player);
    if ((equipped & bit) !== 0) {
        send(player, badgeMessage("message.cobbledrock.gym.badge_already_equipped", index));
        return false;
    }
    if (!takeBadgeItem(player, index)) {
        if (giveOrDrop(player, badgeItemId(index))) {
            send(player, badgeMessage("message.cobbledrock.gym.badge_reissued", index));
        }
        return false;
    }
    setCaseBadgeMask(player, equipped | bit);
    try { player.playSound("random.pop", { volume: 0.8, pitch: 1.3 }); } catch (error) {}
    send(player, badgeMessage("message.cobbledrock.gym.badge_equipped", index));
    return true;
}

function unequipBadge(player, index) {
    const bit = 1 << index;
    const equipped = caseBadgeMask(player);
    if ((equipped & bit) === 0) return false;
    if (!giveOrDrop(player, badgeItemId(index))) return false;
    setCaseBadgeMask(player, equipped & ~bit);
    try { player.playSound("random.pop", { volume: 0.8, pitch: 0.9 }); } catch (error) {}
    send(player, badgeMessage("message.cobbledrock.gym.badge_unequipped", index));
    return true;
}

function handleBadgeSlotClick(player, index) {
    if ((caseBadgeMask(player) & (1 << index)) !== 0) unequipBadge(player, index);
    else equipBadge(player, index);
}

function dropFirstClearItems(index, rewardContext) {
    const reward = GYM_FIRST_CLEAR_REWARDS[index];
    if (!reward?.items?.length || !rewardContext?.dimensionId || !rewardContext?.location) return false;
    let dimension;
    try { dimension = world.getDimension(rewardContext.dimensionId); }
    catch (error) { return false; }
    const location = {
        x: Number(rewardContext.location.x),
        y: Number(rewardContext.location.y) + 0.35,
        z: Number(rewardContext.location.z)
    };
    if (!Object.values(location).every(Number.isFinite)) return false;
    try {
        for (const item of reward.items) {
            dimension.spawnItem(new ItemStack(item.typeId, item.amount), location);
        }
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not drop gym ${index + 1} first-clear reward: ${error}`);
        return false;
    }
}

function requestMewReward(player) {
    if (!player?.isValid || badgeCount(badgeMask(player)) < GYMS.length) return false;
    if (integerProperty(player, GYM_MEW_REWARD_STATE_PROPERTY, 0) >= 2) return true;
    if ([...pendingMewRewards.values()].some(pending => pending.playerId === player.id)) return true;
    const pokemon = GYM_FIRST_CLEAR_REWARDS[GYM_FIRST_CLEAR_REWARDS.length - 1]?.pokemon;
    if (!pokemon) return false;
    player.setDynamicProperty(GYM_MEW_REWARD_STATE_PROPERTY, 1);
    const requestId = requestCorePokemonGrant(player, pokemon);
    if (!requestId) {
        player.setDynamicProperty(GYM_MEW_REWARD_STATE_PROPERTY, 0);
        send(player, gymRawMessage("message.cobbledrock.gym.mew_request_failed"));
        return false;
    }
    pendingMewRewards.set(requestId, { playerId: player.id });
    return true;
}

const LEADER_BATTLE_PROPERTY = "lota:in_battle";

function setLeaderBattlePose(leader, active) {
    try {
        if (leader?.isValid && leader.typeId === LEADER_ENTITY) leader.setProperty(LEADER_BATTLE_PROPERTY, !!active);
    } catch (error) {}
}

function releaseLeaderBattlePose(leaderId) {
    if (!leaderId) return;
    try { setLeaderBattlePose(world.getEntity(leaderId), false); } catch (error) {}
}

function releaseStaleLeaderPoses() {
    const busy = new Set([...pendingBattles.values()].map(pending => pending.leaderId));
    for (const dimensionId of ["overworld", "nether", "the_end"]) {
        let leaders = [];
        try { leaders = world.getDimension(dimensionId).getEntities({ type: LEADER_ENTITY }); } catch (error) {}
        for (const leader of leaders) {
            let active = false;
            try { active = leader.getProperty(LEADER_BATTLE_PROPERTY) === true; } catch (error) {}
            if (active && !busy.has(leader.id)) setLeaderBattlePose(leader, false);
        }
    }
}

function taggedLeaderIndex(leader) {
    for (const tag of leader.getTags()) {
        const match = /^lota:gym_index_([0-9])$/.exec(tag);
        if (match) return Number(match[1]);
    }
    return undefined;
}

function leaderIndex(leader) {
    const tagged = taggedLeaderIndex(leader);
    if (tagged !== undefined) return tagged;
    const property = Number(leader.getProperty("lota:gym_index"));
    return Number.isInteger(property) && property >= 0 && property < GYMS.length ? property : -1;
}

function normalizeYaw(yaw) {
    let value = yaw % 360;
    if (value > 180) value -= 360;
    if (value <= -180) value += 360;
    return value;
}

function positionLegacyLeader(leader, index) {
    if (leader.hasTag(LEADER_POSITIONED_TAG)) return;
    const marker = LEGACY_LEADER_MARKERS[index];
    const origin = leader.location;
    const yaw = leader.getRotation().y;
    const radians = yaw * Math.PI / 180;
    const desiredX = -Math.cos(radians);
    const desiredZ = -Math.sin(radians);
    const radius = Math.ceil(marker.horizontalDistance) + 1;
    const blockY = Math.floor(origin.y) + marker.yOffset;
    let best;
    let bestDot = Number.NEGATIVE_INFINITY;
    for (let dx = -radius; dx <= radius; dx++) {
        for (let dz = -radius; dz <= radius; dz++) {
            const horizontalDistance = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(horizontalDistance - marker.horizontalDistance) > 0.35) continue;
            const block = leader.dimension.getBlock({
                x: Math.floor(origin.x) + dx,
                y: blockY,
                z: Math.floor(origin.z) + dz
            });
            if (block?.typeId !== marker.typeId) continue;
            const targetX = block.location.x + 0.5;
            const targetZ = block.location.z + 0.5;
            const dot = (targetX - origin.x) * desiredX + (targetZ - origin.z) * desiredZ;
            if (dot > bestDot) {
                bestDot = dot;
                best = { x: targetX, y: block.location.y + 1, z: targetZ };
            }
        }
    }
    if (!best) return;
    try {
        leader.teleport(best, { rotation: { x: 0, y: normalizeYaw(yaw - 90) } });
        leader.addTag(LEADER_POSITIONED_TAG);
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not move legacy gym ${index + 1} leader: ${error}`);
    }
}

function configureLeader(leader) {
    if (leader?.typeId !== LEADER_ENTITY || !leader.isValid) return -1;
    const index = leaderIndex(leader);
    if (index < 0 || index >= GYMS.length) return -1;
    positionLegacyLeader(leader, index);
    try {
        leader.setProperty("lota:gym_index", index);
        leader.nameTag = `§e${GYMS[index].leader} · ${GYMS[index].type} Gym Leader§r`;
    } catch (error) {}
    rememberGymLocation(index, leader.location);
    return index;
}

function clearLocator(player) {
    const active = activeWaypoints.get(player.id);
    if (!active) return;
    activeWaypoints.delete(player.id);
    try {
        if (player.locatorBar.hasWaypoint(active.waypoint)) player.locatorBar.removeWaypoint(active.waypoint);
    } catch (error) {}
}

function distanceSquared(from, to) {
    const dx = from.x - to.x;
    const dy = from.y - to.y;
    const dz = from.z - to.z;
    return dx * dx + dy * dy + dz * dz;
}

function horizontalDistanceSquared(from, to) {
    const dx = from.x - to.x;
    const dz = from.z - to.z;
    return dx * dx + dz * dz;
}

function readGymAssignment(player, index) {
    try {
        const assignment = JSON.parse(String(player.getDynamicProperty(GYM_ASSIGNMENT_PROPERTY) || "{}"));
        if (Number(assignment.gymIndex) !== index || String(assignment.seed) !== String(world.seed)) return undefined;
        const x = Number(assignment.x);
        const y = Number(assignment.y);
        const z = Number(assignment.z);
        if (![x, y, z].every(Number.isFinite)) return undefined;
        return { x, y, z };
    } catch (error) {
        return undefined;
    }
}

function rememberGymAssignment(player, index, location) {
    if (!player?.isValid || index < 0 || index >= GYMS.length || !location) return false;
    try {
        player.setDynamicProperty(GYM_ASSIGNMENT_PROPERTY, JSON.stringify({
            gymIndex: index,
            seed: String(world.seed),
            x: location.x,
            y: location.y,
            z: location.z
        }));
        return true;
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not save ${GYMS[index].type} gym assignment for ${player.name}: ${error}`);
        return false;
    }
}

function clearGymAssignment(player) {
    assignmentSearches.delete(player.id);
    try { player.setDynamicProperty(GYM_ASSIGNMENT_PROPERTY, undefined); }
    catch (error) {}
}

function biomeIdsForPlacement(index) {
    if (placementBiomeIds.has(index)) return placementBiomeIds.get(index);
    const placement = GYM_NATIVE_PLACEMENTS[index];
    const ids = new Set();
    for (const tag of placement.biomeTags) {
        for (const typeId of BIOME_ID_FALLBACKS[tag] || []) {
            try {
                if (BiomeTypes.get(typeId)) ids.add(typeId);
            } catch (error) {}
        }
    }
    try {
        for (const biome of BiomeTypes.getAll()) {
            if (placement.biomeTags.some(tag => {
                try { return biome.hasTags([tag]) || biome.hasTags([`minecraft:${tag}`]); }
                catch (error) { return false; }
            })) ids.add(biome.id);
        }
    } catch (error) {}
    const result = [...ids];
    placementBiomeIds.set(index, result);
    return result;
}

function calculateCandidateBiome(dimension, position, biomeId) {
    if (biomeSearchBoundsResolved) {
        return supportedBiomeSearchBounds
            ? dimension.calculateClosestBiomeFromSeed(position, biomeId, { boundingSize: supportedBiomeSearchBounds })
            : dimension.calculateClosestBiomeFromSeed(position, biomeId);
    }
    for (const bounds of GYM_BIOME_SEARCH_BOUNDING_PRESETS) {
        try {
            const found = dimension.calculateClosestBiomeFromSeed(position, biomeId, { boundingSize: bounds });
            supportedBiomeSearchBounds = bounds;
            biomeSearchBoundsResolved = true;
            return found;
        } catch (error) {
            if (!/Invalid bounding box [xyz] size/i.test(String(error))) throw error;
        }
    }
    biomeSearchBoundsResolved = true;
    supportedBiomeSearchBounds = undefined;
    return dimension.calculateClosestBiomeFromSeed(position, biomeId);
}

function nearestRecordedGym(index, origin) {
    let nearest;
    let nearestDistance = Number.POSITIVE_INFINITY;
    for (const location of gymLocations(index)) {
        const distance = horizontalDistanceSquared(origin, location);
        if (distance < nearestDistance) {
            nearest = location;
            nearestDistance = distance;
        }
    }
    return nearest;
}

function finishGymAssignmentSearch(player, index, location) {
    const checks = assignmentSearches.get(player.id)?.checks || 0;
    assignmentSearches.delete(player.id);
    if (!rememberGymAssignment(player, index, location)) return;
    console.info(
        `[CobbleDrockGym] Assigned ${GYMS[index].type} gym to ${player.name} `
        + `at ${Math.floor(location.x)}, ${Math.floor(location.z)} after ${checks} checks.`
    );
    syncLocator(player);
}

function gymVerificationOptions(dimension, candidate) {
    const padding = GYM_VERIFICATION_CHUNK_RADIUS * 16;
    const heightRange = dimension.heightRange || { min: -64, max: 320 };
    return {
        dimension,
        from: {
            x: candidate.x - padding,
            y: heightRange.min,
            z: candidate.z - padding
        },
        to: {
            x: candidate.x + 15 + padding,
            y: heightRange.max - 1,
            z: candidate.z + 15 + padding
        }
    };
}

function verifiedLeaderNearCandidate(dimension, index, candidate) {
    const center = { x: candidate.x + 8, z: candidate.z + 8 };
    let nearest;
    let nearestDistance = Number.POSITIVE_INFINITY;
    for (const leader of dimension.getEntities({ type: LEADER_ENTITY })) {
        if (configureLeader(leader) !== index) continue;
        const distance = horizontalDistanceSquared(center, leader.location);
        if (distance > GYM_ASSIGNMENT_REFINEMENT_DISTANCE ** 2 || distance >= nearestDistance) continue;
        nearest = leader;
        nearestDistance = distance;
    }
    return nearest?.location ? { ...nearest.location } : undefined;
}

async function verifyGymCandidate(dimension, index, candidate) {
    const manager = world.tickingAreaManager;
    if (!manager?.createTickingArea || !manager?.removeTickingArea) {
        throw new Error("temporary ticking areas are unavailable");
    }
    const options = gymVerificationOptions(dimension, candidate);
    if (!manager.hasCapacity(options)) return { retry: true };
    const areaId = `cv_gym_verify_${++gymVerificationSequence}`;
    await manager.createTickingArea(areaId, options);
    try {
        for (let elapsed = 0; elapsed <= GYM_VERIFICATION_TIMEOUT_TICKS; elapsed += GYM_VERIFICATION_POLL_TICKS) {
            const location = verifiedLeaderNearCandidate(dimension, index, candidate);
            if (location) return { location };
            await new Promise(resolve => system.runTimeout(resolve, GYM_VERIFICATION_POLL_TICKS));
        }
        return { location: undefined };
    } finally {
        try { manager.removeTickingArea(areaId); }
        catch (error) {}
    }
}

function beginGymCandidateVerification(player, search, candidate) {
    search.verifying = true;
    verifyGymCandidate(player.dimension, search.gymIndex, candidate).then(result => {
        const active = assignmentSearches.get(player.id);
        if (active !== search) return;
        search.verifying = false;
        if (!player.isValid
            || player.dimension.id !== "minecraft:overworld"
            || badgeCount(badgeMask(player)) !== search.gymIndex) {
            assignmentSearches.delete(player.id);
            return;
        }
        if (result.retry) {
            system.runTimeout(() => continueGymAssignmentSearch(player.id), 20);
            return;
        }
        search.verifications += 1;
        if (result.location) {
            finishGymAssignmentSearch(player, search.gymIndex, result.location);
            return;
        }
        search.candidateIndex += 1;
        search.biomeIndex = 0;
        if (search.verifications >= GYM_ASSIGNMENT_MAX_VERIFICATIONS) {
            search.candidateIndex = search.candidates.length;
        }
        system.run(() => continueGymAssignmentSearch(player.id));
    }).catch(error => {
        if (assignmentSearches.get(player.id) === search) assignmentSearches.delete(player.id);
        console.warn(`[CobbleDrockGym] Could not verify ${GYMS[search.gymIndex].type} gym generation: ${error}`);
    });
}

function continueGymAssignmentSearch(playerId) {
    const search = assignmentSearches.get(playerId);
    if (!search || search.verifying) return;
    const player = world.getAllPlayers().find(candidate => candidate.id === playerId);
    if (!player?.isValid || player.dimension.id !== "minecraft:overworld") {
        assignmentSearches.delete(playerId);
        return;
    }
    const currentIndex = badgeCount(badgeMask(player));
    if (currentIndex !== search.gymIndex || currentIndex >= GYMS.length) {
        assignmentSearches.delete(playerId);
        return;
    }
    if (readGymAssignment(player, currentIndex)) {
        assignmentSearches.delete(playerId);
        syncLocator(player);
        return;
    }
    if (search.candidateIndex >= search.candidates.length) {
        const recorded = nearestRecordedGym(currentIndex, search.origin);
        assignmentSearches.delete(playerId);
        if (recorded) finishGymAssignmentSearch(player, currentIndex, recorded);
        else console.warn(`[CobbleDrockGym] No ${GYMS[currentIndex].type} gym candidate found for ${player.name}.`);
        return;
    }

    try {
        for (let checked = 0; checked < GYM_ASSIGNMENT_SEARCHES_PER_TICK; checked++) {
            if (search.candidateIndex >= search.candidates.length) break;
            const candidate = search.candidates[search.candidateIndex];
            const biomeId = search.biomeIds[search.biomeIndex];
            const found = calculateCandidateBiome(
                player.dimension,
                { x: candidate.x + 8, y: 96, z: candidate.z + 8 },
                biomeId
            );
            search.checks += 1;
            if (candidateBiomeMatchesStart(candidate, found)) {
                beginGymCandidateVerification(player, search, candidate);
                return;
            }
            search.biomeIndex += 1;
            if (search.biomeIndex >= search.biomeIds.length) {
                search.biomeIndex = 0;
                search.candidateIndex += 1;
            }
        }
    } catch (error) {
        assignmentSearches.delete(playerId);
        console.warn(`[CobbleDrockGym] Could not assign ${GYMS[currentIndex].type} gym for ${player.name}: ${error}`);
        return;
    }
    system.run(() => continueGymAssignmentSearch(playerId));
}

function primeGymAssignment(player) {
    if (!player?.isValid || player.dimension.id !== "minecraft:overworld") return;
    const index = badgeCount(badgeMask(player));
    if (index >= GYMS.length || readGymAssignment(player, index) || assignmentSearches.has(player.id)) return;
    const biomeIds = biomeIdsForPlacement(index);
    if (!biomeIds.length) {
        console.warn(`[CobbleDrockGym] No biome IDs match ${GYMS[index].type} gym placement.`);
        return;
    }
    try {
        const origin = { x: player.location.x, y: player.location.y, z: player.location.z };
        const candidates = randomSpreadCandidatesNear(
            world.seed,
            origin,
            GYM_NATIVE_PLACEMENTS[index],
            GYM_ASSIGNMENT_REGION_RADIUS
        );
        if (!candidates.length) throw new Error("random_spread candidate list is empty");
        assignmentSearches.set(player.id, {
            gymIndex: index,
            origin,
            candidates,
            biomeIds,
            candidateIndex: 0,
            biomeIndex: 0,
            checks: 0,
            verifications: 0,
            verifying: false
        });
        system.run(() => continueGymAssignmentSearch(player.id));
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not start ${GYMS[index].type} gym assignment for ${player.name}: ${error}`);
    }
}

function refineGymAssignment(player, index, exactLocation) {
    const assignment = readGymAssignment(player, index);
    if (!assignment || horizontalDistanceSquared(assignment, exactLocation) > GYM_ASSIGNMENT_REFINEMENT_DISTANCE ** 2) return false;
    if (distanceSquared(assignment, exactLocation) < 4) return false;
    return rememberGymAssignment(player, index, exactLocation);
}

function gymLocations(index) {
    if (gymLocationCache[index]) return gymLocationCache[index];
    let locations = [];
    try {
        const raw = world.getDynamicProperty(`${GYM_LOCATION_PROPERTY_PREFIX}${index}`);
        const parsed = typeof raw === "string" ? JSON.parse(raw) : [];
        if (Array.isArray(parsed)) {
            locations = parsed.filter(location =>
                Number.isFinite(location?.x)
                && Number.isFinite(location?.y)
                && Number.isFinite(location?.z)
            ).map(location => ({ x: location.x, y: location.y, z: location.z }));
        }
    } catch (error) {}
    gymLocationCache[index] = locations;
    return locations;
}

function rememberGymLocation(index, location) {
    if (index < 0 || index >= GYMS.length || !location) return false;
    const locations = gymLocations(index);
    if (locations.some(saved => distanceSquared(saved, location) < 4)) return false;
    locations.push({ x: location.x, y: location.y, z: location.z });
    if (locations.length > MAX_SAVED_LOCATIONS_PER_GYM) {
        locations.splice(0, locations.length - MAX_SAVED_LOCATIONS_PER_GYM);
    }
    try {
        world.setDynamicProperty(`${GYM_LOCATION_PROPERTY_PREFIX}${index}`, JSON.stringify(locations));
    } catch (error) {
        console.warn(`[CobbleDrockGym] Could not persist gym ${index + 1} location: ${error}`);
    }
    return true;
}

function registerLoadedLeaders(dimension) {
    for (const leader of dimension.getEntities({ type: LEADER_ENTITY })) configureLeader(leader);
}

function locationKey(location) {
    return `${location.x.toFixed(2)},${location.y.toFixed(2)},${location.z.toFixed(2)}`;
}

function syncLocator(player) {
    const nextIndex = badgeCount(badgeMask(player));
    if (nextIndex >= GYMS.length || player.dimension.id !== "minecraft:overworld") {
        clearLocator(player);
        return;
    }
    const assigned = readGymAssignment(player, nextIndex);
    if (!assigned) {
        clearLocator(player);
        return;
    }
    const active = activeWaypoints.get(player.id);
    const assignedKey = locationKey(assigned);
    if (active?.locationKey === assignedKey && active.gymIndex === nextIndex) return;
    clearLocator(player);
    const gym = GYMS[nextIndex];
    try {
        const waypoint = new LocationWaypoint(
            { dimension: player.dimension, ...assigned },
            {
                textureBoundsList: [{
                    lowerBound: 0,
                    texture: {
                        path: `textures/ui/gym_locator/${String(nextIndex + 1).padStart(2, "0")}_${gym.badge}_leader`,
                        iconWidth: 1,
                        iconHeight: 1
                    }
                }]
            }
        );
        player.locatorBar.addWaypoint(waypoint);
        activeWaypoints.set(player.id, { waypoint, locationKey: assignedKey, gymIndex: nextIndex });
    } catch (error) {
        console.warn(`[CobbleDrockGym] Locator waypoint failed for ${player.name}: ${error}`);
    }
}

function battleParty(index, rematch, cap) {
    const source = GYMS[index].party;
    if (!rematch) return source.map(template => ({
        ...template,
        moves: [...template.moves],
        ivs: { ...template.ivs },
        evs: { ...template.evs }
    }));
    const firstLevel = Math.max(1, cap - (source.length - 1) * 2);
    return source.map((template, slot) => ({
        ...template,
        level: Math.min(cap, firstLevel + slot * 2),
        moves: [...template.moves],
        ivs: { ...template.ivs },
        evs: { ...template.evs }
    }));
}

function leaderFacingDirection(leader) {
    const yaw = Number(leader.getRotation().y) || 0;
    const radians = yaw * Math.PI / 180;
    return { x: -Math.sin(radians), z: Math.cos(radians) };
}

function playerBattleMarker(leader, index) {
    const layout = GYM_BATTLE_LAYOUTS[index];
    if (!layout) return undefined;
    const separation = Math.hypot(
        layout.leaderMarker[0] - layout.playerMarker[0],
        layout.leaderMarker[2] - layout.playerMarker[2]
    );
    const facing = leaderFacingDirection(leader);
    const radius = Math.ceil(separation) + 1;
    const blockY = Math.floor(leader.location.y) - 1;
    let best;
    let bestFacing = Number.NEGATIVE_INFINITY;
    for (let dx = -radius; dx <= radius; dx++) {
        for (let dz = -radius; dz <= radius; dz++) {
            const x = Math.floor(leader.location.x) + dx;
            const z = Math.floor(leader.location.z) + dz;
            const targetX = x + 0.5;
            const targetZ = z + 0.5;
            const distance = Math.hypot(targetX - leader.location.x, targetZ - leader.location.z);
            if (Math.abs(distance - separation) > 0.75) continue;
            let block;
            try { block = leader.dimension.getBlock({ x, y: blockY, z }); }
            catch (error) { continue; }
            if (block?.typeId !== layout.markerBlock) continue;
            const facingScore = (targetX - leader.location.x) * facing.x
                + (targetZ - leader.location.z) * facing.z;
            if (facingScore > bestFacing) {
                bestFacing = facingScore;
                best = { x: targetX, y: block.location.y + 1, z: targetZ };
            }
        }
    }
    if (best) return best;
    return {
        x: leader.location.x + facing.x * separation,
        y: leader.location.y,
        z: leader.location.z + facing.z * separation
    };
}

function gymBattleLocations(leader, index) {
    const playerLocation = playerBattleMarker(leader, index);
    return playerLocation
        ? gymBattleLineLocations(leader.location, playerLocation, GYM_BATTLE_LAYOUTS[index]?.pokemonInsetBonus)
        : undefined;
}

function startGymBattle(player, leader, index) {
    if ([...pendingBattles.values()].some(pending => pending.playerId === player.id)) {
        send(player, gymRawMessage("message.cobbledrock.gym.battle_already_in_progress"));
        return;
    }
    const mask = badgeMask(player);
    const rematch = (mask & (1 << index)) !== 0;
    const cap = syncLevelCap(player);
    const locations = gymBattleLocations(leader, index);
    if (locations) {
        try { leader.teleport(leader.location, { facingLocation: locations.playerLocation }); }
        catch (error) {}
    }
    setLeaderBattlePose(leader, true);
    const requestId = requestCoreTrainerBattle(player, leader, {
        trainerName: GYMS[index].leader,
        party: battleParty(index, rematch, cap),
        levelCap: cap,
        enforceLevelCap: true,
        ai: { ...RCT_LEADER_AI },
        cameraSideScale: GYM_BATTLE_CAMERA_SIDE_SCALE,
        playerLocation: locations?.playerLocation,
        playerPokemonLocation: locations?.playerPokemonLocation,
        opponentLocation: locations?.opponentLocation
    });
    if (!requestId) {
        setLeaderBattlePose(leader, false);
        send(player, gymRawMessage("message.cobbledrock.gym.battle_start_failed"));
        return;
    }
    pendingBattles.set(requestId, {
        playerId: player.id,
        leaderId: leader.id,
        gymIndex: index,
        rewardContext: {
            dimensionId: leader.dimension.id,
            location: { ...leader.location }
        }
    });
}

function completeFirstClear(player, index, rewardContext) {
    const oldMask = badgeMask(player);
    const oldCount = badgeCount(oldMask);
    if ((oldMask & (1 << index)) !== 0 || index !== oldCount) return false;
    caseBadgeMask(player);
    const newMask = oldMask | (1 << index);
    player.setDynamicProperty(BADGE_MASK_PROPERTY, newMask);
    clearGymAssignment(player);
    clearLocator(player);
    const oldCap = levelCapForMask(oldMask);
    const newCap = syncLevelCap(player);
    try {
        player.onScreenDisplay.setTitle(gymRawMessage("message.cobbledrock.gym.badge_earned_title", [GYMS[index].type]), {
            subtitle: newCap > oldCap
                ? gymRawMessage("message.cobbledrock.gym.level_cap_unlocked_subtitle", [String(newCap)])
                : gymRawMessage("message.cobbledrock.gym.badge_progress_subtitle", [String(badgeCount(newMask)), String(GYMS.length)]),
            fadeInDuration: 5,
            stayDuration: 50,
            fadeOutDuration: 10
        });
    } catch (error) {}
    playGymClearSound(player);
    if (giveOrDrop(player, badgeItemId(index))) {
        send(player, badgeMessage("message.cobbledrock.gym.badge_received", index));
    } else {
        send(player, badgeMessage("message.cobbledrock.gym.badge_give_failed", index));
    }
    if (dropFirstClearItems(index, rewardContext)) {
        send(player, gymRawMessage("message.cobbledrock.gym.first_clear_reward_dropped", [GYMS[index].leader]));
    } else {
        send(player, gymRawMessage("message.cobbledrock.gym.first_clear_reward_failed"));
    }
    if (newCap > oldCap) send(player, gymRawMessage("message.cobbledrock.gym.level_cap_increased", [String(newCap)]));
    if (badgeCount(newMask) === GYMS.length) {
        send(player, gymRawMessage("message.cobbledrock.gym.all_gyms_cleared"));
        requestMewReward(player);
    }
    system.run(() => {
        primeGymAssignment(player);
        syncLocator(player);
    });
    return true;
}

function buildBadgeCaseForm(player) {
    const earned = badgeMask(player);
    const count = badgeCount(earned);
    const equipped = caseBadgeMask(player);
    const ready = carriedBadgeMask(player) & earned & ~equipped;
    const cap = syncLevelCap(player);
    if (count === GYMS.length && integerProperty(player, GYM_MEW_REWARD_STATE_PROPERTY, 0) < 2) {
        requestMewReward(player);
    }
    const stateTokens = GYMS
        .map((_, index) => {
            const bit = 1 << index;
            return `${(equipped & bit) !== 0 ? `|GYM:ON:${index}|` : ""}${(ready & bit) !== 0 ? `|GYM:HAS:${index}|` : ""}`;
        })
        .join("");
    const form = new ActionFormData()
        .title(`cobbledrock.gym_badges${stateTokens}`)
        .body(gymRawMessage("message.cobbledrock.gym.badge_case_body", [String(count), String(GYMS.length), String(cap)]))
        .button("|GYM:CLOSE|");
    for (let index = 0; index < GYMS.length; index++) form.button(`|GYM:SLOT:${index}|`);
    return form;
}

const BADGE_CASE_OPEN_PROPERTY = "lota:badge_case_open";

function setBadgeCaseOpen(player, open) {
    try { if (player?.isValid) player.setProperty(BADGE_CASE_OPEN_PROPERTY, !!open); } catch (error) {}
}

function isBadgeCaseOpen(player) {
    try { return player?.getProperty(BADGE_CASE_OPEN_PROPERTY) === true; } catch (error) { return false; }
}

const BADGE_UI_STATE_EVENT = "lota:gym_badge_state_v1";
const BADGE_UI_REQUEST_EVENT = "lota:gym_badge_request_v1";
const BADGE_UI_CLICK_EVENT = "lota:gym_badge_click_v1";
const BADGE_UI_FORM_TAG = "lota:menu_form";

function badgeCaseChestOn(player) {
    try { return !player.hasTag(BADGE_UI_FORM_TAG); } catch (error) { return true; }
}

function pushBadgeState(player) {
    if (!player?.isValid) return;
    try {
        system.sendScriptEvent(BADGE_UI_STATE_EVENT, JSON.stringify({
            playerId: player.id,
            earned: badgeMask(player),
            equipped: caseBadgeMask(player),
            cap: syncLevelCap(player)
        }));
    } catch (error) {}
}

function isHoldingBadgeCase(player) {
    try {
        return playerContainer(player)?.getItem(player.selectedSlotIndex)?.typeId === BADGE_CASE_ITEM;
    } catch (error) { return false; }
}

function clearBadgeFormRequest(playerId, requestToken) {
    const current = activeBadgeFormRequests.get(playerId);
    if (!current || current.token !== requestToken) return false;
    activeBadgeFormRequests.delete(playerId);
    return true;
}

function openBadgeCaseForm(player) {
    const token = nextBadgeRequestToken++;
    activeBadgeFormRequests.set(player.id, { token, attempt: 0 });
    system.runTimeout(() => {
        showBadgeCase(player, 0, token);
    }, BADGE_FORM_RETRY_DELAY_TICKS);
}

function onBadgeCasePress(player) {
    if (!player?.isValid) return;
    const now = system.currentTick;
    if (now - (badgeCaseLastPress.get(player.id) ?? -100) < 3) return;
    badgeCaseLastPress.set(player.id, now);
    if (isBadgeCaseOpen(player)) {
        badgeCaseHolds.delete(player.id);
        if (badgeCaseChestOn(player)) {
            pushBadgeState(player);
            return;
        }
        openBadgeCaseForm(player);
        return;
    }
    badgeCaseHolds.set(player.id, now);
}

function resetBadgeCaseState(playerId) {
    badgeCaseHolds.delete(playerId);
    badgeCaseLastPress.delete(playerId);
    badgeCaseSneaking.delete(playerId);
}

async function showBadgeCase(player, attempt = 0, requestToken) {
    if (!player?.isValid) return;
    const active = activeBadgeFormRequests.get(player.id);
    if (!active || active.token !== requestToken) return;

    try {
        const form = buildBadgeCaseForm(player);
        const response = await form.show(player);
        if (!player?.isValid) {
            clearBadgeFormRequest(player.id, requestToken);
            return;
        }
        const current = activeBadgeFormRequests.get(player.id);
        if (!current || current.token !== requestToken) return;

        if (!response.canceled) {
            const slotIndex = Number(response.selection) - BADGE_SLOT_BUTTON_OFFSET;
            if (Number.isInteger(slotIndex) && slotIndex >= 0 && slotIndex < GYMS.length) {
                handleBadgeSlotClick(player, slotIndex);
                activeBadgeFormRequests.set(player.id, { token: requestToken, attempt: 0 });
                system.runTimeout(() => {
                    showBadgeCase(player, 0, requestToken);
                }, BADGE_FORM_RETRY_DELAY_TICKS);
                return;
            }
            clearBadgeFormRequest(player.id, requestToken);
            return;
        }

        const reason = String(response.cancelationReason || "");
        if (reason === "UserBusy" || reason === "FormValuesNotInitialized" || reason.toLowerCase().includes("busy")) {
            if (attempt < BADGE_FORM_BUSY_RETRIES) {
                const nextAttempt = attempt + 1;
                activeBadgeFormRequests.set(player.id, { token: requestToken, attempt: nextAttempt });
                system.runTimeout(() => {
                    showBadgeCase(player, nextAttempt, requestToken);
                }, BADGE_FORM_RETRY_DELAY_TICKS);
                return;
            }
            clearBadgeFormRequest(player.id, requestToken);
            console.warn(`[CobbleDrockGym] Badge case form retries exhausted for ${player.name} (reason: ${reason})`);
            return;
        }

        if (reason === "UserClosed") {
            clearBadgeFormRequest(player.id, requestToken);
            return;
        }

        clearBadgeFormRequest(player.id, requestToken);
        console.warn(`[CobbleDrockGym] Badge case form canceled for ${player.name} (reason: ${reason})`);
    } catch (error) {
        if (clearBadgeFormRequest(player?.id, requestToken)) {
            console.warn(`[CobbleDrockGym] Badge case form failed for ${player?.name || player?.id}: ${error}`);
        }
    }
}

world.afterEvents.itemUse.subscribe(event => {
    if (event.source?.typeId !== "minecraft:player") return;
    const player = event.source;
    if (!player?.isValid) return;
    const usedIndex = badgeIndexForItem(event.itemStack?.typeId);
    if (usedIndex >= 0) {
        system.run(() => {
            if (player?.isValid) equipBadge(player, usedIndex);
        });
        return;
    }
    if (event.itemStack?.typeId !== BADGE_CASE_ITEM) return;
    onBadgeCasePress(player);
});

if (world.afterEvents.itemStartUse?.subscribe) {
    world.afterEvents.itemStartUse.subscribe(event => {
        if (event.source?.typeId !== "minecraft:player") return;
        if (event.itemStack?.typeId !== BADGE_CASE_ITEM) return;
        onBadgeCasePress(event.source);
    });
}

function cancelBadgeCaseHold(event) {
    const player = event?.source;
    if (player?.typeId !== "minecraft:player") return;
    badgeCaseHolds.delete(player.id);
}
world.afterEvents.itemStopUse?.subscribe(cancelBadgeCaseHold);
world.afterEvents.itemReleaseUse?.subscribe(cancelBadgeCaseHold);
world.afterEvents.itemCompleteUse?.subscribe(cancelBadgeCaseHold);

system.runInterval(() => {
    const now = system.currentTick;
    for (const player of world.getAllPlayers()) {
        const sneaking = player.isSneaking === true;
        const justSneaked = sneaking && badgeCaseSneaking.get(player.id) !== true;
        badgeCaseSneaking.set(player.id, sneaking);

        const open = isBadgeCaseOpen(player);
        const holdStart = badgeCaseHolds.get(player.id);
        if (!open && holdStart === undefined) continue;

        if (!isHoldingBadgeCase(player)) {
            badgeCaseHolds.delete(player.id);
            activeBadgeFormRequests.delete(player.id);
            if (open) setBadgeCaseOpen(player, false);
            continue;
        }

        if (open) {
            if (justSneaked) {
                activeBadgeFormRequests.delete(player.id);
                setBadgeCaseOpen(player, false);
            }
            continue;
        }

        if (now - holdStart >= BADGE_CASE_HOLD_TICKS) {
            badgeCaseHolds.delete(player.id);
            setBadgeCaseOpen(player, true);
            pushBadgeState(player);
        }
    }
}, 2);

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== BADGE_UI_REQUEST_EVENT && event.id !== BADGE_UI_CLICK_EVENT) return;
    let payload;
    try {
        payload = event.id === BADGE_UI_CLICK_EVENT ? JSON.parse(event.message) : { playerId: event.message };
    } catch (error) { return; }
    const playerId = String(payload?.playerId ?? "");
    system.run(() => {
        const player = world.getAllPlayers().find(candidate => candidate.id === playerId);
        if (!player?.isValid) return;
        if (event.id === BADGE_UI_CLICK_EVENT) {
            const index = Number(payload.index);
            if (!Number.isInteger(index) || index < 0 || index >= GYMS.length) return;
            if (!isBadgeCaseOpen(player) || !isHoldingBadgeCase(player)) return;
            handleBadgeSlotClick(player, index);
        }
        pushBadgeState(player);
    });
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== TEST_GYM_CLEAR_EVENT || event.sourceEntity?.typeId !== "minecraft:player") return;
    const player = event.sourceEntity;
    system.run(() => {
        if (!player?.isValid) return;
        const index = badgeCount(badgeMask(player));
        if (index >= GYMS.length) {
            send(player, gymRawMessage("message.cobbledrock.gym.test_all_cleared"));
            return;
        }
        if ([...pendingBattles.values()].some(pending => pending.playerId === player.id)) {
            send(player, gymRawMessage("message.cobbledrock.gym.test_battle_in_progress"));
            return;
        }
        const location = { ...player.location };
        if (completeFirstClear(player, index, { dimensionId: player.dimension.id, location })) {
            send(player, gymRawMessage("message.cobbledrock.gym.test_clear_executed", [GYMS[index].leader]));
        }
    });
});

world.afterEvents.playerInteractWithEntity.subscribe(event => {
    const player = event.player;
    const leader = event.target;
    if (leader?.typeId !== LEADER_ENTITY || !player?.isValid) return;
    system.run(() => {
        if (!leader?.isValid || !player?.isValid) return;
        const index = configureLeader(leader);
        const nextIndex = badgeCount(badgeMask(player));
        if (index < 0 || index >= GYMS.length) return;
        if (index > nextIndex) {
            send(player, gymRawMessage("message.cobbledrock.gym.order_required"));
            return;
        }
        const lastTick = interactionCooldowns.get(player.id) || -100;
        if (system.currentTick - lastTick < 20) return;
        interactionCooldowns.set(player.id, system.currentTick);
        startGymBattle(player, leader, index);
    });
});

subscribeCoreTrainerResult(result => {
    const requestId = String(result?.requestId || "");
    const pending = pendingBattles.get(requestId);
    if (!pending || result.outcome === "started") return;
    pendingBattles.delete(requestId);
    releaseLeaderBattlePose(pending.leaderId);
    const player = world.getAllPlayers().find(candidate => candidate.id === pending.playerId);
    if (!player?.isValid) return;
    if (result.outcome === "victory") {
        if (!completeFirstClear(player, pending.gymIndex, pending.rewardContext)) {
            send(player, gymRawMessage("message.cobbledrock.gym.rematch_victory"));
        }
    } else if (result.outcome === "loss") {
        send(player, gymRawMessage("message.cobbledrock.gym.battle_loss", [GYMS[pending.gymIndex].leader]));
    } else if (result.outcome === "rejected" && result.detail) {
        send(player, gymRawMessage("message.cobbledrock.gym.battle_start_rejected", [result.detail]));
    }
});

subscribeCorePokemonGrantResult(result => {
    const requestId = String(result?.requestId || "");
    const pending = pendingMewRewards.get(requestId);
    if (!pending) return;
    pendingMewRewards.delete(requestId);
    const player = world.getAllPlayers().find(candidate => candidate.id === pending.playerId);
    if (!player?.isValid) return;
    if (result.outcome === "granted") {
        player.setDynamicProperty(GYM_MEW_REWARD_STATE_PROPERTY, 2);
        const destKey = result.storage?.location === "PC_BOX"
            ? "message.cobbledrock.gym.mew_destination_pc"
            : "message.cobbledrock.gym.mew_destination_party";
        send(player, {
            rawtext: [{
                translate: "message.cobbledrock.gym.mew_reward_granted",
                with: [{ translate: destKey }]
            }]
        });
        return;
    }
    player.setDynamicProperty(GYM_MEW_REWARD_STATE_PROPERTY, 0);
    send(player, gymRawMessage("message.cobbledrock.gym.mew_reward_failed", [result.detail || "unknown"]));
});

world.afterEvents.playerSpawn.subscribe(event => {
    system.runTimeout(() => {
        const player = event.player;
        if (!player?.isValid) return;
        resetBadgeCaseState(player.id);
        setBadgeCaseOpen(player, false);
        ensureBadgeCase(player);
        caseBadgeMask(player);
        syncLevelCap(player);
        if (badgeCount(badgeMask(player)) === GYMS.length
            && integerProperty(player, GYM_MEW_REWARD_STATE_PROPERTY, 0) < 2) {
            requestMewReward(player);
        }
        registerLoadedLeaders(player.dimension);
        primeGymAssignment(player);
        syncLocator(player);
    }, 20);
});

function activateLoadedGymLeader(leader) {
    if (leader?.typeId !== LEADER_ENTITY) return;
    system.run(() => {
        const index = configureLeader(leader);
        if (index < 0) return;
        registerLoadedLeaders(leader.dimension);
        for (const player of world.getAllPlayers()) {
            refineGymAssignment(player, index, leader.location);
            syncLocator(player);
        }
    });
}

world.afterEvents.entitySpawn.subscribe(event => {
    activateLoadedGymLeader(event.entity);
});

if (world.afterEvents.entityLoad?.subscribe) {
    world.afterEvents.entityLoad.subscribe(event => {
        activateLoadedGymLeader(event.entity);
    });
}

world.afterEvents.playerLeave.subscribe(event => {
    activeBadgeFormRequests.delete(event.playerId);
    resetBadgeCaseState(event.playerId);
    activeWaypoints.delete(event.playerId);
    assignmentSearches.delete(event.playerId);
    syncedLevelCaps.delete(event.playerId);
    interactionCooldowns.delete(event.playerId);
    for (const [requestId, pending] of pendingBattles) {
        if (pending.playerId === event.playerId) {
            pendingBattles.delete(requestId);
            releaseLeaderBattlePose(pending.leaderId);
        }
    }
    for (const [requestId, pending] of pendingMewRewards) {
        if (pending.playerId === event.playerId) pendingMewRewards.delete(requestId);
    }
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        syncLevelCap(player);
        syncLocator(player);
    }
    releaseStaleLeaderPoses();
}, 40);
