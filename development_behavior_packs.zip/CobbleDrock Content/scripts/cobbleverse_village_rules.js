import {
    VILLAGE_CENTERS,
    VILLAGE_HOUSES,
    VILLAGE_LAYOUTS,
    VILLAGE_ONE_OFFS,
    VILLAGE_TYPES
} from "./cobbleverse_village_data.js";

export const VILLAGE_SPACING_CHUNKS = 50;
export const VILLAGE_SEPARATION_CHUNKS = 25;
export const VILLAGE_SALT = 31415926;

const DEFAULT_VILLAGE_BIOMES = new Set([
    "plains",
    "meadow",
    "desert",
    "savanna",
    "snowy_plains",
    "ice_plains",
    "taiga"
]);
const DARK_VILLAGE_BIOMES = new Set([
    "dark_forest",
    "roofed_forest",
    "mushroom_fields",
    "mushroom_island",
    "swamp",
    "swampland",
    "mangrove_swamp"
]);
const FIGHTING_VILLAGE_BIOMES = new Set([
    "sunflower_plains",
    "plains",
    "savanna",
    "meadow",
    "savanna_plateau"
]);

export function villageHash(...values) {
    let hash = 0x811c9dc5;
    for (const value of values) {
        let number = Math.trunc(Number(value) || 0);
        for (let byte = 0; byte < 4; byte++) {
            hash ^= number & 0xff;
            hash = Math.imul(hash, 0x01000193);
            number >>= 8;
        }
    }
    hash ^= hash >>> 16;
    hash = Math.imul(hash, 0x7feb352d);
    hash ^= hash >>> 15;
    hash = Math.imul(hash, 0x846ca68b);
    return (hash ^ (hash >>> 16)) >>> 0;
}

export function villageRegionForBlock(x, z) {
    const chunkX = Math.floor(Number(x) / 16);
    const chunkZ = Math.floor(Number(z) / 16);
    return {
        x: Math.floor(chunkX / VILLAGE_SPACING_CHUNKS),
        z: Math.floor(chunkZ / VILLAGE_SPACING_CHUNKS)
    };
}

export function villageCandidate(regionX, regionZ, worldSeed = 0) {
    const spread = VILLAGE_SPACING_CHUNKS - VILLAGE_SEPARATION_CHUNKS;
    const firstX = villageHash(worldSeed, regionX, regionZ, VILLAGE_SALT, 1) % spread;
    const secondX = villageHash(worldSeed, regionX, regionZ, VILLAGE_SALT, 2) % spread;
    const firstZ = villageHash(worldSeed, regionX, regionZ, VILLAGE_SALT, 3) % spread;
    const secondZ = villageHash(worldSeed, regionX, regionZ, VILLAGE_SALT, 4) % spread;
    const chunkX = regionX * VILLAGE_SPACING_CHUNKS + Math.floor((firstX + secondX) / 2);
    const chunkZ = regionZ * VILLAGE_SPACING_CHUNKS + Math.floor((firstZ + secondZ) / 2);
    return {
        regionX,
        regionZ,
        chunkX,
        chunkZ,
        x: chunkX * 16 + 8,
        z: chunkZ * 16 + 8
    };
}

export function normalizedBiomeId(value) {
    return String(value?.id || value || "")
        .replace(/^minecraft:/, "")
        .toLowerCase();
}

export function villageThemesForBiome(biome) {
    const id = normalizedBiomeId(biome);
    const themes = [];
    if (DEFAULT_VILLAGE_BIOMES.has(id)) themes.push("default");
    if (DARK_VILLAGE_BIOMES.has(id)) themes.push("dark");
    if (FIGHTING_VILLAGE_BIOMES.has(id)) themes.push("fighting");
    return themes;
}

export function weightedChoice(entries, roll) {
    const total = entries.reduce((sum, entry) => sum + Math.max(0, Number(entry.weight) || 0), 0);
    if (total <= 0 || !entries.length) return undefined;
    let cursor = (Number(roll) >>> 0) % total;
    for (const entry of entries) {
        cursor -= Math.max(0, Number(entry.weight) || 0);
        if (cursor < 0) return entry;
    }
    return entries[entries.length - 1];
}

export function chooseVillageType(biome, regionX, regionZ, worldSeed = 0) {
    const themes = new Set(villageThemesForBiome(biome));
    const eligible = VILLAGE_TYPES.filter(entry => themes.has(entry.theme));
    return weightedChoice(
        eligible,
        villageHash(worldSeed, regionX, regionZ, VILLAGE_SALT, 20)
    );
}

function deterministicPick(values, seed, used = new Set()) {
    if (!values.length) return undefined;
    const available = values.filter(value => !used.has(value));
    const pool = available.length ? available : values;
    const value = pool[villageHash(seed, pool.length, used.size) % pool.length];
    used.add(value);
    return value;
}

export function buildVillagePlan(candidate, type, worldSeed = 0) {
    const seed = villageHash(worldSeed, candidate.regionX, candidate.regionZ, VILLAGE_SALT, 30);
    const centers = VILLAGE_CENTERS[type.theme]?.[type.size] || [];
    const center = deterministicPick(centers, seed);
    const pieces = center ? [{ structure: center, dx: 0, dz: 0, kind: "center" }] : [];
    const slots = VILLAGE_LAYOUTS[type.size] || VILLAGE_LAYOUTS.small;
    const oneOffs = VILLAGE_ONE_OFFS[type.theme] || [];
    const houses = VILLAGE_HOUSES[type.theme] || [];
    const used = new Set();

    for (let index = 0; index < slots.length; index++) {
        const [dx, dz] = slots[index];
        const oneOffLimit = type.size === "small" ? 2 : type.size === "mid" ? 3 : 4;
        const useOneOff = index < Math.min(oneOffLimit, oneOffs.length);
        const pool = useOneOff ? oneOffs : houses;
        const mandatoryDefaultOneOff = type.theme === "default" && index < 2
            ? oneOffs[index]
            : undefined;
        const structure = mandatoryDefaultOneOff
            || deterministicPick(pool, seed + index * 97, used);
        if (mandatoryDefaultOneOff) used.add(mandatoryDefaultOneOff);
        if (!structure) continue;
        pieces.push({
            structure,
            dx,
            dz,
            kind: useOneOff ? "one_off" : "house"
        });
    }

    return {
        version: 1,
        id: `${candidate.regionX}:${candidate.regionZ}`,
        regionX: candidate.regionX,
        regionZ: candidate.regionZ,
        x: candidate.x,
        z: candidate.z,
        type: type.id,
        theme: type.theme,
        size: type.size,
        pieces: pieces.map(piece => ({ ...piece, placed: false })),
        roles: {}
    };
}

export function villagePropertyId(regionX, regionZ) {
    return `lota:village:${regionX}:${regionZ}`;
}

export function squaredHorizontalDistance(first, second) {
    const dx = Number(first.x) - Number(second.x);
    const dz = Number(first.z) - Number(second.z);
    return dx * dx + dz * dz;
}
