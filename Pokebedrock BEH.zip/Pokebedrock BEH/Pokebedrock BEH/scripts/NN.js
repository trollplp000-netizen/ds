import { world, system, EntityInitializationCause } from "@minecraft/server";

const NEARBY_RADIUS = 60;
const ANNOUNCE_DELAY_TICKS = 5;

const COLORS = {
  normal: "\u00a77",
  highlight: "\u00a7f",
  nearPlayer: "\u00a7a",
  reset: "\u00a7r",
  tiers: {
    Legendary: "\u00a75",
    Mythical: "\u00a74",
    "Ultra Beast": "\u00a7b",
    Paradox: "\u00a72",
  },
};

const DIMENSION_NAMES = {
  overworld: "the Overworld",
  nether: "the Nether",
  the_end: "the End",
};

const RARITY_TIER = {};
const DISPLAY_NAME = {};

function register(tier, entries) {
  for (const [id, name] of Object.entries(entries)) {
    RARITY_TIER[id] = tier;
    DISPLAY_NAME[id] = name;
  }
}

register("Legendary", {
  articuno: "Articuno",
  articunogalar: "Articuno-Galar",
  zapdos: "Zapdos",
  zapdosgalar: "Zapdos-Galar",
  moltres: "Moltres",
  moltresgalar: "Moltres-Galar",
  raikou: "Raikou",
  entei: "Entei",
  suicune: "Suicune",
  lugia: "Lugia",
  hooh: "Ho-Oh",
  regirock: "Regirock",
  regice: "Regice",
  registeel: "Registeel",
  latias: "Latias",
  latiasmega: "Latias-Mega",
  latios: "Latios",
  latiosmega: "Latios-Mega",
  kyogre: "Kyogre",
  kyogreprimal: "Kyogre-Primal",
  groudon: "Groudon",
  groudonprimal: "Groudon-Primal",
  rayquaza: "Rayquaza",
  rayquazamega: "Rayquaza-Mega",
  uxie: "Uxie",
  mesprit: "Mesprit",
  azelf: "Azelf",
  dialga: "Dialga",
  dialgaorigin: "Dialga-Origin",
  palkia: "Palkia",
  palkiaorigin: "Palkia-Origin",
  heatran: "Heatran",
  regigigas: "Regigigas",
  giratina: "Giratina",
  giratinaorigin: "Giratina-Origin",
  cresselia: "Cresselia",
  cobalion: "Cobalion",
  terrakion: "Terrakion",
  virizion: "Virizion",
  tornadus: "Tornadus",
  tornadustherian: "Tornadus-Therian",
  thundurus: "Thundurus",
  thundurustherian: "Thundurus-Therian",
  landorus: "Landorus",
  landorustherian: "Landorus-Therian",
  reshiram: "Reshiram",
  zekrom: "Zekrom",
  kyurem: "Kyurem",
  kyuremblack: "Kyurem-Black",
  kyuremwhite: "Kyurem-White",
  xerneas: "Xerneas",
  yveltal: "Yveltal",
  zygarde: "Zygarde",
  zygarde10: "Zygarde-10%",
  zygardecomplete: "Zygarde-Complete",
  tapukoko: "Tapu Koko",
  tapulele: "Tapu Lele",
  tapubulu: "Tapu Bulu",
  tapufini: "Tapu Fini",
  cosmog: "Cosmog",
  cosmoem: "Cosmoem",
  solgaleo: "Solgaleo",
  lunala: "Lunala",
  necrozma: "Necrozma",
  necrozmaduskmane: "Necrozma-Dusk-Mane",
  necrozmadawnwings: "Necrozma-Dawn-Wings",
  necrozmaultra: "Necrozma-Ultra",
  zacian: "Zacian",
  zaciancrowned: "Zacian-Crowned",
  zamazenta: "Zamazenta",
  zamazentacrowned: "Zamazenta-Crowned",
  eternatus: "Eternatus",
  eternatuseternamax: "Eternatus-Eternamax",
  kubfu: "Kubfu",
  urshifu: "Urshifu",
  urshifurapidstrike: "Urshifu-Rapid-Strike",
  urshifusinglestrike: "Urshifu-Single-Strike",
  regieleki: "Regieleki",
  regidrago: "Regidrago",
  glastrier: "Glastrier",
  spectrier: "Spectrier",
  calyrex: "Calyrex",
  calyrexice: "Calyrex-Ice",
  calyrexshadow: "Calyrex-Shadow",
  enamorus: "Enamorus",
  enamorustherian: "Enamorus-Therian",
  wochien: "Wo-Chien",
  chienpao: "Chien-Pao",
  tinglu: "Ting-Lu",
  chiyu: "Chi-Yu",
  koraidon: "Koraidon",
  miraidon: "Miraidon",
  walkingwake: "Walking Wake",
  ironleaves: "Iron Leaves",
  okidogi: "Okidogi",
  munkidori: "Munkidori",
  fezandipiti: "Fezandipiti",
  ogerpon: "Ogerpon",
  ogerponwellspring: "Ogerpon-Wellspring",
  ogerponhearthflame: "Ogerpon-Hearthflame",
  ogerponcornerstone: "Ogerpon-Cornerstone",
  terapagos: "Terapagos",
  terapagosterastal: "Terapagos-Terastal",
  terapagosstellar: "Terapagos-Stellar",
  pecharunt: "Pecharunt",
});

register("Mythical", {
  mew: "Mew",
  celebi: "Celebi",
  jirachi: "Jirachi",
  deoxys: "Deoxys",
  deoxysattack: "Deoxys-Attack",
  deoxysdefense: "Deoxys-Defense",
  deoxysspeed: "Deoxys-Speed",
  phione: "Phione",
  manaphy: "Manaphy",
  darkrai: "Darkrai",
  shaymin: "Shaymin",
  shayminsky: "Shaymin-Sky",
  arceus: "Arceus",
  victini: "Victini",
  keldeo: "Keldeo",
  keldeoresolute: "Keldeo-Resolute",
  meloetta: "Meloetta",
  meloettapirouette: "Meloetta-Pirouette",
  genesect: "Genesect",
  diancie: "Diancie",
  dianciemega: "Diancie-Mega",
  hoopa: "Hoopa",
  hoopaunbound: "Hoopa-Unbound",
  volcanion: "Volcanion",
  magearna: "Magearna",
  magearnaoriginal: "Magearna-Original",
  marshadow: "Marshadow",
  zeraora: "Zeraora",
  meltan: "Meltan",
  melmetal: "Melmetal",
  zarude: "Zarude",
  zarudedada: "Zarude-Dada",
});

register("Ultra Beast", {
  nihilego: "Nihilego",
  buzzwole: "Buzzwole",
  pheromosa: "Pheromosa",
  xurkitree: "Xurkitree",
  celesteela: "Celesteela",
  kartana: "Kartana",
  guzzlord: "Guzzlord",
  poipole: "Poipole",
  naganadel: "Naganadel",
  stakataka: "Stakataka",
  blacephalon: "Blacephalon",
});

register("Paradox", {
  greattusk: "Great Tusk",
  screamtail: "Scream Tail",
  brutebonnet: "Brute Bonnet",
  fluttermane: "Flutter Mane",
  slitherwing: "Slither Wing",
  sandyshocks: "Sandy Shocks",
  irontreads: "Iron Treads",
  ironbundle: "Iron Bundle",
  ironhands: "Iron Hands",
  ironjugulis: "Iron Jugulis",
  ironmoth: "Iron Moth",
  ironthorns: "Iron Thorns",
  roaringmoon: "Roaring Moon",
  ironvaliant: "Iron Valiant",
  walkingwake: "Walking Wake",
  ironleaves: "Iron Leaves",
  gougingfire: "Gouging Fire",
  ragingbolt: "Raging Bolt",
  ironboulder: "Iron Boulder",
  ironcrown: "Iron Crown",
});

function formatBiomeName(biomeId) {
  const raw = biomeId.includes(":") ? biomeId.split(":")[1] : biomeId;
  return raw
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function formatDimensionName(dimensionId) {
  const raw = dimensionId.includes(":") ? dimensionId.split(":")[1] : dimensionId;
  return DIMENSION_NAMES[raw] ?? raw;
}

function findNearestPlayer(entity) {
  let nearest;
  let nearestDistanceSq = NEARBY_RADIUS * NEARBY_RADIUS;

  for (const player of world.getAllPlayers()) {
    if (player.dimension.id !== entity.dimension.id) continue;

    const dx = player.location.x - entity.location.x;
    const dy = player.location.y - entity.location.y;
    const dz = player.location.z - entity.location.z;
    const distanceSq = dx * dx + dy * dy + dz * dz;

    if (distanceSq <= nearestDistanceSq) {
      nearest = player;
      nearestDistanceSq = distanceSq;
    }
  }

  return nearest;
}

function announceSpawn(entity, tier, pokemonName) {
  let biomeName;
  try {
    biomeName = formatBiomeName(entity.dimension.getBiome(entity.location).id);
  } catch {
    return;
  }

  const tierColor = COLORS.tiers[tier] ?? COLORS.highlight;

  let message =
    `${COLORS.normal}The ${tierColor}${tier}${COLORS.normal} ` +
    `${COLORS.highlight}${pokemonName}${COLORS.normal} spawned in a ` +
    `${COLORS.highlight}${biomeName}${COLORS.normal} biome!`;

  const nearestPlayer = findNearestPlayer(entity);
  if (nearestPlayer) {
    const dimensionName = formatDimensionName(entity.dimension.id);
    const x = Math.floor(entity.location.x);
    const y = Math.floor(entity.location.y);
    const z = Math.floor(entity.location.z);

    message =
      `${COLORS.normal}The ${tierColor}${tier}${COLORS.normal} ` +
      `${COLORS.highlight}${pokemonName}${COLORS.normal} spawned in a ` +
      `${COLORS.highlight}${biomeName}${COLORS.normal} biome in ` +
      `${COLORS.highlight}${dimensionName}${COLORS.normal} at ` +
      `${COLORS.highlight}${x}, ${y}, ${z}${COLORS.normal}! ` +
      `${COLORS.normal}(near ${COLORS.nearPlayer}${nearestPlayer.name}${COLORS.normal})`;
  }

  world.sendMessage(message + COLORS.reset);
}

const originalSendMessage = world.sendMessage.bind(world);
world.sendMessage = function (msg) {
  if (typeof msg === "string") {
    const lower = msg.toLowerCase();
    if (
      (lower.includes("has spawned near") || lower.includes("has spawned")) &&
      (lower.includes("legendary") ||
        lower.includes("mythical") ||
        lower.includes("paradox") ||
        lower.includes("ultra beast") ||
        lower.includes("pokémon") ||
        lower.includes("pokemon"))
    ) {
      return; 
    }
  }
  return originalSendMessage(msg);
};


const SHINY_DAY_OBJECTIVE_ID = "pokeb_shinyday";
const SHINY_DAY_KEYS = {
  init: "__init",
  activeDay: "__active_day",
  mult: "__mult",
  all: "__all",
  until: "__until",
  last: "__last",
  rayquaza: "__rayquaza",
  cycleBase: "__cycle_base",
  s_d1: "__s_d1",
  s_w1: "__s_w1",
  s_w1m: "__s_w1m",
  s_w2: "__s_w2",
  s_w2m: "__s_w2m",
  s_d50: "__s_d50",
  s_w3: "__s_w3",
  s_w3m: "__s_w3m",
  s_w4: "__s_w4",
  s_w4m: "__s_w4m",
  s_d100: "__s_d100",
};
const SHINY_DAY_TICKS = 10000;
const CYCLE_LEN = 100;

function getShinyDayObjective() {
  try {
    return world.scoreboard.getObjective(SHINY_DAY_OBJECTIVE_ID) ?? world.scoreboard.addObjective(SHINY_DAY_OBJECTIVE_ID, "Shiny Day");
  } catch {
    return null;
  }
}
function getShinyDayScore(key) {
  try {
    const o = getShinyDayObjective();
    return o?.getScore(key) ?? 0;
  } catch {
    return 0;
  }
}
function setShinyDayScore(key, value) {
  try {
    const o = getShinyDayObjective();
    if (!o) return false;
    o.setScore(key, value);
    return true;
  } catch {
    return false;
  }
}
function currentWorldDay() {
  try {
    return Math.floor(world.getDay()) + 1;
  } catch {
    return 1;
  }
}
function broadcast(text) {
  try {
    world.sendMessage(text);
  } catch {}
}
function randInt(min, max) {
  return min + Math.floor(Math.random() * (max - min + 1));
}
function cycleBaseFor(day) {
  return Math.floor((day - 1) / CYCLE_LEN) * CYCLE_LEN;
}
function ensureCycleSchedule(day) {
  const base = cycleBaseFor(day);
  if (getShinyDayScore(SHINY_DAY_KEYS.cycleBase) === base && getShinyDayScore(SHINY_DAY_KEYS.s_d1) > 0) {
    return base;
  }
  setShinyDayScore(SHINY_DAY_KEYS.s_d1, base + 1);
  let w1 = randInt(base + 10, base + 20);
  setShinyDayScore(SHINY_DAY_KEYS.s_w1, w1);
  setShinyDayScore(SHINY_DAY_KEYS.s_w1m, randInt(2, 5));
  let w2 = randInt(base + 20, base + 40);
  if (w2 === w1) w2 = Math.min(base + 40, w2 + 1);
  setShinyDayScore(SHINY_DAY_KEYS.s_w2, w2);
  setShinyDayScore(SHINY_DAY_KEYS.s_w2m, randInt(6, 10));
  setShinyDayScore(SHINY_DAY_KEYS.s_d50, base + 50);
  let w3 = randInt(base + 51, base + 70);
  setShinyDayScore(SHINY_DAY_KEYS.s_w3, w3);
  setShinyDayScore(SHINY_DAY_KEYS.s_w3m, randInt(2, 10));
  let w4 = randInt(base + 70, base + 90);
  setShinyDayScore(SHINY_DAY_KEYS.s_w4, w4);
  setShinyDayScore(SHINY_DAY_KEYS.s_w4m, randInt(2, 10));
  setShinyDayScore(SHINY_DAY_KEYS.s_d100, base + 100);
  setShinyDayScore(SHINY_DAY_KEYS.cycleBase, base);
  return base;
}
function scheduledEventForDay(day) {
  ensureCycleSchedule(day);
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_d1)) return { mult: 2, all: false };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_w1)) return { mult: getShinyDayScore(SHINY_DAY_KEYS.s_w1m) || 3, all: false };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_w2)) return { mult: getShinyDayScore(SHINY_DAY_KEYS.s_w2m) || 7, all: false };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_d50)) return { mult: 10, all: true };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_w3)) return { mult: getShinyDayScore(SHINY_DAY_KEYS.s_w3m) || 5, all: false };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_w4)) return { mult: getShinyDayScore(SHINY_DAY_KEYS.s_w4m) || 5, all: false };
  if (day === getShinyDayScore(SHINY_DAY_KEYS.s_d100)) return { mult: 10, all: true };
  return null;
}
// Absolute "until" can exceed scoreboard int range — store via dynamic property.
const SHINY_DAY_UNTIL_DP = "pokeb_shinyday_until";
function getShinyDayUntil() {
  try {
    const v = world.getDynamicProperty(SHINY_DAY_UNTIL_DP);
    return typeof v === "number" ? v : 0;
  } catch {
    return 0;
  }
}
function setShinyDayUntil(value) {
  try {
    world.setDynamicProperty(SHINY_DAY_UNTIL_DP, Number(value) || 0);
    return true;
  } catch {
    return false;
  }
}
function startShinyDay(multiplier, all = false) {
  const day = currentWorldDay();
  const until = all ? world.getAbsoluteTime() + SHINY_DAY_TICKS : 0;
  setShinyDayScore(SHINY_DAY_KEYS.activeDay, day);
  setShinyDayScore(SHINY_DAY_KEYS.mult, all ? 0 : multiplier);
  setShinyDayScore(SHINY_DAY_KEYS.all, all ? 1 : 0);
  setShinyDayScore(SHINY_DAY_KEYS.until, all ? SHINY_DAY_TICKS : 0); // leftover marker only
  setShinyDayUntil(until);
  setShinyDayScore(SHINY_DAY_KEYS.last, day);
  if (all) {
    broadcast("§bToday is §6§lShiny Day§r§b! §d100％§b shiny rates are active. §aGo catch them!");
  } else {
    broadcast(`§bToday is §6§lShiny Day§r§b! Increased shiny chances now active. §d${multiplier}x§b multiplier. §aGood luck!`);
  }
}
function clearCurrentShinyDay() {
  setShinyDayScore(SHINY_DAY_KEYS.activeDay, 0);
  setShinyDayScore(SHINY_DAY_KEYS.mult, 0);
  setShinyDayScore(SHINY_DAY_KEYS.all, 0);
  setShinyDayScore(SHINY_DAY_KEYS.until, 0);
  setShinyDayUntil(0);
}
function shinyDayState() {
  const day = currentWorldDay();
  const abs = world.getAbsoluteTime();

  if (getShinyDayScore(SHINY_DAY_KEYS.init) !== 1) {
    setShinyDayScore(SHINY_DAY_KEYS.init, 1);
    ensureCycleSchedule(day);
    if (day === 1) {
      startShinyDay(2, false);
    }
  } else {
    ensureCycleSchedule(day);
  }

  let all = getShinyDayScore(SHINY_DAY_KEYS.all) === 1;
  const activeDay = getShinyDayScore(SHINY_DAY_KEYS.activeDay);
  const mult = getShinyDayScore(SHINY_DAY_KEYS.mult);
  let until = getShinyDayUntil();

  if (all && until > 0 && abs >= until) {
    setShinyDayScore(SHINY_DAY_KEYS.all, 0);
    setShinyDayScore(SHINY_DAY_KEYS.until, 0);
    setShinyDayUntil(0);
    all = false;
    until = 0;
  }

  if (all) return { active: true, all: true, mult: 10, until };
  if (activeDay === day && mult >= 2) return { active: true, all: false, mult };

  if (getShinyDayScore(SHINY_DAY_KEYS.last) !== day) {
    const ev = scheduledEventForDay(day);
    if (ev) {
      startShinyDay(ev.mult, !!ev.all);
      return shinyDayState();
    }
  }

  return { active: false, all: false, mult: 1 };
}
function updateShinyDayActionbar() {
  try {
    const s = shinyDayState();
    if (!s.active || !s.all) return;
    const abs = world.getAbsoluteTime();
    const remaining = Math.max(0, Math.ceil((s.until - abs) / 20));
    const mm = Math.floor(remaining / 60);
    const ss = remaining % 60;
    const clock = mm > 0 ? `${mm}:${String(ss).padStart(2, "0")}` : `${ss}s`;
    for (const p of world.getAllPlayers()) {
      try {
        p.onScreenDisplay.setActionBar(`§6§lShiny Day§r §d§l100％§r§b shiny rates active! §a${clock}§r`);
      } catch {}
    }
  } catch {}
}
function forceEntityShiny(entity) {
  try {
    if (!entity?.isValid) return false;
    entity.setProperty("pokeb:shiny", true);
  } catch {}
  try {
    return globalThis.__pokebApplyShiny?.(entity) ?? false;
  } catch {
    return false;
  }
}
function isEntityShiny(entity) {
  try {
    if (entity.getProperty("pokeb:shiny")) return true;
  } catch {}
  try {
    return !!globalThis.__pokebGetPokemonModel?.(entity)?.data?.shiny;
  } catch {
    return false;
  }
}
function announceRareSpawnShiny(entity, tier, pokemonName) {
  let biome;
  try {
    biome = formatBiomeName(entity.dimension.getBiome(entity.location).id);
  } catch {
    return;
  }
  const c = COLORS.tiers[tier] ?? COLORS.highlight;
  let msg = `§7The §e§lShiny§r ${c}${tier}§7 §f${pokemonName}§7 spawned in a §f${biome}§7 biome!`;
  const nearest = findNearestPlayer(entity);
  if (nearest) {
    const d = formatDimensionName(entity.dimension.id);
    const x = Math.floor(entity.location.x);
    const y = Math.floor(entity.location.y);
    const z = Math.floor(entity.location.z);
    msg = `§7The §e§lShiny§r ${c}${tier}§7 §f${pokemonName}§7 spawned in a §f${biome}§7 biome in §f${d}§7 at §f${x}, ${y}, ${z}§7! §7(near §a${nearest.name}§7)`;
  }
  broadcast(msg + "§r");
}
function captureTier(typeId) {
  const id = String(typeId ?? "").replace(/^pokemon:/, "").toLowerCase().split("<")[0];
  return RARITY_TIER[id] ?? null;
}
function onCaptured(player, model) {
  try {
    const typeId = model?.data?.typeId;
    const tier = captureTier(typeId);
    if (!tier) return;
    const id = String(typeId).replace(/^pokemon:/, "").toLowerCase().split("<")[0];
    const name = DISPLAY_NAME[id] ?? id;
    const tc = COLORS.tiers[tier] ?? "§7";
    player.sendMessage(`§a${player.name}§7 has §6§lsuccessfully§r§7 captured the ${tc}${tier}§7 §6§l${name}§r§7!`);
  } catch {}
}
globalThis.__pokebOnPokemonCaptured = onCaptured;
function findEndExitPortal(dimension) {
  for (let r = 0; r <= 8; r++) {
    for (let x = -r; x <= r; x++) {
      for (let z = -r; z <= r; z++) {
        for (let y = 58; y <= 78; y++) {
          try {
            const b = dimension.getBlock({ x, y, z });
            if (b?.typeId === "minecraft:end_portal") return { x: x + 0.5, y: y + 0.1, z: z + 0.5 };
          } catch {}
        }
      }
    }
  }
  return { x: 0.5, y: 65.1, z: 0.5 };
}
function spawnShinyRayquazaOnce() {
  try {
    if (getShinyDayScore(SHINY_DAY_KEYS.rayquaza) === 1) return;
    const d = world.getDimension("minecraft:the_end");
    const p = findEndExitPortal(d);
    const e = d.spawnEntity("pokemon:rayquaza", { x: p.x + 2, y: p.y + 1, z: p.z + 2 });
    forceEntityShiny(e);
    setShinyDayScore(SHINY_DAY_KEYS.rayquaza, 1);
  } catch {}
}
try {
  world.afterEvents.entityDie.subscribe((event) => {
    try {
      const e = event.deadEntity;
      if (e?.typeId !== "minecraft:ender_dragon") return;
      if (e.dimension.id !== "minecraft:the_end") return;
      if (getShinyDayScore(SHINY_DAY_KEYS.rayquaza) === 1) return;
      system.runTimeout(spawnShinyRayquazaOnce, 20);
    } catch {}
  });
} catch {}
try {
  world.beforeEvents.chatSend.subscribe((event) => {
    const msg = String(event.message ?? "").trim();
    if (!/^-shinyday(?:\s|$)/i.test(msg)) return;
    event.cancel = true;
    system.run(() => {
      const sender = event.sender;
      let hasTag = false;
      try { hasTag = !!sender?.hasTag?.("shinygg"); } catch {}
      if (!hasTag) {
        try { sender.sendMessage("§cYou need the tag \"shinygg\" to use this command."); } catch {}
        return;
      }
      const parts = msg.split(/\s+/);
      const sub = (parts[1] ?? "").toLowerCase();
      const arg = (parts[2] ?? "").toLowerCase();
      if (sub !== "set") {
        sender.sendMessage("§cUsage: -shinyday set <2-10|all|remove>");
        return;
      }
      if (arg === "all") {
        startShinyDay(10, true);
        sender.sendMessage("§aShiny Day 100％ enabled for 500s.");
        return;
      }
      if (arg === "remove") {
        clearCurrentShinyDay();
        sender.sendMessage("§aCurrent Shiny Day removed (schedule kept).");
        return;
      }
      const m = arg.match(/^([2-9]|10)x?$/);
      if (!m) {
        sender.sendMessage("§cUsage: -shinyday set <2-10|all|remove>\n§7Example: -shinyday set 6");
        return;
      }
      const n = Number(m[1]);
      startShinyDay(n, false);
      sender.sendMessage(`§aShiny Day ${n}x enabled.`);
    });
  });
} catch {}
system.runInterval(updateShinyDayActionbar, 1);

world.afterEvents.entitySpawn.subscribe((event) => {
  const { entity, cause } = event;
  if (cause !== EntityInitializationCause.Spawned) return;
  if (!entity?.isValid) return;
  if (!entity.typeId.startsWith("pokemon:")) return;
  const id = entity.typeId.slice("pokemon:".length).split("<")[0];
  const tier = RARITY_TIER[id];
  const pokemonName = DISPLAY_NAME[id] ?? id;
  system.runTimeout(() => {
    if (!entity.isValid) return;
    if (entity.getComponent("minecraft:is_tamed")) return;
    const sd = shinyDayState();
    let shiny = isEntityShiny(entity);
    if (sd.active) {
      if (sd.all) {
        forceEntityShiny(entity);
        shiny = true;
      } else if (!shiny) {
        // 6x so voi ban truoc: (N*144)/4096
        // 2x ≈ 7%, 5x ≈ 17.6%, 10x ≈ 35%
        const chance = Math.min(0.5, (sd.mult * 144) / 4096);
        if (Math.random() < chance) {
          forceEntityShiny(entity);
          shiny = true;
        }
      }
    }
    if (!tier) return;
    if (shiny) announceRareSpawnShiny(entity, tier, pokemonName);
    else announceSpawn(entity, tier, pokemonName);
  }, ANNOUNCE_DELAY_TICKS);
});
