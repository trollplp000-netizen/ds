import { world, system } from "@minecraft/server";

const POKEMON_PREFIX = "pokemon:";
const MAX_SCAN_DISTANCE = 64;
const THROW_SPEED = 0.40;
const ARRIVAL_DISTANCE = 0.35;
const MAX_THROW_TICKS = 100;
const REVEAL_DELAY_TICKS = 1;
const CASUAL_THROW_DISTANCE = 4.0;
const BALL_HAND_OFFSET = 0.48;
const BALL_HAND_Y = 0.95;
const BALL_HAND_FORWARD = 0.18;
const EFFECT_Y_OFFSET = 0.5;
const FLIGHT_PARTICLE_START = 0.25;
const NAME_TAG_SCAN_DISTANCE = 96;
const OLD_ICON_ENTITY = "pokeb:ball_nametag_icon";
const activeThrows = new Map();
const processedSentOut = new Set();
const ownedNameTags = new Map();
const battleAnchors = new Map();
const trainerBattleLastPokemon = new Map();
const trainerBattlePending = new Map();
const pendingBallReads = new Map();
const pendingSentOut = new Map();
const SCALE_GROW_TICKS = 14;
const activeScaleGrows = new Map();

const recentSentDespawns = [];

const FORM_CHANGE_WINDOW_TICKS = 20;
const FORM_CHANGE_RADIUS = 5.0;

function vec(p) {
  return { x: Number(p?.x) || 0, y: Number(p?.y) || 0, z: Number(p?.z) || 0 };
}
function add(a, b) { return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }; }
function sub(a, b) { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; }
function mul(a, n) { return { x: a.x * n, y: a.y * n, z: a.z * n }; }
function len(d) { return Math.sqrt(d.x * d.x + d.y * d.y + d.z * d.z); }
function norm(d) {
  const n = len(d);
  return n > 0.0001 ? { x: d.x / n, y: d.y / n, z: d.z / n } : { x: 0, y: 0, z: 1 };
}
function isPokemon(e) { return !!e && typeof e.typeId === "string" && e.typeId.startsWith(POKEMON_PREFIX); }
function sent(e) { try { return e.hasTag("sentOutPokemon"); } catch { return false; } }
function battleId(e) { try { return globalThis.__pokebGetBattleId?.(e) || null; } catch { return null; } }
function battleSideInfo(e) { try { return globalThis.__pokebGetBattleSideInfo?.(e) || null; } catch { return null; } }
function battleExists(id) { try { return !!globalThis.__pokebBattleExists?.(id); } catch { return true; } }
function isInBattleReliable(e) { try { return !!globalThis.__pokebIsInBattle?.(e); } catch {} try { return !!battleId(e); } catch {} return false; }
function ownedPokemon(e) { try { return !!globalThis.__pokebIsOwnedPokemon?.(e); } catch { return false; } }
function ballId(e) { try { return globalThis.__pokebGetCaughtBallId?.(e) || null; } catch { return null; } }

function pokemonDisplayName(pokemon) {
  try {
    let raw = "";
    try { raw = String(pokemon.nameTag || ""); } catch {}
    try { raw = String(raw).replace(/^[\uE200-\uE2FF]\s*/u, ""); } catch {}
    raw = raw.trim();
    if (raw) return raw;
  } catch {}
  try {
    const model = globalThis.__pokebGetPokemonModel?.(pokemon);
    const n = model?.data?.nickname || model?.data?.name || model?.nickname || model?.name;
    if (n) return String(n).trim();
  } catch {}
  return "";
}

function resolveOwnerPlayer(pokemon) {
  if (!pokemon?.isValid) return null;

  try {
    const model = globalThis.__pokebGetPokemonModel?.(pokemon);
    const data = model?.data || model || null;
    const candidates = [];
    if (data) {
      for (const key of ["owner", "ownerName", "playerName", "ot", "originalTrainer", "trainerName", "caughtBy", "playerId", "ownerId"]) {
        try {
          const v = data[key];
          if (v != null && v !== "") candidates.push(v);
        } catch {}
      }
      try { if (model.owner != null) candidates.push(model.owner); } catch {}
      try { if (model.player != null) candidates.push(model.player); } catch {}
    }
    for (const c of candidates) {
      if (c && typeof c === "object") {
        try {
          if (c.typeId === "minecraft:player" && c.isValid) return c;
        } catch {}
        try {
          if (c.player?.typeId === "minecraft:player" && c.player.isValid) return c.player;
        } catch {}
      }
      const s = String(c || "").trim();
      if (!s) continue;
      for (const p of world.getAllPlayers()) {
        if (!p?.isValid) continue;
        if (String(p.name) === s || String(p.id) === s || String(p.nameTag || "") === s) return p;
      }
    }
  } catch {}

  try {
    const display = pokemonDisplayName(pokemon);
    if (display) {
      const lower = display.toLowerCase();
      for (const p of world.getAllPlayers()) {
        if (!p?.isValid) continue;
        const pn = String(p.name || "");
        if (!pn) continue;

        const pl = pn.toLowerCase();
        if (display === pn || lower === pl) return p;
        if (lower === pl + "'s" || lower === pl + "’s") return p;
        if (lower.startsWith(pl + " ") || lower.startsWith(pl + "'s")) return p;
      }
    }
  } catch {}

  try {
    const info = battleSideInfo(pokemon);
    if (info?.player?.isValid && info.player.typeId === "minecraft:player") return info.player;
    if (info?.sourceEntity?.isValid && info.sourceEntity.typeId === "minecraft:player") return info.sourceEntity;
  } catch {}

  return null;
}

function isOwnedByPlayer(pokemon, player) {
  if (!pokemon?.isValid || !player?.isValid) return false;

  const owner = resolveOwnerPlayer(pokemon);
  if (owner?.isValid) {
    try { return owner.id === player.id; } catch { return false; }
  }

  try {
    const display = pokemonDisplayName(pokemon);
    const pn = String(player.name || "");
    if (display && pn) {
      const d = display.toLowerCase();
      const p = pn.toLowerCase();
      if (d === p) return true;
      if (d === p + "'s" || d === p + "’s") return true;
      if (d.startsWith(p + " ") || d.startsWith(p + "'s")) return true;
    }
  } catch {}

  try {
    const model = globalThis.__pokebGetPokemonModel?.(pokemon);
    const uid = model?.uniqueId ?? model?.data?.uniqueId ?? null;
    if (uid != null && typeof globalThis.PlayerModel?.get === "function") {
      const pm = globalThis.PlayerModel.get(player);
      if (pm) {
        const lists = [];
        try { lists.push(pm.getPartyPokemon?.() || []); } catch {}
        try { lists.push(pm.getAvailablePokemon?.() || []); } catch {}
        try { if (Array.isArray(pm.party)) lists.push(pm.party); } catch {}
        for (const list of lists) {
          for (const slot of list || []) {
            try {
              const sid = slot?.uniqueId ?? slot?.data?.uniqueId ?? slot?.id;
              if (sid != null && String(sid) === String(uid)) return true;
            } catch {}
          }
        }
      }
    }
  } catch {}

  return false;
}
function canon(v) { return String(v || "").toLowerCase().replace(/^.*:/, "").replace(/[^a-z0-9]/g, ""); }
function sideActorList(side) {

  try {
    if (!side) return [];
    if (Array.isArray(side.actors)) return side.actors;
    if (side.actors && typeof side.actors[Symbol.iterator] === "function") return Array.from(side.actors);
    if (Array.isArray(side.pokemon)) return side.pokemon;
    if (side.pokemon && typeof side.pokemon[Symbol.iterator] === "function") return Array.from(side.pokemon);
    if (Array.isArray(side.active)) return side.active;
  } catch {}
  return [];
}
function actorEntity(actor) {
  if (!actor) return null;
  try {
    const c = actor.entity || actor.pokemon || actor.source || null;
    if (c?.isValid) return c;
  } catch {}
  return null;
}
function actorPlayer(actor) {
  if (!actor) return null;
  try {
    if (actor.player?.isValid && actor.player.typeId === "minecraft:player") return actor.player;
    const e = actorEntity(actor);
    if (e?.isValid && e.typeId === "minecraft:player") return e;
  } catch {}
  return null;
}
function isPlayerInBattle(player) {
  if (!player?.isValid) return false;
  try { if (globalThis.__pokebIsInBattle?.(player)) return true; } catch {}
  try { if (battleId(player)) return true; } catch {}
  try {
    const battles = globalThis.__pokebGetBattles?.();
    for (const battle of Object.values(battles || {})) {
      const sides = Array.isArray(battle?.sides) ? battle.sides : Array.from(battle?.sides || []);
      for (const side of sides) {
        for (const actor of sideActorList(side)) {
          const pl = actorPlayer(actor);
          if (pl?.isValid && pl.id === player.id) return true;
        }
      }
    }
  } catch {}
  return false;
}
function findOwnedSentPokemonNear(player, maxDist = 48) {
  if (!player?.isValid) return null;
  try {
    const ents = player.dimension.getEntities({ location: player.location, maxDistance: maxDist });
    for (const e of ents) {
      if (!isPokemon(e) || !sent(e)) continue;
      if (isOwnedByPlayer(e, player)) return e;
    }
  } catch {}
  return null;
}
function actorTrainer(actor) {
  try {
    if (actor?.trainer?.isValid) return actor.trainer;

    const e = actorEntity(actor);
    if (e?.isValid && e.typeId && e.typeId !== "minecraft:player" && !isPokemon(e)) return e;
  } catch {}
  return null;
}
function findSentPokemonNearEntity(anchor, maxDist = 64, predicate) {
  if (!anchor?.isValid) return null;
  try {
    const ents = anchor.dimension.getEntities({ location: anchor.location, maxDistance: maxDist });
    let best = null, bestD = Infinity;
    for (const e of ents) {
      if (!isPokemon(e) || !sent(e)) continue;
      if (predicate && !predicate(e)) continue;
      const d = len(sub(vec(e.location), vec(anchor.location)));
      if (d < bestD) { bestD = d; best = e; }
    }
    return best;
  } catch {}
  return null;
}
function resolveSideBattlePokemon(side, sideIndex, battle) {

  for (const actor of sideActorList(side)) {
    const e = actorEntity(actor);
    if (e?.isValid && isPokemon(e)) {
      const src = actorPlayer(actor) || actorTrainer(actor);
      return { entity: e, pokemonActor: actor, sourceEntity: src };
    }
  }

  for (const actor of sideActorList(side)) {
    const pl = actorPlayer(actor);
    if (!pl?.isValid) continue;
    const mon = findOwnedSentPokemonNear(pl, 64);
    if (mon?.isValid) return { entity: mon, pokemonActor: actor, sourceEntity: pl };
  }

  for (const actor of sideActorList(side)) {
    const tr = actorTrainer(actor);
    if (!tr?.isValid) continue;
    const mon = findSentPokemonNearEntity(tr, 64, (e) => {
      try {
        const o = resolveOwnerPlayer(e);
        if (o?.isValid && o.typeId === "minecraft:player") return false;
      } catch {}
      return true;
    });
    if (mon?.isValid) return { entity: mon, pokemonActor: actor, sourceEntity: tr };
  }
  return { entity: null, pokemonActor: null, sourceEntity: null };
}
function directBattleMembership(entity) {
  try {
    if (!entity?.isValid || typeof globalThis.__pokebGetBattles !== "function") return null;
    const battles = globalThis.__pokebGetBattles();
    for (const [battleId, battle] of Object.entries(battles || {})) {
      if (!battle) continue;
      const sides = Array.isArray(battle.sides) ? battle.sides : Array.from(battle.sides || []);
      for (let sideIndex = 0; sideIndex < sides.length; sideIndex++) {
        const side = sides[sideIndex];
        if (!side) continue;

        for (const actor of sideActorList(side)) {
          const candidate = actorEntity(actor);
          if (candidate?.isValid && candidate.id === entity.id) {
            let sourceEntity = actorPlayer(actor);
            if (!sourceEntity) {
              for (const a2 of sideActorList(side)) {
                const pl = actorPlayer(a2);
                if (pl?.isValid) { sourceEntity = pl; break; }
              }
            }
            return { battleId: String(battleId), sideIndex, side, pokemonActor: actor, sourceEntity };
          }
        }

        for (const actor of sideActorList(side)) {
          const pl = actorPlayer(actor);
          if (!pl?.isValid) continue;
          if (isPokemon(entity) && sent(entity) && isOwnedByPlayer(entity, pl)) {
            return { battleId: String(battleId), sideIndex, side, pokemonActor: actor, sourceEntity: pl };
          }
        }
      }
    }
  } catch {}
  return null;
}
function getDirectBattleStates() {
  try {
    if (typeof globalThis.__pokebGetBattles !== "function") return [];
    const battles = globalThis.__pokebGetBattles();
    const result = [];
    for (const [battleId, battle] of Object.entries(battles || {})) {
      if (!battle) continue;
      const sides = Array.isArray(battle.sides) ? battle.sides : Array.from(battle.sides || []);
      const current = [];
      for (let sideIndex = 0; sideIndex < Math.min(2, sides.length); sideIndex++) {
        const side = sides[sideIndex];
        const resolved = resolveSideBattlePokemon(side, sideIndex, battle);
        current.push({
          sideIndex,
          side,
          entity: resolved.entity,
          pokemonActor: resolved.pokemonActor,
          sourceEntity: resolved.sourceEntity
        });
      }
      result.push({ battleId: String(battleId), battle, sides, current });
    }
    return result;
  } catch {}
  return [];
}

const BALLS = [
  "ancientazureball","ancientcitrineball","ancientfeatherball","ancientgigatonball","ancientgreatball",
  "ancientheavyball","ancientivoryball","ancientjetball","ancientleadenball","ancientoriginball",
  "ancientpokeball","ancientroseateball","ancientslateball","ancientultraball","ancientverdantball",
  "ancientwingball","azureball","beastball","cherishball","citrineball","diveball","dreamball",
  "duskball","fastball","friendball","greatball","gsball","healball","heavyball","levelball",
  "loveball","lureball","luxuryball","masterball","moonball","nestball","netball","parkball",
  "pokeball","premierball","quickball","repeatball","roseateball","safariball","slateball",
  "sportball","strangeball","timerball","ultraball","verdantball"
];
const BALL_SET = new Set(BALLS);
const BALL_ALIASES = new Map([
  ["poke","pokeball"],["pokeball","pokeball"],["master","masterball"],["masterball","masterball"],
  ["great","greatball"],["greatball","greatball"],["ultra","ultraball"],["ultraball","ultraball"],
  ["beast","beastball"],["beastball","beastball"],["cherish","cherishball"],["cherishball","cherishball"],
  ["dream","dreamball"],["dreamball","dreamball"],["dusk","duskball"],["duskball","duskball"],
  ["fast","fastball"],["fastball","fastball"],["friend","friendball"],["friendball","friendball"],
  ["gs","gsball"],["gsball","gsball"],["heal","healball"],["healball","healball"],
  ["heavy","heavyball"],["heavyball","heavyball"],["level","levelball"],["levelball","levelball"],
  ["love","loveball"],["loveball","loveball"],["lure","lureball"],["lureball","lureball"],
  ["luxury","luxuryball"],["luxuryball","luxuryball"],["moon","moonball"],["moonball","moonball"],
  ["nest","nestball"],["nestball","nestball"],["net","netball"],["netball","netball"],
  ["park","parkball"],["parkball","parkball"],["premier","premierball"],["premierball","premierball"],
  ["quick","quickball"],["quickball","quickball"],["repeat","repeatball"],["repeatball","repeatball"],
  ["safari","safariball"],["safariball","safariball"],["sport","sportball"],["sportball","sportball"],
  ["timer","timerball"],["timerball","timerball"],["dive","diveball"],["diveball","diveball"],
  ["strange","strangeball"],["strangeball","strangeball"]
]);
function normalizedBallId(value) {
  const c = canon(value);
  return BALL_ALIASES.get(c) || (BALL_SET.has(c) ? c : null);
}
function ballEntityId(ball) { return ball ? `pokeb:send_ball_${ball}` : null; }

function playLocalSound(player, soundId) {
  if (!player?.isValid) return;
  try {
    player.playSound(soundId, { location: player.location, volume: 1.8, pitch: 1.0 });
  } catch {
    try { player.playSound(soundId, { volume: 1.8, pitch: 1.0 }); } catch {}
  }
}
function playSendOutSound(player) {
  playLocalSound(player, "poke_ball_send_out");
}
function playRecallSound(player) {
  playLocalSound(player, "poke_ball_recall");
}
function spawnParticle(dimension, id, pos) { try { dimension.spawnParticle(id, pos); } catch {} }
function particlePosition(target, mode) {
  const p = vec(target);
  return mode === "battle"
    ? { x: p.x, y: p.y - 0.5, z: p.z }
    : { x: p.x, y: p.y, z: p.z };
}
function emitFlightParticle(dimension, ball, pos, mode) {
  if (!ball || !BALL_SET.has(ball)) return;

  if (mode === "battle" || mode === "trainerBattle") return;
  const p = particlePosition(pos, mode);
  spawnParticle(dimension, `cobblemon:${ball}/casual/ballsparks`, p);
}
function emitArrivalParticle(dimension, ball, target, mode) {
  if (!ball || !BALL_SET.has(ball)) return;
  const p = particlePosition(target, mode);

  const m = (mode === "battle" || mode === "trainerBattle") ? "casual" : mode;
  spawnParticle(dimension, `cobblemon:${ball}/${m}/sendflash`, p);
}
function head(player) {
  try { return vec(player.getHeadLocation()); }
  catch {
    const q = vec(player.location);
    return { x: q.x, y: q.y + 1.55, z: q.z };
  }
}
function viewRight(player) {
  const r = norm(vec(player.getViewDirection?.() || { x: 0, y: 0, z: 1 }));
  const flatRight = { x: -r.z, y: 0, z: r.x };
  const n = Math.sqrt(flatRight.x * flatRight.x + flatRight.z * flatRight.z);
  return n > 0.0001 ? { x: flatRight.x / n, y: 0, z: flatRight.z / n } : { x: 1, y: 0, z: 0 };
}
function isPosBlocking(dimension, pos) {
  try {
    const block = dimension.getBlock({
      x: Math.floor(pos.x),
      y: Math.floor(pos.y),
      z: Math.floor(pos.z)
    });
    return isBlockingBlock(block);
  } catch {
    return false;
  }
}
function throwOrigin(player) {
  const feet = vec(player.location);
  const right = viewRight(player);
  const view = norm(vec(player.getViewDirection?.() || { x: 0, y: 0, z: 1 }));
  const flatLen = Math.sqrt(view.x * view.x + view.z * view.z);
  const forward = flatLen > 0.0001
    ? { x: view.x / flatLen, y: 0, z: view.z / flatLen }
    : { x: 0, y: 0, z: 1 };

  // Prefer right-hand spawn; if that cell is solid (wall on the right),
  // pull inward toward the body in small steps so the ball still leaves
  // from the right side rather than the center, without starting inside a block.
  const y = feet.y + BALL_HAND_Y;
  let rightOff = BALL_HAND_OFFSET;
  let origin = {
    x: feet.x + right.x * rightOff + forward.x * BALL_HAND_FORWARD,
    y,
    z: feet.z + right.z * rightOff + forward.z * BALL_HAND_FORWARD
  };
  try {
    const dim = player.dimension;
    if (dim && isPosBlocking(dim, origin)) {
      for (let step = 1; step <= 6; step++) {
        rightOff = Math.max(0.12, BALL_HAND_OFFSET - step * 0.08);
        origin = {
          x: feet.x + right.x * rightOff + forward.x * BALL_HAND_FORWARD,
          y,
          z: feet.z + right.z * rightOff + forward.z * BALL_HAND_FORWARD
        };
        if (!isPosBlocking(dim, origin)) break;
      }
    }
  } catch {}
  return origin;
}
function battleOwnerPlayer(pokemon){
  try{
    const info=battleSideInfo(pokemon);
    if(!info)return null;
    return info.player?.isValid ? info.player : null;
  }catch{}
  return null;
}
function nearestPlayerToPokemon(pokemon){
  let best=null,bestD=Infinity;
  try{
    for(const p of world.getAllPlayers()){
      if(!p?.isValid||p.dimension.id!==pokemon.dimension.id)continue;
      const d=len(sub(vec(p.location),vec(pokemon.location)));
      if(d>MAX_SCAN_DISTANCE)continue;
      if(d<bestD){bestD=d;best=p;}
    }
  }catch{}
  return best;
}
function viewTarget(player) {
  const feet = vec(player.location);
  const right = viewRight(player);
  const r = norm(vec(player.getViewDirection?.() || { x: 0, y: 0, z: 1 }));
  const horizontal = { x: r.x, y: 0, z: r.z };
  const flatLen = Math.sqrt(horizontal.x * horizontal.x + horizontal.z * horizontal.z);
  const dir = flatLen > 0.0001 ? { x: horizontal.x / flatLen, y: 0, z: horizontal.z / flatLen } : { x: 0, y: 0, z: 1 };

  return {
    x: feet.x + dir.x * CASUAL_THROW_DISTANCE + right.x * 0.28,
    y: feet.y + 0.2,
    z: feet.z + dir.z * CASUAL_THROW_DISTANCE + right.z * 0.28
  };
}
function findGroundTarget(dimension, desired, preferY) {
  const x = Math.floor(desired.x);
  const z = Math.floor(desired.z);
  const prefer = typeof preferY === "number" ? preferY : desired.y;
  const startY = Math.min(320, Math.floor(prefer + 8));
  const minY = Math.max(-64, Math.floor(prefer - 96));
  for (let y = startY; y >= minY; y--) {
    try {
      const block = dimension.getBlock({ x, y, z });
      if (isBlockingBlock(block)) return { x: desired.x, y: y + 1.0, z: desired.z };
    } catch {}
  }
  return { x: desired.x, y: desired.y, z: desired.z };
}

function isBlockingBlock(block){
  try{
    if(!block)return false;
    if(block.isAir)return false;
    const id = block.typeId || "";
    if(!id || id === "minecraft:air" || id === "minecraft:cave_air" || id === "minecraft:void_air") return false;
    if(id.includes("water") || id.includes("lava") || id.includes("bubble")) return false;
    if(id.includes("grass") && id !== "minecraft:grass_block") return false;
    if(id.includes("flower") || id.includes("sapling") || id.includes("carpet") || id.includes("rail")) return false;
    if(id.includes("torch") || id.includes("sign") || id.includes("button") || id.includes("lever")) return false;
    if(id.includes("pressure_plate") || id.includes("tripwire") || id.includes("string")) return false;
    if(typeof block.isSolid === "boolean") return block.isSolid;
    return true;
  }catch{return false}
}
function rayBlockHit(dimension, from, to, ignoreNearFrom = 0) {
  try {
    const delta = sub(to, from);
    const distance = len(delta);
    if (distance <= 0.001) return null;
    const steps = Math.max(2, Math.ceil(distance / 0.05));
    const minT = ignoreNearFrom > 0 ? Math.min(0.95, ignoreNearFrom / distance) : 0;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      if (t < minT) continue;
      const p = add(from, mul(delta, t));
      const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
      let block = null;
      try { block = dimension.getBlock({ x: bx, y: by, z: bz }); } catch {}
      if (isBlockingBlock(block)) {
        const prevT = Math.max(minT, (i - 1) / steps);
        const safeT = Math.max(minT, prevT - 0.12 / distance);
        return add(from, mul(delta, safeT));
      }
    }
    return null;
  } catch { return null; }
}
function findColumnTopY(dimension, x, z, preferY) {
  const bx = Math.floor(x);
  const bz = Math.floor(z);
  const prefer = typeof preferY === "number" ? preferY : 0;
  const startY = Math.min(320, Math.floor(prefer + 8));
  const minY = Math.max(-64, Math.floor(prefer - 96));
  for (let y = startY; y >= minY; y--) {
    try {
      const block = dimension.getBlock({ x: bx, y, z: bz });
      if (isBlockingBlock(block)) return y + 1.0;
    } catch {}
  }
  return prefer + 1;
}
function clampThrowTarget(dimension, start, desired, playerY) {
  const prefer = Math.max(playerY, start.y);
  const dirH = norm({ x: desired.x - start.x, y: 0, z: desired.z - start.z });
  // Ignore wall hits within hand clearance so a block tight against the
  // right side does not collapse the throw target to the player's feet.
  // Real walls further along the throw path still clamp the target.
  const HAND_CLEARANCE = 0.55;
  let wallHit = null;
  for (const h of [0.2, 0.7, 1.2, 1.7]) {
    const from = { x: start.x, y: playerY + h, z: start.z };
    const to = { x: desired.x, y: playerY + h, z: desired.z };
    const hit = rayBlockHit(dimension, from, to, HAND_CLEARANCE);
    if (hit) { wallHit = hit; break; }
  }
  if (wallHit) {
    const front = {
      x: wallHit.x - dirH.x * 0.45,
      y: playerY,
      z: wallHit.z - dirH.z * 0.45
    };
    let target = findGroundTarget(dimension, front, playerY);
    if (target.y > playerY + 2.2) target = { x: front.x, y: playerY + 0.2, z: front.z };
    return { target, hitWall: true };
  }
  let target = findGroundTarget(dimension, desired, prefer);
  try {
    const deep = findGroundTarget(dimension, desired, start.y);
    if (deep.y < target.y) target = deep;
  } catch {}
  if (target.y > playerY + 2.5) {
    target = { x: target.x, y: playerY + 0.2, z: target.z };
  }
  return { target, hitWall: false };
}

function orient(entity, a, b) {
  const n = norm(sub(b, a));
  try {
    entity.setRotation({
      x: -Math.asin(Math.max(-1, Math.min(1, n.y))) * 180 / Math.PI,
      y: Math.atan2(-n.x, n.z) * 180 / Math.PI
    });
  } catch {}
}
function hidePokemon(pokemon) {
  const state = { scale: 1, nameTag: "", nameTagCaptured: false, origin: null };
  try {
    const s = pokemon.getProperty("pokeb:scale");

    if (typeof s === "number" && s > 0.05) state.scale = s;
  } catch {}
  try {
    const nt = String(pokemon.nameTag || "").trim();
    if (nt) {
      state.nameTag = nt;
      state.nameTagCaptured = true;
    } else {

      const dn = pokemonDisplayName(pokemon);
      if (dn) {
        state.nameTag = dn;
        state.nameTagCaptured = true;
      }
    }
    pokemon.nameTag = "";
  } catch {}

  try { pokemon.setProperty("pokeb:scale", 0); } catch {}
  try { pokemon.addEffect("invisibility", MAX_THROW_TICKS + 40, { amplifier: 0, showParticles: false }); } catch {}
  try {
    const loc = vec(pokemon.location);
    state.origin = { x: loc.x, y: loc.y, z: loc.z };

    const buryY = loc.y - 10;
    pokemon.teleport({ x: loc.x, y: buryY, z: loc.z }, { dimension: pokemon.dimension });
  } catch {}
  return state;
}

function restoreHideOrigin(pokemon, hideState) {
  try {
    if (!pokemon?.isValid || !hideState?.origin) return;
    pokemon.teleport(
      { x: hideState.origin.x, y: hideState.origin.y, z: hideState.origin.z },
      { dimension: pokemon.dimension }
    );
  } catch {}
}
function startScaleGrow(pokemon, targetScale) {
  if (!pokemon?.isValid) return;
  const target = (typeof targetScale === "number" && targetScale > 0) ? targetScale : 1;

  const startFrac = 0.3;
  try { pokemon.setProperty("pokeb:scale", target * startFrac); } catch {}
  activeScaleGrows.set(pokemon.id, {
    entity: pokemon,
    targetScale: target,
    startScale: target * startFrac,
    tick: 0
  });
}
function tickScaleGrows() {
  for (const [id, state] of Array.from(activeScaleGrows.entries())) {
    const e = state.entity;
    if (!e?.isValid) {
      activeScaleGrows.delete(id);
      continue;
    }
    state.tick++;
    const t = Math.min(1, state.tick / SCALE_GROW_TICKS);
    const eased = t * t * (3 - 2 * t);
    const scale = state.startScale + (state.targetScale - state.startScale) * eased;
    try { e.setProperty("pokeb:scale", scale); } catch {}
    if (state.tick >= SCALE_GROW_TICKS) {
      try { e.setProperty("pokeb:scale", state.targetScale); } catch {}
      activeScaleGrows.delete(id);
    }
  }
}
function resolvePokemonName(pokemon, hideState) {
  try {
    if (hideState?.nameTagCaptured && hideState.nameTag && String(hideState.nameTag).trim()) {
      return String(hideState.nameTag).trim();
    }
  } catch {}
  try {
    const dn = pokemonDisplayName(pokemon);
    if (dn && String(dn).trim()) return String(dn).trim();
  } catch {}
  try {
    const id = String(pokemon.typeId || "").replace(/^pokemon:/, "").split("<")[0];
    if (id) return id.charAt(0).toUpperCase() + id.slice(1);
  } catch {}
  return "";
}

function forceShowPokemon(pokemon, hideState, atPos, opts) {
  if (!pokemon?.isValid) return;
  const setName = !opts || opts.setName !== false;
  try {
    if (atPos) {
      const p = vec(atPos);
      pokemon.teleport({ x: p.x, y: p.y, z: p.z }, { dimension: pokemon.dimension });
    }
  } catch {}
  try { pokemon.removeEffect("invisibility"); } catch {}
  const targetScale = (typeof hideState?.scale === "number" && hideState.scale > 0.05) ? hideState.scale : 1;
  try {
    const cur = pokemon.getProperty("pokeb:scale");
    if (typeof cur !== "number" || cur < 0.45) pokemon.setProperty("pokeb:scale", targetScale);
  } catch {
    try { pokemon.setProperty("pokeb:scale", targetScale); } catch {}
  }

  if (setName) {
    try {
      const cur = String(pokemon.nameTag || "").trim();
      if (!cur) {
        const name = resolvePokemonName(pokemon, hideState);
        if (name) pokemon.nameTag = name;
      }
    } catch {}
  }
}

function revealPokemon(pokemon, hideState, player, atPos) {
  if (!pokemon?.isValid) return;
  forceShowPokemon(pokemon, hideState, atPos);

  const targetScale = (typeof hideState?.scale === "number" && hideState.scale > 0.05) ? hideState.scale : 1;
  try { pokemon.setProperty("pokeb:scale", targetScale * 0.35); } catch {}
  startScaleGrow(pokemon, targetScale);
  try {
    const p = player?.isValid ? player : resolveOwnerPlayer(pokemon);
    if (p?.isValid) playSendOutSound(p);
  } catch {}

  try {
    system.runTimeout(() => {
      try {
        if (!pokemon?.isValid) return;
        forceShowPokemon(pokemon, hideState, null);
      } catch {}
    }, SCALE_GROW_TICKS + 1);
  } catch {}
}

function isBattlePokemonLive(e) {
  try {
    if (!e?.isValid) return false;
    if (directBattleMembership(e)) return true;
    if (isInBattleReliable(e)) return true;
    if (battleSideInfo(e)?.battleId) return true;
    if (battleId(e)) return true;
  } catch {}
  return false;
}

function isBattlePokemon(e) {
  try {
    if (!e?.isValid) return false;
    try { if (e.hasTag("pokeb:fx_in_battle")) return true; } catch {}
    return isBattlePokemonLive(e);
  } catch {}
  return false;
}

function markBattlePokemon(e) {
  try { if (e?.isValid) e.addTag("pokeb:fx_in_battle"); } catch {}
}
function unmarkBattlePokemon(e) {
  try { if (e?.isValid) e.removeTag("pokeb:fx_in_battle"); } catch {}
}

function isNearAnyBattle(entity, radius = 48) {
  try {
    if (!entity?.isValid) return false;
    const battles = getDirectBattleStates();
    for (const b of battles) {
      for (const c of b.current || []) {
        const other = c?.entity;
        if (!other?.isValid) continue;
        if (other.dimension?.id !== entity.dimension?.id) continue;
        if (len(sub(vec(other.location), vec(entity.location))) <= radius) return true;
      }
    }
  } catch {}
  return false;
}

function purgeBallEntitiesNear(dimension, location, radius = 16) {
  try {
    const ents = dimension.getEntities({ location, maxDistance: radius });
    for (const e of ents) {
      try {
        const id = String(e?.typeId || "");
        if (id.startsWith("pokeb:send_ball_")) {
          e.remove();
        }
      } catch {}
    }
  } catch {}
}

function ownerKeyOf(pokemon) {
  try {
    const o = resolveOwnerPlayer(pokemon);
    if (o?.isValid) return String(o.id);
  } catch {}
  try {
    const d = pokemonDisplayName(pokemon);
    if (d) return "name:" + d.toLowerCase();
  } catch {}
  return null;
}

function recordSentDespawn(pokemon) {
  try {
    if (!pokemon || !isPokemon(pokemon) || !sent(pokemon)) return;
    const loc = vec(pokemon.location);
    const dimId = pokemon.dimension?.id || "";
    const ownerKey = ownerKeyOf(pokemon);
    recentSentDespawns.push({
      tick: system.currentTick,
      dimId,
      x: loc.x, y: loc.y, z: loc.z,
      ownerKey,
      typeId: (function(){ try { return String(e.typeId||""); } catch { return ""; } })()
    });

    while (recentSentDespawns.length > 40) recentSentDespawns.shift();
  } catch {}
}

function pruneRecentDespawns() {
  const now = system.currentTick;
  while (recentSentDespawns.length && now - recentSentDespawns[0].tick > FORM_CHANGE_WINDOW_TICKS) {
    recentSentDespawns.shift();
  }
}

function isLikelyFormChange(pokemon) {
  try {
    if (!pokemon?.isValid) return false;

    // Explicit mega skip by entity id / uniqueId (time-window only — NOT permanent for all mega typeIds)

    try {
      const skip = globalThis.__pokebMegaSkipSendFx;
      if (skip && skip.size) {
        if (skip.has(pokemon.id) || skip.has(String(pokemon.id))) return true;
        try {
          const model = globalThis.__pokebGetPokemonModel?.(pokemon);
          const uid = model?.data?.uniqueId ?? model?.uniqueId;
          if (uid != null && (skip.has(uid) || skip.has(String(uid)))) return true;
        } catch {}
      }
    } catch {}

    // Location skip: any mega-named pokemon near a recent mega transform spot
    try {
      const locs = globalThis.__pokebMegaSkipLocs;
      if (locs && locs.length) {
        const now = system.currentTick;
        // prune
        globalThis.__pokebMegaSkipLocs = locs.filter((d) => now - d.tick <= 60);
        const loc = vec(pokemon.location);
        const dimId = pokemon.dimension?.id || "";
        const typeLow = String(pokemon.typeId || "").toLowerCase();
        const isMegaType = typeLow.includes("mega") || typeLow.includes("primal");
        for (const d of globalThis.__pokebMegaSkipLocs) {
          if (d.dim !== dimId) continue;
          const dx = loc.x - d.x, dz = loc.z - d.z;
          if (dx * dx + dz * dz > 64) continue; // within 8 blocks
          if (isMegaType) return true;
          try {
            const model = globalThis.__pokebGetPokemonModel?.(pokemon);
            const uid = model?.data?.uniqueId ?? model?.uniqueId;
            if (uid != null && d.uid && String(uid) === String(d.uid)) return true;
          } catch {}
        }
      }
    } catch {}

    pruneRecentDespawns();
    if (!recentSentDespawns.length) return false;
    const loc = vec(pokemon.location);
    const dimId = pokemon.dimension?.id || "";
    const ownerKey = ownerKeyOf(pokemon);
    const now = system.currentTick;
    for (const d of recentSentDespawns) {
      if (now - d.tick > FORM_CHANGE_WINDOW_TICKS) continue;
      if (d.dimId !== dimId) continue;
      const dx = loc.x - d.x, dy = loc.y - d.y, dz = loc.z - d.z;
      if (dx * dx + dy * dy + dz * dz > FORM_CHANGE_RADIUS * FORM_CHANGE_RADIUS) continue;
      if (d.ownerKey && ownerKey && d.ownerKey !== ownerKey) continue;
      try {
        const curType = String(pokemon.typeId || "");
        // Same species nearby after recall = normal re-send → allow ball FX
        if (d.typeId && curType && d.typeId === curType) continue;
        // Different species = real form change → skip ball FX
        if (d.typeId && curType && d.typeId !== curType) return true;
      } catch {}
    }
  } catch {}
  return false;
}

function ensurePendingHide(pokemon) {
  if (!pokemon?.isValid || !sent(pokemon) || activeThrows.has(pokemon.id) || pendingSentOut.has(pokemon.id)) return null;

  if (isBattlePokemon(pokemon) || isNearAnyBattle(pokemon, 40)) return null;

  if (isLikelyFormChange(pokemon)) {
    processedSentOut.add(pokemon.id);
    try {
      const s = pokemon.getProperty("pokeb:scale");
      if (typeof s !== "number" || s < 0.5) pokemon.setProperty("pokeb:scale", 1);
    } catch {}
    try { pokemon.removeEffect("invisibility"); } catch {}
    return null;
  }
  const hideState = hidePokemon(pokemon);
  const item = { firstTick: system.currentTick, hideState };
  pendingSentOut.set(pokemon.id, item);
  return item;
}

const BATTLE_GAP = 4.0;

function lockBattleFormation(formation, entity0, entity1, source0, source1) {
  if (!formation || formation.locked) return formation;
  if (!entity0?.isValid || !entity1?.isValid) return formation;

  let owner0 = source0?.isValid ? source0 : null;
  let owner1 = source1?.isValid ? source1 : null;
  try { if (!owner0) owner0 = resolveOwnerPlayer(entity0); } catch {}
  try { if (!owner1) owner1 = resolveOwnerPlayer(entity1); } catch {}
  const side0Player = !!(owner0?.isValid && owner0.typeId === "minecraft:player");
  const side1Player = !!(owner1?.isValid && owner1.typeId === "minecraft:player");

  const dimId = entity0.dimension?.id || entity1.dimension?.id || null;
  let pos0, pos1;

  if (side0Player && !side1Player) {
    const anchor = vec(entity1.location);
    const from = vec(owner0.location);
    let d = { x: anchor.x - from.x, y: 0, z: anchor.z - from.z };
    let n = Math.sqrt(d.x * d.x + d.z * d.z);
    if (n < 0.001) d = { x: 0, y: 0, z: 1 }, n = 1;
    const forward = { x: d.x / n, y: 0, z: d.z / n };
    pos1 = { x: anchor.x, y: anchor.y, z: anchor.z, dimensionId: dimId };
    pos0 = { x: anchor.x - forward.x * BATTLE_GAP, y: anchor.y, z: anchor.z - forward.z * BATTLE_GAP, dimensionId: dimId };
  } else if (side1Player && !side0Player) {
    const anchor = vec(entity0.location);
    const from = vec(owner1.location);
    let d = { x: anchor.x - from.x, y: 0, z: anchor.z - from.z };
    let n = Math.sqrt(d.x * d.x + d.z * d.z);
    if (n < 0.001) d = { x: 0, y: 0, z: 1 }, n = 1;
    const forward = { x: d.x / n, y: 0, z: d.z / n };
    pos0 = { x: anchor.x, y: anchor.y, z: anchor.z, dimensionId: dimId };
    pos1 = { x: anchor.x - forward.x * BATTLE_GAP, y: anchor.y, z: anchor.z - forward.z * BATTLE_GAP, dimensionId: dimId };
  } else {

    let a = vec(entity0.location), b = vec(entity1.location);
    if (side0Player && side1Player) {
      a = vec(owner0.location);
      b = vec(owner1.location);
    }
    const mid = { x: (a.x + b.x) / 2, y: (entity0.location.y + entity1.location.y) / 2, z: (a.z + b.z) / 2 };
    let d = { x: b.x - a.x, y: 0, z: b.z - a.z };
    let n = Math.sqrt(d.x * d.x + d.z * d.z);
    if (n < 0.001) d = { x: 0, y: 0, z: 1 }, n = 1;
    const forward = { x: d.x / n, y: 0, z: d.z / n };
    const half = BATTLE_GAP / 2;
    pos0 = { x: mid.x - forward.x * half, y: entity0.location.y, z: mid.z - forward.z * half, dimensionId: dimId };
    pos1 = { x: mid.x + forward.x * half, y: entity1.location.y, z: mid.z + forward.z * half, dimensionId: dimId };
  }

  formation.positions = [pos0, pos1];
  formation.locked = true;
  return formation;
}

function getBattleFormation(info, pokemon) {
  if (!info?.battleId || info.sideIndex === undefined || info.sideIndex === null || !pokemon?.isValid) return null;
  const battleKey = String(info.battleId);
  let formation = battleAnchors.get(battleKey);
  if (!formation) {
    formation = { battleId: battleKey, locked: false, firstLocations: [null, null], firstIds: [null, null], positions: null, sideSources: [null, null], createdTick: system.currentTick };
    battleAnchors.set(battleKey, formation);
  }
  const side = Number(info.sideIndex);
  if (side < 0 || side > 1) return null;
  if (!formation.firstLocations[side]) {
    formation.firstLocations[side] = vec(pokemon.location);
    formation.firstIds[side] = pokemon.id;
    formation.sideSources[side] = info.sourceEntity?.isValid ? info.sourceEntity : null;
  }
  if (!formation.locked && formation.firstLocations[0] && formation.firstLocations[1]) {
    lockBattleFormation(formation, null, null);
  }
  return formation;
}

function battleSource(info, formation) {
  try { if (info?.sourceEntity?.isValid) return info.sourceEntity; } catch {}
  try { if (formation?.sideSources?.[Number(info?.sideIndex)]?.isValid) return formation.sideSources[Number(info.sideIndex)]; } catch {}
  return null;
}

function faceBattlePokemon(pokemon, target) {
  try {
    const here = vec(pokemon.location);
    const d = norm({ x: target.x - here.x, y: 0, z: target.z - here.z });
    pokemon.setRotation({ x: 0, y: Math.atan2(-d.x, d.z) * 180 / Math.PI });
  } catch {}
}

function getTrainerSourceForBattleSide(battle, sideIndex) {
  try {
    const side = battle?.sides?.[sideIndex];
    const actors = Array.isArray(side?.actors) ? side.actors : Array.from(side?.actors || []);
    for (const actor of actors) {
      try {
        const trainer = actor?.trainer;
        if (trainer?.isValid) return trainer;
      } catch {}
    }
  } catch {}
  return null;
}

function enforceBattlePosition(pokemon, target, opponentTarget) {
  try {
    if (!pokemon?.isValid || !target) return;
    const p = vec(pokemon.location);
    if (len(sub(target, p)) > 0.08) pokemon.teleport(target);
    if (opponentTarget) faceBattlePokemon(pokemon, opponentTarget);
  } catch {}
}

function launch(player, pokemon, pendingState) {
  if (!pokemon?.isValid || activeThrows.has(pokemon.id)) return false;

  if (!isOwnedByPlayer(pokemon, player)) return false;

  if (isBattlePokemon(pokemon)) return false;
  if (isNearAnyBattle(pokemon, 40)) return false;

  try { if (isPlayerInBattle(player)) return false; } catch {}

  if (isLikelyFormChange(pokemon)) {
    processedSentOut.add(pokemon.id);
    try {
      const s = pokemon.getProperty("pokeb:scale");
      if (typeof s !== "number" || s < 0.5) pokemon.setProperty("pokeb:scale", 1);
    } catch {}
    try { pokemon.removeEffect("invisibility"); } catch {}
    return false;
  }
  const ball = normalizedBallId(ballId(pokemon));
  if (!ball) {
    const count = (pendingBallReads.get(pokemon.id) || 0) + 1;
    pendingBallReads.set(pokemon.id, count);
    if (count < 20) return false;
    pendingBallReads.delete(pokemon.id);
    return false;
  }
  pendingBallReads.delete(pokemon.id);
  if (!player?.isValid) return false;
  const start = throwOrigin(player);
  const desired = viewTarget(player);
  const playerY = vec(player.location).y;
  const clamped = clampThrowTarget(player.dimension, start, desired, playerY);
  let target = clamped.target || clamped;
  const hitWall = !!clamped.hitWall;
  const hideState = pendingState?.hideState || hidePokemon(pokemon);

  try {
    pokemon.teleport({ x: target.x, y: target.y - 10, z: target.z }, { dimension: player.dimension });
    pokemon.setProperty("pokeb:scale", 0);
  } catch {}
  try { pokemon.addEffect("invisibility", MAX_THROW_TICKS + 40, { amplifier: 0, showParticles: false }); } catch {}
  const state = { player, pokemon, ball, mode: "casual", age: 0, target, revealAt: -1, ballEntity: null, start: { ...start }, hideState, dimension: player.dimension, anchorKey: null, raised: false, dwellUntil: -1, impactPos: null, flightT: 0 };
  activeThrows.set(pokemon.id, state);
  processedSentOut.add(pokemon.id);
  try { state.ballEntity = player.dimension.spawnEntity(ballEntityId(ball), start); } catch {
    try { restoreHideOrigin(pokemon, hideState); } catch {}
    revealPokemon(pokemon, hideState, player, target);
    activeThrows.delete(pokemon.id);
    return false;
  }
  return true;
}

function launchBattle(player, pokemon, targetPos, opponentPos, pendingState) {
  if (isLikelyFormChange(pokemon)) {
    processedSentOut.add(pokemon.id);
    forceShowPokemon(pokemon, null, null, { setName: false });
    return false;
  }

  if (!pokemon?.isValid || activeThrows.has(pokemon.id)) return false;
  if (!player?.isValid) return false;
  const ball = normalizedBallId(ballId(pokemon)) || "pokeball";
  const start = throwOrigin(player);
  const target = findGroundTarget(player.dimension, vec(targetPos));
    const hideState = pendingState?.hideState || hidePokemon(pokemon);
  {
    const hx = target.x - start.x;
    const hz = target.z - start.z;
    const hd = Math.sqrt(hx * hx + hz * hz);
    if (hd < 1.2) {
      const dir = norm({ x: hx, y: 0, z: hz });
      if (len(dir) < 0.01) {
        const look = player.getViewDirection();
        const d2 = norm({ x: look.x, y: 0, z: look.z });
        target = {
          x: start.x + d2.x * 1.25,
          y: playerY,
          z: start.z + d2.z * 1.25
        };
      } else {
        target = {
          x: start.x + dir.x * 1.25,
          y: Math.min(target.y, playerY + 0.15),
          z: start.z + dir.z * 1.25
        };
      }
    }
  }

  try {
    pokemon.teleport({ x: target.x, y: target.y - 10, z: target.z }, { dimension: player.dimension });
    pokemon.setProperty("pokeb:scale", 0);
  } catch {}
  try { pokemon.addEffect("invisibility", MAX_THROW_TICKS + 40, { amplifier: 0, showParticles: false }); } catch {}
  const state = {
    player, pokemon, ball,
    mode: "battle",
    particleMode: "casual",
    age: 0,
    target,
    opponentTarget: opponentPos ? vec(opponentPos) : null,
    revealAt: -1,
    ballEntity: null,
    start: { ...start },
    hideState,
    dimension: player.dimension,
    anchorKey: null,
    raised: false,
    dwellUntil: -1,
    impactPos: null,
    flightT: 0
  };
  activeThrows.set(pokemon.id, state);
  processedSentOut.add(pokemon.id);
  try {
    state.ballEntity = player.dimension.spawnEntity(ballEntityId(ball), start);
  } catch {
    try { restoreHideOrigin(pokemon, hideState); } catch {}
    revealPokemon(pokemon, hideState);
    try { if (state.opponentTarget) faceBattlePokemon(pokemon, state.opponentTarget); } catch {}
    activeThrows.delete(pokemon.id);
    return false;
  }
  return true;
}

try {
  if (world.afterEvents?.entitySpawn?.subscribe) {
    world.afterEvents.entitySpawn.subscribe(ev => {
      try {
        const e = ev?.entity;
        if (!isPokemon(e) || !sent(e)) return;
        if (activeThrows.has(e.id) || pendingSentOut.has(e.id) || processedSentOut.has(e.id)) return;

        system.run(() => {
          try {
            if (!e?.isValid || !isPokemon(e) || !sent(e)) return;
            if (activeThrows.has(e.id) || processedSentOut.has(e.id)) return;

            if (isLikelyFormChange(e)) {
              processedSentOut.add(e.id);
              forceShowPokemon(e, null, null);
              return;
            }

            const owner = resolveOwnerPlayer(e);
            const inBattle = !!(
              isBattlePokemon(e) ||
              isNearAnyBattle(e, 40) ||
              directBattleMembership(e) ||
              (owner?.isValid && isPlayerInBattle(owner))
            );

            if (inBattle) {
              markBattlePokemon(e);

              const isPlayerMon = !!(owner?.isValid && owner.typeId === "minecraft:player" && isOwnedByPlayer(e, owner));
              if (isPlayerMon && !pendingSentOut.has(e.id) && !activeThrows.has(e.id)) {
                try {
                  const hideState = hidePokemon(e);
                  pendingSentOut.set(e.id, { firstTick: system.currentTick, hideState });
                } catch {}
              } else if (!isPlayerMon) {

                forceShowPokemon(e, null, null, { setName: true });
              }
              return;
            }

            if (!owner?.isValid) {
              processedSentOut.add(e.id);
              forceShowPokemon(e, null, null);
              return;
            }

            if (!pendingSentOut.has(e.id) && !activeThrows.has(e.id) && !processedSentOut.has(e.id)) {
              ensurePendingHide(e);
            }
          } catch {}
        });
      } catch {}
    });
  }
} catch {}

try {
  function handlePokemonRemoved(e) {
    try {
      if (!e) return;
      const rid = e.id;
      let rloc = null;
      let rdim = null;
      try { rloc = e.location; rdim = e.dimension; } catch {}
      recordSentDespawn(e);
      try {
        // Cancel in-flight throw → remove floating ball entities
        const ts = activeThrows.get(rid);
        if (ts) {
          try { ts.ballEntity?.remove(); } catch {}
          try {
            if (ts.dimension && ts.start) purgeBallEntitiesNear(ts.dimension, ts.start, 32);
          } catch {}
          try {
            if (ts.dimension && ts.target) purgeBallEntitiesNear(ts.dimension, ts.target, 32);
          } catch {}
          try {
            if (ts.player?.isValid) purgeBallEntitiesNear(ts.player.dimension, ts.player.location, 48);
          } catch {}
          activeThrows.delete(rid);
        }
        processedSentOut.delete(rid);
        pendingSentOut.delete(rid);
        pendingBallReads.delete(rid);
        // Purge any orphaned ball entities near removal point
        try {
          if (rdim && rloc) purgeBallEntitiesNear(rdim, rloc, 48);
        } catch {}
        try {
          for (const p of world.getAllPlayers()) {
            if (p?.isValid) purgeBallEntitiesNear(p.dimension, p.location, 64);
          }
        } catch {}
      } catch {}
      try {
        if (isPokemon(e) && sent(e)) {
          const owner = resolveOwnerPlayer(e);
          if (owner?.isValid) {
            playRecallSound(owner);
            try { purgeBallEntitiesNear(owner.dimension, owner.location, 64); } catch {}
          }
        }
      } catch {}
    } catch {}
  }
  if (world.beforeEvents?.entityRemove?.subscribe) {
    world.beforeEvents.entityRemove.subscribe(ev => {
      try {
        const e = ev?.removedEntity || ev?.entity || null;
        handlePokemonRemoved(e);
      } catch {}
    });
  } else if (world.afterEvents?.entityRemove?.subscribe) {
    world.afterEvents.entityRemove.subscribe(ev => {
      try {
        const e = ev?.removedEntity || ev?.entity || null;
        handlePokemonRemoved(e);
      } catch {}
    });
  }
} catch {}

function cancelThrow(id, pokemon, hideState) {
  try {
    const ts = activeThrows.get(id);
    if (ts?.ballEntity) try { ts.ballEntity.remove(); } catch {}
  } catch {}
  try { restoreHideOrigin(pokemon, hideState); } catch {}
  try { revealPokemon(pokemon, hideState); } catch {}
  activeThrows.delete(id);
}

function scan() {
  const battleEntityIds = new Set();
  const battleKeys = new Set();
  const battles = getDirectBattleStates();
  const seenBattleMons = new Map();

  for (const state of battles) {
    const bid = String(state.battleId);
    battleKeys.add(bid);

    let formation = battleAnchors.get(bid);
    if (!formation) {
      formation = {
        battleId: bid,
        locked: false,
        firstLocations: [null, null],
        firstIds: [null, null],
        positions: null,
        sideSources: [null, null],
        createdTick: system.currentTick
      };
      battleAnchors.set(bid, formation);
    }

    const e0 = state.current[0]?.entity;
    const e1 = state.current[1]?.entity;
    const s0 = state.current[0]?.sourceEntity;
    const s1 = state.current[1]?.sourceEntity;
    if (s0?.isValid) formation.sideSources[0] = s0;
    if (s1?.isValid) formation.sideSources[1] = s1;

    for (let sideIndex = 0; sideIndex < 2; sideIndex++) {
      const current = state.current[sideIndex];
      if (!current?.entity?.isValid) continue;
      battleEntityIds.add(current.entity.id);
      seenBattleMons.set(current.entity.id, { entity: current.entity, battleId: bid, sideIndex });
      if (!formation.firstLocations[sideIndex]) {
        formation.firstLocations[sideIndex] = vec(current.entity.location);
        formation.firstIds[sideIndex] = current.entity.id;
      }
    }

    if (!formation.locked && e0?.isValid && e1?.isValid) {
      lockBattleFormation(
        formation,
        e0, e1,
        formation.sideSources[0],
        formation.sideSources[1]
      );
    }

    if (formation.locked && formation.positions) {
      for (let sideIndex = 0; sideIndex < 2; sideIndex++) {
        const current = state.current[sideIndex];
        if (!current?.entity?.isValid) continue;
        const e = current.entity;
        const target = vec(formation.positions[sideIndex]);
        const opponentTarget = vec(formation.positions[sideIndex === 0 ? 1 : 0]);

        const active = activeThrows.get(e.id);
        if (active && (active.mode === "battle" || active.mode === "trainerBattle")) {
          active.target = target;
          active.opponentTarget = opponentTarget;
          markBattlePokemon(e);
          continue;
        }

        if (active && active.mode === "casual") {
          try { active.ballEntity?.remove(); } catch {}
          activeThrows.delete(e.id);
          processedSentOut.delete(e.id);
          if (active.hideState) {
            pendingSentOut.set(e.id, { firstTick: system.currentTick, hideState: active.hideState });
          }
        }

        let owner = null;
        try {
          if (current.sourceEntity?.isValid && current.sourceEntity.typeId === "minecraft:player") {
            owner = current.sourceEntity;
          }
        } catch {}
        if (!owner?.isValid) {
          try { owner = resolveOwnerPlayer(e); } catch {}
        }
        if (!owner?.isValid) {
          try {
            const src = formation.sideSources[sideIndex];
            if (src?.isValid && src.typeId === "minecraft:player") owner = src;
          } catch {}
        }

        if (owner?.isValid && owner.typeId === "minecraft:player") {
          if (!activeThrows.has(e.id) && !processedSentOut.has(e.id)) {
            let pendingState = pendingSentOut.get(e.id);
            if (!pendingState) {
              try {
                const hideState = hidePokemon(e);
                pendingState = { firstTick: system.currentTick, hideState };
                pendingSentOut.set(e.id, pendingState);
              } catch {}
            }
            if (isLikelyFormChange(e)) {
              processedSentOut.add(e.id);
              forceShowPokemon(e, null, null, { setName: false });
              markBattlePokemon(e);
              continue;
            }
            if (launchBattle(owner, e, target, opponentTarget, pendingState)) {
              pendingSentOut.delete(e.id);
              markBattlePokemon(e);
              continue;
            }
          }
        }

        if (!activeThrows.has(e.id)) {
          const pendingState = pendingSentOut.get(e.id);
          if (pendingState) {
            revealPokemon(e, pendingState.hideState, owner, target);
            pendingSentOut.delete(e.id);
          }
          enforceBattlePosition(e, target, opponentTarget);
          try { faceBattlePokemon(e, opponentTarget); } catch {}

          forceShowPokemon(e, null, null, { setName: false });
          markBattlePokemon(e);
          processedSentOut.add(e.id);
          pendingBallReads.delete(e.id);
        } else {
          markBattlePokemon(e);
        }
      }
    } else {

      const waited = system.currentTick - (formation.createdTick || system.currentTick);
      for (let sideIndex = 0; sideIndex < 2; sideIndex++) {
        const current = state.current[sideIndex];
        if (!current?.entity?.isValid) continue;
        const e = current.entity;
        battleEntityIds.add(e.id);
        markBattlePokemon(e);
        const active = activeThrows.get(e.id);
        if (active && active.mode === "casual") {
          try { active.ballEntity?.remove(); } catch {}
          activeThrows.delete(e.id);
          processedSentOut.delete(e.id);
          if (active.hideState) {
            pendingSentOut.set(e.id, { firstTick: system.currentTick, hideState: active.hideState });
          }
        }
        if (waited > 40) {
          const pendingState = pendingSentOut.get(e.id);
          if (pendingState) {
            revealPokemon(e, pendingState.hideState, current.sourceEntity, null);
            pendingSentOut.delete(e.id);
          } else {
            forceShowPokemon(e, null, null, { setName: true });
          }
          processedSentOut.add(e.id);
        }
      }
    }
  }

  try {
    for (const player of world.getAllPlayers()) {
      if (!player?.isValid) continue;
      let ents = [];
      try { ents = player.dimension.getEntities({ location: player.location, maxDistance: MAX_SCAN_DISTANCE }); } catch { continue; }
      for (const e of ents) {
        if (!isPokemon(e)) continue;
        let tagged = false;
        try { tagged = e.hasTag("pokeb:fx_in_battle"); } catch {}
        if (!tagged) continue;
        if (battleEntityIds.has(e.id)) continue;

        unmarkBattlePokemon(e);

        let owned = false;
        try { owned = ownedPokemon(e); } catch {}
        let owner = null;
        try { owner = resolveOwnerPlayer(e); } catch {}
        const isPlayerOwned = owned || (owner?.isValid && owner.typeId === "minecraft:player");
        if (!isPlayerOwned && sent(e)) {
          try { e.remove(); } catch {}
          continue;
        }

        forceShowPokemon(e, null, null);
      }
    }
  } catch {}

  for (const [id, throwState] of Array.from(activeThrows.entries())) {
    const p = throwState?.pokemon;
    if (!p) continue;
    if (throwState.mode === "battle" || throwState.mode === "trainerBattle") continue;
    if (battleEntityIds.has(id) || directBattleMembership(p) || isInBattleReliable(p)) {
      try { throwState.ballEntity?.remove(); } catch {}
      activeThrows.delete(id);
      processedSentOut.delete(id);
      if (throwState.hideState && p?.isValid) {
        pendingSentOut.set(id, { firstTick: system.currentTick, hideState: throwState.hideState });
      }
    }
  }

  let players = [];
  try { players = world.getAllPlayers(); } catch { return; }
  const seen = new Set();
  for (const player of players) {
    if (!player?.isValid) continue;

    if (isPlayerInBattle(player)) continue;

    let ents = [];
    try { ents = player.dimension.getEntities({ location: player.location, maxDistance: MAX_SCAN_DISTANCE }); } catch { continue; }
    for (const e of ents) {
      if (!isPokemon(e) || !sent(e)) continue;
      seen.add(e.id);
      if (battleEntityIds.has(e.id)) continue;
      if (directBattleMembership(e)) continue;
      if (isInBattleReliable(e)) continue;
      if (isBattlePokemon(e) || isNearAnyBattle(e, 40)) continue;
      if (processedSentOut.has(e.id) || activeThrows.has(e.id)) continue;
      if (!isOwnedByPlayer(e, player)) continue;

      if (isLikelyFormChange(e)) {
        processedSentOut.add(e.id);
        forceShowPokemon(e, null, null);
        continue;
      }

      const pendingState = pendingSentOut.get(e.id) || ensurePendingHide(e);
      if (!pendingState) continue;
      if (launch(player, e, pendingState)) pendingSentOut.delete(e.id);
    }
  }

  for (const id of Array.from(processedSentOut)) {
    if (!seen.has(id) && !battleEntityIds.has(id) && !activeThrows.has(id)) processedSentOut.delete(id);
  }
  for (const id of Array.from(pendingBallReads.keys())) {
    if (!seen.has(id) && !activeThrows.has(id)) pendingBallReads.delete(id);
  }
  for (const id of Array.from(pendingSentOut.keys())) {
    if (!seen.has(id) && !battleEntityIds.has(id) && !activeThrows.has(id)) pendingSentOut.delete(id);
  }

  for (const [key, formation] of Array.from(battleAnchors.entries())) {
    if (!battleKeys.has(String(formation.battleId))) battleAnchors.delete(key);
  }
  for (const key of Array.from(trainerBattleLastPokemon.keys())) {
    const battleId = String(key).split(":", 1)[0];
    if (!battleKeys.has(battleId)) trainerBattleLastPokemon.delete(key);
  }
}

function ballGlyph(ball) {
  const key = normalizedBallId(ball);
  const index = FONT_BALLS.indexOf(key);
  return index < 0 ? null : String.fromCodePoint(0xE200 + index);
}
const FONT_BALLS = [
  "ancientgreatball","ancientheavyball","ancientpokeball","ancientultraball","beastball","cherishball","christmasball","diveball","dreamball","duskball",
  "fastball","featherball","friendball","gigatonball","greatball","gsball","healball","heavyball","jetball","leadenball",
  "levelball","loveball","lureball","luxuryball","masterball","moonball","nestball","netball","originball","parkball",
  "pokeball","premierball","quickball","repeatball","safariball","sportball","strangeball","timerball","ultraball","wingball"
];
function stripBallGlyph(name) {
  try { return String(name || "").replace(/^[\uE200-\uE2FF]\s*/u, ""); } catch { return String(name || ""); }
}
function updateOwnedNameTag(pokemon) {
  if (!pokemon?.isValid) return;
  if (pendingSentOut.has(pokemon.id) || activeThrows.has(pokemon.id)) return;
  const owned = ownedPokemon(pokemon);
  const state = ownedNameTags.get(pokemon.id);
  if (!owned) {
    if (state) { try { if (state.base) pokemon.nameTag = state.base; } catch {} ownedNameTags.delete(pokemon.id); }
    return;
  }
  const ball = normalizedBallId(ballId(pokemon));
  let current = "";
  try { current = String(pokemon.nameTag || ""); } catch {}
  let base = state?.base || stripBallGlyph(current);
  if (!base || !String(base).trim()) {
    base = pokemonDisplayName(pokemon) || stripBallGlyph(current) || "";
  }
  if (!ball) {

    if (base && current !== base) {
      try { pokemon.nameTag = base; } catch {}
    }
    if (base) ownedNameTags.set(pokemon.id, { base, decorated: base, ball: null });
    return;
  }
  const glyph = ballGlyph(ball);
  if (!glyph) {
    if (base && !current) try { pokemon.nameTag = base; } catch {}
    return;
  }

  if (state && current && current !== state.decorated && stripBallGlyph(current) !== state.base) {
    const stripped = stripBallGlyph(current);
    if (stripped) base = stripped;
  }
  if (!base) return;
  const decorated = glyph + " " + base;
  try { if (current !== decorated) pokemon.nameTag = decorated; } catch {}
  ownedNameTags.set(pokemon.id, { base, decorated, ball });
}
function cleanupOldIconEntities() {
  try {
    for (const player of world.getAllPlayers()) {
      if (!player?.isValid) continue;
      const ents = player.dimension.getEntities({ location: player.location, maxDistance: NAME_TAG_SCAN_DISTANCE });
      for (const e of ents) { if (e?.typeId === OLD_ICON_ENTITY) { try { e.remove(); } catch {} } }
    }
  } catch {}
}
function updateOwnedNameTags() {
  const seen = new Set();
  try {
    for (const player of world.getAllPlayers()) {
      if (!player?.isValid) continue;
      const ents = player.dimension.getEntities({ location: player.location, maxDistance: NAME_TAG_SCAN_DISTANCE });
      for (const e of ents) { if (!isPokemon(e)) continue; seen.add(e.id); updateOwnedNameTag(e); }
    }
  } catch {}
  for (const [id, state] of Array.from(ownedNameTags.entries())) {
    if (!seen.has(id)) { ownedNameTags.delete(id); }
  }
}

function tick() {
  // ORPHAN_BALL_CLEANUP: remove floating send_ball entities with no active throw
  try {
    if (system.currentTick % 20 === 0) {
      const linked = new Set();
      for (const [, ts] of activeThrows) {
        try { if (ts.ballEntity?.id) linked.add(ts.ballEntity.id); } catch {}
      }
      for (const player of world.getAllPlayers()) {
        if (!player?.isValid) continue;
        const ents = player.dimension.getEntities({ location: player.location, maxDistance: 96 });
        for (const e of ents) {
          try {
            const tid = String(e.typeId || "");
            if (!tid.startsWith("pokeb:send_ball_")) continue;
            if (linked.has(e.id)) continue;
            e.remove();
          } catch {}
        }
      }
    }
  } catch {}
  scan();
  tickScaleGrows();
  if (system.currentTick % 2 === 0) { updateOwnedNameTags(); cleanupOldIconEntities(); }

  for (const [id, state] of Array.from(activeThrows.entries())) {
    if (!state.pokemon?.isValid) {
      try { state.ballEntity?.remove(); } catch {}
      activeThrows.delete(id);
      continue;
    }
    const isBattleThrow = state.mode === "battle" || state.mode === "trainerBattle";
    if (!isBattleThrow && (isBattlePokemon(state.pokemon) || isNearAnyBattle(state.pokemon, 40))) {

      try { state.ballEntity?.remove(); } catch {}
      activeThrows.delete(id);
      processedSentOut.delete(id);
      if (state.hideState && state.pokemon?.isValid) {
        pendingSentOut.set(id, { firstTick: system.currentTick, hideState: state.hideState });
      }
      try { purgeBallEntitiesNear(state.pokemon.dimension, state.pokemon.location, 16); } catch {}
      continue;
    }
    state.age++;
    if (state.revealAt >= 0) {
      if (state.age >= state.revealAt) {
        const land = state.impactPos || state.target;

        if (state.mode === "casual" && land) {
          try {
            state.pokemon.teleport(land);
            try { state.pokemon.setProperty("pokeb:scale", 0); } catch {}
          } catch {}
        }
        revealPokemon(state.pokemon, state.hideState, state.player, land);
        try {
          if (state.opponentTarget) faceBattlePokemon(state.pokemon, state.opponentTarget);
        } catch {}
        activeThrows.delete(id);
      } else if (state.mode === "casual") {

        const land = state.impactPos || state.target;
        if (land) {
          try {
            state.pokemon.teleport(land);
            try { state.pokemon.setProperty("pokeb:scale", 0); } catch {}
            try { state.pokemon.addEffect("invisibility", 10, { amplifier: 0, showParticles: false }); } catch {}
          } catch {}
        }
      }
      continue;
    }
    if (!state.ballEntity?.isValid) {

      const land = state.impactPos || state.target;
      revealPokemon(state.pokemon, state.hideState, state.player, land);
      activeThrows.delete(id);
      continue;
    }
    if (state.dwellUntil >= 0) {
      if (state.age >= state.dwellUntil) {
        const impact = state.impactPos || state.target;
        try { state.ballEntity?.remove(); } catch {}
        emitArrivalParticle(state.dimension, state.ball, impact, state.particleMode || state.mode);

        try {
          state.pokemon.teleport(impact);
          if (state.mode === "casual") {
            try { state.pokemon.setProperty("pokeb:scale", 0); } catch {}
            try { state.pokemon.addEffect("invisibility", MAX_THROW_TICKS + 40, { amplifier: 0, showParticles: false }); } catch {}
          }
        } catch {}
        state.raised = true;

        state.revealAt = state.age + (state.mode === "casual" ? Math.max(REVEAL_DELAY_TICKS, 2) : REVEAL_DELAY_TICKS);
        state.dwellUntil = -1;
      } else {
        try {
          if (state.ballEntity?.isValid && state.impactPos) {
            state.ballEntity.teleport(state.impactPos);
          }
        } catch {}
      }
      continue;
    }

    const target = vec(state.target);
    const start = vec(state.start);
    const totalDist = Math.max(0.001, len(sub(target, start)));
    const horizDist = Math.max(0.001, Math.sqrt(
      (target.x - start.x) * (target.x - start.x) +
      (target.z - start.z) * (target.z - start.z)
    ));
    if (state.flightT == null) state.flightT = 0;
    const vertGap = Math.abs(target.y - start.y);
    const speedDist = Math.max(horizDist + vertGap * 0.65, CASUAL_THROW_DISTANCE * 0.85, 2.2);
    const stepT = Math.min(1, THROW_SPEED / speedDist);
    state.flightT = Math.min(1, state.flightT + stepT);
    const t = state.flightT;

    const arcH = Math.max(1.35, Math.min(2.6, horizDist * 0.42));
    const peakY = Math.max(start.y, target.y) + arcH;
    const ctrl = {
      x: (start.x + target.x) * 0.5,
      y: peakY,
      z: (start.z + target.z) * 0.5
    };
    const omt = 1 - t;
    let next = {
      x: omt * omt * start.x + 2 * omt * t * ctrl.x + t * t * target.x,
      y: omt * omt * start.y + 2 * omt * t * ctrl.y + t * t * target.y,
      z: omt * omt * start.z + 2 * omt * t * ctrl.z + t * t * target.z
    };

    const prevT = Math.max(0, t - stepT);
    const prevOmt = 1 - prevT;
    const prev = {
      x: prevOmt * prevOmt * start.x + 2 * prevOmt * prevT * ctrl.x + prevT * prevT * target.x,
      y: prevOmt * prevOmt * start.y + 2 * prevOmt * prevT * ctrl.y + prevT * prevT * target.y,
      z: prevOmt * prevOmt * start.z + 2 * prevOmt * prevT * ctrl.z + prevT * prevT * target.z
    };

    try {
      // Skip collisions very close to the hand origin so a wall on the
      // player's right does not end the throw on the first tick.
      // Collisions further along the arc still land immediately.
      const HAND_CLEARANCE = 0.55;
      const pathHit = rayBlockHit(state.dimension, prev, next, 0);
      if (pathHit && len(sub(pathHit, start)) >= HAND_CLEARANCE) {
        const move = norm(sub(next, prev));
        let land = {
          x: pathHit.x - move.x * 0.35,
          y: pathHit.y,
          z: pathHit.z - move.z * 0.35
        };
        if (move.y < -0.15) {
          try {
            const top = findColumnTopY(state.dimension, pathHit.x, pathHit.z, pathHit.y);
            if (typeof top === "number" && Math.abs(top - pathHit.y) <= 1.25) {
              land = { x: pathHit.x, y: top, z: pathHit.z };
            }
          } catch {}
        }
        if (land.y > start.y + 2.5) {
          land.y = start.y + 0.2;
        }
        next = land;
        state.flightT = 1;
        state.target = land;
        target.x = land.x;
        target.y = land.y;
        target.z = land.z;
        state.impactPos = land;
        state.hitBlock = true;
      }
    } catch {}

    if (!state.raised && t >= 0.98) {
      try {
        if (state.mode === "casual") {
          state.pokemon.teleport({ x: target.x, y: target.y, z: target.z }, { dimension: state.dimension });
          try { state.pokemon.setProperty("pokeb:scale", 0); } catch {}
          try { state.pokemon.addEffect("invisibility", MAX_THROW_TICKS + 40, { amplifier: 0, showParticles: false }); } catch {}
        } else {
          state.pokemon.teleport({ x: target.x, y: target.y - 8, z: target.z }, { dimension: state.dimension });
        }
      } catch {}
      state.raised = true;
    }

    if (t >= 1 || len(sub(target, next)) <= ARRIVAL_DISTANCE) {
      try { orient(state.ballEntity, prev, target); } catch {}
      try { state.ballEntity.teleport(target); } catch {}
      state.impactPos = target;

      state.dwellUntil = state.age + (state.hitBlock ? 0 : (state.mode === "casual" ? 5 : 2));
    } else {
      try { state.ballEntity.teleport(next); } catch {}
      try { orient(state.ballEntity, prev, next); } catch {}

      if (t >= 0.45 && state.age % 5 === 0) {
        emitFlightParticle(state.dimension, state.ball, next, state.particleMode || state.mode);
      }
    }
    if (state.age > MAX_THROW_TICKS) {
      try { state.ballEntity?.remove(); } catch {}
      const land = state.impactPos || state.target;
      revealPokemon(state.pokemon, state.hideState, state.player, land);
      try {
        if (state.opponentTarget) faceBattlePokemon(state.pokemon, state.opponentTarget);
      } catch {}
      activeThrows.delete(id);
    }
  }
}
system.runInterval(tick, 1);

