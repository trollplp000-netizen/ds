/**
 * EvolutionMenu.js v9
 * Particles: pokeb:evo_particles (fixed JSON) only
 * Send-out via PlayerModel.sendOut before evo
 * model.evolve(evoObject) then post-evo stats panel (pack-style)
 */
import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const EVO_FX_TICKS = 120; // ~6s matches particle timeline
const BUSY = new Set();

globalThis.__pokebManualEvoOnly = true;
globalThis.__pokebDisableAutoEvo = true;
globalThis.__pokebManualEvoAllow = false;

function tell(player, msg) {
  try { player.sendMessage(msg); } catch (_) {}
}

function getPokedex() {
  try {
    if (globalThis.POKEMON && typeof globalThis.POKEMON === "object") return globalThis.POKEMON;
  } catch (_) {}
  return null;
}

function getModelFromEntity(entity) {
  try {
    if (globalThis.PokemonModel?.get) return globalThis.PokemonModel.get(entity);
  } catch (_) {}
  return null;
}

function normalizeTypeId(id) {
  if (!id) return "";
  let s = String(id).trim();
  if (s.startsWith("pokemon:")) return s.toLowerCase();
  s = s.toLowerCase().replace(/[^a-z0-9]/g, "");
  return s ? "pokemon:" + s : "";
}

function shortName(typeId) {
  return normalizeTypeId(typeId).replace(/^pokemon:/, "");
}

function displayName(typeId) {
  const entry = getSpeciesEntry(typeId);
  if (entry?.name) return String(entry.name);
  const s = shortName(typeId);
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : "???";
}

function getSpeciesEntry(typeId) {
  const dex = getPokedex();
  if (!dex) return null;
  const tid = normalizeTypeId(typeId);
  if (dex[tid]) return dex[tid];
  if (dex[typeId]) return dex[typeId];
  const short = shortName(tid);
  if (dex[short]) return dex[short];
  try {
    const lower = tid.toLowerCase();
    for (const k of Object.keys(dex)) {
      if (String(k).toLowerCase() === lower) return dex[k];
    }
  } catch (_) {}
  return null;
}

function getPokemonLevel(model, entity) {
  const tries = [];
  try { if (model?.data) tries.push(model.data.level, model.data.lvl); } catch (_) {}
  try { if (model) tries.push(model.level); } catch (_) {}
  try {
    if (entity?.getProperty) {
      tries.push(entity.getProperty("pokeb:level"));
      tries.push(entity.getProperty("pokemon:level"));
    }
  } catch (_) {}
  for (const v of tries) {
    const n = Number(v);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return 1;
}

function getTypeIdFromModel(model, entity) {
  const tries = [];
  try { if (model?.data?.typeId) tries.push(model.data.typeId); } catch (_) {}
  try { if (model?.typeId) tries.push(model.typeId); } catch (_) {}
  try { if (entity?.typeId) tries.push(entity.typeId); } catch (_) {}
  for (const t of tries) {
    const n = normalizeTypeId(t);
    if (n) return n;
  }
  return "";
}

function collectEvolutions(typeId, currentLevel) {
  const results = [];
  const seen = new Set();
  if (!getPokedex()) return results;
  function walk(tid, depth) {
    if (depth > 8) return;
    const entry = getSpeciesEntry(tid);
    if (!entry?.evolutions?.length) return;
    for (const evo of entry.evolutions) {
      if (!evo) continue;
      let nextId = "";
      let needLevel = null;
      let trigger = "";
      if (typeof evo === "string") {
        nextId = normalizeTypeId(evo);
      } else {
        nextId = normalizeTypeId(evo.typeId || evo.id || evo.species || "");
        trigger = String(evo.trigger || "").toLowerCase();
        if (evo.level != null) needLevel = Number(evo.level);
        else if (evo.evoLevel != null) needLevel = Number(evo.evoLevel);
      }
      if (!nextId || seen.has(nextId)) continue;
      if (trigger && trigger !== "level" && trigger !== "level_up" && trigger !== "levelup") {
        if (needLevel == null) continue;
      }
      seen.add(nextId);
      const ok = needLevel == null || currentLevel >= needLevel;
      const evoObject = typeof evo === "object"
        ? { ...evo, typeId: nextId }
        : { typeId: nextId, trigger: "level", level: needLevel };
      results.push({
        typeId: nextId,
        name: displayName(nextId),
        needLevel,
        available: ok,
        icon: "textures/sprites/default/" + shortName(nextId),
        evoObject,
      });
      walk(nextId, depth + 1);
    }
  }
  walk(normalizeTypeId(typeId), 0);
  return results;
}

function playEvoParticles(dim, loc) {
  const p = { x: loc.x, y: loc.y + 1.0, z: loc.z };
  // Master timeline particle (user particles, fixed JSON)
  try { dim.spawnParticle("pokeb:evo_particles", p); } catch (e) {
    console.warn("[EVO] master particle fail: " + e);
  }
  // Fallback schedule individual emitters in case events don't fire
  const seq = [
    [0, "pokeb:evo_buildup"],
    [0, "pokeb:evo_sparkle"],
    [10, "pokeb:evo_obscuring"],
    [10, "pokeb:evo_godrays"],
    [30, "pokeb:evo_flyingsparkles"],
    [50, "pokeb:evo_implode"],
    [70, "pokeb:evo_sparkleburst"],
    [70, "pokeb:evo_bigsparkle"],
    [80, "pokeb:evo_sparklefetti"],
    [80, "pokeb:evo_smokeburst"],
    [100, "pokeb:evo_bigsparkle"],
  ];
  for (const [t, id] of seq) {
    system.runTimeout(() => {
      try { dim.spawnParticle(id, p); } catch (_) {}
    }, t);
  }
}

function findSentOutEntity(player, model) {
  try {
    const uid = model?.data?.uniqueId != null ? String(model.data.uniqueId) : null;
    if (!uid) return null;
    try {
      if (globalThis.SlotsModel?.findSentOutPokemon) {
        const actor = globalThis.SlotsModel.findSentOutPokemon(uid);
        if (actor) {
          const e = actor.entity || actor;
          if (e?.isValid) return e;
        }
      }
    } catch (_) {}
    for (const e of player.dimension.getEntities({ location: player.location, maxDistance: 96 })) {
      try {
        if (!e.typeId || !e.typeId.startsWith("pokemon:")) continue;
        const m = getModelFromEntity(e);
        if (m && String(m.data?.uniqueId) === uid) return e;
      } catch (_) {}
    }
  } catch (_) {}
  return null;
}

function trySendOut(player, model, slotIndex) {
  try {
    const loc = model?.data?.location;
    if (loc === "world" || loc === "sentOut") return true;
  } catch (_) {}

  const PM = globalThis.PlayerModel;
  const pm = PM?.get?.(player);
  if (!pm) {
    console.warn("[EVO] no PlayerModel");
    return false;
  }

  // Pack GUI uses method ending with 't' → sendOut(player, slot)
  const names = [
    "sendOut", "SendOut", "sendOutPokemon", "letOut", "releaseToWorld",
    "sendOutSlot", "spawnOut", "throwOut", "setOut"
  ];
  for (const name of names) {
    if (typeof pm[name] !== "function") continue;
    try {
      pm[name](player, slotIndex);
      console.warn("[EVO] sendOut " + name + "(player,slot)");
      return true;
    } catch (_) {}
    try {
      pm[name](slotIndex);
      console.warn("[EVO] sendOut " + name + "(slot)");
      return true;
    } catch (_) {}
    try {
      pm[name](player, slotIndex, model);
      return true;
    } catch (_) {}
  }

  // Scan all functions on pm for names containing 'out' or 'send'
  try {
    const proto = Object.getPrototypeOf(pm);
    const keys = new Set([
      ...Object.getOwnPropertyNames(pm || {}),
      ...Object.getOwnPropertyNames(proto || {}),
    ]);
    for (const k of keys) {
      if (typeof pm[k] !== "function") continue;
      const low = k.toLowerCase();
      if (!(low.includes("send") || low.includes("out") || low.includes("throw"))) continue;
      if (low.includes("message") || low.includes("sidebar")) continue;
      try {
        pm[k](player, slotIndex);
        console.warn("[EVO] sendOut scanned " + k);
        return true;
      } catch (_) {}
      try {
        pm[k](slotIndex);
        console.warn("[EVO] sendOut scanned " + k + "(slot)");
        return true;
      } catch (_) {}
    }
  } catch (e) {
    console.warn("[EVO] scan sendOut: " + e);
  }
  return false;
}

function snapshotStats(model, typeId) {
  const sp = getSpeciesEntry(typeId);
  const base = sp?.stats || sp?.baseStats || {};
  const level = getPokemonLevel(model, null);
  // rough display stats
  const keys = ["hp", "atk", "def", "spa", "spd", "spe"];
  const out = {};
  for (const k of keys) {
    const b = Number(base[k] || base[k?.toUpperCase?.()] || 0);
    out[k] = b > 0 ? Math.floor(((2 * b + 31) * level) / 100 + (k === "hp" ? level + 10 : 5)) : 0;
  }
  return out;
}


function forceEntityFormChange(player, model, targetTypeId, fromTypeId) {
  try {
    // Mark skip so SendReturnFX does not throw ball for form swap
    try {
      globalThis.__pokebMegaSkipSendFx = globalThis.__pokebMegaSkipSendFx || new Set();
      const uid = model?.data?.uniqueId;
      if (uid != null) {
        globalThis.__pokebMegaSkipSendFx.add(uid);
        globalThis.__pokebMegaSkipSendFx.add(String(uid));
        system.runTimeout(() => {
          try {
            globalThis.__pokebMegaSkipSendFx.delete(uid);
            globalThis.__pokebMegaSkipSendFx.delete(String(uid));
          } catch (_) {}
        }, 80);
      }
    } catch (_) {}

    // Prefer pack handleFormeChange
    try {
      if (typeof handleFormeChange === "function") {
        handleFormeChange(player, model, targetTypeId);
      }
    } catch (e) { console.warn("[EVO] handleFormeChange: " + e); }

    try {
      if (typeof model.setTypeId === "function") model.setTypeId(targetTypeId);
      else if (model.data) model.data.typeId = targetTypeId;
    } catch (_) {}

    // Find current entity and trigger changeForme / replace
    let ent = findSentOutEntity(player, model);
    if (ent && ent.isValid) {
      const loc = { x: ent.location.x, y: ent.location.y, z: ent.location.z };
      const dim = ent.dimension;
      try { ent.triggerEvent("changeForme_" + targetTypeId); } catch (_) {}
      try { ent.triggerEvent("show"); } catch (_) {}

      // Poll for new type entity (pack may despawn+respawn)
      let tries = 0;
      const poll = () => {
        tries++;
        let found = findSentOutEntity(player, model);
        if (found && found.isValid) {
          const tid = String(found.typeId || "").toLowerCase();
          if (tid === targetTypeId || tid.includes(shortName(targetTypeId))) {
            try { found.teleport(loc, { dimension: dim, keepVelocity: false }); } catch (_) {}
            try { found.triggerEvent("show"); } catch (_) {}
            return;
          }
        }
        if (tries < 25) system.runTimeout(poll, 2);
        else {
          // Last resort: remove old entity so next send-out shows correct form
          try {
            if (ent.isValid && String(ent.typeId).toLowerCase() !== targetTypeId) {
              // keep entity but force events again
              try { ent.triggerEvent("changeForme_" + targetTypeId); } catch (_) {}
            }
          } catch (_) {}
        }
      };
      system.runTimeout(poll, 4);
    }
  } catch (e) {
    console.warn("[EVO] forceEntityFormChange: " + e);
  }
}

function getNewMovesForLevel(typeId, level) {
  const moves = [];
  try {
    if (typeof getMovesAtLevel === "function") {
      const m = getMovesAtLevel(typeId, level);
      if (Array.isArray(m)) return m.map((x) => (x?.name || x?.id || x)).filter(Boolean);
    }
  } catch (_) {}
  try {
    const sp = getSpeciesEntry(typeId);
    const list = sp?.moves || sp?.learnset || [];
    for (const m of list) {
      if (!m) continue;
      const method = String(m.learnMethod || m.method || "").toLowerCase();
      if (method && method !== "level" && method !== "level-up" && method !== "levelup") continue;
      const lv = m.level != null ? Number(m.level) : (m.lvl != null ? Number(m.lvl) : null);
      if (lv != null && lv <= level) {
        const name = m.move || m.name || m.id;
        if (name) moves.push(String(name));
      }
    }
  } catch (_) {}
  // unique
  return [...new Set(moves)].slice(-8);
}


/** Pack-style post-evolution stats panel (before → after) */
async function showPostEvoStatsPanel(player, model, oldTypeId, newTypeId, oldStats) {
  try {
    const form = new ActionFormData();
    const nick = model?.data?.nickName || displayName(newTypeId);
    form.title(String(nick));
    const newStats = snapshotStats(model, newTypeId);
    const labels = { hp: "HP", atk: "Atk", def: "Def", spa: "SpA", spd: "SpD", spe: "Spe" };
    const lines = [];
    lines.push("§a" + displayName(oldTypeId) + " §7→ §b" + displayName(newTypeId));
    lines.push("§8Lv." + getPokemonLevel(model, null));
    lines.push("");
    for (const k of ["hp", "atk", "def", "spa", "spd", "spe"]) {
      const a = oldStats?.[k] ?? 0;
      const b = newStats?.[k] ?? 0;
      const diff = b - a;
      const sign = diff > 0 ? "§a+" + diff : (diff < 0 ? "§c" + diff : "§70");
      lines.push("§f" + labels[k] + "  §7" + a + " §f→ §b" + b + "  " + sign);
    }
    const newMoves = getNewMovesForLevel(newTypeId, getPokemonLevel(model, null));
    if (newMoves.length) {
      lines.push("");
      lines.push("§eNew moves available:");
      for (const m of newMoves) lines.push("§7- §f" + m);
    }
    form.body(lines.join("\n"));
    form.button("§aOK");
    await form.show(player);
  } catch (e) {
    console.warn("[EVO] post panel: " + e);
  }
}

async function runEvolve(player, entity, model, pick, slotIndex) {
  const evoObject = pick.evoObject || {
    typeId: pick.typeId,
    trigger: "level",
    level: pick.needLevel,
  };
  const targetTypeId = normalizeTypeId(pick.typeId);
  const targetName = pick.name;
  const uid = String(model?.data?.uniqueId ?? entity?.id ?? player.id);

  if (BUSY.has(uid)) {
    tell(player, "§c[EVO] Evolution already in progress.");
    return;
  }
  BUSY.add(uid);

  const fromTypeId = getTypeIdFromModel(model, entity);
  const fromName = displayName(fromTypeId);
  const oldStats = snapshotStats(model, fromTypeId);
  tell(player, "§d[EVO] §f" + fromName + " is evolving...");

  // 1) Send out if still in inventory
  let activeEntity = entity?.isValid ? entity : findSentOutEntity(player, model);
  const loc0 = model?.data?.location;
  if (!activeEntity && loc0 !== "world" && loc0 !== "sentOut") {
    tell(player, "§7[EVO] Sending out...");
    const ok = trySendOut(player, model, slotIndex);
    console.warn("[EVO] trySendOut=" + ok);
    for (let i = 0; i < 40; i++) {
      await new Promise((r) => system.runTimeout(r, 2));
      activeEntity = findSentOutEntity(player, model);
      if (activeEntity?.isValid) break;
    }
  }

  const dim = activeEntity?.dimension || player.dimension;
  const loc = activeEntity?.isValid
    ? { x: activeEntity.location.x, y: activeEntity.location.y, z: activeEntity.location.z }
    : { x: player.location.x, y: player.location.y, z: player.location.z };

  // Mark so SendReturnFX won't treat post-evo form change as a throw
  try {
    globalThis.__pokebMegaSkipSendFx = globalThis.__pokebMegaSkipSendFx || new Set();
    globalThis.__pokebMegaSkipSendFx.add(uid);
    if (activeEntity?.id) globalThis.__pokebMegaSkipSendFx.add(activeEntity.id);
    system.runTimeout(() => {
      try {
        globalThis.__pokebMegaSkipSendFx.delete(uid);
        if (activeEntity?.id) globalThis.__pokebMegaSkipSendFx.delete(activeEntity.id);
      } catch (_) {}
    }, EVO_FX_TICKS + 40);
  } catch (_) {}

  if (activeEntity?.isValid) {
    try { activeEntity.triggerEvent("hide"); } catch (_) {}
  }

  // 2) User particles only
  playEvoParticles(dim, loc);

  // 3) After FX → evolve data
  system.runTimeout(() => {
    try {
      globalThis.__pokebManualEvoAllow = true;

      try {
        if (typeof model.evolve === "function") {
          const r = model.evolve(evoObject);
          if (r && typeof r.then === "function") r.catch(() => {});
        }
      } catch (e) {
        console.warn("[EVO] model.evolve: " + e);
      }

      try {
        const now = getTypeIdFromModel(model, null);
        if (now !== targetTypeId) {
          if (typeof model.setTypeId === "function") model.setTypeId(targetTypeId);
          else if (model.data) model.data.typeId = targetTypeId;
        }
      } catch (_) {}

      // Force visual form change on entity (not just party data)
      forceEntityFormChange(player, model, targetTypeId, fromTypeId);

      tell(player, "§a[EVO] §f" + fromName + " evolved into " + targetName + "!");
      try { if (typeof updateSidebar === "function") updateSidebar(player); } catch (_) {}

      // 4) Post-evo stats + moves panel
      system.runTimeout(() => {
        showPostEvoStatsPanel(player, model, fromTypeId, targetTypeId, oldStats);
      }, 8);
    } finally {
      globalThis.__pokebManualEvoAllow = false;
      BUSY.delete(uid);
    }
  }, EVO_FX_TICKS);
}

async function openEvolutionForm(player, entity, model, slotIndex) {
  if (!model && entity) model = getModelFromEntity(entity);
  if (!model) {
    tell(player, "§c[EVO] Could not read Pokemon data.");
    return;
  }
  const typeId = getTypeIdFromModel(model, entity);
  const level = getPokemonLevel(model, entity);
  if (!getPokedex()) {
    tell(player, "§c[EVO] Pokedex not loaded.");
    return;
  }
  if (!typeId) {
    tell(player, "§c[EVO] No species.");
    return;
  }
  const evos = collectEvolutions(typeId, level);
  const form = new ActionFormData();
  form.title("Evolution");
  if (!evos.length) {
    form.body(displayName(typeId) + "  Lv." + level + "\nNo level evolutions.");
    form.button("Back");
    await form.show(player);
    return;
  }
  form.body(displayName(typeId) + "  Lv." + level + "\nSelect an evolution:");
  const options = [];
  for (const e of evos) {
    const label = e.available
      ? (e.name + (e.needLevel != null ? "  (Lv." + e.needLevel + ")" : ""))
      : (e.name + "  (Need Lv." + e.needLevel + ")");
    try { form.button(label, e.icon); } catch (_) { form.button(label); }
    options.push(e);
  }
  form.button("Back");
  const res = await form.show(player);
  if (res.canceled || res.selection == null) return;
  if (res.selection >= options.length) return;
  const pick = options[res.selection];
  if (!pick.available) {
    tell(player, "§c[EVO] Need level " + pick.needLevel + ".");
    return;
  }
  await runEvolve(player, entity, model, pick, slotIndex);
}

globalThis.__pokebOpenPartyEvolution = function (player, slotIndex, modelArg) {
  try {
    system.run(() => openFromParty(player, slotIndex, modelArg));
  } catch (e) {
    console.warn("[EVO] openParty: " + e);
  }
};

async function openFromParty(player, slotIndex, modelArg) {
  try {
    let model = null;
    let entity = null;
    if (modelArg && (modelArg.data || modelArg.typeId)) model = modelArg;
    if (!model) {
      try {
        const pm = globalThis.PlayerModel?.get?.(player);
        if (pm?.getPartySlot) model = pm.getPartySlot(slotIndex);
      } catch (_) {}
    }
    entity = findSentOutEntity(player, model);
    if (!model) {
      tell(player, "§c[EVO] Could not find that party Pokemon.");
      return;
    }
    await openEvolutionForm(player, entity, model, slotIndex);
  } catch (e) {
    console.warn("[EVO] party: " + e);
    tell(player, "§c[EVO] " + e);
  }
}

system.runTimeout(() => {
  try {
    if (typeof AUTO_EVOLUTION_TRIGGERS !== "undefined" && AUTO_EVOLUTION_TRIGGERS?.clear)
      AUTO_EVOLUTION_TRIGGERS.clear();
  } catch (_) {}
  try {
    const PM = globalThis.PokemonModel;
    if (PM?.prototype?.evolve && !PM.prototype.__pokebEvoWrapped) {
      const orig = PM.prototype.evolve;
      PM.prototype.evolve = function (...args) {
        if (globalThis.__pokebDisableAutoEvo && !globalThis.__pokebManualEvoAllow) return;
        return orig.apply(this, args);
      };
      PM.prototype.__pokebEvoWrapped = true;
    }
  } catch (_) {}
  console.warn("[EVO v9] ready");
}, 60);

console.warn("[EvolutionMenu v9] loaded");
